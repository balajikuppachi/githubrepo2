package com.wf.df.sdr.dto;

import java.io.Serializable;

/*@Table : CID_STATIC_DATA */
public class CIDStaticData implements Serializable
{
	private Integer busAIdC;
	private String  busAN;
	private String  systemC;
	private String  busAExtlKeyC;
	private String  busAExtlN;
	private String  relationshipType;
	private Integer lgleIdC;
	private String  lgleTypeC;
	private String  lgleFullN;
	private String  regEntitySwapDealer;
	private String  etSDRates;
	private String  etSDEquityderivatives;
	private String  etSDCommodities;
	private String  etSDCreditderivatives;
	private String  etSDFX;
	private String  regEntitySecBasedSwapDealer;
	private String  etSBSDRates;
	private String  etSBSDEquityderivatives;
	private String  etSBSDCommodities;
	private String  etSBSDCreditderivatives;
	private String  etSBSDFX;
	private String  regEntityMajorSwap;
	private String  etMSPRates;
	private String  etMSPEquityderivatives;
	private String  etMSPCommodities;
	private String  etMSPCreditderivatives;
	private String  etMSPFX;
	private String  regEntitySecBasedMajorSwap;
	private String  etSBMSPRates;
	private String  etSBMSPEquityderivatives;
	private String  etSBMSPCommodities;
	private String  etSBMSPCreditderivatives;
	private String  etSBMSPFX;
	private String  regEntityEndUser;
	private String  dfETEUEndUserType;
	private String  isdaRiskValuation;
	private String  isdaPortfolioRecon;
	private String  portfolioDataMethod;
	private String  deliveryPortfolioDataEmail;
	private String  reconSDRData;
	private String  qualifier;

	public Integer getBusAIdC() {
		return busAIdC;
	}
	public void setBusAIdC(Integer busAIdC) {
		this.busAIdC = busAIdC;
	}
	public String getBusAN() {
		return busAN;
	}
	public void setBusAN(String busAN) {
		this.busAN = busAN;
	}
	public String getSystemC() {
		return systemC;
	}
	public void setSystemC(String systemC) {
		this.systemC = systemC;
	}
	public String getBusAExtlKeyC() {
		return busAExtlKeyC;
	}
	public void setBusAExtlKeyC(String busAExtlKeyC) {
		this.busAExtlKeyC = busAExtlKeyC;
	}
	public String getBusAExtlN() {
		return busAExtlN;
	}
	public void setBusAExtlN(String busAExtlN) {
		this.busAExtlN = busAExtlN;
	}
	public String getRelationshipType() {
		return relationshipType;
	}
	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}
	public Integer getLgleIdC() {
		return lgleIdC;
	}
	public void setLgleIdC(Integer lgleIdC) {
		this.lgleIdC = lgleIdC;
	}
	public String getLgleTypeC() {
		return lgleTypeC;
	}
	public void setLgleTypeC(String lgleTypeC) {
		this.lgleTypeC = lgleTypeC;
	}
	public String getLgleFullN() {
		return lgleFullN;
	}
	public void setLgleFullN(String lgleFullN) {
		this.lgleFullN = lgleFullN;
	}
	public String getRegEntitySwapDealer() {
		return regEntitySwapDealer;
	}
	public void setRegEntitySwapDealer(String regEntitySwapDealer) {
		this.regEntitySwapDealer = regEntitySwapDealer;
	}
	public String getEtSDRates() {
		return etSDRates;
	}
	public void setEtSDRates(String etSDRates) {
		this.etSDRates = etSDRates;
	}
	public String getEtSDEquityderivatives() {
		return etSDEquityderivatives;
	}
	public void setEtSDEquityderivatives(String etSDEquityderivatives) {
		this.etSDEquityderivatives = etSDEquityderivatives;
	}
	public String getEtSDCommodities() {
		return etSDCommodities;
	}
	public void setEtSDCommodities(String etSDCommodities) {
		this.etSDCommodities = etSDCommodities;
	}
	public String getEtSDCreditderivatives() {
		return etSDCreditderivatives;
	}
	public void setEtSDCreditderivatives(String etSDCreditderivatives) {
		this.etSDCreditderivatives = etSDCreditderivatives;
	}
	public String getEtSDFX() {
		return etSDFX;
	}
	public void setEtSDFX(String etSDFX) {
		this.etSDFX = etSDFX;
	}
	public String getRegEntitySecBasedSwapDealer() {
		return regEntitySecBasedSwapDealer;
	}
	public void setRegEntitySecBasedSwapDealer(String regEntitySecBasedSwapDealer) {
		this.regEntitySecBasedSwapDealer = regEntitySecBasedSwapDealer;
	}
	public String getEtSBSDRates() {
		return etSBSDRates;
	}
	public void setEtSBSDRates(String etSBSDRates) {
		this.etSBSDRates = etSBSDRates;
	}
	public String getEtSBSDEquityderivatives() {
		return etSBSDEquityderivatives;
	}
	public void setEtSBSDEquityderivatives(String etSBSDEquityderivatives) {
		this.etSBSDEquityderivatives = etSBSDEquityderivatives;
	}
	public String getEtSBSDCommodities() {
		return etSBSDCommodities;
	}
	public void setEtSBSDCommodities(String etSBSDCommodities) {
		this.etSBSDCommodities = etSBSDCommodities;
	}
	public String getEtSBSDCreditderivatives() {
		return etSBSDCreditderivatives;
	}
	public void setEtSBSDCreditderivatives(String etSBSDCreditderivatives) {
		this.etSBSDCreditderivatives = etSBSDCreditderivatives;
	}
	public String getEtSBSDFX() {
		return etSBSDFX;
	}
	public void setEtSBSDFX(String etSBSDFX) {
		this.etSBSDFX = etSBSDFX;
	}
	public String getRegEntityMajorSwap() {
		return regEntityMajorSwap;
	}
	public void setRegEntityMajorSwap(String regEntityMajorSwap) {
		this.regEntityMajorSwap = regEntityMajorSwap;
	}
	public String getEtMSPRates() {
		return etMSPRates;
	}
	public void setEtMSPRates(String etMSPRates) {
		this.etMSPRates = etMSPRates;
	}
	public String getEtMSPEquityderivatives() {
		return etMSPEquityderivatives;
	}
	public void setEtMSPEquityderivatives(String etMSPEquityderivatives) {
		this.etMSPEquityderivatives = etMSPEquityderivatives;
	}
	public String getEtMSPCommodities() {
		return etMSPCommodities;
	}
	public void setEtMSPCommodities(String etMSPCommodities) {
		this.etMSPCommodities = etMSPCommodities;
	}
	public String getEtMSPCreditderivatives() {
		return etMSPCreditderivatives;
	}
	public void setEtMSPCreditderivatives(String etMSPCreditderivatives) {
		this.etMSPCreditderivatives = etMSPCreditderivatives;
	}
	public String getEtMSPFX() {
		return etMSPFX;
	}
	public void setEtMSPFX(String etMSPFX) {
		this.etMSPFX = etMSPFX;
	}
	public String getRegEntitySecBasedMajorSwap() {
		return regEntitySecBasedMajorSwap;
	}
	public void setRegEntitySecBasedMajorSwap(String regEntitySecBasedMajorSwap) {
		this.regEntitySecBasedMajorSwap = regEntitySecBasedMajorSwap;
	}
	public String getEtSBMSPRates() {
		return etSBMSPRates;
	}
	public void setEtSBMSPRates(String etSBMSPRates) {
		this.etSBMSPRates = etSBMSPRates;
	}
	public String getEtSBMSPEquityderivatives() {
		return etSBMSPEquityderivatives;
	}
	public void setEtSBMSPEquityderivatives(String etSBMSPEquityderivatives) {
		this.etSBMSPEquityderivatives = etSBMSPEquityderivatives;
	}
	public String getEtSBMSPCommodities() {
		return etSBMSPCommodities;
	}
	public void setEtSBMSPCommodities(String etSBMSPCommodities) {
		this.etSBMSPCommodities = etSBMSPCommodities;
	}
	public String getEtSBMSPCreditderivatives() {
		return etSBMSPCreditderivatives;
	}
	public void setEtSBMSPCreditderivatives(String etSBMSPCreditderivatives) {
		this.etSBMSPCreditderivatives = etSBMSPCreditderivatives;
	}
	public String getEtSBMSPFX() {
		return etSBMSPFX;
	}
	public void setEtSBMSPFX(String etSBMSPFX) {
		this.etSBMSPFX = etSBMSPFX;
	}
	public String getRegEntityEndUser() {
		return regEntityEndUser;
	}
	public void setRegEntityEndUser(String regEntityEndUser) {
		this.regEntityEndUser = regEntityEndUser;
	}
	public String getDfETEUEndUserType() {
		return dfETEUEndUserType;
	}
	public void setDfETEUEndUserType(String dfETEUEndUserType) {
		this.dfETEUEndUserType = dfETEUEndUserType;
	}
	public String getIsdaRiskValuation() {
		return isdaRiskValuation;
	}
	public void setIsdaRiskValuation(String isdaRiskValuation) {
		this.isdaRiskValuation = isdaRiskValuation;
	}
	public String getIsdaPortfolioRecon() {
		return isdaPortfolioRecon;
	}
	public void setIsdaPortfolioRecon(String isdaPortfolioRecon) {
		this.isdaPortfolioRecon = isdaPortfolioRecon;
	}
	public String getPortfolioDataMethod() {
		return portfolioDataMethod;
	}
	public void setPortfolioDataMethod(String portfolioDataMethod) {
		this.portfolioDataMethod = portfolioDataMethod;
	}
	public String getDeliveryPortfolioDataEmail() {
		return deliveryPortfolioDataEmail;
	}
	public void setDeliveryPortfolioDataEmail(String deliveryPortfolioDataEmail) {
		this.deliveryPortfolioDataEmail = deliveryPortfolioDataEmail;
	}
	public String getReconSDRData() {
		return reconSDRData;
	}
	public void setReconSDRData(String reconSDRData) {
		this.reconSDRData = reconSDRData;
	}
	public String getQualifier() {
		return qualifier;
	}
	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((busAExtlKeyC == null) ? 0 : busAExtlKeyC.hashCode());
		result = prime * result
				+ ((busAExtlN == null) ? 0 : busAExtlN.hashCode());
		result = prime * result + ((busAIdC == null) ? 0 : busAIdC.hashCode());
		result = prime * result + ((busAN == null) ? 0 : busAN.hashCode());
		result = prime
				* result
				+ ((deliveryPortfolioDataEmail == null) ? 0
						: deliveryPortfolioDataEmail.hashCode());
		result = prime
				* result
				+ ((dfETEUEndUserType == null) ? 0 : dfETEUEndUserType
						.hashCode());
		result = prime
				* result
				+ ((etMSPCommodities == null) ? 0 : etMSPCommodities.hashCode());
		result = prime
				* result
				+ ((etMSPCreditderivatives == null) ? 0
						: etMSPCreditderivatives.hashCode());
		result = prime
				* result
				+ ((etMSPEquityderivatives == null) ? 0
						: etMSPEquityderivatives.hashCode());
		result = prime * result + ((etMSPFX == null) ? 0 : etMSPFX.hashCode());
		result = prime * result
				+ ((etMSPRates == null) ? 0 : etMSPRates.hashCode());
		result = prime
				* result
				+ ((etSBMSPCommodities == null) ? 0 : etSBMSPCommodities
						.hashCode());
		result = prime
				* result
				+ ((etSBMSPCreditderivatives == null) ? 0
						: etSBMSPCreditderivatives.hashCode());
		result = prime
				* result
				+ ((etSBMSPEquityderivatives == null) ? 0
						: etSBMSPEquityderivatives.hashCode());
		result = prime * result
				+ ((etSBMSPFX == null) ? 0 : etSBMSPFX.hashCode());
		result = prime * result
				+ ((etSBMSPRates == null) ? 0 : etSBMSPRates.hashCode());
		result = prime
				* result
				+ ((etSBSDCommodities == null) ? 0 : etSBSDCommodities
						.hashCode());
		result = prime
				* result
				+ ((etSBSDCreditderivatives == null) ? 0
						: etSBSDCreditderivatives.hashCode());
		result = prime
				* result
				+ ((etSBSDEquityderivatives == null) ? 0
						: etSBSDEquityderivatives.hashCode());
		result = prime * result
				+ ((etSBSDFX == null) ? 0 : etSBSDFX.hashCode());
		result = prime * result
				+ ((etSBSDRates == null) ? 0 : etSBSDRates.hashCode());
		result = prime * result
				+ ((etSDCommodities == null) ? 0 : etSDCommodities.hashCode());
		result = prime
				* result
				+ ((etSDCreditderivatives == null) ? 0 : etSDCreditderivatives
						.hashCode());
		result = prime
				* result
				+ ((etSDEquityderivatives == null) ? 0 : etSDEquityderivatives
						.hashCode());
		result = prime * result + ((etSDFX == null) ? 0 : etSDFX.hashCode());
		result = prime * result
				+ ((etSDRates == null) ? 0 : etSDRates.hashCode());
		result = prime
				* result
				+ ((isdaPortfolioRecon == null) ? 0 : isdaPortfolioRecon
						.hashCode());
		result = prime
				* result
				+ ((isdaRiskValuation == null) ? 0 : isdaRiskValuation
						.hashCode());
		result = prime * result
				+ ((lgleFullN == null) ? 0 : lgleFullN.hashCode());
		result = prime * result + ((lgleIdC == null) ? 0 : lgleIdC.hashCode());
		result = prime * result
				+ ((lgleTypeC == null) ? 0 : lgleTypeC.hashCode());
		result = prime
				* result
				+ ((portfolioDataMethod == null) ? 0 : portfolioDataMethod
						.hashCode());
		result = prime * result
				+ ((qualifier == null) ? 0 : qualifier.hashCode());
		result = prime * result
				+ ((reconSDRData == null) ? 0 : reconSDRData.hashCode());
		result = prime
				* result
				+ ((regEntityEndUser == null) ? 0 : regEntityEndUser.hashCode());
		result = prime
				* result
				+ ((regEntityMajorSwap == null) ? 0 : regEntityMajorSwap
						.hashCode());
		result = prime
				* result
				+ ((regEntitySecBasedMajorSwap == null) ? 0
						: regEntitySecBasedMajorSwap.hashCode());
		result = prime
				* result
				+ ((regEntitySecBasedSwapDealer == null) ? 0
						: regEntitySecBasedSwapDealer.hashCode());
		result = prime
				* result
				+ ((regEntitySwapDealer == null) ? 0 : regEntitySwapDealer
						.hashCode());
		result = prime
				* result
				+ ((relationshipType == null) ? 0 : relationshipType.hashCode());
		result = prime * result + ((systemC == null) ? 0 : systemC.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CIDStaticData other = (CIDStaticData) obj;
		if (busAExtlKeyC == null) {
			if (other.busAExtlKeyC != null)
				return false;
		} else if (!busAExtlKeyC.equals(other.busAExtlKeyC))
			return false;
		if (busAExtlN == null) {
			if (other.busAExtlN != null)
				return false;
		} else if (!busAExtlN.equals(other.busAExtlN))
			return false;
		if (busAIdC == null) {
			if (other.busAIdC != null)
				return false;
		} else if (!busAIdC.equals(other.busAIdC))
			return false;
		if (busAN == null) {
			if (other.busAN != null)
				return false;
		} else if (!busAN.equals(other.busAN))
			return false;
		if (deliveryPortfolioDataEmail == null) {
			if (other.deliveryPortfolioDataEmail != null)
				return false;
		} else if (!deliveryPortfolioDataEmail
				.equals(other.deliveryPortfolioDataEmail))
			return false;
		if (dfETEUEndUserType == null) {
			if (other.dfETEUEndUserType != null)
				return false;
		} else if (!dfETEUEndUserType.equals(other.dfETEUEndUserType))
			return false;
		if (etMSPCommodities == null) {
			if (other.etMSPCommodities != null)
				return false;
		} else if (!etMSPCommodities.equals(other.etMSPCommodities))
			return false;
		if (etMSPCreditderivatives == null) {
			if (other.etMSPCreditderivatives != null)
				return false;
		} else if (!etMSPCreditderivatives.equals(other.etMSPCreditderivatives))
			return false;
		if (etMSPEquityderivatives == null) {
			if (other.etMSPEquityderivatives != null)
				return false;
		} else if (!etMSPEquityderivatives.equals(other.etMSPEquityderivatives))
			return false;
		if (etMSPFX == null) {
			if (other.etMSPFX != null)
				return false;
		} else if (!etMSPFX.equals(other.etMSPFX))
			return false;
		if (etMSPRates == null) {
			if (other.etMSPRates != null)
				return false;
		} else if (!etMSPRates.equals(other.etMSPRates))
			return false;
		if (etSBMSPCommodities == null) {
			if (other.etSBMSPCommodities != null)
				return false;
		} else if (!etSBMSPCommodities.equals(other.etSBMSPCommodities))
			return false;
		if (etSBMSPCreditderivatives == null) {
			if (other.etSBMSPCreditderivatives != null)
				return false;
		} else if (!etSBMSPCreditderivatives
				.equals(other.etSBMSPCreditderivatives))
			return false;
		if (etSBMSPEquityderivatives == null) {
			if (other.etSBMSPEquityderivatives != null)
				return false;
		} else if (!etSBMSPEquityderivatives
				.equals(other.etSBMSPEquityderivatives))
			return false;
		if (etSBMSPFX == null) {
			if (other.etSBMSPFX != null)
				return false;
		} else if (!etSBMSPFX.equals(other.etSBMSPFX))
			return false;
		if (etSBMSPRates == null) {
			if (other.etSBMSPRates != null)
				return false;
		} else if (!etSBMSPRates.equals(other.etSBMSPRates))
			return false;
		if (etSBSDCommodities == null) {
			if (other.etSBSDCommodities != null)
				return false;
		} else if (!etSBSDCommodities.equals(other.etSBSDCommodities))
			return false;
		if (etSBSDCreditderivatives == null) {
			if (other.etSBSDCreditderivatives != null)
				return false;
		} else if (!etSBSDCreditderivatives
				.equals(other.etSBSDCreditderivatives))
			return false;
		if (etSBSDEquityderivatives == null) {
			if (other.etSBSDEquityderivatives != null)
				return false;
		} else if (!etSBSDEquityderivatives
				.equals(other.etSBSDEquityderivatives))
			return false;
		if (etSBSDFX == null) {
			if (other.etSBSDFX != null)
				return false;
		} else if (!etSBSDFX.equals(other.etSBSDFX))
			return false;
		if (etSBSDRates == null) {
			if (other.etSBSDRates != null)
				return false;
		} else if (!etSBSDRates.equals(other.etSBSDRates))
			return false;
		if (etSDCommodities == null) {
			if (other.etSDCommodities != null)
				return false;
		} else if (!etSDCommodities.equals(other.etSDCommodities))
			return false;
		if (etSDCreditderivatives == null) {
			if (other.etSDCreditderivatives != null)
				return false;
		} else if (!etSDCreditderivatives.equals(other.etSDCreditderivatives))
			return false;
		if (etSDEquityderivatives == null) {
			if (other.etSDEquityderivatives != null)
				return false;
		} else if (!etSDEquityderivatives.equals(other.etSDEquityderivatives))
			return false;
		if (etSDFX == null) {
			if (other.etSDFX != null)
				return false;
		} else if (!etSDFX.equals(other.etSDFX))
			return false;
		if (etSDRates == null) {
			if (other.etSDRates != null)
				return false;
		} else if (!etSDRates.equals(other.etSDRates))
			return false;
		if (isdaPortfolioRecon == null) {
			if (other.isdaPortfolioRecon != null)
				return false;
		} else if (!isdaPortfolioRecon.equals(other.isdaPortfolioRecon))
			return false;
		if (isdaRiskValuation == null) {
			if (other.isdaRiskValuation != null)
				return false;
		} else if (!isdaRiskValuation.equals(other.isdaRiskValuation))
			return false;
		if (lgleFullN == null) {
			if (other.lgleFullN != null)
				return false;
		} else if (!lgleFullN.equals(other.lgleFullN))
			return false;
		if (lgleIdC == null) {
			if (other.lgleIdC != null)
				return false;
		} else if (!lgleIdC.equals(other.lgleIdC))
			return false;
		if (lgleTypeC == null) {
			if (other.lgleTypeC != null)
				return false;
		} else if (!lgleTypeC.equals(other.lgleTypeC))
			return false;
		if (portfolioDataMethod == null) {
			if (other.portfolioDataMethod != null)
				return false;
		} else if (!portfolioDataMethod.equals(other.portfolioDataMethod))
			return false;
		if (qualifier == null) {
			if (other.qualifier != null)
				return false;
		} else if (!qualifier.equals(other.qualifier))
			return false;
		if (reconSDRData == null) {
			if (other.reconSDRData != null)
				return false;
		} else if (!reconSDRData.equals(other.reconSDRData))
			return false;
		if (regEntityEndUser == null) {
			if (other.regEntityEndUser != null)
				return false;
		} else if (!regEntityEndUser.equals(other.regEntityEndUser))
			return false;
		if (regEntityMajorSwap == null) {
			if (other.regEntityMajorSwap != null)
				return false;
		} else if (!regEntityMajorSwap.equals(other.regEntityMajorSwap))
			return false;
		if (regEntitySecBasedMajorSwap == null) {
			if (other.regEntitySecBasedMajorSwap != null)
				return false;
		} else if (!regEntitySecBasedMajorSwap
				.equals(other.regEntitySecBasedMajorSwap))
			return false;
		if (regEntitySecBasedSwapDealer == null) {
			if (other.regEntitySecBasedSwapDealer != null)
				return false;
		} else if (!regEntitySecBasedSwapDealer
				.equals(other.regEntitySecBasedSwapDealer))
			return false;
		if (regEntitySwapDealer == null) {
			if (other.regEntitySwapDealer != null)
				return false;
		} else if (!regEntitySwapDealer.equals(other.regEntitySwapDealer))
			return false;
		if (relationshipType == null) {
			if (other.relationshipType != null)
				return false;
		} else if (!relationshipType.equals(other.relationshipType))
			return false;
		if (systemC == null) {
			if (other.systemC != null)
				return false;
		} else if (!systemC.equals(other.systemC))
			return false;
		return true;
	}
	
	
}
