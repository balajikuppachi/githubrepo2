package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.SdrPortfolioReconDao;
import com.wf.df.sdr.dto.SdrPortfolioRecon;
import com.wf.df.sdr.exception.dao.SdrPortfolioReconDaoException;

public class SdrPortfolioReconDaoImpl extends AbstractDAO implements ParameterizedRowMapper<SdrPortfolioRecon>, SdrPortfolioReconDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(SdrPortfolioRecon dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( id, as_of_date, recon_started, recon_completed) VALUES ( ?, ?, ?, ?)",dto.getId(),dto.getAsOfDate(),dto.getReconStarted(),dto.getReconCompleted());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return BufferStore
	 */
	public SdrPortfolioRecon mapRow(ResultSet rs, int row) throws SQLException
	{
		SdrPortfolioRecon dto = new SdrPortfolioRecon();
		dto.setId(rs.getLong(1));
		dto.setAsOfDate(rs.getDate(2));
		dto.setReconStarted(rs.getDate(3));
		dto.setReconCompleted(rs.getDate(4));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "sdr_portfolio_recon";
	}

	/** 
	 * Returns all rows from the sdr_portfolio_recon table that match the criteria ''.
	 */
	@Transactional
	public List<SdrPortfolioRecon> findAll() throws SdrPortfolioReconDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, as_of_date, recon_started, recon_completed FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new SdrPortfolioReconDaoException("Query failed", e);
		}
		
	}

}
