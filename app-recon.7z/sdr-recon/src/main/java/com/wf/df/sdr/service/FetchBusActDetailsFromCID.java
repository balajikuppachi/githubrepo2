package com.wf.df.sdr.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.dao.BusinessAccountDetailsDao;
import com.wf.df.sdr.dao.spring.BusinessAccountDetailsExtnDaoImpl;
import com.wf.df.sdr.dao.spring.PortfolioViewExtnDaoImpl;
import com.wf.df.sdr.dto.BusinessAccountDetails;
import com.wf.df.sdr.exception.dao.BusinessAccountDetailsDaoException;


@Component
@ManagedResource(description="Get Business Account Details")
public class FetchBusActDetailsFromCID {

	@Autowired
	BusinessAccountDetailsExtnDaoImpl businessAccountDetailsExtnDao;
	
	@Autowired
	BusinessAccountDetailsDao businessAccountDetailsDao;
	
		
	

	@Autowired
	PortfolioViewExtnDaoImpl portFolio;
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@ManagedOperation(description="Get Business Account Details")
	public void display() throws BusinessAccountDetailsDaoException, IOException{
		// Read from file and populate the ba  id details
		
		List<Map<String, Object>> busAccID = portFolio.fetchBusAccID();
		
		for (Object row : busAccID){
			HashMap map = (HashMap)row;
			Set<String> keys = map.keySet();
			//Iterator<Integer> keySetIterator = map.entrySet().iterator();
			
			//for(String baid : keys){
				int id = Integer.parseInt((String)map.get("bus_acc"));
				List<BusinessAccountDetails> list = businessAccountDetailsExtnDao.findBusinessAccountDetails(id);
				String source = (String) map.get("src_system_name");
				Map<String,BusinessAccountDetails> systemMap=new Hashtable<String,BusinessAccountDetails>();
				if(!list.isEmpty()){
					for(BusinessAccountDetails eachRecord: list){
						logger.info("Inserting  Business account details for:" + id);
						if((source.equalsIgnoreCase("EquityPROD") && "IMAGIN".equalsIgnoreCase(eachRecord.getSystemC()))||
								(source.equalsIgnoreCase("Endur.gold") && "ENDUR".equalsIgnoreCase(eachRecord.getSystemC())) ||
									(source.equalsIgnoreCase("FX_INTL") && "WFOPIC".equalsIgnoreCase(eachRecord.getSystemC()))){
							businessAccountDetailsDao.insert(eachRecord);
						}else if((source.equalsIgnoreCase("CIRCprod") || source.equalsIgnoreCase("CALRATES") || source.equalsIgnoreCase("CALSCP")) && eachRecord.getSystemC().startsWith("C")){
							systemMap.put(eachRecord.getSystemC(), eachRecord);
						}
						else {
							logger.info("Business Account CID details missing for: " + id);
						}
				}
				
					if(!systemMap.isEmpty()){
						if(systemMap.containsKey("CLYP12")){
							businessAccountDetailsDao.insert(systemMap.get("CLYP12"));
						}else if(systemMap.containsKey("CLYPS3")){
							businessAccountDetailsDao.insert(systemMap.get("CLYPS3"));
						}else if(systemMap.containsKey("CLYPS2")){
							businessAccountDetailsDao.insert(systemMap.get("CLYPS2"));
						}else{
							businessAccountDetailsDao.insert(systemMap.get("CLYPSO"));
						}
					}
			}
			
		//	}
		}	
	}
}
