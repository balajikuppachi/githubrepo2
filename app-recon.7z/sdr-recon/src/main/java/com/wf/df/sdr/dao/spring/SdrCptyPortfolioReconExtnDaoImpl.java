package com.wf.df.sdr.dao.spring;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class SdrCptyPortfolioReconExtnDaoImpl
{
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	String leiQuery = "SELECT distinct legal_id FROM sdr_cpty_portfolio_recon where frequency = ? and recon_date = ? and portfolio_recon_id = ?";

	@Transactional
	public List<Long> fetchDistinctLegalId(String frequency, Date reconDate, Long portReconId) {
		List<Long> rsList = jdbcTemplate.queryForList(leiQuery, Long.class, frequency, reconDate, portReconId);
		return rsList;

	}
}

