package com.wf.df.sdr.dto;

import java.io.Serializable;

/*@Table : temp_open_trade_details */
public class OpenTradeDetails implements Serializable
{
	private Integer busAIdC ;
	private Integer sendId ;
	private String srcTradeId ;
	private String party1Lei ;
	private String party2Lei;
	public Integer getBusAIdC() {
		return busAIdC;
	}
	public void setBusAIdC(Integer busAIdC) {
		this.busAIdC = busAIdC;
	}
	public Integer getSendId() {
		return sendId;
	}
	public void setSendId(Integer sendId) {
		this.sendId = sendId;
	}
	public String getSrcTradeId() {
		return srcTradeId;
	}
	public void setSrcTradeId(String srcTradeId) {
		this.srcTradeId = srcTradeId;
	}
	public String getParty1Lei() {
		return party1Lei;
	}
	public void setParty1Lei(String party1Lei) {
		this.party1Lei = party1Lei;
	}
	public String getParty2Lei() {
		return party2Lei;
	}
	public void setParty2Lei(String party2Lei) {
		this.party2Lei = party2Lei;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((busAIdC == null) ? 0 : busAIdC.hashCode());
		result = prime * result
				+ ((party1Lei == null) ? 0 : party1Lei.hashCode());
		result = prime * result
				+ ((party2Lei == null) ? 0 : party2Lei.hashCode());
		result = prime * result + ((sendId == null) ? 0 : sendId.hashCode());
		result = prime * result
				+ ((srcTradeId == null) ? 0 : srcTradeId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OpenTradeDetails other = (OpenTradeDetails) obj;
		if (busAIdC == null) {
			if (other.busAIdC != null)
				return false;
		} else if (!busAIdC.equals(other.busAIdC))
			return false;
		if (party1Lei == null) {
			if (other.party1Lei != null)
				return false;
		} else if (!party1Lei.equals(other.party1Lei))
			return false;
		if (party2Lei == null) {
			if (other.party2Lei != null)
				return false;
		} else if (!party2Lei.equals(other.party2Lei))
			return false;
		if (sendId == null) {
			if (other.sendId != null)
				return false;
		} else if (!sendId.equals(other.sendId))
			return false;
		if (srcTradeId == null) {
			if (other.srcTradeId != null)
				return false;
		} else if (!srcTradeId.equals(other.srcTradeId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OpenTradeDetails [busAIdC=" + busAIdC + ", sendId=" + sendId
				+ ", srcTradeId=" + srcTradeId + ", party1Lei=" + party1Lei
				+ ", party2Lei=" + party2Lei + "]";
	}
	
}
