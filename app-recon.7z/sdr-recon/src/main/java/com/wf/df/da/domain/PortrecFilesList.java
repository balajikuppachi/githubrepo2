package com.wf.df.da.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "PORT_REC_FILES_LIST")
public class PortrecFilesList {
	
	@EmbeddedId
	private PortrecFilesListPk portrecFilesListPk;
	
	/*@Column(name = "BO_Cntr_Pty_ID")
	String cptyId = "";*/
	
	/*@Column(name = "Template_Type")
	String templateType;*/
	
	//@Id
	@Column(name = "File_Name")
	String fileName = "";

	@Column(name = "Dir_Path")
	String dirPath = "";
	
	@Column(name = "Period")
	String period;
	
	/*@Column(name = "Recon_Date")
	String reconDate = "";*/

	@Column(name = "File_Tag")
	String fileTag = "";
	
	@Column(name = "Reviewed")
	String reviewed = "";

	/*public String getCptyId() {
		return cptyId;
	}

	public void setCptyId(String cptyId) {
		this.cptyId = cptyId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}*/

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDirPath() {
		return dirPath;
	}

	public void setDirPath(String dirPath) {
		this.dirPath = dirPath;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	/*public String getReconDate() {
		return reconDate;
	}

	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}*/

	public String getFileTag() {
		return fileTag;
	}

	public void setFileTag(String fileTag) {
		this.fileTag = fileTag;
	}

	public String getReviewed() {
		return reviewed;
	}

	public void setReviewed(String reviewed) {
		this.reviewed = reviewed;
	}

	public PortrecFilesListPk getPortrecFilesListPk() {
		return portrecFilesListPk;
	}

	public void setPortrecFilesListPk(PortrecFilesListPk portrecFilesListPk) {
		this.portrecFilesListPk = portrecFilesListPk;
	}

	
	

}