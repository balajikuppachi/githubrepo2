package com.wf.df.da.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


@Embeddable
public class PortrecFilesListPk  implements Serializable{
	
	@Column(name = "BO_Cntr_Pty_ID", nullable = false)
	String cptyId = "";
	
	@Column(name = "Template_Type", nullable = false)
	String templateType;
	
	@Column(name = "Recon_Date", nullable = false)
	String reconDate = "";

	public String getCptyId() {
		return cptyId;
	}

	public void setCptyId(String cptyId) {
		this.cptyId = cptyId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public String getReconDate() {
		return reconDate;
	}

	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}


}