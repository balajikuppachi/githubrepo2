package com.wf.df.sdr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class SdrPortfolioReconExtnDao 
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Long findMaxBufferIdInRange(Long from, Long to) {
		List<Long> maxIdList = jdbcTemplate.queryForList("SELECT MAX(id) FROM sdr_portfolio_recon WHERE id >= ? AND id <= ?", Long.class, from, to);
		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null) {
			return null;
		} else {
			return maxIdList.get(0);
		}
	}
}
