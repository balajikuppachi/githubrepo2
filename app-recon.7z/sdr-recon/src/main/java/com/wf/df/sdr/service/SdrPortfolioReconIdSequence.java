package com.wf.df.sdr.service;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.dao.SdrPortfolioReconExtnDao;

@Component
public class SdrPortfolioReconIdSequence implements ApplicationCacheRefresh{
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private AtomicLong nextId = new AtomicLong();
	
	@Autowired
	private SdrPortfolioReconExtnDao sdrPortfolioReconExtnDao;
	
	@Value("${PortReconIdMin}") Long pReconIdMin;
	@Value("${PortReconIdMax}") Long pReconIdMax;
	
	@PostConstruct
	public void initialize(){
		if (pReconIdMin == null) {
			pReconIdMin = 0l;
		}
		if (pReconIdMax == null) {
			pReconIdMax = Long.MAX_VALUE;
		}
		
		Long maxId = sdrPortfolioReconExtnDao.findMaxBufferIdInRange(pReconIdMin, pReconIdMax);
		
		if (maxId == null) {
			nextId.set(pReconIdMin);
		} else {
			nextId.set(maxId + 1);
		}
		
		logger.info("BufferId start with " + nextId.get() + " and max " + pReconIdMax);
	}

	//TODO: AZ - This implementation is not cluster friendly as it assumes that only one instance of the application can work with the DB
	public BigDecimal getNextId() {
		long id = nextId.getAndIncrement();
		if (id > pReconIdMax) {
			throw new IllegalStateException("PortReconId max reached, configured range is " + pReconIdMin + "-" + pReconIdMax + ". Use pReconIdMin and pReconIdMax application properties to set a different range");
		}
		return BigDecimal.valueOf(id);
	}

}
