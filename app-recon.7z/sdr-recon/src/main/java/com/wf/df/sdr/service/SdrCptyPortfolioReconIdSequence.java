package com.wf.df.sdr.service;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.dao.SdrCptyPortfolioReconExtnDao;

@Component
public class SdrCptyPortfolioReconIdSequence implements ApplicationCacheRefresh{
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private AtomicLong nextId = new AtomicLong();
	
	@Autowired
	private SdrCptyPortfolioReconExtnDao sdrCptyPortfolioReconExtnDao;
	
	@Value("${PortCptyReconIdMin}") Long pCptyReconIdMin;
	@Value("${PortCptyReconIdMax}") Long pCptyReconIdMax;
	
	@PostConstruct
	public void initialize(){
		if (pCptyReconIdMin == null) {
			pCptyReconIdMin = 0l;
		}
		if (pCptyReconIdMax == null) {
			pCptyReconIdMax = Long.MAX_VALUE;
		}
		
		Long maxId = sdrCptyPortfolioReconExtnDao.findMaxBufferIdInRange(pCptyReconIdMin, pCptyReconIdMax);
		
		if (maxId == null) {
			nextId.set(pCptyReconIdMin);
		} else {
			nextId.set(maxId + 1);
		}
		
		logger.info("pCptyReconId start with " + nextId.get() + " and max " + pCptyReconIdMax);
	}

	//TODO: AZ - This implementation is not cluster friendly as it assumes that only one instance of the application can work with the DB
	public BigDecimal getNextId() {
		long id = nextId.getAndIncrement();
		if (id > pCptyReconIdMax) {
			throw new IllegalStateException("pCptyReconId max reached, configured range is " + pCptyReconIdMin + "-" + pCptyReconIdMax + ". Use pReconIdMin and pReconIdMax application properties to set a different range");
		}
		return BigDecimal.valueOf(id);
	}

}
