package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.SdrCptyPortfolioReconDao;
import com.wf.df.sdr.dto.SdrCptyPortfolioRecon;
import com.wf.df.sdr.exception.dao.SdrCptyPortfolioReconDaoException;

public class SdrCptyPortfolioReconDaoImpl extends AbstractDAO implements ParameterizedRowMapper<SdrCptyPortfolioRecon>, SdrCptyPortfolioReconDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;
	
	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(SdrCptyPortfolioRecon dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( id,recon_date,legal_id,bus_acnt_id,portfolio_size,frequency,portfolio_recon_id) VALUES ( ?, ?, ?, ?, ?, ?, ?)", dto.getId(),dto.getReconDate(),dto.getLegalId(),dto.getBaId(),dto.getPortfolioSize(),dto.getFrequency(),dto.getPortReconId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return SdrCptyPortfolioRecon
	 */
	public SdrCptyPortfolioRecon mapRow(ResultSet rs, int row) throws SQLException
	{
		SdrCptyPortfolioRecon dto = new SdrCptyPortfolioRecon();
		dto.setId(rs.getLong(1));
		dto.setReconDate(rs.getDate(2));
		dto.setLegalId(rs.getLong(3));
		dto.setBaId(rs.getLong(4));
		dto.setPortfolioSize(rs.getLong(5));
		dto.setFrequency(rs.getString(6));
		dto.setPortReconId(rs.getLong(7));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "sdr_cpty_portfolio_recon";
	}

	/** 
	 * Returns all rows from the sdr_cpty_portfolio_recon table that match the criteria ''.
	 */
	@Transactional
	public List<SdrCptyPortfolioRecon> findAll() throws SdrCptyPortfolioReconDaoException
	{
		try {
			return jdbcTemplate.query("SELECT  id,recon_date,legal_id,bus_acnt_id,portfolio_size,frequency,portfolio_recon_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new SdrCptyPortfolioReconDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the sdr_cpty_portfolio_recon table that match the criteria frequency and recon_date.
	 */
	@Transactional
	public List<SdrCptyPortfolioRecon> findFreqRcDt(String frequency, Date reconDate) throws SdrCptyPortfolioReconDaoException {
		return jdbcTemplate.query("SELECT  id,recon_date,legal_id,bus_acnt_id,portfolio_size,frequency,portfolio_recon_id FROM " + getTableName() + " where frequency = ? and recon_date = ? ", this, frequency, reconDate);
	}
	
}
