package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.OpenTradeDetails;
import com.wf.df.sdr.exception.dao.OpenTradeDetailsDaoException;

public interface OpenTradeDetailsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(OpenTradeDetails dto);

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria ''.
	 */
	public List<OpenTradeDetails> findAll() throws OpenTradeDetailsDaoException;

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria 'bus_acc_id = :busAIdC'.
	 */
	public List<OpenTradeDetails> findWhereBusAIdCEquals(Integer busAIdC) throws OpenTradeDetailsDaoException;

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria 'send_id = :sendId'.
	 */
	public List<OpenTradeDetails> findWhereSendIdEquals(Integer sendId) throws OpenTradeDetailsDaoException;

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria 'src_trade_id = :srcTradeId'.
	 */
	public List<OpenTradeDetails> findWhereSrcTradeIdEquals(String srcTradeId) throws OpenTradeDetailsDaoException;

}
