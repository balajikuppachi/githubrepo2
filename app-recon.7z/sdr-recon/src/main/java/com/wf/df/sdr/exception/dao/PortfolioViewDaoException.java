package com.wf.df.sdr.exception.dao;

public class PortfolioViewDaoException extends DaoException
{
	/**
	 * Method 'PortfolioViewDaoException'
	 * 
	 * @param message
	 */
	public PortfolioViewDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PortfolioViewDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PortfolioViewDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
