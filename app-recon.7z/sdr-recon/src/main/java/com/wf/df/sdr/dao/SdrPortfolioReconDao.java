package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.SdrPortfolioRecon;
import com.wf.df.sdr.exception.dao.SdrPortfolioReconDaoException;

public interface SdrPortfolioReconDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(SdrPortfolioRecon dto);

	/** 
	 * Returns all rows from the sdr_portfolio_recon table that match the criteria ''.
	 */
	public List<SdrPortfolioRecon> findAll() throws SdrPortfolioReconDaoException;

}
