package com.wf.df.da.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PortRecAuditLogViewPk implements Serializable{

	@Column(name = "Legal_Id")
	String legalId = "";

	@Column(name = "Asset_Class")
	String assetClass = "";
	
	@Column(name = "Recon_Date")
	String reconDate = "";
	
	public String getLegalId() {
		return legalId;
	}

	public void setLegalId(String legalId) {
		this.legalId = legalId;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	

	public String getReconDate() {
		return reconDate;
	}

	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}

}