package com.wf.df.sdr.dto;

import java.io.Serializable;
import java.util.Date;

/*@Table : portfolio_view */
public class PortfolioView implements Serializable
{
	private Date asOfDate;
	private Long legalId ;
	private Long busAIdC ;
	private Long portfolioSize ;
	private String regEntitySwapDealer;
	private String regEntitySecBasedSwapDealer ;
	private String regEntityMajorSwap;
	private String regEntitySecBasedMajorSwap;
	private String isdaPortfolioRecon ;
	private String portfolioDataMethod;
	private String deliveryPortfolioDataEmail;
	private String reconSDRData;
	private String qualifer;
	public Date getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}
	public Long getLegalId() {
		return legalId;
	}
	public void setLegalId(Long legalId) {
		this.legalId = legalId;
	}
	public Long getBusAIdC() {
		return busAIdC;
	}
	public void setBusAIdC(Long busAIdC) {
		this.busAIdC = busAIdC;
	}
	public Long getPortfolioSize() {
		return portfolioSize;
	}
	public void setPortfolioSize(Long portfolioSize) {
		this.portfolioSize = portfolioSize;
	}
	public String getRegEntitySwapDealer() {
		return regEntitySwapDealer;
	}
	public void setRegEntitySwapDealer(String regEntitySwapDealer) {
		this.regEntitySwapDealer = regEntitySwapDealer;
	}
	public String getRegEntitySecBasedSwapDealer() {
		return regEntitySecBasedSwapDealer;
	}
	public void setRegEntitySecBasedSwapDealer(String regEntitySecBasedSwapDealer) {
		this.regEntitySecBasedSwapDealer = regEntitySecBasedSwapDealer;
	}
	public String getRegEntityMajorSwap() {
		return regEntityMajorSwap;
	}
	public void setRegEntityMajorSwap(String regEntityMajorSwap) {
		this.regEntityMajorSwap = regEntityMajorSwap;
	}
	public String getRegEntitySecBasedMajorSwap() {
		return regEntitySecBasedMajorSwap;
	}
	public void setRegEntitySecBasedMajorSwap(String regEntitySecBasedMajorSwap) {
		this.regEntitySecBasedMajorSwap = regEntitySecBasedMajorSwap;
	}
	public String getIsdaPortfolioRecon() {
		return isdaPortfolioRecon;
	}
	public void setIsdaPortfolioRecon(String isdaPortfolioRecon) {
		this.isdaPortfolioRecon = isdaPortfolioRecon;
	}
	public String getPortfolioDataMethod() {
		return portfolioDataMethod;
	}
	public void setPortfolioDataMethod(String portfolioDataMethod) {
		this.portfolioDataMethod = portfolioDataMethod;
	}
	public String getDeliveryPortfolioDataEmail() {
		return deliveryPortfolioDataEmail;
	}
	
	public void setDeliveryPortfolioDataEmail(String deliveryPortfolioDataEmail) {
		this.deliveryPortfolioDataEmail = deliveryPortfolioDataEmail;
	}
	public String getReconSDRData() {
		return reconSDRData;
	}
	public void setReconSDRData(String reconSDRData) {
		this.reconSDRData = reconSDRData;
	}
	public String getQualifer() {
		return qualifer;
	}
	public void setQualifer(String qualifer) {
		this.qualifer = qualifer;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((asOfDate == null) ? 0 : asOfDate.hashCode());
		result = prime * result + ((busAIdC == null) ? 0 : busAIdC.hashCode());
		result = prime
				* result
				+ ((deliveryPortfolioDataEmail == null) ? 0
						: deliveryPortfolioDataEmail.hashCode());
		result = prime
				* result
				+ ((isdaPortfolioRecon == null) ? 0 : isdaPortfolioRecon
						.hashCode());
		result = prime * result + ((legalId == null) ? 0 : legalId.hashCode());
		result = prime
				* result
				+ ((portfolioDataMethod == null) ? 0 : portfolioDataMethod
						.hashCode());
		result = prime * result
				+ ((portfolioSize == null) ? 0 : portfolioSize.hashCode());
		result = prime * result
				+ ((qualifer == null) ? 0 : qualifer.hashCode());
		result = prime * result
				+ ((reconSDRData == null) ? 0 : reconSDRData.hashCode());
		result = prime
				* result
				+ ((regEntityMajorSwap == null) ? 0 : regEntityMajorSwap
						.hashCode());
		result = prime
				* result
				+ ((regEntitySecBasedMajorSwap == null) ? 0
						: regEntitySecBasedMajorSwap.hashCode());
		result = prime
				* result
				+ ((regEntitySecBasedSwapDealer == null) ? 0
						: regEntitySecBasedSwapDealer.hashCode());
		result = prime
				* result
				+ ((regEntitySwapDealer == null) ? 0 : regEntitySwapDealer
						.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortfolioView other = (PortfolioView) obj;
		if (asOfDate == null) {
			if (other.asOfDate != null)
				return false;
		} else if (!asOfDate.equals(other.asOfDate))
			return false;
		if (busAIdC == null) {
			if (other.busAIdC != null)
				return false;
		} else if (!busAIdC.equals(other.busAIdC))
			return false;
		if (deliveryPortfolioDataEmail == null) {
			if (other.deliveryPortfolioDataEmail != null)
				return false;
		} else if (!deliveryPortfolioDataEmail
				.equals(other.deliveryPortfolioDataEmail))
			return false;
		if (isdaPortfolioRecon == null) {
			if (other.isdaPortfolioRecon != null)
				return false;
		} else if (!isdaPortfolioRecon.equals(other.isdaPortfolioRecon))
			return false;
		if (legalId == null) {
			if (other.legalId != null)
				return false;
		} else if (!legalId.equals(other.legalId))
			return false;
		if (portfolioDataMethod == null) {
			if (other.portfolioDataMethod != null)
				return false;
		} else if (!portfolioDataMethod.equals(other.portfolioDataMethod))
			return false;
		if (portfolioSize == null) {
			if (other.portfolioSize != null)
				return false;
		} else if (!portfolioSize.equals(other.portfolioSize))
			return false;
		if (qualifer == null) {
			if (other.qualifer != null)
				return false;
		} else if (!qualifer.equals(other.qualifer))
			return false;
		if (reconSDRData == null) {
			if (other.reconSDRData != null)
				return false;
		} else if (!reconSDRData.equals(other.reconSDRData))
			return false;
		if (regEntityMajorSwap == null) {
			if (other.regEntityMajorSwap != null)
				return false;
		} else if (!regEntityMajorSwap.equals(other.regEntityMajorSwap))
			return false;
		if (regEntitySecBasedMajorSwap == null) {
			if (other.regEntitySecBasedMajorSwap != null)
				return false;
		} else if (!regEntitySecBasedMajorSwap
				.equals(other.regEntitySecBasedMajorSwap))
			return false;
		if (regEntitySecBasedSwapDealer == null) {
			if (other.regEntitySecBasedSwapDealer != null)
				return false;
		} else if (!regEntitySecBasedSwapDealer
				.equals(other.regEntitySecBasedSwapDealer))
			return false;
		if (regEntitySwapDealer == null) {
			if (other.regEntitySwapDealer != null)
				return false;
		} else if (!regEntitySwapDealer.equals(other.regEntitySwapDealer))
			return false;
		return true;
	}
	
}
