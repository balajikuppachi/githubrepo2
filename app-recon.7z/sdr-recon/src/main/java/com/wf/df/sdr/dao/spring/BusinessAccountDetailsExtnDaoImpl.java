package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.BusinessAccountDetails;
import com.wf.df.sdr.exception.dao.BusinessAccountDetailsDaoException;

public class BusinessAccountDetailsExtnDaoImpl {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	protected SimpleJdbcTemplate jdbcTemplate;
	protected DataSource dataSource;
	
	protected BusinessAccountDetailsSP businessAccountDetailsSP;
	
	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
		businessAccountDetailsSP = new BusinessAccountDetailsSP(dataSource);
	}
	
	private class BusinessAccountDetailsSP extends StoredProcedure {
		private String BUSINESS_ACCOUNT_ID = "busAcctId";
		private String BA_ID_DETAILS = "Business_Account_Details";
		String spName = "PORTRECON_SearchByBusAcctId";
		
		protected BusinessAccountDetailsSP(DataSource dataSource) {
			JdbcTemplate spJdbcTemplate = new JdbcTemplate(dataSource);
			spJdbcTemplate.setSkipUndeclaredResults(true);
			setJdbcTemplate(spJdbcTemplate);
			setSql(spName);
			declareParameter(new SqlParameter(BUSINESS_ACCOUNT_ID, Types.INTEGER));
			declareParameter(new SqlReturnResultSet(BA_ID_DETAILS,new ResultSetExtractor<List<BusinessAccountDetails>>() {

				@Override
				public List<BusinessAccountDetails> extractData(ResultSet rs)
						throws SQLException, DataAccessException {
					List<BusinessAccountDetails> bADetails = new ArrayList<BusinessAccountDetails>();
					while(rs.next()){
						BusinessAccountDetails bd = new BusinessAccountDetails();
						bd.setBusAIdC(rs.getInt(1));
						bd.setBusAN(rs.getString(2));
						bd.setSystemC(null!=rs.getString(3)?rs.getString(3).trim():null);
						bd.setBusAExtlKeyC(rs.getString(4));
						bd.setBusAExtlN(rs.getString(5));
						bd.setRelationshipType(rs.getString(6));
						bd.setLgleIdC(rs.getInt(7));
						bd.setLgleTypeC(rs.getString(8));
						bd.setLgleFullN(rs.getString(9));
						bd.setRegEntitySwapDealer(rs.getString(10));
						bd.setEtSDRates(rs.getString(11));
						bd.setEtSDEquityderivatives(rs.getString(12));
						bd.setEtSDCommodities(rs.getString(13));
						bd.setEtSDCreditderivatives(rs.getString(14));
						bd.setEtSDFX(rs.getString(15));
						bd.setRegEntitySecBasedSwapDealer(rs.getString(16));
						bd.setEtSBSDRates(rs.getString(17));
						bd.setEtSBSDEquityderivatives(rs.getString(18));
						bd.setEtSBSDCommodities(rs.getString(19));
						bd.setEtSBSDCreditderivatives(rs.getString(20));
						bd.setEtSBSDFX(rs.getString(21));
						bd.setRegEntityMajorSwap(rs.getString(22));
						bd.setEtMSPRates(rs.getString(23));
						bd.setEtMSPEquityderivatives(rs.getString(24));
						bd.setEtMSPCommodities(rs.getString(25));
						bd.setEtMSPCreditderivatives(rs.getString(26));
						bd.setEtMSPFX(rs.getString(27));
						bd.setRegEntitySecBasedMajorSwap(rs.getString(28));
						bd.setEtSBMSPRates(rs.getString(29));
						bd.setEtSBMSPEquityderivatives(rs.getString(30));
						bd.setEtSBMSPCommodities(rs.getString(31));
						bd.setEtSBMSPCreditderivatives(rs.getString(32));
						bd.setEtSBMSPFX(rs.getString(33));
						bd.setRegEntityEndUser(rs.getString(34));
						bd.setDfETEUEndUserType(rs.getString(35));
						bd.setIsdaRiskValuation(rs.getString(36));
						bd.setIsdaPortfolioRecon(rs.getString(37));
						bd.setPortfolioDataMethod(rs.getString(38));
						bd.setDeliveryPortfolioDataEmail(rs.getString(39));
						bd.setReconSDRData(rs.getString(40));
						bd.setQualifier("Y");
						bd.setlei(rs.getString(41));
						bADetails.add(bd);
					}
					return bADetails;
				}
			}));
			compile();
		}
		
		private List<BusinessAccountDetails> executeSP(Integer businessAccountId) {
			 
			 Map<String,Integer> inputParams = new HashMap<String, Integer>();
			 inputParams.put(BUSINESS_ACCOUNT_ID, businessAccountId);
	            
	         Map<String, Object> results = execute(inputParams);	            
	         List<BusinessAccountDetails> result = (List<BusinessAccountDetails>) results.get(BA_ID_DETAILS);
	         return result;    
	     }
	}
	
	@Transactional
	public List<BusinessAccountDetails> findBusinessAccountDetails(Integer businessAccountId) throws BusinessAccountDetailsDaoException{
		try {	
			List<BusinessAccountDetails> result = businessAccountDetailsSP.executeSP(businessAccountId);
	        return result; 			
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new BusinessAccountDetailsDaoException("Query failed", e);
		}
	}
	
}
