package com.wf.df.sdr.dao;

import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.PortfolioView;
import com.wf.df.sdr.exception.dao.PortfolioViewDaoException;

public interface PortfolioViewDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(PortfolioView dto);

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria qualifier ='Y'.
	 */
	public List<PortfolioView> findAll() throws PortfolioViewDaoException;

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria 'bus_acc_id = :busAIdC'.
	 */
	public List<PortfolioView> findWhereBusAIdCEquals(Long busAIdC) throws PortfolioViewDaoException;

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria 'legal_id = :legalId'.
	 */
	public List<PortfolioView> findWhereLegalIdEquals(Long legalId) throws PortfolioViewDaoException;

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria 'recon_date = :reconDate'.
	 */
	public List<PortfolioView> findWhereReconDateEquals(Date reconDate) throws PortfolioViewDaoException;

}
