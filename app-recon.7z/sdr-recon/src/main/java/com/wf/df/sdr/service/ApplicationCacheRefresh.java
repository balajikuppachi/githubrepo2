package com.wf.df.sdr.service;


public interface ApplicationCacheRefresh {
	public void initialize() throws Exception;
}
