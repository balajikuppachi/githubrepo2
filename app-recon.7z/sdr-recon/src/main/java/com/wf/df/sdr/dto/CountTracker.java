package com.wf.df.sdr.dto;

public class CountTracker {

	private String tradeId;
	private String usi;
	public String getTradeId() {
		return tradeId;
	}
	
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getUsi() {
		return usi;
	}
	public void setUsi(String usi) {
		this.usi = usi;
	}

	@Override
	public String toString() {
		return "CountTracker [tradeId=" + tradeId + ", usi=" + usi + "]";
	}
	
}
