package com.wf.df.da.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.da.domain.PortrecFilesList;
import com.wf.df.da.domain.PortrecFilesListPk;
import com.wf.df.da.repository.PortrecFilesListRepository;

@Component
public class PortrecFilesListHelper {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	PortrecFilesListRepository portrecFilesListRepository;
	

	public List<PortrecFilesList> readPortrecFilesList() {	
		Iterable<PortrecFilesList> listOfGeneratedFiles = portrecFilesListRepository.findAll();
		List<PortrecFilesList> generatedFiles = new ArrayList<PortrecFilesList>();
		
		if(null != listOfGeneratedFiles){
			generatedFiles = (List<PortrecFilesList>) listOfGeneratedFiles;
		}
		
		return generatedFiles;
	}
	
	public void createPortrecListEntry(String legalId, String assetClass, String fileName, String path, String period, String reconDate, String fileTag, String reviewed) {		
			
		PortrecFilesList portrecFile = new PortrecFilesList();
		/*portrecFile.setCptyId(legalId);
		portrecFile.setTemplateType(assetClass);*/
		portrecFile.setFileName(fileName);
		portrecFile.setDirPath(path);
		portrecFile.setPeriod(period);
		/*portrecFile.setReconDate(reconDate);*/
		portrecFile.setFileTag(fileTag);
		portrecFile.setReviewed(reviewed);
		
		PortrecFilesListPk portrecFilesListPk = new PortrecFilesListPk();
		portrecFilesListPk.setCptyId(legalId);
		portrecFilesListPk.setReconDate(reconDate);
		portrecFilesListPk.setTemplateType(assetClass);
		
		portrecFile.setPortrecFilesListPk(portrecFilesListPk);
		
		portrecFilesListRepository.save(portrecFile);
	}
	
}
