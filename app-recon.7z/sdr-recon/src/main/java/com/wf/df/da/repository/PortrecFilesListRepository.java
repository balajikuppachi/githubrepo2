package com.wf.df.da.repository;

import org.springframework.data.repository.CrudRepository;

import com.wf.df.da.domain.PortrecFilesList;
import com.wf.df.da.domain.PortrecFilesListPk;

public interface PortrecFilesListRepository extends CrudRepository<PortrecFilesList, PortrecFilesListPk> {

	
}
