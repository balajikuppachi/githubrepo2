package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.PortfolioViewDao;
import com.wf.df.sdr.dto.PortfolioView;
import com.wf.df.sdr.exception.dao.PortfolioViewDaoException;

public class PortfolioViewDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PortfolioView>, PortfolioViewDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(PortfolioView dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( as_of_date, lgle_id_c, bus_acc_id, portfolio_size, regEntitySwapDealer, regEntitySecBasedSwapDealer, regEntityMajorSwap, regEntitySecBasedMajorSwap, isdaPortfolioRecon, portfolioDataMethod, deliveryPortfolioDataEmail, reconSDRData, qualifer ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",dto.getAsOfDate(),dto.getLegalId(),dto.getBusAIdC(),dto.getPortfolioSize(),dto.getRegEntitySwapDealer(),dto.getRegEntitySecBasedSwapDealer(),dto.getRegEntityMajorSwap(),dto.getRegEntitySecBasedMajorSwap(),dto.getIsdaPortfolioRecon(),dto.getPortfolioDataMethod(),dto.getDeliveryPortfolioDataEmail(),dto.getReconSDRData(),dto.getQualifer());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return BufferStore
	 */
	public PortfolioView mapRow(ResultSet rs, int row) throws SQLException
	{
		PortfolioView dto = new PortfolioView();
		dto.setAsOfDate(rs.getDate(1));
		dto.setLegalId(rs.getLong(2));
		dto.setBusAIdC(rs.getLong(3));
		dto.setPortfolioSize(rs.getLong(4));
		dto.setRegEntitySwapDealer(rs.getString(5));
		dto.setRegEntitySecBasedSwapDealer(rs.getString(6));
		dto.setRegEntityMajorSwap(rs.getString(7));
		dto.setRegEntitySecBasedMajorSwap(rs.getString(8));
		dto.setIsdaPortfolioRecon(rs.getString(9));
		dto.setPortfolioDataMethod(rs.getString(10));
		dto.setDeliveryPortfolioDataEmail(rs.getString(11));
		dto.setReconSDRData(rs.getString(12));
		dto.setQualifer(rs.getString(13));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "portfolio_view";
	}

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria ''.
	 */
	@Transactional
	public List<PortfolioView> findAll() throws PortfolioViewDaoException
	{
		try {
			return jdbcTemplate.query("SELECT as_of_date, lgle_id_c, bus_acc_id, portfolio_size, regEntitySwapDealer, regEntitySecBasedSwapDealer, regEntityMajorSwap, regEntitySecBasedMajorSwap, isdaPortfolioRecon, portfolioDataMethod, deliveryPortfolioDataEmail, reconSDRData, qualifer FROM " + getTableName() + " WHERE qualifer = 'Y'", this);
		}
		catch (Exception e) {
			throw new PortfolioViewDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria 'bus_acc_id = :busAIdC'.
	 */
	@Transactional
	public List<PortfolioView> findWhereBusAIdCEquals(Long busAIdC) throws PortfolioViewDaoException
	{
		try {
			return jdbcTemplate.query("SELECT as_of_date, lgle_id_c, bus_acc_id, portfolio_size, regEntitySwapDealer, regEntitySecBasedSwapDealer, regEntityMajorSwap, regEntitySecBasedMajorSwap, isdaPortfolioRecon, portfolioDataMethod, deliveryPortfolioDataEmail, reconSDRData, qualifer FROM " + getTableName() + " WHERE bus_acc_id = ? ORDER BY bus_acc_id", this,busAIdC);
		}
		catch (Exception e) {
			throw new PortfolioViewDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<PortfolioView> findWhereLegalIdEquals(Long legalId) throws PortfolioViewDaoException
	{
		try {
			return jdbcTemplate.query("SELECT as_of_date, lgle_id_c, bus_acc_id, portfolio_size, regEntitySwapDealer, regEntitySecBasedSwapDealer, regEntityMajorSwap, regEntitySecBasedMajorSwap, isdaPortfolioRecon, portfolioDataMethod, deliveryPortfolioDataEmail, reconSDRData, qualifer FROM " + getTableName() + " WHERE lgle_id_c = ? ORDER BY lgle_id_c", this,legalId);
		}
		catch (Exception e) {
			throw new PortfolioViewDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the portfolio_view table that match the criteria 'recon_date = :reconDate'.
	 */
	@Transactional
	public List<PortfolioView> findWhereReconDateEquals(Date reconDate) throws PortfolioViewDaoException
	{
		try {
			return jdbcTemplate.query("SELECT as_of_date, lgle_id_c, bus_acc_id, portfolio_size, regEntitySwapDealer, regEntitySecBasedSwapDealer, regEntityMajorSwap, regEntitySecBasedMajorSwap, isdaPortfolioRecon, portfolioDataMethod, deliveryPortfolioDataEmail, reconSDRData, qualifer FROM " + getTableName() + " WHERE as_of_date = ? ORDER BY as_of_date", this,reconDate);
		}
		catch (Exception e) {
			throw new PortfolioViewDaoException("Query failed", e);
		}
		
	}
	

}
