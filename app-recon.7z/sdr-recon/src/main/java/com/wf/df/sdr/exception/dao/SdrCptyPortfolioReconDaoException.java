package com.wf.df.sdr.exception.dao;

public class SdrCptyPortfolioReconDaoException extends DaoException
{
	/**
	 * Method 'SdrCptyPortfolioReconDaoException'
	 * 
	 * @param message
	 */
	public SdrCptyPortfolioReconDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'SdrCptyPortfolioReconDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public SdrCptyPortfolioReconDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
