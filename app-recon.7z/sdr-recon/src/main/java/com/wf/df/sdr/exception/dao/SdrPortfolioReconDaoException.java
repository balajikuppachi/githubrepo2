package com.wf.df.sdr.exception.dao;

public class SdrPortfolioReconDaoException extends DaoException
{
	/**
	 * Method 'SdrPortfolioReconDaoException'
	 * 
	 * @param message
	 */
	public SdrPortfolioReconDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'SdrPortfolioReconDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public SdrPortfolioReconDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
