package com.wf.df.sdr.dao;

import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.SdrCptyPortfolioRecon;
import com.wf.df.sdr.exception.dao.SdrCptyPortfolioReconDaoException;

public interface SdrCptyPortfolioReconDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(SdrCptyPortfolioRecon dto);

	/** 
	 * Returns all rows from the sdr_cpty_portfolio_recon table that match the criteria ''.
	 */
	public List<SdrCptyPortfolioRecon> findAll() throws SdrCptyPortfolioReconDaoException;
	
	/** 
	 * Returns all rows from the sdr_cpty_portfolio_recon table that match the criteria frequency and recon_date.
	 */
	public List<SdrCptyPortfolioRecon> findFreqRcDt(String frequency, Date date) throws SdrCptyPortfolioReconDaoException;

}
