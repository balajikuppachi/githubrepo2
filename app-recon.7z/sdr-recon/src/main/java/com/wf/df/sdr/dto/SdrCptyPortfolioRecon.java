package com.wf.df.sdr.dto;

import java.io.Serializable;
import java.util.Date;

/*sdr_cpty_portfolio_recon*/
public class SdrCptyPortfolioRecon implements Serializable{

	private Long id;
	
	private Date reconDate;
	
	private Long legalId;
	
	private Long baId;
	
	private Long portfolioSize;
	
	private String frequency;
	
	private Long portReconId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getReconDate() {
		return reconDate;
	}

	public void setReconDate(Date reconDate) {
		this.reconDate = reconDate;
	}

	public Long getLegalId() {
		return legalId;
	}

	public void setLegalId(Long legalId) {
		this.legalId = legalId;
	}

	public Long getBaId() {
		return baId;
	}

	public void setBaId(Long baId) {
		this.baId = baId;
	}

	public Long getPortfolioSize() {
		return portfolioSize;
	}

	public void setPortfolioSize(Long portfolioSize) {
		this.portfolioSize = portfolioSize;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Long getPortReconId() {
		return portReconId;
	}

	public void setPortReconId(Long portReconId) {
		this.portReconId = portReconId;
	}
	
	
	
	
}
