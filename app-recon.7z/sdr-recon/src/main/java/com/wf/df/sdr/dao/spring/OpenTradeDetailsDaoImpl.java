package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.OpenTradeDetailsDao;
import com.wf.df.sdr.dto.OpenTradeDetails;
import com.wf.df.sdr.exception.dao.OpenTradeDetailsDaoException;

public class OpenTradeDetailsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<OpenTradeDetails>, OpenTradeDetailsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(OpenTradeDetails dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, src_trade_id, party1_lei, party2_lei, bus_acc_id ) VALUES ( ?, ?, ?, ?, ? )",dto.getSendId(),dto.getSrcTradeId(),dto.getParty1Lei(),dto.getParty2Lei(), dto.getBusAIdC());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return BufferStore
	 */
	public OpenTradeDetails mapRow(ResultSet rs, int row) throws SQLException
	{
		OpenTradeDetails dto = new OpenTradeDetails();
		dto.setSendId(Integer.valueOf(rs.getString(1)));
		dto.setSrcTradeId(rs.getString(2));
		dto.setParty1Lei(rs.getString(3));
		dto.setParty2Lei(rs.getString(4));
		dto.setBusAIdC(Integer.valueOf(rs.getString(5)));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "temp_open_trade_details";
	}

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria ''.
	 */
	@Transactional
	public List<OpenTradeDetails> findAll() throws OpenTradeDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_id, party1_lei, party2_lei, bus_acc_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new OpenTradeDetailsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria 'bus_acc_id = :busAIdC'.
	 */
	@Transactional
	public List<OpenTradeDetails> findWhereBusAIdCEquals(Integer busAIdC) throws OpenTradeDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_id, party1_lei, party2_lei, bus_acc_id FROM " + getTableName() + " WHERE bus_acc_id = ? ORDER BY bus_acc_id", this,busAIdC);
		}
		catch (Exception e) {
			throw new OpenTradeDetailsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<OpenTradeDetails> findWhereSendIdEquals(Integer sendId) throws OpenTradeDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_id, party1_lei, party2_lei, bus_acc_id FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new OpenTradeDetailsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the temp_open_trade_details table that match the criteria 'src_trade_id = :srcTradeId'.
	 */
	@Transactional
	public List<OpenTradeDetails> findWhereSrcTradeIdEquals(String srcTradeId) throws OpenTradeDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_id, party1_lei, party2_lei, bus_acc_id FROM " + getTableName() + " WHERE src_trade_id = ? ORDER BY src_trade_id", this,srcTradeId);
		}
		catch (Exception e) {
			throw new OpenTradeDetailsDaoException("Query failed", e);
		}
		
	}
	

}
