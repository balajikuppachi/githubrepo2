package com.wf.df.sdr.exception.dao;

public class BusinessAccountDetailsDaoException extends DaoException
{
	/**
	 * Method 'CollateralAgreementsDaoException'
	 * 
	 * @param message
	 */
	public BusinessAccountDetailsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'CollateralAgreementsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public BusinessAccountDetailsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
