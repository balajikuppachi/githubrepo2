package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.BusinessAccountDetailsDao;
import com.wf.df.sdr.dto.BusinessAccountDetails;
import com.wf.df.sdr.exception.dao.BusinessAccountDetailsDaoException;

public class BusinessAccountDetailsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<BusinessAccountDetails>, BusinessAccountDetailsDao {
	
	protected SimpleJdbcTemplate jdbcTemplate;
	
	protected DataSource dataSource;
	
	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(BusinessAccountDetails bd)
	{
		try{
			jdbcTemplate.update("INSERT INTO " + getTableName() + " ( bus_a_id_c,bus_a_n,system_c,bus_a_extl_key_c,bus_a_extl_n,relationshipType,lgle_id_c,lgle_type_c,lgle_full_n,regEntitySwapDealer,etSD_rates,etSD_equityderivatives,etSD_commodities,etSD_creditderivatives,etSD_FX,regEntitySecBasedSwapDealer,etSBSD_rates,etSBSD_equityderivatives,etSBSD_commodities,etSBSD_creditderivatives,etSBSD_FX,regEntityMajorSwap,etMSP_rates,etMSP_equityderivatives,etMSP_commodities,etMSP_creditderivatives,etMSP_FX,regEntitySecBasedMajorSwap,etSBMSP_rates,etSBMSP_equityderivatives,etSBMSP_commodities,etSBMSP_creditderivatives,etSBMSP_FX,regEntityEndUser,df_ETEU_EndUserType,isdaRiskValuation,isdaPortfolioRecon,portfolioDataMethod,deliveryPortfolioDataEmail,reconSDRData,qualifer,lei ) VALUES ( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )",bd.getBusAIdC(),bd.getBusAN(),bd.getSystemC(),bd.getBusAExtlKeyC(),bd.getBusAExtlN(),bd.getRelationshipType(),bd.getLgleIdC(),bd.getLgleTypeC(),bd.getLgleFullN(),bd.getRegEntitySwapDealer(),bd.getEtSDRates(),bd.getEtSDEquityderivatives(),bd.getEtSDCommodities(),bd.getEtSDCreditderivatives(),bd.getEtSDFX(),bd.getRegEntitySecBasedSwapDealer(),bd.getEtSBSDRates(),bd.getEtSBSDEquityderivatives(),bd.getEtSBSDCommodities(),bd.getEtSBSDCreditderivatives(),bd.getEtSBSDFX(),bd.getRegEntityMajorSwap(),bd.getEtMSPRates(),bd.getEtMSPEquityderivatives(),bd.getEtMSPCommodities(),bd.getEtMSPCreditderivatives(),bd.getEtMSPFX(),bd.getRegEntitySecBasedMajorSwap(),bd.getEtSBMSPRates(),bd.getEtSBMSPEquityderivatives(),bd.getEtSBMSPCommodities(),bd.getEtSBMSPCreditderivatives(),bd.getEtSBMSPFX(),bd.getRegEntityEndUser(),bd.getDfETEUEndUserType(),bd.getIsdaRiskValuation(),bd.getIsdaPortfolioRecon(),bd.getPortfolioDataMethod(),bd.getDeliveryPortfolioDataEmail(),bd.getReconSDRData(),bd.getQualifier(),bd.getlei());
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return BufferStore
	 */
	public BusinessAccountDetails mapRow(ResultSet rs, int row) throws SQLException
	{
		BusinessAccountDetails bd = new BusinessAccountDetails();
		bd.setBusAIdC(rs.getInt(1));
		bd.setBusAN(rs.getString(2));
		bd.setSystemC(rs.getString(3));
		bd.setBusAExtlKeyC(rs.getString(4));
		bd.setBusAExtlN(rs.getString(5));
		bd.setRelationshipType(rs.getString(6));
		bd.setLgleIdC(rs.getInt(7));
		bd.setLgleTypeC(rs.getString(8));
		bd.setLgleFullN(rs.getString(9));
		bd.setRegEntitySwapDealer(rs.getString(10));
		bd.setEtSDRates(rs.getString(11));
		bd.setEtSDEquityderivatives(rs.getString(12));
		bd.setEtSDCommodities(rs.getString(13));
		bd.setEtSDCreditderivatives(rs.getString(14));
		bd.setEtSDFX(rs.getString(15));
		bd.setRegEntitySecBasedSwapDealer(rs.getString(16));
		bd.setEtSBSDRates(rs.getString(17));
		bd.setEtSBSDEquityderivatives(rs.getString(18));
		bd.setEtSBSDCommodities(rs.getString(19));
		bd.setEtSBSDCreditderivatives(rs.getString(20));
		bd.setEtSBSDFX(rs.getString(21));
		bd.setRegEntityMajorSwap(rs.getString(22));
		bd.setEtMSPRates(rs.getString(23));
		bd.setEtMSPEquityderivatives(rs.getString(24));
		bd.setEtMSPCommodities(rs.getString(25));
		bd.setEtMSPCreditderivatives(rs.getString(26));
		bd.setEtMSPFX(rs.getString(27));
		bd.setRegEntitySecBasedMajorSwap(rs.getString(28));
		bd.setEtSBMSPRates(rs.getString(29));
		bd.setEtSBMSPEquityderivatives(rs.getString(30));
		bd.setEtSBMSPCommodities(rs.getString(31));
		bd.setEtSBMSPCreditderivatives(rs.getString(32));
		bd.setEtSBMSPFX(rs.getString(33));
		bd.setRegEntityEndUser(rs.getString(34));
		bd.setDfETEUEndUserType(rs.getString(35));
		bd.setIsdaRiskValuation(rs.getString(36));
		bd.setIsdaPortfolioRecon(rs.getString(37));
		bd.setPortfolioDataMethod(rs.getString(38));
		bd.setDeliveryPortfolioDataEmail(rs.getString(39));
		bd.setReconSDRData(rs.getString(40));
		bd.setQualifier(rs.getString(41));
		bd.setlei(rs.getString(42));
		return bd;
	}
	
	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "cpty_bus_accnt_details";
	}
	
	/** 
	 * Returns all rows from the cpty_bus_accnt_details table that match the criteria ''.
	 */
	@Transactional
	public List<BusinessAccountDetails> findAll() throws BusinessAccountDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT bus_a_id_c,bus_a_n,system_c,bus_a_extl_key_c,bus_a_extl_n,relationshipType,lgle_id_c,lgle_type_c,lgle_full_n,regEntitySwapDealer,etSD_rates,etSD_equityderivatives,etSD_commodities,etSD_creditderivatives,etSD_FX,regEntitySecBasedSwapDealer,etSBSD_rates,etSBSD_equityderivatives,etSBSD_commodities,etSBSD_creditderivatives,etSBSD_FX,regEntityMajorSwap,etMSP_rates,etMSP_equityderivatives,etMSP_commodities,etMSP_creditderivatives,etMSP_FX,regEntitySecBasedMajorSwap,etSBMSP_rates,etSBMSP_equityderivatives,etSBMSP_commodities,etSBMSP_creditderivatives,etSBMSP_FX,regEntityEndUser,df_ETEU_EndUserType,isdaRiskValuation,isdaPortfolioRecon,portfolioDataMethod,deliveryPortfolioDataEmail,reconSDRData,qualifer,lei FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new BusinessAccountDetailsDaoException("Query failed", e);
		}
		
	}
	
	
}
