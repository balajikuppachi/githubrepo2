package com.wf.df.sdr.dto;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/*@Table : sdr_portfolio_recon */
public class SdrPortfolioRecon implements Serializable{

	private Long id;
	
	private Date asOfDate;
	
	private Date reconStarted;
	
	private Date reconCompleted;
	
	public SdrPortfolioRecon() {};
	
	public SdrPortfolioRecon(Date asOfDate) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(asOfDate);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		this.asOfDate = calendar.getTime();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(asOfDate);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		this.asOfDate = calendar.getTime();
	}

	public Date getReconStarted() {
		return reconStarted;
	}

	public void setReconStarted(Date reconStarted) {
		this.reconStarted = reconStarted;
	}

	public Date getReconCompleted() {
		return reconCompleted;
	}

	public void setReconCompleted(Date reconCompleted) {
		this.reconCompleted = reconCompleted;
	}
	

	@Override
	public String toString() {
		return "SdrPortfolioRecon [id=" + id + ", asOfDate=" + asOfDate
				+ ", reconStarted=" + reconStarted + ", reconCompleted="
				+ reconCompleted + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((asOfDate == null) ? 0 : asOfDate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((reconCompleted == null) ? 0 : reconCompleted.hashCode());
		result = prime * result
				+ ((reconStarted == null) ? 0 : reconStarted.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SdrPortfolioRecon other = (SdrPortfolioRecon) obj;
		if (asOfDate == null) {
			if (other.asOfDate != null)
				return false;
		} else if (!asOfDate.equals(other.asOfDate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (reconCompleted == null) {
			if (other.reconCompleted != null)
				return false;
		} else if (!reconCompleted.equals(other.reconCompleted))
			return false;
		if (reconStarted == null) {
			if (other.reconStarted != null)
				return false;
		} else if (!reconStarted.equals(other.reconStarted))
			return false;
		return true;
	}
	
}
