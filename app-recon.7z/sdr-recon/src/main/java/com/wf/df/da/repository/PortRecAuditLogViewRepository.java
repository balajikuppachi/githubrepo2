package com.wf.df.da.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.df.da.domain.PortRecAuditLogView;
import com.wf.df.da.domain.PortRecAuditLogViewPk;

public interface PortRecAuditLogViewRepository extends CrudRepository<PortRecAuditLogView, PortRecAuditLogViewPk> {

	@Query("select cpr from PortRecAuditLogView cpr where cpr.portRecAuditLogViewPk.reconDate = ?")
	List<PortRecAuditLogView> findForReconDate(String date);
}
