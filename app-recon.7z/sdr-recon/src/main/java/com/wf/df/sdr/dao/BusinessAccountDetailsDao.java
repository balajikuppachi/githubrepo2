package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.BusinessAccountDetailsDao;
import com.wf.df.sdr.dto.BusinessAccountDetails;
import com.wf.df.sdr.exception.dao.BusinessAccountDetailsDaoException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface BusinessAccountDetailsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(BusinessAccountDetails dto);

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria ''.
	 */
	public List<BusinessAccountDetails> findAll() throws BusinessAccountDetailsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'agreement_id = :agreementId'.
	 *//*
	public List<BusinessAccountDetails> findWhereAgreementIdEquals(String agreementId) throws BusinessAccountDetailsDaoException;

	*//** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'agreement_type = :agreementType'.
	 *//*
	public List<BusinessAccountDetails> findWhereAgreementTypeEquals(String agreementType) throws BusinessAccountDetailsDaoException;

	*//** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'shortname = :shortname'.
	 *//*
	public List<BusinessAccountDetails> findWhereShortnameEquals(String shortname) throws BusinessAccountDetailsDaoException;

	*//** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'margin_type = :marginType'.
	 *//*
	public List<BusinessAccountDetails> findWhereMarginTypeEquals(String marginType) throws BusinessAccountDetailsDaoException;

	*//** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'market_value = :marketValue'.
	 *//*
	public List<BusinessAccountDetails> findWhereMarketValueEquals(BigDecimal marketValue) throws BusinessAccountDetailsDaoException;

	*//** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'ext_agreement_type = :extAgreementType'.
	 *//*
	public List<BusinessAccountDetails> findWhereExtAgreementTypeEquals(String extAgreementType) throws BusinessAccountDetailsDaoException;

	*//** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'cid_legal = :cidLegal'.
	 *//*
	public List<BusinessAccountDetails> findWhereCidLegalEquals(Integer cidLegal) throws BusinessAccountDetailsDaoException;

	*//** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'create_datetime = :createDatetime'.
	 *//*
	public List<BusinessAccountDetails> findWhereCreateDatetimeEquals(Date createDatetime) throws BusinessAccountDetailsDaoException;
*/
}
