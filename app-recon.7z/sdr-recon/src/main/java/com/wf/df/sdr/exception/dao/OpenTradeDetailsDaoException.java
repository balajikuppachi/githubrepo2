package com.wf.df.sdr.exception.dao;

public class OpenTradeDetailsDaoException extends DaoException
{
	/**
	 * Method 'OpenTradeDetailsDaoException'
	 * 
	 * @param message
	 */
	public OpenTradeDetailsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'OpenTradeDetailsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public OpenTradeDetailsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
