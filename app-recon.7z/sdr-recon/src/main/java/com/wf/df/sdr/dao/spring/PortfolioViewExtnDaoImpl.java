package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.CountTracker;

@Repository
public class PortfolioViewExtnDaoImpl
{
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	//String leiQuery = "select distinct substring(sd.party2_lei, charindex(':',sd.party2_lei)+1, char_length(sd.party2_lei)) from temp_open_trade_details sd, sdr_cpty_portfolio_recon cp where sd.bus_acc_id=cp.bus_acnt_id and cp.legal_id = ? and frequency = ? and cp.portfolio_recon_id = ? and sd.party2_lei not like '%KB1H1DSPRFMYMCUFXT09' ";

	//String leiQuery = "select distinct sd.lei from cpty_bus_accnt_details sd, sdr_cpty_portfolio_recon cp where sd.bus_a_id_c=cp.bus_acnt_id and cp.legal_id = ? and frequency = ? and cp.portfolio_recon_id = ? and sd.lei not like '%KB1H1DSPRFMYMCUFXT09'";
	
	String leiQuery = "select DISTINCT substring(t.party2_lei, charindex(':',t.party2_lei)+1, char_length(t.party2_lei))  from temp_open_trade_details t, cpty_bus_accnt_details c, sdr_cpty_portfolio_recon s where t.bus_acc_id = c.bus_a_id_c and c.lgle_id_c = s.legal_id  and c.lgle_id_c = ? and s.frequency = ? and s.portfolio_recon_id = ? and t.party2_lei not like '%KB1H1DSPRFMYMCUFXT09'";
	
	String busAccDistinct = "select DISTINCT convert(varchar, bus_acc_id) bus_acc, src_system_name from temp_open_trade_details where bus_acc_id is not null and bus_acc_id != 0";
	
	String get1STRTradeUsi = "select tm.src_trade_id,tm.usi From temp_open_trade_details tm, sdr_cpty_portfolio_recon sd where sd.bus_acnt_id=tm.bus_acc_id and sd.legal_id=? and sd.portfolio_recon_id=? and tm.asset_class=?";
	
	@Transactional
	public List<String> fetchLeiForGivenLegalId(Long legalId, String frequency, Long portReconId) {
		List<String> rsList = jdbcTemplate.queryForList(leiQuery, String.class, legalId, frequency, portReconId);
		return rsList;

	}
	@Transactional
	public List<Map<String, Object>> fetchBusAccID() {
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(busAccDistinct);
		return rows;
	}
	
	@Transactional
	public List<CountTracker> fetch1STRTradeUsi(Long legalId, Long portReconId, String assetClass) {
		//List<CountTracker> usiList = jdbcTemplate.queryForList(get1STRTradeUsi, String.class, legalId, portReconId, assetClass);
		List<CountTracker> usiList = jdbcTemplate.query(get1STRTradeUsi, new Object[]{legalId, portReconId, assetClass},
				new RowMapper<CountTracker>(){
					
					@Override
					public CountTracker mapRow(ResultSet rs, int arg1) throws SQLException {
						CountTracker ct = new CountTracker();
						ct.setTradeId(rs.getString(1));
						ct.setUsi(rs.getString(2));
						return ct;
					}
				});
		
		return usiList;
		}
}

