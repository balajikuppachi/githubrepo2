package com.wf.portrec.service.report;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

@Component
@ManagedResource(description="Generating MT")
public class TriggerAllCptyCsvGenerators {
	
	Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	IRCptyCsvGenerator iRCptyCsvGenerator;
	
	@Autowired
	CRCptyCsvGenerator cRCptyCsvGenerator;
	
	@Autowired
	FxCptyCsvGenerator fxCptyCsvGenerator;
	
	@Autowired
	EQCptyCsvGenerator eQCptyCsvGenerator;
	
	@Autowired
	CommCptyCsvGenerator commCptyCsvGenerator;
	
	@ManagedOperation(description="Generating MT")
	public void triggerJMX(String counterPartyLeis, String legalId, String reconDate, String period, Long portReconId){
		
		logger.info("counterPartyLeis :["+ counterPartyLeis + "], legalId :[" + legalId + "], reconDate :["+ reconDate + "]");
		String[] array = counterPartyLeis.split(",");
		List<String> counterPartyLeiList = Arrays.asList(array);
		
		try {
			generateAllCptyMTFiles(counterPartyLeiList, legalId, new SimpleDateFormat("MM/dd/yyyy").parse(reconDate), period, portReconId);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	public OutputFileProperties generateAllCptyMTFiles(List<String> counterPartyLeiList, String legalId, Date reconDate, String period, Long portReconId) throws IOException, ParseException{
		logger.info("counterPartyLei :["+ counterPartyLeiList + "], legalId :[" + legalId + "], reconDate :["+ reconDate + "]");
		boolean mtIrFileFlag = false;
		boolean mtCrFileFlag = false;
		boolean mtFxFileFlag = false;
		boolean mtEqFileFlag = false;
		boolean mtCommFileFlag = false;
		
		OutputFileProperties portfolioProp = new OutputFileProperties(); 
		portfolioProp.setAssetClass(ReportConstants.ASSET_CLASS_ALL);
		if(null!=counterPartyLeiList){
			OutputFileProperties irProp = iRCptyCsvGenerator.createFile(counterPartyLeiList,legalId, reconDate, period, portReconId);
			OutputFileProperties crProp = cRCptyCsvGenerator.createFile(counterPartyLeiList,legalId,reconDate, period, portReconId);
			OutputFileProperties fxProp = fxCptyCsvGenerator.createFile(counterPartyLeiList,legalId,reconDate, period, portReconId);
			OutputFileProperties eqProp = eQCptyCsvGenerator.createFile(counterPartyLeiList,legalId,reconDate, period, portReconId);
			OutputFileProperties commProp = commCptyCsvGenerator.createFile(counterPartyLeiList, legalId, reconDate, period, portReconId);
			
			long count = irProp.getCount()+crProp.getCount()+fxProp.getCount()+eqProp.getCount()+commProp.getCount();
			logger.info("["+counterPartyLeiList+"] Portfolio Frequency :["+ count + "]");
			
			mtIrFileFlag =  irProp.isFlag();
			mtCrFileFlag =  crProp.isFlag();
			mtFxFileFlag =  fxProp.isFlag();
			mtEqFileFlag =  eqProp.isFlag();
			mtCommFileFlag =  commProp.isFlag();
			
			portfolioProp.setFlag(mtIrFileFlag||mtCrFileFlag||mtFxFileFlag||mtEqFileFlag||mtCommFileFlag);
			portfolioProp.setCount(count);
		}
		
		return portfolioProp;
	}
	
}
