package com.wf.portrec.service.loader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wf.df.sdr.dao.PortfolioViewDao;
import com.wf.df.sdr.dao.SdrCptyPortfolioReconDao;
import com.wf.df.sdr.dao.SdrPortfolioReconDao;
import com.wf.df.sdr.dto.PortfolioView;
import com.wf.df.sdr.dto.SdrCptyPortfolioRecon;
import com.wf.df.sdr.dto.SdrPortfolioRecon;
import com.wf.df.sdr.service.SdrCptyPortfolioReconIdSequence;
import com.wf.df.sdr.service.SdrPortfolioReconIdSequence;
import com.wf.portrec.domain.CounterpartyTypeEnum;
import com.wf.portrec.domain.CptyPortfolioRecon;
import com.wf.portrec.domain.FrequencyTypeEnum;
import com.wf.portrec.domain.PortfolioSegment;
import com.wf.portrec.domain.RecCommMtermsStore;
import com.wf.portrec.domain.TradeRecordTypeEnum;
import com.wf.portrec.repository.FXTradeUnfilterdRepository;
import com.wf.portrec.repository.PortfolioSegmentRepository;

///@Transactional(value="portrec", propagation=Propagation.NEVER)
public abstract class CptyLoaderHelper {
	
	/*@Autowired
	MailerCptyPortfolioReconRepositoryFromView cptyPortfolioReconFromViewRepository;*/ // SDR
	
	@Autowired
	PortfolioViewDao portfolioViewDao;
	
	/*@Autowired
	PortfolioReconRepository portRecRepo;*/ // pr_portfolio_recon SDR
	
	@Autowired
	SdrPortfolioReconDao sdrPortfolioReconDao;
	
	@Autowired
	SdrPortfolioReconIdSequence sdrPortfolioReconIdSequence;
	
	@Autowired
	FXTradeUnfilterdRepository fxTradeUnfilterdRepository; // portrec

	/*@Autowired
	CounterpartyRepository counterpartyRepository;*/ // not in use. View would have this data

	/*@Autowired
	CptyPortfolioReconRepository cptyPortRecRepo;*/ // SDR 
	
	@Autowired
	SdrCptyPortfolioReconDao sdrCptyPortfolioReconDao;
	
	@Autowired
	SdrCptyPortfolioReconIdSequence sdrCptyPortfolioReconIdSequence;
	
	@Autowired
	PortfolioSegmentRepository portfolioSegmentRepo; // portrec

	PortfolioSegment portfolioSegment;

	private Logger logger = LoggerFactory.getLogger(CptyLoaderHelper.class);
	
	@PostConstruct
	void init() {
		List<PortfolioSegment> segments = portfolioSegmentRepo.findByName(getPortfolioSegmentName());
		if (segments.size() != 1) {
			throw new RuntimeException("Could not initialize Portfolio Segment '" + getPortfolioSegmentName() + "'");
		}
		portfolioSegment = segments.get(0);
	}
	
	public abstract TradeRecordTypeEnum getRecordType();
	
	public abstract String getPortfolioSegmentName();

	public abstract CptyPortfolioRecon parseRecord(RecCommMtermsStore commodity) throws ParseException;

	public abstract boolean validate(CptyPortfolioRecon trade);
	
	public void postLoad() {};
	
	public void read(InputStream inputStream, String fileName, Date asOfDate,SdrPortfolioRecon recon) throws IOException, ParseException{
		//FIXME: AZ - passing "DEV" and NOW for name and as_of_date, should be accepted as a read() parameter instead
		loadFile(recon);
		logger.info("Data has been Loaded for "+ portfolioSegment.getName() +" from file: " + fileName +" as on "+asOfDate);
	}
	
	public SdrPortfolioRecon startRecon(SdrPortfolioRecon recon) {
		logger.info("Starting reconciliation " + recon);
		recon.setId(sdrPortfolioReconIdSequence.getNextId().longValue());
		recon.setReconStarted(new Date());
		sdrPortfolioReconDao.insert(recon);
		return recon;
	}
	
	public SdrPortfolioRecon initCptyRecons(SdrPortfolioRecon recon) throws IOException, ParseException {
		File file = new File("Test");
		logger.info("Loading data from file: " + file);
		Date asOfDate = extractAsOfDateFromFileName(file);
		InputStream is = null;
		try {
			is = null;
			this.read(is, file.getName(), asOfDate,recon);
		} finally {
			if (is != null) {
				is.close();
			}
		}
		return recon;
	}
	
	@SuppressWarnings("unchecked")
	void loadFile(SdrPortfolioRecon recon) throws IOException, ParseException {
		try {
			// Load fx international data to temp_open_trade_details 
			// List<Object[]> fxIntList = fxTradeUnfilterdRepository.findAllUnlinkedIntSrcTrades(new Date());
			List<PortfolioView> cptyReconView=portfolioViewDao.findWhereReconDateEquals(new Date());
			List<SdrCptyPortfolioRecon> cptyReconsList = cptyReconsToStart(recon,cptyReconView);
			for(SdrCptyPortfolioRecon cptyPortfolioRecon : cptyReconsList){
				sdrCptyPortfolioReconDao.insert(cptyPortfolioRecon);
			}
		logger.info("cptyPortRecRepo records. Saving for all asset class : "+cptyReconsList.size());
		} finally {
		}
		postLoad();
	}
	
	
	private List<SdrCptyPortfolioRecon> cptyReconsToStart(SdrPortfolioRecon portfolioRecon,List<PortfolioView> cptyReconView) {
		LinkedList<SdrCptyPortfolioRecon> cptyRecons = new LinkedList<SdrCptyPortfolioRecon>();
		for(PortfolioView view : cptyReconView){
			SdrCptyPortfolioRecon cptyRecon = new SdrCptyPortfolioRecon();

				cptyRecon.setId(sdrCptyPortfolioReconIdSequence.getNextId().longValue());
				cptyRecon.setReconDate(view.getAsOfDate());
				cptyRecon.setLegalId(view.getLegalId());
				cptyRecon.setBaId(view.getBusAIdC());
				cptyRecon.setPortfolioSize(view.getPortfolioSize());
				cptyRecon.setFrequency(reconFrequency(view));
				cptyRecon.setPortReconId(portfolioRecon.getId());
				cptyRecons.add(cptyRecon);
				logger.debug("Cpty Recon to start: " + cptyRecon);
		}
		return cptyRecons;
	}
	
	private String reconFrequency(PortfolioView portfolioView) {
		
		Long portfolioSize = portfolioView.getPortfolioSize();
		
		CounterpartyTypeEnum cptyType = CounterpartyTypeEnum.UNKNOWN;
		

		if(null != portfolioView.getRegEntitySwapDealer() && portfolioView.getRegEntitySwapDealer().equalsIgnoreCase("Y")){
			cptyType = CounterpartyTypeEnum.SD;
		}else if(null != portfolioView.getRegEntityMajorSwap() && portfolioView.getRegEntityMajorSwap().equalsIgnoreCase("Y")){
			cptyType = CounterpartyTypeEnum.MSP;
		} else {
			cptyType = CounterpartyTypeEnum.NON_SD_MSP;
		}
		
		
		switch (cptyType) {
		case NON_SD_MSP:
			if (portfolioSize > 100) {
				return FrequencyTypeEnum.QUARTERLY.getFrequencyType();
			} else {
				return FrequencyTypeEnum.ANNUALLY.getFrequencyType();
			}
		case SD:
		case MSP:
		case UNKNOWN:
		default:
			if (portfolioSize >= 500) {
				return FrequencyTypeEnum.DAILY.getFrequencyType();
			} else if (portfolioSize >= 51) {
				return FrequencyTypeEnum.WEEKLY.getFrequencyType();
			} else {
				return FrequencyTypeEnum.QUARTERLY.getFrequencyType();
			}
		}
	}
	
	
	Date extractAsOfDateFromFileName(File file) {
		return new Date();
	}
}
