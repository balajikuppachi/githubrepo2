package com.wf.portrec.service.report;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.IRTrade;
import com.wf.portrec.repository.IRTradeRepository;
import com.wf.portrec.repository.MismatchLogRepository;

@Component
public class IrDataCsvWriter {

	Logger logger = LoggerFactory.getLogger(getClass());
	static char SEPARATOR = ',';
	@Value("${mask.counterparty.details}") String counterPartyValue;
	@Value("${wf.affiliatebank.leis}") String wfLeiList;
	
	@Autowired
	IRTradeRepository irTradeRepository;

	@Autowired
	MismatchLogRepository mismatchRepository;

	@PostConstruct
	void init() {
	}

	public void generateMatchUSIFile(File targetFile, Map<String,IRTrade> usiTrdIdMap, String fileType){
		try {
			if (targetFile.exists()) {
				targetFile.delete();
			}
			FileWriter writer = new FileWriter(targetFile);
			writer.append("USI");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 LEI");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 Fin Ent");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 US Per Ind");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 LEI");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 Role");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 Role");
			writer.append(SEPARATOR);
			writer.append("Prod Id Val");
			writer.append(SEPARATOR);
			writer.append("Mul Ast Swp");
			writer.append(SEPARATOR);
			writer.append("Pri Ast Cls");
			writer.append(SEPARATOR);
			writer.append("Scnd Ast Cls");
			writer.append(SEPARATOR);
			writer.append("Rprtng Jrsdctn");
			writer.append(SEPARATOR);
			writer.append("Addl Repo 1");
			writer.append(SEPARATOR);
			writer.append("Exec Venue");
			writer.append(SEPARATOR);
			writer.append("Effec Dt - leg 1");
			writer.append(SEPARATOR);
			writer.append("Effec Dt - leg 2");
			writer.append(SEPARATOR);
			writer.append("Tr Dt unad leg 1");
			writer.append(SEPARATOR);
			writer.append("Tr Dt unad leg 2");
			writer.append(SEPARATOR);
			writer.append("Day Cnt Frc - Leg 1");
			writer.append(SEPARATOR);
			writer.append("Day Cnt Frc - Leg 2");
			writer.append(SEPARATOR);
			writer.append("Notl Amt Prty");
			writer.append(SEPARATOR);
			writer.append("Notl Cur");
			writer.append(SEPARATOR);
			writer.append("Notl Amt Cpty");
			writer.append(SEPARATOR);
			writer.append("Notl Cur Cpty");
			writer.append(SEPARATOR);
			writer.append("Leg Payer 1/2");
			writer.append(SEPARATOR);
			writer.append("Leg Payer 1");
			writer.append(SEPARATOR);
			writer.append("Leg Payer 2");
			writer.append(SEPARATOR);
			writer.append("Buyer");
			writer.append(SEPARATOR);
			writer.append("Seller");
			writer.append(SEPARATOR);
			writer.append("Option Type");
			writer.append(SEPARATOR);
			writer.append("Fxd Rt intl-leg 1");
			writer.append(SEPARATOR);
			writer.append("Fxd Rt intl-leg 2");
			writer.append(SEPARATOR);
			writer.append("Day Cnt Frctn-leg 1");
			writer.append(SEPARATOR);
			writer.append("Day Cnt Frctn-leg 2");
			writer.append(SEPARATOR);
			writer.append("Pay Freq prd-leg 1");
			writer.append(SEPARATOR);
			writer.append("Pay Freq prd-leg 2");
			writer.append(SEPARATOR);
			writer.append("Pay Freq prd mltplr-leg 1");
			writer.append(SEPARATOR);
			writer.append("Pay Freq prd mltplr-leg 2");
			writer.append(SEPARATOR);
			writer.append("Rst Freq prd-leg 1");
			writer.append(SEPARATOR);
			writer.append("Rst Freq prd-leg 2");
			writer.append(SEPARATOR);
			writer.append("Rst Freq prd mltpr-leg 1");
			writer.append(SEPARATOR);
			writer.append("Rst Freq prd mltpr-leg 2");
			writer.append(SEPARATOR);
			writer.append("Fltg Rt Index - leg 1");
			writer.append(SEPARATOR);
			writer.append("Fltg Rt Index - leg 2");
			writer.append(SEPARATOR);
			writer.append("Extc - Undrlyng ast");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Exec Timestamp");
			writer.append(SEPARATOR);
			writer.append("Trd Id");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 Fin Ent");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 US Per Ind"); 
			writer.append('\n'); 

			Iterator it = usiTrdIdMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				IRTrade srcViewDomain = (IRTrade) pairs.getValue();
				String usi = (String) pairs.getKey();
				String[] parts = usi.split(":");
				usi = parts[0];
				srcViewDomain.setUsi(usi);
				
				String dayCountFractionLeg1 = srcViewDomain.getDayCountFractionLeg1();
				if(StringUtils.isNotBlank(dayCountFractionLeg1) && StringUtils.equalsIgnoreCase("30/360", dayCountFractionLeg1))
					dayCountFractionLeg1="30E/360";
				
				String dayCountFractionLeg2 = srcViewDomain.getDayCountFractionLeg2();
				if(StringUtils.isNotBlank(dayCountFractionLeg2) && StringUtils.equalsIgnoreCase("30/360", dayCountFractionLeg2))
					dayCountFractionLeg2="30E/360";
				
				/*String usiPrefix = "";
				if(StringUtils.isNotBlank(srcViewDomain.getUsiNamespace()))
					usiPrefix=srcViewDomain.getUsiNamespace();*/
				
				//writer.append(null != srcViewDomain.getUsi() ? usiPrefix.concat(srcViewDomain.getUsi()) : "");
				writer.append(null != srcViewDomain.getUsi() ? srcViewDomain.getUsi() : "");
				writer.append(SEPARATOR);
				
				if(StringUtils.contains("SRC", fileType)){
					writer.append(null != srcViewDomain.getTradeParty2() ? maskCounterPartyDetails(srcViewDomain.getTradeParty2()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2financialEntityStatus() ? srcViewDomain.getTradeParty2financialEntityStatus() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2UsPersonIndicator() ? srcViewDomain.getTradeParty2UsPersonIndicator() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1() ? maskCounterPartyDetails(srcViewDomain.getTradeParty1()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2Role() ? srcViewDomain.getTradeParty2Role() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1Role() ? srcViewDomain.getTradeParty1Role() : "");				
				}else{
					writer.append(null != srcViewDomain.getTradeParty1() ? maskCounterPartyDetails(srcViewDomain.getTradeParty1()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1financialEntityStatus() ? srcViewDomain.getTradeParty1financialEntityStatus() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1UsPersonIndicator() ? srcViewDomain.getTradeParty1UsPersonIndicator() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2() ? maskCounterPartyDetails(srcViewDomain.getTradeParty2()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1Role() ? srcViewDomain.getTradeParty1Role() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2Role() ? srcViewDomain.getTradeParty2Role() : "");				
				}
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getProductType() ? srcViewDomain.getProductType() : "");
				writer.append(SEPARATOR);
				// Multi Asset Swap : If 'Secondary Asset Class' is populated, then 'Yes'. Else 'NA'
				if (StringUtils.isBlank(srcViewDomain.getSecAssetClass())) {
					writer.append("NA");
				} else {
					writer.append("Yes");
				}
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getAssetClass() ? srcViewDomain.getAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSecAssetClass() ? srcViewDomain.getSecAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportingJurisdiction() ? (srcViewDomain.getReportingJurisdiction().contains(",")?srcViewDomain.getReportingJurisdiction().replace("," ,";"):srcViewDomain.getReportingJurisdiction()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getAdditionalRepository1() ? srcViewDomain.getAdditionalRepository1() : "");
				writer.append(SEPARATOR);
				
				String execVenue = srcViewDomain.getExecutionVenue();
				if(StringUtils.isNotBlank(execVenue) && StringUtils.equalsIgnoreCase("Off-Facility", execVenue))
					execVenue="OffFacility";
				writer.append(null != execVenue ? execVenue : "");

				writer.append(SEPARATOR);
				
				if(StringUtils.contains("SRC", fileType)){
					writer.append(null != srcViewDomain.getEffectiveDateLeg2() ? ReportDateUtil.getStrDate(srcViewDomain.getEffectiveDateLeg2()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEffectiveDateLeg1() ? ReportDateUtil.getStrDate(srcViewDomain.getEffectiveDateLeg1()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTerminationDateLeg2() ? ReportDateUtil.getStrDate(srcViewDomain.getTerminationDateLeg2()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTerminationDateLeg1() ? ReportDateUtil.getStrDate(srcViewDomain.getTerminationDateLeg1()) : "");
					writer.append(SEPARATOR);
					writer.append(null != dayCountFractionLeg2 ? dayCountFractionLeg2 : "");
					//writer.append(null != srcViewDomain.getDayCountFractionLeg1() ? srcViewDomain.getDayCountFractionLeg1() : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getDayCountFractionLeg2() ? srcViewDomain.getDayCountFractionLeg2() : "");
					writer.append(null != dayCountFractionLeg1 ? dayCountFractionLeg1 : "");
				}else{
					writer.append(null != srcViewDomain.getEffectiveDateLeg1() ? ReportDateUtil.getStrDate(srcViewDomain.getEffectiveDateLeg1()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEffectiveDateLeg2() ? ReportDateUtil.getStrDate(srcViewDomain.getEffectiveDateLeg2()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTerminationDateLeg1() ? ReportDateUtil.getStrDate(srcViewDomain.getTerminationDateLeg1()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTerminationDateLeg2() ? ReportDateUtil.getStrDate(srcViewDomain.getTerminationDateLeg2()) : "");
					writer.append(SEPARATOR);
					writer.append(null != dayCountFractionLeg1 ? dayCountFractionLeg1 : "");
					//writer.append(null != srcViewDomain.getDayCountFractionLeg1() ? srcViewDomain.getDayCountFractionLeg1() : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getDayCountFractionLeg2() ? srcViewDomain.getDayCountFractionLeg2() : "");
					writer.append(null != dayCountFractionLeg2 ? dayCountFractionLeg2 : "");
				}
				
				
				writer.append(SEPARATOR);
				if (StringUtils.equalsIgnoreCase(srcViewDomain.getProductType(), "InterestRate:Exotic")) {
					writer.append(null != srcViewDomain.getExoticNotionalAmountLeg1() ? srcViewDomain.getExoticNotionalAmountLeg1().toString() : "");
				} else {
					writer.append(null != srcViewDomain.getNotionalAmountParty() ? srcViewDomain.getNotionalAmountParty().toString() : "");
				}
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNotionalCurrencyParty() ? srcViewDomain.getNotionalCurrencyParty() : "");
				writer.append(SEPARATOR);
				if (StringUtils.equalsIgnoreCase(srcViewDomain.getProductType(), "InterestRate:Exotic")) {
					writer.append(null != srcViewDomain.getExoticNotionalAmountLeg2() ? srcViewDomain.getExoticNotionalAmountLeg2().toString() : "");
				} else {
					writer.append(null != srcViewDomain.getNotionalAmountCpty() ? srcViewDomain.getNotionalAmountCpty().toString() : "");
				}
				writer.append(SEPARATOR);

				if (StringUtils.equalsIgnoreCase(srcViewDomain.getProductType(), "InterestRate:Exotic")) {
					writer.append(null != srcViewDomain.getExoticSettlementCurrencyLeg2() ? srcViewDomain.getExoticSettlementCurrencyLeg2() : "");
				} else {
					writer.append(null != srcViewDomain.getNotionalCurrencyCpty() ? srcViewDomain.getNotionalCurrencyCpty() : "");
				}
				writer.append(SEPARATOR);
				
				
				//writer.append(null != srcViewDomain.getSeller() ? srcViewDomain.getSeller().toUpperCase() : "");// Default to Seller for Leg Payer 1/2
				/**For trade Parties ABC & DEF: 
				If Leg 1 Payer = ABC and Fixed Rate (Initial) Leg 1 has a value, then Payer (Fixed Rate) = ABC
				If Leg 1 Payer = ABC and Fixed Rate (Initial) Leg 1 does NOT have a value, then Payer (Fixed Rate) = DEF
				**/
				payerFixedRate(fileType, writer, srcViewDomain);
				/*if (StringUtils.isNotBlank(srcViewDomain.getBuyer())) {
					writer.append(null != srcViewDomain.getBuyer() ? srcViewDomain.getBuyer().toUpperCase() : "");
				} else {
					writer.append(null != srcViewDomain.getLeg1Payer() ? srcViewDomain.getLeg1Payer().toUpperCase() : "");
				}*/
				writer.append(SEPARATOR);
				/*if(StringUtils.contains("SRC", fileType)){
					writer.append(null != srcViewDomain.getLeg2Payer() ? srcViewDomain.getLeg2Payer().toUpperCase() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeg1Payer() ? srcViewDomain.getLeg1Payer().toUpperCase() : "");
				}else{*/
				
				/**SRC :
					Leg1Payer  or Leg2Payer is  -> Party1 : Then Leg1Payer  or Leg2Payer Field -> is TradeParty2
							  					-> Party2 : Then Leg1Payer  or Leg2Payer Field -> is TradeParty1
				   DTCC :		  				
	  				Leg1Payer  or Leg2Payer is  -> Party1 : Then Leg1Payer  or Leg2Payer Field -> is TradeParty1
	  											-> Party2 : Then Leg1Payer  or Leg2Payer Field -> is TradeParty2
				**/
				
				legPayer(fileType, writer, srcViewDomain);
				
				//}
				//writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getBuyer() ? srcViewDomain.getBuyer().toUpperCase() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSeller() ? srcViewDomain.getSeller().toUpperCase() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOptionType() ? srcViewDomain.getOptionType() : "");
				writer.append(SEPARATOR);
			/*	writer.append(null != srcViewDomain.getFixedRateInitialLeg1() ? srcViewDomain.getFixedRateInitialLeg1().toString() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getFixedRateInitialLeg2() ? srcViewDomain.getFixedRateInitialLeg2().toString() : "");
				writer.append(SEPARATOR);*/
				if(StringUtils.contains("SRC", fileType)){
					writer.append(null != srcViewDomain.getFixedRateInitialLeg2() ? srcViewDomain.getFixedRateInitialLeg2().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFixedRateInitialLeg1() ? srcViewDomain.getFixedRateInitialLeg1().toString() : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getDayCountFractionLeg1() ? srcViewDomain.getDayCountFractionLeg1() : "");
					writer.append(null != dayCountFractionLeg2 ? dayCountFractionLeg2 : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getDayCountFractionLeg2() ? srcViewDomain.getDayCountFractionLeg2() : "");
					writer.append(null != dayCountFractionLeg1 ? dayCountFractionLeg1 : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodleg2() ? srcViewDomain.getPaymentFreqPeriodleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodleg1() ? srcViewDomain.getPaymentFreqPeriodleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodMultiplierleg2() ? srcViewDomain.getPaymentFreqPeriodMultiplierleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodMultiplierleg1() ? srcViewDomain.getPaymentFreqPeriodMultiplierleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodleg2() ? srcViewDomain.getResetFreqPeriodleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodleg1() ? srcViewDomain.getResetFreqPeriodleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodMultiplierleg2() ? srcViewDomain.getResetFreqPeriodMultiplierleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodMultiplierleg1() ? srcViewDomain.getResetFreqPeriodMultiplierleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingRateIndexLeg2() ? srcViewDomain.getFloatingRateIndexLeg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingRateIndexLeg1() ? srcViewDomain.getFloatingRateIndexLeg1() : "");
				}else{
					writer.append(null != srcViewDomain.getFixedRateInitialLeg1() ? srcViewDomain.getFixedRateInitialLeg1().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFixedRateInitialLeg2() ? srcViewDomain.getFixedRateInitialLeg2().toString() : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getDayCountFractionLeg1() ? srcViewDomain.getDayCountFractionLeg1() : "");
					writer.append(null != dayCountFractionLeg1 ? dayCountFractionLeg1 : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getDayCountFractionLeg2() ? srcViewDomain.getDayCountFractionLeg2() : "");
					writer.append(null != dayCountFractionLeg2 ? dayCountFractionLeg2 : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodleg1() ? srcViewDomain.getPaymentFreqPeriodleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodleg2() ? srcViewDomain.getPaymentFreqPeriodleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodMultiplierleg1() ? srcViewDomain.getPaymentFreqPeriodMultiplierleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPaymentFreqPeriodMultiplierleg2() ? srcViewDomain.getPaymentFreqPeriodMultiplierleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodleg1() ? srcViewDomain.getResetFreqPeriodleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodleg2() ? srcViewDomain.getResetFreqPeriodleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodMultiplierleg1() ? srcViewDomain.getResetFreqPeriodMultiplierleg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getResetFreqPeriodMultiplierleg2() ? srcViewDomain.getResetFreqPeriodMultiplierleg2() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingRateIndexLeg1() ? srcViewDomain.getFloatingRateIndexLeg1() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingRateIndexLeg2() ? srcViewDomain.getFloatingRateIndexLeg2() : "");
				}

				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getExoticUnderlyingAsset() ? srcViewDomain.getExoticUnderlyingAsset() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getCollaterlized() ? srcViewDomain.getCollaterlized() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeDate() ? ReportDateUtil.getStrDate(srcViewDomain.getTradeDate()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getExecutionDate() ? ReportDateUtil.getExecTimestampAsString(srcViewDomain.getExecutionDate()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOrigTradeId() ? srcViewDomain.getOrigTradeId() : "");
				if(StringUtils.contains("SRC", fileType)){
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1financialEntityStatus() ? srcViewDomain.getTradeParty1financialEntityStatus() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1UsPersonIndicator() ? srcViewDomain.getTradeParty1UsPersonIndicator() : "");
					
				}else{
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2financialEntityStatus() ? srcViewDomain.getTradeParty2financialEntityStatus() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2UsPersonIndicator() ? srcViewDomain.getTradeParty2UsPersonIndicator() : "");
						
				}
				writer.append('\n');
				it.remove(); // avoids a ConcurrentModificationException
			}
			writer.flush();
			writer.close();
		}
		catch (IOException e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * @param fileType
	 * @param writer
	 * @param srcViewDomain
	 * @throws IOException
	 */
	private void legPayer(String fileType, FileWriter writer,
			IRTrade srcViewDomain) throws IOException {
		//if(StringUtils.contains("SRC", fileType)){
			/*if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY1")){
				writer.append(null != srcViewDomain.getTradeParty2() ? srcViewDomain.getTradeParty2() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1() ? srcViewDomain.getTradeParty1() : "");
				writer.append(SEPARATOR);
			}else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY2")){
				writer.append(null != srcViewDomain.getTradeParty1() ? srcViewDomain.getTradeParty1() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty2() ? srcViewDomain.getTradeParty2() : "");
				writer.append(SEPARATOR);
			}else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg2Payer(), "PARTY1")){
				writer.append(null != srcViewDomain.getTradeParty2() ? srcViewDomain.getTradeParty1() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1() ? srcViewDomain.getTradeParty2() : "");
				writer.append(SEPARATOR);
			}else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg2Payer(), "PARTY2")){
				writer.append(null != srcViewDomain.getTradeParty1() ? srcViewDomain.getTradeParty2() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty2() ? srcViewDomain.getTradeParty1() : "");
				writer.append(SEPARATOR);
			}else{
				writer.append("");
				writer.append(SEPARATOR);
				writer.append("");
				writer.append(SEPARATOR);
			}*/
		/*}else{*/
			if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY1")){
				writer.append(null != srcViewDomain.getTradeParty1() ? maskCounterPartyDetails(srcViewDomain.getTradeParty1()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty2() ? maskCounterPartyDetails(srcViewDomain.getTradeParty2()) : "");
				writer.append(SEPARATOR);
			}else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY2")){
				writer.append(null != srcViewDomain.getTradeParty2() ? maskCounterPartyDetails(srcViewDomain.getTradeParty2()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1() ? maskCounterPartyDetails(srcViewDomain.getTradeParty1()) : "");
				writer.append(SEPARATOR);
			}/*else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg2Payer(), "PARTY1")){
				writer.append(null != srcViewDomain.getTradeParty1() ? srcViewDomain.getTradeParty2() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty2() ? srcViewDomain.getTradeParty1() : "");
				writer.append(SEPARATOR);
			}else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg2Payer(), "PARTY2")){
				writer.append(null != srcViewDomain.getTradeParty2() ? srcViewDomain.getTradeParty1() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1() ? srcViewDomain.getTradeParty2() : "");
				writer.append(SEPARATOR);
			}*/else{
				writer.append("");
				writer.append(SEPARATOR);
				writer.append("");
				writer.append(SEPARATOR);
			}
			/*}*/
	}	
	
	
	/**
	 *For trade Parties ABC & DEF: 
				If Leg 1 Payer = ABC and Fixed Rate (Initial) Leg 1 has a value, then Payer (Fixed Rate) = ABC ie., Tradeparty1
				If Leg 1 Payer = ABC and Fixed Rate (Initial) Leg 1 does NOT have a value, then Payer (Fixed Rate) = DEF ie.,Tradeparty2
	 * @param fileType
	 * @param writer
	 * @param srcViewDomain
	 * @throws IOException
	 */
	private void payerFixedRate(String fileType, FileWriter writer,
			IRTrade srcViewDomain) throws IOException {
			if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY1") && srcViewDomain.getFixedRateInitialLeg1()!=null){
				writer.append(null != srcViewDomain.getTradeParty1() ? maskCounterPartyDetails(srcViewDomain.getTradeParty1()) : "");
			}else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY1") && srcViewDomain.getFixedRateInitialLeg1()==null){
				writer.append(null != srcViewDomain.getTradeParty2() ? maskCounterPartyDetails(srcViewDomain.getTradeParty2()) : "");
			}if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY2") && srcViewDomain.getFixedRateInitialLeg1()!=null){
				writer.append(null != srcViewDomain.getTradeParty2() ? maskCounterPartyDetails(srcViewDomain.getTradeParty2()) : "");
			}else if(StringUtils.equalsIgnoreCase(srcViewDomain.getLeg1Payer(), "PARTY2") && srcViewDomain.getFixedRateInitialLeg1()==null){
				writer.append(null != srcViewDomain.getTradeParty1() ? maskCounterPartyDetails(srcViewDomain.getTradeParty1()) : "");
			}else{
				writer.append("");
			}
	}	
	
	private String maskCounterPartyDetails(String leiValue){
		String cpVal = "";
		if(null!=leiValue){
			if(StringUtils.contains(wfLeiList, leiValue)){
				cpVal = leiValue;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}	
}