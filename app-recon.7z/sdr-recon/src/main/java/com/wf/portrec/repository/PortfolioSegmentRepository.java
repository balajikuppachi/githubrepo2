package com.wf.portrec.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.PortfolioSegment;

public interface PortfolioSegmentRepository extends CrudRepository<PortfolioSegment, Long> {
	List<PortfolioSegment> findByName(String name);
}
