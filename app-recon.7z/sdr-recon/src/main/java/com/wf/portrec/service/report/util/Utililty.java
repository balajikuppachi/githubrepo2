package com.wf.portrec.service.report.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wf.portrec.service.report.TriggerAllCptyCsvGenerators;

public class Utililty {

	public static void main(String[] args) {

		
		ApplicationContext context = new ClassPathXmlApplicationContext("\\META-INF\\spring\\portrec-utility-test.xml");
		
		TriggerAllCptyCsvGenerators allCptyCsvGenerators = (TriggerAllCptyCsvGenerators) context.getBean("TriggerAllCptyCsvGenerators");
		
		System.out.println("allCptyCsvGenerators : "+ allCptyCsvGenerators);
		
	}

}
