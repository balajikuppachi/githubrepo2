package com.wf.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rec_cpty_portfolio_recon")
public class CptyPortfolioReconView {

	/*@Id
	@Column(name = "id")
	protected Long id;*/

	@Column(name = "reconDate")
	protected Date reconDate;

	@Id
	@Column(name = "leiCode")
	protected String leiCode;

	@Column(name = "portfolioSize")
	protected Long portfolioSize;

	public String getLeiCode() {
		return leiCode;
	}

	public void setLeiCode(String leiCode) {
		this.leiCode = leiCode;
	}

	/*public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}*/

	public Date getReconDate() {
		return reconDate;
	}

	public void setReconDate(Date reconDate) {
		this.reconDate = reconDate;
	}

	public Long getPortfolioSize() {
		return portfolioSize;
	}

	public void setPortfolioSize(Long portfolioSize) {
		this.portfolioSize = portfolioSize;
	}
}
