package com.wf.portrec.service.report;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.da.domain.PortRecAuditLogView;
import com.wf.df.da.repository.PortRecAuditLogViewRepository;

@Component
public class CptyAckScanner {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	
	/*@Autowired
	CptyAckRepository cptyAckRepository;*/
	
	@Autowired
	PortRecAuditLogViewRepository portRecAuditLogViewRepository;

	/*public List<CptyAcknwledge> readCptyAckData() {		
		Iterable<CptyAcknwledge> listOfCpty = cptyAckRepository.findAll();
		List<CptyAcknwledge> cptyAcknwledges = new ArrayList<CptyAcknwledge>();
		
		if(null != listOfCpty){
			cptyAcknwledges = (List<CptyAcknwledge>) listOfCpty;
		}
		
		return cptyAcknwledges;
	}*/
	
	public List<PortRecAuditLogView> readCptyAckData(String date) {		
		Iterable<PortRecAuditLogView> listOfCpty = portRecAuditLogViewRepository.findForReconDate(date);
		List<PortRecAuditLogView> cptyAcknwledges = new ArrayList<PortRecAuditLogView>();
		
		if(null != listOfCpty){
			cptyAcknwledges = (List<PortRecAuditLogView>) listOfCpty;
		}
		
		return cptyAcknwledges;
	}

}
