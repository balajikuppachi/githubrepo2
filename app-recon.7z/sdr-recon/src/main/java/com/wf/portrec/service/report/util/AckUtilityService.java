package com.wf.portrec.service.report.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wf.df.da.domain.PortRecAuditLogView;
import com.wf.df.da.domain.PortrecFilesList;
import com.wf.df.da.service.PortrecFilesListHelper;
import com.wf.portrec.service.report.CptyAckScanner;
import com.wf.portrec.service.report.CptyDataHelper;

@Service
@ManagedResource(description="Update customer ACKs and NACKs")
public class AckUtilityService {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@Autowired
	CptyAckScanner cptyAckScanner;
	
	@Autowired
	PortrecFilesListHelper portrecFilesListHelper;
	
	@ManagedOperation(description="Update customer ACKs and NACKs")
	public void updateAckNacks(String yyyy_MM_dd) throws ParseException{
	
		/*List<CptyAcknwledge> cptyAcknwledges = cptyAckScanner.readCptyAckData();
		logger.info("Number of Ack Counter Parties :::: ********************"+ cptyAcknwledges.size());
		for(CptyAcknwledge acknwledge : cptyAcknwledges){
			if(null != acknwledge.getIsAck()){
				cptyDataHelper.updateReportDetailWithAck(acknwledge);
			}
		}*/
		List<PortRecAuditLogView> cptyAcknwledges = cptyAckScanner.readCptyAckData(yyyy_MM_dd);
		logger.info("Number of Ack Counter Parties :::: ********************"+ cptyAcknwledges.size());
		for(PortRecAuditLogView acknwledge : cptyAcknwledges){
			if(null != acknwledge.getAffirmedFlag()){
				cptyDataHelper.updateReportDetailWithAck(acknwledge);
			}
		}
		
	}
	
	
	public void testRun(){
		
		List<PortrecFilesList> portrecFilesLists = portrecFilesListHelper.readPortrecFilesList();
		logger.info("Number of Ack Counter Parties :::: ********************"+ portrecFilesLists.size());
		for(PortrecFilesList acknwledge : portrecFilesLists){
			System.out.println("Party Id : "+ acknwledge.getPortrecFilesListPk().getCptyId());
		}
		
	}
	
	public void testRun2(String yyyy_MM_dd){
		
		List<PortRecAuditLogView> cptyAcknwledges = cptyAckScanner.readCptyAckData(yyyy_MM_dd);
		logger.info("Number of Ack Counter Parties :::: ********************"+ cptyAcknwledges.size());
		for(PortRecAuditLogView acknwledge : cptyAcknwledges){
			System.out.println("Party Id : "+ acknwledge.getUserId());
		}
		
	}
}
