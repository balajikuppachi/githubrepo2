package com.wf.portrec.service.report.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wf.portrec.domain.CptyMasterData;
import com.wf.portrec.domain.ReconCalendar;
import com.wf.portrec.service.report.CptyDataHelper;
import com.wf.portrec.service.report.TriggerAllCptyCsvGenerators;
import com.wf.portrec.service.report.ValuationGenerator;
import com.wf.portrec.service.report.common.OutputFileProperties;

@Service
public class UtilityService {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Value ("${portrec.quarter1.end.date}") String lastDayOfQuarter1;
	@Value ("${portrec.quarter2.end.date}") String lastDayOfQuarter2;
	@Value ("${portrec.quarter3.end.date}") String lastDayOfQuarter3;
	@Value ("${portrec.quarter4.end.date}") String lastDayOfQuarter4;
	@Value ("${portrec.annual.date}") String annualDate;
	
	@Value ("${portrec.recon.date}") String reconDt;
	
	@Autowired
	ValuationGenerator valuationGenerator;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@Autowired
	TriggerAllCptyCsvGenerators triggerAllCptyCsvGenerators;
	
	public void run(){
		
		List<CptyMasterData> cptyMasterDatas = cptyDataHelper.readMasterData();
		logger.info("Number of Counter Parties :::: ********************"+ cptyMasterDatas.size());
		for (CptyMasterData cptyMasterData : cptyMasterDatas) {
			
			//Date reconDate = getReconDateFrom("2014-07-09");
			Date reconDate = getReconDateFrom(reconDt);
			generate(cptyMasterData, reconDate);
		}
	}
	
	
	public boolean generate(CptyMasterData cptyMasterData, Date reconDate){
		boolean valMTFlag = false;
		boolean valFlag = false;
		boolean mtFlag = false;
		OutputFileProperties mtProp = new OutputFileProperties();
		OutputFileProperties valProp = new OutputFileProperties();
		
		try {
			
			//mtProp = triggerAllCptyCsvGenerators.generateAllCptyMTFiles(cptyMasterData.getLei(), cptyMasterData.getLegalId(), reconDate, cptyMasterData.getId()); 
			//mtFlag = mtProp.isFlag();			
			
			Long legalId = Long.valueOf(cptyMasterData.getLegalId());
			
			valProp = valuationGenerator.generateValuationsForCurrentDate(legalId, getLastQuarterDate("ANNUALLY"), "A", 1L);
			valFlag = valProp.isFlag();
			
		} catch (IOException e) {
			logger.error("I/O exception while generating temp valuation file");
			
		} catch (ParseException e) {
			logger.error("Parse exception while generating temp valuation file");
		}
		
		
		if(valFlag || mtFlag)
			valMTFlag = true;
			
		return valMTFlag;
	}
	
	public String getLastQuarterDate(String freq)
	{
		if(freq.equals("QUARTER_1"))
			return lastDayOfQuarter1;
		if(freq.equals("QUARTER_2"))
			return lastDayOfQuarter2;
		if(freq.equals("QUARTER_3"))
			return lastDayOfQuarter3;
		if(freq.equals("QUARTER_4"))
			return lastDayOfQuarter4;
		if(freq.equals("ANNUALLY"))
			return annualDate;
		else
			 return "";
		
	}
	
	private Date getReconDateFrom(String reconDate) {
		
		//yyyy-MM-dd
		DateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;
		try {
			date = dateFormatter.parse(reconDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
			
		return date;
	}

}
