package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.IRTrade;
import com.wf.portrec.domain.TradeFile;

public interface IRTradeRepository extends CrudRepository<IRTrade, Long> {

	@Query("Select ir from IRTrade ir where ir.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, own')")
	public List<IRTrade> findSrcTrades();
	
	@Query("Select ir from IRTrade ir where ir.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'Interest Rate, own')")
	public List<IRTrade> findAllSrcTrades(Date asOfDate);	
	
	@Query("Select ir from IRTrade ir where ir.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC')")
	public List<IRTrade> findDtccTrades();

	@Query("Select um.dtccUsi, ir from IRTrade ir, UsiMapStatic um  where ir.usi=um.dtccUsi and ir.tradeFile = (Select max(tf) " +
	"from TradeFile tf, PortfolioSegment ps where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC')")
	public List<Object[]> fetchDtccUsiMap();

	@Query("Select ir from IRTrade ir where ir.usi not in (select um.dtccUsi from UsiMapSlider um where um.assetClass = 'InterestRate') " + 
	        "and ir.tradeFile = ?")
	public List<IRTrade> fetchIRDtccNonUsiMapSlider(TradeFile trFile);
	
	@Query("select pr from IRTrade pr where pr.id in (select pri.id from IRTrade pri where pri.tradeFile = ? " +
			"group by pri.origTradeId having pri.revisionId = max(pri.revisionId)) " +
			"and pr.tradeFile = ? group by pr.origTradeId having pr.id=max(pr.id)")
	public List<IRTrade> findMaxRevisionTradeByFile(TradeFile fileLeft, TradeFile fileLeft2);
	
	@Query("from IRTrade pr where pr.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC' and tf.loadCompleted is not null) and pr.tradeParty1Lei = ?")
	public List<IRTrade> findDtccTradesByLei(String nextLei);
	
/*	@Query("Select ir from IRTrade ir where ir.tradeParty2=? and ir.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, own')")
	public List<IRTrade> findSrcTradesForCpty(String cpty);
	
	@Query("Select ir from IRTrade ir where ir.tradeParty2=? and ir.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC')")
	public List<IRTrade> findDtccTradesForCpty(String cpty);*/
	
	// To Get result set for Unlinked Population
/*	@Query("Select ir2 from IRTrade ir1, IRTrade ir2 where ir1.tradeFile = ? and ir2.tradeFile = ? and  ir1.usi=ir2.usi")
	public List<IRTrade> findDtccUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);

	@Query("Select ir1 from IRTrade ir1, IRTrade ir2 where ir1.tradeFile = ? and ir2.tradeFile = ? and  ir1.usi=ir2.usi")
	public List<IRTrade> findSrcUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);*/
	
	@Query("Select ir1 from IRTrade ir1, IRTrade ir2 where ir1.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'Interest Rate, own') and ir2.tradeFile = ? and  ir1.usi=ir2.usi")
	public List<IRTrade> findAllSrcUsiMatch(Date asOfDate,TradeFile trDtccFile);
	
	@Query("Select ir2 from IRTrade ir1, IRTrade ir2 where ir1.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'Interest Rate, own')  and ir2.tradeFile = ? and  ir1.usi=ir2.usi")
	public List<IRTrade> findAllDtccUsiMatch(Date asOfDate,TradeFile trDtccFile);
	
	@Query("Select ir from IRTrade ir where ir.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC') and ir.usi not in (Select dtccUsi from UsiMapStatic where assetClass = 'InterestRate' )")
	public List<IRTrade> findUnlinkedDtccTrades();
	
/*	@Query("Select ir from IRTrade ir where ir.tradeFile = ( Select  max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, own') and ir.origTradeId not in (Select srcTradeId from UsiMapStatic where assetClass = 'InterestRate' )")
	public List<IRTrade> findUnlinkedSrcTrades();*/
	
	@Query("Select ir from IRTrade ir where ir.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'Interest Rate, own') and ir.origTradeId not in (Select srcTradeId from UsiMapStatic where assetClass = 'InterestRate' )")
	public List<IRTrade> findAllUnlinkedSrcTrades(Date asOfDate);
	
}
