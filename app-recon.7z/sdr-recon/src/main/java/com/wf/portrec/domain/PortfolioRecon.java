package com.wf.portrec.domain;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "pr_portfolio_recon")
public class PortfolioRecon {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
	
	@Column(name = "as_of_date", nullable = false)
	Date asOfDate;
	
	@Column(name = "recon_started", nullable = false)
	Date reconStarted;
	
	@Column(name = "recon_completed", nullable = true)
	Date reconCompleted;
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="portfolioRecon")
	List<CptyPortfolioRecon> cptyRecons;
	
	public PortfolioRecon() {};
	
	public PortfolioRecon(Date asOfDate) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(asOfDate);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		this.asOfDate = calendar.getTime();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(asOfDate);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		this.asOfDate = calendar.getTime();
	}

	public Date getReconStarted() {
		return reconStarted;
	}

	public void setReconStarted(Date reconStarted) {
		this.reconStarted = reconStarted;
	}

	public Date getReconCompleted() {
		return reconCompleted;
	}

	public void setReconCompleted(Date reconCompleted) {
		this.reconCompleted = reconCompleted;
	}
	
	public List<CptyPortfolioRecon> getCptyRecons() {
		return cptyRecons;
	}

	public void setCptyRecons(List<CptyPortfolioRecon> cptyRecons) {
		this.cptyRecons = cptyRecons;
	}

	@Override
	public String toString() {
		return "PortfolioRecon [id=" + id + ", asOfDate=" + asOfDate
				+ ", reconStarted=" + reconStarted + ", reconCompleted="
				+ reconCompleted + "]";
	}
	
	
	
	
}
