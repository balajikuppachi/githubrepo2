/**
 * 
 */
package com.wf.portrec.service.report;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.da.service.PortrecFilesListHelper;
import com.wf.df.sdr.dao.spring.PortfolioViewExtnDaoImpl;
import com.wf.df.sdr.dto.CountTracker;
import com.wf.portrec.domain.CRTrade;
import com.wf.portrec.domain.CRTradeUnfilterd;
import com.wf.portrec.repository.CRTradeUnfilterdRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

/**
 * @author u293876
 *
 */
@Component
public class CRCptyCsvGenerator {

	
	@Value("${file.portrec.data.extracts}") String outputFolderName;
	@Autowired
	CRTradeUnfilterdRepository crTradeUnfilteredRepo;
	@Autowired
	CrDataCsvWriter crDataCsvWriter;

	@Autowired
	CptyDataHelper cptyDataHelper;

	@Autowired
	PortrecFilesListHelper portrecFilesListHelper;
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	/*-------------------------------------------------------------------------------------------------------------*/
	@Autowired
	PortfolioViewExtnDaoImpl portfolioViewExtnDaoImpl;
	/*
	 * Copy : Global Variable
	 * */
	String legalIdGlobal;
	/*-------------------------------------------------------------------------------------------------------------*/
	
	
	private void generateSrcandDTCCCptyInformation(List<CRTradeUnfilterd> cptyDtccTradeUnfiltered, File targetFileCptyDTCCUnfilterd) {
		Map<String,CRTrade> unfilterdMap=new ConcurrentHashMap<String,CRTrade>();
		for(CRTradeUnfilterd crTradeUnfilterd:cptyDtccTradeUnfiltered){
			try{
			CRTrade trade=new CRTrade();
			BeanUtils.copyProperties(crTradeUnfilterd, trade);
			unfilterdMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
		}
		crDataCsvWriter.generateMatchUSIFile(targetFileCptyDTCCUnfilterd, unfilterdMap,"DTCC");
		
	}
	
	
	public OutputFileProperties createFile(List<String> counterPartyLeiList, String legalId, Date runDate, String period, Long portReconId) throws IOException, ParseException {
		
		boolean crFileFlag = false;
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_CR);
		
		String fileNameForCptyDTCCUnfilterd = "CR_CPTY_DTCC";
		fileNameForCptyDTCCUnfilterd = fileNameForCptyDTCCUnfilterd +"_"+legalId+"_"+ ReportDateUtil.getFileDateExtension(runDate)+ ".csv";
		File targetFileCptyDTCCUnfilterd  = new File(outputFolderName, fileNameForCptyDTCCUnfilterd);
		
		List<CRTradeUnfilterd> entireEptyDtccTradeUnfiltered = null;
		/*-------------------------------------------------------------------------------------------------------------*/
		List<CountTracker> entire1StrTradeUnfiltered = null;
		/*-------------------------------------------------------------------------------------------------------------*/
		
		for(String counterPartyLei : counterPartyLeiList){
			
			List<CRTradeUnfilterd> cptyDtccTradeUnfiltered = null;
			if(null != counterPartyLei){
				cptyDtccTradeUnfiltered = crTradeUnfilteredRepo.findDtccTradesForCptyByDateRevised(runDate,counterPartyLei,counterPartyLei);
			}
			
			if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0) {
				logger.info("Number of cpty CR Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
				crFileFlag = true;
				reportProp.setCount(reportProp.getCount() + cptyDtccTradeUnfiltered.size());
				
				if(!targetFileCptyDTCCUnfilterd.exists()){
					targetFileCptyDTCCUnfilterd.mkdirs();
				}
				
				if(null == entireEptyDtccTradeUnfiltered){
					entireEptyDtccTradeUnfiltered = new ArrayList<CRTradeUnfilterd>();
				}
				entireEptyDtccTradeUnfiltered.addAll(cptyDtccTradeUnfiltered);
				
			}else{
				logger.info("No records found for Cpty CR Dtcc Unfiltered Trade with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
		}
		
		/*-------------------------------------------------------------------------------------------------------------*/
		/*
		 * Copy : Get all the 1STR trades based on LEGAL_ID 
		 */
		legalIdGlobal = legalId;
		entire1StrTradeUnfiltered = portfolioViewExtnDaoImpl.fetch1STRTradeUsi(Long.parseLong(legalId), portReconId, "Credit");
		/*-------------------------------------------------------------------------------------------------------------*/
		
		if(crFileFlag){
			generateSrcandDTCCCptyInformation(entireEptyDtccTradeUnfiltered,targetFileCptyDTCCUnfilterd);
			cptyDataHelper.createReportDetail(legalId, ReportConstants.CR, fileNameForCptyDTCCUnfilterd, outputFolderName, 
					period, new SimpleDateFormat("MM/dd/yyyy").format(runDate), ReportConstants.MATERIAL_TERM, portReconId);
			/*portrecFilesListHelper.createPortrecListEntry(legalId, ReportConstants.CR, fileNameForCptyDTCCUnfilterd, ReportConstants.NFS_FOLDER_PATH, 
					period, new SimpleDateFormat("MM/dd/yyyy").format(runDate), ReportConstants.MATERIAL_TERM, ReportConstants.NOT_REVISED);*/
			logger.info("Report Generation has been Completed for CR at  "+ outputFolderName +" on "+runDate);
		}
		
		reportProp.setFlag(crFileFlag);
		/*-------------------------------------------------------------------------------------------------------------*/
		/* 
		 * Copy : Trigger Logger 
		 */
		triggerMatcherAndLog(entire1StrTradeUnfiltered,entireEptyDtccTradeUnfiltered);
		/*-------------------------------------------------------------------------------------------------------------*/
		return reportProp;
	}

	/*-------------------------------------------------------------------------------------------------------------*/
	/*
	 * Copy : Matcher and logger logic
	 */
	public void triggerMatcherAndLog(List<CountTracker> strTrades, List<CRTradeUnfilterd> mtTrades){
		
		/*
		 * Log 1STR vs MT trade list size. Uncomment if required
		 * */
		logger.info("####Trade_Count_LOG#### | CR | LegalId- "+legalIdGlobal+" | 1STR - "+(null!=strTrades?strTrades.size():0)+" | MT - "+(null!=mtTrades?mtTrades.size():0));
		
		if(null!=strTrades && strTrades.size()>0){
			if(null!=mtTrades && mtTrades.size()>0){
				/*Both 1str and MT has trades, hence compare*/
				matcher(strTrades, mtTrades);
			}
			else {
				/*Log only 1STR break*/
				List<String> strUsiTradesBroken = new ArrayList<String>();
				for(CountTracker ct : strTrades){
					if(null != ct.getUsi())
						strUsiTradesBroken.add(ct.getUsi());
				}
				logMismatches(strUsiTradesBroken,null);
			}
		} else if(null!=mtTrades && mtTrades.size()>0){
			/*Log only MT break*/
			List<String> mtUsiTradesBroken = new ArrayList<String>();
			for(CRTradeUnfilterd cr : mtTrades){
				if(null != cr.getUsi())
					mtUsiTradesBroken.add(cr.getUsi());
			}
			logMismatches(null,mtUsiTradesBroken);
		}
	}
	
	public void matcher(List<CountTracker> strTrades, List<CRTradeUnfilterd> mtTrades){
		
		Map<String,String> mtUsiMap = new ConcurrentHashMap<String, String>();
		List<String> leftStrTrades = new ArrayList<String>();
		List<String> leftMtTrades = new ArrayList<String>();
		
		
		/*Extract distinct USIs from MT*/
		for(CRTradeUnfilterd trade : mtTrades){
			if(null!=trade.getUsi()){
				mtUsiMap.put(trade.getUsi(), "");
			}
		}
		
		for(CountTracker ct : strTrades){
			if(null!=ct.getUsi()){
				if(null!=mtUsiMap.get(ct.getUsi())){
					mtUsiMap.remove(ct.getUsi());
					/*Add count for matched trades*/
					//usiMatchCount++;
				} else {
					leftStrTrades.add(ct.getUsi());
				}
			}
		}
		
		for(String mtUnmatchedUsi : mtUsiMap.keySet()){
			leftMtTrades.add(mtUnmatchedUsi);
		}
		
		logMismatches(leftStrTrades, leftMtTrades);
	}
	
	private void logMismatches(List<String> strTrades, List<String> mtTrades) {
		
		/*
		 * Please change the logger 
		 * as per convenience 
		 * */
		logger.info("####MT_LOG#### | CR | LegalId- "+legalIdGlobal+" | 1STR Mismatches - "+listToString(strTrades)+" | MT Mismatches - "+listToString(mtTrades));
	}
	
	private String listToString(List<String> usiList){
		String usiColonSeperated="";
		if(null!=usiList){
			for(String usi : usiList){
				usiColonSeperated=usiColonSeperated+":"+usi;
			}
		} 
		return usiColonSeperated;
	}

	/*-------------------------------------------------------------------------------------------------------------*/
}
