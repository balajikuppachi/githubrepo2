package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.ValuationEntry;
import com.wf.portrec.repository.custom.ValuationEntryRepositoryCustom;

public interface ValuationEntryRepository extends CrudRepository<ValuationEntry, Long>, ValuationEntryRepositoryCustom {
	
	@Query("select vae from ValuationEntry vae where vae.legalId = ?")
	public List<ValuationEntry> findActiveByCounterparty(Long legalID);
	
	@Query("select vae from ValuationEntry vae where collateralized = 'N' and rundate=?" )
	public Iterable<ValuationEntry> findActiveNonCollateralized(Date date);
	
	public List<ValuationEntry> findByTradeid(String string);

	@Query("select vae from ValuationEntry vae where vae.legalId = ? and pvCobDate = ?")
	public List<ValuationEntry> findActiveByCounterpartyAndCobDate(Long legalId, Date pvCobDate);
}
