package com.wf.portrec.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CptyReportDetailPk implements Serializable{

	@Column(name = "legal_id", nullable = false)
	String legalId = "";
	
	@Column(name = "asset_class", nullable = false)
	String assetClass = "";
	
	@Column(name = "recon_date", nullable = false)
	String reconDate = "";
	
	public String getLegalId() {
		return legalId;
	}

	public void setLegalId(String legalId) {
		this.legalId = legalId;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getReconDate() {
		return reconDate;
	}

	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}

}