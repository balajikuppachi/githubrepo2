package com.wf.portrec.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.Holiday;


public interface PortrectHolidayRepository extends CrudRepository<Holiday, Long> {
	
	@Query("from Holiday where holidayDate=?")
	public Holiday isHolidayDate(Date date);
	
}
