package com.wf.portrec.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.PortfolioRecon;

public interface PortfolioReconRepository extends CrudRepository<PortfolioRecon, Long> {

	@Query("from PortfolioRecon pfr where pfr.id=?")
	PortfolioRecon findForPortfolio(long portfolioRecon);
}
