package com.wf.portrec.service.report.common;

public class ReportConstants {
	public final static String IR_MT = "IR_MT";
	public final static String CR_MT = "CR_MT";
	public final static String FX_MT = "FX_MT";
	public final static String EQ_MT = "EQ_MT";
	public final static String COMM_MT = "COMM_MT";
	
	public final static String IR_VAL = "IR_VAL";
	public final static String CR_VAL = "CR_VAL";
	public final static String FX_VAL = "FX_VAL";
	public final static String EQ_VAL = "EQ_VAL";
	public final static String COMM_VAL = "COMM_VAL";
	
	
	public static final String ASSET_CLASS_IR = "InterestRate";
	public static final String ASSET_CLASS_CR = "Credit";
	public static final String ASSET_CLASS_FX = "ForeignExchange";
	public static final String ASSET_CLASS_EQ = "Equity";
	public static final String ASSET_CLASS_COMM = "Commodity";
	public static final String ASSET_CLASS_ALL = "ALL";
	
	public static final String NFS_FOLDER_PATH = "/nfs/hedgebld/Composite/PortRec/";
	public static final String MATERIAL_TERM = "MT";
	public static final String VALUATION = "VAL";
	public static final String IR = "IR";
	public static final String CR = "CR";
	public static final String FX = "FX";
	public static final String COMM = "COMM";
	public static final String EQ = "EQ";
	public static final String NOT_REVISED = "N";
	public static final String ANNUAL = "A";
	public static final String QUATERLY = "Q";
	
}
