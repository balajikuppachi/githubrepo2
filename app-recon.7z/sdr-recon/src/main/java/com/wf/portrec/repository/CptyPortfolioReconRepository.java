package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.Counterparty;
import com.wf.portrec.domain.CptyPortfolioRecon;

public interface CptyPortfolioReconRepository extends CrudRepository<CptyPortfolioRecon, Long> {
	
	@Query("select max(cpr.reconDate) from CptyPortfolioRecon cpr where cpr.counterparty = ?")
	Date lastReconDate(Counterparty cpty);

	@Query("select cpr from CptyPortfolioRecon cpr where cpr.reconDate = ?")
	List<CptyPortfolioRecon> findForReconDate(Date date);
}
