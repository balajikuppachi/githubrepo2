package com.wf.portrec.message;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.wf.portrec.message.gateway.MTDeliveryRequestSubmitterService;

//@Component
public class MTReportGenerator {

	Logger logger = LoggerFactory.getLogger(getClass());
	
	/*@Autowired
	@Qualifier(value="mtDeliveryRequestSubmitterService")*/
	private MTDeliveryRequestSubmitterService mtDeliveryRequestSubmitterService;
	
	public void submitMaterialTermReport(File targetFile){
		try {
			mtDeliveryRequestSubmitterService.submit(new MTDeliveryRequest(targetFile));
		}
		catch(Exception e){
			logger.error("Error in MT Report submission :"+e.getLocalizedMessage());
		}
	}
	
}