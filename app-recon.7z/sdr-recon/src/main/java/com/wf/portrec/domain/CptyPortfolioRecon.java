package com.wf.portrec.domain;

import java.io.File;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "pr_cpty_portfolio_recon")
public class CptyPortfolioRecon {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
	
	@Column(name = "recon_date", nullable = true)
	Date reconDate;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "counterparty_id", nullable = false)
	Counterparty counterparty;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "portfolio_recon_id", nullable = false)
	PortfolioRecon portfolioRecon;
	
	@Transient
	File valuationReportFile;
	
	@Column(name="frequency")
	@Enumerated(EnumType.STRING)
	FrequencyTypeEnum frequency;
	
	@Column(name="margin_email")
	String marginAnalystEmail;
	
	@Column(name="portfolio_size")
	Long portfolioSize;
	
	public Long getPortfolioSize() {
		return portfolioSize;
	}

	public void setPortfolioSize(Long portfolioSize) {
		this.portfolioSize = portfolioSize;
	}

	public File getValuationReportFile() {
		return valuationReportFile;
	}

	public void setValuationReportFile(File valuationReportFile) {
		this.valuationReportFile = valuationReportFile;
	}

	public FrequencyTypeEnum getFrequency() {
		return frequency;
	}

	public void setFrequency(FrequencyTypeEnum frequency) {
		this.frequency = frequency;
	}

	public String getMarginAnalystEmail() {
		return marginAnalystEmail;
	}

	public void setMarginAnalystEmail(String maginEmailAddress) {
		this.marginAnalystEmail = maginEmailAddress;
	}

	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getReconDate() {
		return reconDate;
	}

	public void setReconDate(Date reconDate) {
		this.reconDate = reconDate;
	}

	public Counterparty getCounterparty() {
		return counterparty;
	}

	public void setCounterparty(Counterparty counterparty) {
		this.counterparty = counterparty;
	}
	
	public PortfolioRecon getPortfolioRecon() {
		return portfolioRecon;
	}

	public void setPortfolioRecon(PortfolioRecon portfolioRecon) {
		this.portfolioRecon = portfolioRecon;
	}

	@Override
	public String toString() {
		return "CptyPortfolioRecon [id=" + id + ", reconDate=" + reconDate
				+ ", counterparty=" + counterparty + ", portfolioRecon="
				+ portfolioRecon + "]";
	}
}
