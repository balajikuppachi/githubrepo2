package com.wf.portrec.service.report;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.da.service.PortrecFilesListHelper;
import com.wf.df.sdr.dao.spring.PortfolioViewExtnDaoImpl;
import com.wf.df.sdr.dto.CountTracker;
import com.wf.portrec.domain.IRTrade;
import com.wf.portrec.domain.IRTradeUnfilterd;
import com.wf.portrec.repository.CounterpartyRepository;
import com.wf.portrec.repository.CptyPortfolioReconRepository;
import com.wf.portrec.repository.IRTradeRepository;
import com.wf.portrec.repository.IRTradeUnfilterdRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

/**
 * @author u250429
 *
 */


@Component
public class IRCptyCsvGenerator {

	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	/*String fileNameForCptySrc = "IR_CPTY_SRC";
	String fileNameForCptyDTCC = "IR_CPTY_DTCC";*/
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	
	@Autowired
	IRTradeRepository irTradeRepo;
	
	@Autowired
	CptyPortfolioReconRepository cptyPortfolioReconRepository;
	
	@Autowired
	CounterpartyRepository counterpartyRepository;
	
	@Autowired
	IRTradeUnfilterdRepository irTradeUnfilteredRepo;
	
	@Autowired
	IrDataCsvWriter irDataCsvWriter;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@Autowired
	PortrecFilesListHelper portrecFilesListHelper;
	
	/*@Autowired
	MTReportGenerator mtReportGenerator;*/
	
	/*-------------------------------------------------------------------------------------------------------------*/
	@Autowired
	PortfolioViewExtnDaoImpl portfolioViewExtnDaoImpl;
	/*
	 * Copy : Global Variable
	 * */
	String legalIdGlobal;
	/*-------------------------------------------------------------------------------------------------------------*/
	
	@PostConstruct
	void init() {
	}

	private void generateSrcandDTCCCptyInformation(List<IRTradeUnfilterd> cptyDtccTradeUnfiltered, File targetFileCptyDTCCUnfilterd) {
		Map<String,IRTrade> unfilterdMap=new ConcurrentHashMap<String,IRTrade>();
		for(IRTradeUnfilterd irTradeUnfilterd:cptyDtccTradeUnfiltered){
			try{
			IRTrade trade=new IRTrade();
			BeanUtils.copyProperties(irTradeUnfilterd, trade);
			unfilterdMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
		}
		irDataCsvWriter.generateMatchUSIFile(targetFileCptyDTCCUnfilterd, unfilterdMap,"DTCC");
	}
	
	public OutputFileProperties createFile(List<String> counterPartyLeiList, String legalId, Date runDate, String period, Long portReconId) {
		
		boolean irFileFlag = false;
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_IR);
		
		String fileNameForCptyDTCCUnfilterd = "IR_CPTY_DTCC";
		fileNameForCptyDTCCUnfilterd = fileNameForCptyDTCCUnfilterd +"_"+legalId+"_"+ ReportDateUtil.getFileDateExtension(runDate)+ ".csv";
		File targetFileCptyDTCCUnfilterd  = new File(outputFolderName, fileNameForCptyDTCCUnfilterd);
		
		List<IRTradeUnfilterd> entireEptyDtccTradeUnfiltered = null;
		/*-------------------------------------------------------------------------------------------------------------*/
		List<CountTracker> entire1StrTradeUnfiltered = null;
		/*-------------------------------------------------------------------------------------------------------------*/
		
		for(String counterPartyLei : counterPartyLeiList){
			
			List<IRTradeUnfilterd> cptyDtccTradeUnfiltered = null;
			List<CountTracker> strTradeUnfiltered = null;
			
			if(null != counterPartyLei){
				cptyDtccTradeUnfiltered = irTradeUnfilteredRepo.findDtccTradesForCptyByDateRevised(runDate,counterPartyLei,counterPartyLei);
			}
			
			if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0) {
				logger.info("Number of cpty IR Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
				irFileFlag = true;
				reportProp.setCount(reportProp.getCount() + cptyDtccTradeUnfiltered.size());
				
				if(!targetFileCptyDTCCUnfilterd.exists()){
					targetFileCptyDTCCUnfilterd.mkdirs();
				}
				
				if(null == entireEptyDtccTradeUnfiltered){
					entireEptyDtccTradeUnfiltered = new ArrayList<IRTradeUnfilterd>();
				}
				entireEptyDtccTradeUnfiltered.addAll(cptyDtccTradeUnfiltered);
				
			}else{
				logger.info("No records found for Cpty IR Dtcc Unfiltered Trade with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
			
		}
		/*-------------------------------------------------------------------------------------------------------------*/
		/*
		 * Copy : Get all the 1STR trades based on LEGAL_ID 
		 */
		legalIdGlobal = legalId;
		entire1StrTradeUnfiltered = portfolioViewExtnDaoImpl.fetch1STRTradeUsi(Long.parseLong(legalId), portReconId, "InterestRate");
		/*-------------------------------------------------------------------------------------------------------------*/
		
		if(irFileFlag){
			generateSrcandDTCCCptyInformation(entireEptyDtccTradeUnfiltered,targetFileCptyDTCCUnfilterd);
			
			cptyDataHelper.createReportDetail(legalId, ReportConstants.IR, fileNameForCptyDTCCUnfilterd, outputFolderName, 
					period, new SimpleDateFormat("MM/dd/yyyy").format(runDate), ReportConstants.MATERIAL_TERM, portReconId);
			/*try {
				submitGeneratedMT(targetFileCptyDTCCUnfilterd);
			}
			catch(Exception ae){
				throw new Exception("Error on sftp remote location " + ReportConstants.NFS_FOLDER_PATH);
			}*/
			/*portrecFilesListHelper.createPortrecListEntry(legalId, ReportConstants.IR, fileNameForCptyDTCCUnfilterd, ReportConstants.NFS_FOLDER_PATH, 
					period, new SimpleDateFormat("MM/dd/yyyy").format(runDate), ReportConstants.MATERIAL_TERM, ReportConstants.NOT_REVISED);*/
			logger.info("Report Generation has been Completed for IR at  "+ outputFolderName +" on "+runDate);	
		}
		reportProp.setFlag(irFileFlag);
		/*-------------------------------------------------------------------------------------------------------------*/
		/* 
		 * Copy : Trigger Logger 
		 */
		triggerMatcherAndLog(entire1StrTradeUnfiltered,entireEptyDtccTradeUnfiltered);
		/*-------------------------------------------------------------------------------------------------------------*/
		return reportProp;
	}

	/*private void submitGeneratedMT(File targetFileCptyDTCCUnfilterd) {
		mtReportGenerator.submitMaterialTermReport(targetFileCptyDTCCUnfilterd);
	}*/
	
	/*-------------------------------------------------------------------------------------------------------------*/
	/*
	 * Copy : Matcher and logger logic
	 */
	public void triggerMatcherAndLog(List<CountTracker> strTrades, List<IRTradeUnfilterd> mtTrades){
		
		/*
		 * Log 1STR vs MT trade list size. Uncomment if required
		 * */
		logger.info("####Trade_Count_LOG#### | IR | LegalId- "+legalIdGlobal+" | 1STR - "+(null!=strTrades?strTrades.size():0)+" | MT - "+(null!=mtTrades?mtTrades.size():0));
		
		if(null!=strTrades && strTrades.size()>0){
			if(null!=mtTrades && mtTrades.size()>0){
				/*Both 1str and MT has trades, hence compare*/
				matcher(strTrades, mtTrades);
			}
			else {
				/*Log only 1STR break*/
				List<String> strUsiTradesBroken = new ArrayList<String>();
				for(CountTracker ct : strTrades){
					if(null != ct.getUsi())
						strUsiTradesBroken.add(ct.getUsi());
				}
				logMismatches(strUsiTradesBroken,null);
			}
		} else if(null!=mtTrades && mtTrades.size()>0){
			/*Log only MT break*/
			List<String> mtUsiTradesBroken = new ArrayList<String>();
			for(IRTradeUnfilterd ir : mtTrades){
				if(null != ir.getUsi())
					mtUsiTradesBroken.add(ir.getUsi());
			}
			logMismatches(null,mtUsiTradesBroken);
		}
	}
	
	public void matcher(List<CountTracker> strTrades, List<IRTradeUnfilterd> mtTrades){
		
		Map<String,String> mtUsiMap = new ConcurrentHashMap<String, String>();
		List<String> leftStrTrades = new ArrayList<String>();
		List<String> leftMtTrades = new ArrayList<String>();
		
		
		/*Extract distinct USIs from MT*/
		for(IRTradeUnfilterd trade : mtTrades){
			if(null!=trade.getUsi()){
				mtUsiMap.put(trade.getUsi(), "");
			}
		}
		
		for(CountTracker ct : strTrades){
			if(null!=ct.getUsi()){
				if(null!=mtUsiMap.get(ct.getUsi())){
					mtUsiMap.remove(ct.getUsi());
					/*Add count for matched trades*/
					//usiMatchCount++;
				} else {
					leftStrTrades.add(ct.getUsi());
				}
			}
		}
		
		for(String mtUnmatchedUsi : mtUsiMap.keySet()){
			leftMtTrades.add(mtUnmatchedUsi);
		}
		
		logMismatches(leftStrTrades, leftMtTrades);
	}
	
	private void logMismatches(List<String> strTrades, List<String> mtTrades) {
		
		/*
		 * Please change the logger 
		 * as per convenience 
		 * */
		logger.info("####MT_LOG#### | IR | LegalId- "+legalIdGlobal+" | 1STR Mismatches - "+listToString(strTrades)+" | MT Mismatches - "+listToString(mtTrades));
	}
	
	private String listToString(List<String> usiList){
		String usiColonSeperated="";
		if(null!=usiList){
			for(String usi : usiList){
				usiColonSeperated=usiColonSeperated+":"+usi;
			}
		} 
		return usiColonSeperated;
	}

	/*-------------------------------------------------------------------------------------------------------------*/

}
