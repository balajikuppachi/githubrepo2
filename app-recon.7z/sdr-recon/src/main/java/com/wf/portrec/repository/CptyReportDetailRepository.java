package com.wf.portrec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.portrec.domain.CptyReportDetail;
import com.wf.portrec.domain.CptyReportDetailPk;

public interface CptyReportDetailRepository extends CrudRepository<CptyReportDetail, CptyReportDetailPk> {

	@Query("Select crd from CptyReportDetail crd where crd.cptyReportDetailPk.legalId = ?")
	List<CptyReportDetail> findByLegalId(Long id);	
	
	@Query("Select crd from CptyReportDetail crd where crd.fileName = ?")
	CptyReportDetail findByFileName(String fileName);
	
	@Modifying
	@Transactional
	@Query("UPDATE CptyReportDetail c SET c.isValid = ?1 WHERE c.cptyReportDetailPk.legalId = ?2 and c.portReconId = ?3 ")
	public void updateValidityByLegalIdPortReconId(String isValid, String legalId, Long portReconId);

	@Query("Select crd from CptyReportDetail crd where crd.portReconId = ? and crd.isValid = 'Y' ")
	List<CptyReportDetail> findValidCptyReportDetailsByPortReconId(Long portReconId);
}
