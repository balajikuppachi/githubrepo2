package com.wf.portrec.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pr_cpty_masterdata")
public class CptyMasterData {


	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	@Column(name = "legal_id")
	String legalId = "";

	@Column(name = "lei")
	String lei = "";
	
	@Column(name = "cpty_name")
	String cptyName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLegalId() {
		return legalId;
	}

	public void setLegalId(String legalId) {
		this.legalId = legalId;
	}

	public String getLei() {
		return lei;
	}

	public void setLei(String lei) {
		this.lei = lei;
	}

	public String getCptyName() {
		return cptyName;
	}

	public void setCptyName(String cptyName) {
		this.cptyName = cptyName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((cptyName == null) ? 0 : cptyName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((legalId == null) ? 0 : legalId.hashCode());
		result = prime * result + ((lei == null) ? 0 : lei.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CptyMasterData other = (CptyMasterData) obj;
		if (cptyName == null) {
			if (other.cptyName != null)
				return false;
		} else if (!cptyName.equals(other.cptyName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (legalId == null) {
			if (other.legalId != null)
				return false;
		} else if (!legalId.equals(other.legalId))
			return false;
		if (lei == null) {
			if (other.lei != null)
				return false;
		} else if (!lei.equals(other.lei))
			return false;
		return true;
	}
	
}