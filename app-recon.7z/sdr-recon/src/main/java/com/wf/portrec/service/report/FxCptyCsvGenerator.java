package com.wf.portrec.service.report;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.da.service.PortrecFilesListHelper;
import com.wf.df.sdr.dao.spring.PortfolioViewExtnDaoImpl;
import com.wf.df.sdr.dto.CountTracker;
import com.wf.portrec.domain.FXTradeUnfiltered;
import com.wf.portrec.domain.FXTrade;
import com.wf.portrec.domain.FXTradeUnfiltered;
import com.wf.portrec.repository.FXTradeUnfilterdRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

@Component
public class FxCptyCsvGenerator {

	@Value("${file.portrec.data.extracts}") String outputFolderName;
	private static final String MAPPING_PROPERTIES = "/mapping.properties";
	private static Properties properties = null;
	Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	FXTradeUnfilterdRepository fxTradeRepo;

	@Autowired
	FxDataCsvWriter fxDataCsvWriter;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@Autowired
	PortrecFilesListHelper portrecFilesListHelper;
	
	/*-------------------------------------------------------------------------------------------------------------*/
	@Autowired
	PortfolioViewExtnDaoImpl portfolioViewExtnDaoImpl;
	/*
	 * Copy : Global Variable
	 * */
	String legalIdGlobal;
	/*-------------------------------------------------------------------------------------------------------------*/
	
	@PostConstruct
	void init() {

	}

	public void createDtccSrcUsiMatchAndExceptionLists(List<FXTradeUnfiltered> cptyDtccTradeUnfiltered, File targetFile) {
		List<FXTrade> unfilterdList=new ArrayList<FXTrade>();
		
		for(FXTradeUnfiltered fxTradeUnfilterd:cptyDtccTradeUnfiltered){
			try{
				FXTrade trade = new FXTrade();
				BeanUtils.copyProperties(fxTradeUnfilterd, trade);
				unfilterdList.add(trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
		}
		fxDataCsvWriter.generateCsvFile(properties, targetFile, unfilterdList, "DTCC");
	}
	
	public OutputFileProperties createFile(List<String> counterPartyLeiList, String legalId, Date runDate, String period, Long portReconId) throws IOException, ParseException {
		
		boolean fxFileFlag = false; 
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_FX);
		
		String fileNameForCptyDTCCUnfilterd = "FX_CPTY_DTCC";
		String fileNameSrcUSIMatch = fileNameForCptyDTCCUnfilterd +"_"+legalId+"_"+ ReportDateUtil.getFileDateExtension(runDate)+ ".csv";
		File targetFileSrcUsiMatch = new File(outputFolderName, fileNameSrcUSIMatch);
		
		List<FXTradeUnfiltered> entireEptyDtccTradeUnfiltered = null;
		/*-------------------------------------------------------------------------------------------------------------*/
		List<CountTracker> entire1StrTradeUnfiltered = null;
		/*-------------------------------------------------------------------------------------------------------------*/
		
		for(String counterPartyLei : counterPartyLeiList){
			List<FXTradeUnfiltered> cptyDtccTradeUnfiltered = null;
			
			if(null != counterPartyLei){
				cptyDtccTradeUnfiltered = fxTradeRepo.findDtccTradesForCptyByDateRevised(runDate,counterPartyLei,counterPartyLei, runDate);
			}
			
			if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0) {
				logger.info("Number of cpty FX Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
				fxFileFlag = true;
				reportProp.setCount(reportProp.getCount() + cptyDtccTradeUnfiltered.size());
				
				if(!targetFileSrcUsiMatch.exists()){
					targetFileSrcUsiMatch.mkdirs();
				}
				
				if(null == entireEptyDtccTradeUnfiltered){
					entireEptyDtccTradeUnfiltered = new ArrayList<FXTradeUnfiltered>();
				}
				entireEptyDtccTradeUnfiltered.addAll(cptyDtccTradeUnfiltered);
				
			}else{
				logger.info("No records found for Cpty FX Dtcc Unfiltered Trade with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
		}
		
		/*-------------------------------------------------------------------------------------------------------------*/
		/*
		 * Copy : Get all the 1STR trades based on LEGAL_ID 
		 */
		legalIdGlobal = legalId;
		entire1StrTradeUnfiltered = portfolioViewExtnDaoImpl.fetch1STRTradeUsi(Long.parseLong(legalId), portReconId, "ForeignExchange");
		/*-------------------------------------------------------------------------------------------------------------*/
		
		if(fxFileFlag){
			createDtccSrcUsiMatchAndExceptionLists(entireEptyDtccTradeUnfiltered,targetFileSrcUsiMatch);
			cptyDataHelper.createReportDetail(legalId, ReportConstants.FX, fileNameSrcUSIMatch, outputFolderName, 
					period, new SimpleDateFormat("MM/dd/yyyy").format(runDate), ReportConstants.MATERIAL_TERM, portReconId);
			/*portrecFilesListHelper.createPortrecListEntry(legalId, ReportConstants.FX, fileNameSrcUSIMatch, ReportConstants.NFS_FOLDER_PATH, 
					period, new SimpleDateFormat("MM/dd/yyyy").format(runDate), ReportConstants.MATERIAL_TERM, ReportConstants.NOT_REVISED);*/
			logger.info("Report Generation has been Completed for FX at  "+ outputFolderName +" on "+runDate);
		}
		
		reportProp.setFlag(fxFileFlag);
		/*-------------------------------------------------------------------------------------------------------------*/
		/* 
		 * Copy : Trigger Logger 
		 */
		triggerMatcherAndLog(entire1StrTradeUnfiltered,entireEptyDtccTradeUnfiltered);
		/*-------------------------------------------------------------------------------------------------------------*/
		return reportProp;
	}

	public String getFileDateExtension(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(date);
	}

	private void loadProperties() {
		logger.info("Loading mapping properties file for Fx Constants.");
		try {
		InputStream inputStream = FxDataCsvWriter.class.getResourceAsStream(MAPPING_PROPERTIES);
		if (inputStream == null) {
			logger.info("Property file '" + MAPPING_PROPERTIES + "' not found in the classpath");
		}
		properties = new Properties();
			properties.load(inputStream);
		} catch (IOException e) {
			logger.info("Failed to load mapping.properties for Fx Constants");
		}
	}

	/*-------------------------------------------------------------------------------------------------------------*/
	/*
	 * Copy : Matcher and logger logic
	 */
	public void triggerMatcherAndLog(List<CountTracker> strTrades, List<FXTradeUnfiltered> mtTrades){
		
		/*
		 * Log 1STR vs MT trade list size. Uncomment if required
		 * */
		logger.info("####Trade_Count_LOG#### | FX | LegalId- "+legalIdGlobal+" | 1STR - "+(null!=strTrades?strTrades.size():0)+" | MT - "+(null!=mtTrades?mtTrades.size():0));
		
		if(null!=strTrades && strTrades.size()>0){
			if(null!=mtTrades && mtTrades.size()>0){
				/*Both 1str and MT has trades, hence compare*/
				matcher(strTrades, mtTrades);
			}
			else {
				/*Log only 1STR break*/
				List<String> strUsiTradesBroken = new ArrayList<String>();
				for(CountTracker ct : strTrades){
					if(null != ct.getUsi())
						strUsiTradesBroken.add(ct.getUsi());
				}
				logMismatches(strUsiTradesBroken,null);
			}
		} else if(null!=mtTrades && mtTrades.size()>0){
			/*Log only MT break*/
			List<String> mtUsiTradesBroken = new ArrayList<String>();
			for(FXTradeUnfiltered fx : mtTrades){
				if(null != fx.getUsiValue())
					mtUsiTradesBroken.add(fx.getUsiValue());
			}
			logMismatches(null,mtUsiTradesBroken);
		}
	}
	
	public void matcher(List<CountTracker> strTrades, List<FXTradeUnfiltered> mtTrades){
		
		Map<String,String> mtUsiMap = new ConcurrentHashMap<String, String>();
		List<String> leftStrTrades = new ArrayList<String>();
		List<String> leftMtTrades = new ArrayList<String>();
		
		
		/*Extract distinct USIs from MT*/
		for(FXTradeUnfiltered trade : mtTrades){
			if(null!=trade.getUsiValue()){
				mtUsiMap.put(trade.getUsiValue(), "");
			}
		}
		
		for(CountTracker ct : strTrades){
			if(null!=ct.getUsi()){
				if(null!=mtUsiMap.get(ct.getUsi())){
					mtUsiMap.remove(ct.getUsi());
					/*Add count for matched trades*/
					//usiMatchCount++;
				} else {
					leftStrTrades.add(ct.getUsi());
				}
			}
		}
		
		for(String mtUnmatchedUsi : mtUsiMap.keySet()){
			leftMtTrades.add(mtUnmatchedUsi);
		}
		
		logMismatches(leftStrTrades, leftMtTrades);
	}
	
	private void logMismatches(List<String> strTrades, List<String> mtTrades) {
		
		/*
		 * Please change the logger 
		 * as per convenience 
		 * */
		logger.info("####MT_LOG#### | FX | LegalId- "+legalIdGlobal+" | 1STR Mismatches - "+listToString(strTrades)+" | MT Mismatches - "+listToString(mtTrades));
	}
	
	private String listToString(List<String> usiList){
		String usiColonSeperated="";
		if(null!=usiList){
			for(String usi : usiList){
				usiColonSeperated=usiColonSeperated+":"+usi;
			}
		} 
		return usiColonSeperated;
	}

	/*-------------------------------------------------------------------------------------------------------------*/
	
}