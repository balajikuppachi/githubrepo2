package com.wf.portrec.service.report;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.FXTrade;
import com.wf.portrec.repository.FXTradeRepository;

@Component
public class FxDataCsvWriter {
	@Value("${file.portrec.data.fx}") String outputFolderName;
	String fileName = "FX_GTR_";
	@Value("${mask.counterparty.details}") String counterPartyValue;
	@Value("${wf.affiliatebank.leis}") String wfLeiList;
	Logger logger = LoggerFactory.getLogger(getClass());
	int SNAPSHOT_HEADER_ROW_NUM = 10;
	static char SEPARATOR = ',';

	@Autowired
	FXTradeRepository fxTradeRepository;

	public void generateCsvFile(Properties properties, File targetFile, List<FXTrade> finalDTCCView, String fileType) {
		try {
			logger.info("Inside Generate CSV File");
			targetFile.mkdirs();
			logger.info("\nGenerated DTCC FX View name and path : " + targetFile.toString());
			if (targetFile.exists()) {
				targetFile.delete();
			}
			FileWriter writer = new FileWriter(targetFile);
			writer.append("USI");
			writer.append(SEPARATOR);
			writer.append("Pary1Lei");
			writer.append(SEPARATOR);
			writer.append("Party1SD");
			writer.append(SEPARATOR);
			writer.append("Party1MSP");
			writer.append(SEPARATOR);
			writer.append("Party1FN");
			writer.append(SEPARATOR);
			writer.append("Party1USPerson");
			writer.append(SEPARATOR);
			writer.append("Party2Lei");
			writer.append(SEPARATOR);
			writer.append("Party2InternalId");
			writer.append(SEPARATOR);
			writer.append("Party2SD");
			writer.append(SEPARATOR);
			writer.append("Party2MSP");
			writer.append(SEPARATOR);
			writer.append("Party2FN");
			writer.append(SEPARATOR);
			writer.append("Party2USPerson");
			writer.append(SEPARATOR);
			writer.append("UPI");
			writer.append(SEPARATOR);
			writer.append("CFTCProductId");
			writer.append(SEPARATOR);
			writer.append("IntProductId");
			writer.append(SEPARATOR);
			writer.append("MultiAssetSwap");
			writer.append(SEPARATOR);
			writer.append("PriAssetClass");
			writer.append(SEPARATOR);
			writer.append("SecAssetClass");
			writer.append(SEPARATOR);
			writer.append("MixedSwap");
			writer.append(SEPARATOR);
			writer.append("SDR2Id");
			writer.append(SEPARATOR);
			writer.append("ContractType");
			writer.append(SEPARATOR);
			writer.append("ExecVenue");
			writer.append(SEPARATOR);
			writer.append("CCY1");
			writer.append(SEPARATOR);
			writer.append("CCY2");
			writer.append(SEPARATOR);
			writer.append("NotionalAmt1");
			writer.append(SEPARATOR);
			writer.append("NotionalAmt2");
			writer.append(SEPARATOR);
			writer.append("ExchangeRate");
			writer.append(SEPARATOR);
			writer.append("DeliveryType");
			writer.append(SEPARATOR);
			writer.append("SettlementExpDt");
			writer.append(SEPARATOR);
			writer.append("Collaterized");
			writer.append(SEPARATOR);
			writer.append("TradeId");
			writer.append('\n');			
			
			for (FXTrade dtccViewDomain : finalDTCCView) {
				writer.append(null != dtccViewDomain.getUsiValue() ? dtccViewDomain.getUsiValue() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getTradeParty1() ? maskCounterPartyDetails(dtccViewDomain.getTradeParty1()) : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty1Sd() ? dtccViewDomain.getIsParty1Sd() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty1Msp() ? dtccViewDomain.getIsParty1Msp() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty1Fin() ? dtccViewDomain.getIsParty1Fin() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty1USPerson() ? dtccViewDomain.getIsParty1USPerson() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getTradeParty2() ? maskCounterPartyDetails(dtccViewDomain.getTradeParty2()) : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getParty2InternalId() ? dtccViewDomain.getParty2InternalId() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty2Sd() ? dtccViewDomain.getIsParty2Sd() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty2Msp() ? dtccViewDomain.getIsParty2Msp() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty2Fin() ? dtccViewDomain.getIsParty2Fin() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsParty2USPerson() ? dtccViewDomain.getIsParty2USPerson() : "");
					writer.append(SEPARATOR);
					
					if(StringUtils.isNotBlank(dtccViewDomain.getProductIdValue())){
						String productId = dtccViewDomain.getProductIdValue();
						//productId = properties.getProperty(productId.trim());
						if(StringUtils.isNotBlank(productId))
							writer.append(productId);
						else
							writer.append(dtccViewDomain.getProductIdValue());
					}
					else{
						writer.append("");
					}
					
					writer.append(SEPARATOR);
					writer.append(dtccViewDomain.getCftcProductId());
					writer.append(SEPARATOR);

					if(StringUtils.isNotBlank(dtccViewDomain.getSdrInternalProductId())){
						String productId = dtccViewDomain.getSdrInternalProductId();
						//productId = properties.getProperty(productId.trim());
						if(StringUtils.isNotBlank(productId))
							writer.append(productId);
						else
							writer.append(dtccViewDomain.getSdrInternalProductId());
					}
					else{
						writer.append("");
					}
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsMultiassetSwap() ? dtccViewDomain.getIsMultiassetSwap() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getPrimaryAssetClass() ? dtccViewDomain.getPrimaryAssetClass() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getSecondaryAssetClass() ? dtccViewDomain.getSecondaryAssetClass() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getIsMixedSwap() ? dtccViewDomain.getIsMixedSwap() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getAdditionalRepository1Prefix() ? dtccViewDomain.getAdditionalRepository1Prefix() : "");
					writer.append(SEPARATOR);
					/*String productId = "";
					if(StringUtils.isNotBlank(dtccViewDomain.getContractType())){
						productId = dtccViewDomain.getContractType();
						if(StringUtils.isNotBlank(productId))
							productId = properties.getProperty(productId);
						else 
							productId = dtccViewDomain.getContractType();
					}*/
					writer.append(dtccViewDomain.getContractType());
					/*if(StringUtils.isNotBlank(dtccViewDomain.getContractType())){
						String productId = dtccViewDomain.getContractType();
						productId = properties.getProperty(productId.trim());
						if(StringUtils.isNotBlank(productId))
							writer.append(productId);
						else
							writer.append(dtccViewDomain.getContractType().trim());
					}
					else{
						writer.append("");
					}*/
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getExecutionVenue() ? dtccViewDomain.getExecutionVenue() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getNotionalCurrency1() ? dtccViewDomain.getNotionalCurrency1() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getNotionalCurrency2() ? dtccViewDomain.getNotionalCurrency2() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getNotionalAmount1() ? dtccViewDomain.getNotionalAmount1().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getNotionalAmount2() ? dtccViewDomain.getNotionalAmount2().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getExchangeRate() ? dtccViewDomain.getExchangeRate().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getDeliveryType() ? dtccViewDomain.getDeliveryType() : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getSettlementExpirationDate() ? ReportDateUtil.getStrDate(dtccViewDomain.getSettlementExpirationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != dtccViewDomain.getCollateralized() ? dtccViewDomain.getCollateralized() : "");
					writer.append(SEPARATOR);
					writer.append("");// TradeId Field is Empty.
					writer.append('\n');
			}
			writer.flush();
			writer.close();
			logger.info("FX View has been Generated");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String maskCounterPartyDetails(String leiValue){
		String cpVal = "";
		if(null!=leiValue){
			if(StringUtils.contains(wfLeiList, leiValue)){
				cpVal = leiValue;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}	
}