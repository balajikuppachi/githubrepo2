package com.wf.portrec.domain;

public enum FrequencyTypeEnum {

	DAILY("DAILY"), WEEKLY("WEEKLY"), QUARTERLY("QUARTERLY"), ANNUALLY("ANNUALLY");

	final String frequencyType;

	private FrequencyTypeEnum(String frequencyType) {
		this.frequencyType = frequencyType;
	}

	public String getFrequencyType() {
		return frequencyType;
	}

	public static FrequencyTypeEnum getFrequencyType(String frequencyType) {
		for (FrequencyTypeEnum value : FrequencyTypeEnum.values()) {
			if (value.getFrequencyType() == frequencyType) {
				return value;
			}
		}

		throw new IllegalArgumentException("Unknown Frequency Type :"
				+ frequencyType);
	}
}
