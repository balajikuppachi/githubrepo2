package com.wf.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;



@Entity
@Table(name = "pr_cpty_report_detail")
public class CptyReportDetail {

	@EmbeddedId
	private CptyReportDetailPk cptyReportDetailPk;
	
	/*@Column(name = "legal_id")
	String legalId = "";*/
	
	/*@Column(name = "asset_class")
	String assetClass = "";*/
	
	//@Id
	@Column(name = "file_name")
	String fileName = "";
	
	@Column(name = "dir_path")
	String dirPath = "";
	
	@Column(name = "period")
	String period = "";
	
	/*@Column(name = "recon_date")
	String reconDate = "";*/
	
	@Column(name = "file_tag")
	String fileTag = "";

	@Column(name = "is_ack")
	String isAck = "";
	
	@Column(name = "is_valid", updatable = true)
	String isValid = "";
	
	@Column(name = "portfolio_recon_id")
	Long portReconId;
	
	@Column(name = "created_date")
	Date createdDate;
	
	@Column(name = "affirm_update_date_time")
	Date affirmUpdateDateTime;
	
	@Column(name = "user_comment")
	String userComment;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/*public String getLegalId() {
		return legalId;
	}

	public void setLegalId(String legalId) {
		this.legalId = legalId;
	}*/

	public String getIsAck() {
		return isAck;
	}

	public void setIsAck(String isAck) {
		this.isAck = isAck;
	}

	/*public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}*/

	public String getDirPath() {
		return dirPath;
	}

	public void setDirPath(String dirPath) {
		this.dirPath = dirPath;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	/*public String getReconDate() {
		return reconDate;
	}

	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}*/

	public String getFileTag() {
		return fileTag;
	}

	public void setFileTag(String fileTag) {
		this.fileTag = fileTag;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public Long getPortReconId() {
		return portReconId;
	}

	public void setPortReconId(Long portReconId) {
		this.portReconId = portReconId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public CptyReportDetailPk getCptyReportDetailPk() {
		return cptyReportDetailPk;
	}

	public void setCptyReportDetailPk(CptyReportDetailPk cptyReportDetailPk) {
		this.cptyReportDetailPk = cptyReportDetailPk;
	}

	public Date getAffirmUpdateDateTime() {
		return affirmUpdateDateTime;
	}

	public void setAffirmUpdateDateTime(Date affirmUpdateDateTime) {
		this.affirmUpdateDateTime = affirmUpdateDateTime;
	}

	public String getUserComment() {
		return userComment;
	}

	public void setUserComment(String userComment) {
		this.userComment = userComment;
	}

	

}