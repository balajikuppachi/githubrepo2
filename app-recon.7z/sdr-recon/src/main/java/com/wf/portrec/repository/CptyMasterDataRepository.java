package com.wf.portrec.repository;

import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.CptyMasterData;

public interface CptyMasterDataRepository extends CrudRepository<CptyMasterData, Long> {

	
}
