package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.CptyPortfolioReconView;

public interface MailerCptyPortfolioReconRepositoryFromView extends CrudRepository<CptyPortfolioReconView, Long> {
	
	/*@Query("select max(cpr.reconDate) from MailerCptyPortfolioRecon cpr where cpr.counterparty = ?")
	Date lastReconDate(Counterparty cpty);*/

	@Query("select cpr from CptyPortfolioReconView cpr where cpr.reconDate = ?")
	List<CptyPortfolioReconView> findForReconDate(Date date);
	
	/*@Query("select cpr from CptyPortfolioReconView cpr where cpr.frequency='QUARTERLY'")
	List<CptyPortfolioReconView> findForReconDateQuarterly();
	
	@Query("select cpr from CptyPortfolioReconView cpr where cpr.reconDate = ? and cpr.frequency='ANNUALLY'")
	List<CptyPortfolioReconView> findForReconDateAnnually(Date date);
	
	@Query("select cpr from CptyPortfolioReconView cpr where cpr.reconDate = ? and cpr.frequency='WEEKLY'")
	List<CptyPortfolioReconView> findForReconDateWeekly(Date date);
	
	@Query("select cpr from CptyPortfolioReconView cpr where cpr.reconDate = ? and cpr.frequency='DAILY'")
	List<CptyPortfolioReconView> findForReconDateDaily(Date date);*/
	
}
