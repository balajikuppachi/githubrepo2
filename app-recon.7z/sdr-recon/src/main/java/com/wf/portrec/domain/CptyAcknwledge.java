package com.wf.portrec.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pr_cpty_ack")
public class CptyAcknwledge {

	@Id
	@Column(name = "ack_id")
	Long ackId;

	@Column(name = "file_name")
	String fileName = "";
	
	@Column(name = "is_ack")
	String isAck = "";
	
	public Long getAckId() {
		return ackId;
	}

	public void setAckId(Long ackId) {
		this.ackId = ackId;
	}

	public String getIsAck() {
		return isAck;
	}

	public void setIsAck(String isAck) {
		this.isAck = isAck;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	
}