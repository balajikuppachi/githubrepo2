package com.wf.portrec.domain;

public enum BoolEnum {
	Y, N
}
