package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.CRTrade;
import com.wf.portrec.domain.TradeFile;

public interface CRTradeRepository extends CrudRepository<CRTrade, Long> {
	
	@Query("select pcr from CRTrade pcr where pcr.tradeFile = " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Credit, own' and ptfi.loadCompleted is not null)")
	public List<CRTrade> findSrcTrades();
	
	@Query("select pcr from CRTrade pcr where pcr.tradeFile in " +
			"(select ptfi from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ptfi.asOfDate = ? and ppsi.name='Credit, own' and ptfi.loadCompleted is not null)")
	public List<CRTrade> findAllSrcTrades(Date asOfDate);
	
	@Query("Select cr from CRTrade cr where cr.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Credit, DTCC')")
	public List<CRTrade> findDtccTrades();
	
	@Query("select t from CRTrade as t where t.tradeFile=?")
	public List<CRTrade> findByFile(TradeFile tradeFile);
	
	@Query("Select um.srcTradeId, cr from CRTrade cr, UsiMapStatic um where " +
	"cr.usi = um.dtccUsi and um.assetClass = 'Credit'" + 
	"and cr.tradeFile =  " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Credit, DTCC' and ptfi.loadCompleted is not null)")
	public List<Object[]> fetchDtccUsiMap();
	
	@Query("Select cr from CRTrade cr where cr.usi not in (select um.dtccUsi from UsiMapSlider um where um.assetClass = 'Credit') " + 
			"and cr.tradeFile = ?")
	public List<CRTrade> fetchCRDtccNonUsiMapSlider(TradeFile tradeFile);

	@Query("select pr from CRTrade pr where pr.id in (select pri.id from CRTrade pri where pri.tradeFile = ? " +
			"group by pri.origTradeId having pri.revisionId = max(pri.revisionId)) " +
			"and pr.tradeFile = ? group by pr.origTradeId having pr.id=max(pr.id)")
	public List<CRTrade> findMaxRevisionTradeByFile(TradeFile fileLeft, TradeFile fileLeft2);
	
	// To Get result set for Unlinked Population
/*	@Query("Select cr2 from CRTrade cr1, CRTrade cr2 where cr1.tradeFile = ? and cr2.tradeFile = ? and  cr1.usi=cr2.usi")
	public List<CRTrade> findDtccUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);

	@Query("Select cr1 from CRTrade cr1, CRTrade cr2 where cr1.tradeFile = ? and cr2.tradeFile = ? and  cr1.usi=cr2.usi")
	public List<CRTrade> findSrcUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);*/
	
	@Query("Select cr2 from CRTrade cr1, CRTrade cr2 where cr1.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'Credit, own')  and cr2.tradeFile = ? and  cr1.usi=cr2.usi")
	public List<CRTrade> findAllDtccUsiMatch(Date asOfDate,TradeFile trDtccFile);

	@Query("Select cr1 from CRTrade cr1, CRTrade cr2 where cr1.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'Credit, own')  and cr2.tradeFile = ? and  cr1.usi=cr2.usi")
	public List<CRTrade> findAllSrcUsiMatch(Date asOfDate,TradeFile trDtccFile);
	
	
	@Query("Select cr from CRTrade cr where cr.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'Credit, DTCC') and cr.usi not in (Select dtccUsi from UsiMapStatic where assetClass = 'Credit' )")
	public List<CRTrade> findUnlinkedDtccTrades();
	
/*	@Query("Select cr from CRTrade cr where cr.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'Credit, own') and cr.origTradeId not in (Select srcTradeId from UsiMapStatic where assetClass = 'Credit' )")
	public List<CRTrade> findUnlinkedSrcTrades();*/
	
	@Query("Select cr from CRTrade cr where cr.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'Credit, own') and cr.origTradeId not in (Select srcTradeId from UsiMapStatic where assetClass = 'Credit' )")
	public List<CRTrade> findAllUnlinkedSrcTrades(Date asOfDate);
}
