package com.wf.portrec.message.gateway;

import com.wf.portrec.message.MTDeliveryRequest;

public interface MTDeliveryRequestSubmitterService {
	public void submit(MTDeliveryRequest repDelivReq);
}
