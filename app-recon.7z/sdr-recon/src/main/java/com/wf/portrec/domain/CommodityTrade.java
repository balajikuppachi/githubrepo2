package com.wf.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.wf.portrec.domain.annotation.UseForMatching;

/**
 * @author u250429
 * @version 1.0
 * 
 *          CommodityTrade Class, which has common params for both DTCC and SRC
 *          Credit Files.
 * 
 * 
 */

@Entity
@Table(name = "pr_commodity")
public class CommodityTrade extends Trade {


	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	@UseForMatching
	@Column(name = "usi_value")
	String usiValue = "";

	@UseForMatching
	@Column(name = "usi_namespace")
	String usiNamespace = "";

	@UseForMatching
	@Column(name = "product_type")
	String productType = "";

	@UseForMatching
	@Column(name = "report_date")
	Date reportDate;

	@UseForMatching
	@Column(name = "last_update")
	Date updateDateTime;

	@UseForMatching
	@Column(name = "trade_party1_name")
	String tradeParty1Name = "";

	@UseForMatching
	@Column(name = "trade_party1_reference_number")
	String tradeParty1ReferenceNumber = "";

	@UseForMatching
	@Column(name = "trade_party2")
	String tradeParty2 = "";

	@UseForMatching
	@Column(name = "trade_party2_name")
	String tradeParty2Name = "";

	@UseForMatching
	@Column(name = "buyer")
	String buyer = "";

	@UseForMatching
	@Column(name = "seller")
	String seller = "";

	@Column(name = "asset_class")
	String assetClass = "";

	@Column(name = "trade_date")
	Date tradeDate;

	@Column(name = "maturity_date")
	Date maturityDate;

	@Column(name = "verification_status")
	String verificationStatus = "";

	@Column(name = "trade_party1")
	String tradeParty1 = "";

	@Column(name = "notional_amount_party")
	BigDecimal notionalAmountParty;

	@Column(name = "notional_currency_party")
	String notionalCurrencyParty = "";

	@Column(name = "notional_amount_cpty")
	BigDecimal notionalAmountCpty;

	@Column(name = "notional_currency_cpty")
	String notionalCurrencyCpty = "";

	@Column(name = "src_trade_id")
	String srcTradeId = "";

	@Column(name = "reporting_party")
	String reportingParty = "";

	@Column(name = "book")
	String book = "";
	
	@Column(name="run_date")
	Date runDate;
	
	@Column(name = "buyer_lei")
	String buyerLei = "";

	@Column(name = "seller_lei")
	String sellerLei = "";
	
	@Column(name = "buyer_us_reg_desg")
	String buyerUsLeiDesg = "";
	
	@Column(name = "seller_us_reg_desg")
	String sellerUsLeiDesg = "";
	
	@Column(name = "buyer_fin_ent")
	String buyerFinEnt = "";
	
	@Column(name = "seller_fin_ent")
	String sellerFinEnt = "";
	
	@Column(name = "buyer_us_ent")
	String buyerUSEnt = "";
	
	@Column(name = "seller_us_ent")
	String sellerUSEnt = "";
	
	@Column(name = "tv_prod_id")
	String tvProdId = "";
	
	@Column(name = "mult_asset_class_swap")
	String multiAssetClassSwap = "";
	
	@Column(name = "mac_pri_asset_class")
	String macPriAssetClass = "";
	
	@Column(name = "mac_sec_asset_class")
	String macSecAssetClass = "";
	
	@Column(name = "mixed_swap")
	String mixedSwap = "";
	
	@Column(name = "mixed_swap_report_sdr")
	String mixedSwapOtherReportedSDR = "";
	
	@Column(name = "contract_type")
	String contractType = "";
	
	@Column(name="execution_venue")
	String executionVenue = "";	
	
	@Column(name = "start_date")
	Date startDate;
	
	@Column(name = "end_date")
	Date endDate;
	
	@Column(name="qantity_unit")
	String quantityUnit = "";	
	
	@Column(name="qantity")
	String quantity = "";	
	
	@Column(name="qantity_freq")
	String quantityFreq = "";
	
	@Column(name="total_freq")
	String totalQuantity = "";
	
	@Column(name="settlement_method")
	String settlementMethod = "";
	
	@Column(name="price")
	String price = "";
	
	@Column(name="price_unit")
	String priceUnit = "";
	
	@Column(name="price_curr")
	String priceCurrency = "";
	
	@Column(name="buyer_pay_index")
	String buyerPayIndex = "";
	
	@Column(name="buyer_payindex_avg_method")
	String buyerPayIndexAveragingMethod = "";
	
	@Column(name="seller_pay_index")
	String sellerPayIndex = "";
	
	@Column(name="seller_payindex_avg_method")
	String sellerPayIndexAveragingMethod = "";
	
	@Column(name="grade")
	String grade = "";
	
	@Column(name="option_type")
	String optionType = "";

	@Column(name="option_style")
	String optionStyle = "";
	
	@Column(name="option_premium")
	String optionPremium = "";
	
	@Column(name="hr_from_thr")
	String hrsFromThr = "";
	
	@Column(name="hr_from_thr_timezone")
	String hrsFromThrTimeZone = "";
	
	@Column(name="days_of_week")
	String daysOfWeek = "";
	
	@Column(name="load_type")
	String loadType = "";
	
	@Column(name="collaterlized")
	String collaterlized = "";
	
	@Column(name = "exec_date")
	Date execDate;
	
	@Column(name = "report_prty_lei")
	String reportPrtyLei;
	
	@Column(name = "report_sd")
	String reportSd;
	
	@Column(name = "report_msp")
	String reportMsp;
	
	@Column(name = "report_fin")
	String reportFin;
	
	@Column(name = "report_us")
	String reportUs;
	
	@Column(name = "non_report_lei")
	String nonReportLei;
	
	@Column(name = "non_report_id")
	String nonReportId;
	
	@Column(name = "non_rept_sd")
	String nonReptSd;
	
	@Column(name = "non_rep_msp")
	String nonRepMsp;
	
	@Column(name = "non_rep_fin")
	String nonRepFin;
		
	@Column(name = "non_rep_us")
	String nonRepUs;
		
	@Column(name = "product_id")
	String productId;
	
	@Column(name = "cftc_product_id")
	String cftcProductId;
	
	@Column(name = "int_product_id")
	String intProductId;
	
	@Column(name = "submitted_onbehalf_party_id_value")
	String SubmittedonBehalfofPtyIDValue;
	
	@Column(name = "reporting_entity_pet_data")
	String reportingEntityPETData;
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCftcProductId() {
		return cftcProductId;
	}

	public void setCftcProductId(String cftcProductId) {
		this.cftcProductId = cftcProductId;
	}

	public String getIntProductId() {
		return intProductId;
	}

	public void setIntProductId(String intProductId) {
		this.intProductId = intProductId;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the usiValue
	 */
	public String getUsiValue() {
		return usiValue;
	}

	/**
	 * @param usiValue
	 *            the usiValue to set
	 */
	public void setUsiValue(String usiValue) {
		this.usiValue = usiValue;
	}

	/**
	 * @return the usiNamespace
	 */
	public String getUsiNamespace() {
		return usiNamespace;
	}

	/**
	 * @param usiNamespace
	 *            the usiNamespace to set
	 */
	public void setUsiNamespace(String usiNamespace) {
		this.usiNamespace = usiNamespace;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType
	 *            the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the reportDate
	 */
	public Date getReportDate() {
		return reportDate;
	}

	/**
	 * @param reportDate
	 *            the reportDate to set
	 */
	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	/**
	 * @return the updateDateTime
	 */
	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	/**
	 * @param updateDateTime
	 *            the updateDateTime to set
	 */
	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	/**
	 * @return the tradeParty1Name
	 */
	public String getTradeParty1Name() {
		return tradeParty1Name;
	}

	/**
	 * @param tradeParty1Name
	 *            the tradeParty1Name to set
	 */
	public void setTradeParty1Name(String tradeParty1Name) {
		this.tradeParty1Name = tradeParty1Name;
	}

	/**
	 * @return the tradeParty1ReferenceNumber
	 */
	public String getTradeParty1ReferenceNumber() {
		return tradeParty1ReferenceNumber;
	}

	/**
	 * @param tradeParty1ReferenceNumber
	 *            the tradeParty1ReferenceNumber to set
	 */
	public void setTradeParty1ReferenceNumber(String tradeParty1ReferenceNumber) {
		this.tradeParty1ReferenceNumber = tradeParty1ReferenceNumber;
	}

	/**
	 * @return the tradeParty2
	 */
	public String getTradeParty2() {
		return tradeParty2;
	}

	/**
	 * @param tradeParty2
	 *            the tradeParty2 to set
	 */
	public void setTradeParty2(String tradeParty2) {
		this.tradeParty2 = tradeParty2;
	}

	/**
	 * @return the tradeParty2Name
	 */
	public String getTradeParty2Name() {
		return tradeParty2Name;
	}

	/**
	 * @param tradeParty2Name
	 *            the tradeParty2Name to set
	 */
	public void setTradeParty2Name(String tradeParty2Name) {
		this.tradeParty2Name = tradeParty2Name;
	}

	/**
	 * @return the buyer
	 */
	public String getBuyer() {
		return buyer;
	}

	/**
	 * @param buyer
	 *            the buyer to set
	 */
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	/**
	 * @return the seller
	 */
	public String getSeller() {
		return seller;
	}

	/**
	 * @param seller
	 *            the seller to set
	 */
	public void setSeller(String seller) {
		this.seller = seller;
	}

	/**
	 * @return the assetClass
	 */
	public String getAssetClass() {
		return assetClass;
	}

	/**
	 * @param assetClass
	 *            the assetClass to set
	 */
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	/**
	 * @return the tradeDate
	 */
	public Date getTradeDate() {
		return tradeDate;
	}

	/**
	 * @param tradeDate
	 *            the tradeDate to set
	 */
	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	/**
	 * @return the maturityDate
	 */
	public Date getMaturityDate() {
		return maturityDate;
	}

	/**
	 * @param maturityDate
	 *            the maturityDate to set
	 */
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	/**
	 * @return the verificationStatus
	 */
	public String getVerificationStatus() {
		return verificationStatus;
	}

	/**
	 * @param verificationStatus
	 *            the verificationStatus to set
	 */
	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	/**
	 * @return the tradeParty1
	 */
	public String getTradeParty1() {
		return tradeParty1;
	}

	/**
	 * @param tradeParty1
	 *            the tradeParty1 to set
	 */
	public void setTradeParty1(String tradeParty1) {
		this.tradeParty1 = tradeParty1;
	}

	/**
	 * @return the notionalAmountParty
	 */
	public BigDecimal getNotionalAmountParty() {
		return notionalAmountParty;
	}

	/**
	 * @param notionalAmountParty
	 *            the notionalAmountParty to set
	 */
	public void setNotionalAmountParty(BigDecimal notionalAmountParty) {
		this.notionalAmountParty = notionalAmountParty;
	}

	/**
	 * @return the notionalCurrencyParty
	 */
	public String getNotionalCurrencyParty() {
		return notionalCurrencyParty;
	}

	/**
	 * @param notionalCurrencyParty
	 *            the notionalCurrencyParty to set
	 */
	public void setNotionalCurrencyParty(String notionalCurrencyParty) {
		this.notionalCurrencyParty = notionalCurrencyParty;
	}

	/**
	 * @return the notionalAmountCpty
	 */
	public BigDecimal getNotionalAmountCpty() {
		return notionalAmountCpty;
	}

	/**
	 * @param notionalAmountCpty
	 *            the notionalAmountCpty to set
	 */
	public void setNotionalAmountCpty(BigDecimal notionalAmountCpty) {
		this.notionalAmountCpty = notionalAmountCpty;
	}

	/**
	 * @return the notionalCurrencyCpty
	 */
	public String getNotionalCurrencyCpty() {
		return notionalCurrencyCpty;
	}

	/**
	 * @param notionalCurrencyCpty
	 *            the notionalCurrencyCpty to set
	 */
	public void setNotionalCurrencyCpty(String notionalCurrencyCpty) {
		this.notionalCurrencyCpty = notionalCurrencyCpty;
	}

	/**
	 * @return the srcTradeId
	 */
	public String getSrcTradeId() {
		return srcTradeId;
	}

	/**
	 * @param srcTradeId
	 *            the srcTradeId to set
	 */
	public void setSrcTradeId(String srcTradeId) {
		this.srcTradeId = srcTradeId;
	}

	/**
	 * @return the reportingParty
	 */
	public String getReportingParty() {
		return reportingParty;
	}

	/**
	 * @param reportingParty
	 *            the reportingParty to set
	 */
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}

	/**
	 * @return the book
	 */
	public String getBook() {
		return book;
	}

	/**
	 * @param book
	 *            the book to set
	 */
	public void setBook(String book) {
		this.book = book;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}

	public String getBuyerLei() {
		return buyerLei;
	}

	public void setBuyerLei(String buyerLei) {
		this.buyerLei = buyerLei;
	}

	public String getSellerLei() {
		return sellerLei;
	}

	public void setSellerLei(String sellerLei) {
		this.sellerLei = sellerLei;
	}

	public String getBuyerUsLeiDesg() {
		return buyerUsLeiDesg;
	}

	public void setBuyerUsLeiDesg(String buyerUsLeiDesg) {
		this.buyerUsLeiDesg = buyerUsLeiDesg;
	}

	public String getSellerUsLeiDesg() {
		return sellerUsLeiDesg;
	}

	public void setSellerUsLeiDesg(String sellerUsLeiDesg) {
		this.sellerUsLeiDesg = sellerUsLeiDesg;
	}

	public String getBuyerFinEnt() {
		return buyerFinEnt;
	}

	public void setBuyerFinEnt(String buyerFinEnt) {
		this.buyerFinEnt = buyerFinEnt;
	}

	public String getSellerFinEnt() {
		return sellerFinEnt;
	}

	public void setSellerFinEnt(String sellerFinEnt) {
		this.sellerFinEnt = sellerFinEnt;
	}

	public String getBuyerUSEnt() {
		return buyerUSEnt;
	}

	public void setBuyerUSEnt(String buyerUSEnt) {
		this.buyerUSEnt = buyerUSEnt;
	}

	public String getSellerUSEnt() {
		return sellerUSEnt;
	}

	public void setSellerUSEnt(String sellerUSEnt) {
		this.sellerUSEnt = sellerUSEnt;
	}

	public String getTvProdId() {
		return tvProdId;
	}

	public void setTvProdId(String tvProdId) {
		this.tvProdId = tvProdId;
	}

	public String getMultiAssetClassSwap() {
		return multiAssetClassSwap;
	}

	public void setMultiAssetClassSwap(String multiAssetClassSwap) {
		this.multiAssetClassSwap = multiAssetClassSwap;
	}

	public String getMacPriAssetClass() {
		return macPriAssetClass;
	}

	public void setMacPriAssetClass(String macPriAssetClass) {
		this.macPriAssetClass = macPriAssetClass;
	}

	public String getMacSecAssetClass() {
		return macSecAssetClass;
	}

	public void setMacSecAssetClass(String macSecAssetClass) {
		this.macSecAssetClass = macSecAssetClass;
	}

	public String getMixedSwap() {
		return mixedSwap;
	}

	public void setMixedSwap(String mixedSwap) {
		this.mixedSwap = mixedSwap;
	}

	public String getMixedSwapOtherReportedSDR() {
		return mixedSwapOtherReportedSDR;
	}

	public void setMixedSwapOtherReportedSDR(String mixedSwapOtherReportedSDR) {
		this.mixedSwapOtherReportedSDR = mixedSwapOtherReportedSDR;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getExecutionVenue() {
		return executionVenue;
	}

	public void setExecutionVenue(String executionVenue) {
		this.executionVenue = executionVenue;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}




	public String getQuantityUnit() {
		return quantityUnit;
	}

	public void setQuantityUnit(String quantityUnit) {
		this.quantityUnit = quantityUnit;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getQuantityFreq() {
		return quantityFreq;
	}

	public void setQuantityFreq(String quantityFreq) {
		this.quantityFreq = quantityFreq;
	}

	public String getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(String totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public String getSettlementMethod() {
		return settlementMethod;
	}

	public void setSettlementMethod(String settlementMethod) {
		this.settlementMethod = settlementMethod;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public String getPriceCurrency() {
		return priceCurrency;
	}

	public void setPriceCurrency(String priceCurrency) {
		this.priceCurrency = priceCurrency;
	}

	public String getBuyerPayIndex() {
		return buyerPayIndex;
	}

	public void setBuyerPayIndex(String buyerPayIndex) {
		this.buyerPayIndex = buyerPayIndex;
	}

	public String getBuyerPayIndexAveragingMethod() {
		return buyerPayIndexAveragingMethod;
	}

	public void setBuyerPayIndexAveragingMethod(String buyerPayIndexAveragingMethod) {
		this.buyerPayIndexAveragingMethod = buyerPayIndexAveragingMethod;
	}

	public String getSellerPayIndex() {
		return sellerPayIndex;
	}

	public void setSellerPayIndex(String sellerPayIndex) {
		this.sellerPayIndex = sellerPayIndex;
	}

	public String getSellerPayIndexAveragingMethod() {
		return sellerPayIndexAveragingMethod;
	}

	public void setSellerPayIndexAveragingMethod(
			String sellerPayIndexAveragingMethod) {
		this.sellerPayIndexAveragingMethod = sellerPayIndexAveragingMethod;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getOptionType() {
		return optionType;
	}

	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}

	public String getOptionStyle() {
		return optionStyle;
	}

	public void setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
	}

	public String getOptionPremium() {
		return optionPremium;
	}

	public void setOptionPremium(String optionPremium) {
		this.optionPremium = optionPremium;
	}

	public String getHrsFromThr() {
		return hrsFromThr;
	}

	public void setHrsFromThr(String hrsFromThr) {
		this.hrsFromThr = hrsFromThr;
	}

	public String getHrsFromThrTimeZone() {
		return hrsFromThrTimeZone;
	}

	public void setHrsFromThrTimeZone(String hrsFromThrTimeZone) {
		this.hrsFromThrTimeZone = hrsFromThrTimeZone;
	}

	public String getDaysOfWeek() {
		return daysOfWeek;
	}

	public void setDaysOfWeek(String daysOfWeek) {
		this.daysOfWeek = daysOfWeek;
	}

	public String getLoadType() {
		return loadType;
	}

	public void setLoadType(String loadType) {
		this.loadType = loadType;
	}

	public String getCollaterlized() {
		return collaterlized;
	}

	public void setCollaterlized(String collaterlized) {
		this.collaterlized = collaterlized;
	}

	public Date getExecDate() {
		return execDate;
	}

	public void setExecDate(Date execDate) {
		this.execDate = execDate;
	}

	public String getReportPrtyLei() {
		return reportPrtyLei;
	}

	public void setReportPrtyLei(String reportPrtyLei) {
		this.reportPrtyLei = reportPrtyLei;
	}

	public String getReportSd() {
		return reportSd;
	}

	public void setReportSd(String reportSd) {
		this.reportSd = reportSd;
	}

	public String getReportMsp() {
		return reportMsp;
	}

	public void setReportMsp(String reportMsp) {
		this.reportMsp = reportMsp;
	}

	public String getReportFin() {
		return reportFin;
	}

	public void setReportFin(String reportFin) {
		this.reportFin = reportFin;
	}

	public String getReportUs() {
		return reportUs;
	}

	public void setReportUs(String reportUs) {
		this.reportUs = reportUs;
	}

	public String getNonReportLei() {
		return nonReportLei;
	}

	public void setNonReportLei(String nonReportLei) {
		this.nonReportLei = nonReportLei;
	}

	public String getNonReportId() {
		return nonReportId;
	}

	public void setNonReportId(String nonReportId) {
		this.nonReportId = nonReportId;
	}

	public String getNonReptSd() {
		return nonReptSd;
	}

	public void setNonReptSd(String nonReptSd) {
		this.nonReptSd = nonReptSd;
	}

	public String getNonRepMsp() {
		return nonRepMsp;
	}

	public void setNonRepMsp(String nonRepMsp) {
		this.nonRepMsp = nonRepMsp;
	}

	public String getNonRepFin() {
		return nonRepFin;
	}

	public void setNonRepFin(String nonRepFin) {
		this.nonRepFin = nonRepFin;
	}

	public String getNonRepUs() {
		return nonRepUs;
	}

	public void setNonRepUs(String nonRepUs) {
		this.nonRepUs = nonRepUs;
	}

	public String getSubmittedonBehalfofPtyIDValue() {
		return SubmittedonBehalfofPtyIDValue;
	}

	public void setSubmittedonBehalfofPtyIDValue(
			String submittedonBehalfofPtyIDValue) {
		SubmittedonBehalfofPtyIDValue = submittedonBehalfofPtyIDValue;
	}
	
	public String getReportingEntityPETData() {
		return reportingEntityPETData;
	}

	public void setReportingEntityPETData(String reportingEntityPETData) {
		this.reportingEntityPETData = reportingEntityPETData;
	}
}