package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.IRTradeUnfilterd;
import com.wf.portrec.domain.TradeFile;

public interface IRTradeUnfilterdRepository extends CrudRepository<IRTradeUnfilterd, Long> {

	@Query("Select ir from IRTradeUnfilterd ir where ir.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, own')")
	public List<IRTradeUnfilterd> findSrcTrades();
	
	@Query("Select ir from IRTradeUnfilterd ir where ir.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC')")
	public List<IRTradeUnfilterd> findDtccTrades();

	@Query("Select um.dtccUsi, ir from IRTradeUnfilterd ir, UsiMapStatic um  where ir.usi=um.dtccUsi and ir.tradeFile = (Select max(tf) " +
	"from TradeFile tf, PortfolioSegment ps where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC')")
	public List<Object[]> fetchDtccUsiMap();

	@Query("Select ir from IRTradeUnfilterd ir where ir.usi not in (select um.dtccUsi from UsiMapSlider um where um.assetClass = 'InterestRate') " + 
	        "and ir.tradeFile = ?")
	public List<IRTradeUnfilterd> fetchIRDtccNonUsiMapSlider(TradeFile trFile);
	
	@Query("select pr from IRTradeUnfilterd pr where pr.id in (select pri.id from IRTradeUnfilterd pri where pri.tradeFile = ? " +
			"group by pri.origTradeId having pri.revisionId = max(pri.revisionId)) " +
			"and pr.tradeFile = ? group by pr.origTradeId having pr.id=max(pr.id)")
	public List<IRTradeUnfilterd> findMaxRevisionTradeByFile(TradeFile fileLeft, TradeFile fileLeft2);
	
	@Query("from IRTradeUnfilterd pr where pr.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC' and tf.loadCompleted is not null) and pr.tradeParty1Lei = ?")
	public List<IRTradeUnfilterd> findDtccTradesByLei(String nextLei);
	
	@Query("Select ir from IRTradeUnfilterd ir where ir.tradeParty1=? or ir.tradeParty2=? and ir.tradeFile = (Select max(tff) from TradeFile tff , PortfolioSegment pss where tff.id <( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Interest Rate, DTCC') and tff.portfolioSegment = pss and pss.name = 'Interest Rate, DTCC')")
	public List<IRTradeUnfilterd> findDtccTradesForCpty(String cpty1, String cpty2);
	
	@Query("Select ir from IRTradeUnfilterd ir where ir.tradeParty1=? or ir.tradeParty2=? and ir.runDate=?")
	public List<IRTradeUnfilterd> findDtccTradesForCptyByDate(String cpty1, String cpty2,Date rundate);
	
	@Query("select ir from IRTradeUnfilterd ir, TradeFile ptf where ir.runDate=? and (ir.tradeParty1=? or ir.tradeParty2=?) " +
			"and ir.tradeFile=ptf.id and ptf.loadCompleted is not null")
	public List<IRTradeUnfilterd> findDtccTradesForCptyByDateRevised(Date rundate, String cpty1, String cpty2);
}
