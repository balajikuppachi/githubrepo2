package com.wf.portrec.domain;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "pr_trade_file")
public class TradeFile {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
	
	@Column(name = "name")
	String name;
	
	@Column(name = "load_started", nullable = false)
	Date loadStarted;
	
	@Column(name = "load_completed", nullable = true)
	Date loadCompleted;
	
	@Column(name = "records_total", nullable = true)
	Integer recordsTotal = 0;
	
	@Column(name = "records_loaded", nullable = true)
	Integer recordsLoaded = 0;
	
	@Column(name = "as_of_date", nullable = false)
	Date asOfDate;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "portfolio_segment_id", nullable = false)
	PortfolioSegment portfolioSegment;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getLoadStarted() {
		return loadStarted;
	}

	public void setLoadStarted(Date loadStarted) {
		this.loadStarted = loadStarted;
	}

	public Date getLoadCompleted() {
		return loadCompleted;
	}

	public void setLoadCompleted(Date loadCompleted) {
		this.loadCompleted = loadCompleted;
	}

	public Date getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(asOfDate);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		this.asOfDate = calendar.getTime();
	}

	public PortfolioSegment getPortfolioSegment() {
		return portfolioSegment;
	}

	public void setPortfolioSegment(PortfolioSegment portfolioSegment) {
		this.portfolioSegment = portfolioSegment;
	}
	
	public Integer getRecordsTotal() {
		return recordsTotal;
	}

	public void setRecordsTotal(Integer recordsTotal) {
		this.recordsTotal = recordsTotal;
	}

	public Integer getRecordsLoaded() {
		return recordsLoaded;
	}

	public void setRecordsLoaded(Integer recordsLoaded) {
		this.recordsLoaded = recordsLoaded;
	}

	@Override
	public String toString() {
		return "TradeFile [id=" + id + ", name=" + name + ", loadStarted="
				+ loadStarted + ", loadCompleted=" + loadCompleted
				+ ", recordsTotal=" + recordsTotal + ", recordsLoaded="
				+ recordsLoaded + ", asOfDate=" + asOfDate
				+ ", portfolioSegment=" + portfolioSegment + "]";
	}

}
