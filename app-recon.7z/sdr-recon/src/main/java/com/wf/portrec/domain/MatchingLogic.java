package com.wf.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * @author u250429
 * 
 */
@Entity
@Table(name = "pr_mismatch_log")
public class MatchingLogic {

	@Id
	@Column(name = "id")
	@TableGenerator(name = "pr_matching_id_generator", table = "pr_id_sequence", allocationSize = 200, pkColumnName = "seq_name", pkColumnValue = "pr_matching_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "pr_matching_id_generator")
	Long id;

	@Column(name = "create_date")
	Date createdDate;

	@Column(name = "dtcc_tr_id")
	Long dtccTrId;

	@Column(name = "dtcc_file_id")
	Long dtccFileId;

	@Column(name = "src_tr_id")
	Long srcTrId;

	@Column(name = "src_file_id")
	Long srcFileId;

	@Column(name = "mismatch_fields")
	String mismatchFields;

	@Column(name = "matching_index")
	double mismatchIndex;
	
	@Column(name = "src_match")
	String srcMatch;
	
	@Column(name = "src_usi")
	String srcUsi;
	
	@Column(name = "dtcc_usi")
	String dtccUsi;

	@Column(name = "src_tradeid")
	String srcTradeid;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the dtccTrId
	 */
	public Long getDtccTrId() {
		return dtccTrId;
	}

	/**
	 * @param dtccTrId
	 *            the dtccTrId to set
	 */
	public void setDtccTrId(Long dtccTrId) {
		this.dtccTrId = dtccTrId;
	}

	/**
	 * @return the dtccFileId
	 */
	public Long getDtccFileId() {
		return dtccFileId;
	}

	/**
	 * @param dtccFileId
	 *            the dtccFileId to set
	 */
	public void setDtccFileId(Long dtccFileId) {
		this.dtccFileId = dtccFileId;
	}

	/**
	 * @return the srcTrId
	 */
	public Long getSrcTrId() {
		return srcTrId;
	}

	/**
	 * @param srcTrId
	 *            the srcTrId to set
	 */
	public void setSrcTrId(Long srcTrId) {
		this.srcTrId = srcTrId;
	}

	/**
	 * @return the srcFileId
	 */
	public Long getSrcFileId() {
		return srcFileId;
	}

	/**
	 * @param srcFileId
	 *            the srcFileId to set
	 */
	public void setSrcFileId(Long srcFileId) {
		this.srcFileId = srcFileId;
	}

	/**
	 * @return the mismatchFields
	 */
	public String getMismatchFields() {
		return mismatchFields;
	}

	/**
	 * @param mismatchFields
	 *            the mismatchFields to set
	 */
	public void setMismatchFields(String mismatchFields) {
		this.mismatchFields = mismatchFields;
	}

	/**
	 * @return the mismatchIndex
	 */
	public double getMismatchIndex() {
		return mismatchIndex;
	}

	/**
	 * @param mismatchIndex
	 *            the mismatchIndex to set
	 */
	public void setMismatchIndex(double mismatchIndex) {
		this.mismatchIndex = mismatchIndex;
	}

	/**
	 * @return the srcMatch
	 */
	public String getSrcMatch() {
		return srcMatch;
	}

	/**
	 * @param srcMatch the srcMatch to set
	 */
	public void setSrcMatch(String srcMatch) {
		this.srcMatch = srcMatch;
	}

	public String getSrcUsi() {
		return srcUsi;
	}

	public void setSrcUsi(String srcUsi) {
		this.srcUsi = srcUsi;
	}

	public String getDtccUsi() {
		return dtccUsi;
	}

	public void setDtccUsi(String dtccUsi) {
		this.dtccUsi = dtccUsi;
	}

	public String getSrcTradeid(){
		return srcTradeid;
	}

	public void setSrcTradeid(String tradeid) {
		this.srcTradeid = tradeid;
	}

}
