package com.wf.portrec.service.report;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.CommodityTrade;

@Component
public class CommDataCsvWriter {
	@Value("${file.portrec.data.comm}") String outputFolderName;
	@Value("${mask.counterparty.details}") String counterPartyValue;
	@Value("${wf.affiliatebank.leis}") String wfLeiList;
	String fileName = "COM_GTR_";
	Logger logger = LoggerFactory.getLogger(getClass());
	int SNAPSHOT_HEADER_ROW_NUM = 10;
	static char SEPARATOR = ',';


	public void generateMatchUSIFile(File targetFile, Map<String,CommodityTrade> usiTrdIdMap, String fileType) {
		try {
			logger.info("Inside Generate CSV File");
			targetFile.mkdirs();						
			if (targetFile.exists()) {
				targetFile.delete();
			}		
			logger.info("file path"+targetFile.getAbsolutePath());			
			FileWriter writer = new FileWriter(targetFile);

			writer.append("USI");
			writer.append(SEPARATOR);
			writer.append("Trade Id");
			writer.append(SEPARATOR);
			writer.append("Reporting prty LEI");
			writer.append(SEPARATOR);
			writer.append("Report SD");
			writer.append(SEPARATOR);
			writer.append("Report MSP");
			writer.append(SEPARATOR);
			writer.append("Report Fin");
			writer.append(SEPARATOR);
			writer.append("Report US");
			writer.append(SEPARATOR);
			writer.append("Non Report LEI");
			writer.append(SEPARATOR);
			writer.append("Non Report id");
			writer.append(SEPARATOR);
			writer.append("Non Rept SD");
			writer.append(SEPARATOR);
			writer.append("Non Rep MSP");
			writer.append(SEPARATOR);
			writer.append("Non Rep Fin");
			writer.append(SEPARATOR);
			writer.append("Non Rep US");
			writer.append(SEPARATOR);
			writer.append("Product ID");	
			writer.append(SEPARATOR);
			writer.append("CFTC Prod Id");
			writer.append(SEPARATOR);
			writer.append("Int Prod Id");
			writer.append(SEPARATOR);
			writer.append("Multi Asset");
			writer.append(SEPARATOR);
			writer.append("Pri Asset Class");
			writer.append(SEPARATOR);
			writer.append("Sec Asset Class");
			writer.append(SEPARATOR);
			writer.append("Mixed Swap");
			writer.append(SEPARATOR);
			writer.append("SDR2");
			writer.append(SEPARATOR);
			writer.append("Contract Type");
			writer.append(SEPARATOR);
			writer.append("Exec Venue");
			writer.append(SEPARATOR);
			writer.append("Start Dt");
			writer.append(SEPARATOR);
			writer.append("End Dt");
			writer.append(SEPARATOR);
			writer.append("Buyer");
			writer.append(SEPARATOR);
			writer.append("Seller");
			writer.append(SEPARATOR);
			writer.append("Qty Unit");
			writer.append(SEPARATOR);
			writer.append("Qty");
			writer.append(SEPARATOR);
			writer.append("Qty Freq");
			writer.append(SEPARATOR);
			writer.append("Total Qty");
			writer.append(SEPARATOR);
			writer.append("Settle Method");
			writer.append(SEPARATOR);
			writer.append("Price");
			writer.append(SEPARATOR);
			writer.append("Price Unit");
			writer.append(SEPARATOR);
			writer.append("Price ccy");
			writer.append(SEPARATOR);
			writer.append("Buyer Pay Ind");
			writer.append(SEPARATOR);
			writer.append("Buyer Pay avg Method");
			writer.append(SEPARATOR);
			writer.append("Seller Pay Ind");
			writer.append(SEPARATOR);
			writer.append("Seller Pay avg Method");
			writer.append(SEPARATOR);
			writer.append("Grade");
			writer.append(SEPARATOR);
			writer.append("Option Type");
			writer.append(SEPARATOR);
			writer.append("Option Style");
			writer.append(SEPARATOR);
			writer.append("Option Premium");
			writer.append(SEPARATOR);
			writer.append("Hrs Frm Thru");
			writer.append(SEPARATOR);
			writer.append("Hours Timezone");
			writer.append(SEPARATOR);
			writer.append("Day of Week");
			writer.append(SEPARATOR);
			writer.append("Load Type");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);			
			writer.append("Exec Date");
			writer.append('\n');			
			
			Iterator it = usiTrdIdMap.entrySet().iterator();
			while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		        //out.write(pairs.getKey() + " = " + pairs.getValue() + "\n");
		        CommodityTrade srcViewDomain = (CommodityTrade)pairs.getValue();
		        String usi = (String)pairs.getKey();
		        String[] parts = usi.split(":");
		        usi=parts[0];
		        srcViewDomain.setUsiValue(usi);
				writer.append((null != srcViewDomain.getUsiNamespace() ? srcViewDomain.getUsiNamespace() : "")
						+(null != srcViewDomain.getUsiValue() ? srcViewDomain.getUsiValue() : ""));
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSrcTradeId() ? srcViewDomain.getSrcTradeId() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportPrtyLei() ? maskCounterPartyDetails(srcViewDomain.getReportPrtyLei()) :"");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportSd() ? srcViewDomain.getReportSd() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportMsp() ? srcViewDomain.getReportMsp() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportFin() ? srcViewDomain.getReportFin() : "");
				writer.append(SEPARATOR);
				writer.append(null!= srcViewDomain.getReportUs() ? srcViewDomain.getReportUs() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonReportLei() ? maskCounterPartyDetails(srcViewDomain.getNonReportLei()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonReportId() ? maskCounterPartyDetails(srcViewDomain.getNonReportId()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonReptSd() ? srcViewDomain.getNonReptSd() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonRepMsp() ? srcViewDomain.getNonRepMsp() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonRepFin() ? srcViewDomain.getNonRepFin() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonRepUs() ? srcViewDomain.getNonRepUs() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getProductId() ? (srcViewDomain.getProductId().contains(",")?srcViewDomain.getProductId().replace(",", ";"):srcViewDomain.getProductId()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getCftcProductId() ? srcViewDomain.getCftcProductId() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getIntProductId() ? srcViewDomain.getIntProductId() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMultiAssetClassSwap() ? srcViewDomain.getMultiAssetClassSwap() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMacPriAssetClass() ? srcViewDomain.getMacPriAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMacSecAssetClass() ? srcViewDomain.getMacSecAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMixedSwap() ? srcViewDomain.getMixedSwap() : "");		
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMixedSwapOtherReportedSDR() ? srcViewDomain.getMixedSwapOtherReportedSDR() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getContractType() ? srcViewDomain.getContractType() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getExecutionVenue() ? srcViewDomain.getExecutionVenue() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getStartDate() ? getStrDate(srcViewDomain.getStartDate()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getEndDate() ? getStrDate(srcViewDomain.getEndDate()) : "");
				writer.append(SEPARATOR);
				String buyer = "";
				String seller = "";
				if(StringUtils.isNotBlank(srcViewDomain.getBuyer()))
					buyer = srcViewDomain.getBuyer().replace(",","");
				if(StringUtils.isNotBlank(srcViewDomain.getSeller()))
					seller = srcViewDomain.getSeller().replace(",","");
				writer.append(null != buyer ? maskCounterPartyName(buyer.trim()) : "");
				writer.append(SEPARATOR);
				writer.append(null != seller ? maskCounterPartyName(seller.trim()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getQuantityUnit() ? srcViewDomain.getQuantityUnit() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getQuantity() ? srcViewDomain.getQuantity() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getQuantityFreq() ? srcViewDomain.getQuantityFreq() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTotalQuantity() ? srcViewDomain.getTotalQuantity() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSettlementMethod() ? srcViewDomain.getSettlementMethod() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPrice() ? srcViewDomain.getPrice() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPriceUnit() ? srcViewDomain.getPriceUnit() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPriceCurrency() ? srcViewDomain.getPriceCurrency() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getBuyerPayIndex() ? srcViewDomain.getBuyerPayIndex() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getBuyerPayIndexAveragingMethod() ? srcViewDomain.getBuyerPayIndexAveragingMethod() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSellerPayIndex() ? srcViewDomain.getSellerPayIndex() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSellerPayIndexAveragingMethod() ? srcViewDomain.getSellerPayIndexAveragingMethod() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getGrade() ? srcViewDomain.getGrade() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOptionType() ? srcViewDomain.getOptionType() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOptionStyle() ? srcViewDomain.getOptionStyle() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOptionPremium() ? srcViewDomain.getOptionPremium() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getHrsFromThr() ? srcViewDomain.getHrsFromThr() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getHrsFromThrTimeZone() ? srcViewDomain.getHrsFromThrTimeZone() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getDaysOfWeek() ? srcViewDomain.getDaysOfWeek() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getLoadType() ? srcViewDomain.getLoadType() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getCollaterlized() ? srcViewDomain.getCollaterlized() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getExecDate() ? getStrDate(srcViewDomain.getExecDate()) : "");
				writer.append('\n');
				
			}
			writer.flush();
			writer.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getStrDate(Date date){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			
		return dateFormat.format(date);
	}
	
	public String getFileDateExtension(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(date);
	}
	
	private String maskCounterPartyDetails(String leiValue){
		String cpVal = "";
		if(null!=leiValue){
			if(StringUtils.contains(wfLeiList, leiValue)){
				cpVal = leiValue;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}	
	
	private String maskCounterPartyName(String partyName){
		String cpVal = "";
		if(null!=partyName){
			if(StringUtils.containsIgnoreCase(partyName, "Wells Fargo")){
				cpVal = partyName;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}	
}