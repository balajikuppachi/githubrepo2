package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.FXTradeUnfiltered;

public interface FXTradeUnfilterdRepository extends CrudRepository<FXTradeUnfiltered, Long> {
	
	@Query("Select fx from FXTradeUnfiltered fx where fx.tradeParty1=? or fx.tradeParty2=? and fx.tradeFile = (Select max(tff) from TradeFile tff , PortfolioSegment pss where tff.id <( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'ForeignExchange, DTCC' and tf.loadCompleted is not null) and tff.portfolioSegment = pss and pss.name = 'ForeignExchange, DTCC' and tff.loadCompleted is not null)")
	public List<FXTradeUnfiltered> findDtccTradesForCpty(String cpty1, String cpty2);
	
	@Query("Select fx from FXTradeUnfiltered fx where fx.tradeParty1=? or fx.tradeParty2=? and fx.runDate = ?")
	public List<FXTradeUnfiltered> findDtccTradesForCptyByDate(String cpty1, String cpty2, Date runDate);
	
	@Query("Select fx from FXTradeUnfiltered fx where fx.runDate=? and (fx.tradeParty1=? or fx.tradeParty2=?) "+ 
	"and fx.tradeFile=( Select max(tf)-1 from TradeFile tf, PortfolioSegment ps "+
	"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'ForeignExchange, DTCC' and tf.loadCompleted is not null )") 
	public List<FXTradeUnfiltered> findDtccTradesForCptyByDateRevised(Date rundate, String cpty1, String cpty2, Date asOfDate);
	
	@Query("Select fx.tradeParty2,count(*) from FXTradeUnfiltered fx where fx.tradeFile in ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps  and tf.asOfDate = ? and ps.name = 'ForeignExchange, own' and tf.recordsTotal=tf.recordsLoaded) group by tradeParty2")
	public List<Object[]> findAllUnlinkedIntSrcTrades(Date asOfDate);
	
	@Query("Select fx.tradeParty1,count(*) from FXTradeUnfiltered fx where fx.tradeFile in ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps  and tf.asOfDate = ? and ps.name = 'ForeignExchange, own' and tf.recordsTotal=tf.recordsLoaded) " +
	"and fx.tradeParty1 != 'KB1H1DSPRFMYMCUFXT09' group by tradeParty1")
	public List<Object[]> findAllUnlinkedIntSrcTradesForParty1(Date asOfDate);
}
