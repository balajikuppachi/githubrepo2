package com.wf.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.wf.portrec.domain.annotation.UseForMatching;

/**
 * @author u250429
 * @version 1.0
 * 
 *          CRTrade Class, which has common params for both DTCC and SRC Credit.
 *          Both DtccCRTrade and SrcCRTrade extends CreditTrade
 * 
 */

@Entity
@Table(name = "pr_foreignexchange")
public class FXTrade extends Trade {

	
	@Id
	@Column(name = "id")
	@TableGenerator(name="pr_foreignexchange_id_generator", table="pr_id_sequence", allocationSize=200,
			pkColumnName="seq_name", pkColumnValue="pr_foreignexchange_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator="pr_foreignexchange_id_generator")
	Long id;

	@UseForMatching
	@Column(name = "usi_value")
	String usiValue = "";

	@UseForMatching
	@Column(name = "allocation_indicator")
	String allocationIndicator = "";

	@UseForMatching
	@Column(name = "secondary_asset_class")
	String secondaryAssetClass = "";

	@UseForMatching
	@Column(name = "primary_asset_class")
	String primaryAssetClass = "";

	@UseForMatching
	@Column(name = "trade_party_1")
	String tradeParty1 = "";

	@UseForMatching
	@Column(name = "trade_party_2")
	String tradeParty2 = "";
	
	@Column(name = "is_party1_fin")
	String isParty1Fin = "";

	@Column(name = "party2_internal_id")
	String party2InternalId = "";
	
	@Column(name = "is_party2_fin")
	String isParty2Fin = "";
	
	@Column(name = "CCY2")
	String ccy2 = "";
	
	@Column(name = "system_derived_reporting_party")
	String systemDerivedReportingParty;

	@Column(name = "reporting_party")
	String reportingParty;
	
	@UseForMatching
	@Column(name = "execution_venue")
	String executionVenue = "";

	@UseForMatching
	@Column(name = "notional_amount_1")
	BigDecimal notionalAmount1;

	@UseForMatching
	@Column(name = "notional_currency_1")
	String notionalCurrency1 = "";

	@UseForMatching
	@Column(name = "notional_amount_2")
	BigDecimal notionalAmount2;

	@UseForMatching
	@Column(name = "notional_currency_2")
	String notionalCurrency2 = "";

	@UseForMatching
	@Column(name = "collateralized")
	String collateralized = "";

	@UseForMatching
	@Column(name = "exchange_rate")
	BigDecimal exchangeRate ;

	@UseForMatching
	@Column(name = "settlement_fixing_date")
	Date settlementFixingDate;

	@UseForMatching
	@Column(name = "settlement_expiration_date")
	Date settlementExpirationDate;

	@UseForMatching
	@Column(name = "mandatory_clearing_indicator")
	String mandatoryClearingIndicator = "";

	@UseForMatching
	@Column(name = "bloack_trade_indicator")
	String bloackTradeIndicator = "";

	@UseForMatching
	@Column(name = "submission_timestamp")
	String submissionTimestamp = "";

	@UseForMatching
	@Column(name = "execution_timestamp")
	String executionTimestamp = "";

	@Column(name = "mtm_position_value")
	String mtmPositionValue = "";
	
	@Column(name = "usi_prefix")
	String usiPrefix = "";

	@Column(name = "additional_repository_1_prefix")
	String additionalRepository1Prefix = "";

	@Column(name = "product_id_prefix")
	String productIdPrefix = "";

	@Column(name = "product_id_value")
	String productIdValue = "";

	@Column(name = "trade_party1_role")
	String tradeParty1Role = "";

	@Column(name = "trade_party2_role")
	String tradeParty2Role = "";

	@Column(name = "data_submitter_lei_prefix")
	String dataSubmitterLeiPrefix = "";

	@Column(name = "data_submitter_lei_value")
	String dataSubmitterLeiValue = "";

	@Column(name = "clearing_exception_party_prefix")
	String clearingExceptionPartyPrefix = "";

	@Column(name = "clearing_exception_party_value")
	String clearingExceptionPartyValue = "";

	@Column(name = "broker_location_party_1")
	String brokerLocationParty1 = "";

	@Column(name = "broker_location_party_2")
	String brokerLocationParty2 = "";

	@Column(name = "desk_location_party_1")
	String deskLocationParty1 = "";

	@Column(name = "desk_location_party_2")
	String deskLocationParty2 = "";

	@Column(name = "trader_location_party_1")
	String traderLocationParty1 = "";

	@Column(name = "trader_location_party_2")
	String traderLocationParty2 = "";

	@Column(name = "expiration_date")
	Date expirationDate;

	@Column(name = "expiration_time")
	String expirationTime = "";

	@Column(name = "trade_party_1_lei")
	String tradeParty1Lei = "";

	@Column(name = "trade_party_2_lei")
	String tradeParty2Lei = "";

	@Column(name = "party_1_lei")
	String party1Lei = "";

	@Column(name = "party_2_lei")
	String party2Lei = "";
	
	@Column(name = "is_party1_sd")
	String isParty1Sd = "";

	@Column(name = "is_party1_msp")
	String isParty1Msp = "";

	@Column(name = "is_party1_us_person")
	String isParty1USPerson = "";

	@Column(name = "is_party2_sd")
	String isParty2Sd = "";

	@Column(name = "is_party2_msp")
	String isParty2Msp = "";

	@Column(name = "is_party2_us_person")
	String isParty2USPerson = "";
	//
	@Column(name = "trade_party1_prefix")
	String tradeParty1Prefix = "";
	
	@Column(name = "trade_party1_fin_ent")
	String tradeParty1FinEnt = "";
	
	@Column(name = "trade_party1_us_person_indicator")
	String tradeParty1UsPersonIndicator = "";
	
	@Column(name = "trade_party2_prefix")
	String tradeParty2Prefix = "";
	
	@Column(name = "trade_party2_fin_ent")
	String tradeParty2FinEnt = "";
	
	@Column(name = "trade_party2_us_person_indicator")
	String tradeParty2UsPersonIndicator = "";
	
	@Column(name = "additional_repository1_lei")
	String additionalRepository1Lei = "";
	
	@Column(name = "exchange_currency_1")
	String exchangeCurrency1 = "";
	
	@Column(name = "exchange_currency_2")
	String exchangeCurrency2 = "";
	
	@Column(name = "exchange_currency1_amount")
	BigDecimal exchangeCurrency1Amount;
	
	@Column(name = "exchange_currency2_amount")
	BigDecimal exchangeCurrency2Amount;

	@Column(name = "exotic_expiration_date")
	Date exoticExpirationDate;
	
	//
	@Column(name = "product_id")
	String productId = "";

	@Column(name = "cftc_product_id")
	String cftcProductId = "";

	@Column(name = "sdr_internal_product_id")
	String sdrInternalProductId = "";

	@Column(name = "is_multiasset_swap")
	String isMultiassetSwap = "";

	@Column(name = "is_mixed_swap")
	String isMixedSwap = "";

	@Column(name = "sdr2_id")
	String sdr2Id = "";

	@Column(name = "contract_type")
	String contractType = "";

	@Column(name = "delivery_type")
	String deliveryType = "";

	@Column(name = "sdr_submision_timestamp")
	String sdrSubmisionTimestamp = "";

	@Column(name = "clearing_venue")
	String clearingVenue = "";

	@Column(name = "is_clearing_req_exc")
	String isClearingReqExc = "";
	
	@UseForMatching
	@Column(name = "CCY1")
	String ccy1 = "";	
	
	@UseForMatching
	@Column(name = "premium_currency")
	String premiumCurrency = "";	
	
	@UseForMatching
	@Column(name = "premium_amount")
	BigDecimal premiumAmount;
	
	@UseForMatching
	@Column(name = "settlement_currency")
	String settlementCurrency = "";
	

	
	@Column(name="run_date")
	Date runDate;
	
	@Column(name="submitted_for")
	String submittedFor;

	public String getSubmittedFor() {
		return submittedFor;
	}

	public void setSubmittedFor(String submittedFor) {
		this.submittedFor = submittedFor;
	}

	

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the usiValue
	 */
	public String getUsiValue() {
		return usiValue;
	}

	/**
	 * @param usiValue the usiValue to set
	 */
	public void setUsiValue(String usiValue) {
		this.usiValue = usiValue;
	}

	/**
	 * @return the allocationIndicator
	 */
	public String getAllocationIndicator() {
		return allocationIndicator;
	}

	/**
	 * @param allocationIndicator the allocationIndicator to set
	 */
	public void setAllocationIndicator(String allocationIndicator) {
		this.allocationIndicator = allocationIndicator;
	}

	/**
	 * @return the secondaryAssetClass
	 */
	public String getSecondaryAssetClass() {
		return secondaryAssetClass;
	}

	/**
	 * @param secondaryAssetClass the secondaryAssetClass to set
	 */
	public void setSecondaryAssetClass(String secondaryAssetClass) {
		this.secondaryAssetClass = secondaryAssetClass;
	}

	/**
	 * @return the primaryAssetClass
	 */
	public String getPrimaryAssetClass() {
		return primaryAssetClass;
	}

	/**
	 * @param primaryAssetClass the primaryAssetClass to set
	 */
	public void setPrimaryAssetClass(String primaryAssetClass) {
		this.primaryAssetClass = primaryAssetClass;
	}

	/**
	 * @return the tradeParty1
	 */
	public String getTradeParty1() {
		return tradeParty1;
	}

	/**
	 * @param tradeParty1 the tradeParty1 to set
	 */
	public void setTradeParty1(String tradeParty1) {
		this.tradeParty1 = tradeParty1;
	}

	/**
	 * @return the tradeParty2
	 */
	public String getTradeParty2() {
		return tradeParty2;
	}

	/**
	 * @param tradeParty2 the tradeParty2 to set
	 */
	public void setTradeParty2(String tradeParty2) {
		this.tradeParty2 = tradeParty2;
	}

	public String getIsParty1Fin() {
		return isParty1Fin;
	}

	public void setIsParty1Fin(String isParty1Fin) {
		this.isParty1Fin = isParty1Fin;
	}

	public String getParty2InternalId() {
		return party2InternalId;
	}

	public void setParty2InternalId(String party2InternalId) {
		this.party2InternalId = party2InternalId;
	}

	public String getIsParty2Fin() {
		return isParty2Fin;
	}

	public void setIsParty2Fin(String isParty2Fin) {
		this.isParty2Fin = isParty2Fin;
	}

	public String getCcy2() {
		return ccy2;
	}

	public void setCcy2(String ccy2) {
		this.ccy2 = ccy2;
	}

	/**
	 * @return the executionVenue
	 */
	public String getExecutionVenue() {
		return executionVenue;
	}

	/**
	 * @param executionVenue the executionVenue to set
	 */
	public void setExecutionVenue(String executionVenue) {
		this.executionVenue = executionVenue;
	}

	/**
	 * @return the notionalAmount1
	 */
	public BigDecimal getNotionalAmount1() {
		return notionalAmount1;
	}

	/**
	 * @param notionalAmount1 the notionalAmount1 to set
	 */
	public void setNotionalAmount1(BigDecimal notionalAmount1) {
		this.notionalAmount1 = notionalAmount1;
	}

	/**
	 * @return the notionalCurrency1
	 */
	public String getNotionalCurrency1() {
		return notionalCurrency1;
	}

	/**
	 * @param notionalCurrency1 the notionalCurrency1 to set
	 */
	public void setNotionalCurrency1(String notionalCurrency1) {
		this.notionalCurrency1 = notionalCurrency1;
	}

	/**
	 * @return the notionalAmount2
	 */
	public BigDecimal getNotionalAmount2() {
		return notionalAmount2;
	}

	/**
	 * @param notionalAmount2 the notionalAmount2 to set
	 */
	public void setNotionalAmount2(BigDecimal notionalAmount2) {
		this.notionalAmount2 = notionalAmount2;
	}

	/**
	 * @return the notionalCurrency2
	 */
	public String getNotionalCurrency2() {
		return notionalCurrency2;
	}

	/**
	 * @param notionalCurrency2 the notionalCurrency2 to set
	 */
	public void setNotionalCurrency2(String notionalCurrency2) {
		this.notionalCurrency2 = notionalCurrency2;
	}

	/**
	 * @return the collateralized
	 */
	public String getCollateralized() {
		return collateralized;
	}

	/**
	 * @param collateralized the collateralized to set
	 */
	public void setCollateralized(String collateralized) {
		this.collateralized = collateralized;
	}

	/**
	 * @return the exchangeRate
	 */
	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}

	/**
	 * @param exchangeRate the exchangeRate to set
	 */
	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	/**
	 * @return the settlementFixingDate
	 */
	public Date getSettlementFixingDate() {
		return settlementFixingDate;
	}

	/**
	 * @param settlementFixingDate the settlementFixingDate to set
	 */
	public void setSettlementFixingDate(Date settlementFixingDate) {
		this.settlementFixingDate = settlementFixingDate;
	}

	/**
	 * @return the settlementExpirationDate
	 */
	public Date getSettlementExpirationDate() {
		return settlementExpirationDate;
	}

	/**
	 * @param settlementExpirationDate the settlementExpirationDate to set
	 */
	public void setSettlementExpirationDate(Date settlementExpirationDate) {
		this.settlementExpirationDate = settlementExpirationDate;
	}

	/**
	 * @return the mandatoryClearingIndicator
	 */
	public String getMandatoryClearingIndicator() {
		return mandatoryClearingIndicator;
	}

	/**
	 * @param mandatoryClearingIndicator the mandatoryClearingIndicator to set
	 */
	public void setMandatoryClearingIndicator(String mandatoryClearingIndicator) {
		this.mandatoryClearingIndicator = mandatoryClearingIndicator;
	}

	/**
	 * @return the bloackTradeIndicator
	 */
	public String getBloackTradeIndicator() {
		return bloackTradeIndicator;
	}

	/**
	 * @param bloackTradeIndicator the bloackTradeIndicator to set
	 */
	public void setBloackTradeIndicator(String bloackTradeIndicator) {
		this.bloackTradeIndicator = bloackTradeIndicator;
	}

	/**
	 * @return the submissionTimestamp
	 */
	public String getSubmissionTimestamp() {
		return submissionTimestamp;
	}

	/**
	 * @param submissionTimestamp the submissionTimestamp to set
	 */
	public void setSubmissionTimestamp(String submissionTimestamp) {
		this.submissionTimestamp = submissionTimestamp;
	}

	/**
	 * @return the executionTimestamp
	 */
	public String getExecutionTimestamp() {
		return executionTimestamp;
	}

	/**
	 * @param executionTimestamp the executionTimestamp to set
	 */
	public void setExecutionTimestamp(String executionTimestamp) {
		this.executionTimestamp = executionTimestamp;
	}

	/**
	 * @return the usiPrefix
	 */
	public String getUsiPrefix() {
		return usiPrefix;
	}

	/**
	 * @param usiPrefix the usiPrefix to set
	 */
	public void setUsiPrefix(String usiPrefix) {
		this.usiPrefix = usiPrefix;
	}

	/**
	 * @return the additionalRepository1Prefix
	 */
	public String getAdditionalRepository1Prefix() {
		return additionalRepository1Prefix;
	}

	/**
	 * @param additionalRepository1Prefix the additionalRepository1Prefix to set
	 */
	public void setAdditionalRepository1Prefix(String additionalRepository1Prefix) {
		this.additionalRepository1Prefix = additionalRepository1Prefix;
	}

	/**
	 * @return the productIdPrefix
	 */
	public String getProductIdPrefix() {
		return productIdPrefix;
	}

	/**
	 * @param productIdPrefix the productIdPrefix to set
	 */
	public void setProductIdPrefix(String productIdPrefix) {
		this.productIdPrefix = productIdPrefix;
	}

	/**
	 * @return the productIdValue
	 */
	public String getProductIdValue() {
		return productIdValue;
	}

	/**
	 * @param productIdValue the productIdValue to set
	 */
	public void setProductIdValue(String productIdValue) {
		this.productIdValue = productIdValue;
	}

	/**
	 * @return the tradeParty1Role
	 */
	public String getTradeParty1Role() {
		return tradeParty1Role;
	}

	/**
	 * @param tradeParty1Role the tradeParty1Role to set
	 */
	public void setTradeParty1Role(String tradeParty1Role) {
		this.tradeParty1Role = tradeParty1Role;
	}

	/**
	 * @return the tradeParty2Role
	 */
	public String getTradeParty2Role() {
		return tradeParty2Role;
	}

	/**
	 * @param tradeParty2Role the tradeParty2Role to set
	 */
	public void setTradeParty2Role(String tradeParty2Role) {
		this.tradeParty2Role = tradeParty2Role;
	}

	/**
	 * @return the dataSubmitterLeiPrefix
	 */
	public String getDataSubmitterLeiPrefix() {
		return dataSubmitterLeiPrefix;
	}

	/**
	 * @param dataSubmitterLeiPrefix the dataSubmitterLeiPrefix to set
	 */
	public void setDataSubmitterLeiPrefix(String dataSubmitterLeiPrefix) {
		this.dataSubmitterLeiPrefix = dataSubmitterLeiPrefix;
	}

	/**
	 * @return the dataSubmitterLeiValue
	 */
	public String getDataSubmitterLeiValue() {
		return dataSubmitterLeiValue;
	}

	/**
	 * @param dataSubmitterLeiValue the dataSubmitterLeiValue to set
	 */
	public void setDataSubmitterLeiValue(String dataSubmitterLeiValue) {
		this.dataSubmitterLeiValue = dataSubmitterLeiValue;
	}

	/**
	 * @return the clearingExceptionPartyPrefix
	 */
	public String getClearingExceptionPartyPrefix() {
		return clearingExceptionPartyPrefix;
	}

	/**
	 * @param clearingExceptionPartyPrefix the clearingExceptionPartyPrefix to set
	 */
	public void setClearingExceptionPartyPrefix(String clearingExceptionPartyPrefix) {
		this.clearingExceptionPartyPrefix = clearingExceptionPartyPrefix;
	}

	/**
	 * @return the clearingExceptionPartyValue
	 */
	public String getClearingExceptionPartyValue() {
		return clearingExceptionPartyValue;
	}

	/**
	 * @param clearingExceptionPartyValue the clearingExceptionPartyValue to set
	 */
	public void setClearingExceptionPartyValue(String clearingExceptionPartyValue) {
		this.clearingExceptionPartyValue = clearingExceptionPartyValue;
	}

	/**
	 * @return the brokerLocationParty1
	 */
	public String getBrokerLocationParty1() {
		return brokerLocationParty1;
	}

	/**
	 * @param brokerLocationParty1 the brokerLocationParty1 to set
	 */
	public void setBrokerLocationParty1(String brokerLocationParty1) {
		this.brokerLocationParty1 = brokerLocationParty1;
	}

	/**
	 * @return the brokerLocationParty2
	 */
	public String getBrokerLocationParty2() {
		return brokerLocationParty2;
	}

	/**
	 * @param brokerLocationParty2 the brokerLocationParty2 to set
	 */
	public void setBrokerLocationParty2(String brokerLocationParty2) {
		this.brokerLocationParty2 = brokerLocationParty2;
	}

	/**
	 * @return the deskLocationParty1
	 */
	public String getDeskLocationParty1() {
		return deskLocationParty1;
	}

	/**
	 * @param deskLocationParty1 the deskLocationParty1 to set
	 */
	public void setDeskLocationParty1(String deskLocationParty1) {
		this.deskLocationParty1 = deskLocationParty1;
	}

	/**
	 * @return the deskLocationParty2
	 */
	public String getDeskLocationParty2() {
		return deskLocationParty2;
	}

	/**
	 * @param deskLocationParty2 the deskLocationParty2 to set
	 */
	public void setDeskLocationParty2(String deskLocationParty2) {
		this.deskLocationParty2 = deskLocationParty2;
	}

	/**
	 * @return the traderLocationParty1
	 */
	public String getTraderLocationParty1() {
		return traderLocationParty1;
	}

	/**
	 * @param traderLocationParty1 the traderLocationParty1 to set
	 */
	public void setTraderLocationParty1(String traderLocationParty1) {
		this.traderLocationParty1 = traderLocationParty1;
	}

	/**
	 * @return the traderLocationParty2
	 */
	public String getTraderLocationParty2() {
		return traderLocationParty2;
	}

	/**
	 * @param traderLocationParty2 the traderLocationParty2 to set
	 */
	public void setTraderLocationParty2(String traderLocationParty2) {
		this.traderLocationParty2 = traderLocationParty2;
	}

	/**
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the expirationTime
	 */
	public String getExpirationTime() {
		return expirationTime;
	}

	/**
	 * @param expirationTime the expirationTime to set
	 */
	public void setExpirationTime(String expirationTime) {
		this.expirationTime = expirationTime;
	}

	/**
	 * @return the tradeParty1Lei
	 */
	public String getTradeParty1Lei() {
		return tradeParty1Lei;
	}

	/**
	 * @param tradeParty1Lei the tradeParty1Lei to set
	 */
	public void setTradeParty1Lei(String tradeParty1Lei) {
		this.tradeParty1Lei = tradeParty1Lei;
	}

	/**
	 * @return the tradeParty2Lei
	 */
	public String getTradeParty2Lei() {
		return tradeParty2Lei;
	}

	/**
	 * @param tradeParty2Lei the tradeParty2Lei to set
	 */
	public void setTradeParty2Lei(String tradeParty2Lei) {
		this.tradeParty2Lei = tradeParty2Lei;
	}

	/**
	 * @return the party1Lei
	 */
	public String getParty1Lei() {
		return party1Lei;
	}

	/**
	 * @param party1Lei the party1Lei to set
	 */
	public void setParty1Lei(String party1Lei) {
		this.party1Lei = party1Lei;
	}

	/**
	 * @return the isParty1Sd
	 */
	public String getIsParty1Sd() {
		return isParty1Sd;
	}

	/**
	 * @param isParty1Sd the isParty1Sd to set
	 */
	public void setIsParty1Sd(String isParty1Sd) {
		this.isParty1Sd = isParty1Sd;
	}

	/**
	 * @return the isParty1Msp
	 */
	public String getIsParty1Msp() {
		return isParty1Msp;
	}

	/**
	 * @param isParty1Msp the isParty1Msp to set
	 */
	public void setIsParty1Msp(String isParty1Msp) {
		this.isParty1Msp = isParty1Msp;
	}

	/**
	 * @return the isParty1USPerson
	 */
	public String getIsParty1USPerson() {
		return isParty1USPerson;
	}

	/**
	 * @param isParty1USPerson the isParty1USPerson to set
	 */
	public void setIsParty1USPerson(String isParty1USPerson) {
		this.isParty1USPerson = isParty1USPerson;
	}

	/**
	 * @return the isParty2Sd
	 */
	public String getIsParty2Sd() {
		return isParty2Sd;
	}

	/**
	 * @param isParty2Sd the isParty2Sd to set
	 */
	public void setIsParty2Sd(String isParty2Sd) {
		this.isParty2Sd = isParty2Sd;
	}

	/**
	 * @return the isParty2Msp
	 */
	public String getIsParty2Msp() {
		return isParty2Msp;
	}

	/**
	 * @param isParty2Msp the isParty2Msp to set
	 */
	public void setIsParty2Msp(String isParty2Msp) {
		this.isParty2Msp = isParty2Msp;
	}

	/**
	 * @return the isParty2USPerson
	 */
	public String getIsParty2USPerson() {
		return isParty2USPerson;
	}

	/**
	 * @param isParty2USPerson the isParty2USPerson to set
	 */
	public void setIsParty2USPerson(String isParty2USPerson) {
		this.isParty2USPerson = isParty2USPerson;
	}

	/**
	 * @return the tradeParty1Prefix
	 */
	public String getTradeParty1Prefix() {
		return tradeParty1Prefix;
	}

	/**
	 * @param tradeParty1Prefix the tradeParty1Prefix to set
	 */
	public void setTradeParty1Prefix(String tradeParty1Prefix) {
		this.tradeParty1Prefix = tradeParty1Prefix;
	}

	/**
	 * @return the tradeParty1FinEnt
	 */
	public String getTradeParty1FinEnt() {
		return tradeParty1FinEnt;
	}

	/**
	 * @param tradeParty1FinEnt the tradeParty1FinEnt to set
	 */
	public void setTradeParty1FinEnt(String tradeParty1FinEnt) {
		this.tradeParty1FinEnt = tradeParty1FinEnt;
	}

	/**
	 * @return the tradeParty1UsPersonIndicator
	 */
	public String getTradeParty1UsPersonIndicator() {
		return tradeParty1UsPersonIndicator;
	}

	/**
	 * @param tradeParty1UsPersonIndicator the tradeParty1UsPersonIndicator to set
	 */
	public void setTradeParty1UsPersonIndicator(String tradeParty1UsPersonIndicator) {
		this.tradeParty1UsPersonIndicator = tradeParty1UsPersonIndicator;
	}

	/**
	 * @return the tradeParty2Prefix
	 */
	public String getTradeParty2Prefix() {
		return tradeParty2Prefix;
	}

	/**
	 * @param tradeParty2Prefix the tradeParty2Prefix to set
	 */
	public void setTradeParty2Prefix(String tradeParty2Prefix) {
		this.tradeParty2Prefix = tradeParty2Prefix;
	}

	/**
	 * @return the tradeParty2FinEnt
	 */
	public String getTradeParty2FinEnt() {
		return tradeParty2FinEnt;
	}

	/**
	 * @param tradeParty2FinEnt the tradeParty2FinEnt to set
	 */
	public void setTradeParty2FinEnt(String tradeParty2FinEnt) {
		this.tradeParty2FinEnt = tradeParty2FinEnt;
	}

	/**
	 * @return the tradeParty2UsPersonIndicator
	 */
	public String getTradeParty2UsPersonIndicator() {
		return tradeParty2UsPersonIndicator;
	}

	/**
	 * @param tradeParty2UsPersonIndicator the tradeParty2UsPersonIndicator to set
	 */
	public void setTradeParty2UsPersonIndicator(String tradeParty2UsPersonIndicator) {
		this.tradeParty2UsPersonIndicator = tradeParty2UsPersonIndicator;
	}

	/**
	 * @return the additionalRepository1Lei
	 */
	public String getAdditionalRepository1Lei() {
		return additionalRepository1Lei;
	}

	/**
	 * @param additionalRepository1Lei the additionalRepository1Lei to set
	 */
	public void setAdditionalRepository1Lei(String additionalRepository1Lei) {
		this.additionalRepository1Lei = additionalRepository1Lei;
	}

	/**
	 * @return the exchangeCurrency1
	 */
	public String getExchangeCurrency1() {
		return exchangeCurrency1;
	}

	/**
	 * @param exchangeCurrency1 the exchangeCurrency1 to set
	 */
	public void setExchangeCurrency1(String exchangeCurrency1) {
		this.exchangeCurrency1 = exchangeCurrency1;
	}

	/**
	 * @return the exchangeCurrency2
	 */
	public String getExchangeCurrency2() {
		return exchangeCurrency2;
	}

	/**
	 * @param exchangeCurrency2 the exchangeCurrency2 to set
	 */
	public void setExchangeCurrency2(String exchangeCurrency2) {
		this.exchangeCurrency2 = exchangeCurrency2;
	}

	/**
	 * @return the exchangeCurrency1Amount
	 */
	public BigDecimal getExchangeCurrency1Amount() {
		return exchangeCurrency1Amount;
	}

	/**
	 * @param exchangeCurrency1Amount the exchangeCurrency1Amount to set
	 */
	public void setExchangeCurrency1Amount(BigDecimal exchangeCurrency1Amount) {
		this.exchangeCurrency1Amount = exchangeCurrency1Amount;
	}

	/**
	 * @return the exchangeCurrency2Amount
	 */
	public BigDecimal getExchangeCurrency2Amount() {
		return exchangeCurrency2Amount;
	}

	/**
	 * @param exchangeCurrency2Amount the exchangeCurrency2Amount to set
	 */
	public void setExchangeCurrency2Amount(BigDecimal exchangeCurrency2Amount) {
		this.exchangeCurrency2Amount = exchangeCurrency2Amount;
	}

	/**
	 * @return the exoticExpirationDate
	 */
	public Date getExoticExpirationDate() {
		return exoticExpirationDate;
	}

	/**
	 * @param exoticExpirationDate the exoticExpirationDate to set
	 */
	public void setExoticExpirationDate(Date exoticExpirationDate) {
		this.exoticExpirationDate = exoticExpirationDate;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the cftcProductId
	 */
	public String getCftcProductId() {
		return cftcProductId;
	}

	/**
	 * @param cftcProductId the cftcProductId to set
	 */
	public void setCftcProductId(String cftcProductId) {
		this.cftcProductId = cftcProductId;
	}

	/**
	 * @return the sdrInternalProductId
	 */
	public String getSdrInternalProductId() {
		return sdrInternalProductId;
	}

	/**
	 * @param sdrInternalProductId the sdrInternalProductId to set
	 */
	public void setSdrInternalProductId(String sdrInternalProductId) {
		this.sdrInternalProductId = sdrInternalProductId;
	}

	/**
	 * @return the isMultiassetSwap
	 */
	public String getIsMultiassetSwap() {
		return isMultiassetSwap;
	}

	/**
	 * @param isMultiassetSwap the isMultiassetSwap to set
	 */
	public void setIsMultiassetSwap(String isMultiassetSwap) {
		this.isMultiassetSwap = isMultiassetSwap;
	}

	/**
	 * @return the isMixedSwap
	 */
	public String getIsMixedSwap() {
		return isMixedSwap;
	}

	/**
	 * @param isMixedSwap the isMixedSwap to set
	 */
	public void setIsMixedSwap(String isMixedSwap) {
		this.isMixedSwap = isMixedSwap;
	}

	/**
	 * @return the sdr2Id
	 */
	public String getSdr2Id() {
		return sdr2Id;
	}

	/**
	 * @param sdr2Id the sdr2Id to set
	 */
	public void setSdr2Id(String sdr2Id) {
		this.sdr2Id = sdr2Id;
	}

	/**
	 * @return the contractType
	 */
	public String getContractType() {
		return contractType;
	}

	/**
	 * @param contractType the contractType to set
	 */
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	/**
	 * @return the deliveryType
	 */
	public String getDeliveryType() {
		return deliveryType;
	}

	/**
	 * @param deliveryType the deliveryType to set
	 */
	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	/**
	 * @return the sdrSubmisionTimestamp
	 */
	public String getSdrSubmisionTimestamp() {
		return sdrSubmisionTimestamp;
	}

	/**
	 * @param sdrSubmisionTimestamp the sdrSubmisionTimestamp to set
	 */
	public void setSdrSubmisionTimestamp(String sdrSubmisionTimestamp) {
		this.sdrSubmisionTimestamp = sdrSubmisionTimestamp;
	}

	/**
	 * @return the clearingVenue
	 */
	public String getClearingVenue() {
		return clearingVenue;
	}

	/**
	 * @param clearingVenue the clearingVenue to set
	 */
	public void setClearingVenue(String clearingVenue) {
		this.clearingVenue = clearingVenue;
	}

	/**
	 * @return the isClearingReqExc
	 */
	public String getIsClearingReqExc() {
		return isClearingReqExc;
	}

	/**
	 * @param isClearingReqExc the isClearingReqExc to set
	 */
	public void setIsClearingReqExc(String isClearingReqExc) {
		this.isClearingReqExc = isClearingReqExc;
	}

	/**
	 * @return the mtmPositionValue
	 */
	public String getMtmPositionValue() {
		return mtmPositionValue;
	}

	/**
	 * @param mtmPositionValue the mtmPositionValue to set
	 */
	public void setMtmPositionValue(String mtmPositionValue) {
		this.mtmPositionValue = mtmPositionValue;
	}

	/**
	 * @return the systemDerivedReportingParty
	 */
	public String getSystemDerivedReportingParty() {
		return systemDerivedReportingParty;
	}

	/**
	 * @param systemDerivedReportingParty the systemDerivedReportingParty to set
	 */
	public void setSystemDerivedReportingParty(String systemDerivedReportingParty) {
		this.systemDerivedReportingParty = systemDerivedReportingParty;
	}

	/**
	 * @return the reportingParty
	 */
	public String getReportingParty() {
		return reportingParty;
	}

	/**
	 * @param reportingParty the reportingParty to set
	 */
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}

	/**
	 * @return the party2Lei
	 */
	public String getParty2Lei() {
		return party2Lei;
	}

	/**
	 * @param party2Lei the party2Lei to set
	 */
	public void setParty2Lei(String party2Lei) {
		this.party2Lei = party2Lei;
	}

	public String getCcy1() {
		return ccy1;
	}

	public void setCcy1(String ccy1) {
		this.ccy1 = ccy1;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public void setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
	}

	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getSettlementCurrency() {
		return settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}

	
	
}
