package com.wf.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

import com.wf.portrec.domain.annotation.UseForMatching;

@Entity
@Table(name = "pr_rates")
public class IRTrade extends Trade {
	
	@Id
	@Column(name = "id")
	@TableGenerator(name="pr_rates_id_generator", table="pr_id_sequence", allocationSize=200,
			pkColumnName="seq_name", pkColumnValue="pr_rates_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator="pr_rates_id_generator")
	Long id;
	
	

	@Column(name = "orig_trade_id")
	String origTradeId = "";

	@Column(name = "usi")
	String usi = "";

	@Column(name = "usi_namespace")
	String usiNamespace = "";
	
	
	@Column(name = "asset_class")
	String assetClass = "";

	
	@Column(name = "product_type")
	String productType = "";

	@UseForMatching
	@Column(name = "trade_date")
	Date tradeDate;

	
	@Column(name = "maturity_date")
	Date maturityDate;

	// TODO: AZ - we may not need this field
	@Column(name = "verification_status")
	String verificationStatus = "";

	// TODO: AZ - we may not need this field
	@Column(name = "trade_party1")
	String tradeParty1 = "";

	@Column(name = "trade_party2")
	String tradeParty2 = "";

	@UseForMatching
	@Column(name = "notional_amount_party")
	BigDecimal notionalAmountParty;

	
	@Column(name = "notional_currency_party")
	String notionalCurrencyParty = "";

	@UseForMatching
	@Column(name = "notional_amount_cpty")
	BigDecimal notionalAmountCpty;

	
	@Column(name = "notional_currency_cpty")
	String notionalCurrencyCpty = "";

	
	@Column(name = "float_fix_party")
	String rate1 = ""; // This could be Floating Rate Index 1 or Fixed
						// Rate Party

	
	@Column(name = "float_fix_cpty")
	String rate2 = ""; // This could be Floating Rate Index 2/Fixed Rate
						// Cpty

	
	@Column(name = "buyer")
	String buyer = "";

	
	@Column(name = "seller")
	String seller = "";

	@Column(name="submitted_for")
	String submittedFor;
	
	@Column(name="data_submitter")
	String dataSubmitter = "";
	
	@Column(name="trade_type_indicator")
	String tradeTypeIndicator;
	
	@Column(name="execution_date")
	Date executionDate;
	
	@Transient
	String tradeParty2LeiTransient;
	
	@Column(name="trade_party_lei_1")
	String tradeParty1Lei = "";
	
	@Column(name="trade_party_role_1")
	String tradeParty1Role = "";
	
	@Column(name="trade_party_role_2")
	String tradeParty2Role = "";	
	
	@Column(name="trade_party_1_financial_entity")
	String tradeParty1financialEntityStatus = "";
	
	@Column(name="trade_party_2_financial_entity")
	String tradeParty2financialEntityStatus = "";
	
	@Column(name="trade_party_1_usperson_indicator")
	String tradeParty1UsPersonIndicator = "";
	
	@Column(name="trade_party_2_usperson_indicator")
	String tradeParty2UsPersonIndicator = "";
	
	@Column(name = "sec_asset_class")
	String secAssetClass = "";
	
	@Column(name="reporting_jurisdiction")
	String reportingJurisdiction = "";
	
	@Column(name="additional_repository_1")
	String additionalRepository1 = "";
	
	@Column(name="execution_venue")
	String executionVenue = "";	
	
	
	@Column(name="effective_date_leg_1")
	Date effectiveDateLeg1;
	
	@Column(name="effective_date_leg_2")
	Date effectiveDateLeg2;
	
	@Column(name="termination_date_leg_1")
	Date terminationDateLeg1;
	
	@Column(name="termination_date_leg_2")
	Date terminationDateLeg2;
	
	@Column(name = "day_count_fraction_leg_1")
	String dayCountFractionLeg1 = "";
	
	@Column(name = "day_count_fraction_leg_2")
	String dayCountFractionLeg2 = "";
	
	@Column(name = "exotic_notional_amount_leg_1")
	BigDecimal exoticNotionalAmountLeg1;
	
	@Column(name = "exotic_notional_amount_leg_2")
	BigDecimal exoticNotionalAmountLeg2;
	
	@Column(name="exotic_settlement_curr")
	String exoticSettlementCurrencyLeg2 = "";
	
	@Column(name="leg_1_payer")
	String leg1Payer = "";
	
	@Column(name="leg_2_payer")
	String leg2Payer = "";
	
	@Column(name="option_type")
	String optionType = "";
	
	@Column(name = "fixed_rate_initial_leg_1")
	BigDecimal fixedRateInitialLeg1;
	
	@Column(name = "fixed_rate_initial_leg_2")
	BigDecimal fixedRateInitialLeg2;
	
	@Column(name="payment_freq_period_leg_1")
	String paymentFreqPeriodleg1 = "";
	
	@Column(name="payment_freq_period_leg_2")
	String paymentFreqPeriodleg2 = "";
	
	@Column(name="payment_freq_period_multiplier_leg_1")
	String paymentFreqPeriodMultiplierleg1 = "";
	
	@Column(name="payment_freq_period_multiplier_leg_2")
	String paymentFreqPeriodMultiplierleg2 = "";
	
	@Column(name="reset_freq_period_leg_1")
	String resetFreqPeriodleg1 = "";
	
	@Column(name="reset_freq_period_leg_2")
	String resetFreqPeriodleg2 = "";
	
	@Column(name="reset_freq_period_multiplier_leg_1")
	String resetFreqPeriodMultiplierleg1 = "";
	
	@Column(name="reset_freq_period_multiplier_leg_2")
	String resetFreqPeriodMultiplierleg2 = "";
	
	@Column(name = "floating_rate_index_leg_1")
	String floatingRateIndexLeg1;
	
	@Column(name = "floating_rate_index_leg_2")
	String floatingRateIndexLeg2;
	
	@Column(name="exotic_underlying_asset")
	String exoticUnderlyingAsset = "";
	
	@Column(name="collaterlized")
	String collaterlized = "";
	
	@Column(name="msg_type")
	String msgType = "";
	
	@Column(name="revision_id")
	Integer revisionId;
	
	
	@Column(name="run_date")
	Date runDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	public String getOrigTradeId() {
		return origTradeId;
	}

	public void setOrigTradeId(String origTradeId) {
		this.origTradeId = origTradeId;
	}

	public String getUsi() {
		return usi;
	}

	public void setUsi(String usi) {
		this.usi = usi;
	}

	public String getUsiNamespace() {
		return usiNamespace;
	}

	public void setUsiNamespace(String usiNamespace) {
		this.usiNamespace = usiNamespace;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getTradeParty1() {
		return tradeParty1;
	}

	public void setTradeParty1(String tradeParty1) {
		this.tradeParty1 = tradeParty1;
	}

	public String getTradeParty2() {
		return tradeParty2;
	}

	public void setTradeParty2(String tradeParty2) {
		this.tradeParty2 = tradeParty2;
	}

	public String getNotionalCurrencyParty() {
		return notionalCurrencyParty;
	}

	public void setNotionalCurrencyParty(String notionalCurrencyParty) {
		this.notionalCurrencyParty = notionalCurrencyParty;
	}


	public String getNotionalCurrencyCpty() {
		return notionalCurrencyCpty;
	}

	public void setNotionalCurrencyCpty(String notionalCurrencyCpty) {
		this.notionalCurrencyCpty = notionalCurrencyCpty;
	}

	public String getRate1() {
		return rate1;
	}

	public void setRate1(String rate1) {
		this.rate1 = rate1;
	}

	public String getRate2() {
		return rate2;
	}

	public void setRate2(String rate2) {
		this.rate2 = rate2;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	/**
	 * @return the submittedFor
	 */
	public String getSubmittedFor() {
		return submittedFor;
	}

	/**
	 * @param submittedFor the submittedFor to set
	 */
	public void setSubmittedFor(String submittedFor) {
		this.submittedFor = submittedFor;
	}

	public String getDataSubmitter() {
		return dataSubmitter;
	}

	public void setDataSubmitter(String dataSubmitter) {
		this.dataSubmitter = dataSubmitter;
	}

	/**
	 * @return the notionalAmountParty
	 */
	public BigDecimal getNotionalAmountParty() {
		return notionalAmountParty;
	}

	/**
	 * @param notionalAmountParty the notionalAmountParty to set
	 */
	public void setNotionalAmountParty(BigDecimal notionalAmountParty) {
		this.notionalAmountParty = notionalAmountParty;
	}

	/**
	 * @return the notionalAmountCpty
	 */
	public BigDecimal getNotionalAmountCpty() {
		return notionalAmountCpty;
	}

	/**
	 * @param notionalAmountCpty the notionalAmountCpty to set
	 */
	public void setNotionalAmountCpty(BigDecimal notionalAmountCpty) {
		this.notionalAmountCpty = notionalAmountCpty;
	}

	public String getTradeTypeIndicator() {
		return tradeTypeIndicator;
	}

	public void setTradeTypeIndicator(String tradeTypeIndicator) {
		this.tradeTypeIndicator = tradeTypeIndicator;
	}

	public Date getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(Date executionDate) {
		this.executionDate = executionDate;
	}

	public String getTradeParty2LeiTransient() {
		return tradeParty2LeiTransient;
	}

	public void setTradeParty2LeiTransient(String tradeParty2Lei) {
		this.tradeParty2LeiTransient = tradeParty2Lei;
	}

	public String getTradeParty1Lei() {
		return tradeParty1Lei;
	}

	public void setTradeParty1Lei(String tradeParty1Lei) {
		this.tradeParty1Lei = tradeParty1Lei;
	}

	public String getTradeParty1Role() {
		return tradeParty1Role;
	}

	public void setTradeParty1Role(String tradeParty1Role) {
		this.tradeParty1Role = tradeParty1Role;
	}

	public String getTradeParty2Role() {
		return tradeParty2Role;
	}

	public void setTradeParty2Role(String tradeParty2Role) {
		this.tradeParty2Role = tradeParty2Role;
	}

	public String getTradeParty1financialEntityStatus() {
		return tradeParty1financialEntityStatus;
	}

	public void setTradeParty1financialEntityStatus(
			String tradeParty1financialEntityStatus) {
		this.tradeParty1financialEntityStatus = tradeParty1financialEntityStatus;
	}

	public String getTradeParty2financialEntityStatus() {
		return tradeParty2financialEntityStatus;
	}

	public void setTradeParty2financialEntityStatus(
			String tradeParty2financialEntityStatus) {
		this.tradeParty2financialEntityStatus = tradeParty2financialEntityStatus;
	}

	public String getTradeParty1UsPersonIndicator() {
		return tradeParty1UsPersonIndicator;
	}

	public void setTradeParty1UsPersonIndicator(String tradeParty1UsPersonIndicator) {
		this.tradeParty1UsPersonIndicator = tradeParty1UsPersonIndicator;
	}

	public String getTradeParty2UsPersonIndicator() {
		return tradeParty2UsPersonIndicator;
	}

	public void setTradeParty2UsPersonIndicator(String tradeParty2UsPersonIndicator) {
		this.tradeParty2UsPersonIndicator = tradeParty2UsPersonIndicator;
	}

	public String getSecAssetClass() {
		return secAssetClass;
	}

	public void setSecAssetClass(String secAssetClass) {
		this.secAssetClass = secAssetClass;
	}

	public String getReportingJurisdiction() {
		return reportingJurisdiction;
	}

	public void setReportingJurisdiction(String reportingJurisdiction) {
		this.reportingJurisdiction = reportingJurisdiction;
	}

	public String getAdditionalRepository1() {
		return additionalRepository1;
	}

	public void setAdditionalRepository1(String additionalRepository1) {
		this.additionalRepository1 = additionalRepository1;
	}

	public String getExecutionVenue() {
		return executionVenue;
	}

	public void setExecutionVenue(String executionVenue) {
		this.executionVenue = executionVenue;
	}

	public Date getEffectiveDateLeg1() {
		return effectiveDateLeg1;
	}

	public void setEffectiveDateLeg1(Date effectiveDateLeg1) {
		this.effectiveDateLeg1 = effectiveDateLeg1;
	}

	public Date getEffectiveDateLeg2() {
		return effectiveDateLeg2;
	}

	public void setEffectiveDateLeg2(Date effectiveDateLeg2) {
		this.effectiveDateLeg2 = effectiveDateLeg2;
	}

	public Date getTerminationDateLeg1() {
		return terminationDateLeg1;
	}

	public void setTerminationDateLeg1(Date terminationDateLeg1) {
		this.terminationDateLeg1 = terminationDateLeg1;
	}

	public Date getTerminationDateLeg2() {
		return terminationDateLeg2;
	}

	public void setTerminationDateLeg2(Date terminationDateLeg2) {
		this.terminationDateLeg2 = terminationDateLeg2;
	}

	public String getDayCountFractionLeg1() {
		return dayCountFractionLeg1;
	}

	public void setDayCountFractionLeg1(String dayCountFractionLeg1) {
		this.dayCountFractionLeg1 = dayCountFractionLeg1;
	}

	public String getDayCountFractionLeg2() {
		return dayCountFractionLeg2;
	}

	public void setDayCountFractionLeg2(String dayCountFractionLeg2) {
		this.dayCountFractionLeg2 = dayCountFractionLeg2;
	}

	public BigDecimal getExoticNotionalAmountLeg1() {
		return exoticNotionalAmountLeg1;
	}

	public void setExoticNotionalAmountLeg1(BigDecimal exoticNotionalAmountLeg1) {
		this.exoticNotionalAmountLeg1 = exoticNotionalAmountLeg1;
	}

	public BigDecimal getExoticNotionalAmountLeg2() {
		return exoticNotionalAmountLeg2;
	}

	public void setExoticNotionalAmountLeg2(BigDecimal exoticNotionalAmountLeg2) {
		this.exoticNotionalAmountLeg2 = exoticNotionalAmountLeg2;
	}

	public String getExoticSettlementCurrencyLeg2() {
		return exoticSettlementCurrencyLeg2;
	}

	public void setExoticSettlementCurrencyLeg2(String exoticSettlementCurrencyLeg2) {
		this.exoticSettlementCurrencyLeg2 = exoticSettlementCurrencyLeg2;
	}

	public String getLeg1Payer() {
		return leg1Payer;
	}

	public void setLeg1Payer(String leg1Payer) {
		this.leg1Payer = leg1Payer;
	}

	public String getLeg2Payer() {
		return leg2Payer;
	}

	public void setLeg2Payer(String leg2Payer) {
		this.leg2Payer = leg2Payer;
	}

	public String getOptionType() {
		return optionType;
	}

	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}

	public BigDecimal getFixedRateInitialLeg1() {
		return fixedRateInitialLeg1;
	}

	public void setFixedRateInitialLeg1(BigDecimal fixedRateInitialLeg1) {
		this.fixedRateInitialLeg1 = fixedRateInitialLeg1;
	}

	public BigDecimal getFixedRateInitialLeg2() {
		return fixedRateInitialLeg2;
	}

	public void setFixedRateInitialLeg2(BigDecimal fixedRateInitialLeg2) {
		this.fixedRateInitialLeg2 = fixedRateInitialLeg2;
	}

	public String getPaymentFreqPeriodleg1() {
		return paymentFreqPeriodleg1;
	}

	public void setPaymentFreqPeriodleg1(String paymentFreqPeriodleg1) {
		this.paymentFreqPeriodleg1 = paymentFreqPeriodleg1;
	}

	public String getPaymentFreqPeriodleg2() {
		return paymentFreqPeriodleg2;
	}

	public void setPaymentFreqPeriodleg2(String paymentFreqPeriodleg2) {
		this.paymentFreqPeriodleg2 = paymentFreqPeriodleg2;
	}

	public String getPaymentFreqPeriodMultiplierleg1() {
		return paymentFreqPeriodMultiplierleg1;
	}

	public void setPaymentFreqPeriodMultiplierleg1(
			String paymentFreqPeriodMultiplierleg1) {
		this.paymentFreqPeriodMultiplierleg1 = paymentFreqPeriodMultiplierleg1;
	}

	public String getPaymentFreqPeriodMultiplierleg2() {
		return paymentFreqPeriodMultiplierleg2;
	}

	public void setPaymentFreqPeriodMultiplierleg2(
			String paymentFreqPeriodMultiplierleg2) {
		this.paymentFreqPeriodMultiplierleg2 = paymentFreqPeriodMultiplierleg2;
	}

	public String getFloatingRateIndexLeg1() {
		return floatingRateIndexLeg1;
	}

	public void setFloatingRateIndexLeg1(String floatingRateIndexLeg1) {
		this.floatingRateIndexLeg1 = floatingRateIndexLeg1;
	}

	public String getFloatingRateIndexLeg2() {
		return floatingRateIndexLeg2;
	}

	public void setFloatingRateIndexLeg2(String floatingRateIndexLeg2) {
		this.floatingRateIndexLeg2 = floatingRateIndexLeg2;
	}

	public String getExoticUnderlyingAsset() {
		return exoticUnderlyingAsset;
	}

	public void setExoticUnderlyingAsset(String exoticUnderlyingAsset) {
		this.exoticUnderlyingAsset = exoticUnderlyingAsset;
	}

	public String getCollaterlized() {
		return collaterlized;
	}

	public void setCollaterlized(String collaterlized) {
		this.collaterlized = collaterlized;
	}

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	public String getResetFreqPeriodleg1() {
		return resetFreqPeriodleg1;
	}

	public void setResetFreqPeriodleg1(String resetFreqPeriodleg1) {
		this.resetFreqPeriodleg1 = resetFreqPeriodleg1;
	}

	public String getResetFreqPeriodleg2() {
		return resetFreqPeriodleg2;
	}

	public void setResetFreqPeriodleg2(String resetFreqPeriodleg2) {
		this.resetFreqPeriodleg2 = resetFreqPeriodleg2;
	}

	public String getResetFreqPeriodMultiplierleg1() {
		return resetFreqPeriodMultiplierleg1;
	}

	public void setResetFreqPeriodMultiplierleg1(
			String resetFreqPeriodMultiplierleg1) {
		this.resetFreqPeriodMultiplierleg1 = resetFreqPeriodMultiplierleg1;
	}

	public String getResetFreqPeriodMultiplierleg2() {
		return resetFreqPeriodMultiplierleg2;
	}

	public void setResetFreqPeriodMultiplierleg2(
			String resetFreqPeriodMultiplierleg2) {
		this.resetFreqPeriodMultiplierleg2 = resetFreqPeriodMultiplierleg2;
	}

	public Integer getRevisionId() {
		return revisionId;
	}

	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}

	

}
