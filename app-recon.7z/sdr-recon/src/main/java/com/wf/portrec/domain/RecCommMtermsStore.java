package com.wf.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// TODO: Auto-generated Javadoc
/**
 * The Class RecCommMtermsStore.
 */
@Entity
@Table(name = "rec_comm_mterms_store")
public class RecCommMtermsStore 
{
	
	/** The send id. */
	@Id
	@Column(name = "send_id")
	protected BigDecimal sendId;

	/** The qty units. */
	@Column(name = "qty_units")
	protected String qtyUnits;

	/** The qty num of units. */
	@Column(name = "qty_num_of_units")
	protected String qtyNumOfUnits;

	/** The qty freq. */
	@Column(name = "qty_freq")
	protected String qtyFreq;

	/** The qty total. */
	@Column(name = "qty_total")
	protected String qtyTotal;

	/** The settle method. */
	@Column(name = "settle_method")
	protected String settleMethod;

	/** The price. */
	@Column(name = "price")
	protected String price;

	/** The price units. */
	@Column(name = "price_units")
	protected String priceUnits;

	/** The price curr. */
	@Column(name = "price_curr")
	protected String priceCurr;

	/** The buyer index. */
	@Column(name = "buyer_index")
	protected String buyerIndex;

	/** The buyer index avg method. */
	@Column(name = "buyer_index_avg_method")
	protected String buyerIndexAvgMethod;

	/** The seller index. */
	@Column(name = "seller_index")
	protected String sellerIndex;

	/** The seller index avg method. */
	@Column(name = "seller_index_avg_method")
	protected String sellerIndexAvgMethod;

	/** The grade. */
	@Column(name = "grade")
	protected String grade;

	/** The option type. */
	@Column(name = "option_type")
	protected String optionType;

	/** The option style. */
	@Column(name = "option_style")
	protected String optionStyle;

	/** The option premium. */
	@Column(name = "option_premium")
	protected String optionPremium;

	/** The hrs from thru. */
	@Column(name = "hrs_from_thru")
	protected String hrsFromThru;

	/** The hrs from thru tz. */
	@Column(name = "hrs_from_thru_tz")
	protected String hrsFromThruTz;

	/** The days week. */
	@Column(name = "days_week")
	protected String daysWeek;

	/** The load type. */
	@Column(name = "load_type")
	protected String loadType;
	
	/** The status. */
	@Column(name="status")
	protected String status;

	/** The usi or uti. */
	@Column(name="usi_or_uti")
	protected String usiOrUti;

	/** The usi or uti alt. */
	@Column(name="usi_or_uti_alt")
	protected String usiOrUtiAlt;

	/** The rep party lei name. */
	@Column(name="rep_party_lei_name")
	protected String repPartyLeiName;

	/** The rep party lei name alt. */
	@Column(name="rep_party_lei_name_alt")
	protected String repPartyLeiNameAlt;

	/** The rep party entity. */
	@Column(name="rep_party_entity")
	protected String repPartyEntity;

	/** The rep party us person. */
	@Column(name="rep_party_us_person")
	protected String repPartyUsPerson;

	/** The non rep party lei name. */
	@Column(name="non_rep_party_lei_name")
	protected String nonRepPartyLeiName;

	/** The non rep party lei name alt. */
	@Column(name="non_rep_party_lei_name_alt")
	protected String nonRepPartyLeiNameAlt;

	/** The non rep party entity. */
	@Column(name="non_rep_party_entity")
	protected String nonRepPartyEntity;

	/** The non rep party us person. */
	@Column(name="non_rep_party_us_person")
	protected String nonRepPartyUsPerson;

	/** The upi. */
	@Column(name="upi")
	protected String upi;

	/** The upi alt. */
	@Column(name="upi_alt")
	protected String upiAlt;

	/** The upi sdr. */
	@Column(name="upi_sdr")
	protected String upiSdr;

	/** The multi asset flag. */
	@Column(name="multi_asset_flag")
	protected String multiAssetFlag;

	/** The asset class. */
	@Column(name="asset_class")
	protected String assetClass;

	/** The asset alternates. */
	@Column(name="asset_alternates")
	protected String assetAlternates;

	/** The mixed asset flag. */
	@Column(name="mixed_asset_flag")
	protected String mixedAssetFlag;

	/** The multi sdr. */
	@Column(name="multi_sdr")
	protected String multiSdr;

	/** The multi sdr ids. */
	@Column(name="multi_sdr_ids")
	protected String multiSdrIds;
	
	/** The cont type. */
	@Column(name="cont_type")
	protected String contType;
	
	/** The exec venue. */
	@Column(name="exec_venue")
	protected String execVenue;

	/** The effective date. */
	@Column(name="effective_date")
	protected Date effectiveDate;

	/** The maturity date. */
	@Column(name="maturity_date")
	protected Date maturityDate;

	/** The buyer. */
	@Column(name="buyer")
	protected String buyer;

	/** The seller. */
	@Column(name="seller")
	protected String seller;

	/** The buyer alt. */
	@Column(name="buyer_alt")
	protected String buyerAlt;

	/** The seller alt. */
	@Column(name="seller_alt")
	protected String sellerAlt;

	/** The collateral ind. */
	@Column(name="collateral_ind")
	protected String collateralInd;

	/** The create datetime. */
	@Column(name = "create_datetime")
	protected Date createDatetime;

	/** The update datetime. */
	@Column(name = "update_datetime")
	protected Date updateDatetime;

	/**
	 * Method 'RecCommMterms'.
	 */
	public RecCommMtermsStore() {
	}

	/**
	 * Method 'getSendId'.
	 *
	 * @return BigDecimal
	 */
	public BigDecimal getSendId() {
		return sendId;
	}

	/**
	 * Method 'setSendId'.
	 *
	 * @param sendId the new send id
	 */
	public void setSendId(BigDecimal sendId) {
		this.sendId = sendId;
	}

	/**
	 * Method 'getQtyUnits'.
	 *
	 * @return String
	 */
	public String getQtyUnits() {
		return qtyUnits;
	}

	/**
	 * Method 'setQtyUnits'.
	 *
	 * @param qtyUnits the new qty units
	 */
	public void setQtyUnits(String qtyUnits) {
		this.qtyUnits = qtyUnits;
	}

	/**
	 * Method 'getQtyNumOfUnits'.
	 *
	 * @return String
	 */
	public String getQtyNumOfUnits() {
		return qtyNumOfUnits;
	}

	/**
	 * Method 'setQtyNumOfUnits'.
	 *
	 * @param qtyNumOfUnits the new qty num of units
	 */
	public void setQtyNumOfUnits(String qtyNumOfUnits) {
		this.qtyNumOfUnits = qtyNumOfUnits;
	}

	/**
	 * Method 'getQtyFreq'.
	 *
	 * @return String
	 */
	public String getQtyFreq() {
		return qtyFreq;
	}

	/**
	 * Method 'setQtyFreq'.
	 *
	 * @param qtyFreq the new qty freq
	 */
	public void setQtyFreq(String qtyFreq) {
		this.qtyFreq = qtyFreq;
	}

	/**
	 * Method 'getQtyTotal'.
	 *
	 * @return String
	 */
	public String getQtyTotal() {
		return qtyTotal;
	}

	/**
	 * Method 'setQtyTotal'.
	 *
	 * @param qtyTotal the new qty total
	 */
	public void setQtyTotal(String qtyTotal) {
		this.qtyTotal = qtyTotal;
	}

	/**
	 * Method 'getSettleMethod'.
	 *
	 * @return String
	 */
	public String getSettleMethod() {
		return settleMethod;
	}

	/**
	 * Method 'setSettleMethod'.
	 *
	 * @param settleMethod the new settle method
	 */
	public void setSettleMethod(String settleMethod) {
		this.settleMethod = settleMethod;
	}

	/**
	 * Method 'getPrice'.
	 *
	 * @return String
	 */
	public String getPrice() {
		return price;
	}

	/**
	 * Method 'setPrice'.
	 *
	 * @param price the new price
	 */
	public void setPrice(String price) {
		this.price = price;
	}

	/**
	 * Method 'getPriceUnits'.
	 *
	 * @return String
	 */
	public String getPriceUnits() {
		return priceUnits;
	}

	/**
	 * Method 'setPriceUnits'.
	 *
	 * @param priceUnits the new price units
	 */
	public void setPriceUnits(String priceUnits) {
		this.priceUnits = priceUnits;
	}

	/**
	 * Method 'getPriceCurr'.
	 *
	 * @return String
	 */
	public String getPriceCurr() {
		return priceCurr;
	}

	/**
	 * Method 'setPriceCurr'.
	 *
	 * @param priceCurr the new price curr
	 */
	public void setPriceCurr(String priceCurr) {
		this.priceCurr = priceCurr;
	}

	/**
	 * Method 'getBuyerIndex'.
	 *
	 * @return String
	 */
	public String getBuyerIndex() {
		return buyerIndex;
	}

	/**
	 * Method 'setBuyerIndex'.
	 *
	 * @param buyerIndex the new buyer index
	 */
	public void setBuyerIndex(String buyerIndex) {
		this.buyerIndex = buyerIndex;
	}

	/**
	 * Method 'getBuyerIndexAvgMethod'.
	 *
	 * @return String
	 */
	public String getBuyerIndexAvgMethod() {
		return buyerIndexAvgMethod;
	}

	/**
	 * Method 'setBuyerIndexAvgMethod'.
	 *
	 * @param buyerIndexAvgMethod the new buyer index avg method
	 */
	public void setBuyerIndexAvgMethod(String buyerIndexAvgMethod) {
		this.buyerIndexAvgMethod = buyerIndexAvgMethod;
	}

	/**
	 * Method 'getSellerIndex'.
	 *
	 * @return String
	 */
	public String getSellerIndex() {
		return sellerIndex;
	}

	/**
	 * Method 'setSellerIndex'.
	 *
	 * @param sellerIndex the new seller index
	 */
	public void setSellerIndex(String sellerIndex) {
		this.sellerIndex = sellerIndex;
	}

	/**
	 * Method 'getSellerIndexAvgMethod'.
	 *
	 * @return String
	 */
	public String getSellerIndexAvgMethod() {
		return sellerIndexAvgMethod;
	}

	/**
	 * Method 'setSellerIndexAvgMethod'.
	 *
	 * @param sellerIndexAvgMethod the new seller index avg method
	 */
	public void setSellerIndexAvgMethod(String sellerIndexAvgMethod) {
		this.sellerIndexAvgMethod = sellerIndexAvgMethod;
	}

	/**
	 * Method 'getGrade'.
	 *
	 * @return String
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * Method 'setGrade'.
	 *
	 * @param grade the new grade
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}

	/**
	 * Method 'getOptionType'.
	 *
	 * @return String
	 */
	public String getOptionType() {
		return optionType;
	}

	/**
	 * Method 'setOptionType'.
	 *
	 * @param optionType the new option type
	 */
	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}

	/**
	 * Method 'getOptionStyle'.
	 *
	 * @return String
	 */
	public String getOptionStyle() {
		return optionStyle;
	}

	/**
	 * Method 'setOptionStyle'.
	 *
	 * @param optionStyle the new option style
	 */
	public void setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
	}

	/**
	 * Method 'getOptionPremium'.
	 *
	 * @return String
	 */
	public String getOptionPremium() {
		return optionPremium;
	}

	/**
	 * Method 'setOptionPremium'.
	 *
	 * @param optionPremium the new option premium
	 */
	public void setOptionPremium(String optionPremium) {
		this.optionPremium = optionPremium;
	}

	/**
	 * Method 'getHrsFromThru'.
	 *
	 * @return String
	 */
	public String getHrsFromThru() {
		return hrsFromThru;
	}

	/**
	 * Method 'setHrsFromThru'.
	 *
	 * @param hrsFromThru the new hrs from thru
	 */
	public void setHrsFromThru(String hrsFromThru) {
		this.hrsFromThru = hrsFromThru;
	}

	/**
	 * Method 'getHrsFromThruTz'.
	 *
	 * @return String
	 */
	public String getHrsFromThruTz() {
		return hrsFromThruTz;
	}

	/**
	 * Method 'setHrsFromThruTz'.
	 *
	 * @param hrsFromThruTz the new hrs from thru tz
	 */
	public void setHrsFromThruTz(String hrsFromThruTz) {
		this.hrsFromThruTz = hrsFromThruTz;
	}

	/**
	 * Method 'getDaysWeek'.
	 *
	 * @return String
	 */
	public String getDaysWeek() {
		return daysWeek;
	}

	/**
	 * Method 'setDaysWeek'.
	 *
	 * @param daysWeek the new days week
	 */
	public void setDaysWeek(String daysWeek) {
		this.daysWeek = daysWeek;
	}

	/**
	 * Method 'getLoadType'.
	 *
	 * @return String
	 */
	public String getLoadType() {
		return loadType;
	}

	/**
	 * Method 'setLoadType'.
	 *
	 * @param loadType the new load type
	 */
	public void setLoadType(String loadType) {
		this.loadType = loadType;
	}

	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the usi or uti.
	 *
	 * @return the usi or uti
	 */
	public String getUsiOrUti() {
		return usiOrUti;
	}

	/**
	 * Sets the usi or uti.
	 *
	 * @param usiOrUti the new usi or uti
	 */
	public void setUsiOrUti(String usiOrUti) {
		this.usiOrUti = usiOrUti;
	}

	/**
	 * Gets the usi or uti alt.
	 *
	 * @return the usi or uti alt
	 */
	public String getUsiOrUtiAlt() {
		return usiOrUtiAlt;
	}

	/**
	 * Sets the usi or uti alt.
	 *
	 * @param usiOrUtiAlt the new usi or uti alt
	 */
	public void setUsiOrUtiAlt(String usiOrUtiAlt) {
		this.usiOrUtiAlt = usiOrUtiAlt;
	}

	/**
	 * Gets the rep party lei name.
	 *
	 * @return the rep party lei name
	 */
	public String getRepPartyLeiName() {
		return repPartyLeiName;
	}

	/**
	 * Sets the rep party lei name.
	 *
	 * @param repPartyLeiName the new rep party lei name
	 */
	public void setRepPartyLeiName(String repPartyLeiName) {
		this.repPartyLeiName = repPartyLeiName;
	}

	/**
	 * Gets the rep party lei name alt.
	 *
	 * @return the rep party lei name alt
	 */
	public String getRepPartyLeiNameAlt() {
		return repPartyLeiNameAlt;
	}

	/**
	 * Sets the rep party lei name alt.
	 *
	 * @param repPartyLeiNameAlt the new rep party lei name alt
	 */
	public void setRepPartyLeiNameAlt(String repPartyLeiNameAlt) {
		this.repPartyLeiNameAlt = repPartyLeiNameAlt;
	}

	/**
	 * Gets the rep party entity.
	 *
	 * @return the rep party entity
	 */
	public String getRepPartyEntity() {
		return repPartyEntity;
	}

	/**
	 * Sets the rep party entity.
	 *
	 * @param repPartyEntity the new rep party entity
	 */
	public void setRepPartyEntity(String repPartyEntity) {
		this.repPartyEntity = repPartyEntity;
	}

	/**
	 * Gets the rep party us person.
	 *
	 * @return the rep party us person
	 */
	public String getRepPartyUsPerson() {
		return repPartyUsPerson;
	}

	/**
	 * Sets the rep party us person.
	 *
	 * @param repPartyUsPerson the new rep party us person
	 */
	public void setRepPartyUsPerson(String repPartyUsPerson) {
		this.repPartyUsPerson = repPartyUsPerson;
	}

	/**
	 * Gets the non rep party lei name.
	 *
	 * @return the non rep party lei name
	 */
	public String getNonRepPartyLeiName() {
		return nonRepPartyLeiName;
	}

	/**
	 * Sets the non rep party lei name.
	 *
	 * @param nonRepPartyLeiName the new non rep party lei name
	 */
	public void setNonRepPartyLeiName(String nonRepPartyLeiName) {
		this.nonRepPartyLeiName = nonRepPartyLeiName;
	}

	/**
	 * Gets the non rep party lei name alt.
	 *
	 * @return the non rep party lei name alt
	 */
	public String getNonRepPartyLeiNameAlt() {
		return nonRepPartyLeiNameAlt;
	}

	/**
	 * Sets the non rep party lei name alt.
	 *
	 * @param nonRepPartyLeiNameAlt the new non rep party lei name alt
	 */
	public void setNonRepPartyLeiNameAlt(String nonRepPartyLeiNameAlt) {
		this.nonRepPartyLeiNameAlt = nonRepPartyLeiNameAlt;
	}

	/**
	 * Gets the non rep party entity.
	 *
	 * @return the non rep party entity
	 */
	public String getNonRepPartyEntity() {
		return nonRepPartyEntity;
	}

	/**
	 * Sets the non rep party entity.
	 *
	 * @param nonRepPartyEntity the new non rep party entity
	 */
	public void setNonRepPartyEntity(String nonRepPartyEntity) {
		this.nonRepPartyEntity = nonRepPartyEntity;
	}

	/**
	 * Gets the non rep party us person.
	 *
	 * @return the non rep party us person
	 */
	public String getNonRepPartyUsPerson() {
		return nonRepPartyUsPerson;
	}

	/**
	 * Sets the non rep party us person.
	 *
	 * @param nonRepPartyUsPerson the new non rep party us person
	 */
	public void setNonRepPartyUsPerson(String nonRepPartyUsPerson) {
		this.nonRepPartyUsPerson = nonRepPartyUsPerson;
	}

	/**
	 * Gets the upi.
	 *
	 * @return the upi
	 */
	public String getUpi() {
		return upi;
	}

	/**
	 * Sets the upi.
	 *
	 * @param upi the new upi
	 */
	public void setUpi(String upi) {
		this.upi = upi;
	}

	/**
	 * Gets the upi alt.
	 *
	 * @return the upi alt
	 */
	public String getUpiAlt() {
		return upiAlt;
	}

	/**
	 * Sets the upi alt.
	 *
	 * @param upiAlt the new upi alt
	 */
	public void setUpiAlt(String upiAlt) {
		this.upiAlt = upiAlt;
	}

	/**
	 * Gets the upi sdr.
	 *
	 * @return the upi sdr
	 */
	public String getUpiSdr() {
		return upiSdr;
	}

	/**
	 * Sets the upi sdr.
	 *
	 * @param upiSdr the new upi sdr
	 */
	public void setUpiSdr(String upiSdr) {
		this.upiSdr = upiSdr;
	}

	/**
	 * Gets the multi asset flag.
	 *
	 * @return the multi asset flag
	 */
	public String getMultiAssetFlag() {
		return multiAssetFlag;
	}

	/**
	 * Sets the multi asset flag.
	 *
	 * @param multiAssetFlag the new multi asset flag
	 */
	public void setMultiAssetFlag(String multiAssetFlag) {
		this.multiAssetFlag = multiAssetFlag;
	}

	/**
	 * Gets the asset class.
	 *
	 * @return the asset class
	 */
	public String getAssetClass() {
		return assetClass;
	}

	/**
	 * Sets the asset class.
	 *
	 * @param assetClass the new asset class
	 */
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	/**
	 * Gets the asset alternates.
	 *
	 * @return the asset alternates
	 */
	public String getAssetAlternates() {
		return assetAlternates;
	}

	/**
	 * Sets the asset alternates.
	 *
	 * @param assetAlternates the new asset alternates
	 */
	public void setAssetAlternates(String assetAlternates) {
		this.assetAlternates = assetAlternates;
	}

	/**
	 * Gets the mixed asset flag.
	 *
	 * @return the mixed asset flag
	 */
	public String getMixedAssetFlag() {
		return mixedAssetFlag;
	}

	/**
	 * Sets the mixed asset flag.
	 *
	 * @param mixedAssetFlag the new mixed asset flag
	 */
	public void setMixedAssetFlag(String mixedAssetFlag) {
		this.mixedAssetFlag = mixedAssetFlag;
	}

	/**
	 * Gets the multi sdr.
	 *
	 * @return the multi sdr
	 */
	public String getMultiSdr() {
		return multiSdr;
	}

	/**
	 * Sets the multi sdr.
	 *
	 * @param multiSdr the new multi sdr
	 */
	public void setMultiSdr(String multiSdr) {
		this.multiSdr = multiSdr;
	}

	/**
	 * Gets the multi sdr ids.
	 *
	 * @return the multi sdr ids
	 */
	public String getMultiSdrIds() {
		return multiSdrIds;
	}

	/**
	 * Sets the multi sdr ids.
	 *
	 * @param multiSdrIds the new multi sdr ids
	 */
	public void setMultiSdrIds(String multiSdrIds) {
		this.multiSdrIds = multiSdrIds;
	}

	/**
	 * Gets the cont type.
	 *
	 * @return the cont type
	 */
	public String getContType() {
		return contType;
	}

	/**
	 * Sets the cont type.
	 *
	 * @param contType the new cont type
	 */
	public void setContType(String contType) {
		this.contType = contType;
	}

	/**
	 * Gets the exec venue.
	 *
	 * @return the exec venue
	 */
	public String getExecVenue() {
		return execVenue;
	}

	/**
	 * Sets the exec venue.
	 *
	 * @param execVenue the new exec venue
	 */
	public void setExecVenue(String execVenue) {
		this.execVenue = execVenue;
	}

	/**
	 * Gets the effective date.
	 *
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate the new effective date
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * Gets the maturity date.
	 *
	 * @return the maturity date
	 */
	public Date getMaturityDate() {
		return maturityDate;
	}

	/**
	 * Sets the maturity date.
	 *
	 * @param maturityDate the new maturity date
	 */
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	/**
	 * Gets the buyer.
	 *
	 * @return the buyer
	 */
	public String getBuyer() {
		return buyer;
	}

	/**
	 * Sets the buyer.
	 *
	 * @param buyer the new buyer
	 */
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	/**
	 * Gets the seller.
	 *
	 * @return the seller
	 */
	public String getSeller() {
		return seller;
	}

	/**
	 * Sets the seller.
	 *
	 * @param seller the new seller
	 */
	public void setSeller(String seller) {
		this.seller = seller;
	}

	/**
	 * Gets the buyer alt.
	 *
	 * @return the buyer alt
	 */
	public String getBuyerAlt() {
		return buyerAlt;
	}

	/**
	 * Sets the buyer alt.
	 *
	 * @param buyerAlt the new buyer alt
	 */
	public void setBuyerAlt(String buyerAlt) {
		this.buyerAlt = buyerAlt;
	}

	/**
	 * Gets the seller alt.
	 *
	 * @return the seller alt
	 */
	public String getSellerAlt() {
		return sellerAlt;
	}

	/**
	 * Sets the seller alt.
	 *
	 * @param sellerAlt the new seller alt
	 */
	public void setSellerAlt(String sellerAlt) {
		this.sellerAlt = sellerAlt;
	}

	/**
	 * Gets the collateral ind.
	 *
	 * @return the collateral ind
	 */
	public String getCollateralInd() {
		return collateralInd;
	}

	/**
	 * Sets the collateral ind.
	 *
	 * @param collateralInd the new collateral ind
	 */
	public void setCollateralInd(String collateralInd) {
		this.collateralInd = collateralInd;
	}

	/**
	 * Method 'getCreateDatetime'.
	 *
	 * @return Date
	 */
	public Date getCreateDatetime() {
		return createDatetime;
	}

	/**
	 * Method 'setCreateDatetime'.
	 *
	 * @param createDatetime the new creates the datetime
	 */
	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	/**
	 * Method 'getUpdateDatetime'.
	 *
	 * @return Date
	 */
	public Date getUpdateDatetime() {
		return updateDatetime;
	}

	/**
	 * Method 'setUpdateDatetime'.
	 *
	 * @param updateDatetime the new update datetime
	 */
	public void setUpdateDatetime(Date updateDatetime) {
		this.updateDatetime = updateDatetime;
	}

	/**
	 * Method 'equals'.
	 *
	 * @param _other the _other
	 * @return boolean
	 */
	public boolean equals(Object _other) {
		if (_other == null) {
			return false;
		}

		if (_other == this) {
			return true;
		}

		if (!(_other instanceof RecCommMtermsStore)) {
			return false;
		}

		final RecCommMtermsStore _cast = (RecCommMtermsStore) _other;
		if (sendId == null ? _cast.sendId != sendId : !sendId
				.equals(_cast.sendId)) {
			return false;
		}

		if (qtyUnits == null ? _cast.qtyUnits != qtyUnits : !qtyUnits
				.equals(_cast.qtyUnits)) {
			return false;
		}

		if (qtyNumOfUnits == null ? _cast.qtyNumOfUnits != qtyNumOfUnits
				: !qtyNumOfUnits.equals(_cast.qtyNumOfUnits)) {
			return false;
		}

		if (qtyFreq == null ? _cast.qtyFreq != qtyFreq : !qtyFreq
				.equals(_cast.qtyFreq)) {
			return false;
		}

		if (qtyTotal == null ? _cast.qtyTotal != qtyTotal : !qtyTotal
				.equals(_cast.qtyTotal)) {
			return false;
		}

		if (settleMethod == null ? _cast.settleMethod != settleMethod
				: !settleMethod.equals(_cast.settleMethod)) {
			return false;
		}

		if (price == null ? _cast.price != price : !price.equals(_cast.price)) {
			return false;
		}

		if (priceUnits == null ? _cast.priceUnits != priceUnits : !priceUnits
				.equals(_cast.priceUnits)) {
			return false;
		}

		if (priceCurr == null ? _cast.priceCurr != priceCurr : !priceCurr
				.equals(_cast.priceCurr)) {
			return false;
		}

		if (buyerIndex == null ? _cast.buyerIndex != buyerIndex : !buyerIndex
				.equals(_cast.buyerIndex)) {
			return false;
		}

		if (buyerIndexAvgMethod == null ? _cast.buyerIndexAvgMethod != buyerIndexAvgMethod
				: !buyerIndexAvgMethod.equals(_cast.buyerIndexAvgMethod)) {
			return false;
		}

		if (sellerIndex == null ? _cast.sellerIndex != sellerIndex
				: !sellerIndex.equals(_cast.sellerIndex)) {
			return false;
		}

		if (sellerIndexAvgMethod == null ? _cast.sellerIndexAvgMethod != sellerIndexAvgMethod
				: !sellerIndexAvgMethod.equals(_cast.sellerIndexAvgMethod)) {
			return false;
		}

		if (grade == null ? _cast.grade != grade : !grade.equals(_cast.grade)) {
			return false;
		}

		if (optionType == null ? _cast.optionType != optionType : !optionType
				.equals(_cast.optionType)) {
			return false;
		}

		if (optionStyle == null ? _cast.optionStyle != optionStyle
				: !optionStyle.equals(_cast.optionStyle)) {
			return false;
		}

		if (optionPremium == null ? _cast.optionPremium != optionPremium
				: !optionPremium.equals(_cast.optionPremium)) {
			return false;
		}

		if (hrsFromThru == null ? _cast.hrsFromThru != hrsFromThru
				: !hrsFromThru.equals(_cast.hrsFromThru)) {
			return false;
		}

		if (hrsFromThruTz == null ? _cast.hrsFromThruTz != hrsFromThruTz
				: !hrsFromThruTz.equals(_cast.hrsFromThruTz)) {
			return false;
		}

		if (daysWeek == null ? _cast.daysWeek != daysWeek : !daysWeek
				.equals(_cast.daysWeek)) {
			return false;
		}

		if (loadType == null ? _cast.loadType != loadType : !loadType
				.equals(_cast.loadType)) {
			return false;
		}


		if (status == null ? _cast.status != status : !status.equals( _cast.status )) {
			return false;
		}
		
		if (usiOrUti == null ? _cast.usiOrUti != usiOrUti : !usiOrUti.equals( _cast.usiOrUti )) {
			return false;
		}
		
		if (usiOrUtiAlt == null ? _cast.usiOrUtiAlt != usiOrUtiAlt : !usiOrUtiAlt.equals( _cast.usiOrUtiAlt )) {
			return false;
		}
		
		if (repPartyLeiName == null ? _cast.repPartyLeiName != repPartyLeiName : !repPartyLeiName.equals( _cast.repPartyLeiName )) {
			return false;
		}
		
		if (repPartyLeiNameAlt == null ? _cast.repPartyLeiNameAlt != repPartyLeiNameAlt : !repPartyLeiNameAlt.equals( _cast.repPartyLeiNameAlt )) {
			return false;
		}
		
		if (repPartyEntity == null ? _cast.repPartyEntity != repPartyEntity : !repPartyEntity.equals( _cast.repPartyEntity )) {
			return false;
		}
		
		if (repPartyUsPerson == null ? _cast.repPartyUsPerson != repPartyUsPerson : !repPartyUsPerson.equals( _cast.repPartyUsPerson )) {
			return false;
		}
		
		if (nonRepPartyLeiName == null ? _cast.nonRepPartyLeiName != nonRepPartyLeiName : !nonRepPartyLeiName.equals( _cast.nonRepPartyLeiName )) {
			return false;
		}
		
		if (nonRepPartyLeiNameAlt == null ? _cast.nonRepPartyLeiNameAlt != nonRepPartyLeiNameAlt : !nonRepPartyLeiNameAlt.equals( _cast.nonRepPartyLeiNameAlt )) {
			return false;
		}
		
		if (nonRepPartyEntity == null ? _cast.nonRepPartyEntity != nonRepPartyEntity : !nonRepPartyEntity.equals( _cast.nonRepPartyEntity )) {
			return false;
		}
		
		if (nonRepPartyUsPerson == null ? _cast.nonRepPartyUsPerson != nonRepPartyUsPerson : !nonRepPartyUsPerson.equals( _cast.nonRepPartyUsPerson )) {
			return false;
		}
		
		if (upi == null ? _cast.upi != upi : !upi.equals( _cast.upi )) {
			return false;
		}
		
		if (upiAlt == null ? _cast.upiAlt != upiAlt : !upiAlt.equals( _cast.upiAlt )) {
			return false;
		}
		
		if (upiSdr == null ? _cast.upiSdr != upiSdr : !upiSdr.equals( _cast.upiSdr )) {
			return false;
		}
		
		if (multiAssetFlag == null ? _cast.multiAssetFlag != multiAssetFlag : !multiAssetFlag.equals( _cast.multiAssetFlag )) {
			return false;
		}
		
		if (assetClass == null ? _cast.assetClass != assetClass : !assetClass.equals( _cast.assetClass )) {
			return false;
		}
		
		if (assetAlternates == null ? _cast.assetAlternates != assetAlternates : !assetAlternates.equals( _cast.assetAlternates )) {
			return false;
		}
		
		if (mixedAssetFlag == null ? _cast.mixedAssetFlag != mixedAssetFlag : !mixedAssetFlag.equals( _cast.mixedAssetFlag )) {
			return false;
		}
		
		if (multiSdr == null ? _cast.multiSdr != multiSdr : !multiSdr.equals( _cast.multiSdr )) {
			return false;
		}
		
		if (multiSdrIds == null ? _cast.multiSdrIds != multiSdrIds : !multiSdrIds.equals( _cast.multiSdrIds )) {
			return false;
		}
		
		if (contType == null ? _cast.contType != contType : !contType.equals( _cast.contType )) {
			return false;
		}
		
		if (execVenue == null ? _cast.execVenue != execVenue : !execVenue.equals( _cast.execVenue )) {
			return false;
		}
		
		if (effectiveDate == null ? _cast.effectiveDate != effectiveDate : !effectiveDate.equals( _cast.effectiveDate )) {
			return false;
		}
		
		if (maturityDate == null ? _cast.maturityDate != maturityDate : !maturityDate.equals( _cast.maturityDate )) {
			return false;
		}
		
		if (buyer == null ? _cast.buyer != buyer : !buyer.equals( _cast.buyer )) {
			return false;
		}
		
		if (seller == null ? _cast.seller != seller : !seller.equals( _cast.seller )) {
			return false;
		}
		
		if (buyerAlt == null ? _cast.buyerAlt != buyerAlt : !buyerAlt.equals( _cast.buyerAlt )) {
			return false;
		}
		
		if (sellerAlt == null ? _cast.sellerAlt != sellerAlt : !sellerAlt.equals( _cast.sellerAlt )) {
			return false;
		}
		
		if (collateralInd == null ? _cast.collateralInd != collateralInd : !collateralInd.equals( _cast.collateralInd )) {
			return false;
		}
	
		if (createDatetime == null ? _cast.createDatetime != createDatetime
				: !createDatetime.equals(_cast.createDatetime)) {
			return false;
		}

		if (updateDatetime == null ? _cast.updateDatetime != updateDatetime
				: !updateDatetime.equals(_cast.updateDatetime)) {
			return false;
		}

		return true;
	}

	/**
	 * Method 'hashCode'.
	 *
	 * @return int
	 */
	public int hashCode() {
		int _hashCode = 0;
		if (sendId != null) {
			_hashCode = 29 * _hashCode + sendId.hashCode();
		}

		if (qtyUnits != null) {
			_hashCode = 29 * _hashCode + qtyUnits.hashCode();
		}

		if (qtyNumOfUnits != null) {
			_hashCode = 29 * _hashCode + qtyNumOfUnits.hashCode();
		}

		if (qtyFreq != null) {
			_hashCode = 29 * _hashCode + qtyFreq.hashCode();
		}

		if (qtyTotal != null) {
			_hashCode = 29 * _hashCode + qtyTotal.hashCode();
		}

		if (settleMethod != null) {
			_hashCode = 29 * _hashCode + settleMethod.hashCode();
		}

		if (price != null) {
			_hashCode = 29 * _hashCode + price.hashCode();
		}

		if (priceUnits != null) {
			_hashCode = 29 * _hashCode + priceUnits.hashCode();
		}

		if (priceCurr != null) {
			_hashCode = 29 * _hashCode + priceCurr.hashCode();
		}

		if (buyerIndex != null) {
			_hashCode = 29 * _hashCode + buyerIndex.hashCode();
		}

		if (buyerIndexAvgMethod != null) {
			_hashCode = 29 * _hashCode + buyerIndexAvgMethod.hashCode();
		}

		if (sellerIndex != null) {
			_hashCode = 29 * _hashCode + sellerIndex.hashCode();
		}

		if (sellerIndexAvgMethod != null) {
			_hashCode = 29 * _hashCode + sellerIndexAvgMethod.hashCode();
		}

		if (grade != null) {
			_hashCode = 29 * _hashCode + grade.hashCode();
		}

		if (optionType != null) {
			_hashCode = 29 * _hashCode + optionType.hashCode();
		}

		if (optionStyle != null) {
			_hashCode = 29 * _hashCode + optionStyle.hashCode();
		}

		if (optionPremium != null) {
			_hashCode = 29 * _hashCode + optionPremium.hashCode();
		}

		if (hrsFromThru != null) {
			_hashCode = 29 * _hashCode + hrsFromThru.hashCode();
		}

		if (hrsFromThruTz != null) {
			_hashCode = 29 * _hashCode + hrsFromThruTz.hashCode();
		}

		if (daysWeek != null) {
			_hashCode = 29 * _hashCode + daysWeek.hashCode();
		}

		if (loadType != null) {
			_hashCode = 29 * _hashCode + loadType.hashCode();
		}

		if (status != null) {
			_hashCode = 29 * _hashCode + status.hashCode();
		}
		
		if (usiOrUti != null) {
			_hashCode = 29 * _hashCode + usiOrUti.hashCode();
		}
		
		if (usiOrUtiAlt != null) {
			_hashCode = 29 * _hashCode + usiOrUtiAlt.hashCode();
		}
		
		if (repPartyLeiName != null) {
			_hashCode = 29 * _hashCode + repPartyLeiName.hashCode();
		}
		
		if (repPartyLeiNameAlt != null) {
			_hashCode = 29 * _hashCode + repPartyLeiNameAlt.hashCode();
		}
		
		if (repPartyEntity != null) {
			_hashCode = 29 * _hashCode + repPartyEntity.hashCode();
		}
		
		if (repPartyUsPerson != null) {
			_hashCode = 29 * _hashCode + repPartyUsPerson.hashCode();
		}
		
		if (nonRepPartyLeiName != null) {
			_hashCode = 29 * _hashCode + nonRepPartyLeiName.hashCode();
		}
		
		if (nonRepPartyLeiNameAlt != null) {
			_hashCode = 29 * _hashCode + nonRepPartyLeiNameAlt.hashCode();
		}
		
		if (nonRepPartyEntity != null) {
			_hashCode = 29 * _hashCode + nonRepPartyEntity.hashCode();
		}
		
		if (nonRepPartyUsPerson != null) {
			_hashCode = 29 * _hashCode + nonRepPartyUsPerson.hashCode();
		}
		
		if (upi != null) {
			_hashCode = 29 * _hashCode + upi.hashCode();
		}
		
		if (upiAlt != null) {
			_hashCode = 29 * _hashCode + upiAlt.hashCode();
		}
		
		if (upiSdr != null) {
			_hashCode = 29 * _hashCode + upiSdr.hashCode();
		}
		
		if (multiAssetFlag != null) {
			_hashCode = 29 * _hashCode + multiAssetFlag.hashCode();
		}
		
		if (assetClass != null) {
			_hashCode = 29 * _hashCode + assetClass.hashCode();
		}
		
		if (assetAlternates != null) {
			_hashCode = 29 * _hashCode + assetAlternates.hashCode();
		}
		
		if (mixedAssetFlag != null) {
			_hashCode = 29 * _hashCode + mixedAssetFlag.hashCode();
		}
		
		if (multiSdr != null) {
			_hashCode = 29 * _hashCode + multiSdr.hashCode();
		}
		
		if (multiSdrIds != null) {
			_hashCode = 29 * _hashCode + multiSdrIds.hashCode();
		}
		
		if (contType != null) {
			_hashCode = 29 * _hashCode + contType.hashCode();
		}
		
		if (execVenue != null) {
			_hashCode = 29 * _hashCode + execVenue.hashCode();
		}
		
		if (effectiveDate != null) {
			_hashCode = 29 * _hashCode + effectiveDate.hashCode();
		}
		
		if (maturityDate != null) {
			_hashCode = 29 * _hashCode + maturityDate.hashCode();
		}
		
		if (buyer != null) {
			_hashCode = 29 * _hashCode + buyer.hashCode();
		}
		
		if (seller != null) {
			_hashCode = 29 * _hashCode + seller.hashCode();
		}
		
		if (buyerAlt != null) {
			_hashCode = 29 * _hashCode + buyerAlt.hashCode();
		}
		
		if (sellerAlt != null) {
			_hashCode = 29 * _hashCode + sellerAlt.hashCode();
		}
		
		if (collateralInd != null) {
			_hashCode = 29 * _hashCode + collateralInd.hashCode();
		}
		if (createDatetime != null) {
			_hashCode = 29 * _hashCode + createDatetime.hashCode();
		}

		if (updateDatetime != null) {
			_hashCode = 29 * _hashCode + updateDatetime.hashCode();
		}

		return _hashCode;
	}

	/**
	 * Method 'toString'.
	 *
	 * @return String
	 */
	public String toString() {
		StringBuffer ret = new StringBuffer();
		ret.append("com.wf.df.sdr.recon.dto.RecCommMtermsStore: ");
		ret.append("sendId=" + sendId);
		ret.append(", qtyUnits=" + qtyUnits);
		ret.append(", qtyNumOfUnits=" + qtyNumOfUnits);
		ret.append(", qtyFreq=" + qtyFreq);
		ret.append(", qtyTotal=" + qtyTotal);
		ret.append(", settleMethod=" + settleMethod);
		ret.append(", price=" + price);
		ret.append(", priceUnits=" + priceUnits);
		ret.append(", priceCurr=" + priceCurr);
		ret.append(", buyerIndex=" + buyerIndex);
		ret.append(", buyerIndexAvgMethod=" + buyerIndexAvgMethod);
		ret.append(", sellerIndex=" + sellerIndex);
		ret.append(", sellerIndexAvgMethod=" + sellerIndexAvgMethod);
		ret.append(", grade=" + grade);
		ret.append(", optionType=" + optionType);
		ret.append(", optionStyle=" + optionStyle);
		ret.append(", optionPremium=" + optionPremium);
		ret.append(", hrsFromThru=" + hrsFromThru);
		ret.append(", hrsFromThruTz=" + hrsFromThruTz);
		ret.append(", daysWeek=" + daysWeek);
		ret.append(", loadType=" + loadType);
		ret.append( ", status=" + status );
		ret.append( ", usiOrUti=" + usiOrUti );
		ret.append( ", usiOrUtiAlt=" + usiOrUtiAlt );
		ret.append( ", repPartyLeiName=" + repPartyLeiName );
		ret.append( ", repPartyLeiNameAlt=" + repPartyLeiNameAlt );
		ret.append( ", repPartyEntity=" + repPartyEntity );
		ret.append( ", repPartyUsPerson=" + repPartyUsPerson );
		ret.append( ", nonRepPartyLeiName=" + nonRepPartyLeiName );
		ret.append( ", nonRepPartyLeiNameAlt=" + nonRepPartyLeiNameAlt );
		ret.append( ", nonRepPartyEntity=" + nonRepPartyEntity );
		ret.append( ", nonRepPartyUsPerson=" + nonRepPartyUsPerson );
		ret.append( ", upi=" + upi );
		ret.append( ", upiAlt=" + upiAlt );
		ret.append( ", upiSdr=" + upiSdr );
		ret.append( ", multiAssetFlag=" + multiAssetFlag );
		ret.append( ", assetClass=" + assetClass );
		ret.append( ", assetAlternates=" + assetAlternates );
		ret.append( ", mixedAssetFlag=" + mixedAssetFlag );
		ret.append( ", multiSdr=" + multiSdr );
		ret.append( ", multiSdrIds=" + multiSdrIds );
		ret.append( ", contType=" + contType );
		ret.append( ", execVenue=" + execVenue );
		ret.append( ", effectiveDate=" + effectiveDate );
		ret.append( ", maturityDate=" + maturityDate );
		ret.append( ", buyer=" + buyer );
		ret.append( ", seller=" + seller );
		ret.append( ", buyerAlt=" + buyerAlt );
		ret.append( ", sellerAlt=" + sellerAlt );
		ret.append( ", collateralInd=" + collateralInd );
		ret.append(", createDatetime=" + createDatetime);
		ret.append(", updateDatetime=" + updateDatetime);
		return ret.toString();
	}


}
