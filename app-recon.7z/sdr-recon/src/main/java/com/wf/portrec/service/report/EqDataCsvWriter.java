
package com.wf.portrec.service.report;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.EquityTrade;
import com.wf.portrec.repository.EquityTradeRepository;

@Component
public class EqDataCsvWriter {

	@Value("${file.portrec.data.eq}") String outputFolderName;
	@Value("${mask.counterparty.details}") String counterPartyValue;
	@Value("${wf.affiliatebank.leis}") String wfLeiList;
	String fileName = "EQ_SRC_";
	Logger logger = LoggerFactory.getLogger(getClass());
	int SNAPSHOT_HEADER_ROW_NUM = 10;
	static char SEPARATOR = ',';


	@Autowired
	EquityTradeRepository equityVSTradeRepository; 
	
	
	public void generateMatchUSIFile(File targetFile, Map<String,EquityTrade> usiTrdIdMap, String src){		
		try {			
			//targetFile = new File(outputFolderName, targetFile.getName());
			targetFile.mkdirs();						
			if (targetFile.exists()) {
				targetFile.delete();
			}			
			FileWriter writer = new FileWriter(targetFile);
			
			writer.append("USI");
			writer.append(SEPARATOR);
			writer.append("Trade Id");
			writer.append(SEPARATOR);
			writer.append("Reporting prty LEI");
			writer.append(SEPARATOR);
			writer.append("Report SD");
			writer.append(SEPARATOR);
			writer.append("Report MSP");
			writer.append(SEPARATOR);
			writer.append("Report Fin");
			writer.append(SEPARATOR);
			writer.append("Report US");
			writer.append(SEPARATOR);
			writer.append("Non Report LEI");
			writer.append(SEPARATOR);
			writer.append("Non Report ident");
			writer.append(SEPARATOR);
			writer.append("Non Rept SD");
			writer.append(SEPARATOR);
			writer.append("Non Rep MSP");
			writer.append(SEPARATOR);
			writer.append("Non Rep Fin");
			writer.append(SEPARATOR);
			writer.append("Non Rep US");
			writer.append(SEPARATOR);
			writer.append("Product ID");
			writer.append(SEPARATOR);
			writer.append("CFTC Prod Id");
			writer.append(SEPARATOR);
			writer.append("Int Prod Id");
			writer.append(SEPARATOR);
			writer.append("Multi Asset");
			writer.append(SEPARATOR);
			writer.append("Pri Asset Class");
			writer.append(SEPARATOR);
			writer.append("Sec Asset Class");
			writer.append(SEPARATOR);
			writer.append("Mixed Swap");
			
			writer.append(SEPARATOR);
			writer.append("SDR2");
			writer.append(SEPARATOR);
			writer.append("Buyer");
			writer.append(SEPARATOR);
			writer.append("Seller");
			writer.append(SEPARATOR);
			writer.append("Under Asset Id Type");
			writer.append(SEPARATOR);
			writer.append("Under Asset");
			writer.append(SEPARATOR);
			writer.append("Under Asset Notional");
			writer.append(SEPARATOR);
			writer.append("Under Asset Notional Ccy");

			writer.append(SEPARATOR);
			writer.append("Under Asset Weight");
			writer.append(SEPARATOR);
			writer.append("Contract Type");
			writer.append(SEPARATOR);
			writer.append("Exec Venue");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Term date");
			writer.append(SEPARATOR);
			writer.append("Valuation Date");
			writer.append(SEPARATOR);
			writer.append("Eq Leg Val Date");

			writer.append(SEPARATOR);
			writer.append("Eq Variance Strike Price");
			writer.append(SEPARATOR);
			writer.append("Volatility Strike Price");
			writer.append(SEPARATOR);
			writer.append("Initial Price");
			writer.append(SEPARATOR);
			writer.append("Price Notation");
			writer.append(SEPARATOR);
			writer.append("Price Notation type");
			writer.append(SEPARATOR);
			writer.append("Vega Notional Amt");
			writer.append(SEPARATOR);
			writer.append("Vega Notional Ccy");
			
			writer.append(SEPARATOR);
			writer.append("Party 1 Notional Amt");
			writer.append(SEPARATOR);
			writer.append("Party 1 Notional Ccy");
			writer.append(SEPARATOR);
			writer.append("Premium");
			writer.append(SEPARATOR);
			writer.append("Eq Pay Freq Period");
			writer.append(SEPARATOR);
			writer.append("Eq Pay Freq Multiplier");
			writer.append(SEPARATOR);
			writer.append("Float Leg Pay Freq Period");
			writer.append(SEPARATOR);
			writer.append("Float Pay Freq Multiplier");

			
			writer.append(SEPARATOR);
			writer.append("Eq Pay Dat");
			writer.append(SEPARATOR);
			writer.append("Float Pay Dt");
			writer.append(SEPARATOR);
			writer.append("Eq Val Dt");
			writer.append(SEPARATOR);
			writer.append("Float Val Dt");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);			
			writer.append("Execution Date");
			writer.append(SEPARATOR);
			writer.append("Cpty Name");
			writer.append('\n');
			
			//for (EquityTrade srcViewDomain : srcViewDomainList) {
			if(StringUtils.contains(src, "SRC")){
				Iterator it = usiTrdIdMap.entrySet().iterator();
				while (it.hasNext()) {
			        Map.Entry pairs = (Map.Entry)it.next();
			        EquityTrade srcViewDomain = (EquityTrade)pairs.getValue();
			        String usi = (String)pairs.getKey();
			        String[] parts = usi.split(":");
			        usi=parts[0];
			        srcViewDomain.setUsi(usi);
			       
			        writer.append(null != srcViewDomain.getUsi() ? srcViewDomain.getUsi() : "");
			        writer.append(SEPARATOR);
			        writer.append(null != srcViewDomain.getOrigTradeId() ? srcViewDomain.getOrigTradeId() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiCp() ? srcViewDomain.getLeiCp() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2financialEntityStatus() ? srcViewDomain.getTradeParty2financialEntityStatus() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2UsPersonIndicator() ? srcViewDomain.getTradeParty2UsPersonIndicator() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiUs() ? srcViewDomain.getLeiUs() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiUs() ? srcViewDomain.getLeiUs() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : "");  
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1financialEntityStatus() ? srcViewDomain.getTradeParty1financialEntityStatus() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1UsPersonIndicator() ? srcViewDomain.getTradeParty1UsPersonIndicator() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpi() ? srcViewDomain.getUpi() : ""); 
					writer.append(SEPARATOR);  
					writer.append("");  // CFTC Prod Id
					writer.append(SEPARATOR);
					writer.append(""); // Internal Prod Id
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMultiAsset() ? srcViewDomain.getIsSwapMultiAsset() : ""); 				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAssetClass() ? srcViewDomain.getAssetClass() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getSecAssetClass() ? srcViewDomain.getSecAssetClass() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMixed() ? srcViewDomain.getIsSwapMixed() : "");	
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAdditionalSDRForMixedSwap() ? srcViewDomain.getAdditionalSDRForMixedSwap() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getBuyer() ? srcViewDomain.getBuyer() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getWeBuySell() ? srcViewDomain.getWeBuySell() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetIdentifierType() ? srcViewDomain.getUnderlyingAssetIdentifierType() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssets() ? srcViewDomain.getUnderlyingAssets(): ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotional() ? srcViewDomain.getUnderlyingAssetsNotional() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotionalCurr() ? srcViewDomain.getUnderlyingAssetsNotionalCurr() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsWeighting() ? srcViewDomain.getUnderlyingAssetsWeighting() : ""); 			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpi() ? srcViewDomain.getUpi() : ""); 		
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionVenue() ? srcViewDomain.getExecutionVenue() : "");			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeDate() ? ReportDateUtil.getStrDate(srcViewDomain.getTradeDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTerminationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getTerminationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getValuationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getEqLegValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEquityVarianceStrikePrice() ? srcViewDomain.getEquityVarianceStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVolatilityStrikePrice() ? srcViewDomain.getVolatilityStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getInitialPrice() ? srcViewDomain.getInitialPrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotation() ? srcViewDomain.getPriceNotation() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotationType() ? srcViewDomain.getPriceNotationType() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1VegaNotionalAmount() ? srcViewDomain.getParty1VegaNotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVegaNotionalCurrency() ? srcViewDomain.getVegaNotionalCurrency().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalAmount() ? srcViewDomain.getParty1NotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalCurrency() ? srcViewDomain.getParty1NotionalCurrency().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpFrontPaymentAmount() ? srcViewDomain.getUpFrontPaymentAmount().toString() : "");				
					writer.append(SEPARATOR);
					writer.append(""); // Eq Pay Freq Period
					writer.append(SEPARATOR);
					writer.append(""); // Eq Pay Freq Multiplier
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFrequencyPeriod() ? srcViewDomain.getFloatingLegPaymentFrequencyPeriod() : "");					
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFrequencyPeriodMultiplier() ? srcViewDomain.getFloatingLegPaymentFrequencyPeriodMultiplier() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegPaymentDate() ? ReportDateUtil.getStrDate(srcViewDomain.getEqLegPaymentDate()) : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFltLegPaymentDate() ? ReportDateUtil.getStrDate(srcViewDomain.getFltLegPaymentDate()) : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getEqLegValuationDate()) : "");				
					writer.append(SEPARATOR);
					writer.append("");				 // Float Val Dt
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getCollaterlized() ? srcViewDomain.getCollaterlized() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionDate() ? ReportDateUtil.getStrDate(srcViewDomain.getExecutionDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2Name() ? srcViewDomain.getTradeParty2Name() : "");
					writer.append('\n');
				}
			}else {
				Iterator it = usiTrdIdMap.entrySet().iterator();
				while (it.hasNext()) {
					 Map.Entry pairs = (Map.Entry)it.next();
				        //out.write(pairs.getKey() + " = " + pairs.getValue() + "\n");
			        EquityTrade srcViewDomain = (EquityTrade)pairs.getValue();
			        String usi = (String)pairs.getKey();
			        String[] parts = usi.split(":");
			        usi=parts[0];
			        srcViewDomain.setUsi(usi);
			        writer.append(null != srcViewDomain.getUsi() ? srcViewDomain.getUsi() : "");
			        writer.append(SEPARATOR);
			        if(StringUtils.isNotBlank(srcViewDomain.getOrigTradeId()))
			        	 writer.append(srcViewDomain.getOrigTradeId());
			        else 
			        	writer.append("");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getLeiCp() ? srcViewDomain.getLeiCp() : "");
					writer.append(null != srcViewDomain.getLeiUs() ? maskCounterPartyDetails(srcViewDomain.getLeiUs()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : ""); // Party 1 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : ""); // Party 2 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1financialEntityStatus() ? srcViewDomain.getTradeParty1financialEntityStatus() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1UsPersonIndicator() ? srcViewDomain.getTradeParty1UsPersonIndicator() : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getLeiUs() ? srcViewDomain.getLeiUs() : "");
					writer.append(null != srcViewDomain.getLeiCp() ? maskCounterPartyDetails(srcViewDomain.getLeiCp()) : "");
					writer.append(SEPARATOR);
					//writer.append(null != srcViewDomain.getLeiUs() ? srcViewDomain.getLeiUs() : "");
					writer.append(null != srcViewDomain.getLeiCp() ? maskCounterPartyDetails(srcViewDomain.getLeiCp()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : ""); // Party 1 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : "");  // Party 2 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2financialEntityStatus() ? srcViewDomain.getTradeParty2financialEntityStatus() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2UsPersonIndicator() ? srcViewDomain.getTradeParty2UsPersonIndicator() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpi() ? srcViewDomain.getUpi() : ""); 
					writer.append(SEPARATOR);  
					writer.append("");  // CFTC Prod Id
					writer.append(SEPARATOR);
					writer.append(""); // Internal Prod Id
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMultiAsset() ? srcViewDomain.getIsSwapMultiAsset() : ""); 				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAssetClass() ? srcViewDomain.getAssetClass() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getSecAssetClass() ? srcViewDomain.getSecAssetClass() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMixed() ? srcViewDomain.getIsSwapMixed() : "");	
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAdditionalSDRForMixedSwap() ? srcViewDomain.getAdditionalSDRForMixedSwap() : "");				
					writer.append(SEPARATOR);
					String buyer = srcViewDomain.getBuyer(); // We are breaking on Buyer  column where counterparty used DTCC ID (6192- Wells Fargo DTCC id  ) in place of LEI – would it be possible translate it to LEI?
					if(StringUtils.isNotBlank(srcViewDomain.getBuyer()) && (buyer.equalsIgnoreCase("6192") || buyer.equalsIgnoreCase("006192") || buyer.equalsIgnoreCase("00006192")))
						buyer = "KB1H1DSPRFMYMCUFXT09";
					writer.append(null != buyer ? buyer : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getWeBuySell() ? srcViewDomain.getWeBuySell() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetIdentifierType() ? srcViewDomain.getUnderlyingAssetIdentifierType() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssets() ? srcViewDomain.getUnderlyingAssets(): ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotional() ? srcViewDomain.getUnderlyingAssetsNotional() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotionalCurr() ? srcViewDomain.getUnderlyingAssetsNotionalCurr() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsWeighting() ? srcViewDomain.getUnderlyingAssetsWeighting() : ""); 			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpi() ? srcViewDomain.getUpi() : ""); 		
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionVenue() ? srcViewDomain.getExecutionVenue() : "");			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeDate() ? ReportDateUtil.getStrDate(srcViewDomain.getTradeDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTerminationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getTerminationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getValuationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getEqLegValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEquityVarianceStrikePrice() ? srcViewDomain.getEquityVarianceStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVolatilityStrikePrice() ? srcViewDomain.getVolatilityStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getInitialPrice() ? srcViewDomain.getInitialPrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotation() ? srcViewDomain.getPriceNotation() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotationType() ? srcViewDomain.getPriceNotationType() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1VegaNotionalAmount() ? srcViewDomain.getParty1VegaNotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVegaNotionalCurrency() ? srcViewDomain.getVegaNotionalCurrency().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalAmount() ? srcViewDomain.getParty1NotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalCurrency() ? srcViewDomain.getParty1NotionalCurrency().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpFrontPaymentAmount() ? srcViewDomain.getUpFrontPaymentAmount().toString() : "");				
					writer.append(SEPARATOR);
					writer.append("");
					writer.append(SEPARATOR);
					writer.append("");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFrequencyPeriod() ? srcViewDomain.getFloatingLegPaymentFrequencyPeriod() : "");					
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFrequencyPeriodMultiplier() ? srcViewDomain.getFloatingLegPaymentFrequencyPeriodMultiplier() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegPaymentDate() ? ReportDateUtil.getStrDate(srcViewDomain.getEqLegPaymentDate()) : "");			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFltLegPaymentDate() ? ReportDateUtil.getStrDate(srcViewDomain.getFltLegPaymentDate()) : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getEqLegValuationDate()) : "");				
					writer.append(SEPARATOR);
					writer.append("");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getCollaterlized() ? srcViewDomain.getCollaterlized() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionDate() ? ReportDateUtil.getStrDate(srcViewDomain.getExecutionDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2Name() ? srcViewDomain.getTradeParty2Name() : "");
					writer.append('\n');
				}
			}
			writer.flush();
			writer.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String maskCounterPartyDetails(String leiValue){
		String cpVal = "";
		if(null!=leiValue){
			if(StringUtils.contains(wfLeiList, leiValue)){
				cpVal = leiValue;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}	
}
