package com.wf.portrec.message;

import java.io.File;

public class MTDeliveryRequest {

	private File file;

	public MTDeliveryRequest( File file) {
		this.file = file;
	}

	public File getFile() {
		return file;
	}
}
