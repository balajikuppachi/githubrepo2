package com.wf.portrec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.CommodityTrade;
import com.wf.portrec.domain.TradeFile;

public interface CommodityTradeRepository extends CrudRepository<CommodityTrade, Long> {

	@Query("Select comm from CommodityTrade comm where comm.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps "
			+ "where tf.portfolioSegment = ps and ps.name = 'Commodities, own' and tf.loadCompleted is not null)")
	public List<CommodityTrade> findSrcTrades();

	@Query("Select um.srcTradeId, comm  from CommodityTrade comm, UsiMapStatic um where "
			+ "comm.usiValue = um.dtccUsi and um.assetClass = 'Commodities'"
			+ "and comm.tradeFile =  "
			+ "(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi "
			+ "where ptfi.portfolioSegment = ppsi.id and ppsi.name='Commodities, DTCC' "
			+ "and ptfi.loadCompleted is not null)")
	public List<Object[]> fetchDtccUsiMap();
	
	@Query("Select um.srcTradeId, comm  from CommodityTrade comm, UsiMapStatic um where "
			+ "comm.usiValue = um.dtccUsi and um.assetClass = 'Commodities'"
			+ "and comm.tradeFile =  "
			+ "(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi "
			+ "where ptfi.portfolioSegment = ppsi.id and ppsi.name='Commodities, ICE' "
			+ "and ptfi.loadCompleted is not null)")
	public List<Object[]> fetchIceUsiMap();
	
	
	@Query("select comm from CommodityTrade comm where comm.tradeFile = " +
			"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ppsi.name= ? and ptfi.loadCompleted is not null)")
	public List<CommodityTrade> findCommDTCCTrades(String comm);
	
	
	@Query("select comm from CommodityTrade comm where comm.tradeFile = " +
			"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Commodities, own' and ptfi.loadCompleted is not null)")
	public List<CommodityTrade> findCommSrcTrades();
	

	@Query("Select comm from CommodityTrade comm where comm.usiValue not in (select um.dtccUsi from UsiMapSlider um where um.assetClass = 'Commodities') " + 
			"and comm.tradeFile = ?")
	public List<CommodityTrade> fetchcommDtccNonUsiMapSlider(TradeFile tradeFile);
	
	// To Get result set for Unlinked Population
	@Query("Select comm2 from CommodityTrade comm1, CommodityTrade comm2 where comm1.tradeFile = ? and comm2.tradeFile = ? and  comm1.usiValue=comm2.usiValue")
	public List<CommodityTrade> findDtccUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);

	@Query("Select comm1 from CommodityTrade comm1, CommodityTrade comm2 where comm1.tradeFile = ? and comm2.tradeFile = ? and  comm1.usiValue=comm2.usiValue")
	public List<CommodityTrade> findSrcUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);
	
	@Query("Select comm from CommodityTrade comm where comm.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = ? ) and comm.usiValue not in (Select dtccUsi from UsiMapStatic where assetClass = 'Commodities' )")
	public List<CommodityTrade> findUnlinkedDtccTrades(String comm);
	
	@Query("Select comm from CommodityTrade comm where comm.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'Commodities, own') and comm.srcTradeId not in (Select srcTradeId from UsiMapStatic where assetClass = 'Commodities' )")
	public List<CommodityTrade> findUnlinkedSrcTrades();
}
