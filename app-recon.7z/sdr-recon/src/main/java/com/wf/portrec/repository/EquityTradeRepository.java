package com.wf.portrec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.wf.portrec.domain.EquityTrade;
import com.wf.portrec.domain.TradeFile;

public interface EquityTradeRepository extends CrudRepository<EquityTrade, Long> {
	
	@Query("select fx from EquityTrade fx where fx.tradeFile = " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Equity VS, own' and ptfi.loadCompleted is not null)")
	public List<EquityTrade> findEqSrcTrades();

	@Query("select fx from EquityTrade fx where fx.tradeFile = " +
			"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ppsi.name= ? and ptfi.loadCompleted is not null)")
	public List<EquityTrade> findEqDTCCTrades(String eq);
			
	
	@Query("select pcr from EquityTrade pcr where pcr.tradeFile = " +
			"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Equity VS, own' and ptfi.loadCompleted is not null)")
	public List<EquityTrade> findEqVsSrcTrades();

	@Query("Select eq from EquityTrade eq where eq.usi not in (select um.dtccUsi from UsiMapSlider um where um.assetClass = 'Equities') " + 
			"and eq.tradeFile = ?")
	public List<EquityTrade> fetchEqDtccNonUsiMapSlider(TradeFile tradeFile);
	
	@Query("Select um.srcTradeId, cr from EquityTrade cr, UsiMapStatic um where "
			+ "cr.usi = um.dtccUsi and um.assetClass = 'Equities'"
			+ "and cr.tradeFile =  "
			+ "(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi "
			+ "where ptfi.portfolioSegment = ppsi.id and ppsi.name= ? and ptfi.loadCompleted is not null)")
	public List<Object[]> fetchDtccUsiMap(String eq);
	
	// To Get result set for Unlinked Population
	@Query("Select eq2 from EquityTrade eq1, EquityTrade eq2 where eq1.tradeFile = ? and eq2.tradeFile = ? and  eq1.usi=eq2.usi")
	public List<EquityTrade> findDtccUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);

	@Query("Select eq1 from EquityTrade eq1, EquityTrade eq2 where eq1.tradeFile = ? and eq2.tradeFile = ? and  eq1.usi=eq2.usi")
	public List<EquityTrade> findSrcUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);
	
	@Query("Select eq from EquityTrade eq where eq.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = ? ) and eq.usi not in (Select dtccUsi from UsiMapStatic where assetClass = 'Equities' )")
	public List<EquityTrade> findUnlinkedDtccTrades(String eq);
	
	@Query("Select eq from EquityTrade eq where eq.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'Equity VS, own') and eq.origTradeId not in (Select srcTradeId from UsiMapStatic where assetClass = 'Equities' )")
	public List<EquityTrade> findUnlinkedSrcTrades();
}
