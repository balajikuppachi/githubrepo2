package com.wf.portrec.domain;

public enum CounterpartyTypeEnum {

	SD("SD"), MSP("MSP"), NON_SD_MSP("Non-SD/MSP"), UNKNOWN("Unknown");
	
	final String counterpartyType;
	
	private CounterpartyTypeEnum(String counterpartyType) {
		this.counterpartyType = counterpartyType;
	}
	
	public String getCounterpartyType() {
		return counterpartyType;
	}
	
	public static CounterpartyTypeEnum getCounterpartyType(String counterptyType) {
		for (CounterpartyTypeEnum value : CounterpartyTypeEnum.values()) {
			if (value.getCounterpartyType() == counterptyType) {
				return value;
			}
		}

		throw new IllegalArgumentException("Unknown Counterparty Type :" + counterptyType);
	}
}
