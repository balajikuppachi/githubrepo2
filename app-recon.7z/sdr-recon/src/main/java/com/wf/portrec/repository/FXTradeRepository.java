package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.FXTrade;
import com.wf.portrec.domain.TradeFile;

public interface FXTradeRepository extends CrudRepository<FXTrade, Long> {
	
	@Query("select fx from FXTrade fx where fx.tradeFile = " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='ForeignExchange, own' and ptfi.loadCompleted is not null)")
	public List<FXTrade> findSrcTrades();
	
	@Query("select fx from FXTrade fx where fx.tradeFile in " +
			"(select ptfi from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ptfi.asOfDate = ? and ppsi.name='ForeignExchange, own' and ptfi.loadCompleted is not null)")
	public List<FXTrade> findAllSrcTrades(Date asOfDate);
	
	@Query("select fx from FXTrade fx where fx.tradeFile = " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='ForeignExchange, DTCC' and ptfi.loadCompleted is not null)")
	public List<FXTrade> findDtccTrades();
	
	// To Get result set for Unlinked Population
/*	@Query("Select fx2 from FXTrade fx1, FXTrade fx2 where fx1.tradeFile = ? and fx2.tradeFile = ? and  fx1.usiValue=fx2.usiValue")
	public List<FXTrade> findDtccUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);

	@Query("Select fx1 from FXTrade fx1, FXTrade fx2 where fx1.tradeFile = ? and fx2.tradeFile = ? and  fx1.usiValue=fx2.usiValue")
	public List<FXTrade> findSrcUsiMatch(TradeFile trSrcFile,TradeFile trDtccFile);*/
	
	@Query("Select fx2 from FXTrade fx1, FXTrade fx2 where fx1.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'ForeignExchange, own')  and fx2.tradeFile = ? and  fx1.usiValue=fx2.usiValue")
	public List<FXTrade> findAllDtccUsiMatch(Date asOfDate,TradeFile trDtccFile);

	@Query("Select fx1 from FXTrade fx1, FXTrade fx2 where fx1.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and tf.asOfDate = ? and ps.name = 'ForeignExchange, own')  and fx2.tradeFile = ? and  fx1.usiValue=fx2.usiValue")
	public List<FXTrade> findAllSrcUsiMatch(Date asOfDate,TradeFile trDtccFile);
	
	@Query("Select fx from FXTrade fx where fx.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'ForeignExchange, DTCC') and fx.usiValue not in (Select dtccUsi from UsiMapStatic where assetClass = 'ForeignExchange' )")
	public List<FXTrade> findUnlinkedDtccTrades();
	
	/*@Query("Select fx from FXTrade fx where fx.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
			"where tf.portfolioSegment = ps and ps.name = 'ForeignExchange, own') and fx.origTradeId not in (Select srcTradeId from UsiMapStatic where assetClass = 'ForeignExchange' )")
	public List<FXTrade> findUnlinkedSrcTrades();*/
/*	@Query("Select fx from FXTrade fx where fx.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'ForeignExchange, own') ")
	public List<FXTrade> findUnlinkedSrcTrades();*/
	
	@Query("Select fx from FXTrade fx where fx.tradeFile in ( Select tf from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps  and tf.asOfDate = ? and ps.name = 'ForeignExchange, own') ")
	public List<FXTrade> findAllUnlinkedSrcTrades(Date asOfDate);
}
