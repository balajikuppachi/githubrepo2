package com.wf.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;



@Entity
@Table(name = "pr_counterparty")
public class Counterparty {

	@Id
	@Column(name = "id")
	@TableGenerator(name="pr_counterparty_id_generator", table="pr_id_sequence", allocationSize=200,
			pkColumnName="seq_name", pkColumnValue="pr_counterparty_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator="pr_counterparty_id_generator")
	Long id;

	@Column(name = "legal_id", nullable = false)
	Long legalId = 0L;

	@Column(name = "legal_name", nullable = false)
	String legalName;

	@Column(name = "email_address")
	String emailAddress;
	
	@Column(name = "cici_code")
	String ciciCode;

	@Column(name = "lei_code")
	String leicode;

	@Column(name = "gtr_code")
	String gtrcode;

	@Column(name = "internal_code")
	String internalCode;

	@Column(name = "last_update_date", nullable = false)
	Date lastUpdateDate;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "cpty_type", nullable = false)
	CounterpartyTypeEnum counterpartyType;

	@Enumerated(EnumType.STRING)
	@Column(name = "one_way_recon", nullable = false)
	BoolEnum oneWayRecon;

	@Enumerated(EnumType.STRING)
	@Column(name = "frequency_type")
	FrequencyTypeEnum frequencyType;
	
	@Column(name = "margin_analyst_email")
	String marginAnalystEmail;
	
	@Column(name = "bus_acct_id")
	String busAcctId;
	
	@Column(name = "bus_acct_name")
	String busAcctName;
	
	@Column(name = "isda_portfolio_recon")
	String isdaPortfolioRecon;
	
	@Column(name = "portfolio_data_method")
	String portfolioDataMethod;
	
	@Column(name = "trioptima_subscriber")
	String trioptimaSubscriber;

	@Column(name = "collat_agrId")
	String collatAgreementId;
	
	@Column(name = "ext_id")
	String externalId;
	
	@Column(name = "ext_system")
	String externalSystem;
	
	public String getBusAcctId() {
		return busAcctId;
	}


	public void setBusAcctId(String busAcctId) {
		this.busAcctId = busAcctId;
	}


	public String getBusAcctName() {
		return busAcctName;
	}


	public void setBusAcctName(String busAcctName) {
		this.busAcctName = busAcctName;
	}


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	

	/**
	 * @return the legalName
	 */
	public String getLegalName() {
		return legalName;
	}

	/**
	 * @param legalName
	 *            the legalName to set
	 */
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the ciciCode
	 */
	public String getCiciCode() {
		return ciciCode;
	}

	/**
	 * @param ciciCode
	 *            the ciciCode to set
	 */
	public void setCiciCode(String ciciCode) {
		this.ciciCode = ciciCode;
	}

	/**
	 * @return the leicode
	 */
	public String getLeicode() {
		return leicode;
	}

	/**
	 * @param leicode
	 *            the leicode to set
	 */
	public void setLeicode(String leicode) {
		this.leicode = leicode;
	}

	/**
	 * @return the gtrcode
	 */
	public String getGtrcode() {
		return gtrcode;
	}

	/**
	 * @param gtrcode
	 *            the gtrcode to set
	 */
	public void setGtrcode(String gtrcode) {
		this.gtrcode = gtrcode;
	}

	/**
	 * @return the internal_code
	 */
	public String getInternalCode() {
		return internalCode;
	}

	/**
	 * @param internalCode
	 *            the internal_code to set
	 */
	public void setInternalCode(String internalCode) {
		this.internalCode = internalCode;
	}

	/**
	 * @return the lastUpdateDate
	 */
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	/**
	 * @param lastUpdateDate
	 *            the lastUpdateDate to set
	 */
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	/**
	 * @return the legalId
	 */
	public Long getLegalId() {
		return legalId;
	}

	/**
	 * @param legalId the legalId to set
	 */
	public void setLegalId(Long legalId) {
		this.legalId = legalId;
	}
	
	

	@Override
	public String toString() {
		return "Counterparty [id=" + id + ", legalId=" + legalId
				+ ", legalName=" + legalName + ", emailAddress=" + emailAddress
				+ ", ciciCode=" + ciciCode + ", leicode=" + leicode
				+ ", gtrcode=" + gtrcode + ", internalCode=" + internalCode
				+ ", lastUpdateDate=" + lastUpdateDate
				+ "]";
	}

	public CounterpartyTypeEnum getCounterpartyType() {
		return counterpartyType;
	}

	public void setCounterpartyType(CounterpartyTypeEnum counterpartyType) {
		this.counterpartyType = counterpartyType;
	}

	public BoolEnum getOneWayRecon() {
		return oneWayRecon;
	}

	public void setOneWayRecon(BoolEnum oneWayRecon) {
		this.oneWayRecon = oneWayRecon;
	}

	public FrequencyTypeEnum getFrequencyType() {
		return frequencyType;
	}

	public void setFrequencyType(FrequencyTypeEnum frequencyType) {
		this.frequencyType = frequencyType;
	}

	public String getMarginAnalystEmail() {
		return marginAnalystEmail;
	}

	public void setMarginAnalystEmail(String marginAnalystEmail) {
		this.marginAnalystEmail = marginAnalystEmail;
	}


	public String getIsdaPortfolioRecon() {
		return isdaPortfolioRecon;
	}


	public void setIsdaPortfolioRecon(String isdaPortfolioRecon) {
		this.isdaPortfolioRecon = isdaPortfolioRecon;
	}


	public String getPortfolioDataMethod() {
		return portfolioDataMethod;
	}


	public void setPortfolioDataMethod(String portfolioDataMethod) {
		this.portfolioDataMethod = portfolioDataMethod;
	}


	public String getTrioptimaSubscriber() {
		return trioptimaSubscriber;
	}


	public void setTrioptimaSubscriber(String trioptimaSubscriber) {
		this.trioptimaSubscriber = trioptimaSubscriber;
	}


	public String getCollatAgreementId() {
		return collatAgreementId;
	}


	public void setCollatAgreementId(String collatAgreementId) {
		this.collatAgreementId = collatAgreementId;
	}


	public String getExternalId() {
		return externalId;
	}


	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}


	public String getExternalSystem() {
		return externalSystem;
	}


	public void setExternalSystem(String externalSystem) {
		this.externalSystem = externalSystem;
	}
}
