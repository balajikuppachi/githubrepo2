package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.CRTradeUnfilterd;
import com.wf.portrec.domain.TradeFile;

public interface CRTradeUnfilterdRepository extends CrudRepository<CRTradeUnfilterd, Long> {
	
	@Query("select pcr from CRTradeUnfilterd pcr where pcr.tradeFile = " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Credit, own' and ptfi.loadCompleted is not null)")
	public List<CRTradeUnfilterd> findSrcTrades();
	
	@Query("Select cr from CRTradeUnfilterd cr where cr.tradeFile = ( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Credit, DTCC')")
	public List<CRTradeUnfilterd> findDtccTrades();
	
	@Query("select t from CRTradeUnfilterd as t where t.tradeFile=?")
	public List<CRTradeUnfilterd> findByFile(TradeFile tradeFile);
	
	@Query("Select um.srcTradeId, cr from CRTradeUnfilterd cr, UsiMapStatic um where " +
	"cr.usi = um.dtccUsi and um.assetClass = 'Credit'" + 
	"and cr.tradeFile =  " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Credit, DTCC' and ptfi.loadCompleted is not null)")
	public List<Object[]> fetchDtccUsiMap();
	
	@Query("Select cr from CRTradeUnfilterd cr where cr.usi not in (select um.dtccUsi from UsiMapSlider um where um.assetClass = 'Credit') " + 
			"and cr.tradeFile = ?")
	public List<CRTradeUnfilterd> fetchCRDtccNonUsiMapSlider(TradeFile tradeFile);

	@Query("select pr from CRTradeUnfilterd pr where pr.id in (select pri.id from CRTradeUnfilterd pri where pri.tradeFile = ? " +
			"group by pri.origTradeId having pri.revisionId = max(pri.revisionId)) " +
			"and pr.tradeFile = ? group by pr.origTradeId having pr.id=max(pr.id)")
	public List<CRTradeUnfilterd> findMaxRevisionTradeByFile(TradeFile fileLeft, TradeFile fileLeft2);
	
	@Query("Select cr from CRTradeUnfilterd cr where cr.tradeParty1=? or cr.tradeParty2=? and cr.tradeFile = (Select max(tff) from TradeFile tff , PortfolioSegment pss where tff.id <( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Credit, DTCC') and tff.portfolioSegment = pss and pss.name = 'Credit, DTCC')")
	public List<CRTradeUnfilterd> findDtccTradesForCpty(String cpty1, String cpty2);
	
	@Query("Select cr from CRTradeUnfilterd cr where cr.tradeParty1=? or cr.tradeParty2=? and cr.runDate = ?")
	public List<CRTradeUnfilterd> findDtccTradesForCptyByDate(String cpty1, String cpty2, Date rundate);
	
	@Query("Select cr from CRTradeUnfilterd cr, TradeFile ptf where cr.runDate=? and (cr.tradeParty1=? or cr.tradeParty2=?) " +
	"and cr.tradeFile=ptf.id and ptf.loadCompleted is not null")
	public List<CRTradeUnfilterd> findDtccTradesForCptyByDateRevised(Date rundate, String cpty1, String cpty2);
}
