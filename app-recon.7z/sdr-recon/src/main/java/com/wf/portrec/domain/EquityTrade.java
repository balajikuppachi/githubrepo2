package com.wf.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.wf.portrec.domain.annotation.UseForMatching;

/**
 * @author u203893
 * @version 1.0
 * 
 */

@Entity
@Table(name = "pr_equity")
public class EquityTrade extends Trade {

	
	@Id
	@Column(name = "id")
	@TableGenerator(name = "pr_equity_id_generator", table = "pr_id_sequence", allocationSize = 200, 
			pkColumnName = "seq_name", pkColumnValue = "pr_equity_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "pr_equity_id_generator")
	Long id;

	//private String tradeId;
//	@Column(name = "orig_trade_id")
//	String origTradeId = "";

	@Column(name = "orig_trade_id")
	String origTradeId;
	
	
	@Column(name = "usi")
	String usi;
	
	
	@Column(name = "party1")
	String party1;

	
	@Column(name = "party2")
	String party2;

	//private String usPersonEntity;

	
	@Column(name = "product_id_value")
	String upi;


	@Column(name = "notional_amount")
	BigDecimal notionalAmount;

	
	@Column(name = "reported_valuation")
	String mtmValue;

	
	@Column(name = "valuation_datetime")
	String mtmValuationDateTime;

	
	@Column(name = "reported_currency")
	String tableAllCurrency;

	@UseForMatching
	@Column(name = "maturity_date")
	Date terminationDate;
	
	
	@Column(name = "execution_date")
	Date executionDate; // From DTCC side, the Column to Retrieve is Trade Date  & from SRC Side, the Column to Retrieve is ExecutionDateTime 

	
	@Column(name = "asset_class")
	String assetClass;
	
	@UseForMatching
	@Column(name = "trade_date")
	Date tradeDate;
	
	@Column(name="submitted_for")
	String submittedFor;
	
	@Column(name="are_we_reporting_party")
	String areWeReportingParty;
	
	
	@Column(name="run_date")
	Date runDate;
	
	/* Added new columns to match with CFTC report.*/ 

	@Column(name = "lei_cp")
	String leiCp;
	
	@Column(name="trade_party_1_financial_entity")
	String tradeParty1financialEntityStatus = "";
	
	@Column(name="trade_party_2_financial_entity")
	String tradeParty2financialEntityStatus = "";
	
	@Column(name="trade_party_1_usperson_indicator")
	String tradeParty1UsPersonIndicator = "";
	
	@Column(name="trade_party_2_usperson_indicator")
	String tradeParty2UsPersonIndicator = "";
	
	@Column(name = "lei_us")
	String leiUs;
	
	@Column(name = "sec_asset_class")
	String secAssetClass = "";
	
	@Column(name="reporting_jurisdiction")
	String reportingJurisdiction = "";
	
	@Column(name="additional_repository_1")
	String additionalRepository1 = "";
	
	@Column(name="additional_repository_2")
	String additionalRepository2 = "";
	
	@Column(name="additional_repository_3")
	String additionalRepository3 = "";
	
	@Column(name="underlying_asset_identifier_type")
	String underlyingAssetIdentifierType = "";
	
	@Column(name="underlying_assets")
	String underlyingAssets = "";
	
	@Column(name="underlying_assets_notional")
	String underlyingAssetsNotional = "";
	
	@Column(name="underlying_assets_notional_curr")
	String underlyingAssetsNotionalCurr = "";
	
	@Column(name="underlying_assets_weighting")
	String underlyingAssetsWeighting = "";
	
	@Column(name="execution_venue")
	String executionVenue = "";	
	
	@UseForMatching
	@Column(name="equity_variance_strike_price")
	BigDecimal equityVarianceStrikePrice;
	
	@Column(name="volatility_strike_price")
	BigDecimal volatilityStrikePrice;
	
	@Column(name="initial_price")
	BigDecimal initialPrice;
	
	@Column(name="price_notation")
	String priceNotation = "";
	
	@Column(name="price_notation_type")
	String priceNotationType = "";	
	
	@Column(name="party1_vega_notional_amount")
	BigDecimal party1VegaNotionalAmount;

	@Column(name="vega_notional_curr")
	String vegaNotionalCurrency = "";
	
	@Column(name="party1_notional_amount")
	BigDecimal party1NotionalAmount;
	
	@Column(name="party1_notional_curr")
	String party1NotionalCurrency = "";
	
	@Column(name="up_front_payment_amount")
	BigDecimal upFrontPaymentAmount;
	
	@Column(name="floating_leg_payment_freq_period")
	String floatingLegPaymentFrequencyPeriod = "";
	
	@Column(name="floating_leg_payment_freq_period_mult")
	String floatingLegPaymentFrequencyPeriodMultiplier = "";
	
	@Column(name="eq_leg_payment_freq_period")
	String eqLegPaymentFrequencyPeriod = "";
	
	@Column(name="collaterlized")
	String collaterlized = "";
	
	@Column(name="is_swap_multi_asset")
	String isSwapMultiAsset = "";
	
	@Column(name="is_swap_mixed")
	String isSwapMixed = "";
	
	@Column(name="add_SDR_for_mixed_swap")
	String additionalSDRForMixedSwap = "";
	
	@Column(name="we_buy_sell")
	String weBuySell = "";
	
	@Column(name="df_etsd_equityderivatives_us")
	String df_ETSD_equityderivatives_Us = "";
	
	@Column(name="df_etsbsd_equityderivatives_us")
	String df_ETSBSD_equityderivatives_Us = "";
	
	@Column(name="df_etmsp_equityderivatives_us")
	String df_ETMSP_equityderivatives_Us = "";
	
	@Column(name="df_etsbmsp_equityderivatives_us")
	String df_ETSBMSP_equityderivatives_Us = "";
	
	@Column(name="df_eteu_endusertype_us")
	String df_ETEU_EndUserType_Us = "";
	
	@Column(name="uspersonentity_us")
	String usPersonEntity_Us = "";
	
	@Column(name="df_etsd_equityderivatives_cp")
	String df_ETSD_equityderivatives_Cp = "";
	
	@Column(name="df_etsbsd_equityderivatives_cp")
	String df_ETSBSD_equityderivatives_Cp = "";
	
	@Column(name="df_etmsp_equityderivatives_cp")
	String df_ETMSP_equityderivatives_Cp = "";
	
	@Column(name="df_etsbmsp_equityderivatives_cp")
	String df_ETSBMSP_equityderivatives_Cp = "";
	
	@Column(name="df_eteu_endusertype_cp")
	String df_ETEU_EndUserType_Cp = "";
	
	@Column(name="uspersonentity_cp")
	String usPersonEntity_Cp = "";
	
	@Column(name="buyer")
	String buyer = "";
	
	@Column(name = "valuation_date")
	Date valuationDate;
	
	@Column(name = "eq_leg_final_valuation_date")
	Date eqLegFinalValuationDate;
	
	@Column(name="premium_amount")
	BigDecimal premiumAmount;
	
	@Column(name="eq_leg_valuation_freq_period")
	String eqLegValuationFreqPeriod = "";
	
	@Column(name="eq_leg_valuation_freq_period_mult")
	String eqLegValuationFreqPeriodMult = "";
	
	@Column(name="flt_leg_payment_freq_period")
	String fltLegPaymentFreqPeriod = "";
	
	@Column(name="flt_leg_payment_freq_period_mult")
	String fltLegPaymentFreqPeriodMult = "";
	
	@Column(name = "eq_leg_payment_date")
	Date eqLegPaymentDate;
	
	@Column(name = "flt_leg_payment_date")
	Date fltLegPaymentDate;
	
	@Column(name = "eq_leg_valuation_date")
	Date eqLegValuationDate;
	
	@Column(name="party_1_role")
	String party1Role = "";
	
	@Column(name="party_2_role")
	String party2Role = "";
	
	@Column(name="revision_id")
	Integer revisionId;
	
	
	@Column(name="trade_party_2_name")
	String tradeParty2Name = "";
	
	public String getTradeParty2Name() {
		return tradeParty2Name;
	}

	public void setTradeParty2Name(String tradeParty2Name) {
		this.tradeParty2Name = tradeParty2Name;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the usiCurrent
	 */
	public String getOrigTradeId() {
		return origTradeId;
	}

	/**
	 * @param usi the usiCurrent to set
	 */
	public void setOrigTradeId(String origTradeId) {
		this.origTradeId = origTradeId;
	}

	/**
	 * @return the usiCurrent
	 */
	public String getUsi() {
		return usi;
	}

	/**
	 * @param usiCurrent the usiCurrent to set
	 */
	public void setUsi(String usi) {
		this.usi = usi;
	}

	/**
	 * @return the leiUS
	 */
	public String getParty1() {
		return party1;
	}

	/**
	 * @param leiUS the leiUS to set
	 */
	public void setParty1(String party1) {
		this.party1 = party1;
	}

	/**
	 * @return the leiCP
	 */
	public String getParty2() {
		return party2;
	}

	/**
	 * @param leiCP the leiCP to set
	 */
	public void setParty2(String party2) {
		this.party2 = party2;
	}

	/**
	 * @return the upi
	 */
	public String getUpi() {
		return upi;
	}

	/**
	 * @param upi the upi to set
	 */
	public void setUpi(String upi) {
		this.upi = upi;
	}

	/**
	 * @return the notionalAmount
	 */
	public BigDecimal getNotionalAmount() {
		return notionalAmount;
	}

	/**
	 * @param notionalAmount the notionalAmount to set
	 */
	public void setNotionalAmount(BigDecimal notionalAmount) {
		this.notionalAmount = notionalAmount;
	}

	/**
	 * @return the mtmValue
	 */
	public String getMtmValue() {
		return mtmValue;
	}

	/**
	 * @param mtmValue the mtmValue to set
	 */
	public void setMtmValue(String mtmValue) {
		this.mtmValue = mtmValue;
	}

	/**
	 * @return the mtmValuationDateTime
	 */
	public String getMtmValuationDateTime() {
		return mtmValuationDateTime;
	}

	/**
	 * @param mtmValuationDateTime the mtmValuationDateTime to set
	 */
	public void setMtmValuationDateTime(String mtmValuationDateTime) {
		this.mtmValuationDateTime = mtmValuationDateTime;
	}

	/**
	 * @return the tableAllCurrency
	 */
	public String getTableAllCurrency() {
		return tableAllCurrency;
	}

	/**
	 * @param tableAllCurrency the tableAllCurrency to set
	 */
	public void setTableAllCurrency(String tableAllCurrency) {
		this.tableAllCurrency = tableAllCurrency;
	}

	/**
	 * @return the terminationDate
	 */
	public Date getTerminationDate() {
		return terminationDate;
	}

	/**
	 * @param terminationDate the terminationDate to set
	 */
	public void setTerminationDate(Date terminationDate) {
		this.terminationDate = terminationDate;
	}

	/**
	 * @return the executionDate
	 */
	public Date getExecutionDate() {
		return executionDate;
	}

	/**
	 * @param executionDate the executionDate to set
	 */
	public void setExecutionDate(Date executionDate) {
		this.executionDate = executionDate;
	}

	/**
	 * @return the assetClass
	 */
	public String getAssetClass() {
		return assetClass;
	}

	/**
	 * @param assetClass the assetClass to set
	 */
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}


	public String getLeiCp() {
		return leiCp;
	}

	public void setLeiCp(String leiCp) {
		this.leiCp = leiCp;
	}

	public String getTradeParty1financialEntityStatus() {
		return tradeParty1financialEntityStatus;
	}

	public void setTradeParty1financialEntityStatus(
			String tradeParty1financialEntityStatus) {
		this.tradeParty1financialEntityStatus = tradeParty1financialEntityStatus;
	}

	public String getTradeParty2financialEntityStatus() {
		return tradeParty2financialEntityStatus;
	}

	public void setTradeParty2financialEntityStatus(
			String tradeParty2financialEntityStatus) {
		this.tradeParty2financialEntityStatus = tradeParty2financialEntityStatus;
	}

	public String getTradeParty1UsPersonIndicator() {
		return tradeParty1UsPersonIndicator;
	}

	public void setTradeParty1UsPersonIndicator(String tradeParty1UsPersonIndicator) {
		this.tradeParty1UsPersonIndicator = tradeParty1UsPersonIndicator;
	}

	public String getTradeParty2UsPersonIndicator() {
		return tradeParty2UsPersonIndicator;
	}

	public void setTradeParty2UsPersonIndicator(String tradeParty2UsPersonIndicator) {
		this.tradeParty2UsPersonIndicator = tradeParty2UsPersonIndicator;
	}

	public String getLeiUs() {
		return leiUs;
	}

	public void setLeiUs(String leiUs) {
		this.leiUs = leiUs;
	}

	public String getSecAssetClass() {
		return secAssetClass;
	}

	public void setSecAssetClass(String secAssetClass) {
		this.secAssetClass = secAssetClass;
	}

	public String getReportingJurisdiction() {
		return reportingJurisdiction;
	}

	public void setReportingJurisdiction(String reportingJurisdiction) {
		this.reportingJurisdiction = reportingJurisdiction;
	}

	public String getAdditionalRepository1() {
		return additionalRepository1;
	}

	public void setAdditionalRepository1(String additionalRepository1) {
		this.additionalRepository1 = additionalRepository1;
	}

	public String getAdditionalRepository2() {
		return additionalRepository2;
	}

	public void setAdditionalRepository2(String additionalRepository2) {
		this.additionalRepository2 = additionalRepository2;
	}

	public String getAdditionalRepository3() {
		return additionalRepository3;
	}

	public void setAdditionalRepository3(String additionalRepository3) {
		this.additionalRepository3 = additionalRepository3;
	}

	public String getUnderlyingAssetIdentifierType() {
		return underlyingAssetIdentifierType;
	}

	public void setUnderlyingAssetIdentifierType(
			String underlyingAssetIdentifierType) {
		this.underlyingAssetIdentifierType = underlyingAssetIdentifierType;
	}

	public String getUnderlyingAssets() {
		return underlyingAssets;
	}

	public void setUnderlyingAssets(String underlyingAssets) {
		this.underlyingAssets = underlyingAssets;
	}

	public String getUnderlyingAssetsNotional() {
		return underlyingAssetsNotional;
	}

	public void setUnderlyingAssetsNotional(String underlyingAssetsNotional) {
		this.underlyingAssetsNotional = underlyingAssetsNotional;
	}

	public String getUnderlyingAssetsNotionalCurr() {
		return underlyingAssetsNotionalCurr;
	}

	public void setUnderlyingAssetsNotionalCurr(String underlyingAssetsNotionalCurr) {
		this.underlyingAssetsNotionalCurr = underlyingAssetsNotionalCurr;
	}

	public String getUnderlyingAssetsWeighting() {
		return underlyingAssetsWeighting;
	}

	public void setUnderlyingAssetsWeighting(String underlyingAssetsWeighting) {
		this.underlyingAssetsWeighting = underlyingAssetsWeighting;
	}

	public String getExecutionVenue() {
		return executionVenue;
	}

	public void setExecutionVenue(String executionVenue) {
		this.executionVenue = executionVenue;
	}



	public BigDecimal getInitialPrice() {
		return initialPrice;
	}

	public void setInitialPrice(BigDecimal initialPrice) {
		this.initialPrice = initialPrice;
	}

	public String getPriceNotation() {
		return priceNotation;
	}

	public void setPriceNotation(String priceNotation) {
		this.priceNotation = priceNotation;
	}

	public String getPriceNotationType() {
		return priceNotationType;
	}

	public void setPriceNotationType(String priceNotationType) {
		this.priceNotationType = priceNotationType;
	}

	public BigDecimal getParty1VegaNotionalAmount() {
		return party1VegaNotionalAmount;
	}

	public void setParty1VegaNotionalAmount(BigDecimal party1VegaNotionalAmount) {
		this.party1VegaNotionalAmount = party1VegaNotionalAmount;
	}

	public String getVegaNotionalCurrency() {
		return vegaNotionalCurrency;
	}

	public void setVegaNotionalCurrency(String vegaNotionalCurrency) {
		this.vegaNotionalCurrency = vegaNotionalCurrency;
	}

	public BigDecimal getParty1NotionalAmount() {
		return party1NotionalAmount;
	}

	public void setParty1NotionalAmount(BigDecimal party1NotionalAmount) {
		this.party1NotionalAmount = party1NotionalAmount;
	}

	public String getParty1NotionalCurrency() {
		return party1NotionalCurrency;
	}

	public void setParty1NotionalCurrency(String party1NotionalCurrency) {
		this.party1NotionalCurrency = party1NotionalCurrency;
	}

	public BigDecimal getUpFrontPaymentAmount() {
		return upFrontPaymentAmount;
	}

	public void setUpFrontPaymentAmount(BigDecimal upFrontPaymentAmount) {
		this.upFrontPaymentAmount = upFrontPaymentAmount;
	}

	public String getFloatingLegPaymentFrequencyPeriod() {
		return floatingLegPaymentFrequencyPeriod;
	}

	public void setFloatingLegPaymentFrequencyPeriod(
			String floatingLegPaymentFrequencyPeriod) {
		this.floatingLegPaymentFrequencyPeriod = floatingLegPaymentFrequencyPeriod;
	}

	public String getFloatingLegPaymentFrequencyPeriodMultiplier() {
		return floatingLegPaymentFrequencyPeriodMultiplier;
	}

	public void setFloatingLegPaymentFrequencyPeriodMultiplier(
			String floatingLegPaymentFrequencyPeriodMultiplier) {
		this.floatingLegPaymentFrequencyPeriodMultiplier = floatingLegPaymentFrequencyPeriodMultiplier;
	}

	public String getEqLegPaymentFrequencyPeriod() {
		return eqLegPaymentFrequencyPeriod;
	}

	public void setEqLegPaymentFrequencyPeriod(String eqLegPaymentFrequencyPeriod) {
		this.eqLegPaymentFrequencyPeriod = eqLegPaymentFrequencyPeriod;
	}

	public String getCollaterlized() {
		return collaterlized;
	}

	public void setCollaterlized(String collaterlized) {
		this.collaterlized = collaterlized;
	}

	public String getIsSwapMultiAsset() {
		return isSwapMultiAsset;
	}

	public void setIsSwapMultiAsset(String isSwapMultiAsset) {
		this.isSwapMultiAsset = isSwapMultiAsset;
	}

	public String getIsSwapMixed() {
		return isSwapMixed;
	}

	public void setIsSwapMixed(String isSwapMixed) {
		this.isSwapMixed = isSwapMixed;
	}

	public String getAdditionalSDRForMixedSwap() {
		return additionalSDRForMixedSwap;
	}

	public void setAdditionalSDRForMixedSwap(String additionalSDRForMixedSwap) {
		this.additionalSDRForMixedSwap = additionalSDRForMixedSwap;
	}

	public String getWeBuySell() {
		return weBuySell;
	}

	public void setWeBuySell(String weBuySell) {
		this.weBuySell = weBuySell;
	}

	public BigDecimal getEquityVarianceStrikePrice() {
		return equityVarianceStrikePrice;
	}

	public void setEquityVarianceStrikePrice(BigDecimal equityVarianceStrikePrice) {
		this.equityVarianceStrikePrice = equityVarianceStrikePrice;
	}

	public BigDecimal getVolatilityStrikePrice() {
		return volatilityStrikePrice;
	}

	public void setVolatilityStrikePrice(BigDecimal volatilityStrikePrice) {
		this.volatilityStrikePrice = volatilityStrikePrice;
	}

	public String getDf_ETSD_equityderivatives_Us() {
		return df_ETSD_equityderivatives_Us;
	}

	public void setDf_ETSD_equityderivatives_Us(String df_ETSD_equityderivatives_Us) {
		this.df_ETSD_equityderivatives_Us = df_ETSD_equityderivatives_Us;
	}

	public String getDf_ETSBSD_equityderivatives_Us() {
		return df_ETSBSD_equityderivatives_Us;
	}

	public void setDf_ETSBSD_equityderivatives_Us(
			String df_ETSBSD_equityderivatives_Us) {
		this.df_ETSBSD_equityderivatives_Us = df_ETSBSD_equityderivatives_Us;
	}

	public String getDf_ETMSP_equityderivatives_Us() {
		return df_ETMSP_equityderivatives_Us;
	}

	public void setDf_ETMSP_equityderivatives_Us(
			String df_ETMSP_equityderivatives_Us) {
		this.df_ETMSP_equityderivatives_Us = df_ETMSP_equityderivatives_Us;
	}

	public String getDf_ETSBMSP_equityderivatives_Us() {
		return df_ETSBMSP_equityderivatives_Us;
	}

	public void setDf_ETSBMSP_equityderivatives_Us(
			String df_ETSBMSP_equityderivatives_Us) {
		this.df_ETSBMSP_equityderivatives_Us = df_ETSBMSP_equityderivatives_Us;
	}

	public String getDf_ETEU_EndUserType_Us() {
		return df_ETEU_EndUserType_Us;
	}

	public void setDf_ETEU_EndUserType_Us(String df_ETEU_EndUserType_Us) {
		this.df_ETEU_EndUserType_Us = df_ETEU_EndUserType_Us;
	}

	public String getUsPersonEntity_Us() {
		return usPersonEntity_Us;
	}

	public void setUsPersonEntity_Us(String usPersonEntity_Us) {
		this.usPersonEntity_Us = usPersonEntity_Us;
	}

	public String getDf_ETSD_equityderivatives_Cp() {
		return df_ETSD_equityderivatives_Cp;
	}

	public void setDf_ETSD_equityderivatives_Cp(String df_ETSD_equityderivatives_Cp) {
		this.df_ETSD_equityderivatives_Cp = df_ETSD_equityderivatives_Cp;
	}

	public String getDf_ETSBSD_equityderivatives_Cp() {
		return df_ETSBSD_equityderivatives_Cp;
	}

	public void setDf_ETSBSD_equityderivatives_Cp(
			String df_ETSBSD_equityderivatives_Cp) {
		this.df_ETSBSD_equityderivatives_Cp = df_ETSBSD_equityderivatives_Cp;
	}

	public String getDf_ETMSP_equityderivatives_Cp() {
		return df_ETMSP_equityderivatives_Cp;
	}

	public void setDf_ETMSP_equityderivatives_Cp(
			String df_ETMSP_equityderivatives_Cp) {
		this.df_ETMSP_equityderivatives_Cp = df_ETMSP_equityderivatives_Cp;
	}

	public String getDf_ETSBMSP_equityderivatives_Cp() {
		return df_ETSBMSP_equityderivatives_Cp;
	}

	public void setDf_ETSBMSP_equityderivatives_Cp(
			String df_ETSBMSP_equityderivatives_Cp) {
		this.df_ETSBMSP_equityderivatives_Cp = df_ETSBMSP_equityderivatives_Cp;
	}

	public String getDf_ETEU_EndUserType_Cp() {
		return df_ETEU_EndUserType_Cp;
	}

	public void setDf_ETEU_EndUserType_Cp(String df_ETEU_EndUserType_Cp) {
		this.df_ETEU_EndUserType_Cp = df_ETEU_EndUserType_Cp;
	}

	public String getUsPersonEntity_Cp() {
		return usPersonEntity_Cp;
	}

	public void setUsPersonEntity_Cp(String usPersonEntity_Cp) {
		this.usPersonEntity_Cp = usPersonEntity_Cp;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public Date getValuationDate() {
		return valuationDate;
	}

	public void setValuationDate(Date valuationDate) {
		this.valuationDate = valuationDate;
	}

	public Date getEqLegFinalValuationDate() {
		return eqLegFinalValuationDate;
	}

	public void setEqLegFinalValuationDate(Date eqLegFinalValuationDate) {
		this.eqLegFinalValuationDate = eqLegFinalValuationDate;
	}

	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getEqLegValuationFreqPeriod() {
		return eqLegValuationFreqPeriod;
	}

	public void setEqLegValuationFreqPeriod(String eqLegValuationFreqPeriod) {
		this.eqLegValuationFreqPeriod = eqLegValuationFreqPeriod;
	}

	public String getEqLegValuationFreqPeriodMult() {
		return eqLegValuationFreqPeriodMult;
	}

	public void setEqLegValuationFreqPeriodMult(String eqLegValuationFreqPeriodMult) {
		this.eqLegValuationFreqPeriodMult = eqLegValuationFreqPeriodMult;
	}

	public String getFltLegPaymentFreqPeriod() {
		return fltLegPaymentFreqPeriod;
	}

	public void setFltLegPaymentFreqPeriod(String fltLegPaymentFreqPeriod) {
		this.fltLegPaymentFreqPeriod = fltLegPaymentFreqPeriod;
	}

	public String getFltLegPaymentFreqPeriodMult() {
		return fltLegPaymentFreqPeriodMult;
	}

	public void setFltLegPaymentFreqPeriodMult(String fltLegPaymentFreqPeriodMult) {
		this.fltLegPaymentFreqPeriodMult = fltLegPaymentFreqPeriodMult;
	}

	public Date getEqLegPaymentDate() {
		return eqLegPaymentDate;
	}

	public void setEqLegPaymentDate(Date eqLegPaymentDate) {
		this.eqLegPaymentDate = eqLegPaymentDate;
	}

	public Date getFltLegPaymentDate() {
		return fltLegPaymentDate;
	}

	public void setFltLegPaymentDate(Date fltLegPaymentDate) {
		this.fltLegPaymentDate = fltLegPaymentDate;
	}

	public Date getEqLegValuationDate() {
		return eqLegValuationDate;
	}

	public void setEqLegValuationDate(Date eqLegValuationDate) {
		this.eqLegValuationDate = eqLegValuationDate;
	}

	public String getParty1Role() {
		return party1Role;
	}

	public void setParty1Role(String party1Role) {
		this.party1Role = party1Role;
	}

	public String getParty2Role() {
		return party2Role;
	}

	public void setParty2Role(String party2Role) {
		this.party2Role = party2Role;
	}

	public Integer getRevisionId() {
		return revisionId;
	}

	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	public String getSubmittedFor() {
		return submittedFor;
	}

	public void setSubmittedFor(String submittedFor) {
		this.submittedFor = submittedFor;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}

	public String getAreWeReportingParty() {
		return areWeReportingParty;
	}

	public void setAreWeReportingParty(String areWeReportingParty) {
		this.areWeReportingParty = areWeReportingParty;
	}


	
}