package com.wf.portrec.service.report.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wf.df.da.service.PortrecFilesListHelper;
import com.wf.df.sdr.dao.SdrCptyPortfolioReconDao;
import com.wf.df.sdr.dao.spring.PortfolioViewExtnDaoImpl;
import com.wf.df.sdr.dao.spring.SdrCptyPortfolioReconExtnDaoImpl;
import com.wf.portrec.domain.CptyReportDetail;
import com.wf.portrec.service.business.CalendarService;
import com.wf.portrec.service.report.CptyDataHelper;
import com.wf.portrec.service.report.TriggerAllCptyCsvGenerators;
import com.wf.portrec.service.report.ValuationGenerator;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

@Service
@ManagedResource(description="Trigger Portfolio MT VAL generation")
public class TriggerPortfolioGenerationService {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Value ("${portrec.quarter1.end.date}") String lastDayOfQuarter1;
	@Value ("${portrec.quarter2.end.date}") String lastDayOfQuarter2;
	@Value ("${portrec.quarter3.end.date}") String lastDayOfQuarter3;
	@Value ("${portrec.quarter4.end.date}") String lastDayOfQuarter4;
	@Value ("${portrec.annual.date}") String annualDate;
	
	@Value ("${portrec.recon.date}") String reconDt;
	
	@Value ("${portrec.nfs.folder}") String nfsFolder;
	
	@Autowired
	ValuationGenerator valuationGenerator;
	
	@Autowired
	SdrCptyPortfolioReconDao sdrCptyPortfolioReconDao;
	
	@Autowired
	TriggerAllCptyCsvGenerators triggerAllCptyCsvGenerators;

	@Autowired
	PortfolioViewExtnDaoImpl portfolioViewExtnDaoImpl;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@Autowired
	PortrecFilesListHelper portrecFilesListHelper;
	
	@Autowired
	SdrCptyPortfolioReconExtnDaoImpl sdrCptyPortfolioReconExtnDaoImpl;
	
	@Autowired
	CalendarService calendarService;
	
	@ManagedOperation(description="Trigger Portfolio MT VAL generation")
	public void triggerPortfolioReporting(String frequency, String rcDate,  Long portReconId){
		Date reconDate = new Date();
		try {
			reconDate = new SimpleDateFormat("yyyy-MM-dd").parse(rcDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		List<Long> listOfDistinctLegalIds = sdrCptyPortfolioReconExtnDaoImpl.fetchDistinctLegalId(frequency, reconDate, portReconId);
		logger.info("Number of distinct legal Ids :"+ listOfDistinctLegalIds.size());
		
		for (Long legalId : listOfDistinctLegalIds) {
			logger.info("Triggering Portfolio Recon for legal_id : " + legalId);
			generate(legalId, frequency, reconDate, portReconId);
		}
		
		// check cpty report detail table and insert into DA table
		updateDerivativeAnalyticsRepository(portReconId);
		
		logger.info("Completed "+frequency+" Recon");
	}

	private void updateDerivativeAnalyticsRepository(Long portReconId) {

		List<CptyReportDetail> listOfValidReports = cptyDataHelper.getValidCptyReportDetailsByReconId(portReconId);
		
		if(null != listOfValidReports && !listOfValidReports.isEmpty()){
			logger.info("Updating DA table for listOfValidReports =["+ listOfValidReports.size());
			for(CptyReportDetail reportDetail : listOfValidReports){
				
				portrecFilesListHelper.createPortrecListEntry(reportDetail.getCptyReportDetailPk().getLegalId(), reportDetail.getCptyReportDetailPk().getAssetClass(), reportDetail.getFileName(), nfsFolder, 
						reportDetail.getPeriod(), reportDetail.getCptyReportDetailPk().getReconDate(), reportDetail.getFileTag(), ReportConstants.NOT_REVISED);
			}
		}else{
			logger.info("No record found to update DA");
		}
	}

	public boolean generate(Long legalId, String frequency, Date reconDate, Long portReconId){
		boolean valMTFlag = false;
		boolean valFlag = false;
		boolean mtFlag = false;
		OutputFileProperties mtProp = new OutputFileProperties();
		OutputFileProperties valProp = new OutputFileProperties();
		
		String period = "" + frequency.charAt(0) ;
		
		try {
			Date rtDate = new SimpleDateFormat("MM/dd/yyyy").parse(getLastQuarterDate(frequency));
			Date nextQuarterFirstBizDate = calendarService.getNextWorkingDay(rtDate);
			mtProp = triggerAllCptyCsvGenerators.generateAllCptyMTFiles(portfolioViewExtnDaoImpl.fetchLeiForGivenLegalId(legalId, frequency, portReconId), String.valueOf(legalId), nextQuarterFirstBizDate, period, portReconId); 
			mtFlag = mtProp.isFlag();			
			
			//Long legalId = Long.valueOf(cptyMasterData.getLegalId());
			
			valProp = valuationGenerator.generateValuationsForCurrentDate(legalId, getLastQuarterDate(frequency), period, portReconId);
			valFlag = valProp.isFlag();
			
		} catch (IOException e) {
			logger.error("I/O exception while generating temp valuation file");
			
		} catch (ParseException e) {
			logger.error("Parse exception while generating temp valuation file");
		}
		
		
		if(valFlag || mtFlag)
		{
			valMTFlag = true;
			logger.info("Update cpty report detail with validity Y where legal id =["+ legalId +"] and port recon id =[" + portReconId +"]");
			cptyDataHelper.updateCptyReportDetailEligibility(String.valueOf(legalId), portReconId);
		}	
		/*
		 * Update the eligibility of the counter party
		 * */
		
		if(mtFlag && valFlag){
			if(mtProp.getCount() == valProp.getCount()){
				logger.info("MT and VAL count matches for legal id : "+ legalId);
				/*logger.info("Update cpty report detail with validity Y where legal id =["+ legalId +"] and port recon id =[" + portReconId +"]");
				cptyDataHelper.updateCptyReportDetailEligibility(legalId, portReconId);*/
			}
		}
		return valMTFlag;
	}
	
	public String getLastQuarterDate(String freq)
	{
		if(freq.equals("QUARTER_1"))
			return lastDayOfQuarter1;
		if(freq.equals("QUARTER_2"))
			return lastDayOfQuarter2;
		if(freq.equals("QUARTER_3"))
			return lastDayOfQuarter3;
		if(freq.equals("QUARTER_4"))
			return lastDayOfQuarter4;
		if(freq.equals("ANNUALLY"))
			return annualDate;
		if(freq.startsWith("QUARTERLY"))
			return lastDayOfQuarter4;
		else
			 return "";
		
	}
	
	private Date getReconDateFrom(String reconDate) {
		
		//yyyy-MM-dd
		DateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;
		try {
			date = dateFormatter.parse(reconDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
			
		return date;
	}

}
