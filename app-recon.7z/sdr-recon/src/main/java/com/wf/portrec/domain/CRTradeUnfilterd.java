package com.wf.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.wf.portrec.domain.annotation.UseForMatching;

/**
 * @author u250429
 * @version 1.0
 * 
 *          CRTrade Class, which has common params for both DTCC and SRC Credit
 *          Files.
 * 
 * 
 */

@Entity
@Table(name = "pr_credit_unfilterd")
public class CRTradeUnfilterd extends Trade {


	@Id
	@Column(name = "id")
	@TableGenerator(name="pr_credit_id_generator", table="pr_id_sequence", allocationSize=200,
			pkColumnName="seq_name", pkColumnValue="pr_credit_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator="pr_credit_id_generator")
	Long id;

	@Column(name = "usi")
	String usi = "";

	
	@Column(name = "usi_prefix")
	String usiPrefix = "";

	
	
	@Column(name = "primary_asset_class")
	String primaryAssetClass = "";

	
	@Column(name = "secondary_asset_class")
	String secondaryAssetClass = "";

	
	@Column(name = "trade_party1_role")
	String tradeParty1Role = "";

	
	
	@Column(name = "trade_party1")
	String tradeParty1 = "";

	
	@Column(name = "trade_party2_role")
	String tradeParty2Role = "";

	
	
	@Column(name = "trade_party2")
	String tradeParty2 = "";

	
	@Column(name = "product_type_prefix")
	String productTypePrefix = "";

	
	
	@Column(name = "product_type")
	String productType = "";

	
	@Column(name = "scheduled_termination_date")
	Date scheduledTerminationDate;

	
	@Column(name = "effective_date")
	Date effectiveDate;

	@UseForMatching
	@Column(name = "notional_amount_1")
	BigDecimal notionalAmount1;

	
	
	@Column(name = "notional_currency_1")
	String notionalCurrency1 = "";

	
	@Column(name = "collateralized")
	String collateralized = "";

	
	@Column(name = "mandatory_clearing_indicator")
	String mandatoryClearingIndicator = "";

	
	@Column(name = "payment_frequency_period_1")
	String paymentFrequencyPeriod1 = "";

	
	@Column(name = "payment_frequency_period_multiplier_1")
	String paymentFrequencyPeriodMultiplier1 = "";

	
	
	@Column(name = "option_strike_price")
	String optionStrikePrice = "";

	
	@Column(name = "execution_venue_prefix")
	String executionVenuePrefix = "";

	
	@Column(name = "execution_venue")
	String executionVenue = "";

	
	@Column(name = "additional_repository_1_lei")
	String additionalRepository1Lei = "";

	
	@Column(name = "trader_location_party1")
	String traderLocationParty1 = "";

	
	@Column(name = "trader_location_party2")
	String traderLocationParty2 = "";

	
	@Column(name = "allocation_indicator")
	String allocationIndicator = "";

	
	@Column(name = "trade_party1_lei")
	String tradeParty1LEI = "";

	
	@Column(name = "trade_party2_lei")
	String tradeParty2LEI = "";

	
	@Column(name = "buyer")
	String buyer = "";
	
	@Column(name = "buyer_lei_prefix")
	String buyerLEIPrefix;

	@Column(name = "buyer_lei_value")
	String buyerLEIValue;

	
	@Column(name = "seller")
	String seller = "";

	@Column(name = "orig_trade_id")
	String origTradeId = "";

	@Column(name = "submitted_for")
	String submittedFor = "";

	@Column(name="reporting_party")
	String reportingParty;
	
	
	@Column(name="reference_entity")
	String referenceEntity = "";	

	
	
	@Column(name="execution_date")
	Date executionDate;
	
	@Column(name="trade_party_1_financial_entity")
	String tradeParty1financialEntity = "";
	
	@Column(name="trade_party_2_financial_entity")
	String tradeParty2financialEntity = "";
	
	@Column(name="trade_party_1_usperson_indicator")
	String tradeParty1UsPersonIndicator = "";
	
	@Column(name="trade_party_2_usperson_indicator")
	String tradeParty2UsPersonIndicator = "";
	
	@Column(name="reporting_jurisdiction")
	String reportingJurisdiction = "";
	
	
	@Column(name="underlying_asset")
	String underlyingAsset = "";
	
	@Column(name = "fixed_rate_per_annum")
	BigDecimal fixedRatePerAnnum;
	
	@Column(name = "disputed_notional_amount_1")
	BigDecimal disputedNotionalAmount1;

	@Column(name = "disputed_notional_currency_1")
	String disputedNotionalCurrency1 = "";
	
	@Column(name = "single_payment_amount")
	BigDecimal singlePaymentAmount;

	@Column(name = "single_payment_currency")
	String singlePaymentCurrency = "";
	
	@Column(name = "initial_payment_amount")
	BigDecimal initialPaymentAmount;

	@Column(name = "initial_payment_currency")
	String initialPaymentCurrency = "";
	
	
	@Column(name = "verified_notional_amount_1")
	BigDecimal verifiedNotionalAmount1;
	
	@Column(name = "verified_notional_currency_1")
	String verifiedNotionalCurrency1;
	
	
	
	@Column(name="run_date")
	Date runDate;
	
	@Column(name="revision_id")
	Integer revisionId;
	
	@UseForMatching
	@Column(name = "trade_date")
	Date tradeDate;

	

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the usi
	 */
	public String getUsi() {
		return usi;
	}

	/**
	 * @param usi
	 *            the usi to set
	 */
	public void setUsi(String usi) {
		this.usi = usi;
	}

	/**
	 * @return the usiPrefix
	 */
	public String getUsiPrefix() {
		return usiPrefix;
	}

	/**
	 * @param usiPrefix
	 *            the usiPrefix to set
	 */
	public void setUsiPrefix(String usiPrefix) {
		this.usiPrefix = usiPrefix;
	}

	/**
	 * @return the primaryAssetClass
	 */
	public String getPrimaryAssetClass() {
		return primaryAssetClass;
	}

	/**
	 * @param primaryAssetClass
	 *            the primaryAssetClass to set
	 */
	public void setPrimaryAssetClass(String primaryAssetClass) {
		this.primaryAssetClass = primaryAssetClass;
	}

	/**
	 * @return the secondaryAssetClass
	 */
	public String getSecondaryAssetClass() {
		return secondaryAssetClass;
	}

	/**
	 * @param secondaryAssetClass
	 *            the secondaryAssetClass to set
	 */
	public void setSecondaryAssetClass(String secondaryAssetClass) {
		this.secondaryAssetClass = secondaryAssetClass;
	}

	/**
	 * @return the tradeParty1Role
	 */
	public String getTradeParty1Role() {
		return tradeParty1Role;
	}

	/**
	 * @param tradeParty1Role
	 *            the tradeParty1Role to set
	 */
	public void setTradeParty1Role(String tradeParty1Role) {
		this.tradeParty1Role = tradeParty1Role;
	}

	/**
	 * @return the tradeParty1
	 */
	public String getTradeParty1() {
		return tradeParty1;
	}

	/**
	 * @param tradeParty1
	 *            the tradeParty1 to set
	 */
	public void setTradeParty1(String tradeParty1) {
		this.tradeParty1 = tradeParty1;
	}

	/**
	 * @return the tradeParty2Role
	 */
	public String getTradeParty2Role() {
		return tradeParty2Role;
	}

	/**
	 * @param tradeParty2Role
	 *            the tradeParty2Role to set
	 */
	public void setTradeParty2Role(String tradeParty2Role) {
		this.tradeParty2Role = tradeParty2Role;
	}

	/**
	 * @return the tradeParty2
	 */
	public String getTradeParty2() {
		return tradeParty2;
	}

	/**
	 * @param tradeParty2
	 *            the tradeParty2 to set
	 */
	public void setTradeParty2(String tradeParty2) {
		this.tradeParty2 = tradeParty2;
	}


	/**
	 * @return the scheduledTerminationDate
	 */
	public Date getScheduledTerminationDate() {
		return scheduledTerminationDate;
	}

	/**
	 * @param scheduledTerminationDate
	 *            the scheduledTerminationDate to set
	 */
	public void setScheduledTerminationDate(Date scheduledTerminationDate) {
		this.scheduledTerminationDate = scheduledTerminationDate;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate
	 *            the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	
	/**
	 * @return the notionalCurrency1
	 */
	public String getNotionalCurrency1() {
		return notionalCurrency1;
	}

	/**
	 * @param notionalCurrency1
	 *            the notionalCurrency1 to set
	 */
	public void setNotionalCurrency1(String notionalCurrency1) {
		this.notionalCurrency1 = notionalCurrency1;
	}

	/**
	 * @return the collateralized
	 */
	public String getCollateralized() {
		return collateralized;
	}

	/**
	 * @param collateralized
	 *            the collateralized to set
	 */
	public void setCollateralized(String collateralized) {
		this.collateralized = collateralized;
	}

	/**
	 * @return the mandatoryClearingIndicator
	 */
	public String getMandatoryClearingIndicator() {
		return mandatoryClearingIndicator;
	}

	/**
	 * @param mandatoryClearingIndicator
	 *            the mandatoryClearingIndicator to set
	 */
	public void setMandatoryClearingIndicator(String mandatoryClearingIndicator) {
		this.mandatoryClearingIndicator = mandatoryClearingIndicator;
	}

	/**
	 * @return the paymentFrequencyPeriod1
	 */
	public String getPaymentFrequencyPeriod1() {
		return paymentFrequencyPeriod1;
	}

	/**
	 * @param paymentFrequencyPeriod1
	 *            the paymentFrequencyPeriod1 to set
	 */
	public void setPaymentFrequencyPeriod1(String paymentFrequencyPeriod1) {
		this.paymentFrequencyPeriod1 = paymentFrequencyPeriod1;
	}

	/**
	 * @return the paymentFrequencyPeriodMultiplier1
	 */
	public String getPaymentFrequencyPeriodMultiplier1() {
		return paymentFrequencyPeriodMultiplier1;
	}

	/**
	 * @param paymentFrequencyPeriodMultiplier1
	 *            the paymentFrequencyPeriodMultiplier1 to set
	 */
	public void setPaymentFrequencyPeriodMultiplier1(String paymentFrequencyPeriodMultiplier1) {
		this.paymentFrequencyPeriodMultiplier1 = paymentFrequencyPeriodMultiplier1;
	}

	/**
	 * @return the optionStrikePrice
	 */
	public String getOptionStrikePrice() {
		return optionStrikePrice;
	}

	/**
	 * @param optionStrikePrice
	 *            the optionStrikePrice to set
	 */
	public void setOptionStrikePrice(String optionStrikePrice) {
		this.optionStrikePrice = optionStrikePrice;
	}

	/**
	 * @return the executionVenuePrefix
	 */
	public String getExecutionVenuePrefix() {
		return executionVenuePrefix;
	}

	/**
	 * @param executionVenuePrefix
	 *            the executionVenuePrefix to set
	 */
	public void setExecutionVenuePrefix(String executionVenuePrefix) {
		this.executionVenuePrefix = executionVenuePrefix;
	}

	/**
	 * @return the executionVenue
	 */
	public String getExecutionVenue() {
		return executionVenue;
	}

	/**
	 * @param executionVenue
	 *            the executionVenue to set
	 */
	public void setExecutionVenue(String executionVenue) {
		this.executionVenue = executionVenue;
	}

	/**
	 * @return the additionalRepository1Lei
	 */
	public String getAdditionalRepository1Lei() {
		return additionalRepository1Lei;
	}

	/**
	 * @param additionalRepository1Lei
	 *            the additionalRepository1Lei to set
	 */
	public void setAdditionalRepository1Lei(String additionalRepository1Lei) {
		this.additionalRepository1Lei = additionalRepository1Lei;
	}

	/**
	 * @return the traderLocationParty1
	 */
	public String getTraderLocationParty1() {
		return traderLocationParty1;
	}

	/**
	 * @param traderLocationParty1
	 *            the traderLocationParty1 to set
	 */
	public void setTraderLocationParty1(String traderLocationParty1) {
		this.traderLocationParty1 = traderLocationParty1;
	}

	/**
	 * @return the traderLocationParty2
	 */
	public String getTraderLocationParty2() {
		return traderLocationParty2;
	}

	/**
	 * @param traderLocationParty2
	 *            the traderLocationParty2 to set
	 */
	public void setTraderLocationParty2(String traderLocationParty2) {
		this.traderLocationParty2 = traderLocationParty2;
	}

	/**
	 * @return the allocationIndicator
	 */
	public String getAllocationIndicator() {
		return allocationIndicator;
	}

	/**
	 * @param allocationIndicator
	 *            the allocationIndicator to set
	 */
	public void setAllocationIndicator(String allocationIndicator) {
		this.allocationIndicator = allocationIndicator;
	}

	/**
	 * @return the tradeParty1LEI
	 */
	public String getTradeParty1LEI() {
		return tradeParty1LEI;
	}

	/**
	 * @param tradeParty1LEI
	 *            the tradeParty1LEI to set
	 */
	public void setTradeParty1LEI(String tradeParty1LEI) {
		this.tradeParty1LEI = tradeParty1LEI;
	}

	/**
	 * @return the tradeParty2LEI
	 */
	public String getTradeParty2LEI() {
		return tradeParty2LEI;
	}

	/**
	 * @param tradeParty2LEI
	 *            the tradeParty2LEI to set
	 */
	public void setTradeParty2LEI(String tradeParty2LEI) {
		this.tradeParty2LEI = tradeParty2LEI;
	}

	/**
	 * @return the buyer
	 */
	public String getBuyer() {
		return buyer;
	}

	/**
	 * @param buyer
	 *            the buyer to set
	 */
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	
	
	/**
	 * @return the buyerLEIPrefix
	 */
	public String getBuyerLEIPrefix() {
		return buyerLEIPrefix;
	}
	
	/**
	 * @param buyerLEIPrefix
	 *            the buyer to set
	 */
	public void setBuyerLEIPrefix(String buyerLEIPrefix) {
		this.buyerLEIPrefix = buyerLEIPrefix;
	}

	/**
	 * @return the buyerLEIValue
	 */
	public String getBuyerLEIValue() {
		return buyerLEIValue;
	}
	
	/**
	 * @param buyerLEIValue
	 *            the buyer to set
	 */
	public void setBuyerLEIValue(String buyerLEIValue) {
		this.buyerLEIValue = buyerLEIValue;
	}

	/**
	 * @return the seller
	 */
	public String getSeller() {
		return seller;
	}

	/**
	 * @param seller
	 *            the seller to set
	 */
	public void setSeller(String seller) {
		this.seller = seller;
	}

	/**
	 * @return the origTradeId
	 */
	public String getOrigTradeId() {
		return origTradeId;
	}

	/**
	 * @param origTradeId
	 *            the origTradeId to set
	 */
	public void setOrigTradeId(String origTradeId) {
		this.origTradeId = origTradeId;
	}

	/**
	 * @return the dataSubmitterLEIValue
	 */
	public String getSubmittedFor() {
		return submittedFor;
	}

	/**
	 * @param SubmittedFor
	 *            the SubmittedFor to set
	 */
	public void setSubmittedFor(String submittedFor) {
		this.submittedFor = submittedFor;
	}

	/**
	 * @return the reportingParty
	 */
	public String getReportingParty() {
		return reportingParty;
	}

	/**
	 * @param reportingParty the reportingParty to set
	 */
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}

	/**
	 * @return the referenceEntity
	 */
	public String getReferenceEntity() {
		return referenceEntity;
	}

	/**
	 * @param referenceEntity the referenceEntity to set
	 */
	public void setReferenceEntity(String referenceEntity) {
		this.referenceEntity = referenceEntity;
	}

	/**
	 * @return the notionalAmount1
	 */
	public BigDecimal getNotionalAmount1() {
		return notionalAmount1;
	}

	/**
	 * @param notionalAmount1 the notionalAmount1 to set
	 */
	public void setNotionalAmount1(BigDecimal notionalAmount1) {
		this.notionalAmount1 = notionalAmount1;
	}

	public Date getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(Date executionDate) {
		this.executionDate = executionDate;
	}

	

	public String getTradeParty1financialEntity() {
		return tradeParty1financialEntity;
	}

	public void setTradeParty1financialEntity(String tradeParty1financialEntity) {
		this.tradeParty1financialEntity = tradeParty1financialEntity;
	}

	public String getTradeParty2financialEntity() {
		return tradeParty2financialEntity;
	}

	public void setTradeParty2financialEntity(String tradeParty2financialEntity) {
		this.tradeParty2financialEntity = tradeParty2financialEntity;
	}

	public String getTradeParty1UsPersonIndicator() {
		return tradeParty1UsPersonIndicator;
	}

	public void setTradeParty1UsPersonIndicator(String tradeParty1UsPersonIndicator) {
		this.tradeParty1UsPersonIndicator = tradeParty1UsPersonIndicator;
	}

	public String getTradeParty2UsPersonIndicator() {
		return tradeParty2UsPersonIndicator;
	}

	public void setTradeParty2UsPersonIndicator(String tradeParty2UsPersonIndicator) {
		this.tradeParty2UsPersonIndicator = tradeParty2UsPersonIndicator;
	}

	public String getReportingJurisdiction() {
		return reportingJurisdiction;
	}

	public void setReportingJurisdiction(String reportingJurisdiction) {
		this.reportingJurisdiction = reportingJurisdiction;
	}

	public String getUnderlyingAsset() {
		return underlyingAsset;
	}

	public void setUnderlyingAsset(String underlyingAsset) {
		this.underlyingAsset = underlyingAsset;
	}

	public BigDecimal getFixedRatePerAnnum() {
		return fixedRatePerAnnum;
	}

	public void setFixedRatePerAnnum(BigDecimal fixedRatePerAnnum) {
		this.fixedRatePerAnnum = fixedRatePerAnnum;
	}

	public BigDecimal getDisputedNotionalAmount1() {
		return disputedNotionalAmount1;
	}

	public void setDisputedNotionalAmount1(BigDecimal disputedNotionalAmount1) {
		this.disputedNotionalAmount1 = disputedNotionalAmount1;
	}

	public String getDisputedNotionalCurrency1() {
		return disputedNotionalCurrency1;
	}

	public void setDisputedNotionalCurrency1(String disputedNotionalCurrency1) {
		this.disputedNotionalCurrency1 = disputedNotionalCurrency1;
	}

	public BigDecimal getSinglePaymentAmount() {
		return singlePaymentAmount;
	}

	public void setSinglePaymentAmount(BigDecimal singlePaymentAmount) {
		this.singlePaymentAmount = singlePaymentAmount;
	}

	public String getSinglePaymentCurrency() {
		return singlePaymentCurrency;
	}

	public void setSinglePaymentCurrency(String singlePaymentCurrency) {
		this.singlePaymentCurrency = singlePaymentCurrency;
	}

	public BigDecimal getInitialPaymentAmount() {
		return initialPaymentAmount;
	}

	public void setInitialPaymentAmount(BigDecimal initialPaymentAmount) {
		this.initialPaymentAmount = initialPaymentAmount;
	}

	public String getInitialPaymentCurrency() {
		return initialPaymentCurrency;
	}

	public void setInitialPaymentCurrency(String initialPaymentCurrency) {
		this.initialPaymentCurrency = initialPaymentCurrency;
	}

	/**
	 * @return the verifiedNotionalAmount1
	 */
	public BigDecimal getVerifiedNotionalAmount1() {
		return verifiedNotionalAmount1;
	}

	/**
	 * @param verifiedNotionalAmount1 the verifiedNotionalAmount1 to set
	 */
	public void setVerifiedNotionalAmount1(BigDecimal verifiedNotionalAmount1) {
		this.verifiedNotionalAmount1 = verifiedNotionalAmount1;
	}

	/**
	 * @return the verifiedNotionalCurrency1
	 */
	public String getVerifiedNotionalCurrency1() {
		return verifiedNotionalCurrency1;
	}

	/**
	 * @param verifiedNotionalCurrency1 the verifiedNotionalCurrency1 to set
	 */
	public void setVerifiedNotionalCurrency1(String verifiedNotionalCurrency1) {
		this.verifiedNotionalCurrency1 = verifiedNotionalCurrency1;
	}

	
	public Integer getRevisionId() {
		return revisionId;
	}

	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public String getProductTypePrefix() {
		return productTypePrefix;
	}

	public void setProductTypePrefix(String productTypePrefix) {
		this.productTypePrefix = productTypePrefix;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	
}
