package com.wf.portrec.service.loader;

import java.text.ParseException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.SdrPortfolioRecon;
import com.wf.portrec.domain.CptyPortfolioRecon;
import com.wf.portrec.domain.RecCommMtermsStore;
import com.wf.portrec.domain.TradeRecordTypeEnum;

//@Service
@Component
//@Transactional(value="portrec", propagation=Propagation.NEVER)
@ManagedResource(description="CptySdrReader request ")
public class CptySdrReader extends CptyLoaderHelper {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	public static String PORTFOLIO_SEGMENT_NAME = "ForeignExchange, own";
	
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.COM;
	}
	
	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}
	
	@Override
	public boolean validate(CptyPortfolioRecon trade) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public CptyPortfolioRecon parseRecord(RecCommMtermsStore commodity)
			throws ParseException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@ManagedOperation(description="reading file request ")
	public void invoke(){
		SdrPortfolioRecon portRecon=new SdrPortfolioRecon(new Date());
		try{
			portRecon = startRecon(portRecon);
			initCptyRecons(portRecon);
		}
		catch(Exception e){
			logger.error("Error:"+e.getLocalizedMessage());
		}
	}
}