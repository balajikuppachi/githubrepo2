package com.wf.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@MappedSuperclass
public class Trade {
	
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "trade_file_id", nullable = false)
	TradeFile tradeFile;

	public TradeFile getTradeFile() {
		return tradeFile;
	}

	public void setTradeFile(TradeFile tradeFile) {
		this.tradeFile = tradeFile;
	}

	
}
