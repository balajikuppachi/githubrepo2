package com.wf.df.sdr;

import javax.xml.bind.annotation.XmlElementRef;

import org.junit.Test;

//import com.wf.df.sdr.metadata.ReportTemplate;

public class JaxbVersionTest {
	/**
	 * Verifies that JAXB 2.2 library is on the classpath by checking for "required" attribute of XmlElementRef
	 * @throws SecurityException
	 * @throws NoSuchMethodException
	 */
	@Test
	public void testRequiredAttributeForXmlElementRef() throws SecurityException, NoSuchMethodException {
//		XmlElementRef a = ReportTemplate.class.getMethod("getProperties").getAnnotation(XmlElementRef.class);
//		a.required();
	}
}
