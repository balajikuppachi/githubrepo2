package com.wf.df.sdr;

import org.junit.Test;


public class ApplicationStartupTest {

    @Test
    public void testApplicationStartup() throws Exception {
//        final ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
//        context.setConfigLocation(SDRApp.APPLICATION_CONTEXT_CONFIG_LOCATION);
//        try {
//        	context.refresh();
//        } finally {
//            context.close();
//        }
    }
}
