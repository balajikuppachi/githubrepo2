package com.wf.df.sdr;

import org.apache.log4j.Logger;
import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.ws.client.core.WebServiceTemplate;

//import com.wf.df.sdr.message.GetFileAsAttachment;
//import com.wf.df.sdr.message.GetFileAsAttachmentResponse;
 


public class DocumentWSFetchTest {
//	private String username = "app1cwf";
//	private String password = "QzBtcG9zaXRl";
	
	Logger logger = Logger.getLogger(this.getClass());

	
//	@Autowired
//	WebServiceTemplate webServiceTemplate;
	
    @Test
    public void testWebServiceCall() throws Exception {
//        final ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
//        context.setConfigLocation("classpath:META-INF/com/wf/df/sdr/application-context.xml");
//        try {
//		    context.refresh();
//		    
//		    String documentId = "80305";
//		    // In Prod PDF 77370581 For TIFF use this  msg.setString("4244718");
//		    // In TEST PDF 80305 
//			GetFileAsAttachment message = new GetFileAsAttachment();
//			message.setString(documentId);
//			GetFileAsAttachmentResponse response = null;
//			
//			// to run this test you need to set the beans manuualy else the test will fail.
//			if ( webServiceTemplate != null) {
//				if ((response = (GetFileAsAttachmentResponse) webServiceTemplate
//						.marshalSendAndReceive((message))) != null) {
//					response.saveFile("C:/usr/download/" + documentId + ".pdf");
//				} else 
//					logger.info("webservicetemplate is NULL");
//			}
//			if ((null == response) || (response.getDocumentAsByteArray() == null))
//				logger.info("Failed to fetch Document[" + documentId + "]");
//        } finally {
//            context.close();
//        }
    }
}
