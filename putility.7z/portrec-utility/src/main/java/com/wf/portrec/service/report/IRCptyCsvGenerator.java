package com.wf.portrec.service.report;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.IRTrade;
import com.wf.portrec.domain.IRTradeUnfilterd;
import com.wf.portrec.repository.CounterpartyRepository;
import com.wf.portrec.repository.CptyPortfolioReconRepository;
import com.wf.portrec.repository.IRTradeRepository;
import com.wf.portrec.repository.IRTradeUnfilterdRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

/**
 * @author u250429
 *
 */


@Component
public class IRCptyCsvGenerator {

	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	/*String fileNameForCptySrc = "IR_CPTY_SRC";
	String fileNameForCptyDTCC = "IR_CPTY_DTCC";*/
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	IRTradeRepository irTradeRepo;
	
	@Autowired
	CptyPortfolioReconRepository cptyPortfolioReconRepository;
	
	@Autowired
	CounterpartyRepository counterpartyRepository;
	
	@Autowired
	IRTradeUnfilterdRepository irTradeUnfilteredRepo;
	
	@Autowired
	IrDataCsvWriter irDataCsvWriter;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@PostConstruct
	void init() {
	}

	private void generateSrcandDTCCCptyInformation(List<IRTradeUnfilterd> cptyDtccTradeUnfiltered, File targetFileCptyDTCCUnfilterd,String counterParty, Date runDate) {
		Map<String,IRTrade> unfilterdMap=new ConcurrentHashMap<String,IRTrade>();
		for(IRTradeUnfilterd irTradeUnfilterd:cptyDtccTradeUnfiltered){
			try{
			IRTrade trade=new IRTrade();
			BeanUtils.copyProperties(irTradeUnfilterd, trade);
			unfilterdMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
		}
		irDataCsvWriter.generateMatchUSIFile(targetFileCptyDTCCUnfilterd, unfilterdMap,"DTCC");
	}
	
	public OutputFileProperties createFile(String counterPartyLei, String legalId, Date runDate, Long id) throws IOException, ParseException {
		
		List<IRTradeUnfilterd> cptyDtccTradeUnfiltered = irTradeUnfilteredRepo.findDtccTradesForCptyByDateRevised(runDate, counterPartyLei,counterPartyLei);
		
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_IR);
		boolean irFileFlag = false;
		if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0) {
			logger.info("Number of cpty IR Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
			irFileFlag = true;
			reportProp.setCount(cptyDtccTradeUnfiltered.size());
			String fileNameForCptyDTCCUnfilterd = "IR_CPTY_DTCC";
			fileNameForCptyDTCCUnfilterd = fileNameForCptyDTCCUnfilterd +"_"+counterPartyLei+"_"+ ReportDateUtil.getFileDateExtension(runDate) + "_" + id + ".csv";
			File targetFileCptyDTCCUnfilterd  = new File(outputFolderName, fileNameForCptyDTCCUnfilterd);
			targetFileCptyDTCCUnfilterd.mkdirs();
			generateSrcandDTCCCptyInformation(cptyDtccTradeUnfiltered,targetFileCptyDTCCUnfilterd,counterPartyLei,runDate);
			cptyDataHelper.createReportDetail(id, "IR", fileNameForCptyDTCCUnfilterd, counterPartyLei);
			logger.info("Report Generation has been Completed for IR at  "+ outputFolderName +" on "+runDate);	
		}else{
			logger.info("No records found for Cpty IR Dtcc Unfiltered Trade");
		}
		reportProp.setFlag(irFileFlag);
		return reportProp;
	}

}
