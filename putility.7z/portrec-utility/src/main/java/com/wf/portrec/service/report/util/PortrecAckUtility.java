package com.wf.portrec.service.report.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PortrecAckUtility {

	Logger logger = LoggerFactory.getLogger(getClass());
	private ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();

	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:/ack-utility-context.xml";

	void start() {
		try {
			init();
		} catch (Exception e) {
			logger.error("Could not initialize the application - shutting down",e);
			e.printStackTrace();
			System.exit(1);
		}

		context.setConfigLocation(APPLICATION_CONTEXT_CONFIG_LOCATION);
		context.registerShutdownHook();
		try {
			context.refresh();
		} catch (Throwable e) {
			logger.error("Could not start application context - shutting down",e);
			e.printStackTrace();
			System.exit(2);
		}
		AckUtilityService ackUtilityService = context.getBean(AckUtilityService.class);
		ackUtilityService.run();
		logger.info("================= Starting Portrec ===================");		
	}

	private void init() throws Exception {

		String portrecDataDirPath = System.getProperty("PORTREC_DATA_DIR");
		logger.info("PORTREC_DATA_DIR=" + portrecDataDirPath);
		
		boolean usingExternalConfig = getClass().getResource("/config.properties") == null;
		logger.info("usingExternalConfig=" + usingExternalConfig);
		
		logger.info("================= Starting Portrec ===================");
	}

	public static void main(String[] args) {
		new PortrecAckUtility().start();
	}
}
