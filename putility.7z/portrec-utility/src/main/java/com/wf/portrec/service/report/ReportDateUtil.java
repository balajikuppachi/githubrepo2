package com.wf.portrec.service.report;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author u250429
 * 
 */
public class ReportDateUtil {
	static Logger logger = LoggerFactory.getLogger(ReportDateUtil.class);
	/** Date Methods for Reports
	 */
	public static String getStrDate(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		return dateFormat.format(date);
	}
	
	public static String getExecTimestampAsString(Date date){		
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return dateFormat.format(date);
	}
	
	public static String getFileDateExtension(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(date);
	}
}
