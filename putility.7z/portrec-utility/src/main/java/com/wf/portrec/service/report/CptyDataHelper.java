package com.wf.portrec.service.report;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.CptyMasterData;
import com.wf.portrec.domain.CptyReportDetail;
import com.wf.portrec.domain.PortRecAuditLogView;
import com.wf.portrec.repository.CptyMasterDataRepository;
import com.wf.portrec.repository.CptyReportDetailRepository;

@Component
public class CptyDataHelper {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	
	@Autowired
	CptyMasterDataRepository cptyMasterDataRepository;
	
	@Autowired
	CptyReportDetailRepository cptyReportDetailRepository;
	

	public List<CptyMasterData> readMasterData() {	
		Iterable<CptyMasterData> listOfCpty = cptyMasterDataRepository.findAll();
		List<CptyMasterData> cptyMasterDatas = new ArrayList<CptyMasterData>();
		
		if(null != listOfCpty){
			cptyMasterDatas = (List<CptyMasterData>) listOfCpty;
		}
		
		return cptyMasterDatas;
	}
	
	/*public void updateReportDetail(Long id, String assetClass, String path) {		
		CptyReportDetail cptyReportDetail = cptyReportDetailRepository.findById(id);
		if(null == cptyReportDetail){
			cptyReportDetail = new CptyReportDetail();
			cptyReportDetail.setId(id);
		}
		
		if(assetClass.equalsIgnoreCase("IR")){
			cptyReportDetail.setIrFileName(path);
		}else if(assetClass.equalsIgnoreCase("CR")){
			cptyReportDetail.setCrFileName(path);
		}else if(assetClass.equalsIgnoreCase("EQ")){
			cptyReportDetail.setEqFileName(path);
		}else if(assetClass.equalsIgnoreCase("FX")){
			cptyReportDetail.setFxFileName(path);
		}else if(assetClass.equalsIgnoreCase("COMM")){
			cptyReportDetail.setCommFileName(path);
		}
		
		cptyReportDetailRepository.save(cptyReportDetail);
	}*/
	
	public void createReportDetail(Long id, String assetClass, String fileName, String counterPartyLei) {		
			
		CptyReportDetail cptyReportDetail = new CptyReportDetail();
		cptyReportDetail.setMasterId(id);
		cptyReportDetail.setLei(counterPartyLei);
		cptyReportDetail.setFileName(fileName);
		
		cptyReportDetailRepository.save(cptyReportDetail);
	}

	/*public void updateReportDetailWithAck(CptyAcknwledge acknwledge) {
		CptyReportDetail cptyReportDetail = cptyReportDetailRepository.findById(acknwledge.getAckId());
		
		if(null != cptyReportDetail){
			cptyReportDetail.setIsAck(acknwledge.getIsAck());
			cptyReportDetailRepository.save(cptyReportDetail);
		}else{
			logger.error("No record found in pr_cpty_report_detail table with provided ack id =["+acknwledge.getAckId()+"]");
		}
	}*/
	
	public void updateReportDetailWithAck(PortRecAuditLogView acknwledge) {
		/*CptyReportDetail cptyReportDetail = cptyReportDetailRepository.findByFileName(acknwledge.getFileName());
		
		if(null != cptyReportDetail){
			cptyReportDetail.setIsAck(acknwledge.getAffirmedFlag());
			cptyReportDetailRepository.save(cptyReportDetail);
		}else{
			logger.error("No record found in pr_cpty_report_detail table with provided file name =["+acknwledge.getFileName()+"]");
		}*/
	}
}
