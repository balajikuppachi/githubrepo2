package com.wf.portrec.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pr_portfolio_segment")
public class PortfolioSegment {
	
	@Id
	@Column(name = "id")
	Long id;
	
	@Column(name = "name")
	String name;

	@Enumerated(EnumType.STRING)
	@Column(name = "record_type", nullable = false)
	TradeRecordTypeEnum recordType;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public TradeRecordTypeEnum getRecordType() {
		return recordType;
	}

	public void setRecordType(TradeRecordTypeEnum recordType) {
		this.recordType = recordType;
	}

}
