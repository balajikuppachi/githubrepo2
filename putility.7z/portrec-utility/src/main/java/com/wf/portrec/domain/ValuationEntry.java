package com.wf.portrec.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

/**
 * @author u250429
 * 
 */
@Entity
@Table(name = "pr_valuation_trioptima")
public class ValuationEntry implements Serializable {

	private static final long serialVersionUID = -2245288212846543504L;

	@Id
	@Column(name = "id")
	@TableGenerator(name="pr_algo_valuation_trioptima_id_generator", table="pr_id_sequence", allocationSize=200,
			pkColumnName="seq_name", pkColumnValue="pr_algo_valuation_trioptima_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator="pr_algo_valuation_trioptima_id_generator")
	Long id;

	@Column(name = "source_system")
	String sourceSystem;

	@Column(name = "collat_agreement_id")
	String collatAgreementId;

	@Column(name = "trade_id")
	String tradeid;

	@Column(name = "product_id")
	String productId;

	@Column(name = "notional1")
	BigDecimal notional1;

	@Column(name = "notional1_ccy")
	String notional1Ccy;

	@Column(name = "notional2")
	BigDecimal notional2;

	@Column(name = "notional2_ccy")
	String notional2Ccy;

	@Column(name = "prod_type")
	String prodType;

	@Column(name = "legal_id")
	Long legalId;

	@Column(name = "full_name")
	String fullName;

	@Column(name = "ext_principal")
	String extPrincipal;

	@Column(name = "parent_legal_id")
	String parentLegalId;

	@Column(name = "parent_legal_name")
	String parentLegalName;

	//FIXME - AZ - the field is no longer used
	@Column(name = "base_ccy")
	String baseCcy;

	//FIXME - AZ - the field is no longer used
	@Column(name = "pv_base_ccy")
	String pvBaseCcy;

	@Column(name = "pv_cob_date")
	Date pvCobDate;

	@Column(name = "effective_date")
	Date effectiveDate;

	@Column(name = "pv_ccy")
	String pvCcy;

	@Column(name = "pv")
	String pv;

	@Column(name = "buy_or_sell")
	String buySell;

	@Column(name = "imargin")
	String iMargin;

	@Column(name = "put_call")
	String putCall;

	@Column(name = "strike_price")
	String strikePrice;

	@Column(name = "underlying_name")
	String underlyingName;

	@Column(name = "book")
	String book;

	@Column(name = "trader")
	String trader;

	@Column(name = "cpty_trade_id")
	String cptyTradeId;

	@Column(name = "cpty_branch")
	String cptyBranch;

	//TODO: AZ - make sure all the boolean values are mapped the same 
	@Column(name = "collateralized")
	String collateralized;

	@Column(name = "trade_date")
	Date tradeDate;

	@Column(name = "maturity_date")
	Date maturityDate;
	
	@Column(name = "rundate")
	Date runDate;
	
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}

	/**
	 * @param sourceSystem the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	/**
	 * @return the collatAgreementId
	 */
	public String getCollatAgreementId() {
		return collatAgreementId;
	}

	/**
	 * @param collatAgreementId the collatAgreementId to set
	 */
	public void setCollatAgreementId(String collatAgreementId) {
		this.collatAgreementId = collatAgreementId;
	}

	/**
	 * @return the tradeid
	 */
	public String getTradeid() {
		return tradeid;
	}

	/**
	 * @param tradeid the tradeid to set
	 */
	public void setTradeid(String tradeid) {
		this.tradeid = tradeid;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the notional1
	 */
	public BigDecimal getNotional1() {
		return notional1;
	}

	/**
	 * @param notional1 the notional1 to set
	 */
	public void setNotional1(BigDecimal notional1) {
		this.notional1 = notional1;
	}

	/**
	 * @return the notional1Ccy
	 */
	public String getNotional1Ccy() {
		return notional1Ccy;
	}

	/**
	 * @param notional1Ccy the notional1Ccy to set
	 */
	public void setNotional1Ccy(String notional1Ccy) {
		this.notional1Ccy = notional1Ccy;
	}

	/**
	 * @return the notional2
	 */
	public BigDecimal getNotional2() {
		return notional2;
	}

	/**
	 * @param notional2 the notional2 to set
	 */
	public void setNotional2(BigDecimal notional2) {
		this.notional2 = notional2;
	}

	/**
	 * @return the notional2Ccy
	 */
	public String getNotional2Ccy() {
		return notional2Ccy;
	}

	/**
	 * @param notional2Ccy the notional2Ccy to set
	 */
	public void setNotional2Ccy(String notional2Ccy) {
		this.notional2Ccy = notional2Ccy;
	}

	/**
	 * @return the prodType
	 */
	public String getProdType() {
		return prodType;
	}

	/**
	 * @param prodType the prodType to set
	 */
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	/**
	 * @return the legalId
	 */
	public Long getLegalId() {
		return legalId;
	}

	/**
	 * @param legalId the legalId to set
	 */
	public void setLegalId(Long legalId) {
		this.legalId = legalId;
	}

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	/**
	 * @return the extPrincipal
	 */
	public String getExtPrincipal() {
		return extPrincipal;
	}

	/**
	 * @param extPrincipal the extPrincipal to set
	 */
	public void setExtPrincipal(String extPrincipal) {
		this.extPrincipal = extPrincipal;
	}

	/**
	 * @return the parentLegalId
	 */
	public String getParentLegalId() {
		return parentLegalId;
	}

	/**
	 * @param parentLegalId the parentLegalId to set
	 */
	public void setParentLegalId(String parentLegalId) {
		this.parentLegalId = parentLegalId;
	}

	/**
	 * @return the parentLegalName
	 */
	public String getParentLegalName() {
		return parentLegalName;
	}

	/**
	 * @param parentLegalName the parentLegalName to set
	 */
	public void setParentLegalName(String parentLegalName) {
		this.parentLegalName = parentLegalName;
	}

	/**
	 * @return the baseCcy
	 */
	public String getBaseCcy() {
		return baseCcy;
	}

	/**
	 * @param baseCcy the baseCcy to set
	 */
	public void setBaseCcy(String baseCcy) {
		this.baseCcy = baseCcy;
	}

	/**
	 * @return the pvBaseCcy
	 */
	public String getPvBaseCcy() {
		return pvBaseCcy;
	}

	/**
	 * @param pvBaseCcy the pvBaseCcy to set
	 */
	public void setPvBaseCcy(String pvBaseCcy) {
		this.pvBaseCcy = pvBaseCcy;
	}

	/**
	 * @return the pvCobDate
	 */
	public Date getPvCobDate() {
		return pvCobDate;
	}

	/**
	 * @param pvCobDate the pvCobDate to set
	 */
	public void setPvCobDate(Date pvCobDate) {
		this.pvCobDate = pvCobDate;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the pvCcy
	 */
	public String getPvCcy() {
		return pvCcy;
	}

	/**
	 * @param pvCcy the pvCcy to set
	 */
	public void setPvCcy(String pvCcy) {
		this.pvCcy = pvCcy;
	}

	/**
	 * @return the pv
	 */
	public String getPv() {
		return pv;
	}

	/**
	 * @param pv the pv to set
	 */
	public void setPv(String pv) {
		this.pv = pv;
	}

	/**
	 * @return the buySell
	 */
	public String getBuySell() {
		return buySell;
	}

	/**
	 * @param buySell the buySell to set
	 */
	public void setBuySell(String buySell) {
		this.buySell = buySell;
	}

	/**
	 * @return the iMargin
	 */
	public String getiMargin() {
		return iMargin;
	}

	/**
	 * @param iMargin the iMargin to set
	 */
	public void setiMargin(String iMargin) {
		this.iMargin = iMargin;
	}

	/**
	 * @return the putCall
	 */
	public String getPutCall() {
		return putCall;
	}

	/**
	 * @param putCall the putCall to set
	 */
	public void setPutCall(String putCall) {
		this.putCall = putCall;
	}

	/**
	 * @return the strikePrice
	 */
	public String getStrikePrice() {
		return strikePrice;
	}

	/**
	 * @param strikePrice the strikePrice to set
	 */
	public void setStrikePrice(String strikePrice) {
		this.strikePrice = strikePrice;
	}

	/**
	 * @return the underlyingName
	 */
	public String getUnderlyingName() {
		return underlyingName;
	}

	/**
	 * @param underlyingName the underlyingName to set
	 */
	public void setUnderlyingName(String underlyingName) {
		this.underlyingName = underlyingName;
	}

	/**
	 * @return the book
	 */
	public String getBook() {
		return book;
	}

	/**
	 * @param book the book to set
	 */
	public void setBook(String book) {
		this.book = book;
	}

	/**
	 * @return the trader
	 */
	public String getTrader() {
		return trader;
	}

	/**
	 * @param trader the trader to set
	 */
	public void setTrader(String trader) {
		this.trader = trader;
	}

	/**
	 * @return the cptyTradeId
	 */
	public String getCptyTradeId() {
		return cptyTradeId;
	}

	/**
	 * @param cptyTradeId the cptyTradeId to set
	 */
	public void setCptyTradeId(String cptyTradeId) {
		this.cptyTradeId = cptyTradeId;
	}

	/**
	 * @return the cptyBranch
	 */
	public String getCptyBranch() {
		return cptyBranch;
	}

	/**
	 * @param cptyBranch the cptyBranch to set
	 */
	public void setCptyBranch(String cptyBranch) {
		this.cptyBranch = cptyBranch;
	}

	/**
	 * @return the collateralized
	 */
	public String getCollateralized() {
		return collateralized;
	}

	/**
	 * @param collateralized the collateralized to set
	 */
	public void setCollateralized(String collateralized) {
		this.collateralized = collateralized;
	}

	/**
	 * @return the tradeDate
	 */
	public Date getTradeDate() {
		return tradeDate;
	}

	/**
	 * @param tradeDate the tradeDate to set
	 */
	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	/**
	 * @return the maturityDate
	 */
	public Date getMaturityDate() {
		return maturityDate;
	}

	/**
	 * @param maturityDate the maturityDate to set
	 */
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}
	

	

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
}
