package com.wf.portrec.service.report;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

@Component
public class TriggerAllCptyCsvGenerators {
	
	Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	IRCptyCsvGenerator iRCptyCsvGenerator;
	
	@Autowired
	CRCptyCsvGenerator cRCptyCsvGenerator;
	
	@Autowired
	FxCptyCsvGenerator fxCptyCsvGenerator;
	
	@Autowired
	EQCptyCsvGenerator eQCptyCsvGenerator;
	
	@Autowired
	CommCptyCsvGenerator commCptyCsvGenerator;
	
	public OutputFileProperties generateAllCptyMTFiles(String counterPartyLei, String legalId, Date reconDate, Long id) throws IOException, ParseException{
		logger.info("counterPartyLei :["+ counterPartyLei + "], legalId :[" + legalId + "], reconDate :["+ reconDate + "]");
		boolean mrIrFileFlag = false;
		boolean mtCrFileFlag = false;
		boolean mtFxFileFlag = false;
		boolean mtEqFileFlag = false;
		boolean mtCoFileFlag = false;
		
		OutputFileProperties portfolioProp = new OutputFileProperties(); 
		portfolioProp.setAssetClass(ReportConstants.ASSET_CLASS_ALL);
		
		OutputFileProperties irProp = iRCptyCsvGenerator.createFile(counterPartyLei,legalId, reconDate, id);
		OutputFileProperties crProp = cRCptyCsvGenerator.createFile(counterPartyLei,legalId,reconDate, id);
		OutputFileProperties fxProp = fxCptyCsvGenerator.createFile(counterPartyLei,legalId,reconDate, id);
		OutputFileProperties eqProp = eQCptyCsvGenerator.createFile(counterPartyLei,legalId,reconDate, id);
		OutputFileProperties commProp = commCptyCsvGenerator.createFile(counterPartyLei, legalId, reconDate, id);
		
		long count = irProp.getCount()+crProp.getCount()+fxProp.getCount()+eqProp.getCount()+commProp.getCount();
		logger.info("["+counterPartyLei+"] Portfolio Frequency :["+ count + "]");
		
		mrIrFileFlag =  irProp.isFlag();
		mtCrFileFlag =  crProp.isFlag();
		mtFxFileFlag =  fxProp.isFlag();
		mtEqFileFlag =  eqProp.isFlag();
		mtCoFileFlag =  commProp.isFlag();
		
		portfolioProp.setFlag(mrIrFileFlag||mtCrFileFlag||mtFxFileFlag||mtEqFileFlag||mtCoFileFlag);
		portfolioProp.setCount(count);
		
		return portfolioProp;
	}
	
}
