package com.wf.portrec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.MatchingLogic;

public interface MismatchLogRepository extends CrudRepository<MatchingLogic, Long> {
	
//	@Query("Select ml from  MatchingLogic ml, TradeRevision tr, TradeFile tf, PortfolioSegment ps " +
//			"where  ml.dtccFileId = tf.id and tf.portfolioSegment = ps " +
//			"and ps.name = 'Interest Rate, DTCC' and tr.deletedFile is null and tf.loadCompleted is not null")
//			public List<MatchingLogic> fetchSrcSliderTrades();
	
	public List<MatchingLogic> findByDtccFileId(Long dtccFileId);
	
	@Query("Select  ml from  MatchingLogic ml where ml.dtccFileId=? and ml.srcMatch = 'BEST_MATCH' and ml.mismatchIndex>0")
	public List<MatchingLogic> findCrBestMatchLogByDtccFileId(Long tradeFileId);
	
	@Query("Select  ml from  MatchingLogic ml where ml.dtccFileId=? and ml.srcMatch = 'BEST_MATCH' and ml.mismatchIndex>0 order by ml.dtccUsi")
	public List<MatchingLogic> findIrBestMatchLogByDtccFileId(Long tradeFileId);
	
	@Query("Select  ml from  MatchingLogic ml where ml.dtccFileId=? and ml.srcMatch = 'BEST_MATCH' and ml.mismatchIndex>0 order by ml.dtccUsi")
	public List<MatchingLogic> findEqBestMatchLogByDtccFileId(Long tradeFileId);
	
	@Query("Select  ml from  MatchingLogic ml where ml.dtccFileId=? and ml.srcMatch = 'BEST_MATCH' and ml.mismatchIndex>0 order by ml.dtccUsi")
	public List<MatchingLogic> findBestMatchLogByDtccFileId(Long tradeFileId);
	
}
