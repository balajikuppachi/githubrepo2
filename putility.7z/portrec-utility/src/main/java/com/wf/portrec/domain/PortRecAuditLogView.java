package com.wf.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Port_Rec_Audit_Log_View")
public class PortRecAuditLogView {

	@Id
	@Column(name = "User_ID")
	String userId;

	@Column(name = "Asset_Class")
	String assetClass = "";
	
	@Column(name = "Affirmed_Flag")
	String affirmedFlag = "";
	
	@Column(name = "Affirm_Date_Time")
	Date affirmDate;
	
	@Column(name = "Port_Rec_Period")
	String portRecPeriod = "";

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getAffirmedFlag() {
		return affirmedFlag;
	}

	public void setAffirmedFlag(String affirmedFlag) {
		this.affirmedFlag = affirmedFlag;
	}

	public Date getAffirmDate() {
		return affirmDate;
	}

	public void setAffirmDate(Date affirmDate) {
		this.affirmDate = affirmDate;
	}

	public String getPortRecPeriod() {
		return portRecPeriod;
	}

	public void setPortRecPeriod(String portRecPeriod) {
		this.portRecPeriod = portRecPeriod;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((affirmDate == null) ? 0 : affirmDate.hashCode());
		result = prime * result
				+ ((affirmedFlag == null) ? 0 : affirmedFlag.hashCode());
		result = prime * result
				+ ((assetClass == null) ? 0 : assetClass.hashCode());
		result = prime * result
				+ ((portRecPeriod == null) ? 0 : portRecPeriod.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortRecAuditLogView other = (PortRecAuditLogView) obj;
		if (affirmDate == null) {
			if (other.affirmDate != null)
				return false;
		} else if (!affirmDate.equals(other.affirmDate))
			return false;
		if (affirmedFlag == null) {
			if (other.affirmedFlag != null)
				return false;
		} else if (!affirmedFlag.equals(other.affirmedFlag))
			return false;
		if (assetClass == null) {
			if (other.assetClass != null)
				return false;
		} else if (!assetClass.equals(other.assetClass))
			return false;
		if (portRecPeriod == null) {
			if (other.portRecPeriod != null)
				return false;
		} else if (!portRecPeriod.equals(other.portRecPeriod))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	
	
}