package com.wf.portrec.service.report;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.Counterparty;
import com.wf.portrec.domain.ValuationEntry;
import com.wf.portrec.repository.CounterpartyRepository;
import com.wf.portrec.repository.ValuationEntryRepository;
import com.wf.portrec.service.business.CalendarService;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

@Component
public class ValuationGenerator {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	CounterpartyRepository counterpartyRepository;
	
	@Value("${file.portrec.data.extracts}") String valuationFilePath;
	
	@Autowired
	CalendarService calendarService;
	
	@Autowired
	ValuationEntryRepository valuationEntryRepo;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	public OutputFileProperties generateValuationsForCurrentDate(Long legalId, String reconDt, Long id) throws IOException, ParseException {
		File file = null;
		boolean valFlag = false;
		OutputFileProperties valProp = new OutputFileProperties();
		valProp.setAssetClass(ReportConstants.ASSET_CLASS_ALL);
		Counterparty cpty = counterpartyRepository.findForLegalId(legalId);
		List<ValuationEntry> entries= new ArrayList<ValuationEntry>();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date reconDate = sdf.parse(reconDt);
		Date fileNameDate = calendarService.getNextWorkingDay(reconDate);
		
		/*One LEI may be mapped to multiple Legal_Ids, hence we have to consider portfolio size for all legal_ids*/
		List<Counterparty> cptyList=counterpartyRepository.findValueByLei(cpty.getLeicode());
		if(cptyList.size()>0){
			for(Counterparty party:cptyList){
				List<ValuationEntry> values=valuationEntryRepo.findActiveByCounterpartyAndCobDate(party.getLegalId(),reconDate);
				entries.addAll(values);
				}
		}
		if(null != entries && entries.size() >0){
			valProp.setCount(entries.size());
			logger.info("Generating CPPortfolioEmail Report for counterparty: " + cpty.getLegalName());
			valFlag = true;
			String valuationFileName = "CPPortfolio-LegalId-" + cpty.getLegalId() + "-" + getDateFromStrValuation(fileNameDate) + ".csv";
			file  = new File(valuationFilePath, valuationFileName);
			//file.mkdirs();
			FileWriter fw = new FileWriter(file);
			fw.append("TradeID,ProductID,TradeDate,EndDate,MaturityDate,Notional1,Not. Ccy,PV,PVCcy\n");
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			DecimalFormat numberFormat = new DecimalFormat("#0.00#");
			try {
				for (ValuationEntry entry : entries) {
					fw
					.append(entry.getSourceSystem().concat(entry.getTradeid()).concat(getDateFromStrValuation(entry.getTradeDate()))).append(',')			
					.append(entry.getProductId()).append(',')
					.append(safeDateFormat(dateFormat, entry.getTradeDate())).append(',')
					.append("").append(',')
					.append(safeDateFormat(dateFormat, entry.getMaturityDate())).append(',')
					.append(safeNumberFormat(numberFormat, entry.getNotional1())).append(',')
					.append(entry.getNotional1Ccy()).append(',')	
					.append(safeStringFormatAsNumber(numberFormat, entry.getPv())).append(',')
					.append(entry.getPvCcy()).append(',')
					.append('\n');
				}
			} finally {
				fw.close();
			}
			
			cptyDataHelper.createReportDetail(id, "VAL", valuationFileName, cpty.getLeicode());
			
			logger.info("CPPortfolioEmail Report For counterparty '" + cpty.getLegalName() + "' has been generated: " + file.getCanonicalPath());
		}
		valProp.setFlag(valFlag);
		return valProp;
	}
	
	public static String getDateFromStrValuation(Date date) throws ParseException {
		DateFormat formatter ; 
   	    formatter = new SimpleDateFormat("yyyyMMdd");
		return formatter.format(date);
	}
	
	private String safeDateFormat(DateFormat format, Date value) {
		if (value == null)
			return "";
		
		try {
			return format.format(value);
		} catch (Exception e) {
			throw new RuntimeException("Couldn't format " + value + " as date");
		}
	}
	
	private String safeNumberFormat(NumberFormat format, Number value) {
		if (value == null)
			return "";
		
		try {
			return format.format(value);
		} catch (Exception e) {
			throw new RuntimeException("Couldn't format " + value + " as number");
		}
	}
	
	private String safeStringFormatAsNumber(NumberFormat format, String value) {
		if (value == null)
			return "";
		
		BigDecimal decimal = null;
		try {
			decimal = new BigDecimal(value);
		} catch (NumberFormatException nfe) {
			throw new RuntimeException("Couldn't format " + value + " as number");
		}
		
		return format.format(decimal);
	}
}
