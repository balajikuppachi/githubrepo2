package com.wf.portrec.service.report;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.FXTrade;
import com.wf.portrec.domain.FXTradeUnfiltered;
import com.wf.portrec.repository.FXTradeUnfilterdRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

@Component
public class FxCptyCsvGenerator {

	@Value("${file.portrec.data.extracts}") String outputFolderName;
	private static final String MAPPING_PROPERTIES = "/mapping.properties";
	private static Properties properties = null;
	Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	FXTradeUnfilterdRepository fxTradeRepo;

	@Autowired
	FxDataCsvWriter fxDataCsvWriter;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@PostConstruct
	void init() {

	}

	public void createDtccSrcUsiMatchAndExceptionLists(List<FXTradeUnfiltered> cptyDtccTradeUnfiltered, File targetFile, String counterparty, Date runDate) {
		List<FXTrade> unfilterdList=new ArrayList<FXTrade>();
		
		for(FXTradeUnfiltered fxTradeUnfilterd:cptyDtccTradeUnfiltered){
			try{
				FXTrade trade = new FXTrade();
				BeanUtils.copyProperties(fxTradeUnfilterd, trade);
				unfilterdList.add(trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
		}
		fxDataCsvWriter.generateCsvFile(properties, targetFile, unfilterdList, "DTCC");
	}
	
	public OutputFileProperties createFile(String counterPartyLei, String legalId, Date runDate, Long id) throws IOException, ParseException {
		
		List<FXTradeUnfiltered> cptyDtccTradeUnfiltered = fxTradeRepo.findDtccTradesForCptyByDateRevised(runDate,counterPartyLei,counterPartyLei, runDate);
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_FX);
		boolean fxFileFlag = false; 
		if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0) {
			logger.info("Number of cpty FX Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
			fxFileFlag = true;
			reportProp.setCount(cptyDtccTradeUnfiltered.size());
			//loadProperties();
			String fileNameForCptyDTCCUnfilterd = "FX_CPTY_DTCC";
			String fileNameSrcUSIMatch = fileNameForCptyDTCCUnfilterd +"_"+counterPartyLei+"_"+ ReportDateUtil.getFileDateExtension(runDate) + "_" + id + ".csv";
			File targetFileSrcUsiMatch = new File(outputFolderName, fileNameSrcUSIMatch);
			targetFileSrcUsiMatch.mkdirs();
			createDtccSrcUsiMatchAndExceptionLists(cptyDtccTradeUnfiltered,targetFileSrcUsiMatch, counterPartyLei, runDate);
			cptyDataHelper.createReportDetail(id, "FX", fileNameSrcUSIMatch, counterPartyLei);
			logger.info("Report Generation has been Completed for FX at  "+ outputFolderName +" on "+runDate);
		}else{
			logger.info("No records found for Cpty FX Dtcc Unfiltered Trade");
		}
		reportProp.setFlag(fxFileFlag);
		return reportProp;
	}

	public String getFileDateExtension(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(date);
	}

	private void loadProperties() {
		logger.info("Loading mapping properties file for Fx Constants.");
		try {
		InputStream inputStream = FxDataCsvWriter.class.getResourceAsStream(MAPPING_PROPERTIES);
		if (inputStream == null) {
			logger.info("Property file '" + MAPPING_PROPERTIES + "' not found in the classpath");
		}
		properties = new Properties();
			properties.load(inputStream);
		} catch (IOException e) {
			logger.info("Failed to load mapping.properties for Fx Constants");
		}
	}

}