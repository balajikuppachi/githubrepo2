package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.EquityTradeUnfilterd;
import com.wf.portrec.domain.TradeFile;

public interface EquityTradeUnfilterdRepository extends CrudRepository<EquityTradeUnfilterd, Long> {
	
	@Query("select eq from EquityTradeUnfilterd eq where eq.tradeFile = " +
	"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
	"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Equity VS, own' and ptfi.loadCompleted is not null)")
	public List<EquityTradeUnfilterd> findEqSrcTrades();

	@Query("select eq from EquityTradeUnfilterd eq where eq.tradeFile = " +
			"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ppsi.name= ? and ptfi.loadCompleted is not null)")
	public List<EquityTradeUnfilterd> findEqDTCCTrades(String eq);
			
	
	@Query("select pcr from EquityTradeUnfilterd pcr where pcr.tradeFile = " +
			"(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ppsi.name='Equity VS, own' and ptfi.loadCompleted is not null)")
	public List<EquityTradeUnfilterd> findEqVsSrcTrades();

	@Query("Select eq from EquityTradeUnfilterd eq where eq.usi not in (select um.dtccUsi from UsiMapSlider um where um.assetClass = 'Equities') " + 
			"and eq.tradeFile = ?")
	public List<EquityTradeUnfilterd> fetchEqDtccNonUsiMapSlider(TradeFile tradeFile);
	
	@Query("Select um.srcTradeId, cr from EquityTradeUnfilterd cr, UsiMapStatic um where "
			+ "cr.usi = um.dtccUsi and um.assetClass = 'Equities'"
			+ "and cr.tradeFile =  "
			+ "(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi "
			+ "where ptfi.portfolioSegment = ppsi.id and ppsi.name= ? and ptfi.loadCompleted is not null)")
	public List<Object[]> fetchDtccUsiMap(String eq);
	
	@Query("select eq from EquityTradeUnfilterd eq where eq.party1= ? or eq.party2= ? and eq.tradeFile = " +
			"(select max(tf.id) from TradeFile tf, PortfolioSegment ps where tf.id <(select max(ptfi.id) from TradeFile ptfi, PortfolioSegment ppsi " + 
			"where ptfi.portfolioSegment = ppsi.id and ppsi.name= ? and ptfi.loadCompleted is not null) and tf.portfolioSegment=ps.id and ps.name= ? and tf.loadCompleted is not null)")
	public List<EquityTradeUnfilterd> findEqDTCCTradesForCpty(String party1,String party2,String eq1,String eq2);
	

	@Query("select eq from EquityTradeUnfilterd eq where eq.party1= ? or eq.party2= ? and eq.runDate = ?")
	public List<EquityTradeUnfilterd> findEqDTCCTradesForCptyByDate(String party1,String party2,Date rundate);
	
	@Query("Select eq from EquityTradeUnfilterd eq, TradeFile ptf where eq.runDate=? and (eq.party1=? or eq.party2=?) " +
	"and eq.tradeFile=ptf.id and ptf.loadCompleted is not null")
	public List<EquityTradeUnfilterd> findDtccTradesForCptyByDateRevised(Date rundate, String cpty1, String cpty2);
}
