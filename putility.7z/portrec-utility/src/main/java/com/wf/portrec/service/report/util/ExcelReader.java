package com.wf.portrec.service.report.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	/**
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {

		ExcelReader excelReader = new ExcelReader();
		List<Object[]> list = excelReader.reader();
		for(Object[] obj : list){
			System.out.println(""+obj[0]+" : "+obj[1]);
		}
	}

	public List<Object[]> reader() throws FileNotFoundException {

		List<Object[]> list = new ArrayList<Object[]>();
				
		try {
			InputStream ExcelFileToRead = new FileInputStream("H:/test.xlsx");
			XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
			XSSFSheet sheet = wb.getSheetAt(0);
			XSSFRow row;
			XSSFCell cell;
			Iterator rows = sheet.rowIterator();
			while (rows.hasNext()) {
				row = (XSSFRow) rows.next();
				Iterator cells = row.cellIterator();
				Object[] objArr = new Object[2];
				int index =0;
				while (cells.hasNext()) {
					cell = (XSSFCell) cells.next();
					if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
						//System.out.println(cell.getStringCellValue() + " ");
						objArr[index] = cell.getStringCellValue();
					} else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
						//System.out.println(cell.getNumericCellValue() + " ");
						objArr[index] = cell.getNumericCellValue();
					} else {
						
					}
					index ++;
				}
				list.add(objArr);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

}
