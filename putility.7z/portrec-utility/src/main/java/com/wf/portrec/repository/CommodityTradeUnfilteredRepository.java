package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.CommodityTradeUnfiltered;

public interface CommodityTradeUnfilteredRepository extends CrudRepository<CommodityTradeUnfiltered, Long> {
	
	@Query("Select comm from CommodityTradeUnfiltered comm where comm.nonReportLei=? or comm.nonReportLei=? and comm.tradeFile = (Select max(tff) from TradeFile tff , PortfolioSegment pss where tff.id <( Select max(tf) from TradeFile tf, PortfolioSegment ps " +
	"where tf.portfolioSegment = ps and ps.name = 'Commodities, DTCC') and tff.portfolioSegment = pss and pss.name = 'Commodities, DTCC')")
	public List<CommodityTradeUnfiltered> findByCptyValue(String cpty, String cpty1);
	
	@Query("Select comm from CommodityTradeUnfiltered comm where comm.reportPrtyLei=? or comm.nonReportLei=? and comm.runDate = ?")
		public List<CommodityTradeUnfiltered> findByCptyValueByDate(String cpty, String cpty1, Date rundate);
	
	@Query("select comm from CommodityTradeUnfiltered comm, TradeFile ptf where comm.runDate=? and (comm.reportPrtyLei=? or comm.nonReportLei=?) " +
	"and comm.tradeFile=ptf.id and ptf.loadCompleted is not null")
	public List<CommodityTradeUnfiltered> findDtccTradesForCptyByDateRevised(Date rundate, String cpty1, String cpty2);
}
