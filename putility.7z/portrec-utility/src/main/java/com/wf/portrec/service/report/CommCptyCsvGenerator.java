package com.wf.portrec.service.report;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.CommodityTrade;
import com.wf.portrec.domain.CommodityTradeUnfiltered;
import com.wf.portrec.repository.CommodityTradeUnfilteredRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

@Component
public class CommCptyCsvGenerator {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	
	@Autowired
	CommodityTradeUnfilteredRepository commTradeUnfilteredRepo;
	
	@Autowired
	CommDataCsvWriter commDataCsvWriter;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	private void generateSrcandDTCCCptyInformation(List<CommodityTradeUnfiltered> cptyDtccTradeUnfiltered, File targetFileCptyDTCCUnfilterd,String counterParty, Date reconDate) {
		Map<String,CommodityTrade> unfilterdMap=new ConcurrentHashMap<String,CommodityTrade>();
		
		for(CommodityTradeUnfiltered commTradeUnfilterd:cptyDtccTradeUnfiltered){
			try{
				CommodityTrade trade=new CommodityTrade();
			BeanUtils.copyProperties(commTradeUnfilterd, trade);
			unfilterdMap.put(trade.getUsiValue()+":"+trade.getSrcTradeId(), trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
		}
		commDataCsvWriter.generateMatchUSIFile(targetFileCptyDTCCUnfilterd, unfilterdMap, "DTCC");
	}
	
	public OutputFileProperties createFile(String counterPartyLei, String legalId,  Date reconDate, Long id) throws IOException, ParseException {		
		List<CommodityTradeUnfiltered> cptyDtccTradeUnfiltered = commTradeUnfilteredRepo.findDtccTradesForCptyByDateRevised(reconDate,counterPartyLei,counterPartyLei);
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_COMM);
		boolean commFileFlag = false;
		if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0) {
			logger.info("Number of cpty COMM Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
			commFileFlag = true;
			reportProp.setCount(cptyDtccTradeUnfiltered.size());
			String fileNameForCptyDTCCUnfilterd = "COMM_CPTY_DTCC";
			fileNameForCptyDTCCUnfilterd = fileNameForCptyDTCCUnfilterd +"_"+counterPartyLei+"_"+ ReportDateUtil.getFileDateExtension(reconDate)+ "_" + id + ".csv";
			File targetFileCptyDTCCUnfilterd  = new File(outputFolderName, fileNameForCptyDTCCUnfilterd);
			targetFileCptyDTCCUnfilterd.mkdirs();
			generateSrcandDTCCCptyInformation(cptyDtccTradeUnfiltered,targetFileCptyDTCCUnfilterd,counterPartyLei,reconDate);
			cptyDataHelper.createReportDetail(id, "COMM", fileNameForCptyDTCCUnfilterd, counterPartyLei);
			logger.info("Report Generation has been Completed for commodity at  "+ outputFolderName +" on "+reconDate);
		}else{
			logger.info("No records found for Cpty COMM Dtcc Unfiltered Trade");
		}
		reportProp.setFlag(commFileFlag);
		return reportProp;
	}

}
