package com.wf.portrec.repository;

import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.PortRecAuditLogView;

public interface PortRecAuditLogViewRepository extends CrudRepository<PortRecAuditLogView, String> {

	
}
