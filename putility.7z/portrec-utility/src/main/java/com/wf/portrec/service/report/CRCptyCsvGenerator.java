/**
 * 
 */
package com.wf.portrec.service.report;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.CRTrade;
import com.wf.portrec.domain.CRTradeUnfilterd;
import com.wf.portrec.repository.CRTradeUnfilterdRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

/**
 * @author u293876
 *
 */
@Component
public class CRCptyCsvGenerator {

	
	@Value("${file.portrec.data.extracts}") String outputFolderName;
	@Autowired
	CRTradeUnfilterdRepository crTradeUnfilterdRepo;
	@Autowired
	CrDataCsvWriter crDataCsvWriter;

	@Autowired
	CptyDataHelper cptyDataHelper;
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	
	private void generateSrcandDTCCCptyInformation(List<CRTradeUnfilterd> cptyDtccTradeUnfiltered, File targetFileCptyDTCCUnfilterd,String counterParty, Date runDate) {
		Map<String,CRTrade> unfilterdMap=new ConcurrentHashMap<String,CRTrade>();
		for(CRTradeUnfilterd crTradeUnfilterd:cptyDtccTradeUnfiltered){
			try{
			CRTrade trade=new CRTrade();
			BeanUtils.copyProperties(crTradeUnfilterd, trade);
			unfilterdMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
		}
		crDataCsvWriter.generateMatchUSIFile(targetFileCptyDTCCUnfilterd, unfilterdMap,"DTCC");
		
	}
	
	
	public OutputFileProperties createFile(String counterPartyLei, String legalId, Date runDate, Long id) throws IOException, ParseException {
		
		
		List<CRTradeUnfilterd> cptyDtccTradeUnfiltered = crTradeUnfilterdRepo.findDtccTradesForCptyByDateRevised(runDate,counterPartyLei,counterPartyLei);
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_CR);
		boolean crFileFlag = false;
		if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0 ) {
			logger.info("Number of cpty CR Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
			crFileFlag = true;
			reportProp.setCount(cptyDtccTradeUnfiltered.size());
			String fileNameForCptyDTCCUnfilterd = "CR_CPTY_DTCC";
			fileNameForCptyDTCCUnfilterd = fileNameForCptyDTCCUnfilterd +"_"+counterPartyLei+"_"+ ReportDateUtil.getFileDateExtension(runDate) + "_" + id + ".csv";
			File targetFileCptyDTCCUnfilterd  = new File(outputFolderName, fileNameForCptyDTCCUnfilterd);
			targetFileCptyDTCCUnfilterd.mkdirs();
			generateSrcandDTCCCptyInformation(cptyDtccTradeUnfiltered,targetFileCptyDTCCUnfilterd,counterPartyLei, runDate);
			cptyDataHelper.createReportDetail(id, "CR", fileNameForCptyDTCCUnfilterd, counterPartyLei);
			logger.info("Report Generation has been Completed for CR at  "+ outputFolderName +" on "+runDate);
		}else{
			logger.info("No records found for Cpty CR Dtcc Unfiltered Trade");
		}
		reportProp.setFlag(crFileFlag);
		return reportProp;
	}

}
