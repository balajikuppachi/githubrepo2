package com.wf.portrec.service.report;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.EquityTrade;
import com.wf.portrec.domain.EquityTradeUnfilterd;
import com.wf.portrec.repository.EquityTradeUnfilterdRepository;
import com.wf.portrec.service.report.common.OutputFileProperties;
import com.wf.portrec.service.report.common.ReportConstants;

/**
 * @author u293876
 *
 */
@Component
public class EQCptyCsvGenerator {
	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	@Autowired
	EquityTradeUnfilterdRepository equityRepo;
	
	@Autowired
	EqDataCsvWriter eqDataCsvWriter;
	
	@Autowired
	CptyDataHelper cptyDataHelper;
	
	Logger logger = LoggerFactory.getLogger(getClass());
	private void generateSrcandDTCCCptyInformation(List<EquityTradeUnfilterd> cptyDtccTradeUnfiltered, File targetFileCptyDTCCUnfilterd,String counterParty, Date rundate) {
		Map<String,EquityTrade> tradeIdDtccTradesMap = new ConcurrentHashMap<String, EquityTrade>();
		
		/*String[] eqDtccValues = {"Equity SP, DTCC","Equity VS, DTCC","Equity CFD, DTCC","Equity DS, DTCC","Equity ES, DTCC"};
		for(String eq : eqDtccValues){
			cptyDtccTradeUnfiltered.addAll(equityRepo.findEqDTCCTradesForCpty(counterParty,counterParty,eq,eq));
		}*/
		
		logger.info("Size of the Original DTCC trade list : " + cptyDtccTradeUnfiltered.size());
		for(EquityTradeUnfilterd unfilterdTrade : cptyDtccTradeUnfiltered){	
			try{
				EquityTrade trade=new EquityTrade();
				BeanUtils.copyProperties(unfilterdTrade, trade);
				tradeIdDtccTradesMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			catch(ClassCastException ce){
				ce.printStackTrace();
			}
			
		}
		eqDataCsvWriter.generateMatchUSIFile(targetFileCptyDTCCUnfilterd, tradeIdDtccTradesMap, "DTCC");
	}
	
	public OutputFileProperties createFile(String counterPartyLei, String legalId, Date rundate, Long id) throws IOException, ParseException {
		
		List<EquityTradeUnfilterd> cptyDtccTradeUnfiltered = new ArrayList<EquityTradeUnfilterd>();
		OutputFileProperties reportProp = new OutputFileProperties();
		reportProp.setAssetClass(ReportConstants.ASSET_CLASS_EQ);
		boolean eqFileFlag = false;
		/*String[] eqDtccValues = {"Equity SP, DTCC","Equity VS, DTCC","Equity CFD, DTCC","Equity DS, DTCC","Equity ES, DTCC"};
		for(String eq : eqDtccValues){
			cptyDtccTradeUnfiltered.addAll(equityRepo.findEqDTCCTradesForCptyByDate(counterPartyLei,counterPartyLei,rundate));
		}*/
		cptyDtccTradeUnfiltered.addAll(equityRepo.findDtccTradesForCptyByDateRevised( rundate,counterPartyLei, counterPartyLei));		
		if(null != cptyDtccTradeUnfiltered && cptyDtccTradeUnfiltered.size() > 0){
			logger.info("Number of cpty EQ Dtcc Trade Unfiltered :["+ cptyDtccTradeUnfiltered.size() + "]");
			eqFileFlag = true;
			reportProp.setCount(cptyDtccTradeUnfiltered.size());
			String fileNameForCptyDTCCUnfilterd = "EQ_CPTY_DTCC";
			fileNameForCptyDTCCUnfilterd = fileNameForCptyDTCCUnfilterd +"_"+counterPartyLei+"_"+ ReportDateUtil.getFileDateExtension(rundate)+ "_" + id + ".csv";
			File targetFileCptyDTCCUnfilterd  = new File(outputFolderName, fileNameForCptyDTCCUnfilterd);
			targetFileCptyDTCCUnfilterd.mkdirs();
			generateSrcandDTCCCptyInformation(cptyDtccTradeUnfiltered,targetFileCptyDTCCUnfilterd,counterPartyLei, rundate);
			cptyDataHelper.createReportDetail(id, "EQ", fileNameForCptyDTCCUnfilterd, counterPartyLei);
			logger.info("Report Generation has been Completed for EQ at  "+ outputFolderName +" on "+rundate);
		}else{
			logger.info("No records found for Cpty EQ Dtcc Unfiltered Trade");
		}
		reportProp.setFlag(eqFileFlag);
		return reportProp;
	}

}
