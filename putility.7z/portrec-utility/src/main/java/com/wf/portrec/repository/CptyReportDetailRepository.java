package com.wf.portrec.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.CptyReportDetail;

public interface CptyReportDetailRepository extends CrudRepository<CptyReportDetail, Long> {

	@Query("Select crd from CptyReportDetail crd where crd.id = ?")
	CptyReportDetail findById(Long id);
	
	
	@Query("Select crd from CptyReportDetail crd where crd.fileName = ?")
	CptyReportDetail findByFileName(String fileName);
}
