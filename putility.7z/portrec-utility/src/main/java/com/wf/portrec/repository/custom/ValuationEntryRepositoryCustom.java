package com.wf.portrec.repository.custom;

import java.util.Date;

public interface ValuationEntryRepositoryCustom {
	
	public Date findActiveNonCollateralizedCobDate(Date date);
}
