package com.wf.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wf.portrec.domain.Counterparty;

public interface CounterpartyRepository extends CrudRepository<Counterparty, Long> {
	
	public List<Counterparty> findByLegalId(Long legalId);
	
//	@Query("select cpty, count(*) from " +
//			"ValuationAlgoEntry vae join vae.tradeRevision tr join tr.createdFile tf,  " +
//			"Counterparty cpty " +
//			"where tr.deletedFile is null and tf.loadCompleted is not null and tr.counterparty = cpty group by cpty")
//	public List<Object[]> findAllWithValuationCount();
	
	@Query("select cpty, count(*) from " +
			"ValuationEntry vae , Counterparty cpty " +
			"where vae.legalId = cpty.legalId and vae.runDate=? group by cpty")
	public List<Object[]> findAllValuationCount(Date date);

	@Query("from Counterparty cpty where cpty.id=?")
	public Counterparty findForCounterParty(long longValue);
	
	@Query("from Counterparty cpty where cpty.legalId=?")
	public Counterparty findForLegalId(long longValue);
	
	@Query("select cpty from Counterparty cpty where cpty.leicode=?")
	public List<Counterparty> findValueByLei(String lei);
	
	@Query("select cpty from Counterparty cpty where cpty.leicode=?")
	public Counterparty findCptyByLei(String lei);
	
	@Query("select cpty from Counterparty cpty where cpty.busAcctId=?")
	public List<Counterparty> findValueByBusinessActId(String bizactid);
	
	@Query("select cpty from Counterparty cpty where cpty.busAcctId=?")
	public Counterparty findCptyByBusinessActId(String bizactid);
	
}
