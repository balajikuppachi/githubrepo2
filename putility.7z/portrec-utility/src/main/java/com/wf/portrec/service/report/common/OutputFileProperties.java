package com.wf.portrec.service.report.common;

public class OutputFileProperties {
	private String assetClass;
	private boolean flag;
	private long count;
	
	public OutputFileProperties() {
		this.assetClass = "";
		this.flag = false;
		this.count = 0;
	}
	
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}	
}
