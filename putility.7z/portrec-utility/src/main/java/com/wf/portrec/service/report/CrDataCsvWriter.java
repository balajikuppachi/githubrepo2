package com.wf.portrec.service.report;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.portrec.domain.CRTrade;
import com.wf.portrec.repository.CRTradeRepository;
import com.wf.portrec.repository.MismatchLogRepository;

@Component
public class CrDataCsvWriter {

	Logger logger = LoggerFactory.getLogger(getClass());
	static char SEPARATOR = ',';

	@Autowired
	CRTradeRepository crTradeRepository;
	
	@Autowired
	MismatchLogRepository mismatchRepository;
	
	public void generateMatchUSIFile(File targetFile, Map<String,CRTrade> usiTrdIdMap, String fileType){		
		try {			
			targetFile.mkdirs();						
			if (targetFile.exists()) {
				targetFile.delete();
			}						
			FileWriter writer = new FileWriter(targetFile);
			writer.append("USI");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 LEI");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 Role");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 Financial Ent");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 2 US Person Ind");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 LEI");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 Role");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 Financial Ent");
			writer.append(SEPARATOR);
			writer.append("Trd Pty 1 US Person Ind");
			writer.append(SEPARATOR);
			writer.append("Product ID");
			writer.append(SEPARATOR);
			writer.append("Sec Asset Avail"); //Doubt
			writer.append(SEPARATOR);
			writer.append("Pri Asset");
			writer.append(SEPARATOR);
			writer.append("Sec Asset");
			writer.append(SEPARATOR);
			writer.append("Rep Jurisdiction");
			writer.append(SEPARATOR);
			writer.append("Add Repo 1 LEI");
			writer.append(SEPARATOR);
			writer.append("Buyer");
			writer.append(SEPARATOR);
			writer.append("Cpty not 'Buyer'"); // Doubt
			writer.append(SEPARATOR);
			writer.append("Underlying Asset");
			writer.append(SEPARATOR);
			writer.append("Execution Venue");
			writer.append(SEPARATOR);
			writer.append("Eff Date");
			writer.append(SEPARATOR);
			writer.append("Scheduled Ter Date");
			writer.append(SEPARATOR);
			writer.append("Fixed Rate");
			writer.append(SEPARATOR);
			writer.append("Notional Amt 1");
			writer.append(SEPARATOR);
			writer.append("Notional Curr 1");
			writer.append(SEPARATOR);
			writer.append("Single Payment Amt");
			writer.append(SEPARATOR);
			writer.append("Single Payment Curr");
			writer.append(SEPARATOR);
			writer.append("Initial Payment Amt");
			writer.append(SEPARATOR);
			writer.append("Initial Payment Curr");
			writer.append(SEPARATOR);
			writer.append("Payment Freq Period 1");
			writer.append(SEPARATOR);
			writer.append("Payment Freq Period Mult 1");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);		
			writer.append("Execution Date");
			writer.append(SEPARATOR);
			writer.append("Trd Id");
			writer.append('\n');			
			
			Iterator it = usiTrdIdMap.entrySet().iterator();
			while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		        //out.write(pairs.getKey() + " = " + pairs.getValue() + "\n");
		        CRTrade srcViewDomain = (CRTrade)pairs.getValue();
		        String usi = (String)pairs.getKey();
		        String[] parts = usi.split(":");
		        usi=parts[0];
		        srcViewDomain.setUsi(usi);

				/*String usiPrefix = "";
				if(StringUtils.isNotBlank(srcViewDomain.getUsiPrefix()))
					usiPrefix=srcViewDomain.getUsiPrefix();*/
		        
		        //writer.append(usiPrefix.concat(srcViewDomain.getUsi()));	
		        writer.append(srcViewDomain.getUsi());
		      		
				writer.append(SEPARATOR);
				/*Start New field Implementation from here */
				writer.append(null != srcViewDomain.getTradeParty2() ? srcViewDomain.getTradeParty2() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty2Role() ? srcViewDomain.getTradeParty2Role() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty2financialEntity() ? srcViewDomain.getTradeParty2financialEntity() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty2UsPersonIndicator() ? srcViewDomain.getTradeParty2UsPersonIndicator() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1() ? srcViewDomain.getTradeParty1() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1Role() ? srcViewDomain.getTradeParty1Role() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1financialEntity() ? srcViewDomain.getTradeParty1financialEntity() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTradeParty1UsPersonIndicator() ? srcViewDomain.getTradeParty1UsPersonIndicator() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getProductType() ? srcViewDomain.getProductType() : "");
				writer.append(SEPARATOR);
				// Multi Asset Swap : If 'Secondary Asset Class' is populated, then 'Yes'. Else 'NA'
				if (StringUtils.isBlank(srcViewDomain.getSecondaryAssetClass())) {
					writer.append("NA");
				} else {
					writer.append("Yes");
				}		
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPrimaryAssetClass() ? srcViewDomain.getPrimaryAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSecondaryAssetClass() ? srcViewDomain.getSecondaryAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportingJurisdiction() ? (srcViewDomain.getReportingJurisdiction().contains(",")?srcViewDomain.getReportingJurisdiction().replace(",", ";"):srcViewDomain.getReportingJurisdiction()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getAdditionalRepository1Lei() ? srcViewDomain.getAdditionalRepository1Lei() : "");
				writer.append(SEPARATOR);
				
				/*String buyerPrefix = "";
				if(null != srcViewDomain.getBuyerLEIPrefix()){
					buyerPrefix = srcViewDomain.getBuyerLEIPrefix();
				}
				
				String buyerLEI = "";
				if(null != srcViewDomain.getBuyerLEIValue()){
					buyerLEI = srcViewDomain.getBuyerLEIValue();
				}
				if(null!=buyerPrefix && null!=buyerLEI){
					writer.append(buyerPrefix+'-'+buyerLEI);
				}else {
					writer.append("");
				}*/
				
				writer.append(null != srcViewDomain.getBuyer() ? srcViewDomain.getBuyer() : "");
				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSeller() ? srcViewDomain.getSeller() : ""); //Counterparty who is not 'Buyer'
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getUnderlyingAsset() ? srcViewDomain.getUnderlyingAsset() : "");
				writer.append(SEPARATOR);
				
				String execVenue = srcViewDomain.getExecutionVenue();
				if(StringUtils.isNotBlank(execVenue) && StringUtils.equalsIgnoreCase("Off-Facility", execVenue))
					execVenue="OffFacility";
				writer.append(null != execVenue ? execVenue : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getEffectiveDate() ? ReportDateUtil.getStrDate(srcViewDomain.getEffectiveDate()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getScheduledTerminationDate() ? ReportDateUtil.getStrDate(srcViewDomain.getScheduledTerminationDate()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getFixedRatePerAnnum() ? srcViewDomain.getFixedRatePerAnnum().toString() : "");
				writer.append(SEPARATOR);

				//if(null != srcViewDomain.getNotionalAmount1()){
				writer.append(null != srcViewDomain.getNotionalAmount1() ? srcViewDomain.getNotionalAmount1().toString() : "");
				writer.append(SEPARATOR);
				if(StringUtils.isNotBlank(srcViewDomain.getNotionalCurrency1())){
					writer.append(null != srcViewDomain.getNotionalCurrency1() ? srcViewDomain.getNotionalCurrency1() : "");
					writer.append(SEPARATOR);
				} else {
					/*writer.append(null != srcViewDomain.getDisputedNotionalAmount1() ? srcViewDomain.getDisputedNotionalAmount1().toString() : "");
					writer.append(SEPARATOR);*/
					writer.append(null != srcViewDomain.getDisputedNotionalCurrency1() ? srcViewDomain.getDisputedNotionalCurrency1() : "");
					writer.append(SEPARATOR);
				}
				
				writer.append(null != srcViewDomain.getSinglePaymentAmount() ? srcViewDomain.getSinglePaymentAmount().toString() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSinglePaymentCurrency() ? srcViewDomain.getSinglePaymentCurrency() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getInitialPaymentAmount() ? srcViewDomain.getInitialPaymentAmount().toString() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getInitialPaymentCurrency() ? srcViewDomain.getInitialPaymentCurrency() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPaymentFrequencyPeriod1() ? srcViewDomain.getPaymentFrequencyPeriod1() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPaymentFrequencyPeriodMultiplier1() ? srcViewDomain.getPaymentFrequencyPeriodMultiplier1() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getCollateralized() ? srcViewDomain.getCollateralized() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getExecutionDate() ? ReportDateUtil.getExecTimestampAsString(srcViewDomain.getExecutionDate()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOrigTradeId() ? srcViewDomain.getOrigTradeId() : "");
				writer.append('\n');
			}
			writer.flush();
			writer.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}	
}