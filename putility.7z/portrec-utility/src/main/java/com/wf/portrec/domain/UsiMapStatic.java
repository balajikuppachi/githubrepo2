package com.wf.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "pr_usi_map_static")
public class UsiMapStatic{
	@Id
	@Column(name = "id")
	@TableGenerator(name="pr_usimap_static_id_generator", table="pr_id_sequence", allocationSize=200,
			pkColumnName="seq_name", pkColumnValue="pr_usimap_static_seq", valueColumnName = "last_id")
	@GeneratedValue(strategy = GenerationType.TABLE, generator="pr_usimap_static_id_generator")
	Long id;
	
	@Column(name = "asset_class")
	String assetClass;

	@Column(name = "dtcc_usi")
	String dtccUsi;	
	
	@Column(name = "src_trade_id")
	String srcTradeId;
	
	@Column(name = "create_datetime")
	Date createDateTime;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getDtccUsi() {
		return dtccUsi;
	}

	public void setDtccUsi(String dtccUsi) {
		this.dtccUsi = dtccUsi;
	}

	
	public String getSrcTradeId() {
		return srcTradeId;
	}

	public void setSrcTradeId(String tradeId) {
		this.srcTradeId = tradeId;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
}