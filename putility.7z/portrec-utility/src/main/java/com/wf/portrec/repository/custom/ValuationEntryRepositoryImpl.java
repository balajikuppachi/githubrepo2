package com.wf.portrec.repository.custom;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class ValuationEntryRepositoryImpl implements ValuationEntryRepositoryCustom {
	
	@PersistenceContext(unitName="Portrec")
	EntityManager entityManager;
	
	@Override
	public Date findActiveNonCollateralizedCobDate(Date date){
		String query = "select vae.pvCobDate from ValuationEntry vae where collateralized = 'N' and rundate= :date";
		return entityManager.createQuery(query, Date.class)
		.setParameter("date", date)
		.setMaxResults(1)
		.getSingleResult();
	}
}
