package com.wf.portrec.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "pr_cpty_report_detail")
public class CptyReportDetail {

	
	/*@Column(name = "report_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long reportId;*/
	
	@Id
	@Column(name = "file_name")
	String fileName = "";
	
	@Column(name = "master_id")
	Long masterId;
	
	@Column(name = "lei")
	String lei = "";

	@Column(name = "is_ack")
	String isAck = "";

	/*public Long getReportId() {
		return reportId;
	}

	public void setReportId(Long reportId) {
		this.reportId = reportId;
	}*/

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getIsAck() {
		return isAck;
	}

	public void setIsAck(String isAck) {
		this.isAck = isAck;
	}

	public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}

	public String getLei() {
		return lei;
	}

	public void setLei(String lei) {
		this.lei = lei;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((fileName == null) ? 0 : fileName.hashCode());
		result = prime * result + ((isAck == null) ? 0 : isAck.hashCode());
		result = prime * result + ((lei == null) ? 0 : lei.hashCode());
		result = prime * result
				+ ((masterId == null) ? 0 : masterId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CptyReportDetail other = (CptyReportDetail) obj;
		if (fileName == null) {
			if (other.fileName != null)
				return false;
		} else if (!fileName.equals(other.fileName))
			return false;
		if (isAck == null) {
			if (other.isAck != null)
				return false;
		} else if (!isAck.equals(other.isAck))
			return false;
		if (lei == null) {
			if (other.lei != null)
				return false;
		} else if (!lei.equals(other.lei))
			return false;
		if (masterId == null) {
			if (other.masterId != null)
				return false;
		} else if (!masterId.equals(other.masterId))
			return false;
		return true;
	}

}