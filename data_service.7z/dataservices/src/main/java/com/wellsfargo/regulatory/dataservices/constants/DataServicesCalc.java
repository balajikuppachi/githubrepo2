package com.wellsfargo.regulatory.dataservices.constants;

public class DataServicesCalc {

	public static final String clearedTradeCalc = "clearedTradeCalc";
	public static final String calculationAgentCalc="calculationAgentCalc";
	public static final String collateralizedDataCalc="collateralizedDataCalc";
	public static final String verificationTypeCalc = "verificationTypeCalc";
	public static final String productTypeCalc = "productTypeCalc";
	public static final String masterAgreementVersionCalc = "masterAgreementVersionCalc";
	public static final String masterAgreementDateCalc = "masterAgreementDateCalc";
	public static final String postEventTransactionDate="postEventTransactionDate";
	public static final String interpolationMethodCalc = "interpolationMethodCalc";
	public static final String upiCalc = "upiCalc";
	public static final String processedByCalc = "processedByCalc";
	public static final String optionTypeCalc = "optionTypeCalc";
	public static final String eqStrikePriceCalc = "eqStrikePriceCalc";
	public static final String eqEndDateCalc = "eqEndDateCalc";
	public static final String novationTradeCalc = "novationTradeCalc";
	public static final String premiumPayOrReceiveCalc = "premiumPayOrReceiveCalc";
	public static final String partyRegionCalc = "partyRegionCalc";
	public static final String calculateDocumentTypeMatrixCalc="calculateDocumentTypeMatrixCalc";
	public static final String calculateMasterDocumentTransactionTypeCalc="calculateMasterDocumentTransactionTypeCalc";
    public static final String calculateMasterDocumentDateCalc = "calculateMasterDocumentDateCalc";
    public static final String calculateDtccProductcalc = "calculateDtccProductCalc";
	
	
	
}
