package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.DocumentationType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class MasterAgreementVersionCalc implements DataSevicesCalculation
{

	
	
	@Override
    public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap, Object[] inputArr)
    {
		String masterAgreementVersion=null;
		String leiUsValue=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyUs().getPartyInfo().getValue());
		String leiCpValue=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyThem().getPartyInfo().getValue());
		DocumentationType documentationTypeData=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation());
		String assetClass = harmonizerMap.get(DataServicesConstants.HRMN_ASSET_CLASS);
		
		if(DataServicesConstants.WF_LEI.equals(leiCpValue) && (DataServicesConstants.WF_AFF_LEI_FX.equals(leiUsValue)||(DataServicesConstants.ASSET_CLASS_INTEREST_RATE.equals(assetClass) && DataServicesConstants.WF_AFF_LEI_IR.equals(leiUsValue))))
		{
			masterAgreementVersion=DataServicesConstants.AGREEMNT_DATE_2002;
		}
		
		else
		{
			masterAgreementVersion=XmlMappingUtil.getFormatedValue(XmlMappingUtil.resolveIfNull(()->documentationTypeData.getLegalAgreementDate().getYear()),String.class);
			if(XmlMappingUtil.IsNullOrBlank(masterAgreementVersion))
				masterAgreementVersion=XmlMappingUtil.getFormatedValue(XmlMappingUtil.resolveIfNull(()->documentationTypeData.getAgreementDate().getYear()),String.class);
		}
		return masterAgreementVersion;
    }

}
