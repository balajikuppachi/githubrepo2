package com.wellsfargo.regulatory.dataservices.calc;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.PartyThemType;
import com.wellsfargo.regulatory.dataservices.bo.PartyUsType;
import com.wellsfargo.regulatory.dataservices.bo.RelatedPartyType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class CalculationAgentCalc implements DataSevicesCalculation{
	
	@Value("${party1.id.Credit}") String party1IdCredit;
	@Value("${party1.id.Forex}") String party1IdForex;
	@Value("${party1.id.InterestRate}") String party1IdInterestRate;
	@Value("${wf.lei}") String wfLEI;
	
	
	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;
	
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map <String,String> harmonizerMap,Object[] inputArr) 
	{
		
		PartyUsType partyUsType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyUs());
		PartyThemType partyThemType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyThem());
		List<RelatedPartyType> relatedParties = partyUsType.getRelatedParty();
		String srcAssetClass= (String) inputArr[0];
		String dtccOurParticipantId = XmlMappingUtil.resolveIfNull(()->partyUsType.getPartyUsDTCCParticipantID());
		String counterPartyLEI = XmlMappingUtil.resolveIfNull(()->partyThemType.getPartyInfo().getValue());
		
		for(RelatedPartyType relatedParty: relatedParties) {
			if(DataServicesConstants.CalculationAgent.equalsIgnoreCase(relatedParty.getRole())) {
				if((!XmlMappingUtil.IsNullOrBlank(relatedParty.getValue()) && relatedParty.getValue().contains(DataServicesConstants.As_Specified_In_MasterAgreement))
					|| (!XmlMappingUtil.IsNullOrBlank(relatedParty.getName()) && relatedParty.getName().contains(DataServicesConstants.As_Specified_In_MasterAgreement))) {
					return DataServicesConstants.AsSpecifiedInMasterAgreement;
				} 
				
				String documentType=getDocumentType(srcAssetClass, transactionType, sdrRequest, harmonizerMap);
				
				if (DataServicesConstants.DTCC_STS_VALUE.equals(documentType)) {
						return DataServicesConstants.AsSpecifiedInStandardTermsSupplement;
				}
				  
				  
				 
				if(DataServicesConstants.WELLS_FARGO.equals(relatedParty.getRole())) {
					return  getSubmitter(srcAssetClass, dtccOurParticipantId);
					
				}
				else {
					
					String cptyParticipantId = getCounterPartyId(transactionType,counterPartyLEI, dtccOurParticipantId,partyThemType);
					if(!XmlMappingUtil.IsNullOrNone(cptyParticipantId)) {
						return cptyParticipantId;
					}
					else if(!XmlMappingUtil.IsNullOrNone(counterPartyLEI)) {
						return counterPartyLEI;
					}
					
				}
				
				if (!"CreditDerivativesPhysicalSettlementMatrix".equals(documentType)) {
					return DataServicesConstants.ALLOW_EMPTY_ON_REQD;
				}
				
				
			}
		}
		
		
		return DataServicesConstants.EMPTY_STRING;
	}

private String getCounterPartyId(TransactionType transactionType,String counterPartyLEI , String dtccOurParticipantId, PartyThemType partyThemType) 
{

		String busAccID = XmlMappingUtil.resolveIfNull(()->partyThemType.getPartyInfo().getBusinessAccountID());
		String cptySname= XmlMappingUtil.resolveIfNull(()->partyThemType.getPartyInfo().getShortName());
		
		String cptyLEI = "";
		
		if (!XmlMappingUtil.IsNullOrNone(counterPartyLEI)){
			cptyLEI = (StringUtils.substringAfter(counterPartyLEI, Constants.COLON));
			cptyLEI = counterPartyLEI.startsWith(DataServicesConstants.DTCC_REPOSITORY)?counterPartyLEI.substring(4):counterPartyLEI;
		}else if(!XmlMappingUtil.IsNullOrNone(dtccOurParticipantId) && dtccOurParticipantId.startsWith(Constants.DTCC)) { 	
			cptyLEI = dtccOurParticipantId.substring(4);
		}else if(!XmlMappingUtil.IsNullOrNone(busAccID)) {
			cptyLEI = busAccID;
		}else if(!XmlMappingUtil.IsNullOrNone(cptySname)) {
			cptyLEI = cptySname;
		}
		
		return cptyLEI;
	}
	
	
	
	
	private String getSubmitter(String assetClass, String dtccOurParticipantId) {
		
		String submitter = "";
		if(	(Constants.ASSET_CLASS_CREDIT.equals(assetClass) && XmlMappingUtil.IsNullOrBlank(party1IdCredit))
				|| (Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass) && XmlMappingUtil.IsNullOrBlank(party1IdInterestRate))
				|| (Constants.ASSET_CLASS_FOREX.equals(assetClass) && XmlMappingUtil.IsNullOrBlank(party1IdForex))	) {
			submitter = wfLEI;
		}
		
		if (Constants.ASSET_CLASS_CREDIT.equals(assetClass)) {
			if (!XmlMappingUtil.IsNullOrBlank(party1IdCredit)) {
				submitter = party1IdCredit;
			}
		} else if (Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass)) {
			if (!XmlMappingUtil.IsNullOrBlank(party1IdInterestRate)) {
				submitter = party1IdInterestRate;
			}
		}else if (Constants.ASSET_CLASS_FOREX.equals(assetClass)) {
			if (!XmlMappingUtil.IsNullOrBlank(party1IdForex)) {
				submitter = party1IdForex;
			}
		}
		
		if(!XmlMappingUtil.IsNullOrNone(dtccOurParticipantId) && dtccOurParticipantId.startsWith(Constants.DTCC)) {
			submitter = dtccOurParticipantId.substring(4);
		}
			return submitter;	
		
	}


	private String getDocumentType(String srcAssetClass,TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap) {
		
		String documentType = DataServicesConstants.DTCC_STS_VALUE;
		
		String productType = (String)dataServicesCalculationTrigger.calculate(DataServicesCalc.productTypeCalc, transactionType, sdrRequest, harmonizerMap, new Object[]{srcAssetClass});
		
		if(DataServicesConstants.PRODUCT_TYPE_CDS.equals(productType)) {
			if("true".equalsIgnoreCase("OurDTCCMatrixParticipantFlag")) {
				documentType = "CreditDerivativesPhysicalSettlementMatrix";
			}
			
		}
		else if(DataServicesConstants.PRODUCT_TYPE_RECOVERY_LOCK.equalsIgnoreCase(productType) ||  DataServicesConstants.PRODUCT_TYPE_FIXED_REOCVERY.equalsIgnoreCase(productType)) {
			if("true".equalsIgnoreCase("OurDTCCMatrixParticipantFlag")) {
				documentType = "CreditDerivativesPhysicalSettlementMatrix";
			}
			else {
				documentType = DataServicesConstants.ALLOW_EMPTY_ON_REQD;
			}
		}
		
		
		return documentType;
	}
	
	
}
