package com.wellsfargo.regulatory.dataservices.calc;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.cache.ProductMappingCache;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepProductMapping;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.mapper.XmlMapperHelper;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class UpiCalc implements DataSevicesCalculation{

	@Autowired
	protected XmlMapperHelper xmlMapperHelper;
	
	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;
	
	private static String subProductArray[]={"CreditDefaultSwapLoan","CDOSQR","CDSIndexOption"};
	private static String keyTypeArray[]={"XCCySwap"};
	private static Logger logger = Logger.getLogger(DataSevicesCalculation.class.getName());
	
	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) 
	{
	String assetClass=xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
		String upi = null;
				//XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getTaxonomy().get(0).getProductIDValue()); 
				//XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getTaxonomy().get(0).getProductIDValue());
		
	
		if (XmlMappingUtil.IsNullOrBlank(upi) && Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
		{
			String	dtccSubProductType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType());
			String dtccProductSubProductType=null;
			String dtccProduct = getProductCalc(transactionType,assetClass,sdrRequest);
			String dtccProductType=xmlMapperHelper.getDtccProductType(dtccProduct);
			
			
			 if(!DataServicesConstants.STRUCTURED_PRODUCT.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType())))
			{
			
				// dtccProductSubProductType=xmlMapperHelper.getDtccSubProductType(dtccProduct);
				if (DataServicesConstants.INFLATION.equalsIgnoreCase(dtccSubProductType) || DataServicesConstants.ZCINFLATION.equalsIgnoreCase(dtccSubProductType))
				{
					dtccProductSubProductType=DataServicesConstants.INFLATION;
				}
				
			}
			 
			 String productType=xmlMapperHelper.getDtccProduct(assetClass,dtccProductType,dtccProductSubProductType);

			upi= Constants.ISDA + Constants.COLON+productType;
		
		}
		
		else if (XmlMappingUtil.IsNullOrBlank(upi) && Constants.ASSET_CLASS_CREDIT.equals(assetClass))
		{
			upi= Constants.ISDA+ Constants.COLON + getProductCalc(transactionType,assetClass,sdrRequest);
		}
		
		else if (XmlMappingUtil.IsNullOrBlank(upi) && Constants.ASSET_CLASS_FOREX.equals(assetClass))
		{
			
			upi= Constants.ISDA+ Constants.COLON + getFxUPI(transactionType,assetClass);;

		}	
		else if(!XmlMappingUtil.IsNullOrBlank(upi))
		{
			upi= Constants.ISDA + Constants.COLON + upi;
		}
		
		return upi;
	}
	
	
	private static String getFxUPI(TransactionType dsTrade,	String assetClass) {
		ProductMappingCache prdCache = ProductMappingCache.getInstance();
		List<String> values 			= null;
		String sourceProductType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType());
		//String sourceProductSubType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType());
		
		String key=getProductIdKey(assetClass, sourceProductType, Constants.ALL.toUpperCase(), Constants.ISDA);
		values=prdCache.getValues(key);
		StringBuilder sb = new StringBuilder(100);
		sb.append(values.get(0)).append(Constants.COLON).append(values.get(1));
		return sb.toString();
	}

	
	private static String getProductIdKey(String assetClass, String prdType, String subPrdType, String mapingType)
	{
		logger.debug("Entering getProductIdKey() method");
		List<String> subprodcutExcludeList=Arrays.asList(subProductArray);
		StringBuilder key = null;

		key = new StringBuilder();

		key.append(assetClass);
		key.append(Constants.UNDERSCORE);
		key.append(prdType);
		key.append(Constants.UNDERSCORE);
		if (null != subPrdType && !subprodcutExcludeList.contains(prdType)) key.append(subPrdType);
		key.append(Constants.UNDERSCORE);
		key.append(mapingType);

		logger.debug("Leaving getProductIdKey() method");

		return key.toString();
	}
	
	public static String getProductCalc(TransactionType dsTrade,String assetClass,SdrRequest sdrRequest) {
		String sourceProductType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType());
		String sourceProductSubType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType());
				
		String creditReferenceEntity=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getReferenceEntity());
		String creditOptionReferenceEntity=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getReferenceEntity());
		
		String region=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCIssuerRegion());
		String optionregion=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCIssuerRegion());
		
		BigDecimal swapLegOptionFixedRate=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getFeeLeg().getFixedRateInitial());
		BigDecimal swapLegFixedRate=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getFeeLeg().getFixedRateInitial());
		
		
		String issuerRegion=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getIssuerRegion());
		String issuerOptionRegion=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getIssuerRegion());
		
		String cdxSector=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCCDXSector());
		String cdxSectorOption=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCCDXSector());
		
		String cdxSectorValue=(!XmlMappingUtil.IsNullOrBlank(cdxSector))?cdxSector:cdxSectorOption;
		String basketValue=(!XmlMappingUtil.IsNullOrBlank(creditReferenceEntity))?creditReferenceEntity:creditOptionReferenceEntity;
		BigDecimal SwapLegFixedRateValue=(!XmlMappingUtil.IsNullOrBlank(swapLegOptionFixedRate))?swapLegOptionFixedRate:swapLegFixedRate;
		String dtccRegionValue=(!XmlMappingUtil.IsNullOrBlank(region))?region:optionregion;
		String issuerRegionValue=(!XmlMappingUtil.IsNullOrBlank(issuerRegion))?issuerRegion:issuerOptionRegion;
		
		RegRepProductMapping isdaPM = getISDAProductValue(assetClass, sourceProductType, sourceProductSubType,sdrRequest);
		
		
		if ("CreditBGS".contains(sourceProductType)) {
			isdaPMForCreditBGS(isdaPM, basketValue);
		} else if ("LCDS".contains(sourceProductType)) {
			isdaPMForLCDS(isdaPM, SwapLegFixedRateValue);
		} else if ("ABSCDO".equals(sourceProductType)) {
			isdaPMForABSCDO(isdaPM, basketValue);
		} else if ("CDSIndexTranche".equals(sourceProductType)) { 
			isdaPMForCDSIndexTranche(isdaPM, basketValue, cdxSectorValue);
		} else if ("CDSIndex".contains(sourceProductType)) {
			isdaPMForCDSIndex(isdaPM, basketValue, cdxSectorValue);
		}  
		
		
		
		// handle Regions
		if (isdaPM.getDtccPrdType().equals("SingleName") && isdaPM.getDtccSubPrdType().contains("Corporate")) {
			
			if(dtccRegionValue == null && issuerRegionValue == null) 
				logger.error("Missing region information for Corporate.");
			
			String tempRegion = dtccRegionValue != null ? dtccRegionValue : issuerRegionValue;
			
			String val = DataServicesDomainMappingUtil.getRegion(tempRegion);
			// handle Soverign's, if there is a Sovereign in region then SubProd Type should be Sovereign not Corporate
			 if (StringUtils.containsIgnoreCase(val, Constants.SOVEREIGN))
                 isdaPM.setDtccSubPrdType(Constants.SOVEREIGN);

			 isdaPM.setDtccTransactionType(val);
		}

		if(isdaPM.getDtccSubPrdType() == null){

			if(!isdaPM.getDtccAssetClass().equals(Constants.ASSET_CLASS_INTEREST_RATE) && !isdaPM.getDtccPrdType().equals(Constants.PRODUCT_TYPE_TOTAL_RETURN_SWAP)){
				logger.info("Could not Map the product : " + assetClass +  
						Constants.COLON + sourceProductType + Constants.COLON + sourceProductSubType);				
			}

		}

		// Assemble the Product Value buffer
		StringBuffer sb = new StringBuffer(isdaPM.getDtccAssetClass());
		if (!XmlMappingUtil.IsNullOrBlank(sb)) {
			sb.append(Constants.COLON).append(isdaPM.getDtccPrdType());
		}
		if (isdaPM.getDtccSubPrdType() != null) {
			sb.append(Constants.COLON).append(isdaPM.getDtccSubPrdType());
			if (!XmlMappingUtil.IsNullOrBlank(isdaPM.getDtccTransactionType())) {
				sb.append(Constants.COLON).append(isdaPM.getDtccTransactionType().contains("|")?isdaPM.getDtccTransactionType().replace("|", ":"):isdaPM.getDtccTransactionType());
			}
		} else {
			sb.append("<UNMAPPED>");
		}

		return sb.toString();
		
	}


	private static void isdaPMForCDSIndex(RegRepProductMapping isdaPM,
			String basketValue, String cdxSector) {

		//Using Equals to Avoid LCDX
		if ("CDX".equals(isdaPM.getSrcSubPrdType())) {
			
			if(cdxSector != null && StringUtils.contains(cdxSector, "Traxx")){
				isdaPM.setDtccSubPrdType("iTraxx");
				isdaPM.setDtccTransactionType(DataServicesDomainMappingUtil.getCDXSector(cdxSector));
			}else{
				isdaPM.setDtccSubPrdType("CDX");
				isdaPM.setDtccTransactionType("CDXIG");
				
				if(null != basketValue){
					
					if(basketValue.contains("CDX")){
						
						if(basketValue.contains("HY")){
							isdaPM.setDtccTransactionType("CDXHY");
						} else if(basketValue.contains("XO")){
							isdaPM.setDtccTransactionType("CDXXO");
						} 
						
					}
								
				}
			}
			
		}

	
		
	}


	private static void isdaPMForCDSIndexTranche(RegRepProductMapping isdaPM,
			String basketValue, String cdxSector) {

		//Using Equals to Avoid LCDX
		if ("Principal".equals(isdaPM.getSrcSubPrdType())) { 
			
			if(cdxSector != null && StringUtils.contains(cdxSector, "Traxx")){
				isdaPM.setDtccSubPrdType("iTraxx");
				isdaPM.setDtccTransactionType(DataServicesDomainMappingUtil.getCDXSector(cdxSector));
			}else{
				isdaPM.setDtccSubPrdType("CDX");
				isdaPM.setDtccTransactionType("CDXTrancheIG");
				
				if(null != basketValue){
					
					if(basketValue.contains("CDX")){
						
						if(basketValue.contains("HY")){
							isdaPM.setDtccTransactionType("CDXTrancheHY");
						} else if(basketValue.contains("XO")){
							isdaPM.setDtccTransactionType("CDXTrancheXO");
						} 
						
					}
								
				}
			}
			
		}
		
	}


	private static void isdaPMForABSCDO(RegRepProductMapping isdaPM,
			String basketValue) {
		if(!XmlMappingUtil.IsNullOrBlank(basketValue) && basketValue.contains("ABX")){
			isdaPM.setDtccPrdType("IndexTranche");
			isdaPM.setDtccSubPrdType("ABX");
			isdaPM.setDtccTransactionType("ABXTranche");
		} else{
			isdaPM.setDtccPrdType("Exotic");
			isdaPM.setDtccSubPrdType("Other");
		}
		
	}


	private static void isdaPMForLCDS(RegRepProductMapping isdaPM,
			BigDecimal swapLegFixedRate) {
		isdaPM.setDtccTransactionType("LCDS");
		
		if(swapLegFixedRate != null){
			
			double fixedRate = swapLegFixedRate.doubleValue();
			if( (fixedRate == 2.50 || fixedRate == 5.00)){
				isdaPM.setDtccTransactionType("StandardLCDSBullet");
			}			
			
		}	
		
	}


	private static void isdaPMForCreditBGS(RegRepProductMapping isdaPM,
			String basketValue) {
		if ((null != basketValue) && DataServicesDomainMappingUtil.isStandardBasketName(basketValue)) {
			isdaPM.setDtccSubPrdType("Corporate");
			isdaPM.setDtccTransactionType("Refobonly");			
		} 
	}


	private static RegRepProductMapping getISDAProductValue(String assetClass, String prodType, String subProdType,SdrRequest sdrRequest) {
		// TODO Auto-generated method stub
		if ((null == assetClass )||(null == prodType)){
			return null;
		}		
		ProductType product = sdrRequest.getTrade().getTradeDetail().getProduct();
		List<String> values 			= null;
		ProductMappingCache prdCache 	= null;
		prdCache 		= ProductMappingCache.getInstance();
		boolean found=false;
		String ALL = "ALL";
		String key=null;
		while (!found) {
			key = getProductIdKey(assetClass, prodType, subProdType,	"ISDA");
			values = prdCache.getValues(key);

			if (null != values) {
				found = true;
				break;
			}

			if (!ALL.equals(subProdType)) {
				subProdType = ALL;
				continue;
			} else if (!ALL.equals(prodType)) {
				prodType = ALL;
				continue;
			} else if (!ALL.equals(assetClass)) {
				assetClass = ALL;
			} else {
				break;
			}
		}
		
		String dtccAssetClass = values.get(0);
		String dtccPrdType = values.get(1).trim();
		String dtccSubPrdType = values.get(2).trim();
		
		List<String> keyTypeList = Arrays.asList(keyTypeArray);
		if(Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass) && keyTypeList.contains(dtccPrdType)) {
			
			String leg1Currency = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(0).getNotionalCurrency());
			String leg2Currency = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(1).getNotionalCurrency());
			if (!XmlMappingUtil.IsNullOrBlank(leg1Currency) 	&& !XmlMappingUtil.IsNullOrBlank(leg2Currency) 	&& !StringUtils.equalsIgnoreCase(leg1Currency, leg2Currency)) {
				dtccPrdType = Constants.PRODUCT_TYPE_XCCY;
			}
			
			String leg1Type = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(0).getFixedFloat().value());
			String leg2Type = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(1).getFixedFloat().value());
			
			if (!XmlMappingUtil.IsNullOrBlank(leg1Type) && !XmlMappingUtil.IsNullOrBlank(leg2Type) && leg1Type.equals(leg2Type)) {
				if (leg1Type.equals("Fixed")) {
					dtccSubPrdType = "FixedFixed";
				} else if (leg1Type.equals("Float")) {
					dtccSubPrdType = "Basis";
				}
			} else if (!XmlMappingUtil.IsNullOrBlank(leg1Type) && !XmlMappingUtil.IsNullOrBlank(leg2Type) && (leg1Type.equals("Fixed") || leg2Type.equals("Fixed"))) {
				dtccSubPrdType = "FixedFloat";
			}
		}

		RegRepProductMapping pmret  = new RegRepProductMapping();
		if(!XmlMappingUtil.IsNullOrBlank(values))
		{
			pmret.setDtccPrdType(dtccPrdType);
			pmret.setDtccSubPrdType(dtccSubPrdType);
			if(!Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass)) {
				pmret.setDtccTransactionType(values.get(5));
			}
		}
		pmret.setSrcPrdType(prodType);
		pmret.setSrcSubPrdType(subProdType);
		pmret.setDtccAssetClass(dtccAssetClass);

		return pmret;
		
	}
	
	
}
