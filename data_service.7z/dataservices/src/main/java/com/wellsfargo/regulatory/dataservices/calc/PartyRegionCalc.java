package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.PartyRelatedType;
import com.wellsfargo.regulatory.dataservices.bo.RegulatoryType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class PartyRegionCalc implements DataSevicesCalculation {

	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) 
	{
	
		RegulatoryType regulatory = transactionType.getTrade().getTradeHeader().getTradeAttributes().getRegulatory();
		PartyRelatedType partyRelatedType =(PartyRelatedType) inputArr[0];
		boolean delegated = regulatory.getReporting().stream().anyMatch(s->StringUtils.isNotBlank(s.getDelegatedModel()));
		boolean emirTrade = regulatory.getReporting().stream().anyMatch(s->StringUtils.isNotBlank(s.getJurisdiction()) && DataServicesConstants.ESMA.equalsIgnoreCase(s.getJurisdiction()));
		
		if((emirTrade ||  delegated ) && !XmlMappingUtil.IsNullOrBlank(partyRelatedType.getRegion()))
		{
				return partyRelatedType.getRegion();
					
		}
		
		return null;
	}

}
