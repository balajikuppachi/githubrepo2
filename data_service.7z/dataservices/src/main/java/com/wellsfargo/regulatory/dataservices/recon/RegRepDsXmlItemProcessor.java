package com.wellsfargo.regulatory.dataservices.recon;

import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.dataservices.comparator.impl.ReconcileXML;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.persister.dataservices.dao.RegRepDsPayloadDao;
import com.wellsfargo.regulatory.persister.dataservices.dto.RegRepDsMatch;
import com.wellsfargo.regulatory.persister.dataservices.dto.RegRepDsPayload;

/***
 * @author Pavithrini Kota
 * 05/06/2015
 *
 */
public class RegRepDsXmlItemProcessor implements ItemProcessor<RegRepDsRecon, RegRepDsPayload>{

	private ReconcileXML reconcileXML;
	private RegRepDsPayloadDao regRepDsPayloadDao;
	
	
	public ReconcileXML getReconcileXML() {
		return reconcileXML;
	}

	public void setReconcileXML(ReconcileXML reconcileXML) {
		this.reconcileXML = reconcileXML;
	}

	
	public void setRegRepDsPayloadDao(RegRepDsPayloadDao regRepDsPayloadDao) {
		this.regRepDsPayloadDao = regRepDsPayloadDao;
	}

	@Override
	public RegRepDsPayload process(RegRepDsRecon item)
			throws Exception {
		
		RegRepDsMatch match = null;
		
		RegRepDsPayload regRepDsPayload = regRepDsPayloadDao.findByPrimaryKey(item.getDsPayloadId());
		
		Integer compareResults = reconcileXML.compare(item.getDsPayload(), item.getSdrPayload(), DataServicesConstants.XML_PAYLOAD_TYPE);
		
		if (compareResults > DataServicesConstants.RECON_NO_MATCH){
			
			match = new RegRepDsMatch();
			match.setSourcePayloadId(item.getDsPayloadId());
			match.setTargetPayloadId(item.getSdrPayloadId());
			
			if (compareResults > DataServicesConstants.RECON_PRIMARY_MATCH)
			{
				match.setIsValid("Y");
				regRepDsPayload.setPotentialMatch("Y");
			}
			else
			{
				match.setIsValid("N");
			}
			regRepDsPayload.setRegRepDsMatch(match);
		}
	
		return regRepDsPayload;
	}

}
