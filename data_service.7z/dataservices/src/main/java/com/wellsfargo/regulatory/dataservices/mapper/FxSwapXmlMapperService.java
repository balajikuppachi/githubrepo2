package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.dataservices.bo.FXSwapLegType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class FxSwapXmlMapperService extends GenericXmlMapperService {

	private static Logger logger = Logger.getLogger(FxSwapXmlMapperService.class.getName());
	
	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");
		
		ProductType productType = super.setProductTypeData(dsTrade, harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade,productType, harmonizerMap));
		
		logger.info("Entering setProductTypeData() method");
		return productType;
	}

	
	protected List<LegType> setLegTypeData(TransactionType dsTrade, ProductType productType,  Map<String, String> harmonizerMap) 
	{
		
		logger.info("Entering setLegTypeData() method");
		FXSwapLegType fxFarLeg = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getFX().getFXSwap().getFarLeg());
		FXSwapLegType fxNearLeg = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getFX().getFXSwap().getNearLeg());
		List<LegType> legTypeList = new ArrayList<LegType>();

		
		if(!XmlMappingUtil.IsNullOrBlank(fxNearLeg))
		{
			LegType leg1Type = objectFactory.createLegType();
			leg1Type.setLegId((short) 1);
			if (!XmlMappingUtil.IsNullOrBlank(productType.getBuySell()))
			{	
			leg1Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
			}
			else
			{
				leg1Type.setPayReceive("PartyUs".equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->fxNearLeg.getExchangedCurrency().get(0).getPayer()))?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);	
			}
			leg1Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg1Type.setStartDate(fxNearLeg.getUnadjustedSettleDate());
			leg1Type.setEndDate(fxNearLeg.getUnadjustedSettleDate());
			leg1Type.setCurrency(XmlMappingUtil.resolveIfNull(()->fxNearLeg.getExchangedCurrency().get(0).getPaymentAmount().getCurrency()));
			leg1Type.setFixedRate(fxNearLeg.getExchangeRate().getSpotRate());
			leg1Type.setNotional(XmlMappingUtil.resolveIfNull(()->fxNearLeg.getExchangedCurrency().get(0).getPaymentAmount().getAmount()));
			leg1Type.setSettlementDate(fxNearLeg.getUnadjustedSettleDate());
			legTypeList.add(leg1Type);
			
			
			LegType leg2Type = objectFactory.createLegType();
			leg2Type.setLegId((short) 2);
			if (!XmlMappingUtil.IsNullOrBlank(productType.getBuySell()))
			{	
			leg2Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.RECEIVE:PayReceiveEnum.PAY);
			}
			else
			{
				leg2Type.setPayReceive("PartyUs".equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->fxNearLeg.getExchangedCurrency().get(1).getPayer()))?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);	
			}
			leg2Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg2Type.setStartDate(fxNearLeg.getUnadjustedSettleDate());
			leg2Type.setEndDate(fxNearLeg.getUnadjustedSettleDate());
			leg2Type.setCurrency(XmlMappingUtil.resolveIfNull(()->fxNearLeg.getExchangedCurrency().get(1).getPaymentAmount().getCurrency()));
			leg2Type.setFixedRate(fxNearLeg.getExchangeRate().getSpotRate());
			leg2Type.setNotional(XmlMappingUtil.resolveIfNull(()->fxNearLeg.getExchangedCurrency().get(1).getPaymentAmount().getAmount()));
			leg2Type.setSettlementDate(fxNearLeg.getUnadjustedSettleDate());
			legTypeList.add(leg2Type);
		}	
		
		if(!XmlMappingUtil.IsNullOrBlank(fxFarLeg))
		{
			LegType leg3Type = objectFactory.createLegType();
			leg3Type.setLegId((short) 3);
			if (!XmlMappingUtil.IsNullOrBlank(productType.getBuySell()))
			{	
			leg3Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
			}
			else
			{
				leg3Type.setPayReceive("PartyUs".equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->fxFarLeg.getExchangedCurrency().get(0).getPayer()))?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);	
			}
			leg3Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg3Type.setStartDate(fxFarLeg.getUnadjustedSettleDate());
			leg3Type.setEndDate(fxFarLeg.getUnadjustedSettleDate());
			leg3Type.setCurrency(XmlMappingUtil.resolveIfNull(()->fxFarLeg.getExchangedCurrency().get(0).getPaymentAmount().getCurrency()));
			leg3Type.setFixedRate(fxFarLeg.getExchangeRate().getSpotRate());
			leg3Type.setNotional(XmlMappingUtil.resolveIfNull(()->fxFarLeg.getExchangedCurrency().get(0).getPaymentAmount().getAmount()));
			leg3Type.setSettlementDate(fxFarLeg.getUnadjustedSettleDate());
			legTypeList.add(leg3Type);
			
			
			LegType leg4Type = objectFactory.createLegType();
			leg4Type.setLegId((short) 4);
			if (!XmlMappingUtil.IsNullOrBlank(productType.getBuySell()))
			{	
			leg4Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.RECEIVE:PayReceiveEnum.PAY);
			}
			else
			{
				leg4Type.setPayReceive("PartyUs".equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->fxFarLeg.getExchangedCurrency().get(1).getPayer()))?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);	
			}
			leg4Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg4Type.setStartDate(fxFarLeg.getUnadjustedSettleDate());
			leg4Type.setEndDate(fxFarLeg.getUnadjustedSettleDate());
			leg4Type.setCurrency(XmlMappingUtil.resolveIfNull(()->fxFarLeg.getExchangedCurrency().get(1).getPaymentAmount().getCurrency()));
			leg4Type.setFixedRate(fxFarLeg.getExchangeRate().getSpotRate());
			leg4Type.setNotional(XmlMappingUtil.resolveIfNull(()->fxFarLeg.getExchangedCurrency().get(1).getPaymentAmount().getAmount()));
			leg4Type.setSettlementDate(fxFarLeg.getUnadjustedSettleDate());
			legTypeList.add(leg4Type);
		}

		
		logger.info("Entering setLegTypeData() method");
		return legTypeList;
	}
}
