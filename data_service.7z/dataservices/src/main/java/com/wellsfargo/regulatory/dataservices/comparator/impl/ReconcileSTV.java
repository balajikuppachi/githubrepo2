package com.wellsfargo.regulatory.dataservices.comparator.impl;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.DataServicesException;
import com.wellsfargo.regulatory.dataservices.comparator.ReconcileDataServicesVs1Str;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.parser.StvParser;

/**
 * 
 * @author Pavithrini Kota
 * Compare the STV sent by DataServices and STV sent by 1STR 
 * 
 */

public class ReconcileSTV implements ReconcileDataServicesVs1Str {

	private static String ignoreStvElements = "MessageId";
	
	private CompareObjects compareObjects = new CompareObjects();
	
	private static HashSet<String> primaryFields = new HashSet<String>();
	private static HashSet<String> secondoryFields = new HashSet<String>();
	
	static {
		
		primaryFields.add("TradeId");
		primaryFields.add("TradeVersion");
		primaryFields.add("PrimaryAssetClass");
		
		secondoryFields.add("Leg1ExoticPrice");
	}
	
	private static Logger logger = Logger.getLogger(ReconcileSTV.class.getName());

	public static void setIgnoreStvElements(String ignoreStvElements) {
		ReconcileSTV.ignoreStvElements = ignoreStvElements;
	}

	/**
	 * Compares one STV to other STV
	 * returns true if same else false
	 */
	@Override
	public Integer compare(String obj1, String obj2, String payloadType) throws DataServicesException {

		StvParser parser = new StvParser();
		Integer matchLevel  = DataServicesConstants.RECON_NO_MATCH;
		
		if ( null == obj1 || obj1.isEmpty() || null == obj2 || obj2.isEmpty() )
		{
			return  DataServicesConstants.RECON_NO_MATCH;
		}
		
		if ( ! DataServicesConstants.STV_PAYLOAD_TYPE.equals(payloadType) )
		{
			String errorStr = " invalid payload type (" + payloadType +") passed to STV reconciliation";
			logger.error("######## Failed to reconcile Stv's as ");
			throw new DataServicesException("recStv:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.DS_ERROR, errorStr);
		}
		
		Map<String, Object> stvMap1 = parser.parseStv(obj1);
		
		Map<String, Object> stvMap2 = parser.parseStv(obj2);
		
		if ( null == stvMap1 || null == stvMap2 )
		{
			return  DataServicesConstants.RECON_NO_MATCH;
		}
		
	/*	if (checkIfEqual (stvMap1, stvMap2))
			
			return 1;*/
		
		matchLevel = checkForMatchLevel(stvMap1, stvMap2);
		
		
		return matchLevel;
	}

	/**
	 * Compares one STV to List of STV's 
	 * returns true if obj1 matches with anyone element of obj2 match
	 * else returns false
	 */
	@Override
	public Integer compare(String obj1, List<String> obj2, String payloadType)  throws DataServicesException {
		
		Integer returnValue = DataServicesConstants.RECON_NO_MATCH ;
		
		if (obj1 == null || obj1.isEmpty() || obj2 == null || obj2.isEmpty())
		{
			return 0;
		}
		
		for (String stv1: obj2)
		{
			Integer curCompareValue = compare (obj1, stv1, payloadType) ;
			if (curCompareValue > returnValue)
				
				returnValue = curCompareValue;
		}
		
		return returnValue;
	}
	
	private boolean checkIfEqual(Map<String, Object> obj1, Map<String, Object> obj2)
	{
		boolean match = true;
		
		int o1size = obj1.keySet().size();
		
		int o2size = obj2.keySet().size();
		
		if (o1size != o2size)
		{
			return false;
		}
		
		for (String key: obj1.keySet())
		{
			if (StringUtils.contains(ignoreStvElements, key))
			{
				continue;
			}
			
			Object value1 = obj1.get(key);
			
			Object value2 = obj2.get(key) ;
			
			if (value1 instanceof String)
			{
				if (! value1.equals(value2))
				{
					match = false;
					break;
				}
			} 
			else if (value1 instanceof LinkedList)
			{
				LinkedList<Object> o1valueslist = (LinkedList<Object>) value1;
				if (value2 instanceof LinkedList)
				{
					LinkedList<Object> o2valueslist = (LinkedList<Object>) value2;
					if (o1valueslist.size() != o2valueslist.size())
					{				
						match = false;
						break;
					}
					for (int i=0; i<o1valueslist.size(); i++)
					{
						Object o1value = o1valueslist.get(i);
						if (!o2valueslist.contains(o1value))
						{
							match = false;
							break;
						}
					}
				}
				else
				{
					match = false;
					break;
				}
			}
			
		}
		
		return match;
	}

	Integer checkForMatchLevel(Map<String, Object> obj1, Map<String, Object> obj2)
	{
		Integer matchLevel = DataServicesConstants.RECON_NO_MATCH; 
		
		boolean primaryMatch = true;
		boolean secondaryMatch = true;
		boolean matchObjects = true;
		
		for (String key: obj1.keySet())
		{
			if (StringUtils.contains(ignoreStvElements, key))
			{
				continue;
			}
			
			Object value1 = obj1.get(key);
			
			Object value2 = obj2.get(key) ;
			
			if (value1 instanceof String)
			{
				if (primaryFields.contains(key) && primaryMatch)
				{
					matchObjects = compareObjects.compare((String)value1, (String)value2);
					if (matchObjects == false)
					{
						primaryMatch = false;
					}
				}
				
				if (secondoryFields.contains(key) && secondaryMatch)
				{
					matchObjects = compareObjects.compare((String)value1, (String)value2);
					if (matchObjects == false)
					{
						secondaryMatch = false;
					}
					
				}
			} 
		}
		
		if (primaryMatch && secondaryMatch)
		{
			matchLevel = DataServicesConstants.RECON_PRIMARY_SECONDARY_MATCH;
			return matchLevel;
		}
		if (primaryMatch)
		{
			matchLevel = DataServicesConstants.RECON_PRIMARY_MATCH;
			return matchLevel;
		}
		
		return matchLevel;
	}
	
	
	@Override
	public Integer compare(List<String> obj1, String obj2, String payloadType)  throws DataServicesException {
		
		 return compare (obj2,obj1,payloadType);	
	}

	@Override
	public Integer compare(List<String> obj1, List<String> obj2, String payloadType)  throws DataServicesException{
		
		Integer returnValue = DataServicesConstants.RECON_FULL_MATCH ;
		
		if ( null == obj1 || obj1.isEmpty() || null == obj2 || obj2.isEmpty() || obj1.size() != obj2.size() )
		{
			return 0;
		}
		
		for (String stv1: obj1)
		{
			Integer curCompareValue = compare (stv1, obj2, payloadType);
			if (curCompareValue <  returnValue)
			{
				returnValue = curCompareValue;
			}
		}
		
		return returnValue;
	}
	
	public static void main(String a[]) throws IOException, DataServicesException
	{
		File srcFile = new File("C:\\SIT_testing\\SampleSTV.txt");
		File srcFile2 = new File("C:\\SIT_testing\\SampleSTV2.txt");
		String stv = org.apache.commons.io.FileUtils.readFileToString(srcFile);
		String stv2 = org.apache.commons.io.FileUtils.readFileToString(srcFile2);
		ReconcileSTV stvRecon = new ReconcileSTV();
		Integer returnValue = stvRecon.compare(stv, stv2, "STV");
		if (returnValue <= 5)
		System.out.println("STVs are NotEqual " + returnValue );
		else
			System.out.println("STVs are Equal " + returnValue );	
		
	}

}
