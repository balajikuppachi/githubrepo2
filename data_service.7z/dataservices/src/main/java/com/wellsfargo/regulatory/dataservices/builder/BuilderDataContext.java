package com.wellsfargo.regulatory.dataservices.builder;


public enum BuilderDataContext {

	
	TRADEBUILDER(new TradeBuilder()),
	LEGBUILDER(new LegBuilder());
	
	private BuilderBase builderBase;
	
	public BuilderBase getBuilderBase() {
		return builderBase;
	}

	public void setBuilderBase(BuilderBase builderBase) {
		this.builderBase = builderBase;
	}

	BuilderDataContext(BuilderBase builderBase) {
		this.builderBase = builderBase;
	}
	
	public BuilderDataContext[] getBuilders() {
		
		return this.values();
	}
}
