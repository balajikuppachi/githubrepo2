package com.wellsfargo.regulatory.dataservices.beans;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.DataServicesException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.bo.WfsMessage;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesPayloadTypeEnum;

public class DataServicesContext
{
	
	private static Logger logger = Logger.getLogger(DataServicesContext.class.getName());
	
	private String errorString;
	private String messageId;
	private TradeContext tradeContext;
	private PayloadContext payloadContext;
	private SdrRequest sdrRequest;
	private DataServicesPayloadTypeEnum contextType;
	private String dsExternalMessageId;
	
	
	private DataServicesContext()
	{
		
	}
	
	public String getMessageId()
	{
		return messageId;
	}

	public void setMessageId(String messageId)
	{
		this.messageId = messageId;
	}


	public static DataServicesContext getInstance()
	{
		return new DataServicesContext();
	}


	public SdrRequest getSdrRequest() {
		return sdrRequest;
	}

	public void setSdrRequest(SdrRequest sdrRequest) {
		this.sdrRequest = sdrRequest;
	}

	public DataServicesPayloadTypeEnum getContextType() {
		return contextType;
	}

	public void setContextType(DataServicesPayloadTypeEnum contextType) {
		this.contextType = contextType;
	}
	
	
	public String getDsExternalMessageId() {
		return dsExternalMessageId;
	}

	public void setDsExternalMessageId(String dsExternalMessageId) {
		this.dsExternalMessageId = dsExternalMessageId;
	}

	public TradeContext getTradeContext() {
		if (tradeContext == null)
		{
			tradeContext = TradeContext.getInstance();
		}
		return tradeContext;
	}

	public void setTradeContext(TradeContext tradeContext) {
		this.tradeContext = tradeContext;
	}

	public PayloadContext getPayloadContext() {
		
		if (payloadContext == null)
		{
			payloadContext =  PayloadContext.getInstance();
		}
				
		return payloadContext;
	}

	public void setPayloadContext(PayloadContext payloadContext) {
		this.payloadContext = payloadContext;
	}

	public void initializeContext(Object ipObject, String dsMessageId,
			DataServicesPayloadTypeEnum contextType, DataServicesContext instance) throws MessagingException, DataServicesException
	{

		logger.debug("Entering DataServicesContext initializeContext() method");

		WfsMessage request = null;

		if (null == ipObject || StringUtils.isBlank(dsMessageId))
		{
			errorString = "Invalid incoming message. DataServices Context could not be initialized.";
			logger.error(errorString);
			throw new DataServicesException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, dsMessageId);
		}

		if (null == contextType)
		{
			errorString = "Invalid incoming context type. Reporting context could not be initialized.";
			logger.error(errorString);
			throw new DataServicesException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, dsMessageId);
		}

		try
		{

			if (DataServicesPayloadTypeEnum.DS_INPUT_JSON.equals(contextType))
			{
				request = (WfsMessage) ipObject;
				instance.getTradeContext().setDsTrade(request);
			}

			instance.setMessageId(dsMessageId);
			instance.setContextType(contextType);

			logger.debug("DataServices context successfully initialized " + instance.toString() + "for the context type " + contextType.name());
	
		}
		catch (Exception e)
		{
			throw new DataServicesException("DataServicesContext-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Unable to initialize reporting context", e.getMessage());
		}

		logger.debug("Leaving DataServicesContext initializeContext() method");

	}
	
	
}
