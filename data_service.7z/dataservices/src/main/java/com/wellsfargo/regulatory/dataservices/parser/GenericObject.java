package com.wellsfargo.regulatory.dataservices.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wellsfargo.regulatory.dataservices.utils.UnsupportedAdditionException;

public class GenericObject {
public static enum Type{
		
		String("String"),Map("Map"),List("List");
		
		String val;
		
		Type(String value){
			this.val = value;
		}
	}
	
	private Type type;
	private Map<String, Object> map;
	private String string;
	private List<Object> list;
	

	public GenericObject(Type type){
		
		if(null != type){
			
			this.type = type;
		
			if(Type.List.equals(type)){
					
				list = new ArrayList<Object>();				
			}
			else if(Type.Map.equals(type)){
				
				map = new HashMap<String, Object>();				
			}
			else if(Type.String.equals(type))
				string = new String();
			
		}		
	}
	
	public void setObject(Object value) throws UnsupportedAdditionException{			
		
		if(null == type || null == value){
			return;
		}
			
		if(Type.List.equals(type) && (value instanceof ArrayList<?>)){
			
			list = (ArrayList<Object>)value;
		}else if(Type.Map.equals(type)  && (value instanceof HashMap<?,?>)){
			
			map = (HashMap<String, Object>)value;
		}else if(Type.String.equals(type) && (value instanceof String)){
			
			string = value.toString();
		}else{
			
			throw new UnsupportedAdditionException("Instance of "+value.getClass()+" is recieved"
					+". Allowed type for this instance is "+type.name());
		}
	}
	
	
	public GenericObject getObject(){			
		return this;
	}

	public Type getType() {
		return type;
	}

	public Map<String, Object> getMap() {
		return map;
	}

	public String getString() {
		return string;
	}

	public List<Object> getList() {
		return list;
	}
	
	public Object getValue(String key)
	{
		if(Type.Map.equals(type))
			return map.get(key);
		if (Type.String.equals(type))
			return string;
		return null;
	}
	
}
