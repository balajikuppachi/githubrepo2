package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.dataservices.bo.FPA;
import com.wellsfargo.regulatory.dataservices.bo.Swap;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.bo.TreasuryLockType;
import com.wellsfargo.regulatory.dataservices.calc.DataServicesCalculationTrigger;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class IrExoticProductXmlMapperService extends GenericXmlMapperService{
	
	private static Logger logger = LoggerFactory.getLogger(IrExoticProductXmlMapperService.class);
	
	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;

	protected ProductType setProductTypeData(TransactionType dsTrade,Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");

		ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade,harmonizerMap));

		logger.info("Leaving setProductTypeData() method");
		productType.setKeywords(null); // TODO
		return productType;
	}
	protected List<LegType>  setLegTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setLegTypeData() method");
		List<LegType> legTypeList = new ArrayList<LegType>();
		
		//check for product type
		com.wellsfargo.regulatory.dataservices.bo.SourceType srcTypeData = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource());
		if(DataServicesConstants.SRC_PRODUCT_TYPE_FPA.equals(srcTypeData.getProductType())) {
			FPA fpa = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getFPA());
			LegType legType = getLegDataForFPA( dsTrade,fpa, (short)1 );
			

			LegType leg2Type = getLegDataForFPA( dsTrade,fpa, (short)2 );
			if(legType.getPayReceive() != null) {
				if(legType.getPayReceive().equals(PayReceiveEnum.PAY)) {
					leg2Type.setPayReceive(PayReceiveEnum.RECEIVE);
				}
				else {
					leg2Type.setPayReceive(PayReceiveEnum.PAY);
				}
			}
			else {
				legType.setPayReceive(PayReceiveEnum.PAY);
				leg2Type.setPayReceive(PayReceiveEnum.RECEIVE);
			}
			legTypeList.add(legType);
			legTypeList.add(leg2Type);
		}
		else if(DataServicesConstants.MMD_RATE_LOCK.equals(srcTypeData.getProductType())) {
			TreasuryLockType treasuryLockType = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getTreasuryLock());
			LegType legType = getLegDataForTreasuryLockType( dsTrade,treasuryLockType, (short)1 );
			

			LegType leg2Type = getLegDataForTreasuryLockType( dsTrade,treasuryLockType, (short)2 );
			if(legType.getPayReceive() != null) {
				if(legType.getPayReceive().equals(PayReceiveEnum.PAY)) {
					leg2Type.setPayReceive(PayReceiveEnum.RECEIVE);
				}
				else {
					leg2Type.setPayReceive(PayReceiveEnum.PAY);
				}
			}
			else {
				legType.setPayReceive(PayReceiveEnum.PAY);
				leg2Type.setPayReceive(PayReceiveEnum.RECEIVE);
			}
			legTypeList.add(legType);
			legTypeList.add(leg2Type);
		}
		
		else if (DataServicesConstants.SRC_PRODUCT_TYPE_STRUCTURED_PRODUCT.equalsIgnoreCase(srcTypeData.getProductType()) &&  DataServicesConstants.PRODUCT_SUB_TYPE_CORRIDOR.equalsIgnoreCase(srcTypeData.getProductSubType())){
			LegType legType = objectFactory.createLegType();
			com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getStructuredProduct().getCapFloor().getCapFloorStream().get(0));
			legType.setLegId((short) (1));
			legType.setPayReceive(legType.getLegId() % 2 == 0 ? PayReceiveEnum.RECEIVE : PayReceiveEnum.PAY);
			boolean isFixed=FixedFloatEnum.FIXED.toString().equalsIgnoreCase(dsLeg.getType())?true:false;
			legType.setFixedFloat(isFixed?FixedFloatEnum.FIXED:FixedFloatEnum.FLOAT);
			legType.setStartDate(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			legType.setEndDate(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
			legType.setCurrency(dsLeg.getSettlementCurrency());
			
			legType.setNotional(XmlMappingUtil.getFormatedValue(()->dsLeg.getNotionalAmount(),BigDecimal.class));
			legType.setNotionalCurrency(dsLeg.getNotionalCurrency());
			legType.setPrice(XmlMappingUtil.formatNumber((XmlMappingUtil.resolveIfNull(()->dsLeg.getExoticPrice()))));
			legType.setPriceUnit(XmlMappingUtil.resolveIfNull(()->dsLeg.getExoticPriceUnits()));
			legType.setBusinessDayConvention(XmlMappingUtil.getEnumString(dsLeg.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
			legType.setDayCountFraction(dsLeg.getDayCountFraction());
			legType.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getSettlement().getSettlementDate()));
			
			legType.setIndexName(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getRateIndex().getFloatingRateIndex()),1,DataServicesConstants.HYPHEN));
			legType.setIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
			legType.setIndexSource(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getRateIndex().getIndexSource()),2,DataServicesConstants.HYPHEN));
			legType.setIndexCurrency(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getRateIndex().getIndexCurrency()),0,DataServicesConstants.HYPHEN));
			legType.setPaymentFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriodMultiplier())));
			legType.setResetFrequency(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod(),String.class)},DataServicesConstants.COLON));
			legType.setSettlementType(SettlementTypeEnum.CASH);
			
			legTypeList.add(legType);
			return legTypeList;
		}
		else {
			Swap swap = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getSwap());
			com.wellsfargo.regulatory.dataservices.bo.LegType dslegType = XmlMappingUtil.resolveIfNull(()->swap.getSwapStream().get(0));
			com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg2Type = XmlMappingUtil.resolveIfNull(()->swap.getSwapStream().get(1));
			
			LegType legType = getLegData( dsTrade,dslegType, (short)1 );
			legTypeList.add(legType);
			LegType leg2Type = getLegData(dsTrade,dsLeg2Type, (short)2);
			
			/**
			 * TODO: Need to override the leg2 startDate with Leg2StartDate from STV
			 */
			
			//set fixedRate for Leg2
			if(!XmlMappingUtil.IsNullOrBlank(dsLeg2Type.getFixed()) && !XmlMappingUtil.IsNullOrBlank(dsLeg2Type.getFixed().getFixedRateInitial()))
			{
			leg2Type.setFixedRate(new BigDecimal(ConversionUtils.formatDecimal8(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFixed().getFixedRateInitial(), BigDecimal.class))));
			}
			legTypeList.add(leg2Type);
		}
		logger.info("Leaving setLegTypeData() method");
		return legTypeList;

	}
	
	private LegType getLegDataForTreasuryLockType(TransactionType dsTrade, TreasuryLockType treasuryLockType, short legId) {

		LegType legType = objectFactory.createLegType();;
		legType.setLegId((short) legId);
		//legType.setPayReceive(XmlMappingUtil.getEnumString(treasuryLockType.getPayOrReceive(), PayReceiveEnum.class));
		
		//legType.setStartDate(XmlMappingUtil.resolveIfNull(legId==1?()->dsTrade.getTrade().getTradeHeader().getTradeDate():()->treasuryLockType.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
		legType.setEndDate(XmlMappingUtil.resolveIfNull(()->treasuryLockType.getMaturityDate()));
		//legType.setDayCountFraction(treasuryLockType.getDayCountFraction());
		legType.setSettlementType(SettlementTypeEnum.CASH);
		
		return legType;
		
	}
	private LegType getLegDataForFPA(TransactionType dsTrade, FPA fpa, short legId) {
		
		LegType legType = objectFactory.createLegType();;
		legType.setLegId((short) legId);
		legType.setPayReceive(XmlMappingUtil.getEnumString(fpa.getPayOrReceive(), PayReceiveEnum.class));
		
		legType.setStartDate(XmlMappingUtil.resolveIfNull(legId==1?()->dsTrade.getTrade().getTradeHeader().getTradeDate():()->fpa.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
		legType.setEndDate(XmlMappingUtil.resolveIfNull(()->fpa.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
		legType.setDayCountFraction(fpa.getDayCountFraction());
		legType.setSettlementType(SettlementTypeEnum.CASH);
		
		
		
		return legType;
	}
	private LegType getLegData(TransactionType dsTrade,com.wellsfargo.regulatory.dataservices.bo.LegType dsLegType, short legId) 
	{
		LegType legType = objectFactory.createLegType();;
		legType.setLegId((short) legId);
		legType.setPayReceive(XmlMappingUtil.getEnumString(dsLegType.getPayOrReceive(), PayReceiveEnum.class));
		boolean isFixed=FixedFloatEnum.FIXED.toString().equalsIgnoreCase(dsLegType.getType())?true:false;
		legType.setFixedFloat(isFixed?FixedFloatEnum.FIXED:FixedFloatEnum.FLOAT);
		legType.setStartDate(XmlMappingUtil.resolveIfNull(legId==1?()->dsTrade.getTrade().getTradeHeader().getTradeDate():()->dsLegType.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
		legType.setEndDate(XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
		legType.setCurrency(dsLegType.getSettlementCurrency());
		legType.setNotional(XmlMappingUtil.getFormatedValue(dsLegType.getNotionalAmount(),BigDecimal.class));
		legType.setNotionalCurrency(dsLegType.getNotionalCurrency());
		legType.setPrice(XmlMappingUtil.formatNumber((dsLegType.getExoticPrice())));
		legType.setPriceUnit(dsLegType.getExoticPriceUnits());
		legType.setBusinessDayConvention(XmlMappingUtil.getEnumString(dsLegType.getCalculationPeriodDates().getCalculationPeriodDatesAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
		legType.setDayCountFraction(dsLegType.getAmortizationParameters().getDayCountFraction());
		legType.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
		
		legType.setIndexName(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getRateIndex().getIndexName()),1,DataServicesConstants.HYPHEN));
		legType.setIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLegType.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLegType.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
		legType.setIndexSource(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getRateIndex().getIndexSource()),2,DataServicesConstants.HYPHEN));
		legType.setIndexCurrency(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getRateIndex().getIndexCurrency()),0,DataServicesConstants.HYPHEN));
		legType.setPaymentFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriodMultiplier())));
		legType.setResetFrequency(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLegType.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLegType.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod(),String.class)},DataServicesConstants.COLON));
		legType.setSettlementType(SettlementTypeEnum.CASH);
		
		return legType;
		
	}
	

}
