package com.wellsfargo.regulatory.dataservices.mapper;



import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.dataservices.bo.CapFloorType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class IrStruturedProductCapFloorXmlMapperService extends IrCapFloorXmlMapperService 
{
	private static Logger logger = LoggerFactory.getLogger(IrStruturedProductCapFloorXmlMapperService.class);

	protected ProductType setProductTypeData(TransactionType dsTrade,Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");

		ProductType productType =  super.setProductTypeData(dsTrade,harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade,harmonizerMap));

		logger.info("Leaving setProductTypeData() method");

		return productType;
	}


	
	protected List<LegType>  setLegTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setLegTypeData() method");
		CapFloorType capFloor= XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getStructuredProduct().getCapFloor());
		
		logger.info("Leaving setLegTypeData() method");
		return super.setLegTypeData(dsTrade, harmonizerMap, capFloor);

	}
	
	
}
