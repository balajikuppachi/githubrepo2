package com.wellsfargo.regulatory.dataservices.service;

import java.io.StringReader;

import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.oxm.Unmarshaller;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.DataServicesException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;
import com.wellsfargo.regulatory.dataservices.bo.WfsMessage;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesPayloadTypeEnum;

@Component
public class DataServicesRequestParserService
{
	
	@Autowired
	@Qualifier("dataServicesJaxbMarshaller")
	private Unmarshaller unmarshaller;
	
	@Autowired
	DataServicesJsonParserService dataServicesJsonParser;
	
	private static Logger logger = Logger.getLogger(DataServicesRequestParserService.class.getName());
	
	public Message<?> parse(Message<?> message) throws Exception
	{
		String dsMessageId = null;
		String errorString = null;
		WfsMessage dsTrade = null;
		DataServicesContext dsContext = null;
		String payload = null;
		Object parsedObject = null;
		StringReader payLoadStream = null;
		
		logger.debug("Entering input dataservices message parsing");

		if (null == message)
		{
			errorString = "Null incoming object. Parsing failed";
			logger.error("########## " + errorString);

			return message;

		}

		if (!(message.getPayload() instanceof DataServicesContext))
		{
			errorString = "Invalid incoming object type. Expected DataServicesContext,  Parsing failed";
			dsMessageId = (String) message.getHeaders().get(DataServicesConstants.DS_MESSAGE_ID);
			logger.error("########## " + errorString);

			throw new DataServicesException("DataServicesRequestParser:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, dsMessageId);
		}

		dsContext = (DataServicesContext) message.getPayload();

		if (null == dsContext || null == dsContext.getPayloadContext().getOrigPayload())
		{
			dsMessageId = (String) message.getHeaders().get(DataServicesConstants.DS_MESSAGE_ID);
			errorString = "Invalid incoming dataservices payload. Parsing failed";
			logger.error("########## " + errorString);

			throw new DataServicesException("DataServicesRequestParser:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, dsMessageId);
		}

		payload = dsContext.getPayloadContext().getOrigPayload();
		
		dsMessageId = dsContext.getMessageId();

		try
		{
			dataServicesJsonParser.parseJson(dsContext);
			payLoadStream = new StringReader(dsContext.getPayloadContext().getDsXmlPayload());
			parsedObject = unmarshaller.unmarshal(new StreamSource(payLoadStream));
		

			if (null == parsedObject || !(parsedObject instanceof WfsMessage))
			{
				errorString = "Invalid parsed object";
				logger.error("########## " + errorString);
			}
		}
		catch (Exception e)
		{
			
			errorString = "Exception occurred while parsing incoming sdr request using JaxB : " + dsMessageId + "::" + e.getMessage();
			logger.info("Payload error*****"+payload+"*****");
			logger.error("########## " + errorString);

			//e.printStackTrace(System.out);
			throw new MessagingException("DataServicesRequestParser:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}
		dsTrade = (WfsMessage) parsedObject;

		try
		{
			// - Initializing the context
			dsContext.initializeContext(dsTrade, dsMessageId, DataServicesPayloadTypeEnum.DS_INPUT_JSON, dsContext);

		}
		catch (Exception e)
		{
			errorString = "Error instantiating the Reporting context : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("DataServicesRequestParser:6", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, dsMessageId, e.getMessage());
		}

		logger.debug("Successfully parsed the incoming trade.");

		return message;
	}

}
