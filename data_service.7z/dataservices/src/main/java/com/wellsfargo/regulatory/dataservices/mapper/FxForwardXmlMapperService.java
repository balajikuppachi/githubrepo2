package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.dataservices.bo.FXSingleLegType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class FxForwardXmlMapperService extends GenericXmlMapperService {


	private static Logger logger = Logger.getLogger(FxForwardXmlMapperService.class.getName());
	
	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");
		
		ProductType productType = super.setProductTypeData(dsTrade, harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade,productType, harmonizerMap));
		
		logger.info("Entering setProductTypeData() method");
		return productType;
	}


	protected List<LegType> setLegTypeData(TransactionType dsTransaction, ProductType productType,  Map<String, String> harmonizerMap) 
	{
		
		logger.info("Entering setLegTypeData() method");
		FXSingleLegType fxSingleLeg1 = XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getProduct().getFX().getFXSingleLeg());
		List<LegType> legTypeList = new ArrayList<LegType>();

		if(!XmlMappingUtil.IsNullOrBlank(fxSingleLeg1))
		{
			LegType leg1Type = objectFactory.createLegType();
			leg1Type.setLegId((short) 1);
			leg1Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
			leg1Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg1Type.setStartDate(fxSingleLeg1.getUnadjustedSettleDate());
			leg1Type.setEndDate(fxSingleLeg1.getUnadjustedSettleDate());
			//leg1Type.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()->fxSingleLeg1.getExchangedCurrency().get(0).getPaymentAmount().getCurrency()));
			leg1Type.setFixedRate(fxSingleLeg1.getSpotRate());
			leg1Type.setNotional(XmlMappingUtil.resolveIfNull(()->fxSingleLeg1.getExchangedCurrency().get(1).getPaymentAmount().getAmount().abs()));
			leg1Type.setCurrency(XmlMappingUtil.resolveIfNull(()->fxSingleLeg1.getExchangedCurrency().get(0).getPaymentAmount().getCurrency()));
			leg1Type.setSettlementDate(fxSingleLeg1.getUnadjustedSettleDate());
			legTypeList.add(leg1Type);
		
			LegType leg2Type = objectFactory.createLegType();
			leg2Type.setLegId((short) 2);
			leg2Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.RECEIVE:PayReceiveEnum.PAY);
			leg2Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg2Type.setStartDate(fxSingleLeg1.getUnadjustedSettleDate());
			leg2Type.setEndDate(fxSingleLeg1.getUnadjustedSettleDate());
			//leg2Type.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()->fxSingleLeg1.getExchangedCurrency().get(1).getPaymentAmount().getCurrency()));
			leg2Type.setFixedRate(new BigDecimal(1.0));
			leg2Type.setNotional(XmlMappingUtil.resolveIfNull(()->fxSingleLeg1.getExchangedCurrency().get(1).getPaymentAmount().getAmount().abs()));
			leg2Type.setCurrency(XmlMappingUtil.resolveIfNull(()->fxSingleLeg1.getExchangedCurrency().get(1).getPaymentAmount().getCurrency()));
			leg2Type.setSettlementDate(fxSingleLeg1.getUnadjustedSettleDate());
			legTypeList.add(leg2Type);
		}	
		logger.info("Entering setLegTypeData() method");
		return legTypeList;
	}

}
