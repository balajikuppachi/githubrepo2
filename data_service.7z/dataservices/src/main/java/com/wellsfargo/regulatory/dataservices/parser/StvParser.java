package com.wellsfargo.regulatory.dataservices.parser;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.exceptions.DataServicesException;
import com.wellsfargo.regulatory.dataservices.comparator.impl.ReconcileSTV;

public class StvParser {

	private static Logger logger = Logger.getLogger(StvParser.class.getName());
	
	private final Pattern arrayPattern = Pattern.compile("\\[\\d+\\]");
	
	public static final String LIST_ELEMENT = "List";
	
	public Map<String,Object> parseStv(String stvStr)
	{
		Map<String, Object> stvMap = null;
		
		if ( null == stvStr)
		{
			return null;
		}
		
		stvMap = new HashMap<String, Object>();
		
		String[] stringArray = stvStr.split("\\{");
		
		for(String row : stringArray) 
		{
			if (!row.trim().isEmpty()) 
			{				
				String[] keyValues = row.trim().split("=");
				
				String key = keyValues[0].trim().substring(0, keyValues[0].length()-1);
				
				Object value = null;
				
				if(keyValues.length == 2) 
				{
					String trimmedValue = keyValues[1].trim();
					value = trimmedValue.isEmpty() ? null : trimmedValue;
				}
				
				Matcher matcher = arrayPattern.matcher(key); 
				
				List<Object> values = null;
				
				if (matcher.find()) 
				{
					// We are dealing with an array here
					key = key.substring(0, matcher.start()) + LIST_ELEMENT;
					
					Object existingValue = stvMap.get(key);
					
					if (existingValue == null) 
					{
						values = new LinkedList<Object>();
						stvMap.put(key, values);
					} 
					else if (existingValue instanceof List) 
					{
						values = (List<Object>) existingValue;
					} 
					
					values.add(value);
					
				} 
				else 
				{
					stvMap.put(key, value);
				}
			}
		}
		
		logger.info("Leaving parse(String) method, stvMap Size :"+stvMap.size());
		
		return stvMap;
	}
	
	public static void main(String a[]) throws IOException, DataServicesException
	{
		File srcFile = new File("C:\\SIT_testing\\SampleSTV.txt");
		File srcFile2 = new File("C:\\SIT_testing\\SampleSTV2.txt");
		String stv = org.apache.commons.io.FileUtils.readFileToString(srcFile);
		String stv2 = org.apache.commons.io.FileUtils.readFileToString(srcFile2);
		//StvParser parser = new StvParser();
		//parser.parseStv(stv);
		ReconcileSTV stvRecon = new ReconcileSTV();
		Integer returnValue = stvRecon.compare(stv, stv2, "STV");
		if (returnValue >= 5)
		System.out.println("STVs are Equal"  );
		else 
			System.out.println("STV's are not Equal");
		
		
	}
}
