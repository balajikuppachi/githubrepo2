package com.wellsfargo.regulatory.dataservices.reader;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.commons.utils.FileUtils;

/***
 * 
 * @author Pavithrini Kota
 * Reads the DataServicesMessage
 *
 */

@Component
public class DataServiesMessageReader
{

	private static Logger logger = Logger.getLogger(DataServiesMessageReader.class.getName());
	
	public Message<?> readMessage(Message<?> message) throws MessagingException
	{
		logger.info("inside DataServiesMessageReader:readMessage method ");

		Object ipMessage = null;
		File srcFile = null;
		String errorString = null;
		String dsMessageId = null;
		String origPayload = null;
		DataServicesContext dsContext = null;
		Message<?> messageOut = null;
		String msgSrc = null;

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);

			return message;
		}

		dsMessageId = (String) message.getHeaders().get(DataServicesConstants.DS_MESSAGE_ID);
		ipMessage = message.getPayload();

		if (null == ipMessage)
		{
			errorString = "Null incoming request ::" + dsMessageId;
			logger.error("########## " + errorString );

			throw new MessagingException("DSReader-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
		}
		else if (ipMessage instanceof File)
		{
			srcFile = ((File) ipMessage);

			try
			{
				origPayload = org.apache.commons.io.FileUtils.readFileToString(srcFile);

				// - Remove the src file
				FileUtils.deleteAFile(srcFile);
			}
			catch (IOException e)
			{
				errorString = "Failed to read the payload ::" + dsMessageId;
				logger.error("########## " + errorString);

				throw new MessagingException("DSReader-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
			}
		}
		else
		{
			errorString = "Failed to read invalid incoming message type ::" + dsMessageId;
			logger.error("########## " + errorString);

			throw new MessagingException("DSReader-5", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		msgSrc = (String) message.getHeaders().get(DataServicesConstants.DS_MESSAGE_TYPE);

		logger.info("@@@@ Message-id :" + StringUtils.trimToEmpty(dsMessageId));
		logger.info("@@@@ Message-source :" + StringUtils.trimToEmpty(msgSrc));
		logger.debug("@@@@ Message-OrigPayload : \n" + StringUtils.trimToEmpty(origPayload));

		dsContext = DataServicesContext.getInstance();
		dsContext.getPayloadContext().setOrigPayload(origPayload);
		dsContext.setMessageId(dsMessageId);

		messageOut = MessageBuilder.withPayload(dsContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.info("@@@@ Message has been sucessfully read !");

		return messageOut;
		
	}

}
