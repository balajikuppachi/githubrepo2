package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.InterpolationMethodEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.LegType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class InterpolationMethodCalc implements DataSevicesCalculation{

	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) 
	{
		/*LegType legType=(LegType) inputArr[0];
		
		
		String interpolationMethod =XmlMappingUtil.resolveIfNull(()->legType.getInflation().getInterpolationMethod());
		
		if(!XmlMappingUtil.IsNullOrBlank(interpolationMethod))
			interpolationMethod=InterpolationMethodEnum.LINEAR_ZERO_YIELD.name();
				
		return interpolationMethod;*/
		
		return DataServicesConstants.LINEAR_ZERO_YIELD;
	}
	
	
	

}
