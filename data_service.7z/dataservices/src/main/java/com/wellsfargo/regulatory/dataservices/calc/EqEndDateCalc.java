package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class EqEndDateCalc implements DataSevicesCalculation {

	@Override
	public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap,	Object[] inputArr) {

		String productType = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType());
		String assetType = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getTaxonomy().get(0).getAssetType());
		XMLGregorianCalendar endDate = null;
		
		if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equals(productType) && DataServicesConstants.STRADDLE.equals(assetType)) {
			endDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getStraddle().getSchedule().getEndDate());
		}
		else if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equals(productType) && 
				(DataServicesConstants.ASIAN.equals(assetType) || DataServicesConstants.SPREAD_ASIAN.equals(assetType)||  DataServicesConstants.RATIO_SPREAD_ASIAN.equals(assetType))) {
			transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getAsian().getAveragingPeriod().getSchedule().get(0).getEndDate().getUnadjustedDate().get(0);
			endDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getAsian().getAveragingPeriod().getSchedule().get(0).getEndDate().getUnadjustedDate().get(0));
		}
		else if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equals(productType) && 
				(DataServicesConstants.SPREAD.equals(assetType) || DataServicesConstants.RATIO_SPREAD.equals(assetType))) {
			endDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getSpread().getSchedule().getEndDate());
		}
		else if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equals(productType) && DataServicesConstants.DIGITAL.equals(assetType)) {
			endDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getDigital().getSchedule().getEndDate());
		}
		else if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equals(productType) && DataServicesConstants.OPTION.equals(assetType)) {
			endDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getOption().getSchedule().getEndDate());
		}
		else if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equals(productType) && DataServicesConstants.CLIQUET.equals(assetType)) {
			endDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getBarrier().getBarrier().getSchedule().get(0).getEndDate().getUnadjustedDate().get(0));
		}
		
		return endDate;
	}

}
