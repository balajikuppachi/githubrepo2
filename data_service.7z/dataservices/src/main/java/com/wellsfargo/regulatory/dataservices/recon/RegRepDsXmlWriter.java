package com.wellsfargo.regulatory.dataservices.recon;

import java.util.Collection;
import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.wellsfargo.regulatory.persister.dataservices.dao.RegRepDsPayloadDao;
import com.wellsfargo.regulatory.persister.dataservices.dto.RegRepDsPayload;

public class RegRepDsXmlWriter  implements ItemWriter<RegRepDsPayload>{

	private RegRepDsPayloadDao regRepDsPayloadDao;
	
	public void setRegRepDsPayloadDao(RegRepDsPayloadDao regRepDsPayloadDao) {
		this.regRepDsPayloadDao = regRepDsPayloadDao;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends RegRepDsPayload> items)
			throws Exception {

		if (items!= null && !items.isEmpty())
			regRepDsPayloadDao.saveOrUpdateAll((Collection<RegRepDsPayload>)items);
		
	}

}
