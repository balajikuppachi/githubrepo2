package com.wellsfargo.regulatory.dataservices.service;



import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;



@Repository
public class CollateralAgreementsExtnDao {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	@Qualifier("collateralJdbcTemplate")
	protected JdbcTemplate colJdbcTemplate;
	
	@Autowired
	@Qualifier("namedParamJdbcTemplate")
	protected NamedParameterJdbcTemplate namedParamJdbcTemplate;
	
	String collateralQuery="SELECT DISTINCT cidLegalId = LE.lgle_id_c FROM customer..legal_entity LE, "+
       			"customer..LegalSystemAccount             LSA, "+
       			"customer..SystemAccountBusUnit           SABU, "+
       			"customer..BusUnitBusAccount              BUBA, "+
       			"customer..bus_a                          BA, "+
       			"customer..bus_a_extl                     BAE "+
 "WHERE LE.lgle_stat_c                           = 'ACTIVE' "+
   "AND LE.lgle_id_c                             = LSA.legalId "+
   "AND LSA.relationshipType                     = 'TRD' "+
   "AND LSA.systemAcctId                         = SABU.systemAcctId "+
   "AND SABU.relationshipType                    = 'TRD' "+
   "AND SABU.busUnitId                           = BUBA.busUnitId "+
   "AND BUBA.relationshipType                    = 'TRD' "+
   "AND BUBA.busAcctId                           = BA.bus_a_id_c "+
   "AND BA.bus_a_stat_c                          = 'ACTIVE' "+
   "AND BA.bus_a_id_c                            = BAE.bus_a_id_c "+
   "AND BAE.bus_a_extl_stat_c                    = 'ACTIVE' "+
   "AND BAE.system_c                             = ? "+
   "AND BAE.bus_a_id_c                           = ?";
	
	String collateralValuationQuery="select sum(case when ca_total < 0 then ca_total else 0 end) total, portfolio_code, principal_id, ca_ccy, collateral_portfolio from collateral_agreements where principal_id in (:principalIds) group by portfolio_code, principal_id, ca_ccy, collateral_portfolio";
	
	String collateralDetailsQuery="select distinct portfolio_code, collateralization,principal_id from collateral_agreements ca, mapping_bussaccid_lei ba  where principal_id  in  (select distinct (case when lei ='BWS7DNS2Z4NPKPNYKL75' then 'WFSI LTD' when lei ='SX0CI4F7GVW5530ZMN03' then 'WFBI' else null end)  from mapping_bussaccid_lei where lei=:lei) and ca.cid_legal = ba.legal_id and ba.lei=:lei2";
	
	
	public String findCidLegalId(String systemName, Long businessAccounId  ) {
		List<String> IdList = colJdbcTemplate.queryForList(collateralQuery, String.class, systemName, businessAccounId);
		if (IdList == null || IdList.isEmpty() || IdList.get(0) == null) {
			return null;
		} else {
			logger.info("Query PLBATCHQA DB");
			return IdList.get(0);
		}
	}
	
	
	public List<Map<String, Object>> findCollateralVals(String[] principalIds) {
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		
		List<String> principalIdlist = new ArrayList<String>();
		for(String principalId : principalIds) {
			principalIdlist.add(principalId);
		}
		
		parameters.addValue("principalIds", principalIdlist);
				
		List<Map<String, Object>> list = namedParamJdbcTemplate.query(collateralValuationQuery, parameters, 
				new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(final ResultSet rs, final int rowNum) throws SQLException {
				
				Map<String, Object> map = new HashMap<String, Object>();
				
				String colValueStr=rs.getString("total");
					BigDecimal colvalueDec = new BigDecimal(colValueStr);
				if(colvalueDec.compareTo(BigDecimal.ZERO)==0)
					colValueStr="0";
				map.put(Constants.COLLATERAL_TOTAL, colValueStr);
				map.put(Constants.COLLATERAL_PORTFOLIO_CODE, rs.getString("portfolio_code"));
				map.put(Constants.COLLATERAL_PRINCIPAL_ID, rs.getString("principal_id"));
				
				map.put(Constants.COLLATERAL_CACCY, rs.getString("ca_ccy"));
				String collPortfolioIndicator = rs.getString("collateral_portfolio");
				
				if(StringUtils.equalsIgnoreCase("Y", collPortfolioIndicator)) 
					collPortfolioIndicator = Constants.TRUE;
				else 
					collPortfolioIndicator = Constants.FALSE;
				
				map.put(Constants.COLLATERAL_COLL_PORTFOLIO, collPortfolioIndicator);
				
				return map;
			}
		});
		
		return list;
		
	}
	
	public List<String[]> findCollateralDetails(String[] principalIds, String lei,String lei2, final String assetClass) {
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		
		List<String> principalIdlist = new ArrayList<String>();
		for(String principalId : principalIds) {
			principalIdlist.add(principalId);
		}
		
		parameters.addValue("principalIds", principalIdlist);
		parameters.addValue("lei", lei);
		parameters.addValue("lei2", lei2);
				
		List<String[]> list = namedParamJdbcTemplate.query(collateralDetailsQuery, parameters, 
				new RowMapper<String[]>() {
			public String[] mapRow(final ResultSet rs, final int rowNum) throws SQLException {
				
				String[] result = new String[2];
				result[0] = rs.getString("portfolio_code");
				String collateralization = rs.getString("collateralization");
				
				if(!GeneralUtils.IsNullOrBlank(collateralization) && !Constants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)) {
					if("PC".equals(collateralization)) 
						collateralization = Constants.PartiallyCollateralized;
					else if("FC".equals(collateralization)) 
						collateralization = Constants.FullyCollateralized;
					else if("OC".equals(collateralization)) 
						collateralization = Constants.OneWayCollateralized;
					else 
						collateralization = Constants.UnCollateralized;
				}
				if(!GeneralUtils.IsNullOrBlank(collateralization) && Constants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)) {
					if("PC".equals(collateralization)) 
						collateralization = Constants.Partially;
					else if("FC".equals(collateralization)) 
						collateralization = Constants.Fully;
					else if("OC".equals(collateralization)) 
						collateralization = Constants.OneWay;
					else 
						collateralization = Constants.UnCollateralized;
				}
				
				result[1] = collateralization;
				
				return result;
			}
		});
		
		return list;
		
	}
	
	
}
