package com.wellsfargo.regulatory.dataservices.persister;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.persister.dao.RegRepDsMappingDao;

public class DataServicesMappingCache {

	private static Logger logger = Logger.getLogger(DataServicesMappingCache.class.getName());

	private static RegRepDsMappingDao regRepDsMappingDao;
	
	
	
	public static void setRegRepDsMappingDao(RegRepDsMappingDao regRepDsMappingDao) {
		DataServicesMappingCache.regRepDsMappingDao = regRepDsMappingDao;
	}

	private static DataServicesMappingCache instance;
	private Map<String, String> dataServicesMappingMap;
	
	private DataServicesMappingCache()
	{
		dataServicesMappingMap = new HashMap<String, String>();
	}
	
	public static void loadDsCache(DataServicesMappingCache domainCache)
	{
		logger.debug("Entering loadDsCache() method");

		String key = null;
		String value = null;

		List<RegRepDomainMapping> configList = regRepDsMappingDao.findAll();

		for (RegRepDomainMapping config : configList)
		{

			key = config.getDomainName() + DataServicesConstants.UNDERSCORE + config.getSrcCode();
			value = config.getDtccCode();

			domainCache.setValue(key, value);
		}

		logger.debug("Successfully loaded Domain Mapping cache " + domainCache);

		logger.debug("Leaving loadDsCache() method");

		return;
	}
	
	
	public static DataServicesMappingCache getDsInstance()
	{

		if (null == instance)
		{
		instance = new DataServicesMappingCache();
		loadDsCache(instance);
		}

		return instance;
	}
	
	public void setValue(String key, String value)
	{
		dataServicesMappingMap.put(key, value);
	}

	public String getValue(String key)
	{
		return dataServicesMappingMap.get(key);
	}

	public Set<String> getKeys()
	{
		return dataServicesMappingMap.keySet();
	}


}
