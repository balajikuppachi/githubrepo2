package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType.ExerciseDates;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.OptionTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DayTypeEnum;
import com.wellsfargo.regulatory.dataservices.bo.OptionType;
import com.wellsfargo.regulatory.dataservices.bo.OptionType.Exercise;
import com.wellsfargo.regulatory.dataservices.bo.SourceType;
import com.wellsfargo.regulatory.dataservices.bo.Swaption;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.calc.DataServicesCalculationTrigger;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;


@Component
public class IrSwaptionXmlMapperService extends IrSwapXmlMapperService {
	
	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;

	private static Logger logger = Logger.getLogger(IrSwaptionXmlMapperService.class.getName());
	
	protected ProductType setProductTypeData(TransactionType dsTransactionType, Map<String, String> harmonizerMap) {
		
		logger.info("IrSwaptionXmlMapperService inside setProductTypeData");
		ProductType productType = objectFactory.createProductType();
		
		SourceType dsSourceType = XmlMappingUtil.resolveIfNull(()->dsTransactionType.getTrade().getTradeHeader().getTradeAttributes().getSource());
		productType.setProductType(dsSourceType.getProductType());		productType.setProductSubType(dsSourceType.getProductSubType());
		productType.setBuySell(XmlMappingUtil.getEnumString(harmonizerMap.get(DataServicesConstants.HRMN_BUY_SELL), BuySellEnum.class));
		productType.getLeg().addAll(setOptionLegTypeData(dsTransactionType, harmonizerMap));
		productType.setExerciseProvision(setExerciseProvisionTypeData(dsTransactionType,harmonizerMap));
		productType.setProductKeys(xmlMapperHelper.getProductKeysTypeData(dsTransactionType, objectFactory,harmonizerMap));
		productType.setKeywords(null);
		productType.getProduct().addAll(setSwapProductTypeData(dsTransactionType,harmonizerMap));

		return productType;
	}
	
	
	private List<LegType> setOptionLegTypeData(TransactionType dsTransactionType,  Map<String, String> harmonizerMap) {

		List<LegType> sdrRequestLegTypeList = new ArrayList<LegType>();
		LegType sdrRequestLegType = objectFactory.createLegType();
		Swaption dsSwaption = XmlMappingUtil.resolveIfNull(()->dsTransactionType.getTrade().getProduct().getInterestRate().getSwaption());
		com.wellsfargo.regulatory.dataservices.bo.LegType dsSwaptionStreamLeg =  XmlMappingUtil.resolveIfNull(()->dsSwaption.getSwap().getSwapStream().get(0));
		BuySellEnum buySell=XmlMappingUtil.getEnumString(harmonizerMap.get(DataServicesConstants.HRMN_BUY_SELL), BuySellEnum.class);
		
		sdrRequestLegType.setLegId((short) 1);
		//boolean isFixed=FixedFloatEnum.FIXED.toString().equalsIgnoreCase(dsSwaptionStreamLeg.getType())?true:false;
		sdrRequestLegType.setFixedFloat(FixedFloatEnum.FIXED);
		if(BuySellEnum.BUY == buySell)
			sdrRequestLegType.setPayReceive(PayReceiveEnum.PAY);
		else
			sdrRequestLegType.setPayReceive(PayReceiveEnum.RECEIVE);
		
		//sdrRequestLegType.setPayReceive(XmlMappingUtil.getEnumString(()->dsSwaptionStreamLeg.getPayOrReceive(), PayReceiveEnum.class));
		sdrRequestLegType.setStartDate(dsSwaption.getOptionFromDate());
		sdrRequestLegType.setEndDate(dsSwaption.getOptionToDate());
		sdrRequestLegType.setCurrency(dsSwaptionStreamLeg.getSettlementCurrency()); 
		sdrRequestLegType.setOptionStrike(dsSwaption.getStrikePrice());
		sdrRequestLegType.setOptionType(XmlMappingUtil.getEnumString(dataServicesCalculationTrigger.calculate(DataServicesCalc.optionTypeCalc, dsTransactionType, null, harmonizerMap,null),OptionTypeEnum.class));
		sdrRequestLegType.setAutoExercise(DataServicesConstants.Automatic.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsSwaption.getExercise().getExerciseAutoOrManual()))?true:false); 
		if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsSwaption.getExercise().getMultipleExerciseFlag())))
		{
		sdrRequestLegType.setMultipleExercise(XmlMappingUtil.getFormatedValue(()->dsSwaption.getExercise().getMultipleExerciseFlag(),Boolean.class));
		}
		if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsSwaption.getExercise().getPartialExerciseFlag())))
		{
		sdrRequestLegType.setPartialExercise(XmlMappingUtil.getFormatedValue(()->dsSwaption.getExercise().getPartialExerciseFlag(),Boolean.class));
		}
		sdrRequestLegType.setResetOffsetDayType(XmlMappingUtil.getEnumString(()->dsSwaptionStreamLeg.getCalculationPeriodDates().getResetDate().getOffsetDayType(),DayTypeEnum.class));
		sdrRequestLegType.setMaximumNotional(XmlMappingUtil.resolveIfNull(()->dsSwaption.getExercise().getMultipleExerciseMaximumExerciseAmount()));
		sdrRequestLegType.setMinimumNotional(XmlMappingUtil.resolveIfNull(()->dsSwaption.getExercise().getMultipleExerciseMinimumExerciseAmount()));
		sdrRequestLegType.setExercisedDate(XmlMappingUtil.resolveIfNull(()->dsTransactionType.getTrade().getTradeHeader().getTradeLifeCycle().getExercisedDate())); 
		sdrRequestLegType.setSwaptionStraddle(XmlMappingUtil.getFormatedValue(dsSwaption.getSwaptionStraddle(),Boolean.class));
		sdrRequestLegType.setNotional(XmlMappingUtil.getFormatedValue(dsSwaptionStreamLeg.getNotionalAmount(),BigDecimal.class));
		sdrRequestLegType.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->dsSwaptionStreamLeg.getNotionalCurrency()));
		sdrRequestLegType.setSettlementType(XmlMappingUtil.getEnumString(dsSwaption.getSettlementType(), SettlementTypeEnum.class));
		
		sdrRequestLegType.setResetFrequency(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsSwaptionStreamLeg.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsSwaptionStreamLeg.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod(),String.class)},DataServicesConstants.COLON));
		sdrRequestLegTypeList.add(sdrRequestLegType);
		return sdrRequestLegTypeList;
		
	}

	private ExerciseProvisionType setExerciseProvisionTypeData(TransactionType dsTransaction, Map<String, String> harmonizerMap) 
	{
		ExerciseProvisionType exerciseProvisionType=null;
		Swaption dsSwaption = dsTransaction.getTrade().getProduct().getInterestRate().getSwaption();
		OptionType.Exercise exercise = dsSwaption.getExercise();
		if(!XmlMappingUtil.IsNullOrBlank(exercise)){
			exerciseProvisionType = objectFactory.createExerciseProvisionType();
			exerciseProvisionType.setOptional(false); 
			exerciseProvisionType.setEventType(null);
			exerciseProvisionType.setExerciseType(XmlMappingUtil.getEnumString(exercise.getOptionExerciseStyle(), ExerciseTypeEnum.class));
			
			exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->exercise.getBermudan().getExerciseDates().getAdjustableDates().getDateAdjustments().getBusinessDayConvention(), BusinessDayConventionEnum.class)); 
			
			
			if(!XmlMappingUtil.IsNullOrBlank(exercise.getAmerican()))
			{
				exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->exercise.getAmerican().getExpirationDate().getUnadjustedDate())); 
				exerciseProvisionType.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getAmerican().getExpirationTime().getHourMinuteTime()))); 
				exerciseProvisionType.setEarliestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getAmerican().getEarliestExerciseTime().getHourMinuteTime()))); 
				exerciseProvisionType.setLatestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getAmerican().getLatestExerciseTime().getHourMinuteTime()))); 
				exerciseProvisionType.setExerciseDateHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->exercise.getAmerican().getExpirationDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA)); 
				exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->exercise.getAmerican().getExpirationDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
				exerciseProvisionType.setCommencementDate(XmlMappingUtil.resolveIfNull(()->exercise.getAmerican().getExpirationDate().getUnadjustedDate())); //stv.SwaptionFirstExerciseDate
				
			}
			
			if(!XmlMappingUtil.IsNullOrBlank(exercise.getBermudan()))
			{
				exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->exercise.getBermudan().getExpirationDate().getUnadjustedDate().get(0))); 
				exerciseProvisionType.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getBermudan().getExpirationTime().getHourMinuteTime()))); 
				exerciseProvisionType.setEarliestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getBermudan().getEarliestExerciseTime().getHourMinuteTime()))); 
				exerciseProvisionType.setLatestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getBermudan().getLatestExerciseTime().getHourMinuteTime()))); 
				exerciseProvisionType.setExerciseDateHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->exercise.getBermudan().getExpirationDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA)); 
				exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->exercise.getBermudan().getExpirationDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
				exerciseProvisionType.setCommencementDate(XmlMappingUtil.resolveIfNull(()->exercise.getBermudan().getExpirationDate().getUnadjustedDate().get(0))); //stv.SwaptionFirstExerciseDate
				
			}
			if(!XmlMappingUtil.IsNullOrBlank(exercise.getEuropean()))
			{
				exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->exercise.getEuropean().getExpirationDate().getUnadjustedDate())); 
				exerciseProvisionType.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getEuropean().getExpirationTime().getHourMinuteTime()))); 
				exerciseProvisionType.setEarliestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getEuropean().getEarliestExerciseTime().getHourMinuteTime()))); 
				exerciseProvisionType.setLatestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->exercise.getEuropean().getLatestExerciseTime().getHourMinuteTime()))); 
				exerciseProvisionType.setExerciseDateHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->exercise.getEuropean().getExpirationDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA)); 
				exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->exercise.getEuropean().getExpirationDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
				exerciseProvisionType.setCommencementDate(XmlMappingUtil.resolveIfNull(()->exercise.getEuropean().getExpirationDate().getUnadjustedDate())); //stv.SwaptionFirstExerciseDate
			}
			exerciseProvisionType.getExerciseDates().addAll(getExerciseDatesData(exercise,harmonizerMap));
			
		}
		return exerciseProvisionType;
	}
	
	private List<ExerciseDates> getExerciseDatesData(Exercise exercise, Map<String, String> harmonizerMap) {
		List<ExerciseDates> exerciseDatesList = new ArrayList<ExerciseDates>();
		
		 List<XMLGregorianCalendar> listObj=  XmlMappingUtil.resolveIfNull(()->exercise.getBermudan().getExerciseDates().getAdjustableDates().getUnadjustedDate());
		if (!XmlMappingUtil.IsListNullOrEmpty(listObj)) { 
			for (XMLGregorianCalendar exerciseDate : listObj) {
				ExerciseDates exerciseDateype = objectFactory.createExerciseProvisionTypeExerciseDates();
				exerciseDateype.setExerciseDate(exerciseDate);
				exerciseDatesList.add(exerciseDateype);
			}
		}
		return exerciseDatesList;
	}

	protected List<ProductType> setSwapProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) {
		List<ProductType> productTypeList = new ArrayList<ProductType>();
		ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
	    //productType.setProductType(dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()); 
		//hard code to Swap - as it always be Swap
		productType.setProductType(DataServicesConstants.SRC_PRODUCT_TYPE_SWAP);
		productTypeList.add(productType);
		return productTypeList;
	}
}
