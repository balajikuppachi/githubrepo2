package com.wellsfargo.regulatory.dataservices.service;

import java.util.Map;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.DataServicesException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;
import com.wellsfargo.regulatory.dataservices.beans.PayloadContext;
import com.wellsfargo.regulatory.dataservices.beans.TradeContext;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.parser.GenericObject;
import com.wellsfargo.regulatory.dataservices.parser.JsonUtil;
import com.wellsfargo.regulatory.dataservices.persister.DataServicesPersisterHelper;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;


/***
 * @author Shreekar Jain
 * @version 1.0
 */
@Component
public class DataServicesJsonParserService {
	
	@Autowired
	JsonUtil jsonParser;
	
	private static Logger logger = Logger.getLogger(DataServicesPersisterHelper.class.getName());
	
	public void parseJson(DataServicesContext instance) throws MessagingException, DataServicesException
	{
		GenericObject dsExtMsgId=null;
		String errorString = null;
		PayloadContext pc=null;
		try
		{
			logger.info("DataServicesJsonParserService: inside parseJson ");
			jsonParser.parse(instance.getPayloadContext().getOrigPayload());
			GenericObject xmlObj = jsonParser.getJsonMsgMap().get(DataServicesConstants.DS_JSON_XML);
			
			pc = instance.getPayloadContext();
			
			
			String xmlPayload = (String) xmlObj.getValue(DataServicesConstants.DS_JSON_XML);
			pc.setDsXmlPayload(xmlPayload);
			
			GenericObject stvObj = jsonParser.getJsonMsgMap().get(DataServicesConstants.DS_JSON_STV);
			String stvPayload = (String) stvObj.getValue(DataServicesConstants.DS_JSON_STV);
			pc.setStvPayload(stvPayload);
			
			GenericObject btDetails = jsonParser.getJsonMsgMap().get(DataServicesConstants.DS_JSON_BUSINESS_TERMS);
			
			TradeContext tc  = instance.getTradeContext();
			
			
			
			String assetClass = (String)btDetails.getValue(DataServicesConstants.DS_JSON_BT_PRODUCT_TYPE);
			
			if (DataServicesConstants.EQUITY.equals(assetClass))
			{
				tc.setTradeId((String)btDetails.getValue(DataServicesConstants.DS_JSON_BT_OTC_TRADEID));
			}
			else
			{
				tc.setTradeId((String)btDetails.getValue(DataServicesConstants.DS_JSON_BT_TRADEID));
				
			}
			
			tc.setTradeVersion((String)btDetails.getValue(DataServicesConstants.DS_JSON_BT_TRADEVERSION));
			logger.info("*****Trade Recieved"+tc.getTradeId()+"-"+tc.getTradeVersion()+"*****");
			tc.setAssetClass(assetClass);
			tc.setUsi((String)btDetails.getValue(DataServicesConstants.DS_JSON_BT_USI) );
			tc.setProductCode((String)btDetails.getValue(DataServicesConstants.DS_JSON_BT_PRODUCT_CODE));
			tc.setTradeDate((String)btDetails.getValue(DataServicesConstants.DS_JSON_BT_TRADE_DATE));
			
	
			dsExtMsgId = jsonParser.getJsonMsgMap().get(DataServicesConstants.DS_JSON_ID);
			
			/** Parser to read sdrKeywords parent keywords */
			GenericObject sdrKeywords = jsonParser.getJsonMsgMap().get(DataServicesConstants.SDR_Keywords);
   		    if( !XmlMappingUtil.IsNullOrBlank(sdrKeywords) && !XmlMappingUtil.IsNullOrBlank(sdrKeywords.getMap()))
   		    	tc.setHarmonizedMap(sdrKeywords.getMap().entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e -> (String)e.getValue())));
			
			//set the DS external messageId
			instance.setDsExternalMessageId(instance.getMessageId() + ":" + dsExtMsgId.getValue(DataServicesConstants.DS_JSON_ID));
			
			logger.info("DataServicesJsonParserService: inside parseJson, json extraction is completed for -> "+ tc.getTradeId());
		}
		catch (Exception e)
		{
			dsExtMsgId = jsonParser.getJsonMsgMap().get(DataServicesConstants.DS_JSON_ID);
			errorString = "Exception occurred while parsing incoming sdr request using JaxB : " +dsExtMsgId.getValue(DataServicesConstants.DS_JSON_ID)+ "::" + e.getMessage();
			logger.error("########## " + errorString);
			throw new DataServicesException("DataServicesContext-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Unable to parse json input message ", e.getMessage());
		}
	}

}
