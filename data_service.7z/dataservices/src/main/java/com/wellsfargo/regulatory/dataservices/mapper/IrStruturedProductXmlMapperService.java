package com.wellsfargo.regulatory.dataservices.mapper;



import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.dataservices.bo.StructuredProductType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class IrStruturedProductXmlMapperService extends GenericXmlMapperService 
{
	private static Logger logger = LoggerFactory.getLogger(IrStruturedProductXmlMapperService.class);

	protected ProductType setProductTypeData(TransactionType dsTrade,Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");

		ProductType productType = objectFactory.createProductType();
		productType = super.setProductTypeData(dsTrade,harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade, productType,harmonizerMap));
		productType.setKeywords(null); // TODO

		logger.info("Leaving setProductTypeData() method");

		return productType;
	}


	
	protected List<LegType> setLegTypeData(TransactionType dsTrade, ProductType productType,Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setLegTypeData() method");

		List<LegType> legTypeList = new ArrayList<LegType>();
		LegType leg1Type = objectFactory.createLegType();
		StructuredProductType dsStructuredProduct=dsTrade.getTrade().getProduct().getInterestRate().getStructuredProduct();
		leg1Type.setLegId((short) 1);
		
		leg1Type.setFixedFloat(FixedFloatEnum.FIXED);
		leg1Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
		leg1Type.setStartDate(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeDate()));
		leg1Type.setEndDate(XmlMappingUtil.resolveIfNull(()->dsStructuredProduct.getStructured().getTerminationDate().getUnadjustedDate()));
		leg1Type.setPrice(XmlMappingUtil.formatNumber(XmlMappingUtil.resolveIfNull(()->dsStructuredProduct.getStructured().getExoticPrice())));
		leg1Type.setPriceUnit(XmlMappingUtil.resolveIfNull(()->dsStructuredProduct.getStructured().getExoticPriceUnits()));
		leg1Type.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsStructuredProduct.getStructured().getTerminationDate().getUnadjustedDate()));
		leg1Type.setSettlementType(SettlementTypeEnum.CASH);
		legTypeList.add(leg1Type);

		
		LegType leg2Type = objectFactory.createLegType();
		leg2Type.setLegId((short) 2);
		leg2Type.setFixedFloat(FixedFloatEnum.FIXED);
		leg2Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.RECEIVE:PayReceiveEnum.PAY);
		leg2Type.setSettlementType(SettlementTypeEnum.CASH);
		
		legTypeList.add(leg2Type);
		logger.info("Leaving setLegTypeData() method");

		return legTypeList;
	}
	
}
