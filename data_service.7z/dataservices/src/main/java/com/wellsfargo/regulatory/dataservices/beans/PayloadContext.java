package com.wellsfargo.regulatory.dataservices.beans;

import java.util.ArrayList;
import java.util.List;

public class PayloadContext {
	
	private String origPayload;
	private String stvPayload;
	private String dsXmlPayload;
	private String regRepXmlPayload;
	private List<String> regRepXmlPayloadList=new ArrayList<String>();
		
	
	public String getOrigPayload() {
		return origPayload;
	}
	public void setOrigPayload(String origPayload) {
		this.origPayload = origPayload;
	}
	public String getStvPayload() {
		return stvPayload;
	}
	public void setStvPayload(String stvPayload) {
		this.stvPayload = stvPayload;
	}
	
	public String getDsXmlPayload() {
		return dsXmlPayload;
	}
	
	public void setDsXmlPayload(String dsXmlPayload) {
		this.dsXmlPayload = dsXmlPayload;
	}
	public static PayloadContext getInstance()
	{
		return new PayloadContext();
	}
	public String getRegRepXmlPayload() {
		return regRepXmlPayload;
	}
	public void setRegRepXmlPayload(String regRepXmlPayload) {
		this.regRepXmlPayload = regRepXmlPayload;
	}
	public List<String> getRegRepXmlPayloadList() {
		return regRepXmlPayloadList;
	}
	public void setRegRepXmlPayloadList(List<String> regRepXmlPayloadList) {
		this.regRepXmlPayloadList = regRepXmlPayloadList;
	}

	
	
	
	
}
