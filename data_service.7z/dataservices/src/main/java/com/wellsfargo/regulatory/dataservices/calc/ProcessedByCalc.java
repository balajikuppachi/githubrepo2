package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;

@Component
public class ProcessedByCalc implements DataSevicesCalculation{

	String markitWire[]={"ECN_SWAPSWIRE","ECN_BLOOMBERG","ECN_TRADEWEB"};
	
	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) 
	{
		
		String ecnSource = transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getECNSource();
		if(StringUtils.isNotEmpty(ecnSource) &&  ArrayUtils.contains(markitWire,ecnSource))
		{
			ecnSource=DataServicesConstants.MARKIT_WIRE;
		}
		return ecnSource;
		
	}

}
