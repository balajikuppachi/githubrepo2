package com.wellsfargo.regulatory.dataservices.recon;

public class RegRepDsRecon implements java.io.Serializable{

	private String msgId;
	private Long dsPayloadId;
	private String dsPayload;
	private Long sdrPayloadId;
	private String sdrPayload;
	
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	
	public Long getDsPayloadId() {
		return dsPayloadId;
	}
	public void setDsPayloadId(Long dsPayloadId) {
		this.dsPayloadId = dsPayloadId;
	}
	
	public String getDsPayload() {
		return dsPayload;
	}
	public void setDsPayload(String dsPayload) {
		this.dsPayload = dsPayload;
	}
	
	public Long getSdrPayloadId() {
		return sdrPayloadId;
	}
	public void setSdrPayloadId(Long sdrPayloadId) {
		this.sdrPayloadId = sdrPayloadId;
	}
	
	public String getSdrPayload() {
		return sdrPayload;
	}
	public void setSdrPayload(String sdrPayload) {
		this.sdrPayload = sdrPayload;
	}
	
}
