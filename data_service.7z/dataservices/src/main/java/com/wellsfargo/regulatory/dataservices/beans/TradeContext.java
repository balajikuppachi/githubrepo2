package com.wellsfargo.regulatory.dataservices.beans;

import java.util.HashMap;
import java.util.Map;

import com.wellsfargo.regulatory.dataservices.bo.WfsMessage;

public class TradeContext {

	private String assetClass;
	private String tradeId;
	private String tradeVersion;
	private String usi;
	private String productCode;
	private String tradeDate;
	private WfsMessage dsTrade;
	private Map<String,String> harmonizedMap=null;
	
	public String getAssetClass() {
		return assetClass;
	}
	
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	
	public String getTradeId() {
		return tradeId;
	}
	
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	
	public String getTradeVersion() {
		return tradeVersion;
	}
	
	public void setTradeVersion(String tradeVersion) {
		this.tradeVersion = tradeVersion;
	}
	
	public String getUsi() {
		return usi;
	}
	
	public void setUsi(String usi) {
		this.usi = usi;
	}
	
	public String getProductCode() {
		return productCode;
	}
	
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	public String getTradeDate() {
		return tradeDate;
	}
	
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	
	public WfsMessage getDsTrade() {
		return dsTrade;
	}
	
	public void setDsTrade(WfsMessage dsTrade) {
		this.dsTrade = dsTrade;
	}
	
	public static TradeContext getInstance()
	{
		return new TradeContext();
	}

	/**
	 * @return the harmonizedMap
	 */
	public Map<String, String> getHarmonizedMap() {
		return harmonizedMap;
	}

	/**
	 * @param harmonizedMap the harmonizedMap to set
	 */
	public void addToHarmonizedMap(String key,String value) 
	{
		if(harmonizedMap==null)
		{
			harmonizedMap=new HashMap<String,String>();
		}
		harmonizedMap.put(key, value);
	}

	/**
	 * @param harmonizedMap the harmonizedMap to set
	 */
	public void setHarmonizedMap(Map<String, String> harmonizedMap) {
		if(harmonizedMap==null)
		{
			harmonizedMap=new HashMap<String,String>();
		}
		this.harmonizedMap = harmonizedMap;
	}
	
	
	
}
