package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;
import com.wellsfargo.regulatory.dataservices.bo.ConfirmType;
import com.wellsfargo.regulatory.dataservices.bo.SourceType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesPayloadTypeEnum;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class DataServicesToSdrRequestMapper
{
	@Autowired
	ProductMapperFactory productMapperFactory;
	
	private static Logger logger = Logger.getLogger(DataServicesToSdrRequestMapper.class.getName());
	
	public Message<?> convert(Message<?> message) throws MessagingException
	{
		logger.info("inside DataServicesToSdrRequestMapper:convert method ");
		
		DataServicesContext dsContext=(DataServicesContext) message.getPayload();
		SdrRequest sdrRequest = new SdrRequest();
		TransactionType dsTrade=dsContext.getTradeContext().getDsTrade().getTransaction();
		ConfirmType confirmTrade = dsContext.getTradeContext().getDsTrade().getConfirm();
		Map<String, String> harmonizerMap=dsContext.getTradeContext().getHarmonizedMap();
		
		if(!XmlMappingUtil.IsNullOrBlank(dsTrade))
		{
			SourceType sourceType=dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource();
			GenericXmlMapperService genericXmlMapperService = productMapperFactory.getMapper(sourceType,harmonizerMap);
			sdrRequest=genericXmlMapperService.buildXml(dsTrade,harmonizerMap);
		}else if(!XmlMappingUtil.IsNullOrBlank(confirmTrade))
		{
			ConfirmationXmlMapperService confirmationXmlMapperService = productMapperFactory.getMapper(confirmTrade,harmonizerMap);
			sdrRequest=confirmationXmlMapperService.buildXml(confirmTrade,harmonizerMap);
		}
		sdrRequest.setMessageId(dsContext.getDsExternalMessageId());
		dsContext.setSdrRequest(sdrRequest);
		dsContext.setContextType(DataServicesPayloadTypeEnum.REG_REP_XML);
		
		logger.info("inside DataServicesToSdrRequestMapper:mapping of DS to REGREP xml completed");
		return message;
	}
	
	

}
