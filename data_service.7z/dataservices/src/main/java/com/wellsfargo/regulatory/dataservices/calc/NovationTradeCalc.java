package com.wellsfargo.regulatory.dataservices.calc;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.mapper.XmlMapperHelper;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class NovationTradeCalc implements DataSevicesCalculation
{
	@Autowired
	protected XmlMapperHelper xmlMapperHelper;
	
	
	
	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr)
	{
		String assetClass=xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
		boolean isNovation = false;
		if(DataServicesConstants.ASSET_CLASS_INTEREST_RATE.equals(assetClass)) {
			isNovation = checkRatesNovation(sdrRequest);
		}
		else if(DataServicesConstants.ASSET_CLASS_CREDIT.equals(assetClass)) {
			isNovation = checkCreditNovation(sdrRequest);
		}
		return isNovation;
	}



	private boolean checkCreditNovation(SdrRequest sdrRequest) {

		boolean isCreditNovation = false;
		String marketType = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeHeader().getLifeCycle().getEventType());
		String docStatus = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeHeader().getStatus());
		List<FeeType> feeTypeList = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee());
		String ncActivity = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeHeader().getLifeCycle().getNovation().getNovationAction());
		
		if(null != marketType) {
			if(StringUtils.containsIgnoreCase(marketType, DataServicesConstants.Novation)) {
				for(FeeType feetype: feeTypeList) {
					if(DataServicesConstants.Novation.equals(feetype.getType())) {
						return Boolean.TRUE;
					}
					else if(DataServicesConstants.Cancel.equals(ncActivity) && DataServicesConstants.TRADE_STATUS_VERIFIED.equalsIgnoreCase(docStatus)) {
						return Boolean.TRUE;
					}
				}
			}
				if(DataServicesConstants.Credit_Novation_OR.equals(marketType) || DataServicesConstants.Credit_Partial_Novation_OR.equals(marketType)) {
					if(DataServicesConstants.TRADE_STATUS_VERIFIED.equalsIgnoreCase(docStatus) && DataServicesConstants.Cancel.equalsIgnoreCase(ncActivity)) {
						return Boolean.TRUE;
					}
				}
				else if(DataServicesConstants.Credit_Novation_EE.equals(marketType)) {
					if (DataServicesConstants.TRADE_STATUS_NC_CANCELED.equalsIgnoreCase(docStatus) && DataServicesConstants.Cancel.equalsIgnoreCase(ncActivity)) {
						return Boolean.TRUE;
					}
				}
		}
		
		
		return isCreditNovation;
	}



	private boolean checkRatesNovation(SdrRequest sdrRequest) {

		boolean isRatesNovation = false;
		String marketType = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeHeader().getLifeCycle().getEventType());
		String docStatus = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeHeader().getStatus());
		
		List<FeeType> feeTypeList =  XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee());
		
		if(null != marketType) {
			if((DataServicesConstants.Novation_EE.equals(marketType) && (DataServicesConstants.PENDING.equals(docStatus) || DataServicesConstants.DAY_PENDING.equals(docStatus)) )
					|| (DataServicesConstants.Novation_OR.equals(marketType) && (DataServicesConstants.ASSIGNED.equals(docStatus) || DataServicesConstants.DAY_ASSIGNED.equals(docStatus)))
					||	(DataServicesConstants.PartialNovation_OR.equals(marketType) && (DataServicesConstants.PENDING.equals(docStatus) || DataServicesConstants.DAY_PENDING.equals(docStatus)))) {
				for(FeeType feetype: feeTypeList) {
					if(DataServicesConstants.FeeType_NovationFee.equals(feetype.getType())) {
						isRatesNovation = true;
					}
				}
			}
			
		}
		return isRatesNovation;
	}

}
