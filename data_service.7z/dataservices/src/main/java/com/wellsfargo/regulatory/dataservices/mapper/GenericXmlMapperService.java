package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CalculationAgentPartyEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExecutionVenueEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeInfoType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ObjectFactory;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartiesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.VerificationMethodEnum;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.dataservices.bo.ExecutionType;
import com.wellsfargo.regulatory.dataservices.bo.PartyThemType;
import com.wellsfargo.regulatory.dataservices.bo.PartyUsType;
import com.wellsfargo.regulatory.dataservices.bo.SourceType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.calc.DataServicesCalculationTrigger;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;



abstract public class GenericXmlMapperService 
{
	@Autowired
	protected ObjectFactory objectFactory;
	
	@Autowired
	protected XmlMapperHelper xmlMapperHelper;
	

	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;

	private static Logger logger = Logger.getLogger(GenericXmlMapperService.class.getName());
	
	public SdrRequest buildXml(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		SdrRequest sdrRequest = objectFactory.createSdrRequest();
		try 
		{
			SourceType sourceType=dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource();
			String srcAssetClass= xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
			String upi = null;
			sdrRequest.setSource(sourceType.getSystem().toString());
			
			sdrRequest.setAssetClass(srcAssetClass);
			sdrRequest.setTrade(setTradeTypeData(dsTrade,harmonizerMap));
			sdrRequest.setCreateDateTime(XmlMappingUtil.getGregorianCurrentDate());
			
			
			/***** Additional items in trades header is mapped using below code. Please refrain from using this way for future items * */
			
			String calculationAgent = (String) dataServicesCalculationTrigger.calculate(DataServicesCalc.calculationAgentCalc, dsTrade, sdrRequest, harmonizerMap, new Object[]{srcAssetClass});
			sdrRequest.getTrade().getTradeHeader().setCalculationAgentParty(XmlMappingUtil.getEnumString(calculationAgent, CalculationAgentPartyEnum.class));
			if(!XmlMappingUtil.IsNullOrBlank(calculationAgent))
			sdrRequest.getTrade().getTradeHeader().setCalculationAgentId(calculationAgent.replace("_",""));
			upi = XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.upiCalc, dsTrade, sdrRequest, harmonizerMap, null),String.class);
			sdrRequest.getTrade().getTradeDetail().getProduct().getProductKeys().setUPI(upi);
			
			/**
			 * For Products having sub products (ex: Swaption) populate the UPI
			 */
			if (!XmlMappingUtil.IsNullOrBlank(sdrRequest.getTrade().getTradeDetail().getProduct().getProduct()) && 
					sdrRequest.getTrade().getTradeDetail().getProduct().getProduct().size() > 0) {
				ProductType subProduct = sdrRequest.getTrade().getTradeDetail().getProduct().getProduct().get(0);
				if (!XmlMappingUtil.IsNullOrBlank(subProduct))	{
					subProduct.getProductKeys().setUPI(upi);
				}
			}
			
			if(Constants.CREDIT.equalsIgnoreCase(srcAssetClass)){
				sdrRequest.getTrade().getTradeDetail().getDocumentation().setMasterDocumentTransactionType(calculateDocumentTransactionType(dsTrade,sdrRequest,harmonizerMap,new Object[]{srcAssetClass}));
				sdrRequest.getTrade().getTradeDetail().getDocumentation().setMasterDocumentationType(calculateDocumentType(dsTrade,sdrRequest,harmonizerMap,new Object[]{srcAssetClass}));
				sdrRequest.getTrade().getTradeDetail().getDocumentation().setMasterDocumentDate((XMLGregorianCalendar)dataServicesCalculationTrigger.calculate(DataServicesCalc.calculateMasterDocumentDateCalc, dsTrade, null, null, new Object[]{srcAssetClass}));
			}
			
		} catch (Exception e) {
			logger.error(" *************** Exception while buiding Data Services Xml " +  ExceptionUtils.getFullStackTrace(e) );
		}
		return sdrRequest;
		
	}

	private String calculateDocumentType(TransactionType dsTrade, SdrRequest sdrRequest,Map<String, String> harmonizerMap,Object[] inputArr) 
	{
	
		String dtccprodtype=XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.calculateDtccProductcalc, dsTrade, sdrRequest, harmonizerMap, inputArr),String.class);
		if(Constants.PRODUCT_TYPE_CDS.equalsIgnoreCase(dtccprodtype) || Constants.PRODUCT_TYPE_RECOVERY_LOCK.equalsIgnoreCase(dtccprodtype))
			return XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.calculateDocumentTypeMatrixCalc, dsTrade, sdrRequest, harmonizerMap, inputArr),String.class);
		
		return Constants.DTCC_STS_VALUE;
	}

	private String calculateDocumentTransactionType(TransactionType dsTrade, SdrRequest sdrRequest,Map<String, String> harmonizerMap,Object[] inputArr) {
		try {
			String docType=XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.calculateMasterDocumentTransactionTypeCalc, dsTrade, sdrRequest, harmonizerMap, inputArr),String.class);
			String productType=XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.calculateDtccProductcalc, dsTrade, sdrRequest, harmonizerMap, inputArr),String.class);
			if(XmlMappingUtil.IsNullOrBlank(docType) && !XmlMappingUtil.IsNullOrBlank(productType))
			{
				if(Constants.PRODUCT_TYPE_ELCDS.equalsIgnoreCase(productType)) return Constants.CDSonLeveragedLoans;
				if(Constants.PRODUCT_TYPE_EMBS.equalsIgnoreCase(productType)) return Constants.EuropeanCMBS;
				if(Constants.PRODUCT_TYPE_LCDS.equalsIgnoreCase(productType) || Constants.PRODUCT_TYPE_MBS.equalsIgnoreCase(productType)) return Constants.StandardTermsSupplement;
				if(Constants.PRODUCT_TYPE_MBX.equalsIgnoreCase(productType)) return Constants.PRODUCT_TYPE_MBX;
				docType=Constants.CreditIndex;
			}
			return docType;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	private TradeType setTradeTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		TradeType tradeType=objectFactory.createTradeType();
	    tradeType.setTradeHeader(setTradeHeaderTypeData(dsTrade,harmonizerMap));
		tradeType.setTradeDetail(setTradeDetailTypeData(dsTrade,harmonizerMap));
		tradeType.setRegulatory(setRegulatoryTypeData(dsTrade,harmonizerMap));
		
	
		return tradeType;
	}

	private TradeDetailType setTradeDetailTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap)
	{
		TradeDetailType tradeDetailType=objectFactory.createTradeDetailType();
		tradeDetailType.setTradeParties(setTradePartiesData(dsTrade,harmonizerMap));
		tradeDetailType.setDocumentation(xmlMapperHelper.getDocumentationTypeData(dsTrade, objectFactory,harmonizerMap));
		//tradeDetailType.setFeeInfo(xmlMapperHelper.getFeeInfoTypeData(dsTrade, objectFactory));
		tradeDetailType.setFeeInfo(getFeeInfoTypeData(dsTrade, objectFactory));
		tradeDetailType.setProduct(setProductTypeData(dsTrade,harmonizerMap));
		return tradeDetailType;
	}

	protected TradePartiesType setTradePartiesData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		TradePartiesType tradePartiesType=objectFactory.createTradePartiesType();
		tradePartiesType.getParty().add(xmlMapperHelper.getTradePartiesDetailsData(dsTrade, objectFactory, false,harmonizerMap));
		tradePartiesType.getParty().add(xmlMapperHelper.getTradePartiesDetailsData(dsTrade, objectFactory, true,harmonizerMap));
		return tradePartiesType;
	}
	
	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		String assetClass =  xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
		
		logger.info("Entering setProductTypeData() method");
		com.wellsfargo.regulatory.dataservices.bo.SourceType srcTypeData = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource());
		ProductType productType = objectFactory.createProductType();
		productType.setProductType(srcTypeData.getProductType());
		if(!assetClass.equalsIgnoreCase(DataServicesConstants.EQUITY)) {
			
			productType.setNonStandardFlag(XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getRegulatory().getNonstandardFlag(),Boolean.class));
		}
		else {
			productType.setNonStandardFlag(null);
		}
		productType.setProductSubType(srcTypeData.getProductSubType());
		if(!XmlMappingUtil.IsNullOrBlank(assetClass) && assetClass.equalsIgnoreCase("InterestRate"))
		{
		productType.setBuySell(XmlMappingUtil.getEnumString(harmonizerMap.get(DataServicesConstants.HRMN_BUY_SELL), BuySellEnum.class));
		}
		else {
			String buyerValue = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getBuyer());

			if (!XmlMappingUtil.IsNullOrBlank(buyerValue) && "partyUs".equalsIgnoreCase(buyerValue))
			{
				productType.setBuySell(BuySellEnum.BUY);
			}
			else if (!XmlMappingUtil.IsNullOrBlank(buyerValue) && "partyThem".equalsIgnoreCase(buyerValue)) {
				productType.setBuySell(BuySellEnum.SELL);
			}

		}
			
		productType.setProductKeys(xmlMapperHelper.getProductKeysTypeData(dsTrade, objectFactory,harmonizerMap));
		
		logger.info("Leaving setProductTypeData() method");

		return productType;
	}

	
	
	protected TradeHeaderType setTradeHeaderTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setTradeHeaderTypeData() method");

		com.wellsfargo.regulatory.dataservices.bo.TradeHeaderType tradeHeader=dsTrade.getTrade().getTradeHeader();
		SourceType sourceType = tradeHeader.getTradeAttributes().getSource();
		ExecutionType execution = tradeHeader.getTradeAttributes().getExecution();
		TradeHeaderType tradeHeaderType = objectFactory.createTradeHeaderType();
		String assetClass =  xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
		PartyUsType partyUsType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getPartyUs());
		PartyThemType partyThemType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getPartyThem());
		
		tradeHeaderType.setTradeId(sourceType.getTradeId());
		tradeHeaderType.setSecondaryTradeId(tradeHeader.getTradeId());
		tradeHeaderType.setTradeVersion(sourceType.getTradeVersion());
		tradeHeaderType.setBookName(sourceType.getBookInfo());
		tradeHeaderType.setProcessingOrgLEI(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.resolveIfNull(()->partyUsType.getPartyInfo().getPrefix()),XmlMappingUtil.resolveIfNull(()->partyUsType.getPartyInfo().getValue())}, DataServicesConstants.COLON));
		tradeHeaderType.setProcessingOrgLEIPrefix(XmlMappingUtil.resolveIfNull(()->partyUsType.getPartyInfo().getPrefix()));
		tradeHeaderType.setProcessingOrgLEIValue(XmlMappingUtil.resolveIfNull(()->partyUsType.getPartyInfo().getValue()));
		tradeHeaderType.setCounterpartyLEI(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.resolveIfNull(()->partyThemType.getPartyInfo().getPrefix()),XmlMappingUtil.resolveIfNull(()->partyThemType.getPartyInfo().getValue())}, DataServicesConstants.COLON));
		tradeHeaderType.setCounterpartyLEIPrefix(XmlMappingUtil.resolveIfNull(()->partyThemType.getPartyInfo().getPrefix()));
		tradeHeaderType.setCounterpartyLEIValue(XmlMappingUtil.resolveIfNull(()->partyThemType.getPartyInfo().getValue()));
		if("Equity".equalsIgnoreCase(assetClass)) {
			tradeHeaderType.setAction(sourceType.getMessageEventType());
			
		}
		else {
			tradeHeaderType.setAction(xmlMapperHelper.getActionData(sourceType.getLifeCycleEvent()));
			
		}
		tradeHeaderType.setStatus(sourceType.getTradeStatus());
		tradeHeaderType.setTraderName(XmlMappingUtil.getElementFromList(partyUsType.getRelatedRole(), DataServicesConstants.TYPE, DataServicesConstants.TRADER,DataServicesConstants.NAME));
		tradeHeaderType.setTradeDate(tradeHeader.getTradeDate());
		tradeHeaderType.setExecutionDateTime(XmlMappingUtil.getFormatedValue(XmlMappingUtil.resolveIfNull(()->execution.getExecutionTimestamp()),XMLGregorianCalendar.class));
		String value=XmlMappingUtil.getElementFromList(partyUsType.getRelatedParty(), DataServicesConstants.ROLE, DataServicesConstants.CalculationAgent,DataServicesConstants.Value);
		
		String prefix=XmlMappingUtil.getElementFromList(partyUsType.getRelatedParty(), DataServicesConstants.ROLE, DataServicesConstants.CalculationAgent,DataServicesConstants.Prefix);
		tradeHeaderType.setCalculationAgentId(XmlMappingUtil.concatenateArrayValues(new String[]{prefix,value},null));
		if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->(execution.getExecutionVenueType()))) && DataServicesConstants.SEF.equalsIgnoreCase(execution.getExecutionVenueType()))
		{
			tradeHeaderType.setExecutionVenue(DataServicesConstants.SEF);
		}
		else
		{
			tradeHeaderType.setExecutionVenue(DataServicesConstants.OFF_FACILITY);
		}
		
		//tradeHeaderType.setCalculationAgentParty(XmlMappingUtil.getEnumString(XmlMappingUtil.getElementFromList(partyUsType.getRelatedParty(), DataServicesConstants.ROLE, DataServicesConstants.CalculationAgent,DataServicesConstants.NAME), CalculationAgentPartyEnum.class));
		tradeHeaderType.setCalculationAgentCity(XmlMappingUtil.getElementFromList(partyUsType.getRelatedParty(), DataServicesConstants.ROLE, DataServicesConstants.CalculationAgent,DataServicesConstants.LOCATION));
		tradeHeaderType.setEcnSource(sourceType.getECNSource());
		String executionVenue =  XmlMappingUtil.resolveIfNull(()->tradeHeader.getTradeAttributes().getExecution().getExecutionVenueType());
		
		tradeHeaderType.setExecutionVenueType(XmlMappingUtil.getEnumString(executionVenue, ExecutionVenueEnum.class));
		//tradeHeaderType.setVerificationMethod(XmlMappingUtil.getEnumString(tradeHeader.getTradeAttributes().getExecution().getVerificationMethod(), VerificationMethodEnum.class));
		tradeHeaderType.setVerificationMethod(XmlMappingUtil.getEnumString(dataServicesCalculationTrigger.calculate(DataServicesCalc.verificationTypeCalc, dsTrade, null, harmonizerMap, null), VerificationMethodEnum.class));
		tradeHeaderType.setEnteredUser(null);
		tradeHeaderType.setEnteredDateTime(null);
		tradeHeaderType.setComment(tradeHeader.getTradeComment());
		tradeHeaderType.setBackload(XmlMappingUtil.getFormatedValue(tradeHeader.getTradeAttributes().getRegulatory().getBackLoadIndicator(),Boolean.class));
		tradeHeaderType.setBackload(BooleanUtils.isTrue(tradeHeaderType.isBackload()));
		tradeHeaderType.setLifeCycle(xmlMapperHelper.getLifeCycleTypeData(dsTrade, objectFactory));
		tradeHeaderType.setKeywords(xmlMapperHelper.getTradeKeywordsData(dsTrade, objectFactory,harmonizerMap));
		tradeHeaderType.setTradeUpdateDatetime(XmlMappingUtil.getFormatedValue(tradeHeader.getTradeAttributes().getSource().getTradeUpdateDateTime(),XMLGregorianCalendar.class));
		tradeHeaderType.setMessageUpdateDateTime(XmlMappingUtil.getFormatedValue(tradeHeader.getTradeAttributes().getSource().getMessageUpdateDateTime(),XMLGregorianCalendar.class));
		
		tradeHeaderType.setOrigExecutionDateTime(XmlMappingUtil.getFormatedValue(XmlMappingUtil.resolveIfNull(()->execution.getExecutionTimestamp()),XMLGregorianCalendar.class));
		tradeHeaderType.setBrokerLEIPrefix(XmlMappingUtil.getElementFromList(partyUsType.getRelatedParty(), DataServicesConstants.ROLE,"Broker",DataServicesConstants.Prefix));
		tradeHeaderType.setBrokerLEIValue(XmlMappingUtil.getElementFromList(partyUsType.getRelatedParty(), DataServicesConstants.ROLE,"Broker",DataServicesConstants.Value));
		tradeHeaderType.setTradeAction(sourceType.getTradeAction());
		tradeHeaderType.setSdrAction(sourceType.getSDRAction());
		logger.info("Leaving setTradeHeaderTypeData() method");

		return tradeHeaderType;
	}

	protected RegulatoryType setRegulatoryTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setRegulatoryTypeData() method");

		
		RegulatoryType regulatoryType = objectFactory.createRegulatoryType();
		
		regulatoryType.setFirstReportedSDR(null);
		regulatoryType.setMixedSwapSDR(null);
		regulatoryType.setVoluntaryReporting(false);
		regulatoryType.setHistoricalSwap(false);
		regulatoryType.setSwapPurpose(null);
		regulatoryType.setExtraLegalLanguage(null);
		//regulatoryType.setCollateralizationType(XmlMappingUtil.getEnumString(dsTrade.getTrade().getTradeHeader().getTradeAttributes().getCollateral() , com.wellsfargo.regulatory.commons.bo.sdrRequest.CollateralTypeEnum.class ));
		regulatoryType.setCollateralizationType(XmlMappingUtil.getEnumString(dataServicesCalculationTrigger.calculate(DataServicesCalc.collateralizedDataCalc, dsTrade, null, harmonizerMap, null),com.wellsfargo.regulatory.commons.bo.sdrRequest.CollateralTypeEnum.class));
		regulatoryType.setBonafideHedgeExemption(null);
		regulatoryType.setFeeReportingParty(XmlMappingUtil.getEnumString(dsTrade.getTrade().getParty().getFeeTradeReportingParty(),UsThemEnum.class));
		regulatoryType.setFeePayer((String)dataServicesCalculationTrigger.calculate(DataServicesCalc.premiumPayOrReceiveCalc, dsTrade, null, harmonizerMap, new Object[]{DataServicesConstants.Payer}));
		regulatoryType.setFeeReceiver((String)dataServicesCalculationTrigger.calculate(DataServicesCalc.premiumPayOrReceiveCalc, dsTrade, null, harmonizerMap, new Object[]{DataServicesConstants.Receive}));
		
		regulatoryType.setFeeUSI(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeIdentifier().getFeeUSIPrefix()),
				XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeIdentifier().getFeeUSIValue())},DataServicesConstants.EMPTY_STRING));

		regulatoryType.getReportingEligibility().addAll(xmlMapperHelper.getReportingEligibilityTypeData(dsTrade, objectFactory));
	
		
		logger.info("Leaving setRegulatoryTypeData() method");

		return regulatoryType;
	}

	protected FeeInfoType getFeeInfoTypeData(TransactionType dsTrade,	ObjectFactory objectFactory) 
	{
		logger.info("Entering getFeeInfoTypeData() method ");
		
		List<com.wellsfargo.regulatory.dataservices.bo.FeeType> feeTypeData = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getFee());
		FeeType feeType=null;
		FeeInfoType feeInfoType = objectFactory.createFeeInfoType();
		
		PartyUsType partyUs = dsTrade.getTrade().getParty().getPartyUs();
		PartyThemType partyThem = dsTrade.getTrade().getParty().getPartyThem();
		String dtccOurParticipantId=XmlMappingUtil.resolveIfNull(()->partyUs.getPartyUsDTCCParticipantID());
		String dtccCntrParticipantId=XmlMappingUtil.resolveIfNull(()->partyThem.getPartyThemDTCCParticipantID());
		
		String leiUs=XmlMappingUtil.concatenateArrayValues(new String[]{partyUs.getPartyInfo().getPrefix(),partyUs.getPartyInfo().getValue()}, DataServicesConstants.COLON);
		String leiCp=XmlMappingUtil.concatenateArrayValues(new String[]{partyThem.getPartyInfo().getPrefix(),partyThem.getPartyInfo().getValue()}, DataServicesConstants.COLON);
		
		if(!XmlMappingUtil.IsListNullOrEmpty(feeTypeData))
		{
			for (com.wellsfargo.regulatory.dataservices.bo.FeeType fee : feeTypeData)
			{
				
				feeType = objectFactory.createFeeType();
				if(fee.getSrcType().contains("Parent"))
				{
				
					feeType.setType(XmlMappingUtil.getElementAtIndex(fee.getSrcType(),1,DataServicesConstants.PERIOD));
				}
				else
				{
					feeType.setType(fee.getSrcType());
				}
				feeType.setAmount(fee.getFeeAmount());
				feeType.setCurrency(fee.getFeeCurrency());
				feeType.setDate(fee.getFeeDate());
				feeType.setPayerLEI((XmlMappingUtil.IsNullOrNone(fee.getSrcPayerDTCCId()) || fee.getSrcType().contains("Parent"))?DataServicesConstants.NONE:(StringUtils.equals(dtccOurParticipantId, fee.getSrcPayerDTCCId())?leiUs:StringUtils.equals(dtccCntrParticipantId, fee.getSrcPayerDTCCId())?leiCp:null));
				feeType.setPayerLEIPrefix((XmlMappingUtil.IsNullOrNone(fee.getSrcPayerDTCCId()) || fee.getSrcType().contains("Parent"))?DataServicesConstants.NONE:(StringUtils.equals(dtccOurParticipantId, fee.getSrcPayerDTCCId())?partyUs.getPartyInfo().getPrefix():StringUtils.equals(dtccCntrParticipantId, fee.getSrcPayerDTCCId())?partyThem.getPartyInfo().getPrefix():null));
				feeType.setPayerLEIValue((XmlMappingUtil.IsNullOrNone(fee.getSrcPayerDTCCId()) || fee.getSrcType().contains("Parent"))?DataServicesConstants.NONE:(StringUtils.equals(dtccOurParticipantId, fee.getSrcPayerDTCCId())?partyUs.getPartyInfo().getValue():StringUtils.equals(dtccCntrParticipantId, fee.getSrcPayerDTCCId())?partyThem.getPartyInfo().getValue():null));
				feeType.setReceiverLEI((XmlMappingUtil.IsNullOrNone(fee.getSrcReceiverDTCCId()) || fee.getSrcType().contains("Parent"))?DataServicesConstants.NONE:(StringUtils.equals(dtccOurParticipantId, fee.getSrcReceiverDTCCId())?leiUs:StringUtils.equals(dtccCntrParticipantId, fee.getSrcReceiverDTCCId())?leiCp:null));
				feeType.setReceiverLEIPrefix((XmlMappingUtil.IsNullOrNone(fee.getSrcReceiverDTCCId()) || fee.getSrcType().contains("Parent"))?DataServicesConstants.NONE:(StringUtils.equals(dtccOurParticipantId, fee.getSrcReceiverDTCCId())?partyUs.getPartyInfo().getPrefix():StringUtils.equals(dtccCntrParticipantId, fee.getSrcReceiverDTCCId())?partyThem.getPartyInfo().getPrefix():null));
				feeType.setReceiverLEIValue((XmlMappingUtil.IsNullOrNone(fee.getSrcReceiverDTCCId()) || fee.getSrcType().contains("Parent"))?DataServicesConstants.NONE:(StringUtils.equals(dtccOurParticipantId, fee.getSrcReceiverDTCCId())?partyUs.getPartyInfo().getValue():StringUtils.equals(dtccCntrParticipantId, fee.getSrcReceiverDTCCId())?partyThem.getPartyInfo().getValue():null));
				feeInfoType.getFee().add(feeType);	
			}
		}
		logger.info("Leaving getFeeInfoTypeData() method ");
		
		return feeInfoType;
	}
	
}
