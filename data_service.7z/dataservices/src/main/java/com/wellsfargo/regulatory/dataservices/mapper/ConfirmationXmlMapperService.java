package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.ConfirmationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ObjectFactory;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.ConfirmType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;



/**
 * @author U236098
 * 
 */
@Component
public class ConfirmationXmlMapperService 
{

	private static Logger logger = Logger.getLogger(ConfirmationXmlMapperService.class.getName());
	protected ObjectFactory objectFactory = null;

	SdrRequest sdrRequest=null;
	public SdrRequest buildXml(ConfirmType confirmType, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering ConfirmationStvToXmlMapperService::mapStvToxml() method");
		try
		{
			objectFactory = new ObjectFactory();
	
			 sdrRequest = objectFactory.createSdrRequest();
			sdrRequest.setSource(DataServicesConstants.CONFIRM_PLATFORM_SCRITTURA);
//			sdrRequest.setAssetClass(uow.getString(Calc.dtccAssetClassCalc));
			sdrRequest.setCreateDateTime(XmlMappingUtil.getGregorianCurrentDate());
	
			sdrRequest.setConfirmation(setConfirmationTypeData(confirmType,harmonizerMap));
	
		} 
		catch(Exception e)
		{
			logger.error("Error while mapping confirm xml to sdrxml "+ e.getClass().getName(), e);
			e.printStackTrace();
		}
		
		logger.info("Leaving ConfirmationStvToXmlMapperService::mapStvToxml() method");
		
		return sdrRequest;
	}
	
	
	protected ConfirmationType setConfirmationTypeData(ConfirmType confirmDataType, Map<String, String> harmonizerMap) {
		
	//	String dtccAssetClass = uow.getString(Calc.dtccAssetClassCalc);
		
		logger.info("Leaving setConfirmationTypeData() method");
		ConfirmationType confirmType=new ObjectFactory().createConfirmationType();
		
		/*if(Constants.ASSET_CLASS_EQUITY.equals(dtccAssetClass))
			confirmType.setTradeId(uow.getString(Stv.OTCProductID));
		else
			confirmType.setTradeId(uow.getString(Stv.TradeId));*/
		confirmType.setTradeId(confirmDataType.getTradeId());
		confirmType.setSecondaryTradeId(confirmDataType.getTradeId());
		confirmType.setTradeVersion(confirmDataType.getTradeVersion());
		if(!XmlMappingUtil.IsNullOrBlank(confirmDataType.getUSIValue()))
		{
			confirmType.setUSI(XmlMappingUtil.concatenateArrayValues(new String[]{confirmDataType.getUSIPrefix(),confirmDataType.getUSIValue()},null));
		}else 
		{
			confirmType.setUSI(XmlMappingUtil.concatenateArrayValues(new String[]{confirmDataType.getUTIPrefix(),confirmDataType.getUTIValue()},null));
		}
		
		confirmType.setConfirmationDateTime(!XmlMappingUtil.IsNullOrBlank(confirmDataType.getConfirmDateTime())?confirmDataType.getConfirmDateTime():confirmDataType.getConfirmSentTimeToCpty());
		/**Set to current date time */
		if(XmlMappingUtil.IsNullOrBlank(confirmType.getConfirmationDateTime()))
			confirmType.setConfirmationDateTime(XmlMappingUtil.getGregorianCurrentDate());
		confirmType.setDocumentId(confirmDataType.getDocId());
		confirmType.setSourceSystem(confirmDataType.getSystem());
		confirmType.setIsPaper(XmlMappingUtil.getFormatedValue(confirmDataType.getPaperFlag(),Boolean.class));
		
		logger.info("Leaving setConfirmationTypeData() method");
		return confirmType;
	}

}
