package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class CalculateMasterDocumentDateCalc implements DataSevicesCalculation {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Override
	public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap, Object[] inputArr)
    {
		XMLGregorianCalendar masterDocumantationDate=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation().getMasterDocumentTranstDate());
		XMLGregorianCalendar legalAgreementDate=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation().getLegalAgreementDate());
		
		XMLGregorianCalendar value = (null != masterDocumantationDate) ? masterDocumantationDate : legalAgreementDate;
		
		return value;
    }
}
