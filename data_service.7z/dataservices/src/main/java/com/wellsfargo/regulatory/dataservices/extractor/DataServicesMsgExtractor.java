package com.wellsfargo.regulatory.dataservices.extractor;

public class DataServicesMsgExtractor {

	
}
