package com.wellsfargo.regulatory.dataservices.calc;



import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;


/****
 * 
 * DataServicesCalculationTrigger is used to trigger the class given as the argument using the arguments as input
 * @author U236098
 *
 */
@Component
public class DataServicesCalculationTrigger {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	
	@Autowired
	private ApplicationContext appContext;
	
	public Object calculate(String fieldCalc, TransactionType transactionType,SdrRequest sdrRequest,Map <String,String> harmonizerMap,Object[] inputParam) {
		
		Object returnValue=null;
		try
		{
			DataSevicesCalculation calcBean = (DataSevicesCalculation)appContext.getBean(fieldCalc);
			logger.debug("Invoking the calculation "+fieldCalc);
			returnValue = calcBean.calculate(transactionType, sdrRequest, harmonizerMap, inputParam);
			
		}catch (Exception e)
		{
			logger.error("Exception in DataServicesCalculationTrigger while triggering the calc :"+fieldCalc +", Exception:"+ExceptionUtils.getFullStackTrace(e));
		}
		
		return returnValue;
	}
}
