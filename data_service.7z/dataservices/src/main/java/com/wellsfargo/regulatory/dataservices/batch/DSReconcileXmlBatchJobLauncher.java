package com.wellsfargo.regulatory.dataservices.batch;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;




public class DSReconcileXmlBatchJobLauncher {

	private Job dsReconcileXmlBatchJob;
	
	private static Logger logger = Logger.getLogger(DSReconcileXmlBatchJobLauncher.class.getName());
	
	@Transformer
	public Message<JobLaunchRequest> launchJob(Message<?> message) throws Exception
	{
		JobLaunchRequest xmlReconJob = null;
		Message<JobLaunchRequest> xmlReconJobLaunch = null;
		
		Date curDate = new Date();
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(curDate);
		cal.add(Calendar.DATE, 1);
		Date nextDay = cal.getTime();
		
		logger.info("DSReconcileXML batch job started with fromDate ("+curDate + ") toDate ("+nextDay +")");
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addDate("fromDate", curDate);
		jobParametersBuilder.addDate("toDate", nextDay);
		
		xmlReconJob = new JobLaunchRequest(dsReconcileXmlBatchJob, jobParametersBuilder.toJobParameters());
		xmlReconJobLaunch = MessageBuilder.withPayload(xmlReconJob).build();
		
		return xmlReconJobLaunch;
	}

	public Job getDsReconcileXmlBatchJob() {
		return dsReconcileXmlBatchJob;
	}

	public void setDsReconcileXmlBatchJob(Job dsReconcileXmlBatchJob) {
		this.dsReconcileXmlBatchJob = dsReconcileXmlBatchJob;
	}
	
	
}
