package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class PostEventTransactionDate implements DataSevicesCalculation{

	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) 
	{
		String retDate=null;
		String eventId=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getEventId());
		 XMLGregorianCalendar tradeDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeDate());
		
		if(!XmlMappingUtil.IsNullOrBlank(eventId))
		{
			  Matcher m = Pattern.compile("(19|20|30)[0-9][0-9][- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])").matcher(eventId);
			  while (m.find()) 
			  {
				  retDate=m.group();
			  }
		}
		
		if(XmlMappingUtil.IsNullOrBlank(retDate))
			retDate=CalendarUtils.xmlGregCalToCustomFormat(tradeDate,null);
		
		return retDate;
	}
	
	

}
