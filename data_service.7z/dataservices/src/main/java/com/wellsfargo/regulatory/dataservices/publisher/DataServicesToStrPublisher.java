package com.wellsfargo.regulatory.dataservices.publisher;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component
public class DataServicesToStrPublisher
{
	private static Logger logger = Logger.getLogger(DataServicesToStrPublisher.class.getName());
	public void publish(Message<?> message) throws Exception
	{
		logger.info("inside DataServicesToStrPublisher:publish method ");

	}

}
