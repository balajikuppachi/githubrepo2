package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.dataservices.bo.ConfirmType;
import com.wellsfargo.regulatory.dataservices.bo.SourceType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;


/**
 * updated - u236098
 * @date 06/01/2015
 * @version 1.0
 */

@Component
public class ProductMapperFactory {

	@Autowired
	private IrFraXmlMapperService irFraXmlMapperService;
	
	@Autowired
	private IrCapFloorXmlMapperService irCapFloorXmlMapperService;
	
	@Autowired
	private IrSwapXmlMapperService irSwapXmlMapperService;
	
	@Autowired
	private IrSwaptionXmlMapperService irSwaptionXmlMapperService;
	
	@Autowired
	private CrExoticXmlMapperService crExoticXmlMapperService;
	
	@Autowired
	private FxSwapXmlMapperService fxSwapXmlMapperService;
	
	@Autowired
	private FxForwardXmlMapperService fxForwardXmlMapperService;
	
	@Autowired
	private FxOptionXmlMapperService fxOptionXmlMapperService;
	
	@Autowired
	private CrSingleNameXmlMapperService crSingleNameXmlMapperService;
	
	@Autowired
	private EqOptionXmlMapperService eqOptionXmlMapperService;
	
	@Autowired
	private EqSwapXmlMapperService eqSwapXmlMapperService;
	
	@Autowired
	private EqVarSwapXmlMapperService eqVarSwapXmlMapperService;
	
	@Autowired
	private EqExoticXmlMapperService eqExoticXmlMapperService;
	
	@Autowired	
	private EqForwardXmlMapperService eqForwardXmlMapperService;
	
	@Autowired
	private IrTreasuryLockXmlMapperService irTreasuryLockXmlMapperService;
	
	@Autowired
	private IrStruturedProductXmlMapperService irStruturedProductXmlMapperService;
	
	
	@Autowired
	private IrStruturedProductSwapXmlMapperService irStruturedProductSwapXmlMapperService;
	
	@Autowired
	private IrExoticProductXmlMapperService irExoticProductXmlMapperService;
	
	
	@Autowired
	private	ConfirmationXmlMapperService confirmationXmlMapperService;
	
	@Autowired
	private IrStruturedProductCapFloorXmlMapperService irStruturedProductCapFloorXmlMapperService;
	
	@Autowired
	XmlMapperHelper xmlMapperHelper; 
	
	private enum SwapProducts {Swap,CancellableSwap,NDS,XCCySwap,CappedSwap}
	
	private enum IrStructuredProducts {FPA,StructuredExotic}
	
	private enum IrStructuredExoticSubProduct1 {CRA_LIBOR}
	
	private enum IrStructuredExoticSubProduct2 {NONE}
	
	private enum IrStructuredCapFloorSubProducts {Corridor,Arrear}
	
	private enum CrExoticProducts {CDSIndexOption}
	
	private enum IrExoticProducts {BGSwap, BGXCCySwap, FPA, MMDRateLock,StructuredProduct}
	
	private enum CrSingleNameSubType {ABSCDO,CDSABSIndex,CDSIndex,CDSIndexTranche,CDSNthLoss,CDSStructProd,CreditDefaultSwap,CreditDefaultSwapLoan,Revolver,RiskParticipationSwap,StructuredProduct,TRSBasketABSAtlas,TRSSingleName}
	
	private static Logger logger = Logger.getLogger(ProductMapperFactory.class.getName());
	
	public GenericXmlMapperService getMapper(SourceType sourceType,	Map<String, String> harmonizerMap)
	{
		
		GenericXmlMapperService returnMapper = null;
		
		String assetClass = xmlMapperHelper.getHarmonizedValue(harmonizerMap, DataServicesConstants.HRMN_ASSET_CLASS);
		String srcProductType = sourceType.getProductType();
		String srcSubProductType =sourceType.getProductSubType();
		
		
		
		try 
		{
			/*if(StringUtils.contains(scritturaPlatform, DataServicesConstants.CONFIRM_PLATFORM_SCRITTURA))
			{
				return confirmationXmlMapperService.buildXml(uow);
			}*/
			
			if(DataServicesConstants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
			{
				if(DataServicesConstants.SRC_PRODUCT_TYPE_FRA.equals(srcProductType))
				{
					logger.info("Calling FraXmlMapperService :: buildXml() method");
					return	irFraXmlMapperService;
				}
				
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcProductType, SwapProducts.class)))
				{
					logger.info("Calling SwapXmlMapperService :: buildXml() method");
					return	irSwapXmlMapperService;
				}
				
				if(DataServicesConstants.SRC_PRODUCT_TYPE_CAPFLOOR.equals(srcProductType) || DataServicesConstants.SRC_PRODUCT_TYPE_SPREADCAPFLOORCMS.equals(srcProductType))
				{
					logger.info("Calling CapFloorXmlMapperService :: buildXml() method");
					return irCapFloorXmlMapperService;
				}
				
				if(DataServicesConstants.SRC_PRODUCT_TYPE_SWAPTION.equals(srcProductType))
				{
					logger.info("Calling SwaptionXmlMapperService :: buildXml() method");
					return	irSwaptionXmlMapperService;
				}
				
				if(DataServicesConstants.SRC_PRODUCT_TYPE_TREASURY_LOCK.equals(srcProductType))
				{
					logger.info("Calling IrTreasuryLockXmlMapperService :: buildXml() method");
					return	irTreasuryLockXmlMapperService;
				}
				if( (!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcProductType, IrStructuredProducts.class)) && !XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcSubProductType, IrStructuredExoticSubProduct2.class)))
						
						|| DataServicesConstants.SRC_PRODUCT_TYPE_STRUCTURED_PRODUCT.equalsIgnoreCase(srcSubProductType))
				{
					logger.info("Calling IrStruturedProductXmlMapperService :: buildXml() method");
					return	irStruturedProductXmlMapperService;
				}
				
				if(DataServicesConstants.SRC_PRODUCT_TYPE_STRUCTURED_MUNI.equalsIgnoreCase(srcProductType) && 
						!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcSubProductType, IrStructuredCapFloorSubProducts.class)) )
				{
					logger.info("Calling IrStruturedProductCapFloorXmlMapperService :: buildXml() method");
					return	irStruturedProductCapFloorXmlMapperService;
				}
				
				
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcProductType, IrStructuredProducts.class)) 
								&& !XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcSubProductType, IrStructuredExoticSubProduct1.class))) 
				{
					logger.info("Calling IrStruturedProductSwapXmlMapperService :: buildXml() method");
					return	irStruturedProductSwapXmlMapperService;
				}
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcProductType, IrExoticProducts.class))){
					logger.info("Calling IrExoticStvToXmlMapperService :: buildXml() method");
					return	irExoticProductXmlMapperService;
				}
				
			}
			
			if(DataServicesConstants.ASSET_CLASS_FOREX.equals(assetClass))
			{
				if(DataServicesConstants.SRC_PRODUCT_TYPE_FXSWAP.equals(srcProductType))
				{
					logger.info("Calling FxSwapXmlMapperService :: buildXml() method");
					return	fxSwapXmlMapperService;
				}
				
				if(DataServicesConstants.SRC_PRODUCT_TYPE_FXFORWARD.equals(srcProductType))
				{
					logger.info("Calling FxForwardXmlMapperService :: buildXml() method");
					return	fxForwardXmlMapperService;
				}
				
				if(DataServicesConstants.SRC_PRODUCT_TYPE_FXOPTION.equals(srcProductType))
				{
					logger.info("Calling FxOptionXmlMapperService :: buildXml() method");
					return	fxOptionXmlMapperService;
				}
			}
			
			if(DataServicesConstants.ASSET_CLASS_CREDIT.equals(assetClass))
			{
				
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcProductType, CrExoticProducts.class)))
				{
					logger.info("Calling CrExoticXmlMapperService :: buildXml() method");
					return	crExoticXmlMapperService;
				}
				
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.getEnumString(srcProductType, CrSingleNameSubType.class)))
				{
					logger.info("Calling SingleNameXmlMapperService :: buildXml() method");
					return	crSingleNameXmlMapperService;
				}
				
			
			}
			
			if(DataServicesConstants.ASSET_CLASS_EQUITY.equals(assetClass))
			{
				
				
				if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITY_SWAP.equalsIgnoreCase(srcProductType) || DataServicesConstants.SRC_PRODUCT_TYPE_GENERIC.equalsIgnoreCase(srcProductType))
				{
					if (DataServicesConstants.SRC_SUB_PRODUCT_TYPE_VARIANCE_SWAP.equalsIgnoreCase(srcSubProductType))
					{
						logger.info("Calling EqVarSwapXmlMapperService :: buildXml() method");
						return eqVarSwapXmlMapperService;
					}
					
					if (DataServicesConstants.SRC_SUB_PRODUCT_TYPE_EXOTIC.equalsIgnoreCase(srcSubProductType))
					{
						logger.info("Calling EqExoticXmlMapperService :: buildXml() method");
						return eqExoticXmlMapperService;
					}					
					
					logger.info("Calling EqSwapXmlMapperService :: buildXml() method");
					return eqSwapXmlMapperService;
				}	

				if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equalsIgnoreCase(srcProductType))
				{
					logger.info("Calling EqOptionXmlMapperService :: buildXml() method");
					return eqOptionXmlMapperService;
				}	
				if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITY_FORWARD.equalsIgnoreCase(srcProductType))
				{
					return eqForwardXmlMapperService;
				}	
				
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			logger.error("Error while mapping stv to xml "+ e.getClass().getName(), e);
		}
		
		
		return returnMapper;
	}

	public ConfirmationXmlMapperService getMapper(ConfirmType confirmTrade,	Map<String, String> harmonizerMap) 
	{
		return confirmationXmlMapperService;
	}

	
}
