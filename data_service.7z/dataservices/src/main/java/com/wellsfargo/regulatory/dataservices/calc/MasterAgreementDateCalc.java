package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.DocumentationType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.mapper.XmlMapperHelper;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class MasterAgreementDateCalc implements DataSevicesCalculation
{
	
	@Autowired
	protected XmlMapperHelper xmlMapperHelper;
	
	@Override
    public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap, Object[] inputArr)
    {

		XMLGregorianCalendar returnDate=null;
		String srcAssetClass= xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
		if(Constants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(srcAssetClass))
		{
		DocumentationType documentationTypeData=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation());
		
		XMLGregorianCalendar terminationDate = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeLifeCycle().getTerminationDate());
		XMLGregorianCalendar amendmentDate =  XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeLifeCycle().getAmendmentDate());
		XMLGregorianCalendar novationDate =  XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeLifeCycle().getNovationDate());
		
		if(!XmlMappingUtil.IsNullOrBlank(documentationTypeData) && !XmlMappingUtil.IsNullOrBlank(documentationTypeData.getAgreementDate()))
		{
			returnDate=documentationTypeData.getAgreementDate();
		}else
		if(!XmlMappingUtil.IsNullOrBlank(terminationDate))
		{
			returnDate=terminationDate;
		}else if(!XmlMappingUtil.IsNullOrBlank(amendmentDate))
		{
			returnDate=amendmentDate;
		}else if(!XmlMappingUtil.IsNullOrBlank(novationDate))
		{
			returnDate=novationDate;
		}
		
		}
		
		if(Constants.CREDIT.equalsIgnoreCase(srcAssetClass)){
			XMLGregorianCalendar legalAgreementDate=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation().getLegalAgreementDate());
			XMLGregorianCalendar dtccMasterAgreementDate=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation().getAgreementDate());
			returnDate=null!=dtccMasterAgreementDate?dtccMasterAgreementDate:legalAgreementDate;
			
		}
	   
	    return returnDate;
    }

}
