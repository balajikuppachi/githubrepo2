package com.wellsfargo.regulatory.dataservices.service;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;
import com.wellsfargo.regulatory.dataservices.bo.FeeType;
import com.wellsfargo.regulatory.dataservices.bo.WfsMessage;
import com.wellsfargo.regulatory.dataservices.calc.DataServicesCalculationTrigger;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class RegRepXmlBufferGeneratorService {
	
	

	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	
	private JAXBContext jaxbContext = null;
	private  Marshaller jaxbMarshaller = null;
	

	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;
	
	
	@PostConstruct
	public void initialize()
	{
		try {
			
			jaxbContext = JAXBContext.newInstance(SdrRequest.class);
			jaxbMarshaller = jaxbContext.createMarshaller();
		} catch (JAXBException e) {
			 logger.warn("#### Error while creating XML marshaller for RegRepXml "+ e.getClass().getName(), e.fillInStackTrace());
		}
		
	}
	
	public Message<?> generate(Message<?> message)
	{
			DataServicesContext dsContext=(DataServicesContext) message.getPayload();
			List<String> toBePublishedList = new ArrayList<String>();
			SdrRequest sdrRequest = dsContext.getSdrRequest();
		
			String productType = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeDetail().getProduct().getProductType());
			String productSubType = XmlMappingUtil.resolveIfNull(()->sdrRequest.getTrade().getTradeDetail().getProduct().getProductSubType());
			String assetClass = sdrRequest.getAssetClass();
			boolean isNovationTrade = (boolean) dataServicesCalculationTrigger.calculate(DataServicesCalc.novationTradeCalc, null, sdrRequest, dsContext.getTradeContext().getHarmonizedMap(), null);
			
			 if(!XmlMappingUtil.IsNullOrBlank(assetClass) && !XmlMappingUtil.IsNullOrBlank(productType) && !XmlMappingUtil.IsNullOrBlank(productSubType) && DataServicesConstants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)
			  && DataServicesConstants.SRC_PRODUCT_TYPE_FXSWAP.equalsIgnoreCase(productType) && DataServicesConstants.Standard.equalsIgnoreCase(productSubType)) {
					toBePublishedList.addAll(createPayloadsForFX(sdrRequest));
				}
			
			 else if(isNovationTrade) 
			{
				 toBePublishedList.addAll(createPayloadsForNovation(sdrRequest, dsContext));
			}
			else 
			{
				toBePublishedList.add(buildPayLoad(sdrRequest));
			}
			 
		
		dsContext.getPayloadContext().setRegRepXmlPayloadList(toBePublishedList);
		return 	message;
	}

	
	private List<String> createPayloadsForNovation(SdrRequest sdrRequest, DataServicesContext dsContext) {
		// TODO Auto-generated method stub
			List<String> regRepXmlPayloadForNovation = new ArrayList<String>();
	
			
			WfsMessage dsTrade =  dsContext.getTradeContext().getDsTrade();
			String payLoadNonFee = buildPayLoad(sdrRequest);
			regRepXmlPayloadForNovation.add(payLoadNonFee);
			
			//create trade id and secondaryTradeid
			sdrRequest.getTrade().getTradeHeader().setTradeId(sdrRequest.getTrade().getTradeHeader().getTradeId() + "F");
			sdrRequest.getTrade().getTradeHeader().setSecondaryTradeId(sdrRequest.getTrade().getTradeHeader().getSecondaryTradeId() + "F");
			
			//create usi related changes
			String usiThirdParty = XmlMappingUtil.resolveIfNull(()->dsTrade.getTransaction().getTrade().getParty().getThirdParty().getValue());
			String usiThirdPartyPrefix=XmlMappingUtil.resolveIfNull(()->dsTrade.getTransaction().getTrade().getParty().getThirdParty().getPrefix());
			if(!XmlMappingUtil.IsNullOrBlank(usiThirdPartyPrefix) && !XmlMappingUtil.IsNullOrBlank(usiThirdParty))
			{
			sdrRequest.getTrade().getTradeHeader().setCounterpartyLEI(XmlMappingUtil.concatenateArrayValues(new String[]{usiThirdPartyPrefix,usiThirdParty},":"));
			}
			sdrRequest.getTrade().getTradeHeader().setCounterpartyLEIValue(usiThirdParty);
			sdrRequest.getTrade().getTradeHeader().getLifeCycle().getNovation().setRemainingPartyLEI(usiThirdParty);
			if(!XmlMappingUtil.IsNullOrBlank(usiThirdPartyPrefix) && !XmlMappingUtil.IsNullOrBlank(usiThirdParty))
			{
			sdrRequest.getTrade().getTradeDetail().getTradeParties().getParty().get(0).setLEI(XmlMappingUtil.concatenateArrayValues(new String[]{usiThirdPartyPrefix,usiThirdParty},":"));
			}
			sdrRequest.getTrade().getTradeDetail().getTradeParties().getParty().get(0).setLEIValue(usiThirdParty);
			sdrRequest.getTrade().getTradeDetail().getProduct().getProductKeys().setUSI(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.resolveIfNull(()->dsTrade.getTransaction().getTrade().getTradeHeader().getTradeIdentifier().getFeeUSIPrefix()),
					XmlMappingUtil.resolveIfNull(()->dsTrade.getTransaction().getTrade().getTradeHeader().getTradeIdentifier().getFeeUSIValue())},DataServicesConstants.EMPTY_STRING));
			
			getFeeInfoTypeData(sdrRequest,dsTrade);
			
			//find party info to modify
			//List<TradePartyType> partyTypes = sdrRequest.getTrade().getTradeDetail().getTradeParties().getParty();
			
			String payLoadFee = buildPayLoad(sdrRequest);
			regRepXmlPayloadForNovation.add(payLoadFee);
	
		
		return regRepXmlPayloadForNovation;
	}

	private List<String> createPayloadsForFX(SdrRequest sdrRequest) {
		
		List<String> payLoadList = new ArrayList<String>();
		ProductType productTypeNL = sdrRequest.getTrade().getTradeDetail().getProduct();
		List<LegType> legs = productTypeNL.getLeg();
		LegType nearLeg = null;
		LegType farLeg = null;
		StringBuilder usiBuilder = null;
		
		String originalTradeId = sdrRequest.getTrade().getTradeHeader().getTradeId();
		
		if(!XmlMappingUtil.IsListNullOrEmpty(legs)) {
			farLeg = legs.get(0);
			if(legs.size() == 2) {
				 nearLeg = legs.get(1);
			}
		}
		
		String usiNL = productTypeNL.getProductKeys().getUSI();
		String usiPrevNL = productTypeNL.getProductKeys().getPrevUSI();
		String utiNL = productTypeNL.getProductKeys().getUTI();
		
		if(!XmlMappingUtil.IsNullOrBlank(usiNL) && usiNL.length() > 20) {
			usiBuilder = new StringBuilder(usiNL);
			usiBuilder.setCharAt(15, 'N');
			productTypeNL.getProductKeys().setUSI(usiBuilder.toString());
		}
		if(!XmlMappingUtil.IsNullOrBlank(usiPrevNL) && usiPrevNL.length() > 20) {
			usiBuilder = new StringBuilder(usiPrevNL);
			usiBuilder.setCharAt(15, 'N');
			productTypeNL.getProductKeys().setPrevUSI(usiBuilder.toString());
		}
		
		if(!XmlMappingUtil.IsNullOrBlank(utiNL) && utiNL.length() > 20) {
			usiBuilder = new StringBuilder(utiNL);
			usiBuilder.setCharAt(15, 'N');
			productTypeNL.getProductKeys().setUTI(usiBuilder.toString());
		}
		
		StringBuilder tradeIDBuilder = new StringBuilder(originalTradeId);
		String tradeIDNL = tradeIDBuilder.append("NL").toString();
		
		sdrRequest.getTrade().getTradeHeader().setTradeId(tradeIDNL);
		sdrRequest.getTrade().getTradeHeader().setSecondaryTradeId(tradeIDNL);
		
		String payloadNL = buildPayLoad(sdrRequest);
		
		if(!XmlMappingUtil.IsNullOrBlank(payloadNL)) {
			payLoadList.add(payloadNL);
		}
		
		
		//for far leg
		
		ProductType productTypeFL = sdrRequest.getTrade().getTradeDetail().getProduct();
		
		String usiFL = productTypeFL.getProductKeys().getUSI();
		String usiPrevFL = productTypeFL.getProductKeys().getPrevUSI();
		String utiFL = productTypeFL.getProductKeys().getUTI();
		
		if(!XmlMappingUtil.IsNullOrBlank(usiFL) && usiFL.length() > 20) {
			usiBuilder = new StringBuilder(usiFL);
			usiBuilder.setCharAt(15, 'F');
			productTypeFL.getProductKeys().setUSI(usiBuilder.toString());
		}
		if(!XmlMappingUtil.IsNullOrBlank(usiPrevFL) && usiPrevFL.length() > 20) {
			usiBuilder = new StringBuilder(usiPrevFL);
			usiBuilder.setCharAt(15, 'F');
			productTypeFL.getProductKeys().setPrevUSI(usiBuilder.toString());
		}
		
		if(!XmlMappingUtil.IsNullOrBlank(utiFL) && utiFL.length() > 20) {
			usiBuilder = new StringBuilder(utiFL);
			usiBuilder.setCharAt(15, 'F');
			productTypeFL.getProductKeys().setUTI(usiBuilder.toString());
		}
		
		StringBuilder tradeIDBuilderFL = new StringBuilder(originalTradeId);
		String tradeIDFL = tradeIDBuilderFL.append("FL").toString();
		
		sdrRequest.getTrade().getTradeHeader().setTradeId(tradeIDFL);
		sdrRequest.getTrade().getTradeHeader().setSecondaryTradeId(tradeIDFL);
		
		String payloadFL = buildPayLoad(sdrRequest);
		
		if(!XmlMappingUtil.IsNullOrBlank(payloadFL)) {
			payLoadList.add(payloadFL);
		}
		
		return payLoadList;
	}

	private String buildPayLoad(SdrRequest sdrRequest) {
		
		String payload = "";
		StringWriter writer = new StringWriter();
		try {
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			jaxbMarshaller.marshal(sdrRequest, writer);
			payload = writer.toString();
			logger.warn("################# Payload for FX trade" + payload);
		}
		catch(JAXBException e ) {
			
			 logger.warn("#### Error while generating XML for REGREP TradeID :"+ sdrRequest.getTrade().getTradeHeader().getTradeId()+",TradeVersion :"+sdrRequest.getTrade().getTradeHeader().getTradeVersion());
			 logger.warn("#### Error while generating XML for REGREP "+ e.getClass().getName(), e.fillInStackTrace());
				  
			
		}
		
		return payload;
	}
	
	public void getFeeInfoTypeData(SdrRequest sdrRequest, WfsMessage dsTrade) {

		String dtccOurParticipantId=XmlMappingUtil.resolveIfNull(()->dsTrade.getTransaction().getTrade().getParty().getPartyUs().getPartyUsDTCCParticipantID());
		String dtccCntrParticipantId=XmlMappingUtil.resolveIfNull(()->dsTrade.getTransaction().getTrade().getParty().getPartyThem().getPartyThemDTCCParticipantID());
		String leiUs=XmlMappingUtil.concatenateArrayValues(new String[]{dsTrade.getTransaction().getTrade().getParty().getPartyUs().getPartyInfo().getPrefix(),dsTrade.getTransaction().getTrade().getParty().getPartyUs().getPartyInfo().getValue()},":");
		String leiCp=XmlMappingUtil.concatenateArrayValues(new String[]{dsTrade.getTransaction().getTrade().getParty().getThirdParty().getPrefix(),dsTrade.getTransaction().getTrade().getParty().getThirdParty().getValue()},":");
		String leiCpPrefix=XmlMappingUtil.getElementAtIndex(leiCp, 0, Constants.COLON);
		String leiCpValue=XmlMappingUtil.getElementAtIndex(leiCp, 1, Constants.COLON);
		String leiUsPrefix=XmlMappingUtil.getElementAtIndex(leiUs, 0, Constants.COLON);
		String leiUsValue=XmlMappingUtil.getElementAtIndex(leiUs, 1, Constants.COLON);
		List <FeeType> listObj = XmlMappingUtil.resolveIfNull(()->dsTrade.getTransaction().getTrade().getTradeHeader().getFee());
		
		
		if (!XmlMappingUtil.IsListNullOrEmpty(listObj))
			
			for (int i = 0; i < listObj.size(); i++) 
			{
				String dtccFeePayer=listObj.get(i).getSrcPayerDTCCId();
				String dtccFeeReceiver=listObj.get(i).getSrcReceiverDTCCId();
				if(XmlMappingUtil.IsNullOrNone(dtccFeePayer))
					{
					sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setPayerLEI(Constants.NONE);
					sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setPayerLEIPrefix(Constants.NONE);
					sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setPayerLEIValue(Constants.NONE);
					}
					else {
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setPayerLEI(StringUtils.equals(dtccOurParticipantId, dtccFeePayer)?leiUs:StringUtils.equals(dtccCntrParticipantId, dtccFeePayer)?leiCp:null);
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setPayerLEIPrefix(StringUtils.equals(dtccOurParticipantId, dtccFeePayer)?leiUsPrefix:StringUtils.equals(dtccCntrParticipantId, dtccFeePayer)?leiCpPrefix:null);
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setPayerLEIValue(StringUtils.equals(dtccOurParticipantId, dtccFeePayer)?leiUsValue:StringUtils.equals(dtccCntrParticipantId, dtccFeePayer)?leiCpValue:null);
					}
					if(XmlMappingUtil.IsNullOrNone(dtccFeeReceiver)) 
					{
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setReceiverLEI(Constants.NONE);
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setReceiverLEIPrefix(Constants.NONE);
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setReceiverLEIValue(Constants.NONE);
					}
					else
					{
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setReceiverLEI(StringUtils.equals(dtccOurParticipantId, dtccFeeReceiver)?leiUs:StringUtils.equals(dtccCntrParticipantId, dtccFeeReceiver)?leiCp:null);
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setReceiverLEIPrefix(StringUtils.equals(dtccOurParticipantId, dtccFeeReceiver)?leiUsPrefix:StringUtils.equals(dtccCntrParticipantId, dtccFeeReceiver)?leiCpPrefix:null);
						sdrRequest.getTrade().getTradeDetail().getFeeInfo().getFee().get(i).setReceiverLEIValue(StringUtils.equals(dtccOurParticipantId, dtccFeeReceiver)?leiUsValue:StringUtils.equals(dtccCntrParticipantId, dtccFeeReceiver)?leiCpValue:null);
					}
			}
	
	}
}
