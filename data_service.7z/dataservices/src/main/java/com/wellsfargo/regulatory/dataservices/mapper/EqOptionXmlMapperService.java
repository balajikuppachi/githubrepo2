package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityUnderlyingAssetType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeInfoType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ObjectFactory;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.OptionTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProcessedByEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.dataservices.bo.BasketConstituent;
import com.wellsfargo.regulatory.dataservices.bo.EQOptionType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.calc.DataServicesCalculationTrigger;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;



/**
 * @author Jayshri Vispute
 * @date 06/01/2015
 * @version 1.0
 */

@Component
public class EqOptionXmlMapperService extends EqSwapXmlMapperService {
	
	private static Logger logger = Logger.getLogger(EqOptionXmlMapperService.class.getName());
	
	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;
	

	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
		productType.setExerciseProvision(getExerciseProvisionTypeData(dsTrade,harmonizerMap));
		
		productType.getLeg().clear();
		productType.getLeg().addAll(setLegTypeData(dsTrade,productType,harmonizerMap));
		
		return productType;
	}
		
	protected List<LegType> setLegTypeData( TransactionType dsTrade,ProductType productType, Map<String, String> harmonizerMap) 
		{
			logger.info("Entering EqOptionXmlMapperService --> setLegTypeData() method");

			List<LegType> legTypeList = new ArrayList<LegType>();
			LegType legType = objectFactory.createLegType();	
			legType.setLegId((short) 1);
			
			EQOptionType eqOption = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption());
			
			
			if ( null != eqOption)
			{
				legType.setOptionType(XmlMappingUtil.getEnumString(eqOption.getOptionType(), OptionTypeEnum.class));
				legType.setOptionStrike(XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.eqStrikePriceCalc, dsTrade, null, null, null), BigDecimal.class));
				legType.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()->eqOption.getNotional().getCurrency()));
				legType.setOptionStrikeCurrency(XmlMappingUtil.resolveIfNull(()->eqOption.getNotional().getCurrency()));
				legType.setStartDate(XmlMappingUtil.resolveIfNull(()->eqOption.getEquityEffectiveDate()));
				
				legType.setEndDate(XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.eqEndDateCalc, dsTrade, null, null, null), XMLGregorianCalendar.class));
				
				/*legType.setEndDate(!XmlMappingUtil.IsNullOrBlank(eqOption.getFeature().getAsian())?XmlMappingUtil.resolveIfNull(()->eqOption.getFeature().getAsian().getAveragingPeriod().getSchedule().get(0).getEndDate().getUnadjustedDate().get(0))
						:XmlMappingUtil.resolveIfNull(()->eqOption.getFeature().getBarrier().getBarrier().getSchedule().get(0).getEndDate().getUnadjustedDate().get(0)));*/
				legType.setNotional(XmlMappingUtil.resolveIfNull(()->eqOption.getNotional().getAmount()));
				
				legType.setSettlementType(XmlMappingUtil.getEnumString(()->eqOption.getEquityExercise().getSettlementType(),SettlementTypeEnum.class));
			}
			
			legType.setPayReceive(PayReceiveEnum.PAY);
			legType.setFixedFloat(FixedFloatEnum.FLOAT);

			legTypeList.add(legType);
			logger.info("Leaving EqOptionXmlMapperService --> setLegTypeData() method");

			return legTypeList;
		}
		
		private ExerciseProvisionType getExerciseProvisionTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) {
			
			ExerciseProvisionType exerciseProvisionType = objectFactory.createExerciseProvisionType();
			
			String exerciseStyle = dsTrade.getTrade().getProduct().getEquity().getEquityOption().getEquityExercise().getExerciseStyle();
			
			if (DataServicesConstants.AMERICAN_EXERCISE.equals(exerciseStyle))
			{
				exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption().getEquityExercise().
						getEquityAmericanExercise().getExpirationDate().getAdjustableDate().getUnadjustedDate().get(0)));
			}
			else if (DataServicesConstants.EUROPEAN_EXERCISE.equals(exerciseStyle))
			{
				exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption().getEquityExercise().
						getEquityEuropeanExercise().getExpirationDate().getAdjustableDate().getUnadjustedDate().get(0)));
			}
			exerciseProvisionType.setExerciseType(XmlMappingUtil.getEnumString(exerciseStyle, ExerciseTypeEnum.class));
			return exerciseProvisionType;
			
		}
		
		protected EquityTermsType getEquityTermsData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
		{
			
			logger.info("Entering EqOptionXmlMapperService --> getEquityTermsData() method");

			EquityTermsType equityTermsType = objectFactory.createEquityTermsType();
			//change as per new mapping
			equityTermsType.setEmbeddedOption(ConversionUtils.booleanFromBoolean(XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getProduct().getEmbeddedOption(),Boolean.class))); //Stv.EmbeddedOptionOnSwap
			
			if(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getRegulatory().getNonstandardFlag()) != null)
				equityTermsType.setNonStandardFlag(XmlMappingUtil.getFormatedValue(dsTrade.getTrade().getTradeHeader().getTradeAttributes().getRegulatory().getNonstandardFlag(), Boolean.class)); //Stv.NonStandardFlag
			
			equityTermsType.getUnderlyingAsset().addAll(setUnderlyingAssetData(dsTrade));
			
			logger.info("Leaving EqOptionXmlMapperService --> getEquityTermsData() method");
			
			return equityTermsType;
		}
		
		private List<EquityUnderlyingAssetType> setUnderlyingAssetData(TransactionType dsTrade) 
		{
			logger.info("Entering EqOptionXmlMapperService --> setUnderlyingAssetData() method");

			EquityUnderlyingAssetType equityUnderlyingAssetType = objectFactory.createEquityUnderlyingAssetType();
			List<EquityUnderlyingAssetType> listEquityUnderlyingAssetType=new ArrayList<EquityUnderlyingAssetType>();
			EQOptionType eqOption = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption());
			String subProductType=dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType();
			String instrumentIdType=null;
			String instrumentId=null;
			String exchangeId=null;
			if(subProductType.contains("Share"))
			{
				instrumentIdType=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getEquity().getInstrument().getInstrumentType());
				instrumentId=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getEquity().getInstrument().getInstrumentId());
				exchangeId=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getEquity().getExchangeId());
			}
			else if(subProductType.contains("Basket"))
			{
				instrumentIdType=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getGeneric().getInstrument().getInstrumentType());
				instrumentId=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getGeneric().getInstrument().getInstrumentId());
				exchangeId=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getGeneric().getExchangeId());
			}
			else
			{
				instrumentIdType=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getIndex().getInstrument().getInstrumentType());
				instrumentId=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getIndex().getInstrument().getInstrumentId());
				exchangeId=XmlMappingUtil.resolveIfNull(()->eqOption.getUnderlyer().getBasket().getBasketConstituent().get(0).getIndex().getExchangeId());
			}
			
			if (null != eqOption && null != instrumentIdType)
			{
				if(instrumentIdType.equalsIgnoreCase(DataServicesConstants.Index) 
						|| instrumentIdType.equalsIgnoreCase(DataServicesConstants.Share)||instrumentIdType.equalsIgnoreCase("Generic"))
				{
				equityUnderlyingAssetType.setInstrumentIdType("RIC");
				}
				else if(instrumentIdType.equalsIgnoreCase(DataServicesConstants.Basket))
				{
					equityUnderlyingAssetType.setInstrumentIdType(instrumentIdType.substring(0,1).toUpperCase()+instrumentIdType.substring(1).toLowerCase());
				}
				else
				{
					equityUnderlyingAssetType.setInstrumentId(instrumentIdType);
				}
				equityUnderlyingAssetType.setInstrumentId(instrumentId);
				
				equityUnderlyingAssetType.setNumberOfUnits(XmlMappingUtil.resolveIfNull(()->eqOption.getNumberOfOptions()));
				equityUnderlyingAssetType.setNotional(XmlMappingUtil.resolveIfNull(()->eqOption.getNotional().getAmount()));
				equityUnderlyingAssetType.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->eqOption.getNotional().getCurrency()));
				
			}
			
			listEquityUnderlyingAssetType.add(equityUnderlyingAssetType);
		
			logger.info("Leaving EqOptionXmlMapperService --> setUnderlyingAssetData() method");

			return listEquityUnderlyingAssetType;
		}
		
		protected LifeCycleType setLifeCycleEventData(TransactionType dsTrade,Map<String, String> harmonizerMap,TradeHeaderType tradeHeaderType) 
		{
			LifeCycleType lifeCycle = tradeHeaderType.getLifeCycle();
			
			EQOptionType eqOption = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption());
			
			lifeCycle.setEventEffectiveDate(XmlMappingUtil.resolveIfNull(()->eqOption.getEquityEffectiveDate()));
			//lifeCycle.setEventType(dsTrade.getTrade().getTradeHeader().getTradeLifeCycle().getLifeCycleEvent());
			lifeCycle.setEventType(dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getLifeCycleEvent());
			
			return lifeCycle;
		}

		protected FeeInfoType getFeeInfoTypeData(TransactionType dsTrade,	ObjectFactory objectFactory) 
		{
			logger.info("Entering EqOptionXmlMapperService -->  getFeeInfoTypeData() method ");
			
			FeeType feeType = objectFactory.createFeeType();
			FeeInfoType feeInfoType = objectFactory.createFeeInfoType();
			feeType.setType(DataServicesConstants.FeeType_Premium);
			feeType.setAmount(xmlMapperHelper.getFormattedAmount(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption().getEquityPremium().getPremiumAmount())).abs());
			feeType.setCurrency(getEqOptionCurrency(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption().getUnderlyer().getBasket().getBasketConstituent())));
			feeType.setDate(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityOption().getEquityExercise().getSettlementDate().getUnadjustedDate().get(0)));
			feeInfoType.getFee().add(feeType);
			
			logger.info("Leaving EqOptionXmlMapperService -->  getFeeInfoTypeData() method ");
			
			return feeInfoType;
		}
		
		private String getEqOptionCurrency(List<BasketConstituent> basketConstituents) {
			
			String currency = null;
			
			if(!XmlMappingUtil.IsListNullOrEmpty(basketConstituents)){
				
				for(BasketConstituent basketConstituent :basketConstituents){
					
					if(XmlMappingUtil.resolveIfNull(()-> basketConstituent.getGeneric().getCurrency()) != null){
						currency = basketConstituent.getGeneric().getCurrency();
						break;
					}
					
					if(XmlMappingUtil.resolveIfNull(()-> basketConstituent.getEquity().getCurrency()) != null){
						currency = basketConstituent.getEquity().getCurrency();
						break;
					}
					
					if(XmlMappingUtil.resolveIfNull(()-> basketConstituent.getIndex().getCurrency()) != null){
						currency = basketConstituent.getIndex().getCurrency();
						break;
					}
				}
			}
			return currency;
		}
		
}
