package com.wellsfargo.regulatory.dataservices.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;
import com.wellsfargo.regulatory.persister.dao.RegRepCollateralAgreementsDao;
import com.wellsfargo.regulatory.persister.dto.RegRepCollateralAgreements;




@Component
public class CollateralDataService {


	private Map<String, List<RegRepCollateralAgreements>>  allAgreementsMap = new HashMap<String, List<RegRepCollateralAgreements>>();
	private Map<String, List<RegRepCollateralAgreements>>  cidLegalKeyAgreementMap = new HashMap<String, List<RegRepCollateralAgreements>>();
	private Map<String, List<RegRepCollateralAgreements>>  businessAccountAgreementMap = new HashMap<String, List<RegRepCollateralAgreements>>();
	

	@Autowired
	private CollateralAgreementsExtnDao agreementExtnDAO;
	@Autowired
	RegRepCollateralAgreementsDao regRepCollateralAgreementsDaoImpl;
	
	@PostConstruct
	public void initialize() {
		
		List<RegRepCollateralAgreements> agreementList = regRepCollateralAgreementsDaoImpl.findAll();
		if(!XmlMappingUtil.IsNullOrBlank(agreementList))
		{
			List<RegRepCollateralAgreements> caList = null;
			List<RegRepCollateralAgreements> cidLegalList = null;
			
			for (RegRepCollateralAgreements agreements : agreementList) {
				if (!XmlMappingUtil.IsNullOrBlank(agreements.getId().getShortname())) {
					caList = (List<RegRepCollateralAgreements>) allAgreementsMap.get(agreements.getId().getShortname());
					if (caList == null) {
						caList = new ArrayList<RegRepCollateralAgreements>();
						allAgreementsMap.put(agreements.getId().getShortname(), caList);
					}
					caList.add(agreements);
				}
				
				if (!XmlMappingUtil.IsNullOrBlank(agreements.getId().getCidLegal())) {
					cidLegalList = (List<RegRepCollateralAgreements>) cidLegalKeyAgreementMap.get(agreements.getId().getCidLegal());
					if (cidLegalList == null) {
						cidLegalList = new ArrayList<RegRepCollateralAgreements>();
						cidLegalKeyAgreementMap.put(agreements.getId().getCidLegal(),cidLegalList);
					}
					cidLegalList.add(agreements);
				}
			}
		}
		
	}
	
	public String getDTCCCollaterlizedValue(String cidLegal,	String cptyShortName, String businessAccountId,	String assetClass) {
		
		boolean initialMargin = false, variationMargin = false, bilateralVariationMargin = false, bilateralInitialMargin = false;
		List<RegRepCollateralAgreements> listAgreements = null;
		
		
		
		
		
		
		
		if (!DataServicesConstants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass)) {
			listAgreements = allAgreementsMap.get(cptyShortName);
		}
		if(XmlMappingUtil.IsListNullOrEmpty(listAgreements) && !XmlMappingUtil.IsNullOrBlank(businessAccountId)){
			String sourceSystem = null;
			if(DataServicesConstants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass)) {
				sourceSystem = "CLYPS2";
			}
			else if(DataServicesConstants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass)) {
				sourceSystem = "IMAGIN";
			}
			else {
				sourceSystem = "CLYPSO";
			}
			
			String calypsoSrcSystems[] = {"CLYP12","CLYPS3","CLYPSO","CLYPS2"}; 
			String key = sourceSystem + "|" + businessAccountId;
			if(businessAccountAgreementMap.containsKey(key)) {
				listAgreements = businessAccountAgreementMap.get(key);
			} else {
				if (sourceSystem.equals("CLYPSO")){
					for (int i=0; i<calypsoSrcSystems.length; i++){
						listAgreements = cidLegalKeyAgreementMap.get(agreementExtnDAO.findCidLegalId(calypsoSrcSystems[i], new Long(businessAccountId)));
						if (!GeneralUtils.IsListNullOrEmpty(listAgreements)){ 
							businessAccountAgreementMap.put(key, listAgreements);
						break;
						}
					}
				} else {
					listAgreements = cidLegalKeyAgreementMap.get(agreementExtnDAO.findCidLegalId(sourceSystem, new Long(businessAccountId)));
					businessAccountAgreementMap.put(key, listAgreements);
			}
		}
		}
		if (  listAgreements != null && !listAgreements.isEmpty() ){
		for ( RegRepCollateralAgreements item : listAgreements ) {

			if (StringUtils.contains(item.getId().getExtAgreementType(), DataServicesConstants.Exchange)) {
				return DataServicesConstants.FullyCollateralized;
			} else 
				if ( XmlMappingUtil.IsNullOrBlank(item.getId().getExtAgreementType())) {
					if (StringUtils.contains(item.getId().getMarginType(),DataServicesConstants.Variation))
						return DataServicesConstants.FullyCollateralized;
			} else						
			if (StringUtils.contains(item.getId().getExtAgreementType(),DataServicesConstants.ISDA)){
						if (!variationMargin) {
							variationMargin = (StringUtils.contains(item.getId().getMarginType(),DataServicesConstants.Variation));
							bilateralVariationMargin = StringUtils.contains(item.getId().getAgreementType(),DataServicesConstants.Bilateral);
						}
						if (!initialMargin) {
							initialMargin = (StringUtils.contains(item.getId().getMarginType(),DataServicesConstants.Initial));
							bilateralInitialMargin = StringUtils.contains(item.getId().getAgreementType(),DataServicesConstants.Bilateral);
						}
			}
		}
		}
		if ((variationMargin && bilateralVariationMargin) && (!initialMargin))
			return DataServicesConstants.PartiallyCollateralized;
		else if ((variationMargin && bilateralVariationMargin) && (initialMargin))
			return DataServicesConstants.FullyCollateralized;
		else if (variationMargin && !bilateralVariationMargin)
			return DataServicesConstants.OneWayCollateralized;


	return DataServicesConstants.UnCollateralized;
		
	}



}
