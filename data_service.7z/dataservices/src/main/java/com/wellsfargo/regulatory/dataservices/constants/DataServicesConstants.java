package com.wellsfargo.regulatory.dataservices.constants;

public class DataServicesConstants {

	// DataServices constants
	public static final String DS_MESSAGE_ID = "dsMessageId";
	public static final String DS_MESSAGE_TYPE = "dsMessageType";
	public static final String DATASERVICES_XML="DATASERVICES_XML";
	public static final String ALLOW_EMPTY_ON_REQD = "ALLOW_EMPTY_ON_REQD";
	public static final String EMPTY_STRING = "";
	public static final String HYPHEN = "-";
	public static final String SLASH = "/";
	public static final String COMMA = ",";
	public static final String COLON = ":";
	public static final String SRC_PRODUCT_TYPE_FRA = "FRA";
	public static final String SRC_PRODUCT_TYPE_CAPFLOOR = "CapFloor";
	public static final String SRC_PRODUCT_TYPE_SWAPTION = "Swaption";
	public static final String SRC_PRODUCT_TYPE_SWAP = "Swap";
	public static final String SRC_PRODUCT_TYPE_FXSWAP = "FXSwap";
	public static final String SRC_PRODUCT_TYPE_FXFORWARD="FXForward";
	public static final String SRC_PRODUCT_TYPE_FXOPTION="FXOption";
	public static final String SRC_PRODUCT_TYPE_CDSSTRUCTPROD = "CDSStructProd";
	public static final String SRC_PRODUCT_TYPE_CREDITDEFAULTSWAP = "CreditDefaultSwap";
	public static final String SRC_PRODUCT_TYPE_SPREADCAPFLOORCMS = "SpreadCapFloorCMS";
	public static final String SRC_PRODUCT_TYPE_CREDITDEFAULTSWAPLOAN="CreditDefaultSwapLoan";
	public static final String SRC_PRODUCT_TYPE_CDSINDEXTRANCHE = "CDSIndexTranche";
	public static final String SRC_PRODUCT_TYPE_ABSCDO = "ABSCDO";
	public static final String SRC_PRODUCT_TYPE_TREASURY_LOCK = "TreasuryLock";
	public static final String SRC_PRODUCT_TYPE_CANCELLABLE_SWAP = "CancellableSwap";
	public static final String SRC_PRODUCT_TYPE_STRUCTURED_MUNI ="StructuredMuni";
	public static final String SRC_PRODUCT_TYPE_STRUCTURED_PRODUCT ="StructuredProduct";
	public static final String SRC_PRODUCT_TYPE_CAPPED_SWAP = "CappedSwap";
	public static final String NON_SD_NON_MSP="non-SD/MSP";
	public static final String PRODUCT_TYPE_CDS = "CDS";
	public static final String PRODUCT_TYPE_RECOVERY_LOCK = "Recovery Lock";
	public static final String PRODUCT_TYPE_FIXED_REOCVERY = "Fixed Recovery";
	public static final String SRC_PRODUCT_TYPE_FPA = "FPA";
	public static final String MMD_RATE_LOCK = "MMDRateLock";
	//Equity product types
	public static final String SRC_PRODUCT_TYPE_EQUITYOPTION = "EquityOption";
	public static final String SRC_PRODUCT_TYPE_EQUITY_SWAP = "EquitySwap";
	public static final String SRC_PRODUCT_TYPE_EQUITY_FORWARD = "EquityForward";
		
	//Equity Sub product types
	public static final String SRC_SUB_PRODUCT_TYPE_VARIANCE_SWAP = "VarianceIndexSwap";
	public static final String SRC_SUB_PRODUCT_TYPE_EXOTIC = "EquityExotic";
	
	public static final String SRC_SUBPRODUCT_TYPE_CORPCDS = "CORPCDS";
	
	public static final String ASSET_CLASS_INTEREST_RATE = "InterestRate";
	public static final String ASSET_CLASS_CREDIT = "Credit";
	public static final String ASSET_CLASS_EQUITY = "Equity";
	public static final String ASSET_CLASS_FOREX = "ForeignExchange";
	
	public static final String LC = "LC"; 
	public static final String DTCCCtyParticipantId="DTCCCtyParticipantId";
	public static final String DTCCOurParticipantId = "DTCCOurParticipantId";
	public static final String Modify = "Modify";
	public static final String New = "New";
	public static final String NEW_DEAL = "New Deal";
	public static final String NONE = "NONE";
	public static final String TYPE="Type";
	public static final String ROLE="Role";
	public static final String TRADER="TRADER";
	public static final String NAME = "Name";
	public static final String GET = "get";
	public static final String CalculationAgent = "CalculationAgent";
	public static final String Value = "Value";
	public static final String DTCC_REPOSITORY = "DTCC";
	
	//Reconciliation Constants
	public static final Integer RECON_FULL_MATCH = 10;
	public static final Integer RECON_PRIMARY_SECONDARY_MATCH = 8;
	public static final Integer RECON_PRIMARY_MATCH = 5;
	public static final Integer RECON_NO_MATCH = 1;
	
	public static final String XML_PAYLOAD_TYPE = "XML";
	public static final String STV_PAYLOAD_TYPE = "STV";
	
	//DS input JSON
	public static final String DS_JSON_HEADER = "headers";
	public static final String DS_JSON_BUSINESS_TERMS = "businessTerms";
	public static final String DS_JSON_EXCEPTIONS = "exceptions";
	public static final String DS_JSON_STV = "sourceBody";
	public static final String DS_JSON_XML = "body";
	
	public static final String DS_JSON_ID = "id";
	// Business Terms constants
	public static final String DS_JSON_BT_TRADEVERSION = "SourceTradeVersion";
	public static final String DS_JSON_BT_TRADEID = "SourceTradeId";
	public static final String DS_JSON_BT_TRADEDATE = "TradeDate";
	public static final String DS_JSON_BT_PRODUCT_TYPE = "ProductType";
	public static final String DS_JSON_BT_USI = "USI";
	public static final String DS_JSON_BT_PRODUCT_CODE = "ProductCode";
	public static final String DS_JSON_BT_TRADE_DATE = "TradeDate";
	public static final String DS_JSON_BT_OTC_TRADEID = "OTCProductID";
	public static final String NOT_FOUND = "NOT FOUND";
	public static final String RATES = "RATES";
	public static final String EQUITY = "EQUITY";
	public static final String FX = "FX";
	public static final String CREDIT = "CREDIT";

	public static final String FIXED= "FIXED";
	public static final String FLOAT= "FLOAT";
	
	public static final String Optional = "Optional";
	
	//InstrumentIdEnum-ENUMS
	public static final String REDPAIR = "RedPair";
	public static final String REDENTITY = "RedEntity";
	
	//Harmonization fields
	
	public static final String HRMN_ASSET_CLASS = "HRMN_ASSET_CLASS";
	public static final String HRMN_BUY_SELL = "HRMN_BUY_SELL";
	public static final String HRMN_FIXED_FLOAT ="HRMN_FIXED_FLOAT";
	public static final String HRMN_VALUATION_DATE = "HRMN_VAL_DATE";
	public static final String HRMN_REGION="HRMN_REGION";
	
	public static final String Auto = "Auto";
	public static final String YES = "YES";
	public static final String Y="Y";
	public static final String N="N";
	public static final String FALSE="FALSE";
	public static final String CONFIRM_PLATFORM_SCRITTURA = "Scrittura";
	public static final String Automatic = "Automatic";

	// Exercise Styles
	
	public static final String EUROPEAN_EXERCISE = "European";
	public static final String AMERICAN_EXERCISE = "American";
	
	public static final String LOCATION = "Location";
	public static final String MeasureType = "MeasureType";
	public static final String ExecutedSpread = "ExecutedSpread";
	public static final String Prefix = "Prefix";
	public static final String NOT_APPLICABLE = "Not Applicable";
	public static final String Exchange = "Exchange";
	public static final String FullyCollateralized = "FullyCollateralized";
	public static final String Variation = "Variation";
	public static final String ISDA = "ISDA";
	public static final String Bilateral = "BILATERAL";
	public static final String Initial = "Initial";
	public static final String PartiallyCollateralized = "PartiallyCollateralized";
	public static final String OneWayCollateralized = "One-WayCollateralized";
	public static final String UnCollateralized = "UnCollateralized";
	public static final String Fully = "Fully";
	public static final String OneWay = "OneWay";
	public static String Partially = "Partially";
	
	public static final String PAY_RELATIVE_TO_LEG1="PaymentRelativeTo";	
	public static final String PAY_RELATIVE_TO_LEG2="PaymentRelativeTo";
	public static final String Parent_KW_UTI_CURRENT = "Parent.KW.UTI_CURRENT";
	public static final String Parent_KW_LEI_CP = "Parent.KW.LEI_CP";
	public static final String Parent_KW_USI_CURRENT = "Parent.KW.USI_CURRENT";
	public static final String KW_SDR_MarketType = "KW.SDR_MarketType";
	public static final String ROLL_CONVENTION = "EOM";
	public static final String DS_PAYMENT_PERIOD = "DS_PRD";
	public static final String BUSSINESS_CENTER="BusinessCenter";
	public static final String UNDERSCORE = "_";
	
	public static final String As_Specified_In_MasterAgreement = "Master Agreement";
	public final static String AsSpecifiedInMasterAgreement = "As_Specified_In_Master_Agreement";
	public final static String DTCC_STS_VALUE = "StandardTermsSupplement";
	public static final String WELLS_FARGO = "Wells Fargo";
	
	public final static String AsSpecifiedInStandardTermsSupplement = "As_Specified_In_Standard_Terms_Supplement";

	public static final String Clearing = "Clearing";

	public final static String Dot=".";
	public final static String Cad="CAD";
	public final static String On="ON";
	public final static String Qc="QC";
	public final static String Mb="MB";
	public final static String Ca="CA";
	public final static String Ns="NS";
	public final static String Index="Index";
	public final static String Share="Share";
	public final static String Basket="Basket";
	public final static String EMIRUSTAXONOMY="EmirUsTaxonomy";
	public final static String EMIRCPTAXONOMY="EmirCpTaxonomy";
	public final static String IMAGINE4="IMAGINE4";
	public final static String STIERS_ENDUR="STIERS_ENDUR";
	public final static String STIERS_CALYPSO_CALRATES="STIERS_CALYPSO_CALRATES";
	public static final String ASSET_CLASS_COMMODITY = "Commodity";
	public static final String PC = "PC";
	public static final String OW = "OW";
	public static final String FC = "FC";
	public static final String UC = "UC";
	
	public static final String TRADE_STATUS_TO_BE_VER = "TO_BE_VER";
	public static final String TRADE_STATUS_TOBE_VER = "TOBE_VER";
	public static final String TRADE_STATUS_TOBE_ASSIGNED = "TOBE_ASSIGNED";
	public static final String DAY_ASSIGNED = "DAY_ASSIGNED";
	public static final String DAY_PENDING = "DAY_PENDING";

	public static final String TRADE_STATUS_TO_BE_MAT = "TO_BE_MAT";
	public static final String TRADE_STATUS_ECN_EARLY_RISK = "ECN_EARLY_RISK";
	public static final String TRADE_STATUS_PRE_BOOKED = "PRE_BOOKED";
	public static final String TRADE_STATUS_CH_TO_BE_VER = "CH_TO_BE_VER";
	
	public static final String UNVERIFIED = "Unverified";
	public static final String ELECTRONIC = "Electronic";
	public static final String TRUE = "true";
	public static final String REGION = "RGN";
	public static final String CDX_SECTOR = "CDXSector";
	public static final String BASKET_INDEX_NAME = "BINDEX";
	public static final String fromValue = "fromValue";
	public static final String AGREEMNT_DATE_2002 = "2002";

	public static final String WF_LEI="KB1H1DSPRFMYMCUFXT09";
	public static final String WF_AFF_LEI_FX="SX0CI4F7GVW5530ZMN03";
	public static final String WF_AFF_LEI_IR="BWS7DNS2Z4NPKPNYKL75";
	
	public static final String FeeType_Premium = "PREMIUM";
	
	public static final String  EEA="EEA";
	public static final String  NON_EEA="nonEEA";
	public static final String  MARKIT_WIRE="MARKIT_WIRE";
	public static final String MasterAgreement = "MasterAgreement";
	public static final String SRC_PRODUCT_TYPE_GENERIC = "Generic";
	public static final String EQ_TXN = "EquityTxn";
	public static final String STRADDLE = "Straddle";
	
	public static final String ASIAN = "Asian";
	public static final String SPREAD_ASIAN = "Spread Asian";
	public static final String RATIO_SPREAD_ASIAN = "Ratio Spread Asian";
	public static final String SPREAD = "Spread";
	public static final String RATIO_SPREAD = "Ratio Spread";
	public static final String DIGITAL = "Digital";
	public static final String OPTION = "Option";
	public static final String CLIQUET = "Cliquet";
	public static final String PENDING = "PENDING";
	public static final String Novation_EE = "Novation - EE";
	public static final String Novation_OR = "Novation - OR";
	public static final String ASSIGNED = "ASSIGNED";
	public static final String PartialNovation_OR = "Partial Novation - OR";
	public static final String US = "Us";
	public static final String FeeType_NovationFee = "NOVATION_FEE";
	public static final String Novation = "Novation";
	public static final String Cancel = "Cancel";
	public static final String TRADE_STATUS_VERIFIED = "VERIFIED";
	public static final String Credit_Novation_OR = "Credit Novation - OR";
	public static final String Credit_Partial_Novation_OR = "Credit Partial Novation - OR";
	public static final String Credit_Novation_EE = "Credit Novation - EE";
	public static final String TRADE_STATUS_NC_CANCELED = "NC_CANCELED";
	public static final String THEM = "Them";
	public static final String Payer = "Payer";
	public static final String Receive = "Receive";
	public static final String Standard = "Standard";
	public static final String ESMA = "ESMA";
	public static final String ISDACreditMonolineInsurers ="ISDACreditMonolineInsurers";
	public static final String SDR_Keywords ="sdrKeywords";
	public final static String MTT = "MTT";
	public final static String SMTT = "SMTT";
	public final static String MATT = "MATT";
	public final static String SMATT = "SMATT";
	public static final String BASKET = "Basket";
	public static final String SHARE = "Share";
	public static final String ThirdPartyPrefix="ThirdPartyPrefix";
	public static final String ThirdPartyValue="ThirdPartyValue";
	public static final String PartyUsValue="PartyUsValue";
	public static final String PartyUsPrefix="PartyUsPrefix";
	public static final String PartyThemPrefix="PartyThemPrefix";
	public static final String PartyThemValue="PartyThemValue";
	public static final String Red = "Red";	
	public static final String PartyUs="PartyUs";
	public static final String RemainingParty="RemainingParty";
	public static final String Transferer="Transferer";
	public static final String Transferee="Transferee";
	public static final String FinancialEntity="FinancialEntity";
	public static final String NonFinancialEntity="Non-FinancialEntity";
	public static final String SRC_PRODUCT_TYPE_CDSABSINDEX = "CDSABSIndex";
	public static final String PERIOD = ".";
	public static final String SRC_PRODUCT_TYPE_CDSINDEX = "CDSIndex";
	public static final String SRC_PRODUCT_TYPE_CDSNTHLOSS = "CDSNthLoss";
	public static final String SRC_PRODUCT_TYPE_CDSINDEXOPTION = "CDSIndexOption";
	public static final String SRC_PRODUCT_TYPE_SCDO = "SCDO";
	public static final String STRUCTURED_PRODUCT = "StructuredProduct";
	public static final String INFLATION = "Inflation";
	public static final String ZCINFLATION = "ZCInflation";
	public static final String CDSINDEXOPTION = "CDSIndexOption";
	public static final Object LINEAR_ZERO_YIELD = "LinearZeroYield";
	public static final String SEF = "SEF";
	public static final String OFF_FACILITY = "Off-Facility";
	public static final String CMD = "CMD";
	public static final String PRODUCT_SUB_TYPE_CORRIDOR = "Corridor";
	
	
	
}

