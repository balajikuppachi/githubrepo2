package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityUnderlyingAssetType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.dataservices.bo.BasketConstituent;
import com.wellsfargo.regulatory.dataservices.bo.EQOptionType;
import com.wellsfargo.regulatory.dataservices.bo.EquityForward;
import com.wellsfargo.regulatory.dataservices.bo.GenericUnderlyer;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class EqForwardXmlMapperService extends EqSwapXmlMapperService {
private static Logger logger = Logger.getLogger(EqForwardXmlMapperService.class.getName());
	
	protected List<LegType> setLegTypeData(TransactionType dsTrade,ProductType productType, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering EqForwardXmlMapperService --> setLegTypeData() method");

		List<LegType> legTypeList = new ArrayList<LegType>();
		LegType legType = objectFactory.createLegType();	
		legType.setLegId((short) 1);
		
		EquityForward eqForward = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityForward());
		
		if (!XmlMappingUtil.IsNullOrBlank(eqForward))
		{
			legType.setSettlementType(XmlMappingUtil.getEnumString(eqForward.getEquityExercise().getSettlementType(),SettlementTypeEnum.class));
			//changed per new mapping
			legType.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()->eqForward.getEquityExercise().getSettlementCurrency()));
			legType.setStartDate(XmlMappingUtil.resolveIfNull(()->eqForward.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			//legType.setEndDate(XmlMappingUtil.resolveIfNull(()->varianceLeg.getTerminationDate().getUnadjustedDate()));
			BuySellEnum buySell = productType.getBuySell();
			if (BuySellEnum.BUY == buySell){
				legType.setPayReceive(PayReceiveEnum.PAY);
			}
			else {
				legType.setPayReceive(PayReceiveEnum.RECEIVE);
			}
			
			//QC-774
			legType.setNotional(XmlMappingUtil.resolveIfNull(()->eqForward.getNotional().getAmount()));
			
		}
		
		legTypeList.add(legType);
	
		logger.info("Leaving EqForwardXmlMapperService --> setLegTypeData() method");

		return legTypeList;
	}
	
	protected EquityTermsType getEquityTermsData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering EqForwardXmlMapperService --> getEquityTermsData() method");

		EquityForward eqForward = dsTrade.getTrade().getProduct().getEquity().getEquityForward();
		
		EquityTermsType equityTermsType = objectFactory.createEquityTermsType();
		
		if (!XmlMappingUtil.IsNullOrBlank(eqForward))
		{
			// Calculation needed to calculate finalValDate
			equityTermsType.setValuationFrequencyPeriodMultiplier(new BigDecimal(XmlMappingUtil.resolveIfNull(()->eqForward.getEquityExercise().getEquityValuation().getValuationDates().getCalculationPeriodFrequency().getPeriodMultiplier())));
			equityTermsType.setValuationFrequencyPeriod(XmlMappingUtil.getConvertedPeriod(XmlMappingUtil.resolveIfNull(()->eqForward.getEquityExercise().getEquityValuation().getValuationDates().getCalculationPeriodFrequency().getPeriod())));
			equityTermsType.getUnderlyingAsset().addAll(setUnderlyingAssetData(dsTrade));
		}
	
		logger.info("Leaving EqForwardXmlMapperService --> getEquityTermsData() method");
		
		return equityTermsType;
	}
	
	private List<EquityUnderlyingAssetType> setUnderlyingAssetData(TransactionType dsTrade) 
	{
		
		logger.info("Entering EqForwardXmlMapperService --> setUnderlyingAssetData() method");
		
		EquityForward eqForward = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityForward());
		List<BasketConstituent> basketConstituent = XmlMappingUtil.resolveIfNull(()->eqForward.getUnderlyer().getBasket().getBasketConstituent());
		EquityUnderlyingAssetType equityUnderlyingAssetType = null;
		List<EquityUnderlyingAssetType> listEquityUnderlyingAssetType = new ArrayList<EquityUnderlyingAssetType>();
		
		for(BasketConstituent basketConstituentValue:basketConstituent){
		equityUnderlyingAssetType = objectFactory.createEquityUnderlyingAssetType();
		String subProductType=dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType();
		String instrumentIdType=null;
		String instrumentId=null;
		String exchangeId=null;
		if(subProductType.contains("Share")  || subProductType.contains(DataServicesConstants.SHARE))
		{
			instrumentIdType=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getEquity().getInstrument().getInstrumentType());
		  	instrumentId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getEquity().getInstrument().getInstrumentId());
		  	exchangeId=basketConstituentValue.getEquity().getExchangeId();
		}
		else if(subProductType.contains("Basket") || subProductType.contains(DataServicesConstants.BASKET))
		{
			instrumentIdType=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getGeneric().getInstrument().getInstrumentType());
			instrumentId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getGeneric().getInstrument().getInstrumentId());
			exchangeId=basketConstituentValue.getGeneric().getExchangeId();
		}
		else
		{
			instrumentIdType=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getIndex().getInstrument().getInstrumentType());
			instrumentId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getIndex().getInstrument().getInstrumentId());
			exchangeId=basketConstituentValue.getIndex().getExchangeId();
		}

	
		if (null!= eqForward)
		{
			
			
			if(instrumentIdType.equalsIgnoreCase(DataServicesConstants.Share)||instrumentIdType.equalsIgnoreCase(DataServicesConstants.Index))
			{
				equityUnderlyingAssetType.setInstrumentIdType("RIC");
			}
			else if(instrumentIdType.equalsIgnoreCase(DataServicesConstants.Basket))
			{
				equityUnderlyingAssetType.setInstrumentIdType(instrumentIdType.substring(0,1).toUpperCase()+instrumentIdType.substring(1).toLowerCase());
			}
			else
			{
				equityUnderlyingAssetType.setInstrumentIdType(instrumentIdType);
			}
			equityUnderlyingAssetType.setInstrumentId(instrumentId);
			equityUnderlyingAssetType.setBasketExchange(exchangeId);
			equityUnderlyingAssetType.setNumberOfUnits(XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getConstituentWeight().getOpenUnits()));
			equityUnderlyingAssetType.setNotional(XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getConstituentWeight().getBasketAmount().getAmount()));
			equityUnderlyingAssetType.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getConstituentWeight().getBasketAmount().getCurrency()));
	//		equityUnderlyingAssetType.setBasketInitialPrice(XmlMappingUtil.resolveIfNull(()->varianceLeg.getAmount().getVariance().getInitialLevel()));
			listEquityUnderlyingAssetType.add(equityUnderlyingAssetType);
		}
		
		logger.info("Leaving EqForwardXmlMapperService --> setUnderlyingAssetData() method");

		}
		return listEquityUnderlyingAssetType;
	}

	protected LifeCycleType setLifeCycleEventData(TransactionType dsTrade,Map<String, String> harmonizerMap,TradeHeaderType tradeHeaderType) 
	{
		LifeCycleType lifeCycle = tradeHeaderType.getLifeCycle();
		
		EquityForward eqForward = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquityForward());
		
		lifeCycle.setEventEffectiveDate(XmlMappingUtil.resolveIfNull(()->eqForward.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
		
		return lifeCycle;
	}

	
	
}
