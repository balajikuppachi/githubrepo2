package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class CalculateDocumentTypeMatrixCalc implements DataSevicesCalculation {
Logger logger = Logger.getLogger(this.getClass());
@Autowired
protected DataServicesCalculationTrigger dataServicesCalculationTrigger;
	
	@Override
	public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap, Object[] inputArr)
    {
		String productType=XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.calculateDtccProductcalc, transactionType, sdrRequest, harmonizerMap, inputArr),String.class);
		String flag=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyUs().getPartyInfo().getDTCCMatrixParticipantFlag());
		if(Constants.PRODUCT_TYPE_CDS.equalsIgnoreCase(productType)){
			if(Constants.TRUE.equalsIgnoreCase(flag)){
				return "CreditDerivativesPhysicalSettlementMatrix";
			} else return Constants.DTCC_STS_VALUE;
			
			
		}else if( Constants.PRODUCT_TYPE_RECOVERY_LOCK.equalsIgnoreCase(productType) ||  Constants.PRODUCT_TYPE_FIXED_REOCVERY.equalsIgnoreCase(productType)){
			if(Constants.TRUE.equalsIgnoreCase(flag)){
				return "CreditDerivativesPhysicalSettlementMatrix";
			} else return Constants.ALLOW_EMPTY_ON_REQD;
		}
		
		else return Constants.DTCC_STS_VALUE;
		
    }

}
