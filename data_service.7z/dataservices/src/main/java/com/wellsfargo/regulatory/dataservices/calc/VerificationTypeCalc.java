package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.mapper.XmlMapperHelper;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class VerificationTypeCalc implements DataSevicesCalculation {

	@Autowired
	XmlMapperHelper xmlMapperHelper;
	
	@Override
	public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap,	Object[] inputArr) {

		String assetClass = xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
		String verificationMethod = DataServicesConstants.EMPTY_STRING;
		
		
		if(DataServicesConstants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(assetClass)) {
			verificationMethod = getVerificationMethodForIR(transactionType);
		}
		else if(DataServicesConstants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass)) {
			verificationMethod = getVerificationMethodForCR(transactionType);
		}
		else if(DataServicesConstants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass)) {
			verificationMethod = getVerificationMethodForEQ(transactionType);
		}
		else if(DataServicesConstants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)) {
			verificationMethod = getVerificationMethodForIR(transactionType);
		}
		return verificationMethod;
	}

	private String getVerificationMethodForEQ(TransactionType transactionType) {

		String verificationMethod = DataServicesConstants.EMPTY_STRING; 
		String verificationType = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getExecution().getVerificationMethod());
		char delimit[]  = {'-', ' ', '.' };
		
		if(!XmlMappingUtil.IsNullOrBlank(verificationType)) {
			String tempString = WordUtils.capitalizeFully(verificationType,delimit);
			verificationMethod = StringUtils.remove(tempString, DataServicesConstants.HYPHEN);
		}
		else {
			verificationMethod = DataServicesConstants.UNVERIFIED;
		}
		return verificationMethod;
	}

	private String getVerificationMethodForCR(TransactionType transactionType) {

		String verificationMethod = DataServicesConstants.EMPTY_STRING; 
		String ecnSource = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getECNSource());
		Boolean ecnTrade=null;
		if(XmlMappingUtil.IsNullOrBlank(ecnSource))
			ecnTrade=false;
		else
			ecnTrade=true;
		
		String clear = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getClearing().getCCPValue());
		

		String electronicConfirm=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getEligibleForElectronicConfirm());
		String electronicConfirmOption=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getEligibleForElectronicConfirm());
		String electronicConfirmValue=(!XmlMappingUtil.IsNullOrBlank(electronicConfirm))?electronicConfirm:electronicConfirmOption;
	
		
	

			//mapping missing for DTCCOkTradeFlag STV tag

			if(!XmlMappingUtil.IsNullOrBlank(ecnTrade)||!XmlMappingUtil.IsNullOrBlank(clear) || (!XmlMappingUtil.IsNullOrBlank(electronicConfirmValue) && electronicConfirmValue.equalsIgnoreCase(Constants.FALSE))) {

				verificationMethod = DataServicesConstants.ELECTRONIC;;
			}
		
		else {
			verificationMethod = DataServicesConstants.UNVERIFIED;
		}
		
		
		return verificationMethod;
	}

	private String getVerificationMethodForIR(TransactionType transactionType) {

		String verificationMethod = DataServicesConstants.EMPTY_STRING; 
		String tradeStatus = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getTradeStatus());
		String ecnSource = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getECNSource());
		
		if(!XmlMappingUtil.IsNullOrBlank(tradeStatus)) {
			if(DataServicesConstants.TRADE_STATUS_TO_BE_VER.equals(tradeStatus) || DataServicesConstants.TRADE_STATUS_CH_TO_BE_VER.equals(tradeStatus)
					|| DataServicesConstants.TRADE_STATUS_ECN_EARLY_RISK.equals(tradeStatus)) {
				verificationMethod = DataServicesConstants.UNVERIFIED;
			}
			
		}
		if(!XmlMappingUtil.IsNullOrBlank(ecnSource)) {
				verificationMethod = DataServicesConstants.ELECTRONIC;
			
		}
		else if(XmlMappingUtil.IsNullOrBlank(ecnSource)) {
			verificationMethod = DataServicesConstants.UNVERIFIED;
		}
		
		return verificationMethod;
	}

}
