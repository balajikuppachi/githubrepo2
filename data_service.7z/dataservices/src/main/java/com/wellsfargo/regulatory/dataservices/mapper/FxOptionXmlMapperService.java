package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.OptionTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.dataservices.bo.FXAmericanExerciseType;
import com.wellsfargo.regulatory.dataservices.bo.FXEuropeanExerciseType;
import com.wellsfargo.regulatory.dataservices.bo.FXOptionType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class FxOptionXmlMapperService extends GenericXmlMapperService {


	private static Logger logger = Logger.getLogger(FxOptionXmlMapperService.class.getName());
	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) {
		
		logger.info("Entering setProductTypeData() method");
		ProductType productType = super.setProductTypeData(dsTrade, harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade, productType,harmonizerMap));
		productType.setExerciseProvision(getExerciseProvision(dsTrade,harmonizerMap));
		
		logger.info("Entering setProductTypeData() method");
		return productType;
	}

	

	protected List<LegType> setLegTypeData(	TransactionType dsTrade, ProductType productType, Map<String, String> harmonizerMap)
	{
		logger.info("Entering setLegTypeData() method");
		List<LegType> legTypeList = new ArrayList<LegType>();
		LegType leg1Type = objectFactory.createLegType();
		FXOptionType fxOption = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getFX().getFXOption());
		if(!XmlMappingUtil.IsNullOrBlank(fxOption))
		{
			leg1Type.setLegId((short) 1);
			leg1Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
			leg1Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg1Type.setStartDate(fxOption.getUnadjustedSettleDate());
			leg1Type.setEndDate(fxOption.getUnadjustedSettleDate());
			leg1Type.setOptionType(XmlMappingUtil.getEnumString(fxOption.getSoldAs(),OptionTypeEnum.class));
			leg1Type.setCurrency(leg1Type.getOptionType()==OptionTypeEnum.PUT?XmlMappingUtil.resolveIfNull(()->fxOption.getPutNotionalAmount().getCurrency()):XmlMappingUtil.resolveIfNull(()->fxOption.getCallNotionalAmount().getCurrency()));
			leg1Type.setNotional(leg1Type.getOptionType()==OptionTypeEnum.PUT?XmlMappingUtil.resolveIfNull(()->fxOption.getPutNotionalAmount().getAmount()):XmlMappingUtil.resolveIfNull(()->fxOption.getCallNotionalAmount().getAmount()));
			leg1Type.setSettlementDate(fxOption.getUnadjustedSettleDate());
			leg1Type.setOptionStrike(fxOption.getStrikeRate());
			leg1Type.setAutoExercise(DataServicesConstants.Auto.equalsIgnoreCase(fxOption.getExerciseProcedureManualOrAutomatic()));
			legTypeList.add(leg1Type);
			
			LegType leg2Type = objectFactory.createLegType();
			leg2Type.setLegId((short) 2);
			leg2Type.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.RECEIVE:PayReceiveEnum.PAY);			
			
			leg2Type.setFixedFloat(FixedFloatEnum.FIXED);
			leg2Type.setStartDate(fxOption.getUnadjustedSettleDate());
			leg2Type.setEndDate(fxOption.getUnadjustedSettleDate());
			leg2Type.setOptionType(leg1Type.getOptionType()==OptionTypeEnum.CALL ? OptionTypeEnum.PUT: OptionTypeEnum.CALL);
			leg2Type.setCurrency(leg1Type.getOptionType()==OptionTypeEnum.CALL?XmlMappingUtil.resolveIfNull(()->fxOption.getPutNotionalAmount().getCurrency()):XmlMappingUtil.resolveIfNull(()->fxOption.getCallNotionalAmount().getCurrency()));
			leg2Type.setNotional(leg1Type.getOptionType()==OptionTypeEnum.CALL?XmlMappingUtil.resolveIfNull(()->fxOption.getPutNotionalAmount().getAmount()):XmlMappingUtil.resolveIfNull(()->fxOption.getCallNotionalAmount().getAmount()));
			leg2Type.setSettlementDate(fxOption.getUnadjustedSettleDate());
			leg2Type.setOptionStrike(fxOption.getStrikeRate());
			leg2Type.setAutoExercise(DataServicesConstants.Auto.equalsIgnoreCase(fxOption.getExerciseProcedureManualOrAutomatic()));
			legTypeList.add(leg2Type);
		
		}
		logger.info("Entering setLegTypeData() method");
		
		return legTypeList;
	}

	
	protected ExerciseProvisionType getExerciseProvision(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
	
		ExerciseProvisionType exerciseProvision = objectFactory.createExerciseProvisionType();	
		FXAmericanExerciseType americanExerciseType = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getFX().getFXOption().getAmericanExercise());
		FXEuropeanExerciseType europeanExerciseType = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getFX().getFXOption().getEuropeanExercise());
		exerciseProvision.setExerciseType(XmlMappingUtil.getEnumString(()->dsTrade.getTrade().getProduct().getFX().getFXOption().getExerciseStyle(),ExerciseTypeEnum.class));
		if(!XmlMappingUtil.IsNullOrBlank(americanExerciseType))
		{
			exerciseProvision.setCommencementDate(americanExerciseType.getCommencementDate().getAdjustableDate().getUnadjustedDate().get(0));
			exerciseProvision.setExpirationDate(americanExerciseType.getExpiryDate());
			exerciseProvision.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->americanExerciseType.getExpiryTime().getHourMinuteTime())));
			exerciseProvision.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->americanExerciseType.getExpiryTime().getBusinessCenter().get(0), BusinessDayConventionEnum.class));
			exerciseProvision.setLatestExerciseTime(americanExerciseType.getLatestValueDate());
			//exerciseProvision.setExerciseDateHolidays(americanExerciseType.getExpiryTime().ge);
		}
		
		if(!XmlMappingUtil.IsNullOrBlank(europeanExerciseType))
		{
			exerciseProvision.setCommencementDate(europeanExerciseType.getValueDate());
			exerciseProvision.setExpirationDate(europeanExerciseType.getExpiryDate());
			exerciseProvision.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->europeanExerciseType.getExpiryTime().getHourMinuteTime())));
			exerciseProvision.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->europeanExerciseType.getExpiryTime().getBusinessCenter().get(0), BusinessDayConventionEnum.class));
			//exerciseProvision.setExerciseDateHolidays(americanExerciseType.getExpiryTime().ge);
		}
		
		return exerciseProvision;
	}

	
}
