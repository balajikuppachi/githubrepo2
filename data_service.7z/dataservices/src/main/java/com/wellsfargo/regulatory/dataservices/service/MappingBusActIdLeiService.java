package com.wellsfargo.regulatory.dataservices.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;
import com.wellsfargo.regulatory.persister.dao.RegRepMappingBussAccLeiDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMappingBussaccidLei;

@Component
public class MappingBusActIdLeiService 

{

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	final Map<String, String> resultMap =new HashMap<String, String>();
	final Map<String, String> resultMapLei =new HashMap<String, String>();
	final Map<String, String> resultMapLeiBusLegalName =new HashMap<String, String>();
	final Map<String, String> resultMapLeiLegalName =new HashMap<String, String>();



	@Autowired
	RegRepMappingBussAccLeiDao regRepMappingBussAccLeiDaoImpl;

	@PostConstruct
	public void initialize() {
		
		List<RegRepMappingBussaccidLei> bussaccidLeis =  regRepMappingBussAccLeiDaoImpl.fetchAllDistinctLegalIds();
		for(RegRepMappingBussaccidLei bussaccidLei: bussaccidLeis) {
			String lei = XmlMappingUtil.resolveIfNull(()->bussaccidLei.getId().getLei());
			String businessAccId = XmlMappingUtil.resolveIfNull(()->bussaccidLei.getId().getBusAccId());
			String legalId = XmlMappingUtil.resolveIfNull(()->bussaccidLei.getId().getLegalId());
			String legalName = XmlMappingUtil.resolveIfNull(()->bussaccidLei.getId().getLegalName());
			
			if(null != lei && null != businessAccId && null != legalId && null != legalName) {
				String key = lei + "-" + businessAccId;
				resultMap.put(key, legalId);
				resultMapLei.put(lei, legalId);
				resultMapLeiBusLegalName.put(key, legalName);
				resultMapLeiLegalName.put(lei, legalName);
			}
			
		}
		
	}
	
	public String getLegalId(String lei,String busAccId) {
		
		String returnValue=null;
		//String leiValueArr[]=XmlMappingUtil.IsNullOrBlank(lei)?null:lei.split(":");
		
		if(!XmlMappingUtil.IsNullOrBlank(lei))
		{
			returnValue= resultMap.get(lei+ "-" +busAccId);
		
		if(XmlMappingUtil.IsNullOrBlank(returnValue))
			returnValue=resultMapLei.get(lei);
		}
		 
		return returnValue;
		
	}
	
	public String getLegalName(String LEI,String busAccId,String legalName) {
		
		logger.debug("Lookup for LegalId, Lei:"+LEI+", BusAccID:"+busAccId+", old legalName:"+legalName);
		String returnValue=null;
		//String leiValueArr[]=XmlMappingUtil.IsNullOrBlank(LEI)?null:LEI.split(":");
		
		if(!XmlMappingUtil.IsNullOrBlank(LEI))
		{
			//String leiValue =leiValueArr[1];
		returnValue= resultMapLeiBusLegalName.get(LEI+ "-" +busAccId);
		
		if(XmlMappingUtil.IsNullOrBlank(returnValue))
			returnValue=resultMapLeiLegalName.get(LEI);
			
		if(XmlMappingUtil.IsNullOrBlank(returnValue))
		 	returnValue=legalName;
			
		}
		return returnValue;
	}

}
		