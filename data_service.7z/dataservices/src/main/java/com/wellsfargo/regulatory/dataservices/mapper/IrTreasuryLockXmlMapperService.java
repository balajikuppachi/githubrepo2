package com.wellsfargo.regulatory.dataservices.mapper;



import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.dataservices.bo.StructuredProductType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.bo.TreasuryLockType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class IrTreasuryLockXmlMapperService extends GenericXmlMapperService 
{
	private static Logger logger = LoggerFactory.getLogger(IrTreasuryLockXmlMapperService.class);

	protected ProductType setProductTypeData(TransactionType dsTrade,Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");

		ProductType productType = objectFactory.createProductType();
		productType = super.setProductTypeData(dsTrade,harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade, productType,harmonizerMap,1));
		productType.setKeywords(null); 

		logger.info("Leaving setProductTypeData() method");

		return productType;
	}


	
	protected List<LegType> setLegTypeData(TransactionType dsTrade, ProductType productType,Map<String, String> harmonizerMap,int legId) 
	{
		logger.info("Entering setLegTypeData() method");

		TreasuryLockType dsTreasuryLock=dsTrade.getTrade().getProduct().getInterestRate().getTreasuryLock();
		StructuredProductType structuredProduct = dsTrade.getTrade().getProduct().getInterestRate().getStructuredProduct();
		
		List<LegType> legTypeList = new ArrayList<LegType>();
		
		LegType leg1Type = objectFactory.createLegType();
	
		leg1Type.setLegId((short) 1);
		leg1Type.setFixedFloat(FixedFloatEnum.FIXED);
		leg1Type.setPayReceive(legId % 2 == 0 ? PayReceiveEnum.RECEIVE : PayReceiveEnum.PAY);
		leg1Type.setStartDate(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeDate()));
		leg1Type.setEndDate(dsTreasuryLock.getMaturityDate());//doubt
		leg1Type.setCurrency(dsTreasuryLock.getCurrency());
		leg1Type.setNotional(XmlMappingUtil.resolveIfNull(()->dsTreasuryLock.getTradeNotional().getAmount()));
		leg1Type.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->dsTreasuryLock.getTradeNotional().getCurrency())); 
		leg1Type.setPrice(XmlMappingUtil.formatNumber(XmlMappingUtil.resolveIfNull(()->structuredProduct.getStructured().getExoticPrice())));
		leg1Type.setPriceUnit(XmlMappingUtil.resolveIfNull(()->structuredProduct.getStructured().getExoticPriceUnits()));
		leg1Type.setDayCountFraction(null);
		leg1Type.setSettlementDate(dsTreasuryLock.getSettlementDate());
		leg1Type.setSettlementType(SettlementTypeEnum.CASH);
		leg1Type.setIndexName(null);
		leg1Type.setIndexTenor(null);
		leg1Type.setIndexSource(null);
		leg1Type.setIndexCurrency(null);
		leg1Type.setPaymentFrequency(null);	
		
		legTypeList.add(leg1Type);

		
		LegType leg2Type = objectFactory.createLegType();
		leg2Type.setLegId((short) 2);
		leg2Type.setFixedFloat(FixedFloatEnum.FIXED);
		leg2Type.setPayReceive(legId % 2 == 0 ? PayReceiveEnum.PAY : PayReceiveEnum.RECEIVE);
		leg2Type.setSettlementType(SettlementTypeEnum.CASH);
		legTypeList.add(leg2Type);

		logger.info("Leaving setLegTypeData() method");

		return legTypeList;
	}
	
	

}
