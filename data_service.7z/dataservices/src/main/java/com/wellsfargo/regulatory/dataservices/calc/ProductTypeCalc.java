package com.wellsfargo.regulatory.dataservices.calc;

import static com.wellsfargo.regulatory.commons.keywords.Constants.COLON;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.cache.ProductMappingCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.RegulatoryType;
import com.wellsfargo.regulatory.dataservices.bo.SourceType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class ProductTypeCalc implements DataSevicesCalculation {

	private static Logger logger = Logger.getLogger(ProductTypeCalc.class.getName());
	private static String subProductArray[]={"CreditDefaultSwapLoan","CDOSQR","CDSIndexOption"};

	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) {

		String srcAssetClass = (String) inputArr[0];
		ProductMappingCache prdCache = null;
		    prdCache =ProductMappingCache.getInstance();
	
		String key = null;
		List<String> values = null;
		boolean found = false;
		String ALL = "ALL";
	
		SourceType srcTypeData = transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource();
		
		ProductType product = sdrRequest.getTrade().getTradeDetail().getProduct();
		RegulatoryType regulatory = transactionType.getTrade().getTradeHeader().getTradeAttributes().getRegulatory();
		
		String srcPrdType = srcTypeData.getProductType();
		String srcSubPrdType = srcTypeData.getProductSubType();
		String repository = Optional.ofNullable(regulatory.getReporting().stream().filter(s->StringUtils.isBlank(s.getRepository())).findFirst().get().getRepository()).orElse(DataServicesConstants.DTCC_REPOSITORY);

		while (!found) {
			key = getProductIdKey(srcAssetClass, srcPrdType, srcSubPrdType,	repository);
			values = prdCache.getValues(key);

			if (null != values) {
				found = true;
				break;
			}

			if (!ALL.equals(srcSubPrdType)) {
				srcSubPrdType = ALL;
				continue;
			} else if (!ALL.equals(srcPrdType)) {
				srcPrdType = ALL;
				continue;
			} else if (!ALL.equals(srcAssetClass)) {
				srcAssetClass = ALL;
			} else {
				break;
			}
		}

		if (!found) {
			logger.error("########## ");

		}

		String dtccAssetClass = values.get(0);
		String dtccPrdType = values.get(1).trim();
		String dtccSubPrdType = values.get(2).trim();
		StringBuilder prdId = new StringBuilder();
		String leg1Currency = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(0).getNotionalCurrency());
		String leg2Currency = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(1).getNotionalCurrency());
		if (!XmlMappingUtil.IsNullOrBlank(leg1Currency) 	&& !XmlMappingUtil.IsNullOrBlank(leg2Currency) 	&& !StringUtils.equalsIgnoreCase(leg1Currency, leg2Currency)) {
			dtccPrdType = Constants.PRODUCT_TYPE_XCCY;
		}

		String leg1Type = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(0).getFixedFloat().value());
		String leg2Type = XmlMappingUtil.resolveIfNull(() -> product.getLeg().get(1).getFixedFloat().value());

		if (!XmlMappingUtil.IsNullOrBlank(leg1Type) && !XmlMappingUtil.IsNullOrBlank(leg2Type) && leg1Type.equals(leg2Type)) {
			if (leg1Type.equals("Fixed")) {
				dtccSubPrdType = "FixedFixed";
			} else if (leg1Type.equals("Float")) {
				dtccSubPrdType = "Basis";
			}
		} else if (!XmlMappingUtil.IsNullOrBlank(leg1Type) && !XmlMappingUtil.IsNullOrBlank(leg2Type) && (leg1Type.equals("Fixed") || leg2Type.equals("Fixed"))) {
			dtccSubPrdType = "FixedFloat";
		}

		/*
		 * prdId.append(dtccAssetClass); prdId.append(COLON);
		 * prdId.append(dtccPrdType); prdId.append(COLON);
		 */
		if (XmlMappingUtil.IsNullOrBlank(dtccAssetClass)) {
			prdId.append("BLANK");
			prdId.append(COLON);
		} else {
			prdId.append(dtccAssetClass);
			prdId.append(COLON);
		}
		if (XmlMappingUtil.IsNullOrBlank(dtccPrdType)) {
			prdId.append("BLANK");
			prdId.append(COLON);
		} else {
			prdId.append(dtccPrdType);
			prdId.append(COLON);
		}

		if (XmlMappingUtil.IsNullOrBlank(dtccSubPrdType)) {
			prdId.append("BLANK");
			prdId.append(COLON);
		} else {
			prdId.append(dtccSubPrdType);
		}
		// prdId.append(dtccSubPrdType);

		return prdId.toString();

	}

	private static String getProductIdKey(String assetClass, String prdType,String subPrdType, String mapingType) {
		logger.debug("Entering getProductIdKey() method");
		List<String> subprodcutExcludeList=Arrays.asList(subProductArray);
		StringBuilder key = null;

		key = new StringBuilder();

		key.append(assetClass);
		key.append(Constants.UNDERSCORE);
		key.append(prdType);
		key.append(Constants.UNDERSCORE);
		if (null != subPrdType && !subprodcutExcludeList.contains(prdType))
			key.append(subPrdType);
		key.append(Constants.UNDERSCORE);
		key.append(mapingType);

		logger.debug("Leaving getProductIdKey() method");

		return key.toString();
	}
}
