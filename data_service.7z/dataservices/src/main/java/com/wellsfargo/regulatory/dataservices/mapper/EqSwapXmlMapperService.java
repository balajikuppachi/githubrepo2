package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityUnderlyingAssetType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExecutionVenueEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ObjectFactory;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartiesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.dataservices.bo.BasketConstituent;
import com.wellsfargo.regulatory.dataservices.bo.EquitySwapInterestLegType;
import com.wellsfargo.regulatory.dataservices.bo.EquitySwapReturnLegType;
import com.wellsfargo.regulatory.dataservices.bo.GenericUnderlyer;
import com.wellsfargo.regulatory.dataservices.bo.PartyThemType;
import com.wellsfargo.regulatory.dataservices.bo.PartyUsType;
import com.wellsfargo.regulatory.dataservices.bo.PriorUSIType;
import com.wellsfargo.regulatory.dataservices.bo.PriorUTIType;
import com.wellsfargo.regulatory.dataservices.bo.SettlementType;
import com.wellsfargo.regulatory.dataservices.bo.TradeIdentifiertype;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;



/**
 * @author Jayshri Vispute
 * @date 06/01/2015
 * @version 1.0
 */


@Component
public class EqSwapXmlMapperService extends GenericXmlMapperService {

	private static Logger logger = Logger.getLogger(EqSwapXmlMapperService.class.getName());
	
		protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
		{
			logger.info("Entering EqSwapXmlMapperService --> setProductTypeData() method");

			ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
			productType.setProductKeys(getProductKeysTypeData(dsTrade, objectFactory));
			productType.setKeywords(null);
			productType.getLeg().addAll(this.setLegTypeData(dsTrade,productType,harmonizerMap));
			productType.setEquityTerms(getEquityTermsData(dsTrade,harmonizerMap));
		
			logger.info("Leaving EqSwapXmlMapperService --> setProductTypeData() method");

			return productType;
		}
	
		public ProductKeysType getProductKeysTypeData(TransactionType dsTrade,	ObjectFactory objectFactory) {
			
			logger.info("Entering EqSwapXmlMapperService --> getProductKeysTypeData() method ");
			ProductKeysType productKeysType = objectFactory.createProductKeysType();
			TradeIdentifiertype tradeIdentifiertype = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeIdentifier());
			if(null != tradeIdentifiertype)	{
				productKeysType.setUSI(XmlMappingUtil.concatenateArrayValues(new String[]{tradeIdentifiertype.getUSIPrefix(),tradeIdentifiertype.getUSIValue()},null));
					
				for (PriorUSIType priorUsi : tradeIdentifiertype.getPriorUSI()) {
					productKeysType.setPrevUSI(XmlMappingUtil.concatenateArrayValues(new String[]{priorUsi.getPriorUSIPrefix(),priorUsi.getPriorUSIValue()},null));
				}
				
				for (PriorUTIType priorUti : tradeIdentifiertype.getPriorUTI()) {
					productKeysType.setPrevUSI(XmlMappingUtil.concatenateArrayValues(new String[]{priorUti.getPriorUTIPrefix(),priorUti.getPriorUTIValue()},null));
				}
				
				productKeysType.setUTI(XmlMappingUtil.concatenateArrayValues(new String[]{tradeIdentifiertype.getUTIPrefix(),tradeIdentifiertype.getUTIValue()},null));
				productKeysType.setUPI(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getTaxonomy().get(0).getProductIDValue()));
			
				
				logger.info("Entering EqSwapXmlMapperService --> getProductKeysTypeData() method ");
			}	
			return productKeysType;

		}
	
		protected List<LegType> setLegTypeData(TransactionType dsTrade, ProductType productType,Map<String, String> harmonizerMap) 
		{
			logger.info("Entering EqSwapXmlMapperService --> setLegTypeData() method");

			EquitySwapInterestLegType dsEquitySwapInterestLegType = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquitySwap().getInterestLeg());
			EquitySwapReturnLegType dsEquitySwapReturnLegType = XmlMappingUtil.resolveIfNull(()-> dsTrade.getTrade().getProduct().getEquity().getEquitySwap().getReturnLeg());

			
			List<LegType> legTypeList = new ArrayList<LegType>();
			LegType leg1Type = objectFactory.createLegType();	
			leg1Type.setLegId((short) 1);
			leg1Type.setNotional(XmlMappingUtil.resolveIfNull(()->dsEquitySwapReturnLegType.getNotional().getAmount()));
			leg1Type.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->dsEquitySwapReturnLegType.getNotional().getCurrency()));
			if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getInterestCalculation().getFloatingRateCalculation().getSpreadSchedule().getInitialValue())))
			{
			BigDecimal spread=dsEquitySwapInterestLegType.getInterestCalculation().getFloatingRateCalculation().getSpreadSchedule().getInitialValue().multiply(new BigDecimal(1000),new MathContext(1));
			leg1Type.setSpread(spread);
			}
			leg1Type.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()-> dsEquitySwapReturnLegType.getSettlement().getSettlementCurrency()));
			leg1Type.setSettlementType(XmlMappingUtil.getEnumString(()->dsEquitySwapReturnLegType.getSettlement().getSettlementType(), SettlementTypeEnum.class));
			leg1Type.setStartDate(XmlMappingUtil.resolveIfNull(()->dsEquitySwapReturnLegType.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			leg1Type.setEndDate(XmlMappingUtil.resolveIfNull(()->dsEquitySwapReturnLegType.getTerminationDate().getUnadjustedDate()));
			leg1Type.setDayCountFraction(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getInterestCalculation().getDayCountFraction()));
			leg1Type.setIndexTenor(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getInterestCalculation().getFloatingRateCalculation().getIndexTenor().getFloatingRatePeriod()));
			leg1Type.setIndexName(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getInterestCalculation().getFloatingRateCalculation().getFloatingRateIndex()));
			leg1Type.setPaymentFrequency(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getInterestLegCalculationPeriodDates().getInterestLegPaymentDates().getRelativeDate().getPeriod().getPeriod()));
			leg1Type.setPaymentFrequencyPeriodMultiplier(XmlMappingUtil.getFormatedValue(()->dsEquitySwapInterestLegType.getInterestLegCalculationPeriodDates().getInterestLegPaymentDates().getRelativeDate().getPeriod().getPeriodMultiplier(),BigDecimal.class));
					//.getInterestCalculation().getFloatingRateCalculation().getIndexTenor().getFloatingRatePeriodMultiplier(),BigDecimal.class));			
			leg1Type.setPayReceive(PayReceiveEnum.PAY);
			leg1Type.setFixedFloat(FixedFloatEnum.FLOAT); // TODO
			legTypeList.add(leg1Type);
			
			/*LegType leg2Type = objectFactory.createLegType();
			leg2Type.setLegId((short) 2);
			leg2Type.setNotional(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getNotional().getAmount()));
			leg2Type.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getNotional().getCurrency()));
			leg2Type.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()-> dsEquitySwapInterestLegType.getNotional().getCurrency()));
			leg2Type.setStartDate(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			leg2Type.setEndDate(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getTerminationDate().getUnadjustedDate()));
			leg2Type.setPayReceive(productType.getBuySell()==BuySellEnum.BUY?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
			leg2Type.setFixedFloat(FixedFloatEnum.FIXED); // TODO
			legTypeList.add(leg2Type);*/
		
			logger.info("Leaving EqSwapXmlMapperService --> setLegTypeData() method");

			return legTypeList;
		}
		
		protected EquityTermsType getEquityTermsData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
		{
			logger.info("Entering EqSwapXmlMapperService --> getEquityTermsData() method");

			EquitySwapReturnLegType returnLeg = XmlMappingUtil.resolveIfNull(()-> dsTrade.getTrade().getProduct().getEquity().getEquitySwap().getReturnLeg());
			EquityTermsType equityTermsType = objectFactory.createEquityTermsType();
			//change as per new mapping
			equityTermsType.setEmbeddedOption((XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getProduct().getEmbeddedOption(), Boolean.class)));
			equityTermsType.setNonStandardFlag(XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getRegulatory().getNonstandardFlag(), Boolean.class)); 
			equityTermsType.setValuationFrequencyPeriod(XmlMappingUtil.resolveIfNull(()->returnLeg.getRateOfReturn().getValuationRules().getCalculationPeriodFrequency().getPeriod()));
			if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->returnLeg.getRateOfReturn().getValuationRules().getCalculationPeriodFrequency().getPeriodMultiplier())))
			equityTermsType.setValuationFrequencyPeriodMultiplier(new BigDecimal(XmlMappingUtil.resolveIfNull(()->returnLeg.getRateOfReturn().getValuationRules().getCalculationPeriodFrequency().getPeriodMultiplier())));

			equityTermsType.getUnderlyingAsset().addAll(setUnderlyingAssetData(dsTrade));
			equityTermsType.setFinalValuationDate(XmlMappingUtil.resolveIfNull(()->returnLeg.getRateOfReturn().getValuationRules().getPeriodicUnadjustedStartDate().getUnadjustedDate().get(0)));
			
			//equityTermsType.setValuationDates(getValuatioinDateData(valuationDates,uow));
			
			logger.info("Leaving EqSwapXmlMapperService --> getEquityTermsData() method");
			
			return equityTermsType;
		}
		
		private List<EquityUnderlyingAssetType> setUnderlyingAssetData(TransactionType dsTrade) 
		{
			
			logger.info("Entering EqSwapXmlMapperService --> setUnderlyingAssetData() method");
			
			EquitySwapReturnLegType returnLeg = XmlMappingUtil.resolveIfNull(()-> dsTrade.getTrade().getProduct().getEquity().getEquitySwap().getReturnLeg());
			List<BasketConstituent> basketConstituent = XmlMappingUtil.resolveIfNull(()->returnLeg.getUnderlyer().getBasket().getBasketConstituent());
			String subProductType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType());
			String instrumentIdType=null;
			String instrumentId=null;
			String exchangeId=null;
			List<EquityUnderlyingAssetType> listEquityUnderlyingAssetType = new ArrayList<EquityUnderlyingAssetType>();
			if(basketConstituent != null) {
				for(BasketConstituent basketConstituentValue:basketConstituent){
				if(subProductType.contains(DataServicesConstants.Share) || subProductType.contains(DataServicesConstants.SHARE))
				{
					instrumentIdType=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getEquity().getInstrument().getInstrumentType());
				  	instrumentId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getEquity().getInstrument().getInstrumentId());
				  	exchangeId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getEquity().getExchangeId());
				}
				else if(subProductType.contains(DataServicesConstants.Basket) || subProductType.contains(DataServicesConstants.BASKET))
				{
					instrumentIdType=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getGeneric().getInstrument().getInstrumentType());
					instrumentId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getGeneric().getInstrument().getInstrumentId());
					exchangeId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getGeneric().getExchangeId());
				}
				else
				{
					instrumentIdType=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getIndex().getInstrument().getInstrumentType());
					instrumentId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getIndex().getInstrument().getInstrumentId());
					exchangeId=XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getIndex().getExchangeId());
				}
				
				
				EquityUnderlyingAssetType equityUnderlyingAssetType = objectFactory.createEquityUnderlyingAssetType();
				//change as per new mappings.
				equityUnderlyingAssetType.setNumberOfUnits(XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getConstituentWeight().getOpenUnits()));
				equityUnderlyingAssetType.setNotional(XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getConstituentWeight().getBasketAmount().getAmount()));
				equityUnderlyingAssetType.setBasketInitialPrice(XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getUnderlyerUnitPrice().getNetPrice().getAmount()));
				equityUnderlyingAssetType.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->basketConstituentValue.getConstituentWeight().getBasketAmount().getCurrency()));
				equityUnderlyingAssetType.setInstrumentId(instrumentId);
				equityUnderlyingAssetType.setInstrumentIdType(instrumentIdType);
				equityUnderlyingAssetType.setBasketExchange(exchangeId);
				
				listEquityUnderlyingAssetType.add(equityUnderlyingAssetType);					
				}
		}
			logger.info("Leaving EqSwapXmlMapperService --> setUnderlyingAssetData() method");

			return listEquityUnderlyingAssetType;
		}
	
		protected TradeHeaderType setTradeHeaderTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
		{
			
			logger.info("Entering EqSwapXmlMapperService --> setTradeHeaderTypeData() method");
			TradeHeaderType tradeHeaderType = super.setTradeHeaderTypeData(dsTrade, harmonizerMap);
			
			tradeHeaderType.setTradeId(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getProductIdentifier().get(0).getProductId()));
			tradeHeaderType.setSecondaryTradeId(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeId()));
			// Trade_id being the TradeVersion from Equity upstream system
			tradeHeaderType.setTradeVersion(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeId()));
			tradeHeaderType.setExecutionVenue(ExecutionVenueEnum.OFF_FACILITY.toString());
			tradeHeaderType.setLifeCycle(setLifeCycleEventData(dsTrade,harmonizerMap,tradeHeaderType));
			logger.info("Leaving EqSwapXmlMapperService --> setTradeHeaderTypeData() method");
			return tradeHeaderType;
		}
		
		
		
		protected LifeCycleType setLifeCycleEventData(TransactionType dsTrade,Map<String, String> harmonizerMap,TradeHeaderType tradeHeaderType) 
		{
			LifeCycleType lifeCycle = tradeHeaderType.getLifeCycle();
			
			EquitySwapInterestLegType dsEquitySwapInterestLegType = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getEquitySwap().getInterestLeg());
			
			lifeCycle.setEventEffectiveDate(XmlMappingUtil.resolveIfNull(()->dsEquitySwapInterestLegType.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			
			return lifeCycle;
		}

		protected TradePartiesType setTradePartiesData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
		{
			TradePartiesType tradePartiesType=objectFactory.createTradePartiesType();
			TradePartyType cpPartyType = xmlMapperHelper.getTradePartiesDetailsData(dsTrade, objectFactory, false,harmonizerMap);
			//DTCCPaticipantId based on LEI_CP for CounterParty
			
			PartyUsType partyUsType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getPartyUs());
			PartyThemType partyThemType=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getPartyThem());
			
			cpPartyType.setLEI(partyThemType.getPartyThemDTCCParticipantID());
			cpPartyType.setLEIPrefix(XmlMappingUtil.getElementAtIndex(partyThemType.getPartyThemDTCCParticipantID(),0,DataServicesConstants.COLON));
			tradePartiesType.getParty().add(cpPartyType);
			
			TradePartyType rptPartyType = xmlMapperHelper.getTradePartiesDetailsData(dsTrade, objectFactory, true,harmonizerMap);
			//DTCCPaticipantId based on LEI_US for ReportingParty
			rptPartyType.setLEI(partyUsType.getPartyUsDTCCParticipantID());
			rptPartyType.setLEIPrefix(XmlMappingUtil.getElementAtIndex(partyUsType.getPartyUsDTCCParticipantID(),0,DataServicesConstants.COLON));
			tradePartiesType.getParty().add(rptPartyType);
			return tradePartiesType;
		}
		
		
		
		
}
