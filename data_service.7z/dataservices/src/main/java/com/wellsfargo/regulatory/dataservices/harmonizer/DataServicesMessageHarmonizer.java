package com.wellsfargo.regulatory.dataservices.harmonizer;

import org.apache.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;

@Component
public class DataServicesMessageHarmonizer
{

	private static Logger logger = Logger.getLogger(DataServicesMessageHarmonizer.class.getName());
	
	public Message<?> harmonize(Message<?> message) throws MessagingException
	{
		logger.info("inside DataServicesMessageHarmonizer:harmonize method ");
		
		DataServicesContext context=(DataServicesContext) message.getPayload();
		
		KieServices ks = KieServices.Factory.get();
		KieContainer kc = ks.getKieClasspathContainer();
		KieSession Ksession = kc.newKieSession("dataServicesKsession");
		Ksession.insert(context);
		Ksession.setGlobal("logger", logger);

		// all rules placed under commonAgenda will be executed first		
		Agenda agenda = Ksession.getAgenda();
		agenda.getAgendaGroup("hrmn_equity").setFocus();
		agenda.getAgendaGroup("hrmn_xasset").setFocus();
		agenda.getAgendaGroup("hrmn_ir").setFocus();
		
		//agenda.getAgendaGroup("etdcommonAgenda").setFocus();

		Ksession.fireAllRules();
		Ksession.dispose();

		
		return message;
	}

}
