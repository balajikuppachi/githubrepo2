package com.wellsfargo.regulatory.dataservices.calc;

import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class PremiumPayOrReceiveCalc implements DataSevicesCalculation
{

	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) 
	{
		
		String premiumType=inputArr[0].toString();
		
		String counterPartyName=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyThem().getPartyInfo().getFullName());
		String counterShortPartyName=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyThem().getPartyInfo().getShortName());
		List<com.wellsfargo.regulatory.dataservices.bo.FeeType> feeTypeList=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getFee());
		String ourName=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyUs().getPartyInfo().getFullName());
		
		String premiumParty = null;
		
		if (XmlMappingUtil.IsListNullOrEmpty(feeTypeList))
		{
			
			OptionalInt indices = IntStream.range(0, feeTypeList.size()).filter(i -> Constants.FeeType_Premium.equalsIgnoreCase(feeTypeList.get(i).getType())).findFirst();
			Integer premiumIndex=indices.isPresent()?indices.getAsInt():-1;
		    boolean  isPremiumAttached=feeTypeList.stream().anyMatch(s->feeTypeList.get(premiumIndex).getFeeAmount()!=null && feeTypeList.get(premiumIndex).getFeeAmount().doubleValue()>0 );
		 
			if(isPremiumAttached)
			{
				if(DataServicesConstants.Payer.equals(premiumType))
					premiumParty = feeTypeList.get(premiumIndex).getPayer();
				
				if(DataServicesConstants.Receive.equals(premiumType))
					premiumParty = feeTypeList.get(premiumIndex).getReceiver();
				
				if(XmlMappingUtil.IsNullOrNone(premiumParty)){					
					premiumParty = feeTypeList.get(premiumIndex).getLegalEntity();					
				}
				
				if(!XmlMappingUtil.IsNullOrBlank(premiumParty))
				{
					if(premiumParty.equalsIgnoreCase(counterPartyName) || premiumParty.equalsIgnoreCase(counterShortPartyName))
						return Constants.PARTY2;
					if(premiumParty.equals(ourName) )
						return Constants.PARTY1;
					}
				}  
					
			}
			
		return premiumParty;
	}

}
