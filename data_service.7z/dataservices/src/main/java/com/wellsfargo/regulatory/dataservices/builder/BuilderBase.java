package com.wellsfargo.regulatory.dataservices.builder;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;

public interface BuilderBase {

	public SdrRequest build(SdrRequest sdrRequest, DataServicesContext dataservicesInput);
	
}
