package com.wellsfargo.regulatory.dataservices.persister;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesPayloadTypeEnum;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;
import com.wellsfargo.regulatory.persister.dataservices.dao.RegRepDsPayloadDao;
import com.wellsfargo.regulatory.persister.dataservices.dto.RegRepDsPayload;

@Component
public class DataServicesPersisterHelper {

	private static Logger logger = Logger.getLogger(DataServicesPersisterHelper.class.getName());
	
	private RegRepDsPayloadDao regRepDsPayloadDao;
	
	
	public void setRegRepDsPayloadDao(RegRepDsPayloadDao regRepDsPayloadDao) {
		this.regRepDsPayloadDao = regRepDsPayloadDao;
	}

	public void persistPayload(Message<?> message) throws MessagingException
	{
		
		
		DataServicesContext context 				= null;
		String messageId 							= null;
		String errorString 							= null;
		DataServicesPayloadTypeEnum contextType 	= null;
		RegRepDsPayload dsPayload					= null;
		
		context = (DataServicesContext) message.getPayload();
		contextType = context.getContextType();
		messageId = context.getMessageId();
		logger.info("DataServicesPersisterHelper:inside persistPayload messageId->"+messageId);
		try 
		{
			if (null == contextType)
			{
				dsPayload = new RegRepDsPayload();
				dsPayload.setMessageId(messageId);
				dsPayload.setType(DataServicesPayloadTypeEnum.DS_INPUT_JSON.getValue());
				dsPayload.setPayload(context.getPayloadContext().getOrigPayload());
				dsPayload.setCreateDatetime(new Date());
				dsPayload.setUpdateDatetime(new Date());
				
				regRepDsPayloadDao.save(dsPayload);
			}
		}
		catch (Exception e)
		{
			errorString = "Failed to persist " + messageId + " message with id : " + messageId + " with reason " + e.getMessage();
			logger.error("########## " + errorString);
		}
		
		return ;
	}
	
	public void updatePayload(Message<?> message) throws MessagingException
	{
		DataServicesContext context 	= null;
		String messageId 				= null;
		String errorString 				= null;
		DataServicesPayloadTypeEnum contextType 	= null;
		RegRepDsPayload dsPayload		= null;
		RegRepDsPayload payload		= null;
		
		
		context = (DataServicesContext) message.getPayload();
		contextType = context.getContextType();
		messageId = context.getMessageId();
		logger.info("DataServicesPersisterHelper:inside updatePayload messageId->"+messageId +" , contextType ->"+contextType);
		try 
		{
			
			if (DataServicesPayloadTypeEnum.DS_INPUT_JSON.equals(contextType))
			{
				
				//update the original payload record
				dsPayload = lookUpTradeDetails(context, messageId);
				regRepDsPayloadDao.saveOrUpdate(dsPayload);
				
				// XML payload record
				
				//payload = preparePayloadObject(dsPayload,context.getPayloadContext().getDsXmlPayload(),DataServicesPayloadTypeEnum.DS_XML.getValue());
				//regRepDsPayloadDao.save(payload);
				
				// Add one more entry in REG_REP_DS_PAYLOAD for STV payload
				//payload = preparePayloadObject(dsPayload,context.getPayloadContext().getStvPayload(),DataServicesPayloadTypeEnum.STV.getValue());
				//regRepDsPayloadDao.save(payload);
				
			}
			else if (DataServicesPayloadTypeEnum.REG_REP_XML.equals(contextType))
			{
				
				//dsPayload = lookUpTradeDetails(context, messageId);
				// XML payload record
				//payload = preparePayloadObject(dsPayload,context.getPayloadContext().getRegRepXmlPayload(),DataServicesPayloadTypeEnum.REG_REP_XML.getValue());
				//regRepDsPayloadDao.save(payload);
				
			
				
			}
		}
		catch (Exception e) {
			errorString = "Failed to update the " + messageId + " message with id : " + messageId + " with reason " + e.getMessage();
			logger.error("########## " + errorString);
		}
		
	}

	private RegRepDsPayload lookUpTradeDetails(DataServicesContext context,	String messageId) {
		RegRepDsPayload dsPayload;
		dsPayload = regRepDsPayloadDao.loadDsMsgByMessageIdAndType(messageId, DataServicesPayloadTypeEnum.DS_INPUT_JSON.getValue());
		
		String productCode = context.getTradeContext().getProductCode();
					
		dsPayload.setAssetClass(context.getTradeContext().getAssetClass());
		dsPayload.setTradeId(context.getTradeContext().getTradeId());
		dsPayload.setTradeVersion(context.getTradeContext().getTradeVersion());
		dsPayload.setProductType(XmlMappingUtil.getElementAtIndex(productCode, 0, DataServicesConstants.SLASH));
		dsPayload.setSubProductType(XmlMappingUtil.getElementAtIndex(productCode, 1, DataServicesConstants.SLASH));
		dsPayload.setUpdateDatetime(new Date());
		dsPayload.setUsi(context.getTradeContext().getUsi());
		return dsPayload;
	}

	/**
	 * preparePayloadObject to prepare the xml record to be inserted
	 * @param dsPayload
	 * @param payLoad
	 * @param payloadType
	 * @return
	 */
	private RegRepDsPayload preparePayloadObject(RegRepDsPayload dsPayload,String payLoad,String payloadType) 
	{
		RegRepDsPayload payload= new RegRepDsPayload();
		payload.setAssetClass(dsPayload.getAssetClass());
		payload.setMessageId(dsPayload.getMessageId());
		payload.setTradeId(dsPayload.getTradeId());
		payload.setTradeVersion(dsPayload.getTradeVersion());
		payload.setUsi(!StringUtils.isEmpty(dsPayload.getUsi())?dsPayload.getUsi():dsPayload.getUti());
		payload.setProductType(dsPayload.getProductType());
		payload.setSubProductType(dsPayload.getSubProductType());
		payload.setPayload(payLoad);
		payload.setType(payloadType);
		payload.setCreateDatetime(new Date());
		payload.setUpdateDatetime(new Date());
		return payload;
	}
}
