package com.wellsfargo.regulatory.dataservices.parser;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;

@Component
public class JsonUtil {

	
	private static Map<String , GenericObject> jsonMsgMap ;
	private static Logger logger = Logger.getLogger(JsonUtil.class.getName());
	private final static JSONParser parser = new JSONParser();
	
	public Map<String, GenericObject>  parse(String inputStr) throws Exception
	{
		
			jsonMsgMap = new HashMap<String, GenericObject>();
			
			//Object obj = parser.parse(new FileReader("C:\\SIT_testing\\SampleJSON.txt"));
			
		try
		{
			Object obj = parser.parse(inputStr);
			
			JSONObject jsonObject = (JSONObject) obj;
			
			String idValue = (String) jsonObject.get("id");
			
			if (idValue !=null )
			{
				GenericObject id = new GenericObject(GenericObject.Type.String);
				id.setObject(idValue);
				jsonMsgMap.put("id", id);
			}
			
			JSONObject headers = (JSONObject) jsonObject.get(DataServicesConstants.DS_JSON_HEADER);
			
			if (headers!=null && !headers.isEmpty())
			{

				GenericObject headersObject = new GenericObject(GenericObject.Type.Map);
				headersObject.setObject(headers);
				
				jsonMsgMap.put(DataServicesConstants.DS_JSON_HEADER, headersObject);
			}
			
			JSONObject businessTerms = (JSONObject) jsonObject.get(DataServicesConstants.DS_JSON_BUSINESS_TERMS);
			
			if (businessTerms!= null && !businessTerms.isEmpty())
			{
				GenericObject btObject = new GenericObject(GenericObject.Type.Map);
				btObject.setObject(businessTerms);
				
				jsonMsgMap.put(DataServicesConstants.DS_JSON_BUSINESS_TERMS, btObject);
			}
			
			JSONObject sdrKeywords = (JSONObject) jsonObject.get(DataServicesConstants.SDR_Keywords);
			
			if (sdrKeywords!= null && !sdrKeywords.isEmpty())
			{
				GenericObject btObject = new GenericObject(GenericObject.Type.Map);
				btObject.setObject(sdrKeywords);
				
				jsonMsgMap.put(DataServicesConstants.SDR_Keywords, btObject);
			}
			
			/*JSONObject exceptions = (JSONObject) jsonObject.get(DataServicesConstants.DS_JSON_EXCEPTIONS);
			
			if (exceptions!=null && !exceptions.isEmpty())
			{
				GenericObject excObject = new GenericObject(GenericObject.Type.Map);
				excObject.setObject(exceptions);
				
				jsonMsgMap.put(DataServicesConstants.DS_JSON_EXCEPTIONS, excObject);
			}*/
			
			String stv = (String) jsonObject.get(DataServicesConstants.DS_JSON_STV);
			
			if (stv != null)
			{
				GenericObject stvObj = new GenericObject(GenericObject.Type.String);
				stvObj.setObject(stv);
				jsonMsgMap.put(DataServicesConstants.DS_JSON_STV, stvObj);
			}
			
			String xml = (String)jsonObject.get(DataServicesConstants.DS_JSON_XML);
			
			if (xml != null)
			{
				GenericObject xmlObj = new GenericObject(GenericObject.Type.String);
				xmlObj.setObject(xml);
				jsonMsgMap.put(DataServicesConstants.DS_JSON_XML, xmlObj);
			}
			
	
		} catch (Exception e) {
			String errorString = "Exception occurred while parsing JSON message : " + inputStr + "::" + e.getMessage();
			logger.error("########## " + errorString);

			e.printStackTrace(System.out);
			throw new MessagingException("JsonUtil:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}
			return jsonMsgMap;
	}
	
	public Map<String, GenericObject> getJsonMsgMap() {
		return jsonMsgMap;
	}

	public void setJsonMsgMap(Map<String, GenericObject> jsonMsgMap) {
		this.jsonMsgMap = jsonMsgMap;
	}
	
	public static JsonUtil getInstance()
	{
		return new JsonUtil();
	}

	public static void main(String a[]) throws Exception
	{
		JsonUtil ju = new JsonUtil();
		ju.parse("test");
		GenericObject g = ju.getJsonMsgMap().get("headers");
		System.out.println(g.getValue("source_file_type"));
		System.out.println(g.getValue("jms_redelivered"));
		System.out.println(g.getValue("jms_timestamp"));
		
		GenericObject h = ju.getJsonMsgMap().get("businessTerms");
		System.out.println(h.getValue("ProductType"));
		System.out.println(h.getValue("TradeDate"));
		
		GenericObject s = ju.getJsonMsgMap().get("id");
		System.out.println(s.getValue("id"));

	}
	
}
