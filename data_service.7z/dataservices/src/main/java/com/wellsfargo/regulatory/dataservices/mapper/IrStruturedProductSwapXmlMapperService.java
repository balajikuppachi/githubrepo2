package com.wellsfargo.regulatory.dataservices.mapper;



import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.dataservices.bo.Swap;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class IrStruturedProductSwapXmlMapperService extends IrSwapXmlMapperService 
{
	private static Logger logger = LoggerFactory.getLogger(IrStruturedProductSwapXmlMapperService.class);

	protected ProductType setProductTypeData(TransactionType dsTrade,Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");

		ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade,harmonizerMap));

		logger.info("Leaving setProductTypeData() method");

		return productType;
	}

	protected List<LegType>  setLegTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setLegTypeData() method");
		List<LegType> legTypeList = new ArrayList<LegType>();
		Swap swap = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getStructuredProduct().getSwap());
		com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg1Type = XmlMappingUtil.resolveIfNull(()->swap.getSwapStream().get(0));
		com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg2Type = XmlMappingUtil.resolveIfNull(()->swap.getSwapStream().get(1));
		
		LegType leg1Type = getLegData( dsTrade,dsLeg1Type, (short)1 );
		legTypeList.add(leg1Type);
		LegType leg2Type = getLegData(dsTrade,dsLeg2Type, (short)2);
		
		/**
		 * TODO: Need to override the leg2 startDate with Leg2StartDate from STV
		 */
		
		//set fixedRate for Leg2
		if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getFixed().getFixedRateInitial())))
		{
		leg2Type.setFixedRate(new BigDecimal(ConversionUtils.formatDecimal8(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFixed().getFixedRateInitial(), BigDecimal.class))));
		}
		leg2Type.setEndDate(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
		leg2Type.setSettlementDate(null);
		legTypeList.add(leg2Type);
		
		logger.info("Leaving setLegTypeData() method");
		return legTypeList;

	}
	
	private LegType getLegData(TransactionType dsTrade,com.wellsfargo.regulatory.dataservices.bo.LegType dsLegType, short legId)
	{
		LegType leg1Type = objectFactory.createLegType();;
		leg1Type.setLegId((short) legId);
		
		leg1Type.setPayReceive(XmlMappingUtil.getEnumString(XmlMappingUtil.resolveIfNull(()->dsLegType.getPayOrReceive()), PayReceiveEnum.class));
		boolean isFixed=FixedFloatEnum.FIXED.toString().equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsLegType.getType()))?true:false;
		leg1Type.setFixedFloat(isFixed?FixedFloatEnum.FIXED:FixedFloatEnum.FLOAT);
		leg1Type.setStartDate(XmlMappingUtil.resolveIfNull(legId%2!=0?()->dsTrade.getTrade().getTradeHeader().getTradeDate():()->XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0))));
		XMLGregorianCalendar terminationDate=!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getTradeMaturityDate()))?
				dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getTradeMaturityDate():XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate());
					
		leg1Type.setEndDate(terminationDate);
		leg1Type.setCurrency(XmlMappingUtil.resolveIfNull(()->dsLegType.getSettlementCurrency()));
		leg1Type.setNotional(XmlMappingUtil.getFormatedValue(XmlMappingUtil.resolveIfNull(()->dsLegType.getNotionalAmount()),BigDecimal.class));
		leg1Type.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getRateIndex().getIndexCurrency()));
		leg1Type.setPrice(XmlMappingUtil.formatNumber((XmlMappingUtil.resolveIfNull(()->dsLegType.getExoticPrice()))));
		leg1Type.setPriceUnit(XmlMappingUtil.resolveIfNull(()->dsLegType.getExoticPriceUnits()));
		leg1Type.setBusinessDayConvention(XmlMappingUtil.getEnumString(XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getCalculationPeriodDatesAdjustments().getBusinessDayConvention()),BusinessDayConventionEnum.class));
		leg1Type.setDayCountFraction(XmlMappingUtil.resolveIfNull(()->dsLegType.getAmortizationParameters().getDayCountFraction()));
		leg1Type.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
		
		leg1Type.setIndexName(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getRateIndex().getIndexName()),1,DataServicesConstants.HYPHEN));
		leg1Type.setIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLegType.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLegType.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
		leg1Type.setIndexSource(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getRateIndex().getIndexSource()),2,DataServicesConstants.HYPHEN));
		leg1Type.setIndexCurrency(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getRateIndex().getIndexCurrency()),0,DataServicesConstants.HYPHEN));
		leg1Type.setPaymentFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLegType.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriodMultiplier())));
		leg1Type.setResetFrequency(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLegType.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLegType.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod(),String.class)},DataServicesConstants.COLON));
		leg1Type.setSettlementType(SettlementTypeEnum.CASH);
		
		return leg1Type;
	}
}
