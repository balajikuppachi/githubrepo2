package com.wellsfargo.regulatory.dataservices.publisher;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;

@Component
public class DataServicesToRegRepPublisher
{
	private static Logger logger = Logger.getLogger(DataServicesToRegRepPublisher.class.getName());
	public List<Message<?>> publish(Message<?> message) throws Exception
	{
		logger.info("inside DataServicesToRegRepPublisher:publish method ");
		
		List<Message<?>> messageList = new ArrayList<Message<?>>();
		Message<?> regRepMessage = null;
	
		logger.info("inside DataServicesToSdrRequestMapper:mapping of DS to REGREP xml completed");
	
		DataServicesContext dsContext=(DataServicesContext) message.getPayload();
		for(String messageString: dsContext.getPayloadContext().getRegRepXmlPayloadList())
		{
			dsContext.getPayloadContext().setRegRepXmlPayload(messageString);
			regRepMessage = MessageBuilder.withPayload(dsContext.getPayloadContext().getRegRepXmlPayload()).setHeader("origStv", dsContext.getPayloadContext().getStvPayload()).build();
			
			messageList.add(regRepMessage);
		}
		
		
	return messageList;	
		
		
	}

}
