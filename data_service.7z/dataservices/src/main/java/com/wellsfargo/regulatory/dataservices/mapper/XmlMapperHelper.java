package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType.CashFlow;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType.PaymentDates;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType.ValuationDates;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClassificationEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DesignationEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DocumentationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType.ExerciseDates;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.GtrEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.NovationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ObjectFactory;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PartyAttributesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PartyAttributesType.Attribute;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProcessedByEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.dataservices.bo.AmortizationType;
import com.wellsfargo.regulatory.dataservices.bo.CSIType;
import com.wellsfargo.regulatory.dataservices.bo.CashFlowsType;
import com.wellsfargo.regulatory.dataservices.bo.LegType;
import com.wellsfargo.regulatory.dataservices.bo.OptionProvisionType;
import com.wellsfargo.regulatory.dataservices.bo.PartyRelatedType;
import com.wellsfargo.regulatory.dataservices.bo.PartyType;
import com.wellsfargo.regulatory.dataservices.bo.PriorUSIType;
import com.wellsfargo.regulatory.dataservices.bo.PriorUTIType;
import com.wellsfargo.regulatory.dataservices.bo.RegulatoryType;
import com.wellsfargo.regulatory.dataservices.bo.ReportingEligible;
import com.wellsfargo.regulatory.dataservices.bo.SettlementType;
import com.wellsfargo.regulatory.dataservices.bo.ThirdPartyType;
import com.wellsfargo.regulatory.dataservices.bo.TradeAttributeType;
import com.wellsfargo.regulatory.dataservices.bo.TradeIdentifiertype;
import com.wellsfargo.regulatory.dataservices.bo.TradelifecycleType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.calc.DataServicesCalculationTrigger;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.service.MappingBusActIdLeiService;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class XmlMapperHelper  {

	@Autowired
	MappingBusActIdLeiService mappingBusActIdLeiService;
	
	@Autowired
	private ConversionUtils parserService;

	@Autowired
	protected DataServicesCalculationTrigger dataServicesCalculationTrigger;

	
	private static Logger logger = Logger.getLogger(XmlMapperHelper.class.getName());

	
	
	public TradePartyType getTradePartiesDetailsData(TransactionType dsTrade, ObjectFactory objectFactory,boolean isRpParty, Map<String, String> harmonizerMap) {

		logger.info("Entering setTradeDetailTypeData() method when isRpParty :"+isRpParty);
		
		String srcAssetClass= getHarmonizedValue(harmonizerMap,DataServicesConstants.HRMN_ASSET_CLASS);
		TradePartyType tradePartyType = objectFactory.createTradePartyType();
		PartyType partyType=dsTrade.getTrade().getParty();
		
		PartyRelatedType partyRelatedType =isRpParty?partyType.getPartyUs().getPartyInfo() :partyType.getPartyThem().getPartyInfo();
		
		tradePartyType.setLegalId(XmlMappingUtil.resolveIfNull(()->mappingBusActIdLeiService.getLegalId(partyRelatedType.getValue(), partyRelatedType.getBusinessAccountID())));
		//tradePartyType.setPartyName(XmlMappingUtil.resolveIfNull(()->getLegalName(partyRelatedType.getValue(), partyRelatedType.getBusinessAccountID(), partyRelatedType.getShortName())));
		tradePartyType.setPartyName(partyRelatedType.getShortName());
		//tradePartyType.setPartyLongName(XmlMappingUtil.resolveIfNull(()->getLegalName(partyRelatedType.getValue(), partyRelatedType.getBusinessAccountID(), partyRelatedType.getFullName())));
	
		String partyName = XmlMappingUtil.resolveIfNull(() -> dsTrade.getTrade().getTradeHeader().getTradeProcessingOrgName());	
		if (!("Equity".equalsIgnoreCase(srcAssetClass)))
		tradePartyType.setPartyLongName((isRpParty && StringUtils.isNotBlank(partyName))?partyName:partyRelatedType.getFullName());
		else
		{
		tradePartyType.setPartyLongName(isRpParty ?partyRelatedType.getFullName():partyRelatedType.getName());	
		}
		tradePartyType.setAddress1(partyRelatedType.getStreet());
		tradePartyType.setAddress2(null);
		tradePartyType.setCity(partyRelatedType.getCity());
		tradePartyType.setState(partyRelatedType.getState());
		tradePartyType.setZip(partyRelatedType.getZip());
		tradePartyType.setCountry(partyRelatedType.getCountry());
		tradePartyType.setBusinessAccountId(partyRelatedType.getBusinessAccountID());
		Boolean isFcm=XmlMappingUtil.getFormatedValue(()->XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getClearing().getCCPClearingCompleted()), Boolean.class);
		if(XmlMappingUtil.IsNullOrBlank(isFcm))
		{
			tradePartyType.setIsFCM(!isRpParty?null:false);
		}
		else
		{
		tradePartyType.setIsFCM(!isRpParty?isFcm:false);
		}
		
		tradePartyType.setDtccParticipantId(isRpParty?partyType.getPartyUs().getPartyUsDTCCParticipantID():partyType.getPartyThem().getPartyThemDTCCParticipantID());
		tradePartyType.setLEI(XmlMappingUtil.concatenateArrayValues(new String[]{partyRelatedType.getPrefix(),partyRelatedType.getValue()}, DataServicesConstants.COLON));
		tradePartyType.setLEIPrefix(partyRelatedType.getPrefix());
		tradePartyType.setLEIValue(partyRelatedType.getValue());
		
		tradePartyType.setDesignation(XmlMappingUtil.getEnumString(()->DataServicesConstants.NON_SD_NON_MSP.equals(partyRelatedType.getRole())?DesignationEnum.NON_SD_NON_MSP.toString():partyRelatedType.getRole(),DesignationEnum.class));
  	    tradePartyType.setProcessedBy(isRpParty?XmlMappingUtil.getEnumString(dataServicesCalculationTrigger.calculate(DataServicesCalc.processedByCalc, dsTrade, null, null, null),ProcessedByEnum.class):null);
  	    if(!XmlMappingUtil.IsNullOrBlank(partyRelatedType.getUSPersonIndicator()))
		tradePartyType.setUsPerson(XmlMappingUtil.getFormatedValue(partyRelatedType.getUSPersonIndicator(),Boolean.class));
  	    if("Equity".equalsIgnoreCase(srcAssetClass))
  	    {
	  	    if(!isRpParty)
	  	    {
	  	    	tradePartyType.setFinancialEntity(DataServicesConstants.FinancialEntity.equals(partyRelatedType.getCFTCFinancialEntityStatus())?Boolean.TRUE:DataServicesConstants.NonFinancialEntity.equals(partyRelatedType.getCFTCFinancialEntityStatus())?Boolean.FALSE:null);
	  	    }
	  	    else
	  	    	tradePartyType.setFinancialEntity(XmlMappingUtil.getFormatedValue(partyRelatedType.getCFTCFinancialEntityStatus(),Boolean.class));
	  	}
  	    else
  	    	tradePartyType.setFinancialEntity(XmlMappingUtil.getFormatedValue(partyRelatedType.getCFTCFinancialEntityStatus(),Boolean.class));
		tradePartyType.setEmirTaxonomy(DataServicesDomainMappingUtil.enrichEmirTaxonomy(partyRelatedType.getESMATaxonomy(), isRpParty));
		tradePartyType.setEmirClearingThreshold(XmlMappingUtil.getFormatedValue(partyRelatedType.getClearingThreshold(),Boolean.class));
		if(!isRpParty)
		{
		tradePartyType.setInterAffiliateClearingException(!XmlMappingUtil.IsNullOrBlank(partyRelatedType.getEndUserInterAffilException())?(((DataServicesConstants.YES.equalsIgnoreCase(partyRelatedType.getEndUserInterAffilException())) || (DataServicesConstants.Y.equalsIgnoreCase(partyRelatedType.getEndUserInterAffilException())))?true:false):false);
		}
		tradePartyType.setEmirRegionEEA((String)dataServicesCalculationTrigger.calculate(DataServicesCalc.partyRegionCalc, dsTrade, null, harmonizerMap, new Object[]{partyRelatedType}));
		tradePartyType.setEmirDirectlyLinked(XmlMappingUtil.getFormatedValue(partyRelatedType.getDirectlyLinkedToCommercialActivityorTreasuryFinancing(),Boolean.class));
		tradePartyType.setEmirFinancialEntity(XmlMappingUtil.getFormatedValue(partyRelatedType.getESMAFinancialEntity(), Boolean.class));
		tradePartyType.setEmirTradingCapacity(partyRelatedType.getTradingCapacity());
		tradePartyType.setPartyAttributes(getCPAttribute(partyType, objectFactory,isRpParty));
		tradePartyType.setClassification(!isRpParty?XmlMappingUtil.getEnumString(()->dsTrade.getTrade().getParty().getPartyThem().getClassification(),ClassificationEnum.class):null);
		tradePartyType.setEndUserException(!isRpParty?(((DataServicesConstants.YES.equalsIgnoreCase(partyRelatedType.getEndUserClearingException())) || (DataServicesConstants.Y.equalsIgnoreCase(partyRelatedType.getEndUserClearingException())))?true:false):null);
		tradePartyType.setUltimateCptyName(!isRpParty?XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->partyType.getUltimateCounterparty().getName()))?null:
			XmlMappingUtil.resolveIfNull(()->partyType.getUltimateCounterparty().getName()):null);
		
		logger.info("Leaving setTradeDetailTypeData() method");
		
		return tradePartyType;

	}

	private PartyAttributesType getCPAttribute(	PartyType partyType, ObjectFactory objectFactory,	boolean isRpParty) {

		PartyAttributesType partyAttributesType = objectFactory.createPartyAttributesType();
		Attribute attribute = objectFactory.createPartyAttributesTypeAttribute();
		List<Attribute> listAttributes = new ArrayList<Attribute>();
		attribute.setValue(isRpParty?partyType.getPartyUs().getPartyUsDTCCParticipantID():partyType.getPartyThem().getPartyThemDTCCParticipantID());
		attribute.setName(isRpParty?DataServicesConstants.DTCCOurParticipantId:DataServicesConstants.DTCCCtyParticipantId);
		listAttributes.add(attribute);
		partyAttributesType.getAttribute().addAll(listAttributes);
		return partyAttributesType;
	}


	public DocumentationType getDocumentationTypeData(TransactionType dsTrade, ObjectFactory objectFactory,Map<String, String> harmonizerMap) {
		
		logger.info("Entering setTradeDetailTypeData() method ");
		DocumentationType documentationType= objectFactory.createDocumentationType();

		Boolean isMonolineInsurer = false;
			
		
		com.wellsfargo.regulatory.dataservices.bo.DocumentationType documentationTypeData=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getDocumentation());
		//dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getMonolineInsurerFlag();
		documentationType.setMasterAgreementType(DataServicesDomainMappingUtil.getMasterAgreementType(XmlMappingUtil.resolveIfNull(()->documentationTypeData.getAgreementType())));
		documentationType.setMasterAgreementVersion(XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.masterAgreementVersionCalc, dsTrade, null, harmonizerMap, null),String.class));
		documentationType.setMasterAgreementDate((XMLGregorianCalendar)dataServicesCalculationTrigger.calculate(DataServicesCalc.masterAgreementDateCalc, dsTrade, null, harmonizerMap, null));	
		isMonolineInsurer = Optional.ofNullable(XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getMonolineInsurerFlag(), Boolean.class)).orElse(
			XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getMonolineInsurerFlag(), Boolean.class));
		
		if(!XmlMappingUtil.IsNullOrBlank(isMonolineInsurer) && isMonolineInsurer == Boolean.TRUE) {
			documentationType.setContractualTermsSupplementType(DataServicesConstants.ISDACreditMonolineInsurers);
		}
		Boolean dtccMatrixParticipantFlag=XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getParty().getPartyUs().getPartyInfo().getDTCCMatrixParticipantFlag(), Boolean.class);
		if(!XmlMappingUtil.IsNullOrBlank(dtccMatrixParticipantFlag) && dtccMatrixParticipantFlag == Boolean.TRUE) 
			documentationType.setDtccMatrixParticipant(XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getParty().getPartyUs().getPartyInfo().getDTCCMatrixParticipantFlag(), Boolean.class));
		
		logger.info("Leaving setTradeDetailTypeData() method ");
		return documentationType;
	}

	
	
	



	public ProductKeysType getProductKeysTypeData(TransactionType dsTrade,	ObjectFactory objectFactory,Map<String, String> harmonizerMap) {
		
		logger.info("Entering getProductKeysTypeData() method ");
		ProductKeysType productKeysType = objectFactory.createProductKeysType();
		TradeIdentifiertype tradeIdentifiertype = dsTrade.getTrade().getTradeHeader().getTradeIdentifier();
		if(!XmlMappingUtil.IsNullOrBlank(tradeIdentifiertype))	{
			productKeysType.setUSI(XmlMappingUtil.concatenateArrayValues(new String[]{tradeIdentifiertype.getUSIPrefix(),tradeIdentifiertype.getUSIValue()},null));
				
			for (PriorUSIType priorUsi : tradeIdentifiertype.getPriorUSI()) {
				productKeysType.setPrevUSI(XmlMappingUtil.concatenateArrayValues(new String[]{priorUsi.getPriorUSIPrefix(),priorUsi.getPriorUSIValue()},null));
			}
			
			for (PriorUTIType priorUti : tradeIdentifiertype.getPriorUTI()) {
				productKeysType.setPrevUSI(XmlMappingUtil.concatenateArrayValues(new String[]{priorUti.getPriorUTIPrefix(),priorUti.getPriorUTIValue()},null));
			}
			
			productKeysType.setUTI(XmlMappingUtil.concatenateArrayValues(new String[]{tradeIdentifiertype.getUTIPrefix(),tradeIdentifiertype.getUTIValue()},null));
			
			logger.info("Entering getProductKeysTypeData() method ");
		}	
		return productKeysType;

	}

	

	
	/**The getActionData which calculates the Action
	 * @param uow
	 * @return
	 */
	public String getActionData(String exeEvent)
	{
		logger.info("getActionData : Calculate the Action");
		
		if(DataServicesConstants.NEW_DEAL.equals(exeEvent) || DataServicesConstants.NONE.equalsIgnoreCase(exeEvent))
		{
			return DataServicesConstants.New;
		}else
		{
			return DataServicesConstants.Modify;
		}	
	}
	
	
	public LifeCycleType getLifeCycleTypeData(TransactionType dsTrade, ObjectFactory objectFactory) {

		LifeCycleType lifeCycleType = objectFactory.createLifeCycleType();
		XMLGregorianCalendar cDSstartDate=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0));
		XMLGregorianCalendar cDSOptionstartDate=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0));
		
		XMLGregorianCalendar cDSStartDateValue=(!XmlMappingUtil.IsNullOrBlank(cDSstartDate))?cDSstartDate:cDSOptionstartDate;
		TradelifecycleType tradeLifeCycle = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeLifeCycle());
		TradeAttributeType tradeAttributes = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes());
		
		lifeCycleType.setEventType(dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getLifeCycleEvent());
		lifeCycleType.setEventSubType(XmlMappingUtil.resolveIfNull(()->tradeAttributes.getSource().getLifeCycleEventSubType()));
		XMLGregorianCalendar eventExectionDateTime=XmlMappingUtil.resolveIfNull(()->tradeAttributes.getExecution().getLifeCycleExecutionDateTime());
		if(XmlMappingUtil.IsNullOrBlank(eventExectionDateTime))
			eventExectionDateTime=XmlMappingUtil.resolveIfNull(()->tradeAttributes.getExecution().getExecutionTimestamp());
		lifeCycleType.setEventExecutionDateTime(XmlMappingUtil.getFormatedValue(eventExectionDateTime,XMLGregorianCalendar.class));
		lifeCycleType.setEventEffectiveDate(XmlMappingUtil.resolveIfNull(()->tradeLifeCycle.getAmendmentDate()));
		//lifeCycleType.setInternalConfirmRequired(uow.getBoolean(Calc.isAffliateConfirmReportableCalc));
		lifeCycleType.setCounterpartyAffirmedTimestamp(XmlMappingUtil.getFormatedValue(()->tradeAttributes.getAffirmation().getCounterpartyAffirmationTimestamp(),XMLGregorianCalendar.class));
		lifeCycleType.setOriginalNotional(tradeLifeCycle.getDealNotional()); 
		lifeCycleType.setParentSubAllocated(ConversionUtils.booleanFromBoolean(XmlMappingUtil.getFormatedValue(()->tradeAttributes.getAllocation().getIsSubAllocated(),Boolean.class)));
		if(XmlMappingUtil.IsNullOrBlank(tradeLifeCycle.getIsCompressedTrade())) {
			lifeCycleType.setPortfolioCompression(DataServicesConstants.N);
		} 
		else {
			//lifeCycleType.setPortfolioCompression(DataServicesConstants.FALSE.equalsIgnoreCase(tradeLifeCycle.getIsCompressedTrade())?DataServicesConstants.N:DataServicesConstants.Y);
			lifeCycleType.setPortfolioCompression(XmlMappingUtil.IsNullOrBlank(tradeLifeCycle.getEventProcessingID())?DataServicesConstants.N:DataServicesConstants.Y);
		}
		
		lifeCycleType.setTransferFrom(tradeLifeCycle.getTransferFrom()); 
		lifeCycleType.setTransferTo(tradeLifeCycle.getTransferTo());
		lifeCycleType.setAllocatedFrom(XmlMappingUtil.resolveIfNull(()->tradeAttributes.getAllocation().getAllocatedFrom()));
		lifeCycleType.setClearing(getClearingTypeData(dsTrade, objectFactory)); 
		lifeCycleType.setNovation(getNovationTypeDate(dsTrade, objectFactory)); 
		lifeCycleType.setPostEventEffectiveDate(XmlMappingUtil.getFormatedValue(!XmlMappingUtil.IsNullOrBlank(tradeLifeCycle.getPostTradeEffectiveDate())?tradeLifeCycle.getPostTradeEffectiveDate():cDSStartDateValue,XMLGregorianCalendar.class));
		lifeCycleType.setPostEventTransactionDate(XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.postEventTransactionDate, dsTrade, null, null, null),XMLGregorianCalendar.class));
		return lifeCycleType;

	}
	
	
	private ClearingType getClearingTypeData(TransactionType dsTrade, ObjectFactory objectFactory) {
		ClearingType clearingType = null;
		com.wellsfargo.regulatory.dataservices.bo.ClearingType clearing = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getClearing());
		XMLGregorianCalendar ccpClearingDateTime=null;
		XMLGregorianCalendar swSendForClearingTimeStamp=null;
		clearingType = objectFactory.createClearingType();
		// set default value of false for clearedTrade
		clearingType.setClearedTrade(Boolean.FALSE);
		if (!XmlMappingUtil.IsNullOrBlank(clearing)){
		String ccpTradeID=clearing.getCCPTradeId();
		String ccpStatus = clearing.getClearingStatus();
		swSendForClearingTimeStamp = clearing.getSendForClearingTimeStamp();
		String kwSendForClearing = clearing.getSendForClearing();
		String swAutoSendForClearing = clearing.getAutoSendForClearing();
		ccpClearingDateTime = clearing.getCCPClearingTimeStamp();
		String swEligibleForClearing = clearing.getEligibleForClearing();
		String ccp = clearing.getCCPValue();
			if (!XmlMappingUtil.IsNullOrBlank(ccpTradeID)
					|| !XmlMappingUtil.IsNullOrBlank(ccpStatus)
					|| !XmlMappingUtil.IsNullOrBlank(swSendForClearingTimeStamp)
					|| !XmlMappingUtil.IsNullOrBlank(ccpClearingDateTime)
					|| !XmlMappingUtil.IsNullOrBlank(kwSendForClearing)
					|| !XmlMappingUtil.IsNullOrBlank(swAutoSendForClearing)
					|| !XmlMappingUtil.IsNullOrBlank(swEligibleForClearing)
					|| !XmlMappingUtil.IsNullOrBlank(ccp)) {
				clearingType.setClearedTrade(XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.clearedTradeCalc, dsTrade,null, null, null), Boolean.class));
				clearingType.setClearingTradeId(ccpTradeID);
				clearingType.setClearingStatus(ccpStatus);
				clearingType.setSendForClearingDateTime(XmlMappingUtil.getFormatedValue(swSendForClearingTimeStamp,XMLGregorianCalendar.class));
				clearingType.setSendForClearing(kwSendForClearing);
				clearingType.setClearedDateTime(XmlMappingUtil.getFormatedValue(ccpClearingDateTime,XMLGregorianCalendar.class));
				clearingType.setEligibleForClearing(swEligibleForClearing);
				clearingType.setClearingHouse(ccp);
				if(clearingType.isClearedTrade())
				{
				clearingType.setClearingHouseLEI(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getPartyThem().getPartyInfo().getValue()));
				}
				clearingType.setBilateralTradeId(null);
			}
		}
				
		return clearingType;
	}
	


	public NovationType getNovationTypeDate(TransactionType dsTrade, ObjectFactory objectFactory) {

		NovationType novationType = null;
		TradelifecycleType tradeLifeCycle =  XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeLifeCycle());
		
		PartyRelatedType partyUs = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getPartyUs().getPartyInfo());
		PartyRelatedType partyThem=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getPartyThem().getPartyInfo());
		ThirdPartyType thirdParty=XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getParty().getThirdParty());
		
		Map <String ,String> novationLeiMap=new HashMap<String, String>();
		novationLeiMap.put(DataServicesConstants.ThirdPartyPrefix, XmlMappingUtil.resolveIfNull(()->thirdParty.getPrefix()));
		novationLeiMap.put(DataServicesConstants.ThirdPartyValue, XmlMappingUtil.resolveIfNull(()->thirdParty.getValue()));
		novationLeiMap.put(DataServicesConstants.PartyUsPrefix, XmlMappingUtil.resolveIfNull(()->partyUs.getPrefix()));
		novationLeiMap.put(DataServicesConstants.PartyUsValue, XmlMappingUtil.resolveIfNull(()->partyUs.getValue()));
		novationLeiMap.put(DataServicesConstants.PartyThemPrefix, XmlMappingUtil.resolveIfNull(()->partyThem.getPrefix()));
		novationLeiMap.put(DataServicesConstants.PartyThemValue, XmlMappingUtil.resolveIfNull(()->partyThem.getValue()));
		
		if(!XmlMappingUtil.IsNullOrBlank(tradeLifeCycle) && DataServicesConstants.Novation.equals(tradeLifeCycle.getLifeCycleEvent()))
		{
			novationType=objectFactory.createNovationType();
			
			novationType.setRole(DataServicesConstants.PartyUs.equals(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeLifeCycle().getRemainingPartyValue()))?DataServicesConstants.RemainingParty:null); //stv.NovationWachoviaRole
			novationType.setRole(DataServicesConstants.PartyUs.equals(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeLifeCycle().getTransferorValue()))?DataServicesConstants.Transferer:null);
			novationType.setRole(DataServicesConstants.PartyUs.equals(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeLifeCycle().getTransfereeValue()))?DataServicesConstants.Transferee:null);

			novationType.setNovationAction(tradeLifeCycle.getNCActivity()); 
			novationType.setNovationDate(tradeLifeCycle.getNovationDate());
			novationType.setNovatedAmount(XmlMappingUtil.resolveIfNull(()->tradeLifeCycle.getDecreasedAmount().getAmount()));
			novationType.setRemainingAmount(new BigDecimal(0)); 
			novationType.setNewNovationTradeId(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getTradeLinkIds().getTradeLinkId()));
	
			novationType.setTransferorLEI(XmlMappingUtil.concatenateArrayValues(new String[]{novationLeiMap.get(tradeLifeCycle.getTransferorValue()+DataServicesConstants.Prefix),novationLeiMap.get(tradeLifeCycle.getTransferorValue()+DataServicesConstants.Value)}, Constants.COLON));
			novationType.setTransferorLEIPrefix(novationLeiMap.get(tradeLifeCycle.getTransferorValue()+DataServicesConstants.Prefix));
			novationType.setTransferorLEIValue(novationLeiMap.get(tradeLifeCycle.getTransferorValue()+DataServicesConstants.Value));
			
			novationType.setTransfereeLEI(XmlMappingUtil.concatenateArrayValues(new String[]{novationLeiMap.get(tradeLifeCycle.getTransfereeValue()+DataServicesConstants.Prefix),novationLeiMap.get(tradeLifeCycle.getTransfereeValue()+DataServicesConstants.Value)}, Constants.COLON));
			novationType.setTransfereeLEIPrefix(novationLeiMap.get(tradeLifeCycle.getTransfereeValue()+DataServicesConstants.Prefix));
			novationType.setTransfereeLEIValue(novationLeiMap.get(tradeLifeCycle.getTransfereeValue()+DataServicesConstants.Value));
			
			novationType.setRemainingPartyLEI(XmlMappingUtil.concatenateArrayValues(new String[]{novationLeiMap.get(tradeLifeCycle.getRemainingPartyValue()+DataServicesConstants.Prefix), novationLeiMap.get(tradeLifeCycle.getRemainingPartyValue()+DataServicesConstants.Value)},Constants.COLON));
			novationType.setRemainingPartyLEIPrefix(novationLeiMap.get(tradeLifeCycle.getRemainingPartyValue()+DataServicesConstants.Prefix));
			novationType.setRemainingPartyLEIValue(novationLeiMap.get(tradeLifeCycle.getRemainingPartyValue()+DataServicesConstants.Value));
		}
		
		return novationType;
	}

	
	public ExerciseProvisionType getExerciseProvisionTypeData(TransactionType dsTrade, ObjectFactory objectFactory) 
	{
		ExerciseProvisionType exerciseProvisionType = null;
		
		List<CSIType> csiContent =  XmlMappingUtil.resolveIfNull(()->(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getSettlement()).getCSI()));
		
		if(!XmlMappingUtil.IsListNullOrEmpty(csiContent) )
		{
			for (CSIType csiTypeData : csiContent) 
			{
				exerciseProvisionType = objectFactory.createExerciseProvisionType();
				exerciseProvisionType.setOptional(DataServicesConstants.Optional.equalsIgnoreCase(csiTypeData.getSettlementOption())?true:false);
				exerciseProvisionType.setEventType(csiTypeData.getEventType());
				exerciseProvisionType.setExerciseType(XmlMappingUtil.getEnumString(csiTypeData.getOptionStyle(),ExerciseTypeEnum.class));
				exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->csiTypeData.getExpirationDate().getUnadjustedDate())); 
				exerciseProvisionType.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->csiTypeData.getExpirationTime().getHourMinuteTime()))); 
				exerciseProvisionType.setEarliestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->csiTypeData.getFirstExerciseTime().getHourMinuteTime()))); 
				//exerciseProvisionType.setLatestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->csiTypeData.getExpirationTime().getHourMinuteTime())));
				exerciseProvisionType.setLatestExerciseTime(null);
				exerciseProvisionType.setExerciseDateHolidays(csiTypeData.getExerciseDateBusDays()); 
				exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->csiTypeData.getExerciseDates().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class)); 
				exerciseProvisionType.getExerciseDates().addAll(getExerciseDatesData(csiTypeData, objectFactory));
				
				exerciseProvisionType.setCashSettlement(getCashSettlement(csiTypeData, objectFactory,dsTrade )); 
			}
		}
		
		return exerciseProvisionType;
	}

	private CashSettlementType getCashSettlement(CSIType csiTypeData,ObjectFactory objectFactory,TransactionType dsTrade) {
		CashSettlementType cashSettlementType = objectFactory.createCashSettlementType();
		cashSettlementType.setCurrency(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getSettlement().getCurrency()));
		cashSettlementType.setQuoteType(csiTypeData.getQuoteType());
		cashSettlementType.setSettleMethod(csiTypeData.getMethod()); 
		cashSettlementType.setValuationDateHolidays(csiTypeData.getValuationDateBusDays());
		cashSettlementType.setValuationDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->csiTypeData.getPaymentDates().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
		cashSettlementType.getValuationDates(). addAll(getValuationDatesData(csiTypeData,objectFactory));
		cashSettlementType.setPaymentDateHolidays(csiTypeData.getPaymentDateBusDays());
		cashSettlementType.setPaymentDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->csiTypeData.getExerciseDates().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
		cashSettlementType.getPaymentDates().addAll(getPaymentDatesData(csiTypeData,objectFactory));

		return cashSettlementType;
	}

	
	private List<ValuationDates> getValuationDatesData(CSIType csiTypeData, ObjectFactory objectFactory) {
		List<ValuationDates> valuationDatesList = new ArrayList<ValuationDates>();
		List<XMLGregorianCalendar> dates = XmlMappingUtil.resolveIfNull(()-> csiTypeData.getValuationDates().getUnadjustedDate());
		if(!XmlMappingUtil.IsListNullOrEmpty(dates))
		{
			for (XMLGregorianCalendar valuationDate : dates) {
				ValuationDates valuationDateType = objectFactory.createCashSettlementTypeValuationDates();
				valuationDateType.setValuationDate(valuationDate);
				valuationDatesList.add(valuationDateType);
			}
		}
		return valuationDatesList;
	}

	private List<PaymentDates> getPaymentDatesData(CSIType csiTypeData, ObjectFactory objectFactory) {
		List<PaymentDates> paymentDatesList = new ArrayList<PaymentDates>();
		List<XMLGregorianCalendar> dates = XmlMappingUtil.resolveIfNull(()-> csiTypeData.getPaymentDates().getUnadjustedDate());
		if(!XmlMappingUtil.IsListNullOrEmpty(dates))
		{
			for (XMLGregorianCalendar paymentDate : dates) {
				PaymentDates paymentDateype = objectFactory.createCashSettlementTypePaymentDates();
				paymentDateype.setPaymentDate(paymentDate);
				paymentDatesList.add(paymentDateype);
			}
		}
		return paymentDatesList;
	}


	private List<ExerciseDates> getExerciseDatesData(CSIType csiTypeData, ObjectFactory objectFactory)
	{
		List<ExerciseDates> exerciseDatesList = new ArrayList<ExerciseDates>();
		List<XMLGregorianCalendar> dates = XmlMappingUtil.resolveIfNull(()->csiTypeData.getExerciseDates().getUnadjustedDate());
		if(!XmlMappingUtil.IsListNullOrEmpty(dates))
		{
			for (XMLGregorianCalendar exerciseDate : dates) {
				ExerciseDates exerciseDateype = objectFactory.createExerciseProvisionTypeExerciseDates();
				exerciseDateype.setExerciseDate(exerciseDate);
				exerciseDateype.setExerciseFee(null); // not found in xsl mapping
				exerciseDatesList.add(exerciseDateype);
			}
		}
		return exerciseDatesList;
	}

	
	
	public ExerciseProvisionType getExerciseProvisionTypeData(TransactionType dsTrade, ObjectFactory objectFactory,OptionProvisionType cancelableProvision ) 
	{
		ExerciseProvisionType exerciseProvisionType = objectFactory.createExerciseProvisionType();
		SettlementType settlement = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getSettlement());
		
			if(null != settlement ) {
				List<CSIType> csiContent = settlement.getCSI();
					
						for (CSIType csiTypeData : csiContent) {
							if(!XmlMappingUtil.IsListNullOrEmpty(csiContent)) {
							exerciseProvisionType.setOptional(DataServicesConstants.Optional.equalsIgnoreCase(csiTypeData.getOptionStyle())?true:false);
							exerciseProvisionType.setEventType(csiTypeData.getEventType());
							
							exerciseProvisionType.setExerciseDateHolidays(csiTypeData.getExerciseDateBusDays());
							
							
				//			exerciseProvisionType.getExerciseDates().addAll(getExerciseDatesData(csiTypeData, objectFactory));
				//			exerciseProvisionType.setCashSettlement(getCashSettlement(csiTypeData, objectFactory,dsTrade )); 
							}
						}
						exerciseProvisionType.setExerciseType(XmlMappingUtil.getEnumString(cancelableProvision.getOptionExerciseStyle(),ExerciseTypeEnum.class));
							if(!XmlMappingUtil.IsNullOrBlank(cancelableProvision.getAmerican())) {
								
								exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getAmerican().getExpirationDate().getUnadjustedDate())); 
								exerciseProvisionType.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getAmerican().getExpirationTime().getHourMinuteTime()))); 
								exerciseProvisionType.setEarliestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getAmerican().getExpirationTime().getHourMinuteTime())));  
								exerciseProvisionType.setLatestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getAmerican().getLatestExerciseTime().getHourMinuteTime()))); 
								exerciseProvisionType.setExerciseDateHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getAmerican().getExpirationDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA)); 
								exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->cancelableProvision.getAmerican().getCommencementDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
								
							}
							
							if(!XmlMappingUtil.IsNullOrBlank(cancelableProvision.getBermudan())) {
						
								exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getBermudan().getExpirationDate().getUnadjustedDate().get(0))); 
								exerciseProvisionType.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getBermudan().getExpirationTime().getHourMinuteTime()))); 
								exerciseProvisionType.setEarliestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getBermudan().getExpirationTime().getHourMinuteTime()))); 
								exerciseProvisionType.setLatestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getBermudan().getLatestExerciseTime().getHourMinuteTime()))); 
								exerciseProvisionType.setExerciseDateHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getBermudan().getExpirationDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA)); 
								exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->cancelableProvision.getBermudan().getExpirationDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
							}
							if(!XmlMappingUtil.IsNullOrBlank(cancelableProvision.getEuropean())) {
						
								exerciseProvisionType.setExpirationDate(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getEuropean().getExpirationDate().getUnadjustedDate())); 
								exerciseProvisionType.setExpirationTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getEuropean().getExpirationTime().getHourMinuteTime()))); 
								exerciseProvisionType.setEarliestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getEuropean().getExpirationTime().getHourMinuteTime()))); 
								exerciseProvisionType.setLatestExerciseTime(XmlMappingUtil.formatXMLGregorianCalendarTime(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getEuropean().getLatestExerciseTime().getHourMinuteTime()))); 
								exerciseProvisionType.setExerciseDateHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->cancelableProvision.getEuropean().getExpirationDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA)); 
								exerciseProvisionType.setExerciseDateBusinessDayConvention(XmlMappingUtil.getEnumString(()->cancelableProvision.getEuropean().getExpirationDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));
							}
				
		}
		return exerciseProvisionType;
	}
	

	public List<ReportingEligibilityType> getReportingEligibilityTypeData(TransactionType dsTrade, ObjectFactory objectFactory) 
	{
		
		List<ReportingEligibilityType> reportingPartyList = new ArrayList<ReportingEligibilityType>();
		RegulatoryType regulatory = dsTrade.getTrade().getTradeHeader().getTradeAttributes().getRegulatory();
		
		if(!XmlMappingUtil.IsListNullOrEmpty(regulatory.getReporting()))
		{
			for (ReportingEligible reportingEligibile : regulatory.getReporting()) 
			{
				ReportingEligibilityType reportingEligibilityType = objectFactory.createReportingEligibilityType();
				String jurKey=reportingEligibile.getJurisdiction();
				if(StringUtils.isNotBlank(reportingEligibile.getSubJurisdiction()))
				{
						jurKey=jurKey+DataServicesConstants.Dot+reportingEligibile.getSubJurisdiction();
						
				}	
				reportingEligibilityType.setReportingJurisdiction(XmlMappingUtil.getJurisdictionEnumString(jurKey,JurisdictionEnum.class));
				reportingEligibilityType.setSubJurisdictions(null);
				String repo=XmlMappingUtil.IsNullOrBlank(reportingEligibile.getRepository())?DataServicesConstants.DTCC_REPOSITORY:reportingEligibile.getRepository();
				reportingEligibilityType.setRepository(XmlMappingUtil.getEnumString(repo, GtrEnum.class));
				String delegateArr[]=StringUtils.split(reportingEligibile.getDelegatedModel(),DataServicesConstants.Dot);
				reportingEligibilityType.setDelegatedReporting(XmlMappingUtil.IsNullOrBlank(delegateArr)?null:delegateArr[0]);
				reportingEligibilityType.setReportingParty(XmlMappingUtil.getEnumString(reportingEligibile.getReportingParty(),UsThemEnum.class ));
				reportingPartyList.add(reportingEligibilityType);
			}
		}
		return reportingPartyList;
	}

	public CashFlowType getLegCashFlowData(LegType dsLegType, ObjectFactory objectFactory) 
	{
		logger.debug("Entering setCashFlowTypeData() method");
		CashFlowType cashFlowType =null;
		try 
		{
			List<AmortizationType> iasList = dsLegType.getAmortizationStepSchedule(); 
			boolean iasAvailable =	!XmlMappingUtil.IsListNullOrEmpty(iasList);
			List<CashFlowsType> nonIasList = dsLegType.getCashFlows();
			
			// STR-419 : Take cashflow float leg when indexFactor is gt lt 1.
			if(iasAvailable){
				
				boolean isFixed=FixedFloatEnum.FIXED.toString().equalsIgnoreCase(dsLegType.getType())?true:false;
				
				FixedFloatEnum fixedFloat = isFixed?FixedFloatEnum.FIXED:FixedFloatEnum.FLOAT;
				
				if(null != fixedFloat && fixedFloat.compareTo(FixedFloatEnum.FLOAT) == 0)
				{
					if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsLegType.getFloat().getFloatingRateMultiplierInitialValue()))) 
					{
						BigDecimal indexFactor = XmlMappingUtil.getFormatedValue(()->dsLegType.getFloat().getFloatingRateMultiplierInitialValue(), BigDecimal.class);
						
						if((null != indexFactor && (indexFactor.floatValue() < 1 || indexFactor.floatValue() > 1))){
							iasAvailable = false; 
						}
					}
				}
			} 			
			
			if(iasAvailable || !XmlMappingUtil.IsListNullOrEmpty(dsLegType.getCashFlows()))
			{
				
				cashFlowType = objectFactory.createCashFlowType();
				for (int i = 0; i < (iasAvailable ? iasList.size():nonIasList.size()); i++)  
				{
					final int j = i;
					CashFlow cashFlow = objectFactory.createCashFlowTypeCashFlow();
					cashFlow.setCashflowType(XmlMappingUtil.resolveIfNull(()->dsLegType.getCashFlows().get(j).getType()));
					cashFlow.setStartDate(iasAvailable?XmlMappingUtil.resolveIfNull(()->dsLegType.getAmortizationStepSchedule().get(j).getBeginPeriod()):XmlMappingUtil.resolveIfNull(()->dsLegType.getCashFlows().get(j).getStartDate()));
					cashFlow.setEndDate(iasAvailable?XmlMappingUtil.resolveIfNull(()->dsLegType.getAmortizationStepSchedule().get(j).getEndPeriod()):XmlMappingUtil.resolveIfNull(()->dsLegType.getCashFlows().get(j).getEndDate()));
					cashFlow.setPaymentDate(iasAvailable?XmlMappingUtil.resolveIfNull(()->dsLegType.getAmortizationStepSchedule().get(j).getPaymentDate()):XmlMappingUtil.resolveIfNull(()->dsLegType.getCashFlows().get(j).getPayDate()));
					cashFlow.setResetDate(XmlMappingUtil.resolveIfNull(()->dsLegType.getAmortizationStepSchedule().get(j).getResetDate()));
					cashFlow.setCashflowAmount(iasAvailable?XmlMappingUtil.getFormatedValue(()->dsLegType.getAmortizationStepSchedule().get(j).getInterestAmount(),BigDecimal.class):XmlMappingUtil.getFormatedValue(()->dsLegType.getCashFlows().get(j).getAmount(),BigDecimal.class));
					//cashFlow.setCashflowCurrency(dsLegType.getSettlementCurrency());
					BigDecimal cashFlowRate=iasAvailable?XmlMappingUtil.resolveIfNull(()->dsLegType.getAmortizationStepSchedule().get(j).getInterestRate()):XmlMappingUtil.resolveIfNull(()->dsLegType.getCashFlows().get(j).getFloatRate());
					cashFlow.setCashflowRate(parserService.parseBigDecimal(XmlMappingUtil.getFormatedValue(cashFlowRate,String.class)));
					cashFlow.setNotional(XmlMappingUtil.getFormatedValue(()->dsLegType.getAmortizationStepSchedule().get(j).getNotionalAmount(),BigDecimal.class));
					cashFlowType.getCashFlow().add(cashFlow);
				}
			}	
	
		} catch (Exception e) {
			logger.error("Error while executing getLeg1CashFlowData "+ e.getClass().getName(), e.fillInStackTrace());
			e.printStackTrace();
		}
		logger.debug("Exit setCashFlowTypeData() method");
		return cashFlowType;
	}
	

	public String getHarmonizedValue(Map<String, String> harmonizerMap,String hrmnKey) 
	{
		return harmonizerMap.get(hrmnKey);
	}

	
	
	



	public KeywordsType getTradeKeywordsData(TransactionType dsTrade,ObjectFactory objectFactory, Map<String, String> harmonizerMap) {
		
		Keyword keyObj=null;
		String value=null;
		KeywordsType keywordType=objectFactory.createKeywordsType();
		String[] jsonKeyWords={DataServicesConstants.Parent_KW_USI_CURRENT,DataServicesConstants.Parent_KW_UTI_CURRENT,DataServicesConstants.Parent_KW_LEI_CP,DataServicesConstants.KW_SDR_MarketType};
		
		for (String jsonKey : jsonKeyWords) 
		{
			value=harmonizerMap.get(jsonKey);
			
			 if(!XmlMappingUtil.IsNullOrBlank(value))
			 {
				 keyObj=getKeyObject(value,jsonKey,objectFactory);
				if(!XmlMappingUtil.IsNullOrBlank(keyObj)){
					 keywordType.getKeyword().add(keyObj);		
				 }
				
			 }
			
		}
		
		if(XmlMappingUtil.IsListNullOrEmpty(keywordType.getKeyword()))
			return null;
		
		return keywordType;
		
	}

	public Keyword getKeyObject(String value,String jsonKey,ObjectFactory objectFactory)
	{
		Keyword keyObj=null;
		if(!XmlMappingUtil.IsNullOrBlank(value))
		{
			keyObj = objectFactory.createKeywordsTypeKeyword();
			keyObj.setValue(value);
			keyObj.setName(jsonKey);
		
		}
		 return keyObj;
	}


	public String getDtccProductType(String dtccProduct) {
		String dtccProducttype[]=dtccProduct.split(":");
		String dtccProducttypes=dtccProducttype[1];
		
		return dtccProducttypes;
	}


	public String getDtccSubProductType(String dtccProduct) {
		String dtccSubProducttypes=null;
		if(!XmlMappingUtil.IsNullOrBlank(dtccProduct)){
		String dtccSubProducttype[]=dtccProduct.split(":");
		dtccSubProducttypes=dtccSubProducttype[2];
		}
		
		return dtccSubProducttypes;
		
	}


	public String getDtccProduct(String assetClass,String productType,String subproductType) {
		StringBuilder sb = new StringBuilder(100);
		sb.append(assetClass).append(":").append(productType);
		if (subproductType != null && !subproductType.equalsIgnoreCase("BLANK")) {
			sb.append(":").append(subproductType);
		}
		return sb.toString();
	}


	
	
	public BigDecimal getFormattedAmount(BigDecimal amount) {
		
		try 
		{
			if (!XmlMappingUtil.IsNullOrBlank(amount)){
				amount = parserService.parseBigDecimal(XmlMappingUtil.getFormatedValue(amount,String.class));
			}
		
		} catch (Exception e) {
			logger.error("Error while executing getFormattedAmount "+ e.getClass().getName(), e.fillInStackTrace());
			e.printStackTrace();
		}
		
		return amount;
	}


	public static String getOptionType(String optionType,String swaptionStraddle) {
		if(!XmlMappingUtil.IsNullOrBlank(swaptionStraddle))
		{
		if(Constants.TRUE.equalsIgnoreCase(swaptionStraddle)){
			return Constants.OPTION_STRADDLE;
		}
		
		if(Constants.FALSE.equalsIgnoreCase(swaptionStraddle) && !XmlMappingUtil.IsNullOrBlank(optionType))
		{
			if (Constants.RTP.equalsIgnoreCase(optionType))
					return Constants.PAYER;			
			if (Constants.RTR.equalsIgnoreCase(optionType))
					return Constants.RECEIVER;
			
		}
		}
		return Constants.EMPTY_STRING;
	}
		
}
