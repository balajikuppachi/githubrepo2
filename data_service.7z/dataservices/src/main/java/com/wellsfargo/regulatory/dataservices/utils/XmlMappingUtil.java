package com.wellsfargo.regulatory.dataservices.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EnumSet;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.util.function.Supplier;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;




/**
 * @author Shreekar
 * 
 * Util class to do formating while mapping.
 *
 */
/**
 * @author u236098
 *
 */
/**
 * @author u236098
 *
 */
@Component
public class XmlMappingUtil {
	
	public static final String FORMAT_1 = "HH:mm:ss";
	public static final String FORMAT_2 = "yyyy-MM-dd";
	
	private static TimeZone UTC = TimeZone.getTimeZone("GMT");

	private static  String[] datePatterns = new String[] {
		"MM/dd/yy hh:mm:ss a",
		"M/d/yy",
		"M/d/yy hh:mm:ss.S a z",
		"MM/dd/yy hh:mm:ss.S z",
		"MM/dd/yyyy hh:mm:ss a",
		"MM/dd/yy hh:mm:ss.S a z",
		"MM/dd/yy hh:mm:ss a z",
		"yyyy-MM-dd hh:mm:ss a",
		"yyyy-MM-dd'T' HH:mm:ss'Z'",
		"yyyy-MM-dd'T'HH:mm:ssz",
		"MM/dd/yyyy hh:mm:ss.S a z",
		"MM/dd/yyyy",
		"MMMMM dd, yyyy",
		"dd MMM yy",
		"yyyy-MM-dd",
		"MM-dd-yyyy",
		"yyyy-MM-dd'T'HH:mm:ss",
		"yyyy-MM-dd'T'HH:mm:ss'Z'",
		"yyyy-MM-dd'T'HHmmssZ",
		"yyyy-MM-dd'T'HH:mm:ss.Sz",
		"yyyy-MM-dd'T'HH:mm:ssXXX",
		
	};
		
	private static  String[] timePatterns = new String[] {
			"HHmm",
			"HH:mm:ss"
		};
	private static ThreadLocal<NumberFormat> parsingNumberFormat = new ThreadLocal<NumberFormat>() {
		@Override
		protected NumberFormat initialValue() {
			return NumberFormat.getInstance();
		}
	};
	
	
	
	
	public static String  parseNumber(String numberStr) throws ParseException {
		return parsingNumberFormat.get().parse(numberStr).toString();
	}
	
	private static Logger logger = Logger.getLogger(XmlMappingUtil.class.getName());
	
	public static Date parseTime(String strTime) throws ParseException {
		String adjustedStrTime = String.format("%4s", strTime).replace(" ", "0");
		return DateUtils.parseDate(adjustedStrTime, timePatterns );			
	}
	/**
	 * GetStvValue -get the stv value from context & return after casting
	 * 
	 * @param <T>
	 * @param uow
	 * @param requiredKey
	 * @param clz
	 * @return casted value
	 */
	public static <T> T getFormatedValue(Object requiredvalue, Class<T> clz) 
	{
		Object retVal = requiredvalue;
		try {
			
			if(retVal==null)
				return null;
			if (clz.equals(Boolean.class))
				return clz.cast(Boolean.parseBoolean(retVal.toString()));
			else if (clz.equals(BigDecimal.class))
				return clz.cast(new BigDecimal(parseNumber(retVal.toString())));  
			else if (clz.equals(Short.class))
				return clz.cast(Short.parseShort(retVal.toString()));
			else if (clz.equals(XMLGregorianCalendar.class) && requiredvalue instanceof String)
				return clz.cast(convertDateStringtoGregorianCalender(retVal.toString()));
			else if (clz.equals(String.class))
				return clz.cast(String.valueOf(retVal));
			else if (clz.equals(XMLGregorianCalendar.class) && requiredvalue instanceof XMLGregorianCalendar)
				return clz.cast(formatXMLGregorianCalendar((XMLGregorianCalendar)retVal));


		} catch (Exception e) {
			logger.warn("#### Error while formating Value:"+ requiredvalue +"-"+ e.getClass().getName(), e.fillInStackTrace());
			return null;
		}

		return clz.cast(retVal);
	}

	

	/**
	 * GetStvValue -get the stv value from context & return after casting
	 * 
	 * @param resolver
	 * @param clz
	 * @return
	 */
	public static<T, E> E getFormatedValue(Supplier<T> resolver, Class<E> clz) 
	{
		T requiredvalue=null;
	
		try {
		 	requiredvalue = resolver.get();
		 	return getFormatedValue(requiredvalue,clz);


		} catch (Exception e) {
			return null;
		}
		
	}
	
	/**
	 * @param requiredvalue
	 * @param enumClass
	 * @return
	 */
	public static <E extends Enum<E>> E getEnumString(Object requiredvalue, Class<E> enumClass) {
		
		Method declaredMethod=null;
		String lookUpvalue = (String)requiredvalue;
		try {
		
			if (StringUtils.isNotBlank(lookUpvalue)) {
				for (E en : EnumSet.allOf(enumClass)) 
				{
					if (en.name().equalsIgnoreCase(lookUpvalue.replace(DataServicesConstants.HYPHEN, DataServicesConstants.EMPTY_STRING))) {
						return en;
					}
				}
				
				boolean present=false;
				Method[] declaredMethods = enumClass.getDeclaredMethods();
				for (Method method : declaredMethods) {
					if(DataServicesConstants.fromValue.equals(method.getName()))
						present=true;	
				}
				
				if(present)
					declaredMethod=enumClass.getDeclaredMethod(DataServicesConstants.fromValue, String.class);
				if (!XmlMappingUtil.IsNullOrBlank(declaredMethod))
				{
					try
		            {
						@SuppressWarnings("unchecked")
		                E en=(E) declaredMethod.invoke(null,lookUpvalue);
						return en;
		            }
		            catch (Exception e)
		            {
						@SuppressWarnings("unchecked")
		                E en=(E) declaredMethod.invoke(null,lookUpvalue.replace(DataServicesConstants.HYPHEN, DataServicesConstants.EMPTY_STRING));
						return en;
		            }
				}
				
			}
		}
		catch (Exception e) {
			logger.warn("####Error while executing getEnumString "+ e.getClass().getName(), e.fillInStackTrace());
			//return enumClass.cast(DataServicesConstants.EMPTY_STRING);
		}
		return null;
	}
	
	public  static JurisdictionEnum  getJurisdictionEnumString(Object requiredvalue,Class<JurisdictionEnum> jurisEnumClass) {
		String lookUpvalue = (String)requiredvalue;
		String[] enumVal={"CAD.ON","CAD.QC","CAD.MB"};
		String[] posEnumVal={"CA.ON.OSC","CA.QC.AMF","CA.MB.MSC"};
		int index=ArrayUtils.indexOf(enumVal,lookUpvalue);
		if(index>=0)
			lookUpvalue=posEnumVal[index];
		
		if (StringUtils.isNotBlank(lookUpvalue)) {
			for (JurisdictionEnum en : EnumSet.allOf(jurisEnumClass)) {
				if (en.value().equalsIgnoreCase(lookUpvalue)) {
					return en;
				}
			}
		}
		return JurisdictionEnum.NONE;
	}	
	
	
	/**
	 * @param resolver
	 * @param enumClass
	 * @return
	 */
	public static <T,E extends Enum<E>> E getEnumString(Supplier<T> resolver, Class<E> enumClass) {
		
		T requiredvalue=null;
		try 
		{
			requiredvalue = resolver.get();
			return getEnumString(requiredvalue, enumClass);
		}
		catch (Exception e) {
			return null;
		}
	}
	
	
	/**
	 * convertDateStringtoGregorianCalender is used to convert string to date
	 * @param strDate
	 * @return XMLGregorianCalendar
	 */
	public static XMLGregorianCalendar convertDateStringtoGregorianCalender(String strDate) 
	{
		
		XMLGregorianCalendar xmlGregorianCalendar=null;
		try {
			GregorianCalendar c = new GregorianCalendar();
			if(StringUtils.isNotBlank(strDate)){
				c.setTime(DateUtils.parseDateStrictly(strDate, datePatterns));
				xmlGregorianCalendar= DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
			}
						
		} catch (DatatypeConfigurationException e) {
			logger.warn("#### DatatypeConfigurationException Error while executing convertDateStringtoGregorianCalender "+ e.getClass().getName(), e.fillInStackTrace());
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			logger.error("#### Parse Error while executing convertDateStringtoGregorianCalender "+ e.getClass().getName(), e.fillInStackTrace());
		}
		return xmlGregorianCalendar;
	}
	

	/**
	 * Concatenate the array of values & return the string (with or without delimeter)
	 * @param inputArray
	 * @param delimeter
	 * @return string
	 */
	public static String concatenateArrayValues(String[] inputArray,String delimeter)
	{
		String retStr = StringUtils.join(inputArray,delimeter);
		 
		if ( IsNullOrBlank(retStr) || retStr.equalsIgnoreCase(delimeter))
			return null;
		else 
			return retStr;
	}
	
	/**
	 * Concatenate the List of values & return the string (with or without delimeter)
	 * @param inputArray
	 * @param delimeter
	 * @return string
	 */
	public static String concatenateListValues(List<String> coll, String delimeter) {
		
		String retStr = StringUtils.join(coll,delimeter);
		 
		if ( IsNullOrBlank(retStr) || retStr.equalsIgnoreCase(delimeter))
			return null;
		else 
			return retStr;
	}
	
	/**
	 * getElementFromList - to return an string values from the list of the object after matching the specified condition
	 * @param listElement
	 * @param attributeName - The attribute used for condtion
	 * @param attributeValue - value to match the attributeName
	 * @param requiredAttribValue - Value to be returned
	 * @return string
	 */
	public static <T> String getElementFromList(List<T> listElement,String attributeName,String attributeValue,String requiredAttribValue)
	{
		try 
		{
			for (T element : listElement) 
			{
				Class<? extends Object> clsObj = element.getClass();
				Method method = clsObj.getMethod(DataServicesConstants.GET+attributeName);
				if(attributeValue.equalsIgnoreCase((String)method.invoke(element)))
					{
						return (String) clsObj.getMethod(DataServicesConstants.GET+requiredAttribValue).invoke(element);
					}
			}
			
		} catch (NoSuchMethodException | SecurityException e) {
			logger.warn("#### NoSuchMethodException Error while executing getElementFromList "+ e.getClass().getName(), e.fillInStackTrace());
		} catch (IllegalAccessException e) {
			logger.warn("#### IllegalAccessException Error while executing getElementFromList "+ e.getClass().getName(), e.fillInStackTrace());
		} catch (IllegalArgumentException e) {
			logger.warn("#### IllegalArgumentException Error while executing getElementFromList "+ e.getClass().getName(), e.fillInStackTrace());
		} catch (InvocationTargetException e) {
			logger.warn("#### InvocationTargetException Error while executing getElementFromList "+ e.getClass().getName(), e.fillInStackTrace());
		}
		return null;
	}
	
	

	public static String getElementAtIndex(String inputString, int index, String token)
	{
		String returnString = inputString;
		String[] arrayString = StringUtils.split(inputString, token);
		if(arrayString!=null && arrayString.length>1 && index < arrayString.length)
			returnString = arrayString[index];
		
		return returnString;
		
	}
	
	
	
	
	public static boolean IsNullOrBlank(Object obj) {

		if (obj instanceof String) {
			return ((String)obj).trim().length() == 0;
		} else if (obj == null) {
			return true;
		} else
			return false;
	}
	
	/**
	 * Function which accepts the lambda expression of nested getter calls, calls next function only if the previous call is non null 
	 * @param <E>
	 *  
	 * @param resolver - Nested getter calls
	 * @return String
	 */
	public static <T, E> T resolveIfNull(Supplier<T> resolver) {
	    try {
	    	
	        T result = resolver.get();
	        return  result ;
	    }
	   catch (NullPointerException e) {
	        return null;
	    }
	    catch(IndexOutOfBoundsException i){
	    	return null;
	    }
		
	}
	
	public static final boolean IsListNullOrEmpty(List<?> obj) {
		
		return (obj == null) || (((List<?>) obj).isEmpty());
		
	}
	
	public static final boolean IsNullOrNone(Object obj) {
		String s = null;
		if (obj instanceof String) {
			s = (String)obj;
			if(DataServicesConstants.NONE.equalsIgnoreCase(s.trim())){
				return true;
			} else if (DataServicesConstants.NOT_FOUND.equalsIgnoreCase(s.trim())) {
				return true;
			}
			return s.trim().length() == 0;
		} else if (obj == null) {
			return true;
		} else
			return false;
	}
	
    /**
	 * The method getGregorianCurrentDate
	 * @return 
	 * @throws DatatypeConfigurationException
	 */
	public static XMLGregorianCalendar getGregorianCurrentDate()			{
		XMLGregorianCalendar xmlGregorianCalendar=null;
		try {
			GregorianCalendar c = new GregorianCalendar();
			c.setTime(new Date());
		
			xmlGregorianCalendar= DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}
		return xmlGregorianCalendar;
	}

	public static String camelCase(String original)
	{
		if (StringUtils.isBlank(original)) return original;

		return original.substring(0, 1).toUpperCase() + original.substring(1).toLowerCase();
	}
	
	public static String getConvertedPeriod(String period) {
		
		String returnPeriod = period;
		if(null != period && "M".equalsIgnoreCase(period)) {
			returnPeriod = "MTH";
			
		}
		return returnPeriod;
	}

	private static XMLGregorianCalendar formatXMLGregorianCalendar(XMLGregorianCalendar calendar)
	{

		XMLGregorianCalendar xmlGregorianCalendar=null;
		try
		{
				
				GregorianCalendar c = new GregorianCalendar();
				if(!IsNullOrBlank(calendar)){
					c.setTime(DateUtils.parseDate(formatISODate(calendar),datePatterns));
					xmlGregorianCalendar= DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
				}
			
		} catch (DatatypeConfigurationException e) {
			logger.warn("#### DatatypeConfigurationException Error while executing formatXMLGregorianCalendar "+ e.getClass().getName(), e.fillInStackTrace());
		} catch (ParseException e) {
			logger.warn("#### Exception Error while executing formatXMLGregorianCalendar "+ e.getClass().getName(), e.fillInStackTrace());
		}		
	
		return xmlGregorianCalendar;

	}
	
	public static XMLGregorianCalendar formatXMLGregorianCalendarTime(XMLGregorianCalendar calendar)
	{
		 XMLGregorianCalendar xmlGregorianCalendar=null;
		try
		{
			
				GregorianCalendar cal=calendar.toGregorianCalendar();
				SimpleDateFormat sdf=new SimpleDateFormat(FORMAT_1);
				sdf.setTimeZone(UTC);
				String dateString = sdf.format(cal.getTime());
				cal.setTime(parseTime(dateString));
				xmlGregorianCalendar=DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
				xmlGregorianCalendar.setDay(DatatypeConstants.FIELD_UNDEFINED);
				xmlGregorianCalendar.setMonth(DatatypeConstants.FIELD_UNDEFINED);
				xmlGregorianCalendar.setYear(DatatypeConstants.FIELD_UNDEFINED);

		} catch (Exception e) {
			logger.warn("#### Exception Error while executing formatXMLGregorianCalendarTime for the format "+ FORMAT_1+" : Exception -> "+ e.getClass().getName(), e.fillInStackTrace());
		} 	

		return xmlGregorianCalendar;
	}
	
	public static BigDecimal formatNumber(BigDecimal number)  {
		
		BigDecimal retPrice=number;
			if(!XmlMappingUtil.IsNullOrNone((number))) {
				retPrice=  new BigDecimal(new DecimalFormat("#0.########").format(number));
			}	
		return retPrice;
	}
	
	public static String formatISODate(XMLGregorianCalendar calendar)
	{
	 	String text = calendar.toXMLFormat();
        int pos = text.indexOf('Z');
        return pos < 0 ? text : text.substring(0,pos) + "GMT+00:00";
	}
	
	
}
