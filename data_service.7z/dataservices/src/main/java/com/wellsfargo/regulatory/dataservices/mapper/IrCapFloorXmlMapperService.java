package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType.CashFlow;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DayTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.OptionTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayRelativeToEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.dataservices.bo.AmortizationType;
import com.wellsfargo.regulatory.dataservices.bo.CapFloorType;
import com.wellsfargo.regulatory.dataservices.bo.CashFlowsType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;


@Component
public class IrCapFloorXmlMapperService extends GenericXmlMapperService {


	private static Logger logger = Logger.getLogger(IrCapFloorXmlMapperService.class.getName());
	
	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setProductTypeData() method");
		
		ProductType productType = super.setProductTypeData(dsTrade, harmonizerMap);
		CapFloorType capFloor = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getCapFloor());
		productType.getLeg().addAll(setLegTypeData(dsTrade, harmonizerMap,capFloor));
		
		productType.setExerciseProvision(xmlMapperHelper.getExerciseProvisionTypeData(dsTrade, objectFactory));
		productType.setProductKeys(xmlMapperHelper.getProductKeysTypeData(dsTrade, objectFactory,harmonizerMap));
		productType.setKeywords(null);

		logger.info("Leaving setProductTypeData() method");

		return productType;
	}

	protected List<LegType> setLegTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap,CapFloorType capFloor) 
	{
		logger.info("Entering setLegTypeData() method");

		List<LegType> sdrRequestLegTypeList = new ArrayList<LegType>();
		LegType sdrRequestLegType = objectFactory.createLegType();
		com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg= XmlMappingUtil.resolveIfNull(()->capFloor.getCapFloorStream().get(0));
		sdrRequestLegType.setLegId((short) 1);
		BuySellEnum buySell=XmlMappingUtil.getEnumString(harmonizerMap.get(DataServicesConstants.HRMN_BUY_SELL), BuySellEnum.class);
		
		
		if(!XmlMappingUtil.IsNullOrBlank(dsLeg) )
		{	
			
			// STR-419
			sdrRequestLegType.setFixedFloat(FixedFloatEnum.FLOAT);
			
			if(BuySellEnum.BUY == buySell)
				sdrRequestLegType.setPayReceive(PayReceiveEnum.PAY);
			else
				sdrRequestLegType.setPayReceive(PayReceiveEnum.RECEIVE);
			sdrRequestLegType.setStartDate(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			sdrRequestLegType.setEndDate(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
			sdrRequestLegType.setSpread(XmlMappingUtil.getFormatedValue(()->dsLeg.getFloat().getFloatingRateSpreadInitial(),BigDecimal.class));
			sdrRequestLegType.setCurrency(dsLeg.getSettlementCurrency());
			sdrRequestLegType.setNotional(XmlMappingUtil.getFormatedValue(()->dsLeg.getNotionalAmount(),BigDecimal.class));
			sdrRequestLegType.setNotionalCurrency(dsLeg.getNotionalCurrency());
			if(!XmlMappingUtil.getFormatedValue(()->dsLeg.getCapRateInitial(),BigDecimal.class).equals(BigDecimal.ZERO))
			{
			sdrRequestLegType.setCapStrike(dsLeg.getCapRateInitial());
			}
			if(!XmlMappingUtil.getFormatedValue(()->dsLeg.getFloorRateInitial(),BigDecimal.class).equals(BigDecimal.ZERO))
			{
			sdrRequestLegType.setFloorStrike(dsLeg.getFloorRateInitial());
			}
			sdrRequestLegType.setRoundingPrecision(XmlMappingUtil.getFormatedValue(()->dsLeg.getRateIndexRoundingPrecision(),Short.class));
			sdrRequestLegType.setRoundingDirection(dsLeg.getRateIndexRoundingDirection());
			//change as per mapping
			sdrRequestLegType.setPaymentHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA));//getCalculationPeriodDatesAdjustments().getBusinessCenters().getBusinessCenter()), DataServicesConstants.COMMA));
			sdrRequestLegType.setPaymentDateOffset(XmlMappingUtil.getFormatedValue(()->dsLeg.getCalculationPeriodDates().getPaymentDate().getOffsetPeriod().getPeriodMultiplier(),String.class));
			sdrRequestLegType.setPaymentDateOffsetDayType(XmlMappingUtil.getEnumString(()->dsLeg.getFixed().getFixingDatesDayType(),DayTypeEnum.class));//dsLeg.getFixed().getFixingDatesDayType()
			sdrRequestLegType.setPayRelativeTo(XmlMappingUtil.getEnumString(()->dsLeg.getCalculationPeriodDates().getResetDate().getRelativeTo(),PayRelativeToEnum.class));
			sdrRequestLegType.setFirstPaymentDate(dsLeg.getFirstPeriodStartDate());
			sdrRequestLegType.setPaymentFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriodMultiplier()))); 
			sdrRequestLegType.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getSettlement().getSettlementDate()));
			
			sdrRequestLegType.setIndexName(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getRateIndex().getFloatingRateIndex()),1,DataServicesConstants.HYPHEN));
			
			sdrRequestLegType.setIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
			
			sdrRequestLegType.setIndexSource(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getRateIndex().getIndexSource()),2,DataServicesConstants.HYPHEN));
			sdrRequestLegType.setIndexCurrency(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getRateIndex().getIndexCurrency()),0,DataServicesConstants.HYPHEN));
			
			sdrRequestLegType.setResetOffsetDayType(XmlMappingUtil.getEnumString(()->dsLeg.getCalculationPeriodDates().getResetDate().getOffsetDayType(),DayTypeEnum.class));
			sdrRequestLegType.setRollConvention(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getCalculationPeriodFrequency().getRollConvention()));
			//change as per new mapping
			sdrRequestLegType.setBusinessDayConvention(XmlMappingUtil.getEnumString(dsLeg.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));//getCalculationPeriodDatesAdjustments().getBusinessDayConvention(), BusinessDayConventionEnum.class));
			sdrRequestLegType.setDayCountFraction(dsLeg.getDayCountFraction());
			
			sdrRequestLegType.setAmortizationFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLeg.getAmortizationParameters().getAmortizationFrequency().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLeg.getAmortizationParameters().getAmortizationFrequency().getPeriodMultiplier())));
			sdrRequestLegType.setOptionType(XmlMappingUtil.getEnumString(dsLeg.getOptionType(), OptionTypeEnum.class));
			//Added this mapping
			//sdrRequestLegType.setResetFrequency(XmlMappingUtil.resolveIfNull(()->dsLeg.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod()));
			
			sdrRequestLegType.setResetFrequency(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod(),String.class)},DataServicesConstants.COLON));
			sdrRequestLegType.setCashFlowSet(setCashFlowTypeData(dsTrade,harmonizerMap));
			
			if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getFloatingRateMultiplierInitialValue()))) {
				sdrRequestLegType.setIndexFactor(XmlMappingUtil.getFormatedValue(()->dsLeg.getFloat().getFloatingRateMultiplierInitialValue(), BigDecimal.class));
			}
			
			sdrRequestLegTypeList.add(sdrRequestLegType);
		}
		logger.info("Leaving setLegTypeData() method");

		return sdrRequestLegTypeList;
	}
	
	private CashFlowType setCashFlowTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) {
		logger.info("Entering setCashFlowTypeData() method");
		com.wellsfargo.regulatory.dataservices.bo.ProductType productTypeData = dsTrade.getTrade().getProduct();
		com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg=XmlMappingUtil.resolveIfNull(()->productTypeData.getInterestRate().getCapFloor().getCapFloorStream().get(0));
		CashFlowType cashFlowType = null;
		if(!XmlMappingUtil.IsNullOrBlank(dsLeg)) {
			List<AmortizationType> iasList = dsLeg.getAmortizationStepSchedule(); 
			boolean iasAvailable =	!XmlMappingUtil.IsListNullOrEmpty(iasList);
			List<CashFlowsType> nonIasList = dsLeg.getCashFlows();
			
			// STR-419
			if(iasAvailable){

				BigDecimal indexFactor = null;
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsLeg.getFloat().getFloatingRateMultiplierInitialValue()))) {
					indexFactor = XmlMappingUtil.getFormatedValue(()->dsLeg.getFloat().getFloatingRateMultiplierInitialValue(), BigDecimal.class);
				}
				
				if(null != indexFactor && (indexFactor.floatValue() < 1 || indexFactor.floatValue() > 1)){
					iasAvailable = false; 
				}
			} 
			
			if(iasAvailable || !XmlMappingUtil.IsListNullOrEmpty(nonIasList)) {
				cashFlowType = objectFactory.createCashFlowType();
				for (int i = 0; i < (iasAvailable ? iasList.size():nonIasList.size()); i++) {
						final int j = i;
						CashFlow cashFlow = objectFactory.createCashFlowTypeCashFlow();
						cashFlow.setCashflowType(XmlMappingUtil.resolveIfNull(()->dsLeg.getCashFlows().get(j).getType()));
						cashFlow.setStartDate(iasAvailable?XmlMappingUtil.resolveIfNull(()->dsLeg.getAmortizationStepSchedule().get(j).getBeginPeriod()):XmlMappingUtil.resolveIfNull(()->dsLeg.getCashFlows().get(j).getStartDate()));
						cashFlow.setEndDate(iasAvailable?XmlMappingUtil.resolveIfNull(()->dsLeg.getAmortizationStepSchedule().get(j).getEndPeriod()):XmlMappingUtil.resolveIfNull(()->dsLeg.getCashFlows().get(j).getEndDate()));
						cashFlow.setPaymentDate(iasAvailable?XmlMappingUtil.resolveIfNull(()->dsLeg.getAmortizationStepSchedule().get(j).getPaymentDate()):XmlMappingUtil.resolveIfNull(()->dsLeg.getCashFlows().get(j).getPayDate()));
						cashFlow.setResetDate(XmlMappingUtil.resolveIfNull(()->dsLeg.getAmortizationStepSchedule().get(j).getResetDate()));
						cashFlow.setCashflowAmount(iasAvailable?XmlMappingUtil.getFormatedValue(()->dsLeg.getAmortizationStepSchedule().get(j).getInterestAmount(),BigDecimal.class):XmlMappingUtil.getFormatedValue(()->dsLeg.getCashFlows().get(j).getAmount(),BigDecimal.class));
						//cashFlow.setCashflowCurrency(dsLeg.getSettlementCurrency());
						cashFlow.setCashflowRate(iasAvailable?XmlMappingUtil.getFormatedValue(()->dsLeg.getAmortizationStepSchedule().get(j).getInterestRate(),BigDecimal.class):XmlMappingUtil.getFormatedValue(()->dsLeg.getCashFlows().get(j).getFloatRate(),BigDecimal.class));
						cashFlow.setNotional(XmlMappingUtil.getFormatedValue(()->dsLeg.getAmortizationStepSchedule().get(j).getNotionalAmount(),BigDecimal.class));
						cashFlowType.getCashFlow().add(cashFlow);
					}
			}
		}
		logger.info("Leaving setCashFlowTypeData() method");
		return cashFlowType;
	}
}
