package com.wellsfargo.regulatory.dataservices.calc;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class EqStrikePriceCalc implements DataSevicesCalculation {

	@Override
	public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap,	Object[] inputArr) {

		String productType = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType());
		String assetType = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getTaxonomy().get(0).getAssetType());
		BigDecimal strikePrice=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getStrike().getStrikePrice());
		BigDecimal sellerStrikePrice=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getBuySellStrike().getSellerStrike());
		BigDecimal strikeFactor = null;
		
		if(DataServicesConstants.SRC_PRODUCT_TYPE_EQUITYOPTION.equals(productType) && DataServicesConstants.STRADDLE.equals(assetType)) {
			strikeFactor = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getEquity().getEquityOption().getFeature().getStraddle().getStrikeFactor());
		}
		if(!XmlMappingUtil.IsNullOrBlank(strikePrice))
			strikeFactor=strikePrice;
		else if(!XmlMappingUtil.IsNullOrBlank(sellerStrikePrice))
			strikeFactor=sellerStrikePrice;
		return strikeFactor;
	}

}
