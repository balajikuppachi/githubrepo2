package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType.CashFlow;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CdsTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CreditEventType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CreditEventType.CreditEvent;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DayTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EntityIdType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EntityIdType.EntityId;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.IndexInformationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.InstrumentIdEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.InstrumentIdType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.InstrumentIdType.InstrumentId;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.MortgageSectorEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ObligationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ObligationType.Obligation;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayRelativeToEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProtectionTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReferenceEntityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReferenceInformationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReferenceObligationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.dataservices.bo.CDSDeliveryCharacteristics;
import com.wellsfargo.regulatory.dataservices.bo.CashFlowsType;
import com.wellsfargo.regulatory.dataservices.bo.CreditDefaultSwap;
import com.wellsfargo.regulatory.dataservices.bo.FeeLeg;
import com.wellsfargo.regulatory.dataservices.bo.ProtectionTerms;
import com.wellsfargo.regulatory.dataservices.bo.ReferenceInformation;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

import static com.wellsfargo.regulatory.commons.bo.sdrRequest.InstrumentIdEnum.*;



/**
 * @author u236098
 * @date 05/29/2015
 * @version 1.0
 */
@Component
public class CrSingleNameXmlMapperService extends GenericXmlMapperService {
	
	private static Logger logger = Logger.getLogger(CrSingleNameXmlMapperService.class.getName());

	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) {
		ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
		CreditDefaultSwap dsCreditDefaultSwap = !XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap()))?dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwap():
			dsTrade.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap();
		productType.getLeg().addAll(setLegTypeData(dsTrade, productType,harmonizerMap,dsCreditDefaultSwap));
		productType.setCdsTerms(setCdsTermsType(dsTrade,harmonizerMap,dsCreditDefaultSwap));
		productType.setKeywords(null);

		return productType;
	}

	protected List<LegType> setLegTypeData(TransactionType dsTransaction, ProductType productType, Map<String, String> harmonizerMap,CreditDefaultSwap dsCreditDefaultSwap) {
		
		logger.info("Entering setLegTypeData() method");
		List<LegType> legTypeList = new ArrayList<LegType>();
		LegType legType = objectFactory.createLegType();
		
		legType.setLegId((short) 1);
		legType.setFixedFloat(FixedFloatEnum.FIXED);
		legType.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
		if(!XmlMappingUtil.IsNullOrBlank(dsCreditDefaultSwap)){
			
			FeeLeg dsFeeLegData = dsCreditDefaultSwap.getFeeLeg();
			legType.setStartDate( XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			legType.setEndDate( XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getScheduledTerminationDate()));
			legType.setCurrency( XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getProtectionTerms().get(0).getNotionalCurrency()));
			legType.setFixedRate(XmlMappingUtil.getFormatedValue(()->dsTransaction.getQuote().get(0).getValue(),BigDecimal.class));
			legType.setSettlementType(XmlMappingUtil.getEnumString(()->dsTransaction.getTrade().getProduct().getSettlement().getType(), SettlementTypeEnum.class));
			
			legType.setPaymentFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(dsFeeLegData.getCalculationPeriodFrequencyPeriod(),dsFeeLegData.getCalculationPeriodFrequencyPeriodMultiplier()));
			if(productType.getProductType().equals("CDSABSIndex")||productType.getProductType().equals("CDSIndex"))
			{
				BigDecimal legPrincipal=XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getProtectionTerms().get(0).getNotionalAmount());
				BigDecimal originalNotional=XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getProtectionTerms().get(0).getCDXOriginalNotionalAmount());
				legType.setNotional(!XmlMappingUtil.IsNullOrBlank(originalNotional)?originalNotional:legPrincipal);
			}
			else
				legType.setNotional(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getProtectionTerms().get(0).getNotionalAmount()));
			legType.setDayCountFraction(dsFeeLegData.getDayCountFraction());
			legType.setInterpIndexTenor(null);
			legType.setBusinessDayConvention(XmlMappingUtil.getEnumString(dsFeeLegData.getBusinessDayConvention() , BusinessDayConventionEnum.class));
			legType.setPaymentHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->dsFeeLegData.getBusinessCenters().getBusinessCenter()), DataServicesConstants.COMMA));
			legType.setPaymentDateOffsetDayType(XmlMappingUtil.getEnumString(XmlMappingUtil.resolveIfNull(()->dsFeeLegData.getPaymentDateOffset().getDayType()), DayTypeEnum.class));
			legType.setPaymentDateOffset(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getFeeLeg().getPaymentDateOffset().getPeriodMultiplier().toString()));
			if(!DataServicesConstants.CDSINDEXOPTION.equalsIgnoreCase(dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
			{
			if(DataServicesConstants.TRUE.equalsIgnoreCase(dsCreditDefaultSwap.getFeeLeg().getPaymentAtEndFlag()))
			{
				legType.setPayRelativeTo(PayRelativeToEnum.CALCULATION_PERIOD_END_DATE);
			}
			else if(DataServicesConstants.FALSE.equalsIgnoreCase(dsCreditDefaultSwap.getFeeLeg().getPaymentAtEndFlag()))
			{
				legType.setPayRelativeTo(PayRelativeToEnum.CALCULATION_PERIOD_START_DATE);
			}
			}
			legType.setSpread(XmlMappingUtil.getFormatedValue(()->XmlMappingUtil.getElementFromList(dsTransaction.getQuote(), DataServicesConstants.MeasureType, DataServicesConstants.ExecutedSpread, DataServicesConstants.Value), BigDecimal.class));
			BigDecimal price=XmlMappingUtil.formatNumber(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getProtectionTerms().get(0).getExecutionPrice()));
			legType.setPrice(XmlMappingUtil.IsNullOrBlank(price)?new BigDecimal(0.00):price);
		}
		
		legType.setCashFlowSet(setCashflowDataList(dsTransaction,harmonizerMap,dsCreditDefaultSwap));
		legTypeList.add(legType);
		
		logger.info("Leaving setLegTypeData() method");

		return legTypeList;
	}
	


	private CashFlowType setCashflowDataList(TransactionType dsTransaction, Map<String, String> harmonizerMap, CreditDefaultSwap dsCreditDefaultSwap) 
	{
		
		logger.info("Entering setCashFlowTypeData() method");
		
		CashFlowType cashFlowType = objectFactory.createCashFlowType();
		List <CashFlowsType> dsCashFlowsTypeListData = dsCreditDefaultSwap.getFeeLeg().getCashFlow();
		if(!XmlMappingUtil.IsListNullOrEmpty(dsCashFlowsTypeListData))
		{
			for (CashFlowsType cashFlowsType : dsCashFlowsTypeListData) {
				CashFlow cashflowData = objectFactory.createCashFlowTypeCashFlow();
				
				cashflowData.setCashflowType(cashFlowsType.getType());
				cashflowData.setStartDate(cashFlowsType.getStartDate());
				cashflowData.setEndDate(cashFlowsType.getEndDate());
				cashflowData.setPaymentDate(cashFlowsType.getPayDate());
				cashflowData.setCashflowAmount(XmlMappingUtil.getFormatedValue(()->cashFlowsType.getAmount(),BigDecimal.class));
				cashflowData.setCashflowRate(cashFlowsType.getFloatRate());
				
				cashFlowType.getCashFlow().add(cashflowData);
				
			}
		}
		logger.info("Leaving setCashFlowTypeData() method");
		
		return cashFlowType;
	}

	protected CdsTermsType setCdsTermsType(TransactionType dsTransaction, Map<String, String> harmonizerMap, CreditDefaultSwap dsCreditDefaultSwap) {
		
		logger.info("Entering getCdsTermsType() method");
		
		CdsTermsType cdsTermsType= objectFactory.createCdsTermsType();
		ReferenceInformationType referenceInformationType = objectFactory.createReferenceInformationType();
		ReferenceEntityType referenceEntityType = objectFactory.createReferenceEntityType();
				
		referenceEntityType.setEntityName(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation().getReferenceEntity()));
		referenceEntityType.setEntityIds(getEntityIdsData(harmonizerMap, dsCreditDefaultSwap));
		
		referenceInformationType.setReferenceEntity(referenceEntityType);
		referenceInformationType.setReferenceObligation(setReferenceObligationTypeData(dsCreditDefaultSwap,harmonizerMap));
		referenceInformationType.setReferencePrice(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation().getReferencePrice()));
		
		ProtectionTermsType protectionTermsType = objectFactory.createProtectionTermsType();
		String interestShortCap=XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getProtectionTerms().get(0).getInterestShortfallCapApplicable());
		if(!XmlMappingUtil.IsNullOrBlank(interestShortCap) || !DataServicesConstants.FALSE.equalsIgnoreCase(interestShortCap)  )
		{
			protectionTermsType.setInterestShortfallCap(interestShortCap);
		}
		else
		{
		protectionTermsType.setInterestShortfallCap(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getProtectionTerms().get(0).getInterestShortfallCapBasis()));
		}
		protectionTermsType.setInterestShortfallCompounding(XmlMappingUtil.getFormatedValue(dsCreditDefaultSwap.getProtectionTerms().get(0).getInterestShortfallCompoundingApplicable(),Boolean.class));
		protectionTermsType.setCurrentNotional(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeLifeCycle().getDecreasedAmount().getAmount()));
		protectionTermsType.setObligations(setObligationsType(dsCreditDefaultSwap, harmonizerMap));
		protectionTermsType.setCreditEvents(setCreditEventsType(dsCreditDefaultSwap, harmonizerMap));
		
		
		cdsTermsType.setEffectiveDate(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
		cdsTermsType.setTerminationDate(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getScheduledTerminationDate()));
		cdsTermsType.setHolidays(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessDayConvention()));
		//cdsTermsType.setPartialCashSettlement(XmlMappingUtil.resolveIfNull(()->XmlMappingUtil.getFormatedValue(dsTransaction.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getProtectionTerms().get(0).getCDSPartialCashSettleLoans(),boolean.class)));
		cdsTermsType.setCreditSeniority(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation().getSeniority()));
		cdsTermsType.setDtccIsssuerRegion(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation().getDTCCIssuerRegion()));
		cdsTermsType.setFirstPaymentDate(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getFeeLeg().getFirstPaymentDate()));
		
		cdsTermsType.setReferenceInformation(referenceInformationType);
		cdsTermsType.getProtectionTerms().add(protectionTermsType);
		
		if(DataServicesConstants.SRC_PRODUCT_TYPE_CDSINDEXTRANCHE.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType())) 
				|| DataServicesConstants.SRC_PRODUCT_TYPE_ABSCDO.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
				|| DataServicesConstants.SRC_PRODUCT_TYPE_CDSABSINDEX.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
				|| DataServicesConstants.SRC_PRODUCT_TYPE_CDSINDEX.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
				|| DataServicesConstants.SRC_PRODUCT_TYPE_CDSNTHLOSS.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
				|| DataServicesConstants.SRC_PRODUCT_TYPE_CDSINDEXOPTION.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
				|| DataServicesConstants.SRC_PRODUCT_TYPE_CDSSTRUCTPROD.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
				|| DataServicesConstants.SRC_PRODUCT_TYPE_STRUCTURED_PRODUCT.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType()))
				|| DataServicesConstants.SRC_PRODUCT_TYPE_SCDO.equalsIgnoreCase(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType())))
			
		{
			cdsTermsType.setIndexInformation(setIndexInformationType(dsCreditDefaultSwap,harmonizerMap));
		}
		
		
		
		logger.info("Leaving getCdsTermsType() method");

		return cdsTermsType;
	}
	
	
	private ReferenceObligationType setReferenceObligationTypeData(CreditDefaultSwap dsCreditDefaultSwap, Map<String, String> harmonizerMap) {
		
		ReferenceObligationType referenceObligationType = objectFactory.createReferenceObligationType();
		ReferenceInformation  dsReferenceInformation =  dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation();
		if(!XmlMappingUtil.IsNullOrBlank(dsReferenceInformation))
		{
			referenceObligationType.setObligationType(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation().getReferenceObligationType()));
			referenceObligationType.setCouponRate(XmlMappingUtil.getFormatedValue(dsReferenceInformation.getCouponRate(),BigDecimal.class));
			referenceObligationType.setCurrency(XmlMappingUtil.IsNullOrBlank(dsReferenceInformation.getCurrency())?dsCreditDefaultSwap.getProtectionTerms().get(0).getNotionalCurrency():dsReferenceInformation.getCurrency());
			String faceAmount=StringUtils.trimToEmpty(XmlMappingUtil.getFormatedValue(dsReferenceInformation.getFaceAmount(), String.class));
			if(faceAmount.equalsIgnoreCase("0"))
				faceAmount=XmlMappingUtil.getFormatedValue(dsCreditDefaultSwap.getFeeLeg().getSinglePaymentAmount(), String.class);
			if(!XmlMappingUtil.IsNullOrBlank(faceAmount)){
			referenceObligationType.setFaceAmount(XmlMappingUtil.getFormatedValue(faceAmount, String.class));
			}
			referenceObligationType.setMaturityDate(dsReferenceInformation.getMaturity());
			referenceObligationType.setInitialFactor(XmlMappingUtil.getFormatedValue(dsReferenceInformation.getInitialFactor(), BigDecimal.class));
			referenceObligationType.setSector(XmlMappingUtil.getEnumString(dsReferenceInformation.getDTCCCDXSector(),MortgageSectorEnum.class));
			referenceObligationType.setInstrumentIds(getInstrumentIdTypeData(dsCreditDefaultSwap, harmonizerMap));
					
			
		}
		
		
		return referenceObligationType;
	}
	
	
	private CreditEventType setCreditEventsType(CreditDefaultSwap dsCreditDefaultSwap, Map<String, String> harmonizerMap) {
		logger.info("Entering setCreditEventsType() method");
		
		CreditEventType creditEventType = objectFactory.createCreditEventType();
		CreditEvent creditEvent = objectFactory.createCreditEventTypeCreditEvent();
		ProtectionTerms dsProtectionTerms = dsCreditDefaultSwap.getProtectionTerms().get(0);
		List<com.wellsfargo.regulatory.dataservices.bo.CreditEvent> dsCreditEventList = dsProtectionTerms.getCreditEvent();
		if(!XmlMappingUtil.IsListNullOrEmpty(dsCreditEventList))
		{
			for (com.wellsfargo.regulatory.dataservices.bo.CreditEvent dsCreditEvent : dsCreditEventList) {
					creditEvent = objectFactory.createCreditEventTypeCreditEvent();
					creditEvent.setName(dsCreditEvent.getSrcEventType());
					creditEvent.setValue(DataServicesConstants.TRUE);
					creditEventType.getCreditEvent().add(creditEvent);
			}
		}
		return creditEventType;
	}

	private EntityIdType getEntityIdsData(Map<String, String> harmonizerMap, CreditDefaultSwap dsCreditDefaultSwap) {
		logger.info("Entering getEntityIdsData() method");

		EntityIdType entityIdType = objectFactory.createEntityIdType();
		EntityId entityId = objectFactory.createEntityIdTypeEntityId();
		entityId.setValue(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation().getReferenceEntity()));
		entityId.setType("BespokeBasket");
		
		entityIdType.getEntityId().add(entityId);

		logger.info("Leaving getEntityIdsData() method");

		return entityIdType;
	}
	
	private ObligationType setObligationsType(CreditDefaultSwap dsCreditDefaultSwap, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering setObligationsType() method");
		
		ObligationType obligationType = objectFactory.createObligationType();
		Obligation obligation  = null;
		ProtectionTerms dsProtectionTerms = dsCreditDefaultSwap.getProtectionTerms().get(0);
		obligationType.setCategory(dsCreditDefaultSwap.getProtectionTerms().get(0).getCDSDeliverableObligationType());
		List<CDSDeliveryCharacteristics> dsCDSDeliveryCharacteristicsList = dsProtectionTerms.getCDSDeliveryCharacteristics();
		
		if(!XmlMappingUtil.IsListNullOrEmpty(dsCDSDeliveryCharacteristicsList))
		{
		
			for (CDSDeliveryCharacteristics dsCDSDeliveryCharacteristics : dsCDSDeliveryCharacteristicsList) {
				obligation = objectFactory.createObligationTypeObligation();
				obligation.setName(dsCDSDeliveryCharacteristics.getCharacteristic());
				//obligation.setValue(dsCDSDeliveryCharacteristics.getValue());
				obligation.setValue( null != dsCDSDeliveryCharacteristics.getValue() ? dsCDSDeliveryCharacteristics.getValue() : "true");
				obligationType.getObligation().add(obligation);
			}
		}
		
		logger.info("Leaving setObligationsType() method");

		return obligationType;
		
	}
	
	private InstrumentIdType getInstrumentIdTypeData(CreditDefaultSwap dsCreditDefaultSwap, Map<String, String> harmonizerMap) {
		
		logger.info("Entering getInstrumentIdTypeData() method");
		
		InstrumentIdType instrumentIdType = new InstrumentIdType();
		InstrumentId instrumerntId =null;
		List<com.wellsfargo.regulatory.dataservices.bo.Instrument>  dsInstrumentList = 	XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation().getInstrumentId());
		String instrumentTypeArr[]={CUSIP.toString(),ISIN.toString(),RED_PAIR.toString(),RIC.toString(),BLOOMBERG.toString(),SEDOL.toString(),BespokeBasket.toString(),BASKET.toString(),INDEX.toString(),UPI.toString()};
		String instrumentStr=null;
		if(!XmlMappingUtil.IsListNullOrEmpty(dsInstrumentList))
		{
			for ( com.wellsfargo.regulatory.dataservices.bo.Instrument dsInstrument : dsInstrumentList ) {
				if(!XmlMappingUtil.IsNullOrNone(dsInstrument.getInstrumentId()))
				{
					instrumerntId =objectFactory.createInstrumentIdTypeInstrumentId();
					instrumentStr=dsInstrument.getInstrumentType();
					if(dsInstrument.getInstrumentType().startsWith(DataServicesConstants.Red))
						instrumentStr=InstrumentIdEnum.RED_PAIR.toString();
					if(ArrayUtils.contains(instrumentTypeArr, instrumentStr))
					{
						instrumerntId.setType(XmlMappingUtil.getEnumString(instrumentStr, InstrumentIdEnum.class));
						instrumerntId.setValue(dsInstrument.getInstrumentId());
						instrumentIdType.getInstrumentId().add(instrumerntId);
					}
				}
		
			}
		}
		
		logger.info("Leaving getInstrumentIdTypeData() method");

		if(XmlMappingUtil.IsListNullOrEmpty(instrumentIdType.getInstrumentId()))
		{
			instrumerntId = objectFactory.createInstrumentIdTypeInstrumentId();
			instrumerntId.setType(InstrumentIdEnum.BespokeBasket);
			instrumerntId.setValue(InstrumentIdEnum.BespokeBasket.toString());
			instrumentIdType.getInstrumentId().add(instrumerntId);
		}
		return instrumentIdType;

	}

	
	private IndexInformationType setIndexInformationType(CreditDefaultSwap dsCreditDefaultSwap, Map<String, String> harmonizerMap) {
		
		IndexInformationType indexInformationType =null;
		logger.info("Entering setIndexInformationType() method");
		ReferenceInformation referenceInformation = dsCreditDefaultSwap.getGeneralTerms().getReferenceInformation();
		if(!XmlMappingUtil.IsNullOrBlank(referenceInformation))
		{
			indexInformationType = objectFactory.createIndexInformationType();
			indexInformationType.setIndexName(referenceInformation.getReferenceEntity());
			indexInformationType.setIndexAnnexDate(XmlMappingUtil.resolveIfNull(()->dsCreditDefaultSwap.getGeneralTerms().getAnnexDate()));
			indexInformationType.setAttachmentPoint(referenceInformation.getAttachmentPoint());
			indexInformationType.setDetachmentPoint(referenceInformation.getExhaustionPoint());
			indexInformationType.setIndexAnnexSource(referenceInformation.getSettledEntityMatrixSource());
			indexInformationType.setIndexSeries(null);
			indexInformationType.setIndexVersion(null);
		}
	
		logger.info("Leaving setIndexInformationType() method");
		
		return indexInformationType;
	}
	


}
