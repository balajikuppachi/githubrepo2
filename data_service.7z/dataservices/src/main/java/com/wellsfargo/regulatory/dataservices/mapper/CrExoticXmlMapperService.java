package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CdsTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.dataservices.bo.CreditDefaultSwap;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

/**
 * updated - U236098
 * @date 06/01/2015
 * @version 1.0
 */

@Component
public class CrExoticXmlMapperService extends CrSingleNameXmlMapperService {

	private static Logger logger = Logger.getLogger(CrExoticXmlMapperService.class.getName());

	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) {
		
		logger.info("Entering setProductTypeData() method");
		
		ProductType productType = super.setProductTypeData(dsTrade, harmonizerMap);
		productType.getLeg().addAll(setLegTypeData(dsTrade,productType, harmonizerMap));
		productType.setKeywords(null);
		productType.setCdsTerms(setCdsTermsType(dsTrade,productType, harmonizerMap));
		
		logger.info("Leaving setProductTypeData() method");

		return productType;
	}

	private CdsTermsType setCdsTermsType(TransactionType dsTransaction, ProductType productType, Map<String, String> harmonizerMap) {
		 CreditDefaultSwap dsCreditDefaultSwap = XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap());
		 return super.setCdsTermsType(dsTransaction, harmonizerMap, dsCreditDefaultSwap);
	}


	private List<LegType> setLegTypeData(TransactionType dsTransaction, ProductType productType, Map<String, String> harmonizerMap) {
		
		logger.info("Entering setLegTypeData() method");
		
		 CreditDefaultSwap dsCreditDefaultSwap = XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap());
		 List<LegType> legTypeList = super.setLegTypeData(dsTransaction, productType, harmonizerMap, dsCreditDefaultSwap);
	
		
		
		logger.info("Leaving setLegTypeData() method");

		return legTypeList;
	}

}
