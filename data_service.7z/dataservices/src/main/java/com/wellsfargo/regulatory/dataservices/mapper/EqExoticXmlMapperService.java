package com.wellsfargo.regulatory.dataservices.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityUnderlyingAssetType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.dataservices.bo.GenericType;
import com.wellsfargo.regulatory.dataservices.bo.GenericUnderlyer;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class EqExoticXmlMapperService extends EqSwapXmlMapperService {

private static Logger logger = Logger.getLogger(EqExoticXmlMapperService.class.getName());

	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering EqExoticXmlMapperService --> setProductTypeData() method");

		ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
		productType.setKeywords(null);
		productType.getLeg().clear();
		productType.getLeg().addAll(this.setLegTypeData(dsTrade,productType,harmonizerMap));
		productType.setEquityTerms(getEquityTermsData(dsTrade,harmonizerMap));
	
		logger.info("Leaving EqExoticXmlMapperService --> setProductTypeData() method");

		return productType;
	}

	
	protected List<LegType> setLegTypeData(TransactionType dsTrade,ProductType productType, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering EqExoticXmlMapperService --> setLegTypeData() method");

		List<LegType> legTypeList = new ArrayList<LegType>();
		LegType legType = objectFactory.createLegType();	
		legType.setLegId((short) 1);

		GenericType genericProduct = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getGenericProduct());
		
		//legType.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
		if (!XmlMappingUtil.IsNullOrBlank(genericProduct))
		{
			legType.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()->genericProduct.getSettlementCurrency()));
			legType.setSettlementType(XmlMappingUtil.getEnumString(XmlMappingUtil.resolveIfNull(()->genericProduct.getSettlementType()),SettlementTypeEnum.class));
			legType.setStartDate(XmlMappingUtil.resolveIfNull(()->genericProduct.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			legType.setEndDate(XmlMappingUtil.resolveIfNull(()->genericProduct.getTerminationDate().getTerminationDate()));
			legType.setNotional(XmlMappingUtil.resolveIfNull(()->genericProduct.getNotional().get(0).getAmount()));
			legType.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->genericProduct.getNotional().get(0).getCurrency()));
			legType.setEndDate(XmlMappingUtil.resolveIfNull(()->genericProduct.getTerminationDate().getTerminationDate()));
			legType.setPayReceive(PayReceiveEnum.PAY);
			legType.setFixedFloat(FixedFloatEnum.FLOAT); // TODO
		}
		
		legTypeList.add(legType);
	
		logger.info("Leaving EqExoticXmlMapperService --> setLegTypeData() method");

		return legTypeList;
	}
	
	protected EquityTermsType getEquityTermsData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering EqExoticXmlMapperService --> getEquityTermsData() method");

		GenericType genericProduct = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getGenericProduct());

		EquityTermsType equityTermsType = objectFactory.createEquityTermsType();
		
		
		if ( !XmlMappingUtil.IsNullOrBlank(genericProduct))
		{
			equityTermsType.setEmbeddedOption((XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getProduct().getEmbeddedOption(), Boolean.class)));
			equityTermsType.setNonStandardFlag(XmlMappingUtil.getFormatedValue(()->dsTrade.getTrade().getTradeHeader().getTradeAttributes().getRegulatory().getNonstandardFlag(), Boolean.class)); 
			//equityTermsType.setValuationFrequencyPeriod(XmlMappingUtil.getConvertedPeriod(XmlMappingUtil.resolveIfNull(()->returnLeg.getRateOfReturn().getValuationRules().getCalculationPeriodFrequency().getPeriod())));
			//equityTermsType.setValuationFrequencyPeriodMultiplier(new BigDecimal(XmlMappingUtil.resolveIfNull(()->returnLeg.getRateOfReturn().getValuationRules().getCalculationPeriodFrequency().getPeriodMultiplier())));
			equityTermsType.getUnderlyingAsset().addAll(setUnderlyingAssetData(dsTrade));
			
		}
		
		
		logger.info("Leaving EqExoticXmlMapperService --> getEquityTermsData() method");
		
		return equityTermsType;
	}
	
	private List<EquityUnderlyingAssetType> setUnderlyingAssetData(TransactionType dsTrade) 
	{
		
		logger.info("Entering EqExoticXmlMapperService --> setUnderlyingAssetData() method");
		
		GenericType genericProduct = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getGenericProduct());

		EquityUnderlyingAssetType equityUnderlyingAssetType = null;
		List<EquityUnderlyingAssetType> listEquityUnderlyingAssetType = new ArrayList<EquityUnderlyingAssetType>();
		equityUnderlyingAssetType = objectFactory.createEquityUnderlyingAssetType();
	
		
		if (!XmlMappingUtil.IsNullOrBlank(genericProduct))
		{
			GenericUnderlyer dsGenericUnderlyer = XmlMappingUtil.resolveIfNull(()->genericProduct.getUnderlyer().get(0).getBasket().getBasketConstituent().get(0).getGeneric());
			
			if (! XmlMappingUtil.IsNullOrBlank(dsGenericUnderlyer))
			{
				equityUnderlyingAssetType.setInstrumentId(XmlMappingUtil.resolveIfNull(()->dsGenericUnderlyer.getInstrument().getInstrumentId()));
				equityUnderlyingAssetType.setInstrumentIdType(XmlMappingUtil.resolveIfNull(()->dsGenericUnderlyer.getInstrument().getInstrumentType()));
				equityUnderlyingAssetType.setBasketExchange(XmlMappingUtil.resolveIfNull(()->dsGenericUnderlyer.getExchangeId()));
			}
			
		//	equityUnderlyingAssetType.setNumberOfUnits(XmlMappingUtil.resolveIfNull(()->genericProduct.getUnderlyer().get(0).getBasket().getBasketConstituent().get(0).getConstituentWeight().getOpenUnits()));
			equityUnderlyingAssetType.setNotional(XmlMappingUtil.resolveIfNull(()->genericProduct.getNotional().get(0).getAmount()));
		//	equityUnderlyingAssetType.setBasketInitialPrice(XmlMappingUtil.resolveIfNull(()->varianceLeg.getAmount().getVariance().getInitialLevel()));
			equityUnderlyingAssetType.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->genericProduct.getSettlementCurrency()));
			
			listEquityUnderlyingAssetType.add(equityUnderlyingAssetType);	
		}
		
	
		logger.info("Leaving EqExoticXmlMapperService --> setUnderlyingAssetData() method");

		return listEquityUnderlyingAssetType;
	}

	protected LifeCycleType setLifeCycleEventData(TransactionType dsTrade,Map<String, String> harmonizerMap,TradeHeaderType tradeHeaderType) 
	{
		LifeCycleType lifeCycle = tradeHeaderType.getLifeCycle();
		
		GenericType genericProduct = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getGenericProduct());
		
		lifeCycle.setEventEffectiveDate(XmlMappingUtil.resolveIfNull(()->genericProduct.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
		
		return lifeCycle;
	}

	
}
