package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityUnderlyingAssetType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.bo.VarianceSwapLegType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class EqVarSwapXmlMapperService extends EqSwapXmlMapperService {

	private static Logger logger = Logger.getLogger(EqVarSwapXmlMapperService.class.getName());
	
	protected List<LegType> setLegTypeData(TransactionType dsTrade,ProductType productType, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering EqVarSwapXmlMapperService --> setLegTypeData() method");

		List<LegType> legTypeList = new ArrayList<LegType>();
		LegType legType = objectFactory.createLegType();	
		legType.setLegId((short) 1);
		
		VarianceSwapLegType varianceLeg = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getVarianceSwap().getVarianceLeg());
		
		
		if (! XmlMappingUtil.IsNullOrBlank(varianceLeg))
		{

			legType.setSettlementType(XmlMappingUtil.getEnumString(varianceLeg.getSettlement().getSettlementType(),SettlementTypeEnum.class));
			legType.setSettlementCurrency(XmlMappingUtil.resolveIfNull(()->varianceLeg.getSettlement().getSettlementCurrency()));
			legType.setStartDate(XmlMappingUtil.resolveIfNull(()->varianceLeg.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
			legType.setEndDate(XmlMappingUtil.resolveIfNull(()->varianceLeg.getTerminationDate().getUnadjustedDate()));
			legType.setPayReceive(PayReceiveEnum.PAY);
			legType.setFixedFloat(FixedFloatEnum.FLOAT);
			/*BuySellEnum buySell = productType.getBuySell();
			if (BuySellEnum.BUY == buySell){
				legType.setPayReceive(PayReceiveEnum.PAY);
			}
			else {
				legType.setPayReceive(PayReceiveEnum.RECEIVE);
			}	*/		
			
			//QC-774
			legType.setNotional(XmlMappingUtil.resolveIfNull(()->varianceLeg.getAmount().getVariance().getVarianceAmount().getAmount()));
		}
		
		legTypeList.add(legType);
	
		logger.info("Leaving EqVarSwapXmlMapperService --> setLegTypeData() method");

		return legTypeList;
	}
	
	protected EquityTermsType getEquityTermsData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("Entering EqVarSwapXmlMapperService --> getEquityTermsData() method");

		
		VarianceSwapLegType varianceLeg = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getVarianceSwap().getVarianceLeg());

		EquityTermsType equityTermsType = objectFactory.createEquityTermsType();
		
		if (! XmlMappingUtil.IsNullOrBlank(varianceLeg))
		{
			equityTermsType.setVegaNotional(XmlMappingUtil.resolveIfNull(()->varianceLeg.getAmount().getVariance().getVegaNotionalAmount()));
			equityTermsType.setEquityVarianceStrikePrice(XmlMappingUtil.resolveIfNull(()->varianceLeg.getAmount().getVariance().getVarianceStrikePrice()));
			equityTermsType.setFinalValuationDate(XmlMappingUtil.convertDateStringtoGregorianCalender((XmlMappingUtil.resolveIfNull(()->harmonizerMap.get(DataServicesConstants.HRMN_VALUATION_DATE)))));
			equityTermsType.setValuationFrequencyPeriodMultiplier(new BigDecimal(XmlMappingUtil.resolveIfNull(()->varianceLeg.getValuation().getDateOffset().getPeriodMultiplier())));
			equityTermsType.setValuationFrequencyPeriod(XmlMappingUtil.getConvertedPeriod(XmlMappingUtil.resolveIfNull(()->varianceLeg.getValuation().getDateOffset().getPeriod())));
			equityTermsType.getUnderlyingAsset().addAll(setUnderlyingAssetData(dsTrade));
		}
		//equityTermsType.setValuationDates(getValuatioinDateData(valuationDates,uow));
		
		logger.info("Leaving EqVarSwapXmlMapperService --> getEquityTermsData() method");
		
		return equityTermsType;
	}
	
	private List<EquityUnderlyingAssetType> setUnderlyingAssetData(TransactionType dsTrade) 
	{
		
		logger.info("Entering EqVarSwapXmlMapperService --> setUnderlyingAssetData() method");
		
		VarianceSwapLegType varianceLeg = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getVarianceSwap().getVarianceLeg());
		
		EquityUnderlyingAssetType equityUnderlyingAssetType = null;
		List<EquityUnderlyingAssetType> listEquityUnderlyingAssetType = new ArrayList<EquityUnderlyingAssetType>();
		equityUnderlyingAssetType = objectFactory.createEquityUnderlyingAssetType();
		String subProductType=dsTrade.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType();
		String instrumentIdType=null;
		String instrumentId=null;
		String exchangeId=null;
		if(subProductType.contains("Share"))
		{
			instrumentIdType=XmlMappingUtil.resolveIfNull(()->varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getEquity().getInstrument().getInstrumentType());
		  	instrumentId=XmlMappingUtil.resolveIfNull(()->varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getEquity().getInstrument().getInstrumentId());
		  	exchangeId=varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getEquity().getExchangeId();
		}
		else if(subProductType.contains("Basket"))
		{
			instrumentIdType=XmlMappingUtil.resolveIfNull(()->varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getGeneric().getInstrument().getInstrumentType());
			instrumentId=XmlMappingUtil.resolveIfNull(()->varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getGeneric().getInstrument().getInstrumentId());
			exchangeId=varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getGeneric().getExchangeId();
		}
		else
		{
			instrumentIdType=XmlMappingUtil.resolveIfNull(()->varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getIndex().getInstrument().getInstrumentType());
			instrumentId=XmlMappingUtil.resolveIfNull(()->varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getIndex().getInstrument().getInstrumentId());
			exchangeId=varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getIndex().getExchangeId();
		}

		
		if (! XmlMappingUtil.IsNullOrBlank(varianceLeg))
		{
			if(instrumentIdType.equalsIgnoreCase(DataServicesConstants.Share)||instrumentIdType.equalsIgnoreCase(DataServicesConstants.Index))
			{
				equityUnderlyingAssetType.setInstrumentIdType("RIC");
			}
			else if(instrumentIdType.equalsIgnoreCase(DataServicesConstants.Basket))
			{
				equityUnderlyingAssetType.setInstrumentIdType(instrumentIdType.substring(0,1).toUpperCase()+instrumentIdType.substring(1).toLowerCase());
			}
			else
			{
				equityUnderlyingAssetType.setInstrumentIdType(instrumentIdType);
			}
			
				equityUnderlyingAssetType.setInstrumentId(instrumentId);
				equityUnderlyingAssetType.setBasketExchange(exchangeId);
			
			
			equityUnderlyingAssetType.setNumberOfUnits(XmlMappingUtil.resolveIfNull(()->varianceLeg.getUnderlyer().getBasket().getBasketConstituent().get(0).getConstituentWeight().getOpenUnits()));
			equityUnderlyingAssetType.setNotional(XmlMappingUtil.getFormatedValue(()->varianceLeg.getAmount().getVariance().getVarianceAmount().getAmount(),BigDecimal.class));
			equityUnderlyingAssetType.setBasketInitialPrice(XmlMappingUtil.resolveIfNull(()->varianceLeg.getAmount().getVariance().getInitialLevel()));
			equityUnderlyingAssetType.setNotionalCurrency(XmlMappingUtil.resolveIfNull(()->varianceLeg.getSettlement().getSettlementCurrency()));
			
			listEquityUnderlyingAssetType.add(equityUnderlyingAssetType);	
		}
		
						
	
		logger.info("Leaving EqVarSwapXmlMapperService --> setUnderlyingAssetData() method");

		return listEquityUnderlyingAssetType;
	}
	
	protected LifeCycleType setLifeCycleEventData(TransactionType dsTrade,Map<String, String> harmonizerMap,TradeHeaderType tradeHeaderType) 
	{
		LifeCycleType lifeCycle = tradeHeaderType.getLifeCycle();
		
		VarianceSwapLegType varianceLeg = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getEquity().getVarianceSwap().getVarianceLeg());
		
		lifeCycle.setEventEffectiveDate(XmlMappingUtil.resolveIfNull(()->varianceLeg.getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
		
		return lifeCycle;
	}

}
