package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;

@Component
public interface DataSevicesCalculation 

{
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map <String,String> harmonizerMap,Object[] inputArr); 
}
