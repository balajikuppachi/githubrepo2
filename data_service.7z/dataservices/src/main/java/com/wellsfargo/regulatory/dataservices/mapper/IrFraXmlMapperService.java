package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DayTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FraDiscountingEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.dataservices.bo.FRA;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class IrFraXmlMapperService extends GenericXmlMapperService {

	private static Logger logger = Logger.getLogger(IrFraXmlMapperService.class.getName());
	
		
	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) {
		
		logger.info("Entering setProductTypeData() method");
		
		ProductType sdrRequestProductType = super.setProductTypeData(dsTrade,harmonizerMap);
		sdrRequestProductType.getLeg().addAll(setLegTypeData(dsTrade, sdrRequestProductType,harmonizerMap));
		sdrRequestProductType.setKeywords(null);

		logger.info("Leaving setProductTypeData() method");

		return sdrRequestProductType;
	}
	
	protected List<LegType> setLegTypeData(TransactionType dsTrade, ProductType productType, Map<String, String> harmonizerMap) {
		
		logger.info("Entering setLegTypeData() method");
		
		List<LegType> sdrRequestLegTypeList = new ArrayList<LegType>();
		LegType sdrRequestLegType = objectFactory.createLegType();
		com.wellsfargo.regulatory.dataservices.bo.ProductType productTypeData = dsTrade.getTrade().getProduct();
		FRA dsFra = productTypeData.getInterestRate().getFRA();
		sdrRequestLegType.setLegId((short) 1);
		sdrRequestLegType.setFixedFloat(FixedFloatEnum.FIXED);
		
		sdrRequestLegType.setPayReceive((BuySellEnum.BUY == productType.getBuySell())?PayReceiveEnum.PAY:PayReceiveEnum.RECEIVE);
		sdrRequestLegType.setStartDate(dsFra.getAdjustedEffectiveDate());
		sdrRequestLegType.setEndDate(dsFra.getAdjustedTerminationDate());
		sdrRequestLegType.setCurrency(XmlMappingUtil.getElementAtIndex(dsFra.getRateIndex().getIndexCurrency(), 0, DataServicesConstants.HYPHEN));
		sdrRequestLegType.setFixedRate(new BigDecimal(ConversionUtils.formatDecimal8(XmlMappingUtil.getFormatedValue(dsFra.getFixedRate(), BigDecimal.class))));
		sdrRequestLegType.setNotional(XmlMappingUtil.getFormatedValue(()->dsFra.getNotional().getAmount(), BigDecimal.class));
		sdrRequestLegType.setNotionalCurrency(XmlMappingUtil.getFormatedValue(()->dsFra.getNotional().getCurrency(),String.class));
		sdrRequestLegType.setRoundingPrecision(XmlMappingUtil.getFormatedValue(dsFra.getFinalRateRoundingPrecision(),Short.class));
		sdrRequestLegType.setRoundingDirection(dsFra.getFinalRateRoundingDirection());
		sdrRequestLegType.setPaymentHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->dsFra.getPaymentDate().getBusinessCenters().getBusinessCenter()), DataServicesConstants.COMMA));
		sdrRequestLegType.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsFra.getPaymentDate().getUnadjustedDate()));
		sdrRequestLegType.setIndexName(XmlMappingUtil.getElementAtIndex(dsFra.getRateIndex().getIndexName(), 1, DataServicesConstants.HYPHEN));
		
		sdrRequestLegType.setIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsFra.getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsFra.getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
		sdrRequestLegType.setIndexSource(XmlMappingUtil.getElementAtIndex(dsFra.getRateIndex().getIndexSource(), 2,DataServicesConstants.HYPHEN));
		sdrRequestLegType.setResetOffsetDayType(XmlMappingUtil.getEnumString(()->dsFra.getFixingDatesOffset().getDayType(),DayTypeEnum.class)); 
		sdrRequestLegType.setBusinessDayConvention(XmlMappingUtil.getEnumString(dsFra.getPaymentDate().getAdjustmentConvention(), BusinessDayConventionEnum.class));
		sdrRequestLegType.setDayCountFraction(dsFra.getDayCountFraction());
		sdrRequestLegType.setFraDiscounting(XmlMappingUtil.getEnumString(dsFra.getFRADiscounting(), FraDiscountingEnum.class));
		
		logger.info("Entering setLegTypeData() method");
		
		sdrRequestLegTypeList.add(sdrRequestLegType);

		return sdrRequestLegTypeList;
	}
	
}
