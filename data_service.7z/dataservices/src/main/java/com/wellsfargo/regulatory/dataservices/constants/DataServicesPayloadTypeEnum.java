package com.wellsfargo.regulatory.dataservices.constants;
/**
 * 
 * @author Pavithrini Kota
 * specifies if the payload is XML or STV.
 *
 */

public enum DataServicesPayloadTypeEnum {

	DS_INPUT_JSON 	("DS_INPUT_JSON"),
	DS_XML 				("DS_XML"),
	STV					("DS_STV"),
	REG_REP_XML			("REG_REP_XML");

	private final String value;

	public String getValue()
	{

		return value;
	}

	DataServicesPayloadTypeEnum(String v)
	{
		value = v;
	}

	
}
