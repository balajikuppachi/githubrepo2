/**
 * 
 */
package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

/**
 * @author u293876
 *
 */
@Component
public class CalculateDtccProductCalc implements DataSevicesCalculation  {

Logger logger = Logger.getLogger(this.getClass());
@Autowired
DataServicesCalculationTrigger dataServicesCalculationTrigger;
	
	@Override
	public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap, Object[] inputArr)
    {
		String productType=XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.productTypeCalc, transactionType, sdrRequest, harmonizerMap, inputArr),String.class);
		String srcPrdType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType());
		String srcSubPrdType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType());
		String dtccProduct=productType.split(":")[1];
		
		String CDS =XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getReferenceEntity());
		String CDSIdx =XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getReferenceEntity());
		String CDSEntity=(null!=CDS)?CDS:CDSIdx;
		if("CDSABSIndexTranche".equals(srcPrdType)){
			
			if(!GeneralUtils.IsNullOrBlank(CDSEntity) && CDSEntity.contains("ABX")){
				dtccProduct="CDT";
			} else{
				dtccProduct="SWAP REDUCED VALIDATION*";
			}
			
		}
		// Specials for ABSCDO as well
		if("ABSCDO".equals(srcPrdType)){
			
			if(!GeneralUtils.IsNullOrBlank(CDSEntity) && CDSEntity.contains("ABX")){
				dtccProduct="CDT";
			} else{
				dtccProduct="SWAP REDUCED VALIDATION*";
			}
		}	
				
		return dtccProduct;
    }
}

