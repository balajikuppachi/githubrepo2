package com.wellsfargo.regulatory.dataservices.builder;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;

public class LegBuilder implements BuilderBase {

	@Override
	public SdrRequest build(SdrRequest sdrRequest, DataServicesContext dataservicesInput) {
		// TODO Auto-generated method stub
		System.out.println("Inside Leg builder");
		
		// create JAXB object here
		return null;
	}

}
