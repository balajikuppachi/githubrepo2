package com.wellsfargo.regulatory.dataservices.comparator.impl;

import java.math.BigDecimal;

/**
 *@author Pavithrini Kota 
 */

public class CompareObjects {

	boolean compare(String str1, String str2)
	{
		boolean returnValue = false;
		
		if (str1 == null && str2 == null)
			return true;
		
		if (str1 == null && str2 != null || str1 != null && str2 == null)
		{
			return false;
		}
		
		if (compareForBigDecimal(str1, str2))
			
			return true;
		
		if (compareForDouble(str1, str2))
			
			return true;
		
		if (compareForShort(str1, str2))
			
			return true;
		
		if (compareForString(str1, str2))
			
			return true;
		
		return returnValue;
		
	}
	
	boolean compareForBigDecimal(String str1, String str2)
	{
		boolean returnValue = false;
		
		BigDecimal str1BD = null, str2BD = null;
		
		try
		{
			str1BD = new BigDecimal(str1);
			str2BD = new BigDecimal(str2);
			
		}catch(Exception e){
			str1BD = null;
			str2BD = null;
		}
		
		if (null != str1BD ){
			
			if (str1BD.compareTo(str2BD) == 0)
			returnValue = true;
		}
		
		return returnValue;
	}
	
	boolean compareForDouble(String str1, String str2)
	{
		boolean returnValue = false;
		
		Double str1Double = null, str2Double = null;
		
		try
		{
			str1Double = new Double(str1);
			str2Double = new Double(str2);
			
		}catch(Exception e){
			str1Double = null;
			str2Double = null;
		}
		
		if (null != str1Double ){
			
			if (str1Double.compareTo(str2Double) == 0)
			returnValue = true;
		}
		
		return returnValue;
	}
	
	boolean compareForShort(String str1, String str2)
	{
		boolean returnValue = false;
		
		Short str1Short = null, str2Short = null;
		
		try
		{
			str1Short = new Short(str1);
			str2Short = new Short(str2);
			
		}catch(Exception e){
			str1Short = null;
			str2Short = null;
		}
		
		if (null != str1Short ){
			
			if (str1Short.compareTo(str2Short) == 0)
			returnValue = true;
		}
		
		return returnValue;
	}
	
	boolean compareForString(String str1, String str2)
	{
		boolean returnValue = false;
		if (str1.trim().equalsIgnoreCase(str2.trim()))
			returnValue = true;
				
		return returnValue;
	}
	
	
}
