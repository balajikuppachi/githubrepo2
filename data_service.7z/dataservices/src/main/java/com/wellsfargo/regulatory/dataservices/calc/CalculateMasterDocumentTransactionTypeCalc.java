package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class CalculateMasterDocumentTransactionTypeCalc  implements DataSevicesCalculation  {

	Logger logger = Logger.getLogger(this.getClass());
	
	
	static  String[] CDX_TT = {"LCDX", "MBX", "MCDX", "TRX", "TRX II", "PrimeX", "CDX" };
	
	@Autowired
	DataServicesCalculationTrigger dataServicesCalculationTrigger;

	@Override
	public Object calculate(TransactionType transactionType, SdrRequest sdrRequest, Map<String, String> harmonizerMap, Object[] inputArr)
    {
		String productType=XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.calculateDtccProductcalc, transactionType, sdrRequest, harmonizerMap, inputArr),String.class);
		String ourDTCCMatrixFlag=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyUs().getPartyInfo().getDTCCMatrixParticipantFlag());
		
		String swapDtccIssuerRegion= XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCIssuerRegion());
		String optionDtccIssuerRegion= XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCIssuerRegion());
		
		String swapDTCCCDXSector= XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCCDXSector());
		String optionDTCCCDXSector= XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getDTCCCDXSector());
		
		String masterDocumentType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation().getMasterDocumentTransType());
		String LegalAgreementType= XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getDocumentation().getLegalAgreementType());
		
		String CDS =XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getReferenceEntity());
		String CDSIdx =XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getCredit().getCreditDefaultSwapOption().getCreditDefaultSwap().getGeneralTerms().getReferenceInformation().getReferenceEntity());
		
		String srcPrdType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductType());
		String srcSubPrdType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getProductSubType());
		String issuerRegion=(null!=swapDtccIssuerRegion)?swapDtccIssuerRegion:optionDtccIssuerRegion;
		String dtccCDXSector=(null!=swapDTCCCDXSector)?swapDTCCCDXSector:optionDTCCCDXSector;
		String CDSEntity=(null!=CDS)?CDS:CDSIdx;
		boolean standard = false;
		boolean STS = false;
		
		// We expect this to be Standards Terms Supplement but sometime te STV gets STS(!)
				if ((LegalAgreementType != null) && 
						(StringUtils.containsIgnoreCase(LegalAgreementType, Constants.STS)	||
								(StringUtils.containsIgnoreCase(LegalAgreementType, "STS"))))
						STS = true;
				
				if (issuerRegion != null) {
					// Check if its a Standard or a regular type
					standard = StringUtils.containsIgnoreCase(issuerRegion, "Standard");
				}
				
				if (Constants.PRODUCT_TYPE_CDS.equals(productType) || Constants.PRODUCT_TYPE_RECOVERY_LOCK.equalsIgnoreCase(productType))
					return handleCDS(standard, issuerRegion, ourDTCCMatrixFlag, LegalAgreementType);
				
				else if ((productType.equals("CDX") || productType.equals("CDT"))) {
					
					if (dtccCDXSector != null )
						return dtccCDXSector;
					else if (masterDocumentType != null) 
						return masterDocumentType;
					else {
						// Fall all check for CDX
						if(!GeneralUtils.IsNullOrBlank(CDSEntity) &&CDSEntity.contains("ABX") && ("CDSABSIndexTranche".equals(srcPrdType) || "CDSIndexTranche".equals(srcPrdType) ))
							return ("ABXTranche");
						else if (!GeneralUtils.IsNullOrBlank(CDSEntity) && CDSEntity.contains("CDX") && ("SCDO".equals(srcPrdType) || "CDSIndexTranche".equals(srcPrdType)))
							return "CDXTranche";
						
						if(STS){
							if("CDX".equals(srcSubPrdType))
								return "CDX";
							for ( int x=0; x < CDX_TT.length; x++) {
								if (StringUtils.containsIgnoreCase(LegalAgreementType, CDX_TT[x]))
									return CDX_TT[x];
								
							}
						
						}
						return "2003CreditIndex";  
					
					}
					
				}
				
				return Constants.EMPTY_STRING;
		
    }
	public String handleCDS( boolean standard, String region,
			String matrixFlag, String agreementType) {

		String value = null;

		// Check if its Matrix documentation
		if (Constants.TRUE.equalsIgnoreCase(matrixFlag)) {
			// Lookup domain MATT or SMATT (if standard is true)
			value = (standard) ? DataServicesDomainMappingUtil.getSMATT(region) : DataServicesDomainMappingUtil.getMATT(region);
			return value;
		}
		// Check if a standard terms Supplement
		else if ((agreementType != null)
				&& (agreementType.contains(Constants.STS))) {
			return Constants.DTCC_STS_VALUE;
		}
		// Master Confirmation
		else if ((agreementType != null)
				&& StringUtils.containsIgnoreCase(agreementType, "master")) {		
			// Lookup domain MTT or SMTT (if standard is true)
			value = (standard) ? DataServicesDomainMappingUtil.getSMTT(region) : DataServicesDomainMappingUtil.getMTT(region);			
			return value;
		}
		// throw an exception
		else {
			logger.error("MasterDocumentTypeCalc failed");
		}
		return value;
	}
}
