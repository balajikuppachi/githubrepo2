package com.wellsfargo.regulatory.dataservices.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.AveragingMethodEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BusinessDayConventionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CompoundingMethodEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DayTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.InterpolationMethodEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayRelativeToEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.StubPeriodEnum;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.dataservices.bo.OptionProvisionType;
import com.wellsfargo.regulatory.dataservices.bo.Swap;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.DataServicesDomainMappingUtil;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class IrSwapXmlMapperService extends GenericXmlMapperService {
	private static Logger logger = Logger.getLogger(IrSwapXmlMapperService.class.getName());
	
	protected ProductType setProductTypeData(TransactionType dsTrade, Map<String, String> harmonizerMap) 
	{
		logger.info("IrSwapXmlMapperService inside setProductTypeData");
		
		ProductType productType = super.setProductTypeData(dsTrade,harmonizerMap);
		Swap swap = XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getSwap()))?
					XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getSwaption().getSwap()):XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getSwap());
		productType.getLeg().addAll(setLegTypeData(dsTrade,harmonizerMap,swap));
		productType.setExerciseProvision(getExerciseProvisionData(dsTrade, productType));
		productType.setKeywords(null);
		
		logger.info("IrSwapXmlMapperService inside setProductTypeData");
		return productType;
	}

	protected List<LegType> setLegTypeData(TransactionType dsTransaction, Map<String, String> harmonizerMap, Swap swap) {
		List<LegType> legTypeList = new ArrayList<LegType>();
		
		
		com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg1Type = XmlMappingUtil.resolveIfNull(()->swap.getSwapStream().get(0));
		com.wellsfargo.regulatory.dataservices.bo.LegType dsLeg2Type = XmlMappingUtil.resolveIfNull(()->swap.getSwapStream().get(1));
			
			if (!XmlMappingUtil.IsNullOrBlank(dsLeg1Type))
			{	
				boolean isFixed=FixedFloatEnum.FIXED.toString().equalsIgnoreCase(dsLeg1Type.getType())?true:false;
				LegType leg1Type = objectFactory.createLegType();
				leg1Type.setLegId((short) 1);
				leg1Type.setPayReceive(XmlMappingUtil.getEnumString(dsLeg1Type.getPayOrReceive(), PayReceiveEnum.class));
				leg1Type.setFixedFloat(isFixed?FixedFloatEnum.FIXED:FixedFloatEnum.FLOAT);
				leg1Type.setStartDate(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0)));
				leg1Type.setEndDate(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate()));
				leg1Type.setCurrency(dsLeg1Type.getSettlementCurrency());
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getFixed().getFixedRateInitial())))
				{	
				leg1Type.setFixedRate(new BigDecimal(ConversionUtils.formatDecimal8(XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getFixed().getFixedRateInitial(), BigDecimal.class))));
				}
				leg1Type.setSpread(XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getFloat().getFloatingRateSpreadInitial(), BigDecimal.class));
				leg1Type.setEmbeddedOptionType(null);
				leg1Type.setNotional(XmlMappingUtil.getFormatedValue(dsLeg1Type.getNotionalAmount(),BigDecimal.class));
				leg1Type.setNotionalCurrency(dsLeg1Type.getNotionalCurrency());
				leg1Type.setRoundingPrecision(XmlMappingUtil.getFormatedValue(dsLeg1Type.getFinalRateRoundingPrecision(),Short.class));
				leg1Type.setRoundingDirection(dsLeg1Type.getFinalRateRoundingDirection());
				// change as per new mapping
				leg1Type.setPaymentHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA));//.getCalculationPeriodDatesAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA));
				leg1Type.setPaymentDateOffset(XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getCalculationPeriodDates().getPaymentDate().getOffsetPeriod().getPeriodMultiplier(),String.class));
				leg1Type.setPaymentDateOffsetDayType( XmlMappingUtil.getEnumString(()->dsLeg1Type.getCalculationPeriodDates().getResetDate().getOffsetDayType(),DayTypeEnum.class));
				leg1Type.setPayRelativeTo(XmlMappingUtil.getEnumString(xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.PAY_RELATIVE_TO_LEG1),PayRelativeToEnum.class));
				leg1Type.setPaymentFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriodMultiplier())));
				leg1Type.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getProduct().getSettlement().getSettlementDate()));
				leg1Type.setIndexName(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getFloat().getRateIndex().getIndexName()),1,DataServicesConstants.HYPHEN));
				
				leg1Type.setIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
				leg1Type.setIndexSource(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getFloat().getRateIndex().getIndexSource()),2,DataServicesConstants.HYPHEN));
				leg1Type.setIndexCurrency(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getFloat().getRateIndex().getIndexCurrency()),0,DataServicesConstants.HYPHEN));
				if(null != XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getFloat().getFloatingRateMultiplierInitialValue())) {
					leg1Type.setIndexFactor(XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getFloat().getFloatingRateMultiplierInitialValue(), BigDecimal.class));
				}				
				
				
				leg1Type.setResetOffsetDayType(XmlMappingUtil.getEnumString(()->dsLeg1Type.getCalculationPeriodDates().getResetDate().getOffsetDayType(),DayTypeEnum.class));
				leg1Type.setRollConvention(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getCalculationPeriodDates().getCalculationPeriodFrequency().getRollConvention()));
				leg1Type.setAveragingMethod(XmlMappingUtil.getEnumString(()->dsLeg1Type.getAveragingMethod(),AveragingMethodEnum.class));
				//change as per new mapping
				leg1Type.setBusinessDayConvention(XmlMappingUtil.getEnumString(dsLeg1Type.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessDayConvention(),BusinessDayConventionEnum.class));//.getCalculationPeriodDatesAdjustments().getBusinessDayConvention(), BusinessDayConventionEnum.class));
				leg1Type.setDayCountFraction(dsLeg1Type.getDayCountFraction());
				leg1Type.setCompoundingMethod(XmlMappingUtil.getEnumString(()->DataServicesDomainMappingUtil.getConvertedCompoundingMethod(dsLeg1Type.getCompoundingMethod()),CompoundingMethodEnum.class));
				leg1Type.setInterpolationMethod(XmlMappingUtil.getEnumString(dataServicesCalculationTrigger.calculate(DataServicesCalc.interpolationMethodCalc, dsTransaction, null, harmonizerMap, new Object[]{dsLeg2Type}),InterpolationMethodEnum.class));
				leg1Type.setInterpIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(), String.class),XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getAmortizationParameters().getAmortizationFrequency().getPeriodMultiplier())))
				{
				leg1Type.setAmortizationFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getAmortizationParameters().getAmortizationFrequency().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLeg1Type.getAmortizationParameters().getAmortizationFrequency().getPeriodMultiplier())));
				}
				leg1Type.setAmortizationType(XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getAmortizationParameters().getAmortizationType(), String.class));
				
				leg1Type.setStubPeriodType(XmlMappingUtil.getEnumString(dsLeg1Type.getStubPeriodType(),StubPeriodEnum.class));
				leg1Type.setInitialInflationRate(XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getInflation().getRate(), BigDecimal.class));
				//Added new mapping
				leg1Type.setResetFrequency(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg1Type.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod(),String.class)},DataServicesConstants.COLON));
				leg1Type.setCashFlowSet(xmlMapperHelper.getLegCashFlowData(dsLeg1Type,objectFactory)); 
				legTypeList.add(leg1Type);
				
			}
				
			if (!XmlMappingUtil.IsNullOrBlank(dsLeg2Type))
			{	
				LegType leg2Type = objectFactory.createLegType();
				leg2Type.setLegId((short) 2);
				boolean isFixed=FixedFloatEnum.FIXED.toString().equalsIgnoreCase(dsLeg2Type.getType())?true:false;
				leg2Type.setPayReceive(XmlMappingUtil.getEnumString(dsLeg2Type.getPayOrReceive(), PayReceiveEnum.class));
				leg2Type.setFixedFloat(isFixed?FixedFloatEnum.FIXED:FixedFloatEnum.FLOAT);
				leg2Type.setStartDate(dsLeg2Type.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getUnadjustedDate().get(0));
				leg2Type.setEndDate(dsLeg2Type.getCalculationPeriodDates().getTerminationDate().getUnadjustedDate());
				leg2Type.setCurrency(dsLeg2Type.getSettlementCurrency()); 
				if(!XmlMappingUtil.IsNullOrBlank(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getFixed().getFixedRateInitial())))
				{	
				leg2Type.setFixedRate(new BigDecimal(ConversionUtils.formatDecimal8(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFixed().getFixedRateInitial(), BigDecimal.class))));
				}
				leg2Type.setSpread(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFloat().getFloatingRateSpreadInitial(), BigDecimal.class));
				leg2Type.setEmbeddedOptionType(null); 
				leg2Type.setNotional(XmlMappingUtil.getFormatedValue(dsLeg2Type.getNotionalAmount(),BigDecimal.class)); 
				leg2Type.setNotionalCurrency(dsLeg2Type.getNotionalCurrency()); 
				leg2Type.setRoundingPrecision(XmlMappingUtil.getFormatedValue(dsLeg2Type.getFinalRateRoundingPrecision(),Short.class)); 
				leg2Type.setRoundingDirection(dsLeg2Type.getFinalRateRoundingDirection()); 
				//change as per new mapping
				leg2Type.setPaymentHolidays(XmlMappingUtil.concatenateListValues(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA));//.getCalculationPeriodDatesAdjustments().getBusinessCenters().getBusinessCenter()),DataServicesConstants.COMMA));
				leg2Type.setPaymentDateOffset(XmlMappingUtil.getFormatedValue(dsLeg2Type.getCalculationPeriodDates().getPaymentDate().getOffsetPeriod().getPeriodMultiplier(), String.class)); 
				leg2Type.setPaymentDateOffsetDayType( XmlMappingUtil.getEnumString(()->dsLeg2Type.getCalculationPeriodDates().getResetDate().getOffsetDayType(),DayTypeEnum.class)); 
				leg2Type.setPayRelativeTo(XmlMappingUtil.getEnumString(xmlMapperHelper.getHarmonizedValue(harmonizerMap,DataServicesConstants.PAY_RELATIVE_TO_LEG2),PayRelativeToEnum.class));
				leg2Type.setPaymentFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getCalculationPeriodDates().getPaymentDate().getFrequencyPeriod().getPeriodMultiplier()))); 
				leg2Type.setSettlementDate(XmlMappingUtil.resolveIfNull(()->dsTransaction.getTrade().getProduct().getSettlement().getSettlementDate()));
				leg2Type.setIndexName(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getFloat().getRateIndex().getIndexName()),1,DataServicesConstants.HYPHEN));
				leg2Type.setIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
				//leg2Type.setIndexTenor(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFloat().getFloatingRateTenorPeriod(), String.class));
				leg2Type.setIndexSource(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getFloat().getRateIndex().getIndexSource()),2,DataServicesConstants.HYPHEN));
				leg2Type.setIndexCurrency(XmlMappingUtil.getElementAtIndex(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getFloat().getRateIndex().getIndexCurrency()),0,DataServicesConstants.HYPHEN));
				leg2Type.setIndexFactor(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFloat().getFloatingRateMultiplierInitialValue(), BigDecimal.class));
				leg2Type.setResetOffsetDayType( XmlMappingUtil.getEnumString(()->dsLeg2Type.getCalculationPeriodDates().getResetDate().getOffsetDayType(),DayTypeEnum.class)); 
				leg2Type.setRollConvention(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getCalculationPeriodDates().getCalculationPeriodFrequency().getRollConvention()));
				leg2Type.setAveragingMethod(XmlMappingUtil.getEnumString(()->dsLeg2Type.getAveragingMethod(),AveragingMethodEnum.class)); 
				//change as per new mapping
				leg2Type.setBusinessDayConvention(XmlMappingUtil.getEnumString(()->dsLeg2Type.getCalculationPeriodDates().getEffectiveDate().getAdjustableDate().getDateAdjustments().getBusinessDayConvention(), BusinessDayConventionEnum.class));//.getCalculationPeriodDatesAdjustments().getBusinessDayConvention(), BusinessDayConventionEnum.class));
				leg2Type.setDayCountFraction(dsLeg2Type.getDayCountFraction());
				leg2Type.setCompoundingMethod(XmlMappingUtil.getEnumString(()->DataServicesDomainMappingUtil.getConvertedCompoundingMethod(dsLeg2Type.getCompoundingMethod()),CompoundingMethodEnum.class));
				leg2Type.setInterpolationMethod(XmlMappingUtil.getEnumString(dataServicesCalculationTrigger.calculate(DataServicesCalc.interpolationMethodCalc, dsTransaction, null, harmonizerMap, new Object[]{dsLeg2Type}),InterpolationMethodEnum.class));
				leg2Type.setInterpIndexTenor(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriodMultiplier(), String.class),XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getFloat().getRateIndex().getIndexTenor().getFloatingRatePeriod(),String.class)},null));
				
				leg2Type.setAmortizationFrequency(DataServicesDomainMappingUtil.getConvertedPaymentFreqPeriod(XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getAmortizationParameters().getAmortizationFrequency().getPeriod()),XmlMappingUtil.resolveIfNull(()->dsLeg2Type.getAmortizationParameters().getAmortizationFrequency().getPeriodMultiplier())));
				leg2Type.setAmortizationType(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getAmortizationParameters().getAmortizationType(), String.class));  
				leg2Type.setStubPeriodType(XmlMappingUtil.getEnumString(dsLeg2Type.getStubPeriodType(),StubPeriodEnum.class)); 
				leg2Type.setInitialInflationRate(XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getInflation().getRate(), BigDecimal.class));
				leg2Type.setCashFlowSet(xmlMapperHelper.getLegCashFlowData(dsLeg2Type,objectFactory)); 
				leg2Type.setResetFrequency(XmlMappingUtil.concatenateArrayValues(new String[]{XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriodMultiplier(),String.class),XmlMappingUtil.getFormatedValue(()->dsLeg2Type.getCalculationPeriodDates().getResetDate().getFrequencyPeriod().getPeriod(),String.class)},DataServicesConstants.COLON));
				legTypeList.add(leg2Type);
			}
		return legTypeList;
	}

	private ExerciseProvisionType getExerciseProvisionData(TransactionType dsTrade,	ProductType productType) 
	{
		if(DataServicesConstants.SRC_PRODUCT_TYPE_CANCELLABLE_SWAP.equalsIgnoreCase(productType.getProductType()))
		{
			OptionProvisionType provision = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getSwap().getCancelableProvision());
			return xmlMapperHelper.getExerciseProvisionTypeData(dsTrade, objectFactory,provision);
		}	
		if(DataServicesConstants.SRC_PRODUCT_TYPE_CAPPED_SWAP.equalsIgnoreCase(productType.getProductType()))
		{
			OptionProvisionType provision = XmlMappingUtil.resolveIfNull(()->dsTrade.getTrade().getProduct().getInterestRate().getSwap().getCappedProvision());
			return xmlMapperHelper.getExerciseProvisionTypeData(dsTrade, objectFactory,provision);
		}	
		else
			return xmlMapperHelper.getExerciseProvisionTypeData(dsTrade, objectFactory);
	}
	
}
