package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class OptionTypeCalc implements DataSevicesCalculation {
	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr) 
	{
		
		String swaptionStraddle = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getInterestRate().getSwaption().getSwaptionStraddle());
		String optionType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getProduct().getInterestRate().getSwaption().getOptionType());
		if(!XmlMappingUtil.IsNullOrBlank(swaptionStraddle))
		{
		if(Constants.TRUE.equalsIgnoreCase(swaptionStraddle)){
			return Constants.OPTION_STRADDLE;
		}
		
		if(Constants.FALSE.equalsIgnoreCase(swaptionStraddle) && !XmlMappingUtil.IsNullOrBlank(optionType))
		{
			if (Constants.RTP.equalsIgnoreCase(optionType))
					return Constants.PAYER;			
			if (Constants.RTR.equalsIgnoreCase(optionType))
					return Constants.RECEIVER;
			
		}
		}
		return Constants.EMPTY_STRING;
	
		
	}

}
