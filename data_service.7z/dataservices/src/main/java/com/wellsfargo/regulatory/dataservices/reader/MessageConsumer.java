package com.wellsfargo.regulatory.dataservices.reader;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.springframework.stereotype.Component;

import com.solacesystems.jcsmp.TextMessage;
import com.solacesystems.jms.SolJmsUtility;

//@Component
public class MessageConsumer /*implements MessageListener*/ {/*

	public void onMessage(Message message) {
		*//*** Application specific handling code would follow. For this example print the topic of each message ***//*
		System.out.println("Bingo message received");
		
		try 
		{
			String messageString = SolJmsUtility.dumpMessage(message);
			System.out.println("Received message on destination: " + message.getJMSDestination().toString() + "\n" + messageString);
			if(message instanceof javax.jms.TextMessage) {
				System.out.println("message body is" + ((javax.jms.TextMessage) message).getText());
			}
		} 
		catch (JMSException ex) 
		{
			throw new RuntimeException(ex);
		}
	}
*/}
