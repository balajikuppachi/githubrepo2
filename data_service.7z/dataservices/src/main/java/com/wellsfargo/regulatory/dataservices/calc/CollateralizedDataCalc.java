package com.wellsfargo.regulatory.dataservices.calc;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.PartyRelatedType;
import com.wellsfargo.regulatory.dataservices.bo.PartyType;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesCalc;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.service.CollateralDataService;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;
import com.wellsfargo.regulatory.persister.dao.RegRepTradeCollateralDao;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeCollateral;

@Component
public class CollateralizedDataCalc implements DataSevicesCalculation{
	
	@Autowired
	CollateralDataService collateralDataService;
	

	@Autowired
	RegRepTradeCollateralDao regRepTradeCollateralDao;
	
	@Autowired
	DataServicesCalculationTrigger dataServicesCalculationTrigger;
	
		@Override
		public Object calculate(TransactionType transactionType, SdrRequest sdrRequest,	Map<String, String> harmonizerMap, Object[] inputArr) 
		{
		
			
			
			String assetClass = harmonizerMap.get(DataServicesConstants.HRMN_ASSET_CLASS);
			PartyType partyType = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty());
			Boolean isClearedTrade = Boolean.FALSE;
			String returnValue = DataServicesConstants.EMPTY_STRING;
			
			PartyRelatedType partyRelatedType = XmlMappingUtil.resolveIfNull(()->partyType.getPartyThem().getPartyInfo());
			String businessAccountId = partyRelatedType.getBusinessAccountID();
			String legalId = partyRelatedType.getCIDLegalId();
			isClearedTrade = XmlMappingUtil.getFormatedValue(dataServicesCalculationTrigger.calculate(DataServicesCalc.clearedTradeCalc, transactionType, null, null, null), Boolean.class);
			if(null != isClearedTrade && isClearedTrade.booleanValue()) {
				returnValue =   DataServicesConstants.FullyCollateralized;
			}
			else {
				String tradeId = transactionType.getTrade().getTradeHeader().getTradeAttributes().getSource().getTradeId();
				if(!XmlMappingUtil.IsNullOrBlank(tradeId)) {
					String srcSystem = getSrcSystem(assetClass);
					if(!XmlMappingUtil.IsNullOrBlank(srcSystem)) {
						List<RegRepTradeCollateral> listTradeAgreements = null;
						if(DataServicesConstants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass)) {
							tradeId = tradeId + ".OTC";
							listTradeAgreements = regRepTradeCollateralDao.findWhereEQTickerIDSourceEquals(tradeId, srcSystem);
						}
						else {
							listTradeAgreements = regRepTradeCollateralDao.findWhereTradeIdSourceEquals(tradeId, srcSystem);
						}
						
						
						if(!XmlMappingUtil.IsListNullOrEmpty(listTradeAgreements)) {
							String tradeCollateralization = listTradeAgreements.get(0).getCollateralization();
							if(StringUtils.contains(tradeCollateralization,DataServicesConstants.PC)){
								return DataServicesConstants.PartiallyCollateralized;
							}
							if(StringUtils.contains(tradeCollateralization,DataServicesConstants.OW)){
								return DataServicesConstants.OneWayCollateralized;
							}
							if(StringUtils.contains(tradeCollateralization,DataServicesConstants.FC)){
								return DataServicesConstants.FullyCollateralized;
							}
							if(StringUtils.contains(tradeCollateralization,DataServicesConstants.UC)){
								return DataServicesConstants.UnCollateralized;
							}
						}
					}
				}
			}
			
			if(returnValue==null || DataServicesConstants.EMPTY_STRING.equals(returnValue) )
			{
				String collateralizedValue = DataServicesConstants.EMPTY_STRING;
				if(DataServicesConstants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass)) {
					if(!XmlMappingUtil.IsNullOrBlank(businessAccountId)) {
						collateralizedValue = collateralDataService.getDTCCCollaterlizedValue(DataServicesConstants.NOT_APPLICABLE, DataServicesConstants.NOT_APPLICABLE, businessAccountId, DataServicesConstants.NOT_APPLICABLE);
						if(DataServicesConstants.PartiallyCollateralized.equalsIgnoreCase(collateralizedValue))
							returnValue =  DataServicesConstants.Partially;
						else if(DataServicesConstants.FullyCollateralized.equalsIgnoreCase(collateralizedValue))
							returnValue =  DataServicesConstants.Fully;
						else if(DataServicesConstants.OneWayCollateralized.equalsIgnoreCase(collateralizedValue))
							returnValue =  DataServicesConstants.OneWay;
						else 
							returnValue =  collateralizedValue;
					}
				}
				else if(DataServicesConstants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)) {
					  collateralizedValue = collateralDataService.getDTCCCollaterlizedValue(legalId, partyRelatedType.getShortName(), businessAccountId, assetClass);
					if(DataServicesConstants.FullyCollateralized.equalsIgnoreCase(collateralizedValue))
						returnValue =  DataServicesConstants.Fully;
					else if(DataServicesConstants.PartiallyCollateralized.equalsIgnoreCase(collateralizedValue))
						returnValue =  DataServicesConstants.Partially;
					else if (DataServicesConstants.OneWayCollateralized.equalsIgnoreCase(collateralizedValue))
						returnValue =  DataServicesConstants.OneWay;
				}
				else {
					
					     returnValue = collateralDataService.getDTCCCollaterlizedValue(legalId, partyRelatedType.getShortName(), businessAccountId, assetClass);
				}
			}
			return returnValue;
		
		}
		
		private String getSrcSystem(String assetClass) {
			if(DataServicesConstants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass)){
				return DataServicesConstants.IMAGINE4;
			}
			if(DataServicesConstants.ASSET_CLASS_COMMODITY.equalsIgnoreCase(assetClass)){
				return DataServicesConstants.STIERS_ENDUR;
			}
			if(DataServicesConstants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass) || DataServicesConstants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(assetClass) || DataServicesConstants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)){
				return DataServicesConstants.STIERS_CALYPSO_CALRATES;
			}
			else return null;
			
		}


}
