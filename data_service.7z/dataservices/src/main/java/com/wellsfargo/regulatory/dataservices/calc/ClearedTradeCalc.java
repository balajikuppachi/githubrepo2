package com.wellsfargo.regulatory.dataservices.calc;

import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.dataservices.bo.TransactionType;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.utils.XmlMappingUtil;

@Component
public class ClearedTradeCalc implements DataSevicesCalculation
{

	@Value("${valuation.rp}") String valuationRP;
	
	@Override
	public Object calculate(TransactionType transactionType,SdrRequest sdrRequest, Map<String, String> harmonizerMap,Object[] inputArr)
	{
		String cpLEI=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getParty().getPartyThem().getPartyInfo().getValue());
		String marketType=XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeLifeCycle().getLifeCycleEvent());
		
		Boolean isClearingTrade=Boolean.FALSE;
		XMLGregorianCalendar clearingDateTime=null;
		
		com.wellsfargo.regulatory.dataservices.bo.ClearingType clearing = XmlMappingUtil.resolveIfNull(()->transactionType.getTrade().getTradeHeader().getTradeAttributes().getClearing());
		if (!XmlMappingUtil.IsNullOrBlank(clearing)){
			clearingDateTime=clearing.getCCPClearingTimeStamp();
		}
		if (!XmlMappingUtil.IsNullOrBlank(clearing) &&
				 (!XmlMappingUtil.IsNullOrBlank(clearingDateTime)
				|| (!XmlMappingUtil.IsNullOrBlank(cpLEI) && StringUtils
						.contains(valuationRP, cpLEI))
				|| (!XmlMappingUtil.IsNullOrBlank(marketType) && StringUtils
						.equalsIgnoreCase(DataServicesConstants.Clearing,
								marketType)) || !XmlMappingUtil.IsNullOrBlank(clearing.getCCPTradeId()) ))
		{
			
				isClearingTrade=Boolean.TRUE;
		
		}
		
		
		return isClearingTrade;
	}

}
