package com.wellsfargo.regulatory.dataservices.builder;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;


public class TestBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BuilderDataContext[] context = BuilderDataContext.values();
		
		
		for(BuilderDataContext contextValue: context) {
			 //BuilderBase builderBase = contextValue.getBuilderBase();
			 //builderBase.build(new SdrRequest(), new ());
		}
	}

}
