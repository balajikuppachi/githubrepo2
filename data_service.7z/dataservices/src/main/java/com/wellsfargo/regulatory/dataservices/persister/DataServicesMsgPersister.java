package com.wellsfargo.regulatory.dataservices.persister;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.dataservices.beans.DataServicesContext;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.constants.DataServicesPayloadTypeEnum;

/***
 * 
 * @author Pavithrini Kota
 * Persister class for saving and extracting the messages for DataServices
 *
 */

public class DataServicesMsgPersister
{
	
	private DataServicesPersisterHelper dataServicesPersisterHelper;
	
	private static Logger logger = Logger.getLogger(DataServicesMsgPersister.class.getName());
	
	public void setDataServicesPersisterHelper(
			DataServicesPersisterHelper dataServicesPersisterHelper) {
		this.dataServicesPersisterHelper = dataServicesPersisterHelper;
	}


	public Message<?> persist(Message<?> message) throws Exception
	{
		logger.info("inside DataServicesMsgPersister:persist method of contextType ");
		
		DataServicesContext context = null;
		String messageId = null;
		String errorString = null;
		DataServicesPayloadTypeEnum contextType = null;
		
		if (null == message)
		{
			errorString = "Failed to persist DS message since incoming message was null";
			logger.error("########## " + errorString);

			return message;
		}

		if (null == message.getPayload() || !(message.getPayload() instanceof DataServicesContext))
		{
			messageId = (String) message.getHeaders().get(DataServicesConstants.DS_MESSAGE_ID);

			errorString = "Failed to persist message since the incoming payload type was invalid or null ::" + messageId;
			logger.error("########## " + errorString);

			throw new MessagingException("Prstr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		context = (DataServicesContext) message.getPayload();
		messageId = context.getMessageId();
		contextType = context.getContextType();
		
		logger.info("inside DataServicesMsgPersister:persist method of contextType --> "+contextType);
		try
		{
			if (null == contextType)
			{
				dataServicesPersisterHelper.persistPayload(message);
			} 
			else if (DataServicesPayloadTypeEnum.DS_INPUT_JSON.equals(contextType))
			{
				dataServicesPersisterHelper.updatePayload(message);
			}else if (DataServicesPayloadTypeEnum.REG_REP_XML.equals(contextType))
			{
				dataServicesPersisterHelper.updatePayload(message);
			}
			
		}
		catch (Exception e)
		{
			errorString = "Failed to persist " + messageId + " message with id : " + messageId + " with reason " + e.getMessage();
			logger.error("########## " + errorString);
		}

		logger.info("Message with messageId=" + messageId + " has been successfully persisted.");

		return message;
	}

}
