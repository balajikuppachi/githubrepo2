package com.wellsfargo.regulatory.dataservices.recon;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.persister.dataservices.dto.RegRepDsPayload;

/***
 * @author Pavithrini Kota
 * 05/06/2015
 *
 */
public class RegRepDsReconRowMapper implements RowMapper<RegRepDsRecon>{

	@Override
	public RegRepDsRecon mapRow(ResultSet rset, int row)
			throws SQLException {
		
		RegRepDsRecon dsRecon = new RegRepDsRecon();
		dsRecon.setMsgId(rset.getString("msgId"));
		dsRecon.setDsPayloadId(rset.getLong("dsPayloadId"));
		dsRecon.setDsPayload(rset.getString("dsPayload"));
		dsRecon.setSdrPayloadId(rset.getLong("sdrPayloadId"));
		dsRecon.setSdrPayload(rset.getString("sdrPayload"));
		return dsRecon;
	}

}
