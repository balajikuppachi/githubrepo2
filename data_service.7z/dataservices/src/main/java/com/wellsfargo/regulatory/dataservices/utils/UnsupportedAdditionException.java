package com.wellsfargo.regulatory.dataservices.utils;

public class UnsupportedAdditionException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UnsupportedAdditionException(){
		super();
	}
	
	public UnsupportedAdditionException(String message){		
		super(message);
	}
}
