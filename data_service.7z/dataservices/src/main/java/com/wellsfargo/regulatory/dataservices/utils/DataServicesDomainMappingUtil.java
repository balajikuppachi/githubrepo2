package com.wellsfargo.regulatory.dataservices.utils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.dataservices.constants.DataServicesConstants;
import com.wellsfargo.regulatory.dataservices.persister.DataServicesMappingCache;

/**
 * @author Raji Komatreddy 
 * this util class contains methods to enrich data for sdrRequest using data
 * from REG_REP_DOMAIN_MAPPING table
 */


public class DataServicesDomainMappingUtil
{

	private static Logger logger = Logger.getLogger(XmlMappingUtil.class.getName());
	
	public static String enrichEmirTaxonomy(String taxonomy, boolean isRpParty)
	{
		String domainKey = null,domainValue = null;
		if (isRpParty)
			domainKey = getDomainKey(DataServicesConstants.EMIRUSTAXONOMY, taxonomy);
		else
			domainKey = getDomainKey(DataServicesConstants.EMIRCPTAXONOMY, taxonomy);
		
		domainValue = getDomainValue(domainKey, taxonomy);
		return domainValue;
	}

	private static String getDomainValue(String key, String srcValue)
	{
		String value = null;
		DataServicesMappingCache cache = null;
		try
		{
			cache = DataServicesMappingCache.getDsInstance();
			value = cache.getValue(key);
		}
		catch (Exception ex)
		{
			logger.error("getDomainValue : Exception while retreving the domain values for key : "+key+", Exception:"+ExceptionUtils.getFullStackTrace(ex));
		}
		
		return value;
	}
	
	
	public static String getConvertedRollConvention(String rollconvention) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.DS_PAYMENT_PERIOD, rollconvention);
		domainValue = getDomainValue(domainKey, rollconvention);
		return domainValue;
	}
	public static String getConvertedCompoundingMethod(String compoundingMethod) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.CMD, compoundingMethod);
		domainValue = getDomainValue(domainKey, compoundingMethod);
		return domainValue;
	}
	public static String getConvertedPaymentFreqPeriod(String paymentFrequency,BigInteger multiplier) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.DS_PAYMENT_PERIOD, paymentFrequency);
		domainKey=domainKey+DataServicesConstants.UNDERSCORE + multiplier;
		domainValue = getDomainValue(domainKey, paymentFrequency);
		return domainValue;
	}
	

	public static String getRegion(String tempRegion) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.REGION, tempRegion);
		domainValue = getDomainValue(domainKey, tempRegion);
		return domainValue;
	}

	private static String getDomainKey(String preFix,String value)
    {
	    String domainkey = preFix;
		if (!XmlMappingUtil.IsNullOrBlank(domainkey))
			domainkey = preFix + DataServicesConstants.UNDERSCORE + value;
	    return domainkey;
    }



	public static String getCDXSector(String cdxSector) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.CDX_SECTOR, cdxSector);
		domainValue = getDomainValue(domainKey, cdxSector);
		return domainValue;
	}



	public static boolean isStandardBasketName(String basketValue) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.CDX_SECTOR, basketValue);
		domainValue = getDomainValue(domainKey, basketValue);
		return StringUtils.isNotEmpty(domainValue);
		
	}
	
	public static String getMasterAgreementType(String masterType) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.MasterAgreement, masterType);
		domainValue = getDomainValue(domainKey, masterType);
		return StringUtils.isNotEmpty(domainValue)?domainValue:DataServicesConstants.ISDA;
	}
	
	public static String getSMTT(String Region) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.SMTT, Region);
		domainValue = getDomainValue(domainKey, Region);
		return domainValue;
	}
	public static String getMTT(String Region) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.MTT, Region);
		domainValue = getDomainValue(domainKey, Region);
		return domainValue;
	}
	public static String getSMATT(String Region) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.SMATT, Region);
		domainValue = getDomainValue(domainKey, Region);
		return domainValue;
	}
	public static String getMATT(String Region) 
	{
		String domainKey = null,domainValue = null;
		domainKey = getDomainKey(DataServicesConstants.MATT, Region);
		domainValue = getDomainValue(domainKey, Region);
		return domainValue;
	}

}
