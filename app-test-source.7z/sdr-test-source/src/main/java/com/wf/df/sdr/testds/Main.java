package com.wf.df.sdr.testds;

import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static final String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:application-context.xml";

    private Main() { }

    public static void main(final String... args) {

        final ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
        context.setConfigLocation(APPLICATION_CONTEXT_CONFIG_LOCATION);
        context.registerShutdownHook();
        try {
        	context.refresh();
        } catch (Throwable e) {
        	LoggerFactory.getLogger(Main.class).error("Could not start application context - shutting down", e);
        	System.exit(0);
        }

        //TODO: AZ - implement stopping the application
        try {
			Thread.sleep(10000000);
		} catch (InterruptedException e) {
			System.exit(1);
		}
        
        System.exit(0);

    }

}
