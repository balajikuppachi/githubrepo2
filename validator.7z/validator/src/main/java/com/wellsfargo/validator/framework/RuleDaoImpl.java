package com.wellsfargo.validator.framework;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class RuleDaoImpl implements	RuleDao {
	
	private static Logger logger = Logger.getLogger(RuleDaoImpl.class);
	
	private JdbcTemplate jdbcTemplate;
		
	public RuleDaoImpl(JdbcTemplate jdbcTemplate) 
	{
		this.jdbcTemplate = jdbcTemplate;	
	}	

	@Override
	public Rule findRuleById(String id) {
		logger.info("Entering findRuleById() method");

        String query = RuleQueryMaster.GET_RULE_BY_RULE_ID;
        
        Rule rule = (Rule)jdbcTemplate.queryForObject(
        		query, new Object[] { id }, new RuleRowMapper());

		
		return rule;
	}
	
	class RuleRowMapper implements RowMapper<Rule>
	{
		public Rule mapRow(ResultSet rs, int rowNum) throws SQLException {
			Rule rule = new Rule();
			rule.setRuleId(rs.getString("RULE_ID"));
			rule.setRuleName(rs.getString("RULE_NAME"));
			return rule;
		}
	}

	@Override
	public List<Rule> findAll() {
		logger.info("Entering findAll() method");

        String query = RuleQueryMaster.GET_ALL_RULE;

        List<Rule> rules = new ArrayList<Rule>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

        for (Map<String, Object> row : rows) 
        {
        	Rule rule = new Rule();

        	rule.setRuleName((String)row.get("RULE_NAME"));
        	rule.setRuleId((String)row.get("RULE_ID"));

        	rules.add(rule);
        }
		logger.info("Leaving findAll() method");
        
        return rules;
	}

	

}
