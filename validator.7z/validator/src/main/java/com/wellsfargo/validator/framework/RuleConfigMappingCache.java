package com.wellsfargo.validator.framework;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RuleConfigMappingCache {
	
	private static RuleConfigMappingCache instance;
	private Map<String, List<String>> ruleConfigMap;
	
	private RuleConfigMappingCache() {
		
		ruleConfigMap = new HashMap<String, List<String>>();		
	}
	
	public static RuleConfigMappingCache getInstance(){
		if(null == instance){
			instance = new RuleConfigMappingCache();			
			RuleConfigMappingCacheLoader.loadRulesConfigMappingCache(instance);
		}
		
		return instance;
	}
	

	public void setValue(String key, List<String> values){
		ruleConfigMap.put(key, values);
	}
	
	public List<String> getValues(String key){
		return ruleConfigMap.get(key);
	}
	
}
