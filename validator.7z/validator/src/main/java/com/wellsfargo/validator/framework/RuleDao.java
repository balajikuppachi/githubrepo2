package com.wellsfargo.validator.framework;

import java.util.List;


public interface RuleDao{

	public Rule findRuleById(String id);
	
	public List<Rule> findAll();
	
}
