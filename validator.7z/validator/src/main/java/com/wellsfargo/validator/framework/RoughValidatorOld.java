package com.wellsfargo.validator.framework;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.commons.lang.StringUtils;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
/*import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;*/
@Deprecated
public class RoughValidatorOld {/*
	
	private static final String NEW_DEAL = "New Deal";
	private static final String EXPIRY = "Expiry";
	private static final String TERMINATION = "Termination";
	private static final String NOVATION = "Novation";
	
	private static ScriptEngineManager manager = new ScriptEngineManager ();
	private static ScriptEngine engine = manager.getEngineByName("JavaScript");
	
	public boolean validateInput(SdrRequest sdrRequest) throws Exception{
		
		boolean flag = false;
		
		String eventType = sdrRequest.getTrade().getTradeDetail().getProduct().getExerciseProvision().getEventType();
		String tradeId = sdrRequest.getTrade().getTradeHeader().getTradeId();

		// Check if trade id exist REG_REP_TRADE table
		RegRepTrade regRepTrade = getTradeByTradeId(tradeId);
		
		if(regRepTrade != null){
			
			if(StringUtils.equalsIgnoreCase(eventType, NEW_DEAL)){

				// Raise warning
				
			}else{
				
				// Check status in REG_REP_MESSAGE table				
				RegRepMessage regRepMessage = getMessageByLatestRegRepMsgId(regRepTrade.getLatestRegRepMessageId());
				if(!StringUtils.equalsIgnoreCase(regRepMessage.getLifecycleEventType(), EXPIRY) && 
				   !StringUtils.equalsIgnoreCase(regRepMessage.getLifecycleEventType(), TERMINATION) &&
				   !StringUtils.equalsIgnoreCase(regRepMessage.getLifecycleEventType(), NOVATION)){
					flag = true;
				}
			}
		}else
		{
			// Trade Id does not exist
			
			// Check if event type is New Deal
			if(StringUtils.equalsIgnoreCase(eventType, NEW_DEAL)){
				flag = true;
			}else{
				// throw exception if life cycle even is not NEW_DEAL
				throw new Exception("Error");
			}
		}
		
		return flag;
	}

	private RegRepMessage getMessageByLatestRegRepMsgId(String latestRegRepMessageId) {
		return null;
	}

	private RegRepTrade getTradeByTradeId(String tradeId) {
		return null;
	}
	
	
	
	public static void test() throws ScriptException{
		System.out.println("test");
		ScriptEngineManager manager = new ScriptEngineManager ();
		ScriptEngine engine = manager.getEngineByName("JavaScript");
	    
	    SdrRequest request = new SdrRequest();

	    TradeHeaderType header = new TradeHeaderType();
	    header.setTradeId("1234");
	    
	    LifeCycleType lifeCycle = new LifeCycleType();
	    lifeCycle.setEventType("New Deal");
	    
	    header.setLifeCycle(lifeCycle);
	    
	    TradeType tradeType = new TradeType();
	    tradeType.setTradeHeader(header);
	    
	    request.setTrade(tradeType);
	    
	    engine.put("request", request);
	    
	    System.out.println(engine.eval("request.getTrade().getTradeHeader().getTradeId() == '1234'"));
	    
	    List<String> list = new ArrayList<String>();
	    list.add("ram");
	    list.add("shyam");
	    
	    engine.put("list", list);
	    
	    System.out.println(engine.eval("!list.contains('shyam')"));
	    
	    values.add("greenList.contains(request.getTrade().getTradeHeader().getTradeId())");
		values.add("redList.contains(request.getTrade().getTradeHeader().getTradeId())");
		values.add("!eventType.equals('New Deal')");
	    
	    List<String> greenList = new ArrayList<String>();
	    greenList.add("111");
	    greenList.add("222");
	    engine.put("greenList", greenList);
	    
	    List<String> redList = new ArrayList<String>();
	    redList.add("333");
	    redList.add("444");
	    engine.put("redList", redList);
	    
	    boolean result = Boolean.FALSE;
	    
	    List<String> ruleList = RuleConfigMappingCache.getInstance().getValues("ValidationTrade");
	    for(String rule : ruleList){
	    	 result = (Boolean)engine.eval(rule);
	    }
	    
	    System.out.println(result);
	}
	
	public static void main(String[] args) throws ScriptException {
	
		SdrRequest request = new SdrRequest();

	    TradeHeaderType header = new TradeHeaderType();
	    header.setTradeId("1234");
	    
	    LifeCycleType lifeCycle = new LifeCycleType();
	    lifeCycle.setEventType("Something Else");
	    
	    header.setLifeCycle(lifeCycle);
	    
	    TradeType tradeType = new TradeType();
	    tradeType.setTradeHeader(header);
	    
	    request.setTrade(tradeType);
	    
	    engine.put("request", request);
	    
	    List<String> greenList = new ArrayList<String>();
	    greenList.add("111");
	    greenList.add("222");
	    engine.put("greenList", greenList);
	    
	    List<String> redList = new ArrayList<String>();
	    redList.add("333");
	    redList.add("444");
	    engine.put("redList", redList);	
		
		
		Map<String, List<ValidationRule>> cache = new HashMap<String, List<ValidationRule>>();
		ValidationRule rule = new ValidationRule();
		rule.setRuleId("12");
		rule.setExpression("greenList.contains(request.getTrade().getTradeHeader().getTradeId())");
		rule.setResult("false");
		rule.setConsequence("process:17");
		
		ValidationRule rule1 = new ValidationRule();
		rule1.setRuleId("17");
		rule1.setExpression("request.getTrade().getTradeHeader().getLifeCycle().getEventType().equals('New Deal')");
		rule1.setResult("false");
		rule1.setConsequence("result:exception");
		
		List<ValidationRule> ruleList = new ArrayList<ValidationRule>();
		
		ruleList.add(rule);
		ruleList.add(rule1);
		
		cache.put("1", ruleList);
		
		List<ValidationRule > ruleList1 = cache.get("1");
		
		ValidationRule initialRule = ruleList1.get(0);
		evaluate(ruleList1, initialRule);
	}
	
	public static RuleExecutionResult evaluate(List<ValidationRule> ruleListForCategory, ValidationRule ruleToExecute)throws ScriptException{
		RuleExecutionResult ruleExecutionResult = new RuleExecutionResult();
		
		String expResult = engine.eval(ruleToExecute.getExpression()).toString();
		ValidationRule ruleInExecution = locateConsequenceForRule(expResult, ruleToExecute, ruleListForCategory);
		
		String consequence = ruleInExecution.getConsequence();
		String[] tasks = consequence.split(":");
		if("process".equals(tasks[0])) {
			// in the rule list get the rule for rule id = consequence id
			ValidationRule nextRuleInExecution = findNextRule( tasks[1], ruleListForCategory);
			evaluate(ruleListForCategory, nextRuleInExecution);
		}
		else if("result".equals(tasks[0])){
			String ruleDescription = getRuleDescription(ruleInExecution.getRuleId());
			ruleExecutionResult.setMsg(ruleDescription);
		}
		
		return ruleExecutionResult;
	}

	private static String getRuleDescription(String ruleId) {
		
		// TODO : get rule description from RULE table
		
		return null;
	}

	private static ValidationRule findNextRule(String consequence, List<ValidationRule> ruleSetList) {
		
		ValidationRule returnRule = null;
		for(ValidationRule rule: ruleSetList) {
			if(rule.getRuleId().equals(consequence)) {
				returnRule = rule;
			}
		}
		return returnRule;
	}
	
	
	private static ValidationRule locateConsequenceForRule(String expResult, ValidationRule validationRule, List<ValidationRule> ruleSetList) {
		
		ValidationRule returnRule = null;
		for(ValidationRule rule: ruleSetList) {
			if(rule.getRuleId().equals(validationRule.getRuleId()) && rule.getCategoryId().equals(validationRule.getCategoryId()) && expResult.equals(validationRule.getResult())) {
				returnRule = rule;
			}
		}
		return returnRule;
	}
*/}
