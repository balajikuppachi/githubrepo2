package com.wellsfargo.validator.framework;


public class RuleFrameworkConstant {
	
	
	static final String REQUEST = "request";
	static final String ELIGIBLE_TRADES = "eligibleTrades";
	static final String NOT_ELIGIBLE_TRADES = "notEligibleTrades";
	
	static final String PROCESS = "process";
	static final String RESULT = "result";
	
	static final String EXCEPTION = "exception";
	static final String ELIGIBLE = "eligible";
	static final String INELIGIBLE = "ineligible";
	

}
