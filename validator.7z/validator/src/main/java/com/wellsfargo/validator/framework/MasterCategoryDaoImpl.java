package com.wellsfargo.validator.framework;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.validator.framework.RuleDaoImpl.RuleRowMapper;

public class MasterCategoryDaoImpl implements MasterCategoryDao {

private static Logger logger = Logger.getLogger(MasterCategoryDaoImpl.class);
	
	private JdbcTemplate jdbcTemplate;
		
	public MasterCategoryDaoImpl(JdbcTemplate jdbcTemplate) 
	{
		this.jdbcTemplate = jdbcTemplate;	
	}	
	
	@Override
	public List<MasterCategory> findAll() {
		logger.info("Entering findAll() method");

        String query = RuleQueryMaster.GET_ALL_CATEGORIES;

        List<MasterCategory> masterCategories = new ArrayList<MasterCategory>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

        for (Map<String, Object> row : rows) 
        {
        	MasterCategory masterCategory = new MasterCategory();

        	masterCategory.setCategoryId((String)row.get("CAT_ID"));
        	masterCategory.setRuleId((String)row.get("RULE_ID"));

        	masterCategories.add(masterCategory);
        }
		logger.info("Leaving findAll() method");
        
        return masterCategories;
	}
	
	public String findRuleIdByCatId(String id) {
		logger.info("Entering findRuleById() method");

        String query = RuleQueryMaster.GET_RULES_BY_CATEGERY_ID;
        
        String ruleId = (String)jdbcTemplate.queryForObject(
        		query, new Object[] { id }, String.class);

		
		return ruleId;
	}
	
	

}
