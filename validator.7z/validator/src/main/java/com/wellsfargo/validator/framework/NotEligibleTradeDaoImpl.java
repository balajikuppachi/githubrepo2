package com.wellsfargo.validator.framework;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

public class NotEligibleTradeDaoImpl implements NotEligibleTradeDao {

private static Logger logger = Logger.getLogger(NotEligibleTradeDaoImpl.class);
	
	private JdbcTemplate jdbcTemplate;
		
	public NotEligibleTradeDaoImpl(JdbcTemplate jdbcTemplate) 
	{
		this.jdbcTemplate = jdbcTemplate;	
	}
	
	public void insertNotEligibleTrade(NotEligibleTrade notEligibleTrade) 
	{
		logger.debug("Entering insertNotEligibleTrade() method");
		
		String query = RuleQueryMaster.INSERT_NOT_ELIGIBLE_TRADE;

		jdbcTemplate.update(query, new Object[]{notEligibleTrade.getTradeId(), notEligibleTrade.getMsg()});

		logger.debug("Leaving insertNotEligibleTrade() method");
	}

	public EligibleTrade findConfigByKey(String key) 
	{	
		logger.debug("Entering findConfigByKey() method");
		
		EligibleTrade config = null;
		
		logger.debug("Leaving findConfigByKey() method");

		return config;
	}
   
    public List<NotEligibleTrade> findAll()
    {       
		logger.debug("Entering findAll() method");

        String query = RuleQueryMaster.GET_ALL_NOT_ELIGIBLE_TRADE;

        List<NotEligibleTrade> notEligibleTrades = new ArrayList<NotEligibleTrade>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

        for (Map<String, Object> row : rows) 
        {
        	NotEligibleTrade notEligibleTrade = new NotEligibleTrade();

        	notEligibleTrade.setTradeId((String) row.get("TRADE_ID"));
        	notEligibleTrade.setMsg((String) (row.get("MSG")));

        	notEligibleTrades.add(notEligibleTrade);

        }
        
		logger.debug("Leaving findAll() method");
        
        return notEligibleTrades;

    }

}
