package com.wellsfargo.validator.framework;

import java.util.List;

public interface RuleConfigMappingDao {

	public void insertConfig(RuleConfigMapping ruleConfigMapping);
	
	public RuleConfigMapping findConfigByKey(String key);
	
	public List<RuleConfigMapping> findAll();

	
}
