package com.wellsfargo.validator.framework;

import java.util.List;

public interface MasterCategoryDao {

	public List<MasterCategory> findAll();
	
	public String findRuleIdByCatId(String id);

}
