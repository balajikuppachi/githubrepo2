package com.wellsfargo.validator.framework;

public class ValidationRule implements java.io.Serializable {

	
	private String categoryId;
	
	private String ruleId;

	private String result;
	
	private String consequence;
	
	private String expression;
	
	
	public String getExpression() {
		return expression;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getConsequence() {
		return consequence;
	}

	public void setConsequence(String consequence) {
		this.consequence = consequence;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	@Override
	public String toString() {
		return "ValidationRule [categoryId=" + categoryId + ", ruleId="
				+ ruleId + ", result=" + result + ", consequence="
				+ consequence + ", expression=" + expression + "]";
	}
	
	
	
}
