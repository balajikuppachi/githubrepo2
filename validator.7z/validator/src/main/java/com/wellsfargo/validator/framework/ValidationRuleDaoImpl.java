package com.wellsfargo.validator.framework;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

public class ValidationRuleDaoImpl implements ValidationRuleDao {

private static Logger logger = Logger.getLogger(ValidationRuleDaoImpl.class);
	
	private JdbcTemplate jdbcTemplate;
		
	public ValidationRuleDaoImpl(JdbcTemplate jdbcTemplate) 
	{
		this.jdbcTemplate = jdbcTemplate;	
	}
	
	public void insertValidationRule(ValidationRule validationRule) 
	{
		logger.debug("Entering insertConfig() method");
		
		String query = RuleQueryMaster.INSERT_VALIDATION_RULE;

		jdbcTemplate.update(query, new Object[]{validationRule.getCategoryId(), validationRule.getRuleId(), validationRule.getExpression(), validationRule.getResult(), validationRule.getConsequence()});

		logger.debug("Leaving insertConfig() method");
	}

	public ValidationRule findConfigByKey(String key) 
	{	
		logger.debug("Entering findConfigByKey() method");
		
		ValidationRule config = null;
		
		logger.debug("Leaving findConfigByKey() method");

		return config;
	}
   
    public List<ValidationRule> findAll()
    {       
		logger.debug("Entering findAll() method");

        String query = RuleQueryMaster.GET_ALL_VALIDATION_RULE;

        List<ValidationRule> validationRules = new ArrayList<ValidationRule>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

        for (Map<String, Object> row : rows) 
        {
        	ValidationRule validationRule = new ValidationRule();

        	validationRule.setCategoryId((String)row.get("CAT_ID"));
        	validationRule.setRuleId((String)row.get("RULE_ID"));
        	validationRule.setExpression((String)(row.get("EXP")));        	
        	validationRule.setResult((String)(row.get("EXP_RESULT")));
        	validationRule.setConsequence((String)(row.get("EXP_CONSEQUENCE")));

        	validationRules.add(validationRule);

        }
        
		logger.debug("Leaving findAll() method");
        
        return validationRules;

    }

}
