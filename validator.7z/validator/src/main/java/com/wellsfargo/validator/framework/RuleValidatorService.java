package com.wellsfargo.validator.framework;

import java.util.List;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;


public class RuleValidatorService {

	private static Logger logger = Logger.getLogger(RuleValidatorService.class.getName());	
	
	private ScriptEngineManager manager = new ScriptEngineManager ();
	private ScriptEngine engine = manager.getEngineByName("JavaScript");
	
	@Autowired
	private RuleDao ruleDao;
	
	public void setRuleDao(RuleDao ruleDao) {
		this.ruleDao = ruleDao;
	}
	
	@Autowired
	private MasterCategoryDao masterCategoryDao;

	public void setMasterCategoryDao(MasterCategoryDao masterCategoryDao) {
		this.masterCategoryDao = masterCategoryDao;
	}

	public void execute(SdrRequest request) throws ScriptException {
		logger.info("================= Start Of Execution ===================");		
	
	    engine.put(RuleFrameworkConstant.REQUEST, request);
	    
	    EligibleTradesCache eligibleTradesCache = EligibleTradesCache.getInstance();
	    engine.put(RuleFrameworkConstant.ELIGIBLE_TRADES, eligibleTradesCache.getEligibleTrades());
	    
	    NotEligibleTradesCache notEligibleTradesCache = NotEligibleTradesCache.getInstance();
	    engine.put(RuleFrameworkConstant.NOT_ELIGIBLE_TRADES, notEligibleTradesCache.getNotEligibleTrades());	
	    
	    ValidationRuleCache validationRuleCache = ValidationRuleCache.getInstance();
		
		for(String category: validationRuleCache.getRuleConfigMap().keySet()) {
			List<ValidationRule > firstCategoryRuleList = validationRuleCache.getRuleConfigMap().get(category);
			
			String ruleID = masterCategoryDao.findRuleIdByCatId(category);
			
			ValidationRule initialRule = getInitialRule(ruleID, firstCategoryRuleList);
			RuleExecutionResult executionResult = new RuleExecutionResult();
			executionResult = evaluate(firstCategoryRuleList, initialRule, executionResult);
			
			logger.info("================= Error Messages ===================");
			for(String message: executionResult.getMsgList()) {
				logger.info("Error message >>>>>> " + message + '\n');
			}
		}
		logger.info("================= End Of Execution ===================");
	}
	
	private ValidationRule getInitialRule(String ruleID, List<ValidationRule> firstCategoryRuleList) {

		ValidationRule validationRule = null;
		for(ValidationRule rule : firstCategoryRuleList){
			if(ruleID.equals(rule.getRuleId())){
				validationRule = rule;
				break;
			}
		}
		return validationRule;
	}

	public RuleExecutionResult evaluate(List<ValidationRule> ruleListForCategory, ValidationRule ruleToExecute, RuleExecutionResult executionResult)throws ScriptException{
		
		logger.info("Expression to be executed : " + ruleToExecute.getExpression());	
		String expResult = engine.eval(ruleToExecute.getExpression()).toString();
		logger.info("rule : evaluation for " + ruleToExecute.getExpression() + " is:>>>>> " + expResult);
		ValidationRule ruleInExecution = locateConsequenceForRule(expResult, ruleToExecute, ruleListForCategory);
		
		if(ruleInExecution != null){
			String consequence = ruleInExecution.getConsequence();
			logger.info("Consequence : " + ruleToExecute.getConsequence());	
			
			String[] tasks = consequence.split(":");
			if(RuleFrameworkConstant.PROCESS.equals(tasks[0])) {
				// in the rule list get the rule for rule id = consequence id
				ValidationRule nextRuleInExecution = findNextRule( tasks[1], ruleListForCategory, expResult);
				executionResult = evaluate(ruleListForCategory, nextRuleInExecution, executionResult);
			}
			else if(RuleFrameworkConstant.RESULT.equals(tasks[0])){
				SdrRequest sdrRequest = (SdrRequest) engine.get(RuleFrameworkConstant.REQUEST);
				//check if we have to update list or exception or both
				//check the string
				if(tasks.length == 2) {
					if(RuleFrameworkConstant.EXCEPTION.equals(tasks[1])) {
						executionResult.getMsgList().add("Error in " +  getRuleDescription(ruleInExecution.getRuleId()));
					}
					else if(RuleFrameworkConstant.ELIGIBLE.equals(tasks[1])){
						EligibleTradesCache.getInstance().setValue(sdrRequest.getTrade().getTradeHeader().getTradeId());
					}
					else if(RuleFrameworkConstant.INELIGIBLE.equals(tasks[1])) {
						NotEligibleTradesCache.getInstance().setValue(sdrRequest.getTrade().getTradeHeader().getTradeId());
					}
				}
				else if(tasks.length == 3) {
					executionResult.getMsgList().add("Error in " +  getRuleDescription(ruleInExecution.getRuleId()));
					if(RuleFrameworkConstant.ELIGIBLE.equals(tasks[2])) {
						EligibleTradesCache.getInstance().setValue(sdrRequest.getTrade().getTradeHeader().getTradeId());
					}
					else if(RuleFrameworkConstant.INELIGIBLE.equals(tasks[2])) {
						NotEligibleTradesCache.getInstance().setValue(sdrRequest.getTrade().getTradeHeader().getTradeId());
					}
				}
			}
		}
		return executionResult;
	}

	private String getRuleDescription(String ruleId) {
		Rule rule = ruleDao.findRuleById(ruleId);
		logger.info("Rule Desciption Retrieved : " + rule.toString());	
		return rule.getRuleName();
	}

	private ValidationRule findNextRule(String consequence, List<ValidationRule> ruleSetList, String expResult) {
		
		ValidationRule returnRule = null;
		for(ValidationRule rule: ruleSetList) {
			if(rule.getRuleId().equals(consequence) && expResult.toUpperCase().equals(rule.getResult())) {
				returnRule = rule;
				break;
			}
		}
		return returnRule;
	}
	
	
	private ValidationRule locateConsequenceForRule(String expResult, ValidationRule validationRule, List<ValidationRule> ruleSetList) {
		
		ValidationRule returnRule = null;
		for(ValidationRule rule: ruleSetList) {
			if(rule.getRuleId().equals(validationRule.getRuleId()) && rule.getCategoryId().equals(validationRule.getCategoryId()) && expResult.toUpperCase().equals(rule.getResult())) {
				returnRule = rule;
				break;
			}
		}
		
		if(returnRule!= null){
			logger.info(" Consequence ValidationRule : " + returnRule.toString());
		}
		
		return returnRule;
	}
}
