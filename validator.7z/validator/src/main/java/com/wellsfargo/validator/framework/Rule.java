package com.wellsfargo.validator.framework;

public class Rule implements java.io.Serializable {
	
	private String ruleName;
	
	private String ruleId;

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	@Override
	public String toString() {
		return "Rule [ruleName=" + ruleName + ", ruleId=" + ruleId + "]";
	}
	
	
	
}
