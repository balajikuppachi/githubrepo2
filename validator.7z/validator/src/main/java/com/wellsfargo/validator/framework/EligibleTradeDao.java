package com.wellsfargo.validator.framework;

import java.util.List;

public interface EligibleTradeDao {

	public void insertEligibleTrade(EligibleTrade eligibleTrade);
	
	public EligibleTrade findConfigByKey(String key);
	
	public List<EligibleTrade> findAll();

	
}
