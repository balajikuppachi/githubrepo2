package com.wellsfargo.validator.framework;

import javax.script.ScriptException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;

public class RuleValidator {

	private static Logger logger = Logger.getLogger(RuleValidator.class.getName());
	
	private ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();

	private static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:/rule-framework-context.xml";

	private void start() throws ScriptException {
		logger.info("================= Start Of Process ===================");		
		try {
			init();
		} catch (Exception e) {
			logger.error("Could not initialize the application - shutting down",e);
			e.printStackTrace();
			System.exit(1);
		}

		context.setConfigLocation(APPLICATION_CONTEXT_CONFIG_LOCATION);
		context.registerShutdownHook();
		try {
			context.refresh();
		} catch (Throwable e) {
			logger.error("Could not start application context - shutting down",e);
			e.printStackTrace();
			System.exit(2);
		}
		
		RuleValidatorService validatorService = (RuleValidatorService) context.getBean("ruleValidatorService");
		
		SdrRequest request = populateRequest();
		
		validatorService.execute(request);
		
		logger.info("================= Green Cache ===================");	
		for(String trade: EligibleTradesCache.getInstance().getEligibleTrades()) {
			logger.info(">>>>>>>Eligible Trade : " + trade);
		}
		
		logger.info("================= Red Cache ===================");	
		for(String trade: NotEligibleTradesCache.getInstance().getNotEligibleTrades()) {
			logger.info(">>>>>>>Not Eligible Trade : " + trade);
		}
		
		logger.info("================= End Of Process ===================");		
	}

	private SdrRequest populateRequest() {
		
		SdrRequest request = new SdrRequest();

	    TradeHeaderType header = new TradeHeaderType();
	    header.setTradeId("9999");
	    
	    LifeCycleType lifeCycle = new LifeCycleType();
	    lifeCycle.setEventType("New Deal");
	    
	    header.setLifeCycle(lifeCycle);
	    
	    TradeType tradeType = new TradeType();
	    tradeType.setTradeHeader(header);
	    
	    request.setTrade(tradeType);
		return request;
	}

	private void init() throws Exception {
		
		logger.info("================= Start Of Init Process ===================");

		/*String portrecDataDirPath = System.getProperty("PORTREC_DATA_DIR");
		logger.info("PORTREC_DATA_DIR=" + portrecDataDirPath);*/
		
		logger.info("================= End Of Init Process ===================");
	}
	
	public static void main(String[] args) throws ScriptException {
		new RuleValidator().start();
	}

	
}

