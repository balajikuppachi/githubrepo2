package com.wellsfargo.validator.framework;

import java.util.ArrayList;
import java.util.List;


public class EligibleTradesCache {
	
	private static EligibleTradesCache instance;
	private List<String> eligibleTrades;
	
	private EligibleTradesCache() {
		
		eligibleTrades = new ArrayList<String>();		
	}
	
	public static EligibleTradesCache getInstance(){
		if(null == instance){
			instance = new EligibleTradesCache();
			EligibleTradeCacheLoader.loadEligibleTradeCache(instance);
		}
		return instance;
	}
	

	public void setValue(String tradeId){
		eligibleTrades.add(tradeId);
	}
	
	public boolean contains(String tradeId){
		return eligibleTrades.contains(tradeId);
	}

	public List<String> getEligibleTrades() {
		return eligibleTrades;
	}

}
