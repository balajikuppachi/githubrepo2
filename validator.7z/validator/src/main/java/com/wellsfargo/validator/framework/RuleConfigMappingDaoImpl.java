package com.wellsfargo.validator.framework;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.cache.dao.impl.DRLConfigDaoImpl;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;

public class RuleConfigMappingDaoImpl implements RuleConfigMappingDao {

private static Logger logger = Logger.getLogger(DRLConfigDaoImpl.class);
	
	private JdbcTemplate jdbcTemplate;
		
	public RuleConfigMappingDaoImpl(JdbcTemplate jdbcTemplate) 
	{
		this.jdbcTemplate = jdbcTemplate;	
	}
	
	public void insertConfig(RuleConfigMapping drlConfig) 
	{
		logger.debug("Entering insertConfig() method");
		
		String query = QueryMaster.INSERT_CONFIG;

		jdbcTemplate.update(query, new Object[]{drlConfig.getId(), drlConfig.getCategoryId(), drlConfig.getValidationTypeId(), drlConfig.getIsValidationApplicable(),
				drlConfig.getRuleId(), drlConfig.getIsRuleApplicable()});

		logger.debug("Leaving insertConfig() method");
	}

	public RuleConfigMapping findConfigByKey(String key) 
	{	
		logger.debug("Entering findConfigByKey() method");
		
		RuleConfigMapping config = null;
		
		logger.debug("Leaving findConfigByKey() method");

		return config;
	}
   
    public List<RuleConfigMapping> findAll()
    {       
		logger.debug("Entering findAll() method");

        String query = QueryMaster.GET_ALL_CONFIG;

        List<RuleConfigMapping> configs = new ArrayList<RuleConfigMapping>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

        for (Map<String, Object> row : rows) 
        {
        	RuleConfigMapping config = new RuleConfigMapping();

        	/*config.setRegRepRulesConfigId((Integer)row.get("REG_REP_RULES_CONFIG_ID"));
        	config.setReportingJurisdiction((String)row.get("REPORTING_JURISDICTION"));
        	config.setRepository((String)(row.get("REPOSITORY")));        	
        	config.setFileLocation((String)(row.get("FILE_LOCATION")));
        	config.setDrlType((String)(row.get("DRL_TYPE")));
        	config.setDrlKey((String)(row.get("DRL_KEY")));*/

            configs.add(config);

        }
        
		logger.debug("Leaving findAll() method");
        
        return configs;

    }

}
