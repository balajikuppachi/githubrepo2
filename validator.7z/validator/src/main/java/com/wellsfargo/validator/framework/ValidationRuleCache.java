package com.wellsfargo.validator.framework;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ValidationRuleCache {
	
	private static ValidationRuleCache instance;
	private Map<String, List<ValidationRule>> ruleConfigMap;

	private ValidationRuleCache() {
		
		ruleConfigMap = new HashMap<String, List<ValidationRule>>();		
	}
	
	public static ValidationRuleCache getInstance(){
		if(null == instance){
			instance = new ValidationRuleCache();			
			ValidationRuleCacheLoader.loadRulesConfigMappingCache(instance);
		}
		
		return instance;
	}
	

	public void setValue(String key, List<ValidationRule> values){
		ruleConfigMap.put(key, values);
	}
	
	public List<ValidationRule> getValues(String key){
		return ruleConfigMap.get(key);
	}

	public Map<String, List<ValidationRule>> getRuleConfigMap() {
		return ruleConfigMap;
	}
	
}
