package com.wellsfargo.validator.framework;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

public class EligibleTradeCacheLoader {	
	
	@Autowired
	private static EligibleTradeDao eligibleTradeDao;
	
	private static Logger logger = Logger.getLogger(EligibleTradeCacheLoader.class.getName());
	
	public void setEligibleTradeDao(EligibleTradeDao dao) {
		EligibleTradeCacheLoader.eligibleTradeDao = dao;
	}
	
	public static void loadEligibleTradeCache(EligibleTradesCache eligibleTradesCache){	
				
		List<EligibleTrade> configList = eligibleTradeDao.findAll();
				
		for(EligibleTrade config : configList){
			
			eligibleTradesCache.setValue(config.getTradeId());			
		}
		
		logger.debug("Successfully instantiated Eligible Trade cache.");
	}

}
