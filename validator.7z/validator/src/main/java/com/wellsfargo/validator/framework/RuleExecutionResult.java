package com.wellsfargo.validator.framework;

import java.util.ArrayList;
import java.util.List;


public class RuleExecutionResult implements java.io.Serializable {
	
	private List<String> msgList = new ArrayList<String>();

	public List<String> getMsgList() {
		return msgList;
	}

	public void setMsgList(List<String> msgList) {
		this.msgList = msgList;
	}
	
	

}
