package com.wellsfargo.validator.framework;

import java.util.ArrayList;
import java.util.List;


public class NotEligibleTradesCache {
	
	private static NotEligibleTradesCache instance;
	private List<String> notEligibleTrades;
	
	private NotEligibleTradesCache() {
		
		notEligibleTrades = new ArrayList<String>();		
	}
	
	public static NotEligibleTradesCache getInstance(){
		if(null == instance){
			instance = new NotEligibleTradesCache();
			NotEligibleTradeCacheLoader.loadEligibleTradeCache(instance);
		}
		return instance;
	}
	

	public void setValue(String tradeId){
		notEligibleTrades.add(tradeId);
	}
	
	public boolean contains(String tradeId){
		return notEligibleTrades.contains(tradeId);
	}

	public List<String> getNotEligibleTrades() {
		return notEligibleTrades;
	}
	
}
