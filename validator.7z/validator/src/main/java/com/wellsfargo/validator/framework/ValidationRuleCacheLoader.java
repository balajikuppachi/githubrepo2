package com.wellsfargo.validator.framework;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

public class ValidationRuleCacheLoader {	
	
	@Autowired
	private static ValidationRuleDao validationRuleDao;
	
	/*@Autowired
	private static MasterCategoryDao masterCategoryDao;*/
	
	private static Logger logger = Logger.getLogger(ValidationRuleCacheLoader.class.getName());
	
	public void setRuleConfigMappingDao(ValidationRuleDao dao) {
		ValidationRuleCacheLoader.validationRuleDao = dao;
	}
	
	/*public void setMasterCategoryDao(MasterCategoryDao dao) {
		ValidationRuleCacheLoader.masterCategoryDao = dao;
	}*/
	
	public static void loadRulesConfigMappingCache(ValidationRuleCache validationRuleCache){	
				
		String key	= null;
		List<ValidationRule>	values		= null;

		List<ValidationRule> configList = validationRuleDao.findAll();
				
		/*List<MasterCategory> categoryList = masterCategoryDao.loadAll();
		
		for(MasterCategory masterCategory : categoryList){
			
		}*/
		
		
		for(ValidationRule config : configList){
			
			key = config.getCategoryId();
			values = validationRuleCache.getValues(key);
			
			if(null == values){
				values = new ArrayList<ValidationRule>();
			}
			
			values.add(config);
			validationRuleCache.setValue(key, values);			
		}
		
		logger.debug("Successfully instantiated Rules Config Mapping cache.");
	}

}
