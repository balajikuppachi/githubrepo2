package com.wellsfargo.validator.framework;

import java.util.List;

public interface ValidationRuleDao {

	public void insertValidationRule(ValidationRule validationRule);
	
	public ValidationRule findConfigByKey(String key);
	
	public List<ValidationRule> findAll();

	
}
