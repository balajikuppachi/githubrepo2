package com.wellsfargo.validator.framework;

public class RuleQueryMaster {
	
	public static final String INSERT_ELIGIBLE_TRADE = "INSERT INTO RF_ELIGIBLE_TRADE (TRADE_ID, MSG) values(?,?)";
	
	public static final String INSERT_NOT_ELIGIBLE_TRADE = "INSERT INTO RF_NOT_ELIGIBLE_TRADE (TRADE_ID, MSG) values(?,?)";
	
	public static final String INSERT_VALIDATION_RULE = "INSERT INTO RF_VALIDATION_RULE (CAT_ID, RULE_ID, EXP, EXP_RESULT, EXP_CONSEQUENCE) values(?,?)";
	
		
	public static final String GET_ALL_ELIGIBLE_TRADE =	"SELECT * FROM RF_ELIGIBLE_TRADE";
	
	public static final String GET_ALL_NOT_ELIGIBLE_TRADE =	"SELECT * FROM RF_NOT_ELIGIBLE_TRADE";
		
	public static final String GET_ALL_VALIDATION_RULE = "SELECT * FROM RF_VALIDATION_RULE";
	
	public static final String GET_ALL_RULE = "SELECT * FROM RF_RULE";
	
	public static final String GET_ALL_CATEGORY = "SELECT * FROM RF_CATEGORY";	
	
	public static final String GET_RULE_BY_RULE_ID = "SELECT * FROM RF_RULE WHERE RULE_ID = ?";
	
	public static final String GET_RULES_BY_CATEGERY_ID = "SELECT RULE_ID FROM RF_CATEGORY_RULE_MAPPING WHERE CAT_ID = ? ";
	
	public static final String GET_ALL_CATEGORIES = "SELECT * FROM RF_CATEGORY_RULE_MAPPING";	
	
	
}
