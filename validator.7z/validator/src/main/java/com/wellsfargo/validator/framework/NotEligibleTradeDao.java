package com.wellsfargo.validator.framework;

import java.util.List;

public interface NotEligibleTradeDao {

	public void insertNotEligibleTrade(NotEligibleTrade notEligibleTrade);
	
	public EligibleTrade findConfigByKey(String key);
	
	public List<NotEligibleTrade> findAll();

	
}
