package com.wellsfargo.validator.framework;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

public class RuleConfigMappingCacheLoader {	
	
	@Autowired
	private static RuleConfigMappingDao ruleConfigMappingDao;
	
	private static Logger logger = Logger.getLogger(RuleConfigMappingCacheLoader.class.getName());
	
	public void setRuleConfigMappingDao(RuleConfigMappingDao dao) {
		RuleConfigMappingCacheLoader.ruleConfigMappingDao = dao;
	}
	
	public static void loadRulesConfigMappingCache(RuleConfigMappingCache ruleConfigMappingCache){	
				
		String 			key			= null;
		List<String>	values		= null;

		//List<RuleConfigMapping> configList = ruleConfigMappingDao.findAll();
				
		
		//List<RuleConfigMapping> configList =  new ArrayList<RuleConfigMapping>();
		
		
		//for(RuleConfigMapping config : configList){
			
			//key = config.getCategoryId() + config.getValidationTypeId();
			key = "ValidationTrade";
			
			values = ruleConfigMappingCache.getValues(key);
			
			if(null == values){
				values = new ArrayList<String>();
			}
			
			String ruleString = "!(greenList.contains(request.getTrade().getTradeHeader().getTradeId()" + " || "
								+ "redList.contains(request.getTrade().getTradeHeader().getTradeId())))" + " && "
								+ "!request.getTrade().getTradeHeader().getLifeCycle().getEventType().equals('New Deal')";
			//values.add("greenList.contains(request.getTrade().getTradeHeader().getTradeId())");
			//values.add("redList.contains(request.getTrade().getTradeHeader().getTradeId())");
			//values.add("!request.getTrade().getTradeHeader().getLifeCycle().getEventType().equals('New Deal')");
			System.out.println(ruleString);
			values.add(ruleString);
			
			//values.add(config.getRuleId());
			ruleConfigMappingCache.setValue(key, values);			
		//}
		
		logger.debug("Successfully instantiated Rules Config Mapping cache.");
	}

}
