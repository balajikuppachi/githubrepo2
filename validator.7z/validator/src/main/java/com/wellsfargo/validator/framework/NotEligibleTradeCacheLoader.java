package com.wellsfargo.validator.framework;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

public class NotEligibleTradeCacheLoader {	
	
	@Autowired
	private static NotEligibleTradeDao notEligibleTradeDao;
	
	private static Logger logger = Logger.getLogger(NotEligibleTradeCacheLoader.class.getName());
	
	public void setNotEligibleTradeDao(NotEligibleTradeDao dao) {
		NotEligibleTradeCacheLoader.notEligibleTradeDao = dao;
	}
	
	public static void loadEligibleTradeCache(NotEligibleTradesCache notEligibleTradesCache){	
				
		List<NotEligibleTrade> configList = notEligibleTradeDao.findAll();
				
		for(NotEligibleTrade config : configList){
			
			notEligibleTradesCache.setValue(config.getTradeId());			
		}
		
		logger.debug("Successfully instantiated Not Eligible Trade cache.");
	}

}
