package com.wellsfargo.validator.framework;

public class RuleConfigMapping implements java.io.Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	
	private String categoryId;
	
	private String validationTypeId;
	
	private String isValidationApplicable;	
	
	private String ruleId;
	
	private String isRuleApplicable;

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getValidationTypeId() {
		return validationTypeId;
	}

	public void setValidationTypeId(String validationTypeId) {
		this.validationTypeId = validationTypeId;
	}

	public String getIsValidationApplicable() {
		return isValidationApplicable;
	}

	public void setIsValidationApplicable(String isValidationApplicable) {
		this.isValidationApplicable = isValidationApplicable;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getIsRuleApplicable() {
		return isRuleApplicable;
	}

	public void setIsRuleApplicable(String isRuleApplicable) {
		this.isRuleApplicable = isRuleApplicable;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	

	
}
