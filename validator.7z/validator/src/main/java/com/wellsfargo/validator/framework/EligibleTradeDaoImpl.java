package com.wellsfargo.validator.framework;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

public class EligibleTradeDaoImpl implements EligibleTradeDao {

	private static Logger logger = Logger.getLogger(EligibleTradeDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public EligibleTradeDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void insertEligibleTrade(EligibleTrade eligibleTrade) {
		logger.debug("Entering insertEligibleTrade() method");

		String query = RuleQueryMaster.INSERT_ELIGIBLE_TRADE;

		jdbcTemplate.update(query, new Object[] { eligibleTrade.getTradeId(),
				eligibleTrade.getMsg() });

		logger.debug("Leaving insertEligibleTrade() method");
	}

	public EligibleTrade findConfigByKey(String key) {
		logger.debug("Entering findConfigByKey() method");

		EligibleTrade config = null;

		logger.debug("Leaving findConfigByKey() method");

		return config;
	}

	public List<EligibleTrade> findAll() {
		logger.debug("Entering findAll() method");

		String query = RuleQueryMaster.GET_ALL_ELIGIBLE_TRADE;

		List<EligibleTrade> eligibleTrades = new ArrayList<EligibleTrade>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

		for (Map<String, Object> row : rows) {
			EligibleTrade eligibleTrade = new EligibleTrade();

			eligibleTrade.setTradeId((String) row.get("TRADE_ID"));
			eligibleTrade.setMsg((String) (row.get("MSG")));

			eligibleTrades.add(eligibleTrade);

		}

		logger.debug("Leaving findAll() method");

		return eligibleTrades;

	}

}
