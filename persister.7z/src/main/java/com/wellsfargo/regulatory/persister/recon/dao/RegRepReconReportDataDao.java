package com.wellsfargo.regulatory.persister.recon.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportData;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public interface RegRepReconReportDataDao extends Serializable, Dao<RegRepReconReportData>
{

	public List<RegRepReconReportData> getReconReportData(Date reportDate, String source1, String source2);
}
