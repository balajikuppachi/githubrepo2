package com.wellsfargo.regulatory.persister.util.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportData;
import com.wellsfargo.regulatory.persister.util.dao.RegRepSequenceIdDao;
import com.wellsfargo.regulatory.persister.util.dto.RegRepSequenceId;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class RegRepSequenceIdDaoImpl extends AbstractDaoImpl<RegRepSequenceId> implements RegRepSequenceIdDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private DataSource dataSource;
	private SimpleJdbcCall simpleJdbcCall;
	private String storedProcName;
	private String reconProc;

	
    private JdbcTemplate m_jdbcTemplate;
    
    public JdbcTemplate getJdbcTemplate() 
    {
        return m_jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) 
    {
        m_jdbcTemplate = jdbcTemplate;
    }

	
	@Override
	public Class<RegRepSequenceId> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepSequenceId.class;
	}

	@SuppressWarnings("unchecked")
	public RegRepSequenceId getNextRegRepSequnceId(String queryName, int sequenceCode)
	{

		this.simpleJdbcCall = new SimpleJdbcCall(dataSource).withProcedureName(storedProcName);
		SqlParameterSource in = new MapSqlParameterSource().addValue("nextIdType", sequenceCode);
		Map<String, Object> out = simpleJdbcCall.execute(in);

		RegRepSequenceId regRepSequenceId = new RegRepSequenceId();
		regRepSequenceId.setSequenceId(Integer.parseInt(String.valueOf(out.get("nextIdValue"))));

		// return ((List<T>) getNextSequenceIdUsingStoredProc(queryName, sequenceCode));
		return regRepSequenceId;
	}

	@SuppressWarnings("unchecked")
	public List<RegRepReconReportData> getReconReportData(Date reportDate, String source1, String source2)
	{
		List<RegRepReconReportData> regRepReconReportDataList = new ArrayList<RegRepReconReportData>();
		this.simpleJdbcCall = new SimpleJdbcCall(dataSource).withProcedureName(reconProc);
		SqlParameterSource in = new MapSqlParameterSource().addValue("reportDate", reportDate).addValue("source1", source1).addValue("source2", source2);
		Map<String, Object> out = simpleJdbcCall.execute(in);

		Object reconResultsSet = out.get("#result-set-1");
		String reconResultsString = reconResultsSet.toString();
		String[] reconResultsArray = reconResultsString.split("}");
		
		RegRepReconReportData currRegRepReconReportData = null;

		for (String resultObj : reconResultsArray)
		{
			currRegRepReconReportData = regRepReconReportDataRowMapper(resultObj);
			
			if(null != currRegRepReconReportData)
				regRepReconReportDataList.add(currRegRepReconReportData);

		}

		// return ((List<T>) getNextSequenceIdUsingStoredProc(queryName, sequenceCode));
		return regRepReconReportDataList;
	}

	private RegRepReconReportData regRepReconReportDataRowMapper(String resultObjStr)
	{
		RegRepReconReportData currRegRepReconReportData = new RegRepReconReportData();
		String[] currResultObjSet = null;
		String updatedKeyValueStr1 = null;
		String updatedKeyValueStr = null;

		if (StringUtils.isNotBlank(resultObjStr))
		{
			currResultObjSet = resultObjStr.split(",");

			for (String keyValueString : currResultObjSet)
			{

				updatedKeyValueStr1 = 	StringUtils.replaceChars(keyValueString.trim(), "{", "");
				updatedKeyValueStr = StringUtils.replaceChars(updatedKeyValueStr1, "[", "");

				String key = StringUtils.substringBefore(updatedKeyValueStr, "=").trim();
				String value = StringUtils.substringAfter(updatedKeyValueStr, "=").trim();

				if (StringUtils.isNotBlank(key))
				{
					if (key.equalsIgnoreCase("category")) currRegRepReconReportData.setCategory(value);
					if (key.equalsIgnoreCase("row_id1")) currRegRepReconReportData.setRow_id1(value);
					if (key.equalsIgnoreCase("trade_id1")) currRegRepReconReportData.setTrade_id1(value);
					if (key.equalsIgnoreCase("sender_trade_ref_id1")) currRegRepReconReportData.setSender_trade_ref_id1(value);
					if (key.equalsIgnoreCase("usi1")) currRegRepReconReportData.setUsi1(value);
					if (key.equalsIgnoreCase("trade_date1")) currRegRepReconReportData.setTrade_date1(value);
					if (key.equalsIgnoreCase("start_date1")) currRegRepReconReportData.setStart_date1(value);
					if (key.equalsIgnoreCase("maturity_date1")) currRegRepReconReportData.setMaturity_date1(value);
					if (key.equalsIgnoreCase("OurName1")) currRegRepReconReportData.setOurName1(value);
					if (key.equalsIgnoreCase("OurLEI1")) currRegRepReconReportData.setOurLEI1(value);
					if (key.equalsIgnoreCase("CptyName1")) currRegRepReconReportData.setCptyName1(value);
					if (key.equalsIgnoreCase("CptyLEI1")) currRegRepReconReportData.setCptyLEI1(value);
					if (key.equalsIgnoreCase("rp1")) currRegRepReconReportData.setRp1(value);

					if (key.equalsIgnoreCase("row_id2")) currRegRepReconReportData.setRow_id2(value);
					if (key.equalsIgnoreCase("trade_id2")) currRegRepReconReportData.setTrade_id2(value);
					if (key.equalsIgnoreCase("sender_trade_ref_id2")) currRegRepReconReportData.setSender_trade_ref_id2(value);
					if (key.equalsIgnoreCase("usi2")) currRegRepReconReportData.setUsi2(value);
					if (key.equalsIgnoreCase("trade_date2")) currRegRepReconReportData.setTrade_date2(value);
					if (key.equalsIgnoreCase("start_date2")) currRegRepReconReportData.setStart_date2(value);
					if (key.equalsIgnoreCase("maturity_date2")) currRegRepReconReportData.setMaturity_date2(value);
					if (key.equalsIgnoreCase("OurName2")) currRegRepReconReportData.setOurName2(value);
					if (key.equalsIgnoreCase("OurLEI2")) currRegRepReconReportData.setOurLEI2(value);
					if (key.equalsIgnoreCase("CptyName2")) currRegRepReconReportData.setCptyName2(value);
					if (key.equalsIgnoreCase("CptyLEI2")) currRegRepReconReportData.setCptyLEI2(value);
					if (key.equalsIgnoreCase("rp2")) currRegRepReconReportData.setRp2(value);

				}

			}

		}

		return currRegRepReconReportData;
	}

	public DataSource getDataSource()
	{
		return dataSource;
	}

	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}

	public String getStoredProcName()
	{
		return storedProcName;
	}

	public void setStoredProcName(String storedProcName)
	{
		this.storedProcName = storedProcName;
	}

	public String getReconProc()
	{
		return reconProc;
	}

	public void setReconProc(String reconProc)
	{
		this.reconProc = reconProc;
	}

}
