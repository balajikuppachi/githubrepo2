package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmissionTracker;

/**
 * @author Shreekar DAO class to access data from REG_REP_EOD_SUBMISSION_TRACKER
 */
@Component
public class RegRepEodSubmissionsTrackerDaoImpl implements RowMapper<RegRepEodSubmissionTracker>
{

	@Autowired
	private JdbcTemplate jdbcTemplate;



	String insertQuery = "INSERT into REG_REP_EOD_SUBMISSION_TRACKER(SUBMISSION_ID,EOD_REPORT_ID,REG_REP_MESSAGE_ID,SWAP_TRADE_ID,TRADE_USI  ,TRADE_UTI,EVENT_TYPE,REPORT_TYPE,JURISDICTION,ASSET_CLASS,REPOSITORY,PARTY_1_LEI_PREFIX,PARTY_1_LEI_VALUE,PARTY_2_LEI_PREFIX,PARTY_2_LEI_VALUE,SENT_TO,SENT_BY,DATA_SUBMITTER  ,RESPONSE_STATUS ,COB_DATE) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	String statusUpdateQuery="UPDATE REG_REP_EOD_SUBMISSION_TRACKER SET RESPONSE_STATUS=?,SENT_TO=?,SENT_BY=?,UPDATE_DATETIME=getutcdate() WHERE SUBMISSION_ID=? AND EOD_REPORT_ID=?";
	
	String lastSubmissionStatus="SELECT TOP 1 RESPONSE_STATUS FROM REG_REP_EOD_SUBMISSION_TRACKER WHERE EOD_REPORT_ID= ? AND REPORT_TYPE=? AND JURISDICTION=?  ORDER BY SUBMISSION_ID DESC";


	private static Logger logger = Logger.getLogger(RegRepEodSubmissionsTrackerDaoImpl.class.getName());

	@Override
	public RegRepEodSubmissionTracker mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		RegRepEodSubmissionTracker currRegRepEodSubmission = new RegRepEodSubmissionTracker();
		return currRegRepEodSubmission;
	}

	
	public int batchInsertEodSubmissionTracker(List<RegRepEodSubmissionTracker> submissionDataList) throws Exception
	{
		try
		{
			jdbcTemplate.batchUpdate(insertQuery, new BatchPreparedStatementSetter()
			{
				@Override
				public void setValues(PreparedStatement pStmt, int i) throws SQLException
				{
					RegRepEodSubmissionTracker eodSubmsnTracker = submissionDataList.get(i);
					
					pStmt.setLong(1, eodSubmsnTracker.getSubmissionId());
					pStmt.setString(2, eodSubmsnTracker.getEodReportId());
					pStmt.setString(3, eodSubmsnTracker.getRegRepMessageId());
					pStmt.setString(4, eodSubmsnTracker.getTradeId());
					pStmt.setString(5, eodSubmsnTracker.getTradeUsi());
					pStmt.setString(6, eodSubmsnTracker.getTradeUti());
					pStmt.setString(7, eodSubmsnTracker.getEventType());
					pStmt.setString(8, eodSubmsnTracker.getReportType());
					pStmt.setString(9, eodSubmsnTracker.getJurisdiction());
					pStmt.setString(10, eodSubmsnTracker.getAssetClass());
					pStmt.setString(11, eodSubmsnTracker.getRepository());
					pStmt.setString(12, eodSubmsnTracker.getParty1LeiPrefix());
					pStmt.setString(13, eodSubmsnTracker.getParty1Lei());
					pStmt.setString(14, eodSubmsnTracker.getParty2LeiPrefix());
					pStmt.setString(15, eodSubmsnTracker.getParty2Lei());
					pStmt.setString(16, eodSubmsnTracker.getSentTo());
					pStmt.setString(17, eodSubmsnTracker.getSentBy());
					pStmt.setString(18, eodSubmsnTracker.getDataSubmitter());
					pStmt.setString(19, eodSubmsnTracker.getResponseStatus());
					pStmt.setDate(20, new java.sql.Date(eodSubmsnTracker.getCobDate().getTime()));
				}

				@Override
				public int getBatchSize()
				{
					return submissionDataList.size();
				}
			});

		}
		catch (Exception ex)
		{
			logger.error("######### Exception occurred inside RegRepEodSubmissionsTrackerDaoImpl:  batchInsertEodSubmissionTracker method- " + ExceptionUtils.getFullStackTrace(ex));

		}

		return submissionDataList.size();
	}
	
	public int updateResponseDetails(RegRepEodSubmissionTracker regRepEodSubTracker)
	{
		int updatedRecords=0;
		updatedRecords=jdbcTemplate.update(statusUpdateQuery, new Object[] {regRepEodSubTracker.getResponseStatus(),regRepEodSubTracker.getSentBy(),regRepEodSubTracker.getSentTo(),regRepEodSubTracker.getSubmissionId(),regRepEodSubTracker.getEodReportId()});
		
		return updatedRecords;
	}
	
	public String getLastSubmissionStatus(String eodReportID,String reportType,String jurisdiction)
	{
		String retval=null;
		List<String> listVals = jdbcTemplate.queryForList(lastSubmissionStatus,String.class,eodReportID,reportType,jurisdiction);
		if(!GeneralUtils.IsListNullOrEmpty(listVals))
			retval=listVals.get(0);
		return retval;
		}
	

}
