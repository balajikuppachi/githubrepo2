package com.wellsfargo.regulatory.persister.recon.dto;

import java.util.Date;

public class RegRepReconReportData
{
	private String category;
	private String row_id1;
	private String trade_id1;
	private String sender_trade_ref_id1;
	private String usi1;
	private String trade_date1;
	private String start_date1;
	private String maturity_date1;
	private String OurName1;
	private String OurLEI1;
	private String CptyName1;
	private String CptyLEI1;
	private String rp1;


	private String row_id2;
	private String trade_id2;
	private String sender_trade_ref_id2;
	private String usi2;
	private String trade_date2;
	private String start_date2;
	private String maturity_date2;
	private String OurName2;
	private String OurLEI2;
	private String CptyName2;
	private String CptyLEI2;
	private String rp2;
	public String getCategory()
	{
		return category;
	}
	public void setCategory(String category)
	{
		this.category = category;
	}
	public String getRow_id1()
	{
		return row_id1;
	}
	public void setRow_id1(String row_id1)
	{
		this.row_id1 = row_id1;
	}
	public String getTrade_id1()
	{
		return trade_id1;
	}
	public void setTrade_id1(String trade_id1)
	{
		this.trade_id1 = trade_id1;
	}
	public String getSender_trade_ref_id1()
	{
		return sender_trade_ref_id1;
	}
	public void setSender_trade_ref_id1(String sender_trade_ref_id1)
	{
		this.sender_trade_ref_id1 = sender_trade_ref_id1;
	}
	public String getUsi1()
	{
		return usi1;
	}
	public void setUsi1(String usi1)
	{
		this.usi1 = usi1;
	}
	public String getTrade_date1()
	{
		return trade_date1;
	}
	public void setTrade_date1(String trade_date1)
	{
		this.trade_date1 = trade_date1;
	}
	public String getStart_date1()
	{
		return start_date1;
	}
	public void setStart_date1(String start_date1)
	{
		this.start_date1 = start_date1;
	}
	public String getMaturity_date1()
	{
		return maturity_date1;
	}
	public void setMaturity_date1(String maturity_date1)
	{
		this.maturity_date1 = maturity_date1;
	}
	public String getOurName1()
	{
		return OurName1;
	}
	public void setOurName1(String ourName1)
	{
		OurName1 = ourName1;
	}
	public String getOurLEI1()
	{
		return OurLEI1;
	}
	public void setOurLEI1(String ourLEI1)
	{
		OurLEI1 = ourLEI1;
	}
	public String getCptyName1()
	{
		return CptyName1;
	}
	public void setCptyName1(String cptyName1)
	{
		CptyName1 = cptyName1;
	}
	public String getCptyLEI1()
	{
		return CptyLEI1;
	}
	public void setCptyLEI1(String cptyLEI1)
	{
		CptyLEI1 = cptyLEI1;
	}
	public String getRp1()
	{
		return rp1;
	}
	public void setRp1(String rp1)
	{
		this.rp1 = rp1;
	}
	public String getRow_id2()
	{
		return row_id2;
	}
	public void setRow_id2(String row_id2)
	{
		this.row_id2 = row_id2;
	}
	public String getTrade_id2()
	{
		return trade_id2;
	}
	public void setTrade_id2(String trade_id2)
	{
		this.trade_id2 = trade_id2;
	}
	public String getSender_trade_ref_id2()
	{
		return sender_trade_ref_id2;
	}
	public void setSender_trade_ref_id2(String sender_trade_ref_id2)
	{
		this.sender_trade_ref_id2 = sender_trade_ref_id2;
	}
	public String getUsi2()
	{
		return usi2;
	}
	public void setUsi2(String usi2)
	{
		this.usi2 = usi2;
	}
	public String getTrade_date2()
	{
		return trade_date2;
	}
	public void setTrade_date2(String trade_date2)
	{
		this.trade_date2 = trade_date2;
	}
	public String getStart_date2()
	{
		return start_date2;
	}
	public void setStart_date2(String start_date2)
	{
		this.start_date2 = start_date2;
	}
	public String getMaturity_date2()
	{
		return maturity_date2;
	}
	public void setMaturity_date2(String maturity_date2)
	{
		this.maturity_date2 = maturity_date2;
	}
	public String getOurName2()
	{
		return OurName2;
	}
	public void setOurName2(String ourName2)
	{
		OurName2 = ourName2;
	}
	public String getOurLEI2()
	{
		return OurLEI2;
	}
	public void setOurLEI2(String ourLEI2)
	{
		OurLEI2 = ourLEI2;
	}
	public String getCptyName2()
	{
		return CptyName2;
	}
	public void setCptyName2(String cptyName2)
	{
		CptyName2 = cptyName2;
	}
	public String getCptyLEI2()
	{
		return CptyLEI2;
	}
	public void setCptyLEI2(String cptyLEI2)
	{
		CptyLEI2 = cptyLEI2;
	}
	public String getRp2()
	{
		return rp2;
	}
	public void setRp2(String rp2)
	{
		this.rp2 = rp2;
	}
	
	
	
}
