package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepPrHoliday;

public interface RegRepPrHolidayDao extends Dao<RegRepPrHoliday>, Serializable {
	List<RegRepPrHoliday> findDate(Date date);
	
}
