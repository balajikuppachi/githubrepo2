package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepMessageRegulatoryDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessageRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepMessageRegulatoryId;

public class RegRepMessageRegulatoryDaoImpl extends AbstractDaoImpl<RegRepMessageRegulatory> implements RegRepMessageRegulatoryDao
{

	/**
	 *
	 */
	private static final long serialVersionUID = 3960385152327233066L;

	@Override
	public Class<RegRepMessageRegulatory> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepMessageRegulatory.class;
	}


	@SuppressWarnings("unchecked")
    @Override
    @Transactional
    public List<RegRepMessageRegulatory> findByMessageId(String msgId)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepMessageRegulatory result = null;
		List<RegRepMessageRegulatory> regulatories = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(
					RegRepMessageRegulatory.GET_MSG_BY_MSG_ID);
			queryObject.setString("srcMsgId", msgId);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty()){

				regulatories = new ArrayList<RegRepMessageRegulatory>(4);

				for (Object[] obj: objs){
					result = new RegRepMessageRegulatory();
					result.setReportingJurisdiction((String)obj[0]);
					result.setReportingParty((String)obj[1]);
					result.setRepository((String)obj[2]);

					regulatories.add(result);
				}

				return regulatories;
			}

		}
		finally 
		{
			SessionFactoryUtils.closeSession(session);
			
/*			if (session!= null ){
				session.flush();
				session.close();
			}
*/		}

		return null;
    }

	@SuppressWarnings("unchecked")
    @Override
    @Transactional
    public List<RegRepMessageRegulatory> loadRegulatoryByMsgId(List<String> msgIds)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepMessageRegulatory result = null;
		List<RegRepMessageRegulatory> resultList = null;
		RegRepMessageRegulatoryId id = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepMessageRegulatory.GET_REGULATORY_BY_MSG_IDs);
			queryObject.setParameterList("msgIds", msgIds);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				resultList = new ArrayList<RegRepMessageRegulatory>(100);

				for (Object[] obj: objs)
				{
					result = new RegRepMessageRegulatory();
										
					id = new RegRepMessageRegulatoryId();
					id.setRegRepMessageId((String)obj[0]);
					id.setRegRepMessageRegulatoryId((Integer)obj[1]);
					
					result.setId(id);
					result.setReportingJurisdiction((String)obj[2]);
					result.setReportingParty((String)obj[3]);
					result.setRepository((String)obj[4]);					
					
					resultList.add(result);
				}
			}

		}
		finally 
		{

			SessionFactoryUtils.closeSession(session);
			
/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return resultList;
    }



}
