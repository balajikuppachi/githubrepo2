package com.wellsfargo.regulatory.persister.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;

import javax.sql.DataSource;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public class DataSourceDao
{

	private static DataSource dataSource;
	private static Logger logger = Logger.getLogger(DataSourceDao.class.getName());

	public static Connection getConnection()
	{
		Connection con = null;

		try
		{
			con = dataSource.getConnection();
		}
		catch (SQLException e)
		{
			logger.error("Unable to create db connection " + e);
		}

		return con;
	}

	/**
	 * @param dataSource
	 * the dataSource to set
	 */
	public void setDataSource(DataSource dataSource)
	{
		DataSourceDao.dataSource = dataSource;
	}

	public static void closeResources(Connection con, Statement stmt, ResultSet rst)
	{

		if (null != rst)
		{
			try
			{
				rst.close();
			}
			catch (SQLException e)
			{
				logger.error("Unable to close result set " + e);
			}
		}

		if (null != stmt)
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
				logger.error("Unable to close statement " + e);
			}
		}

		if (null != con)
		{
			try
			{
				con.close();
			}
			catch (SQLException e)
			{
				logger.error("Unable to close connection " + e);
			}
		}

	}

}
