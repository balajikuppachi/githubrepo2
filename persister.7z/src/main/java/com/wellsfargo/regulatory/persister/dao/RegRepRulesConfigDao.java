package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepRulesConfig;

public interface RegRepRulesConfigDao extends Dao<RegRepRulesConfig>, Serializable
{

}
