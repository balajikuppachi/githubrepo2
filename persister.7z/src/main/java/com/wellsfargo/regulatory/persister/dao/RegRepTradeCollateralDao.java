package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepTradeCollateral;

public interface RegRepTradeCollateralDao extends Serializable {

	
	public List<RegRepTradeCollateral> findWhereEQTickerIDSourceEquals(String tickerID, String srcSystem);
	public List<RegRepTradeCollateral> findWhereTradeIdSourceEquals(String trade_id, String srcSystem);
}
