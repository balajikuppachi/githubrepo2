package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.dao.RegRepEquityTermsDao;
import com.wellsfargo.regulatory.persister.dto.RegRepEquityTerms;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class RegRepEquityTermsDaoImpl extends AbstractDaoImpl<RegRepEquityTerms> implements RegRepEquityTermsDao
{

    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
	@Override
    public List<RegRepEquityTerms> loadRegRepEuqityTermsByUsi(String usi)
	{
		return findByNamedQuery(RegRepEquityTerms.GET_EQUITY_TERMS_BY_USI, new Object[]{ usi , usi});    	
		
	}

	@Override
    public Class<RegRepEquityTerms> getEntityClass()
    {
	    // TODO Auto-generated method stub
	    return null;
    }


}
