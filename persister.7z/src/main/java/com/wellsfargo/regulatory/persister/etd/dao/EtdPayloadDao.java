package com.wellsfargo.regulatory.persister.etd.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;

public interface EtdPayloadDao extends Serializable, Dao<EtdPayload>
{

	  public List<EtdPayload> getEtdPayLoadByCreateDate(Date createFromDate, Date createToDate);
}
