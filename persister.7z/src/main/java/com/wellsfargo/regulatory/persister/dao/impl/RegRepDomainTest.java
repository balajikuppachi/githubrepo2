package com.wellsfargo.regulatory.persister.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.dao.RegRepDomainValuesDao;
import com.wellsfargo.regulatory.persister.dto.RegRepDomainValues;
import com.wellsfargo.regulatory.persister.dto.RegRepDomainValuesId;

public class RegRepDomainTest
{
	public static void main(String arg[])
	{
		SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

		try
		{
			ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:META-INF/hibernateContext.xml");
			applicationContext.start();
			RegRepDomainValuesDao rrfd = (RegRepDomainValuesDao) applicationContext.getBean("regRepDomainValuesDao", RegRepDomainValuesDao.class);

			RegRepDomainValues a = new RegRepDomainValues();
			a.setEntityDescription("testing");
			RegRepDomainValuesId id = new RegRepDomainValuesId();
			id.setEntityName("kp");
			id.setEntityValue("kota");
			a.setId(id);
			rrfd.save(a);
		}
		catch (HibernateException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
