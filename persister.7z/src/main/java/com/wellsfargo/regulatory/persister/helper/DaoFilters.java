package com.wellsfargo.regulatory.persister.helper;

import java.util.Collection;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

public class DaoFilters {

	public static Criteria addRestrictionIn(Criteria criteria, String subCriteria, String propertyName, Collection<String> values){
		if (values.size() > 0){
			criteria.createCriteria(subCriteria).add(Restrictions.in(propertyName, values));
			return criteria;
		}
		return null;
	}
	
	public static Criteria addRestrictionIn(Criteria criteria, String propertyName, Collection<String> values){
		if (values.size() > 0){
			criteria.add(Restrictions.in(propertyName, values));
		}
		return criteria;
	}
}
