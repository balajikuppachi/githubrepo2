package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

public interface RegRepTradeHeaderDao extends Dao<RegRepTradeHeader>, Serializable
{

}
