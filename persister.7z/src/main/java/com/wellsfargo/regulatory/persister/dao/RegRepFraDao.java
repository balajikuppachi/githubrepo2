package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepFra;

public interface RegRepFraDao extends Serializable, Dao<RegRepFra>
{

}
