package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepKeyword;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;
import com.wellsfargo.regulatory.persister.dto.RegRepRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepKeywordMapper
{

	private static Logger logger = Logger.getLogger(RegRepKeywordMapper.class.getName());

	public RegRepKeyword createRegRepKeyword(RegRepProduct dbProduct, RegRepRegulatory dbRegulatory, RegRepTradeHeader dbHeader, Keyword ipKeyword)
	{

		RegRepKeyword dbKeyword = null;
		String id = null;

		if (ipKeyword == null || (null == dbHeader && null == dbProduct && null == dbRegulatory))
		{
			logger.debug("RegRepKeyword object could not be " + "populated due to invalid incoming data");
			return dbKeyword;
		}

		id = ReportingDataUtils.generateMessageId();
		dbKeyword = new RegRepKeyword();

		dbKeyword.setName(ipKeyword.getName());
		dbKeyword.setRegRepKeyId(id);
		dbKeyword.setRegRepProduct(dbProduct);
		dbKeyword.setRegRepRegulatory(dbRegulatory);
		dbKeyword.setRegRepTradeHeader(dbHeader);
		dbKeyword.setValue(ipKeyword.getValue());

		return dbKeyword;
	}

}
