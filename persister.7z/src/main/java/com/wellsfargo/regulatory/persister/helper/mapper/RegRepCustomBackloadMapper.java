package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CustomBackloadType;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepCustomBackload;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public class RegRepCustomBackloadMapper {
	
	private static Logger logger = Logger.getLogger(RegRepCustomBackloadMapper.class.getName());

	public Set<RegRepCustomBackload> createRegRepCustomBackload(CustomBackloadType ipBackload, RegRepMessage regRepMessage)
	{
		RegRepCustomBackload backload = null;
		Set<RegRepCustomBackload> backloads = null;

		if (null == ipBackload || null == regRepMessage)
		{
			logger.debug("RegRepCustomBackload object could not be " + "populated due to invalid incoming data");
			return backloads;
		}

		backload = new RegRepCustomBackload();
		
		backload.setBackloadReason(ipBackload.getBackloadReason());
		backload.setIsCustomBackload(ConversionUtils.booleanToDbString(ipBackload.isIsCustomBackload()));
		backload.setIsSdrLive(ConversionUtils.booleanToDbString(ipBackload.isIsSdrLive()));
		backload.setOrginalEnteredDateTime(new Date());
		backload.setRegRepMessage(regRepMessage);
		
		if(null != ipBackload.getSendId())
			backload.setSendId(ipBackload.getSendId().longValue());
		
		backload.setV7AssetClass(ipBackload.getV7AssetClass());
		backload.setV7ProductSubType(ipBackload.getV7ProductSubType());
		backload.setV7ProductType(ipBackload.getV7ProductType());
		backload.setIsCustomEodRefresh(ConversionUtils.booleanToDbString(ipBackload.isIsCustomEodRefresh()));
		backload.setCustomEodRefreshReason(ipBackload.getCustomEodRefreshReason());
		
		if(null != backload){
			
			backloads = new HashSet<RegRepCustomBackload>(3);
			backloads.add(backload);
		}
		
		return backloads;
	}


}
