package com.wellsfargo.regulatory.persister.dto;

import java.io.Serializable;
import java.util.Date;

public class RegRepPortfolioCount implements Serializable  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long countId;	
	private String counterpartyLei;
	private String counterpartyName;
	private String counterpartyDsig;
	private String assetClass;
	private Long regRepCount;
	private Date UpdateTimestamp;
	
	public final static String GET_COUNT_BY_LEI_AND_ASSET ="getCountByLeiAndAsset";
	
	
	public RegRepPortfolioCount()
	{
	}

	public RegRepPortfolioCount(String counterpartyLei, String counterpartyName,
			String counterpartyDsig, String assetClass,
			Long regRepCount, Date UpdateTimestamp) {
		super();
		
		this.counterpartyLei = counterpartyLei;
		this.counterpartyName = counterpartyName;
		this.counterpartyDsig = counterpartyDsig;
		this.assetClass = assetClass;
		this.regRepCount = regRepCount;
		this.UpdateTimestamp = UpdateTimestamp;
	}
	

	public Long getCountId() {
		return countId;
	}

	public void setCountId(Long countId) {
		this.countId = countId;
	}

	public String getCounterpartyLei() {
		return counterpartyLei;
	}

	public void setCounterpartyLei(String counterpartyLei) {
		this.counterpartyLei = counterpartyLei;
	}

	public String getCounterpartyName() {
		return counterpartyName;
	}

	public void setCounterpartyName(String counterpartyName) {
		this.counterpartyName = counterpartyName;
	}

	public String getCounterpartyDsig() {
		return counterpartyDsig;
	}

	public void setCounterpartyDsig(String counterpartyDsig) {
		this.counterpartyDsig = counterpartyDsig;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public Long getRegRepCount() {
		return regRepCount;
	}

	public void setRegRepCount(Long regRepCount) {
		this.regRepCount = regRepCount;
	}

	public Date getUpdateTimestamp() {
		return UpdateTimestamp;
	}

	public void setUpdateTimestamp(Date updateTimestamp) {
		UpdateTimestamp = updateTimestamp;
	}

}
