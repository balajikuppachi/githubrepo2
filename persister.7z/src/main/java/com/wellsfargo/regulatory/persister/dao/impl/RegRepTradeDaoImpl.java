package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepTradeDao;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;

public class RegRepTradeDaoImpl extends AbstractDaoImpl<RegRepTrade> implements RegRepTradeDao
{

	private static final long serialVersionUID = 4842697898954739965L;

	@Override
	public Class<RegRepTrade> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepTrade.class;
	}

	/**
	 * Retrieve REG_REP_TRADE records based on TRADE_USI_PREFIX and TRADE_USI_VALUE
	 */
	@SuppressWarnings("unchecked")
	@Transactional
	public List<RegRepTrade> loadRegRepTradesByUSI(String usiPrefix, String usiValue)
	{
		return findByNamedQuery(RegRepTrade.GET_TRADES_BY_USI, new Object[]
		{ usiPrefix, usiValue });
	}

	@Override
    public RegRepTrade findByPrimaryKeyNS(String swapTradeId)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepTrade result = null;
		
		try 
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepTrade.GET_TRADE_BY_TRADE_ID);
			queryObject.setString("swapTradeId", swapTradeId);
			objs = queryObject.list();
		
			if (objs!=null && !objs.isEmpty())
			{
				for (Object[] obj: objs)
				{
					result = new RegRepTrade();
					result.setSwapTradeId((String)obj[0]);
					result.setTradeUsi((String)obj[1]);
					result.setTradeUti((String)obj[2]);
					result.setSrcSystemType((String)obj[3]);
					result.setIsExpired((String)obj[4]);
					result.setTradeLatestVersion((String)obj[5]);
					result.setRegRepTradeTimestamp((java.util.Date)obj[6]);
					result.setLatestRegRepMessageId((String)obj[7]);
					result.setTradeFoStatus((String)obj[8]);
					result.setRegRepTradeUpdateTimestamp((java.util.Date)obj[9]);
					result.setLifeCycleEvent((String)obj[10]);
					result.setJurisdiction((String)obj[11]);
					result.setAssetClass((String)obj[12]);
					result.setRepository((String)obj[13]);
					result.setReportingParty((String)obj[14]);
					result.setExpiredOn((java.util.Date)obj[15]);
				}
				
			}
		} 
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);

/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return result;
    }
	
	
	

}
