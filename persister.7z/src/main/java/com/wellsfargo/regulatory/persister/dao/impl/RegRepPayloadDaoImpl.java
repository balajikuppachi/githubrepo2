package com.wellsfargo.regulatory.persister.dao.impl;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepPayloadDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPayload;

public class RegRepPayloadDaoImpl extends AbstractDaoImpl<RegRepPayload> implements RegRepPayloadDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4624561308764106832L;

	@Override
	public Class<RegRepPayload> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepPayload.class;
	}
	
	@SuppressWarnings("unchecked")
    @Override
    @Transactional
    public RegRepPayload findPayloadByRegRepMessageId(String msgId)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepPayload result = null;

		try
		{
			session = openSession();
			
			queryObject = session.getNamedQuery(RegRepPayload.GET_PAYLOAD_BY_MSG_ID);
			queryObject.setString("msgId", msgId);	
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				for (Object[] obj: objs)
				{
					if(null == obj)
						continue;
										
					result = new RegRepPayload();
					result.setPayload((String)obj[0]);
					result.setRegRepPayloadTimestamp( (Timestamp)obj[1]);
					// Just need the latest reported message
					break;
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Error while fetching payload by message id : "+e);
		}
		finally 
		{
			SessionFactoryUtils.closeSession(session);
			
/*			if (session!= null ){
				session.flush();
				session.close();
			}
*/		}
		
		return result;
	}
	



}
