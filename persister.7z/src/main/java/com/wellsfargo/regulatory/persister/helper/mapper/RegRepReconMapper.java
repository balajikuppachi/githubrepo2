package com.wellsfargo.regulatory.persister.helper.mapper;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CollateralTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DesignationEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepReconTrioptima;
import com.wellsfargo.regulatory.persister.trioptima.mapper.RegRepReconCRMapper;
import com.wellsfargo.regulatory.persister.trioptima.mapper.RegRepReconEQMapper;
import com.wellsfargo.regulatory.persister.trioptima.mapper.RegRepReconFXMapper;
import com.wellsfargo.regulatory.persister.trioptima.mapper.RegRepReconIRMapper;
import com.wellsfargo.regulatory.persister.trioptima.parser.RegRepTrioptimaParser;

/**
* @author a120564
*
*/
public class RegRepReconMapper {

	private static Logger logger = Logger.getLogger(RegRepReconMapper.class
			.getName());

	/**
	 * @param context
	 * @param isTradeActive
	 * @return
	 */
	@SuppressWarnings("unused")
	public RegRepReconTrioptima mapRegRepRecon(ReportingContext context, Boolean isTradeActive, RegRepReconTrioptima recon, RegRepTrioptimaParser regRepTrioptimaParser) {

		SdrRequest sdrRequest 				= null;
		sdrRequest 							= context.getSdrRequest();
		String srcSysMessageId 				= null;
		String srcAssetClass				= null;
		String execPrefix 					= null;
		String execVenue 					= null;
		String usiPrefix 					= null;
		String usiValue 					= null;
		String usi 							= null;
		String isAffiliateTrade 			= null;
		String usPersonCPStr 				= null;
		String usPersonRPStr 				= null;
		String marketType					= null;
		String processingOrgPrefix  		= null;
		String processingOrgValue 			= null;
		String cptyPrefix	 				= null;
		String cptyValue 					= null;
		String dtccProdType					= null;
		String delegatedRep 				= null;
		String outputMessage 				= null;
		String jursStr 						= null;
		StringBuilder executionVen  		= new StringBuilder();
		Date current_date 					= new Date();
		ProductType product 				= null;
		TradeType trade 					= null;
		TradeDetailType tradeDetail			= null;
		DomainMappingCache cache 			= null;
		TradeHeaderType tradeHeader 		= null;
		RegulatoryType regulatoryType 		= null;
		DesignationEnum desigPartyCPEnum 	= null;
		DesignationEnum desigPartyRPEnum	= null;
		XMLGregorianCalendar tradeDate 		= null;
		XMLGregorianCalendar schedTermDate 	= null;
		XMLGregorianCalendar startDate1		= null;
		XMLGregorianCalendar startDate2 	= null;
		RegRepTrioptima regRepTrioptima 	= new RegRepTrioptima();
		Map<String, String> regulatories 	= new HashMap<String, String>();
		List<ReportingEligibilityType> reportingEligibility = null;
		
		if (null != sdrRequest) {
			
			logger.debug("Mapping Trade to RegRepRecon");
			srcSysMessageId 			= context.getMessageId();
			srcAssetClass 				= sdrRequest.getAssetClass();
			trade 						= sdrRequest.getTrade();
			tradeDetail 				= trade.getTradeDetail();
			tradeHeader 				= trade.getTradeHeader();
			product						= tradeDetail.getProduct();
			regulatoryType				= trade.getRegulatory();
			
			tradeDate							= tradeHeader.getTradeDate();
			usiPrefix			    		 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.USI_PREFIX);	
			usiValue 						 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.USI_VALUE);	
			isAffiliateTrade				 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.IS_GTR_USI);	
			CollateralTypeEnum collEnum 	 	= regulatoryType.getCollateralizationType();
			reportingEligibility			 	= regulatoryType.getReportingEligibility();
			execPrefix	 					 	= tradeHeader.getExecutionVenuePrefix();
			execVenue	 					 	= tradeHeader.getExecutionVenue();
			processingOrgPrefix 			 	= tradeHeader.getProcessingOrgLEIPrefix();
			processingOrgValue 				 	= tradeHeader.getProcessingOrgLEIValue();
			cptyPrefix 						 	= tradeHeader.getCounterpartyLEIPrefix();
			cptyValue 						 	= tradeHeader.getCounterpartyLEIValue();
			usi 							 	= usiPrefix + ":" + usiValue;
			BigDecimal parentOriginalNotional	= tradeHeader.getLifeCycle().getOriginalNotional();
			marketType				 		 	= tradeHeader.getLifeCycle().getEventType();
			dtccProdType	 				 	= product.getProductKeys().getUPI();
			
			/*#########################*/
			 /*Initial Mapping* START/
			/*#########################*/
			{	
				if(null == recon)
				{
					recon = new RegRepReconTrioptima();
				}
					
				if (isTradeActive ) 
				{
					recon.setIsActive("1");
				}
				else 
				{
					recon.setIsActive("0");
				}
				
				if(GeneralUtils.IsNullOrBlank(usi) || usi.contains(Constants.GTRCREATE) || usi.equals(":")) 
				{	
					usi = context.getUsi();
					
					if( null == usi ) 
					{
						usi = "SDRGeneratedUSI_" + tradeHeader.getTradeId();
					}
				}
				if(Constants.TRUE.contains(isAffiliateTrade)) 
				{
					usi = usi + "_aff"; 
				}
				
				
				if (!GeneralUtils.IsNullOrBlank(execPrefix))
				{
					executionVen = executionVen.append(execPrefix);
				} 
				else if (!GeneralUtils.IsNullOrBlank(execVenue))
				{
					executionVen = executionVen.append(":").append(execVenue);
				}
				
				if(!tradeDetail.getTradeParties().getParty().isEmpty())
				{
					Boolean usPersonCP 				 	= tradeDetail.getTradeParties().getParty().get(0).isUsPerson();
					Boolean usPersonRP 				 	= tradeDetail.getTradeParties().getParty().get(1).isUsPerson();
					if(usPersonCP!=null){
					if (usPersonCP)
						usPersonCPStr = "TRUE";
					else
						usPersonCPStr = "FALSE";
					}
					if(usPersonRP!=null){
					if (usPersonRP)
						usPersonRPStr = "TRUE";
					else
						usPersonRPStr = "FALSE";
					}
				}
					
				if (!GeneralUtils.IsNull(context.getRegulatories())) 
				{
					regulatories = context.getRegulatories();
					for (String key: regulatories.keySet()) 
					{
						if(jursStr != null)
							jursStr = jursStr+";"+key;
						else 
							jursStr = key;
					}
				}
				if(!tradeDetail.getTradeParties().getParty().isEmpty())
				{
					desigPartyCPEnum 	= tradeDetail.getTradeParties().getParty().get(0).getDesignation();
					desigPartyRPEnum 	= tradeDetail.getTradeParties().getParty().get(1).getDesignation();
				}
				
				if(!reportingEligibility.isEmpty())
				{
					delegatedRep = reportingEligibility.get(0).getDelegatedReporting();
				}
				
			}
			/*#########################*/
			 	/*Initial Mapping* END/
			/*#########################*/
			
			/*###################################*/
			 /*Set RegRepTrioptima Common- START*/
			/*####################################*/
			{
				recon.setMessageId(srcSysMessageId);
				recon.setReportType(Constants.MESSAGE_TYPE_SNAPSHOT_TO);
				recon.setAssetClass(srcAssetClass);
				
				regRepTrioptima.setPartyId("");
				regRepTrioptima.setCptyId("");
				regRepTrioptima.setProductClass("");
				regRepTrioptima.setSecondaryAssetClass("");
				regRepTrioptima.setAdditionalRepository("");
				
				/*#######*/
				/*TRADE ID*/
				/*#######*/
				{
					regRepTrioptima.setTradeId(tradeHeader.getTradeId());
					recon.setTradeID(tradeHeader.getTradeId());
				}
				/*#######*/
				  /*USI*/
				/*#######*/
				{
					regRepTrioptima.setUsi(usi);
					recon.setUsi(usi);
				}
				/*#######*/
				 /*UTI*/
				/*#######*/
				{
					regRepTrioptima.setUti(product.getProductKeys().getUTI());
				}			
				/*################################################################################################*/
				/* TRADE DATE, TRADE PARTY 1, TRADE PARTY 2, PRODUCT ID, REPOSITORY, JURISDICTION
				 * REPORTING PARTY, PARTY ROLE, COLLATERALIZED, EXECUTION VENUE,
				 * US PERSON INDICATOR, SUBMITTOR, TERMINATION DATE */
				/*################################################################################################*/
				{
					if (!GeneralUtils.IsNull(tradeDate)) 
					{
						regRepTrioptima.setTradeDate(CalendarUtils.xmlGregCalToCustomFormat(tradeDate, null));
					}
					
					if(!GeneralUtils.IsNullOrBlank(processingOrgValue)) 
					{
						regRepTrioptima.setTradeParty1(processingOrgPrefix + ":" + processingOrgValue);
					}
					else 
					{
						regRepTrioptima.setTradeParty1(tradeHeader.getProcessingOrgLEI());
					}
					
					if(!GeneralUtils.IsNullOrBlank(cptyValue)) 
					{ 
						regRepTrioptima.setTradeParty2(cptyPrefix + ":"+ cptyValue);
					}
					else 
					{
						regRepTrioptima.setTradeParty2(tradeHeader.getCounterpartyLEI());
					}
					
					if (Constants.ASSET_CLASS_EQUITY.contains(srcAssetClass))
					{
						regRepTrioptima.setProductId(Constants.ISDA +":" +dtccProdType);
					}
					else
					{
						regRepTrioptima.setProductId(dtccProdType);
					}
					if(!GeneralUtils.IsNullOrBlank(jursStr))
					{
						if(jursStr.contains(Constants.CA_PERIOD))
						{
							recon.setRepository(Constants.CAD);
						}
						else 
						{
							recon.setRepository(Constants.DTCC);
						}
						
						jursStr = jursStr.replaceAll("_DTCC", "").replaceAll("_ICE", "").replaceAll("NONE","").replaceAll(";;",";");
						recon.setJurisdiction(jursStr);
					
					}
					
					if (!GeneralUtils.IsNull(context.isReportingParty()))
					{
						if(context.isReportingParty())
						{
							regRepTrioptima.setReportingParty(tradeHeader.getProcessingOrgLEI());
						} 
						else
						{
							regRepTrioptima.setReportingParty(tradeHeader.getCounterpartyLEI());
						}
					}
					if (!GeneralUtils.IsNull(desigPartyRPEnum)) 
					{
						regRepTrioptima.setTradeParty1Role(desigPartyRPEnum.value());
					}
					if (!GeneralUtils.IsNull(desigPartyCPEnum))
					{
						regRepTrioptima.setTradeParty2Role(desigPartyCPEnum.value());
					}
					if (!GeneralUtils.IsNull(collEnum))
					{
						regRepTrioptima.setCollateralized(collEnum.value());
					}
					
					if(!GeneralUtils.IsNull(executionVen)) 
					{
						regRepTrioptima.setExecutionVenue(executionVen.toString());
					}
					
					if (!GeneralUtils.IsNull(usPersonRPStr))
					{
						regRepTrioptima.setTradeParty1UsPersonIndicator(usPersonRPStr);
					}
					if (!GeneralUtils.IsNull(usPersonCPStr)) 
					{
						regRepTrioptima.setTradeParty2UsPersonIndicator(usPersonCPStr);
					}
		
					if (!product.getLeg().isEmpty()) 
					{
						schedTermDate = product.getLeg().get(0).getEndDate();
						if (!GeneralUtils.IsNull(schedTermDate))
						{
							regRepTrioptima.setSchedTerminationDate(CalendarUtils.xmlGregCalToCustomFormat(schedTermDate, null));
						}
					}
					
					if (!GeneralUtils.IsNull(delegatedRep)) 
					{
						regRepTrioptima.setSubmittor(Constants.BOTH);
					} 
					else 
					{
						regRepTrioptima.setSubmittor(tradeHeader.getProcessingOrgLEI());
					}
				}
			}
			/*##################################*/
			 /*Set RegRepTrioptima Common - END*/
			/*##################################*/
			
		/*#############################################*/
		 	/*Set RegRepTrioptima IR LEG DETAILS */
		/*#############################################*/
		if (Constants.ASSET_CLASS_INTEREST_RATE.contains(srcAssetClass)) 
		{
			RegRepReconIRMapper reconIRMapper = new RegRepReconIRMapper();
			
			regRepTrioptima = reconIRMapper.mapIRrows(context, tradeDetail, product, regRepTrioptima, parentOriginalNotional, marketType, dtccProdType);
		}
			
		/*#############################################*/
		 	/*Set RegRepTrioptima CR LEG DETAILS*/
		/*#############################################*/
		else if (Constants.ASSET_CLASS_CREDIT.contains(srcAssetClass)) 
		{
			RegRepReconCRMapper reconCRMapper = new RegRepReconCRMapper();
			
			regRepTrioptima = reconCRMapper.mapCRrows(context, tradeDetail, product, regRepTrioptima, parentOriginalNotional, marketType);
		}
			
		/*#############################################*/
		 	/*Set RegRepTrioptima FX LEG DETAILS */
		/*#############################################*/
		else if (Constants.ASSET_CLASS_FOREX.contains(srcAssetClass)) 
		{
			RegRepReconFXMapper reconFXMapper = new RegRepReconFXMapper();
			
			regRepTrioptima = reconFXMapper.mapFXrows(context, product, regRepTrioptima, tradeHeader);
		}

			
		/*#############################################*/
		 	/*Set RegRepTrioptima EQ LEG DETAILS */
		/*#############################################*/
		else if(Constants.ASSET_CLASS_EQUITY.contains(srcAssetClass)) 
		{
			String template = null;
			template 		= StringUtils.join(new String[] {Constants.EQUITY_UPI_TEMPLATE,dtccProdType },Constants.UNDERSCORE);
			template 		= getDomain(template);
			
			recon.setEquityTemplate(template);
			
			regRepTrioptima.setTradeId(tradeHeader.getTradeVersion());
			
			RegRepReconEQMapper reconEQMapper = new RegRepReconEQMapper();
			
			regRepTrioptima = reconEQMapper.mapEQrows(context, tradeDetail, product, regRepTrioptima, template);
		}
			/*################################*/
			 /*Marshal RegRepTrioptima - START*/
			/*################################*/
			try 
			{
				outputMessage= regRepTrioptimaParser.marshallToDtccTemplateString(regRepTrioptima);
			}
			catch (Exception e) 
			{
				logger.error("Error in Parsing Incoming Message for Trioptima " + e.getMessage());
			}
			/*################################*/
			 /*Marshal RegRepTrioptima - END*/
			/*################################*/
			
			if(!GeneralUtils.IsNull(outputMessage))
				recon.setOutputMessage(outputMessage);
		}
		
		if(GeneralUtils.IsNull(recon.getInsertTimeStamp()))
		{
			recon.setInsertTimeStamp(current_date);
		}
		
		recon.setUpdateTimeStamp(current_date);
		
		return recon;
	}

	public String getDomain(String domain) {
		String domainRet = null;
		DomainMappingCache cache = DomainMappingCache.getInstance();
		domainRet = cache.getValue(domain);
		if (!GeneralUtils.IsNull(domainRet)) 
		{
			return domainRet;
		} 
		else
			return null;
	}
	

	
	
	

}
