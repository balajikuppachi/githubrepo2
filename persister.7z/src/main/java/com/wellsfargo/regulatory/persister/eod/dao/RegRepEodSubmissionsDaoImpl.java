package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;

/**
 * @author Shreekar DAO class to access data from REG_REP_EOD_SUBMISSION
 */
@Component
public class RegRepEodSubmissionsDaoImpl implements RowMapper<RegRepEodSubmission>
{

	@Autowired
	private JdbcTemplate jdbcTemplate;

	String selectQuery = "select EOD_REPORT_ID, SUBMISSION_ID from REG_REP_EOD_SUBMISSION  where EOD_REPORT_ID = ? and SUBMISSION_ID = ?";

	String insertQuery = "INSERT INTO REG_REP_EOD_SUBMISSION (EOD_REPORT_ID, AS_OF_DATE, SDR_REPORT, "
	        + " STATUS, SWAP_TRADE_ID, REPORT_TYPE, INSERT_TIMESTAMP, SUBMISSION_TIMESTAMP, SUBMISSION_ID,COB_DATE ) VALUES(?,?,?,?,?,?,?,?,?,?)";

	private final TimeZone UTC = TimeZone.getTimeZone("UTC");

	private static Logger logger = Logger.getLogger(RegRepEodSubmissionsDaoImpl.class.getName());

	@Override
	public RegRepEodSubmission mapRow(ResultSet rs, int rowNum) throws SQLException
	{

		RegRepEodSubmission currRegRepEodSubmission = new RegRepEodSubmission();
		currRegRepEodSubmission.setEodReportId(rs.getString("EOD_REPORT_ID"));
		currRegRepEodSubmission.setSubmissionId(rs.getLong("SUBMISSION_ID"));

		return currRegRepEodSubmission;
	}

	//queryForInt deprecated in Spring4
	public int getEodReportId(List<String> reportIDs)
	{

		Map<String, Object> params = new HashMap<String, Object>();
		int count = 0;
		params.put("reportIds", reportIDs);
		String countQuery = "SELECT count(1) AS COUNTS FROM REG_REP_EOD_SUBMISSION WHERE EOD_REPORT_ID in (:reportIds)";
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		//count = namedParameterJdbcTemplate.queryForInt(countQuery, params);
		count = namedParameterJdbcTemplate.queryForObject(countQuery, params, Integer.class);
		namedParameterJdbcTemplate = null;
		return count;
	}

	public List<RegRepEodSubmission> getExistingSubmissionRecord(RegRepEodSubmission regRepEodSubmission)
	{
		List<RegRepEodSubmission> queryResult = jdbcTemplate.query(selectQuery, new Object[]
		{ regRepEodSubmission.getEodReportId(), regRepEodSubmission.getSubmissionId() }, this);
		return queryResult;

	}

	//queryForLong depreacted in Spring4
	public long getMaxSubmissionId()
	{
		String query = "select max(SUBMISSION_ID) AS SUBMISSION_ID from REG_REP_EOD_SUBMISSION";
		//long subId = jdbcTemplate.queryForLong(query);
		long subId = jdbcTemplate.queryForObject(query, Long.class);
		return subId;

	}

	public int batchInsertEodSubmission(List<RegRepEodSubmission> submissionDataList, Date cobDate) throws Exception
	{
		try
		{
			jdbcTemplate.batchUpdate(insertQuery, new BatchPreparedStatementSetter()
			{
				@Override
				public void setValues(PreparedStatement pStmt, int i) throws SQLException
				{
					RegRepEodSubmission eodSubmsn = submissionDataList.get(i);
					Date asOfDate = null;
					Date insrtTime = null;
					Date submsnTime = null;
					String status = null;
					String sdrReport = null;
					String eodRptId = null;
					String tradeId = null;
					String reportType = null;
					Long submsnId = null;

					eodRptId = eodSubmsn.getEodReportId();
					asOfDate = eodSubmsn.getAsOfDate();
					sdrReport = eodSubmsn.getSdrReport();
					insrtTime = eodSubmsn.getInsertTimestamp();
					submsnTime = eodSubmsn.getSubmissionTimestamp();
					status = eodSubmsn.getStatus();
					submsnId = eodSubmsn.getSubmissionId();
					tradeId = eodSubmsn.getTradeId();
					reportType = eodSubmsn.getReportType();

					pStmt.setString(1, eodRptId);
					pStmt.setTimestamp(2, ((asOfDate == null) ? null : new Timestamp(asOfDate.getTime())));
					pStmt.setString(3, sdrReport);
					pStmt.setString(4, status);
					pStmt.setString(5, tradeId);
					pStmt.setString(6, reportType);
					pStmt.setTimestamp(7, ((insrtTime == null) ? null : new Timestamp(insrtTime.getTime())), Calendar.getInstance(UTC));
					pStmt.setTimestamp(8, ((submsnTime == null) ? null : new Timestamp(submsnTime.getTime())), Calendar.getInstance(UTC));
					pStmt.setLong(9, submsnId);
					pStmt.setDate(10, new java.sql.Date(cobDate.getTime()));

				}

				@Override
				public int getBatchSize()
				{
					return submissionDataList.size();
				}
			});

		}
		catch (Exception ex)
		{
			logger.error("######### Exception occurred inside RegRepEodSubmissionsDaoImpl:  batchInsertEodSubmission method- " + ExceptionUtils.getFullStackTrace(ex));

		}

		return submissionDataList.size();
	}

}
