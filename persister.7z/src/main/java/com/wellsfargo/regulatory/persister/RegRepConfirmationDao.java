package com.wellsfargo.regulatory.persister;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.dto.RegRepConfirmation;

public interface RegRepConfirmationDao extends Serializable, Dao<RegRepConfirmation> {

}
