package com.wellsfargo.regulatory.persister.trioptima.parser;

import java.io.File;
import java.io.FileOutputStream;
import java.io.StringReader;
import java.util.Date;
import java.util.Scanner;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;


/**
 * 
 * @author a120564
 * 
 */
@Component
public class RegRepTrioptimaParser
{
	private Marshaller marshaller;
	private Unmarshaller unmarshaller;
	private String tempFileLoc;

	private static Logger logger = Logger.getLogger(RegRepTrioptimaParser.class.getName());

	
	public RegRepTrioptima unmarshallToTemplateObj(String payload) throws Exception
	{
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.RegRepTrioptimaParser);
		
		logger.debug("inside RegRepTrioptimaParser unmarshallToTemplateObj method");
		StringReader payLoadStream = null;
		Object parsedObject = null;
		String errorString = null;
		RegRepTrioptima regRepTrioptima = null;

		try
		{
			payLoadStream = new StringReader(payload);
			parsedObject = unmarshaller.unmarshal(new StreamSource(payLoadStream));
		}
		catch (Exception e)
		{
			errorString = "Exception occurred while parsing incoming sdr request using JaxB : " + e.getMessage();
			logger.error("########## " + errorString);
			return null;
		}

		if (null == parsedObject || !(parsedObject instanceof RegRepTrioptima))
		{
			errorString = "Invalid parsed object : ";
			logger.error("########## " + errorString);
			return null;

		}

		regRepTrioptima = (RegRepTrioptima) parsedObject;

		logger.debug(" RegRepTrioptimaParser object formed out of xml string: " + regRepTrioptima.toString());
		logger.debug("exiting RegRepTrioptimaParser unmarshallToTemplateObj method");

		return regRepTrioptima;

	}

	public String marshallToDtccTemplateString(RegRepTrioptima regRepTrioptima) throws Exception
	{
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.RegRepTrioptimaParser);
		String response = null;
		String fileName = Constants.REG_REP_TEMP + Constants.UNDERSCORE + "RegRepTrioptimaParser" +  Constants.UNDERSCORE + (new Date()).getTime();

		File tempFile = new File(tempFileLoc + File.separator + fileName);

		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(tempFile);

			marshaller.marshal(regRepTrioptima, new StreamResult(fos));
			
			Scanner respScanner = new Scanner(tempFile);			
			response = respScanner.useDelimiter("\\Z").next();
			respScanner.close();	
		
			logger.debug("RegRepTrioptimaParser string: " + response);

		}
		catch (Exception exp)
		{
			throw exp;

		}
		finally
		{
			if (fos != null)
			{
				fos.close();
			}

			tempFile.delete();
		}

		return response;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

}
