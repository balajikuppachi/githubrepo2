package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;

import com.wellsfargo.regulatory.persister.dto.RegRepException;
import com.wellsfargo.regulatory.persister.helper.DaoFilters;

public interface RegRepExceptionDao extends Serializable, Dao<RegRepException>
{
	public Function<Criteria, Criteria> filter(Date start, Date end, List<String> assetClasses, List<String> jurisdictions, boolean orderByTimestamp);
}
