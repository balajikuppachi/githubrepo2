package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepDupCheckMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepDupCheckMapping;

public class RegRepDupCheckMappingDaoImpl extends AbstractDaoImpl<RegRepDupCheckMapping> implements RegRepDupCheckMappingDao{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7459829006588983460L;

	@Override
	public Class<RegRepDupCheckMapping> getEntityClass()
	{
		return RegRepDupCheckMapping.class;
	}

}
