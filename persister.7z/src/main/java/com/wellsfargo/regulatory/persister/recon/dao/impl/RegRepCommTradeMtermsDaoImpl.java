package com.wellsfargo.regulatory.persister.recon.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepCommTradeMtermsDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;

/**
 * @author Raji Komatreddy
 */
public class RegRepCommTradeMtermsDaoImpl extends AbstractDaoImpl<RegRepCommTradeMterms> implements RegRepCommTradeMtermsDao
{

	private JdbcTemplate jdbcTemplate;
	private static final long serialVersionUID = 1L;


	@Override
	public Class<RegRepCommTradeMterms> getEntityClass()
	{

		return RegRepCommTradeMterms.class;
	}

	@SuppressWarnings("unchecked")
	public Long getCountofTransactions(Date reportDate, String sourceSystem)
	{
		List<Object> objList = findByNamedQuery(RegRepCommTradeMterms.GET_TOTAL_TRANSACTIONS_FOR_SYSTEM, new Object[]
		{ reportDate, sourceSystem });
		Long count = null;

		if (null != objList)
		{
			count = (Long) objList.get(0);
		}

		return count;
	}

	@SuppressWarnings("unchecked")
	public Long getCntOfMatchedTransactions(Date reportDate, String sourceSystem, Date reportDate1, String CompareSourceSystem)
	{
		List<Object> objList = findByNamedQuery(RegRepCommTradeMterms.GET_MATCHED_TRANSACTIONS_COUNT_FOR_SYSTEM, new Object[]
		{ reportDate, sourceSystem, reportDate1, CompareSourceSystem });
		Long count = null;

		if (null != objList)
		{
			count = (Long) objList.get(0);
		}

		return count;
	}

	@SuppressWarnings("unchecked")
	public List<RegRepCommTradeMterms> getMatchedTransactions(Date reportDate, String sourceSystem, Date reportDate1, String CompareSourceSystem)
	{
		return findByNamedQuery(RegRepCommTradeMterms.GET_MATCHED_TRANSACTIONS_FOR_SYSTEM, new Object[]
		{ reportDate, sourceSystem, reportDate1, CompareSourceSystem });
	}

	@SuppressWarnings("unchecked")
	public List<RegRepCommTradeMterms> getUnMatchedTransactions(Date reportDate, String sourceSystem, Date reportDate1, String CompareSourceSystem)
	{
		return findByNamedQuery(RegRepCommTradeMterms.GET_UN_MATCHED_TRANSACTIONS_FOR_SYSTEM, new Object[]
		{ reportDate, sourceSystem, reportDate1, CompareSourceSystem });
	}

	public int springBatchInsert(final List<RegRepCommTradeMterms> regRepCommTradeMtermsList)
	{

		String sql = "insert into REG_REP_COMM_TRADE_MTERMS" + " (batch_id, report_date, source_system, trade_id," + " trade_version, product_id, product_name, trade_date,"
		        + " effective_date, maturity_date, tlc_event, tlc_event_datetime, " + "trade_status, party1_name, party2_name, party1_lei, party2_lei,"
		        + " reportable, reporting_party, delegated_reporting, repository, usi, endur_unique_id," + " sender_trade_ref_id, ice_confirm_status, create_datetime) "
		        + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
		{

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException
			{
				RegRepCommTradeMterms currRegRepCommTradeMterms = regRepCommTradeMtermsList.get(i);

				ps.setInt(1, currRegRepCommTradeMterms.getBatchId());
				ps.setDate(2, new java.sql.Date(currRegRepCommTradeMterms.getReportDate().getTime()));
				ps.setString(3, currRegRepCommTradeMterms.getSourceSystem());
				ps.setString(4, currRegRepCommTradeMterms.getTradeId());
				ps.setString(5, currRegRepCommTradeMterms.getTradeVersion());
				ps.setString(6, currRegRepCommTradeMterms.getProductId());
				ps.setString(7, currRegRepCommTradeMterms.getProductName());

				if (null != currRegRepCommTradeMterms.getTradeDate())
				{
					ps.setDate(8, new java.sql.Date(currRegRepCommTradeMterms.getTradeDate().getTime()));
				}
				else
				{
					ps.setDate(8, null);
				}

				if (null != currRegRepCommTradeMterms.getEffectiveDate())
				{
					ps.setDate(9, new java.sql.Date(currRegRepCommTradeMterms.getEffectiveDate().getTime()));
				}
				else
				{
					ps.setDate(9, null);
				}

				if (null != currRegRepCommTradeMterms.getMaturityDate())
				{
					ps.setDate(10, new java.sql.Date(currRegRepCommTradeMterms.getMaturityDate().getTime()));
				}
				else
				{
					ps.setDate(10, null);
				}

				ps.setString(11, currRegRepCommTradeMterms.getTlcEvent());
				if (null != currRegRepCommTradeMterms.getTlcEventDatetime())
				{
					ps.setDate(12, new java.sql.Date(currRegRepCommTradeMterms.getTlcEventDatetime().getTime()));
				}
				else
				{
					ps.setDate(12, null);
				}

				ps.setString(13, currRegRepCommTradeMterms.getTradeStatus());
				ps.setString(14, currRegRepCommTradeMterms.getParty1Name());
				ps.setString(15, currRegRepCommTradeMterms.getParty2Name());
				ps.setString(16, currRegRepCommTradeMterms.getParty1Lei());
				ps.setString(17, currRegRepCommTradeMterms.getParty2Lei());
				ps.setByte(18, currRegRepCommTradeMterms.isReportable());
				ps.setByte(19, currRegRepCommTradeMterms.getReportingParty());
				ps.setByte(20, currRegRepCommTradeMterms.isDelegatedReporting());
				ps.setString(21, currRegRepCommTradeMterms.getRepository());
				ps.setString(22, currRegRepCommTradeMterms.getUsi());
				ps.setString(23, currRegRepCommTradeMterms.getEndurUniqueId());
				ps.setString(24, currRegRepCommTradeMterms.getSenderTradeRefId());
				ps.setString(25, currRegRepCommTradeMterms.getIceConfirmStatus());

				ps.setDate(26, new java.sql.Date(currRegRepCommTradeMterms.getCreateDatetime().getTime()));
			}

			@Override
			public int getBatchSize()
			{
				return regRepCommTradeMtermsList.size();
			}
		});

		return regRepCommTradeMtermsList.size();
	}

	public JdbcTemplate getJdbcTemplate()
	{
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

}
