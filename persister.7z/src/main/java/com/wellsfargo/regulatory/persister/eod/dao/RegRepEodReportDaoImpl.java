package com.wellsfargo.regulatory.persister.eod.dao;

import static com.wellsfargo.regulatory.commons.keywords.Constants.APP_FALSE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.APP_TRUE;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodReport;
/**
 * 
 * @author Raji Komatreddy
 *
 */

@Component
public class RegRepEodReportDaoImpl implements RowMapper<RegRepEodReport>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	String insertQuery = " INSERT INTO REG_REP_EOD_REPORT (EOD_REPORT_ID, SWAP_TRADE_ID, ASSET_CLASS, JURISDICTION, EVENT_TYPE, ACTION_TYPE,TRADE_STATUS, SRC_MESSAGE_ID, IS_ACTIVE, EXPIRED_ON, INSERT_TIMESTAMP, REPORT_TYPE, IS_BUFFER_ELIGIBLE,COB_DATE,TRADE_USI,TRADE_UTI) "
			+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?) ";
	
	
	String updateActiveFlagTradeidRepQuery = "UPDATE REG_REP_EOD_REPORT SET r.IS_ACTIVE = '"+ APP_FALSE +"' FROM REG_REP_EOD_REPORT r WHERE r.SWAP_TRADE_ID = ? AND r.IS_ACTIVE = '"+ APP_TRUE +"' AND r.JURISDICTION = ?  AND r.ASSET_CLASS = ? AND r.REPORT_TYPE = ? ";
	
	String updateActiveFlagTradeidQuery = "UPDATE REG_REP_EOD_REPORT SET r.IS_ACTIVE = '"+ APP_FALSE +"' FROM REG_REP_EOD_REPORT r WHERE r.SWAP_TRADE_ID = ? AND r.IS_ACTIVE = '"+ APP_TRUE +"' AND r.JURISDICTION = ?  AND r.ASSET_CLASS = ?";
	
	
	String reportIdQuery = "SELECT EOD_REPORT_ID,SWAP_TRADE_ID,ASSET_CLASS,JURISDICTION,EVENT_TYPE,ACTION_TYPE,TRADE_STATUS,SRC_MESSAGE_ID,IS_ACTIVE,EXPIRED_ON,INSERT_TIMESTAMP,REPORT_TYPE,IS_BUFFER_ELIGIBLE,COB_DATE,TRADE_USI,TRADE_UTI FROM REG_REP_EOD_REPORT "
			+ " WHERE SWAP_TRADE_ID = ? AND IS_ACTIVE = '"+ APP_TRUE +"' AND JURISDICTION = ? AND ASSET_CLASS = ? AND REPORT_TYPE = ? ";

	String findLastActivequery 						= "SELECT EOD_REPORT_ID,SWAP_TRADE_ID,ASSET_CLASS,JURISDICTION,EVENT_TYPE,ACTION_TYPE,TRADE_STATUS,SRC_MESSAGE_ID,IS_ACTIVE,EXPIRED_ON,INSERT_TIMESTAMP,REPORT_TYPE,IS_BUFFER_ELIGIBLE,COB_DATE,TRADE_USI,TRADE_UTI FROM REG_REP_EOD_REPORT r WHERE r.SWAP_TRADE_ID = ?  AND r.JURISDICTION = ? AND r.ASSET_CLASS = ?  ORDER BY r.INSERT_TIMESTAMP DESC ";
	String valuationCheckQuery 						= "SELECT count(*) FROM REG_REP_EOD_PAYLOAD p, REG_REP_EOD_REPORT r WHERE p.EOD_REPORT_ID=r.EOD_REPORT_ID AND r.IS_ACTIVE='1' AND r.IS_BUFFER_ELIGIBLE = 1 AND r.REPORT_TYPE='Valuation' AND r.SWAP_TRADE_ID = ? AND r.JURISDICTION = ? ";
	
	String updateBufferEligibleQuery				= "UPDATE REG_REP_EOD_REPORT SET IS_BUFFER_ELIGIBLE = 0 WHERE SWAP_TRADE_ID = ? AND JURISDICTION = ? AND ASSET_CLASS = ? AND REPORT_TYPE = ? AND EOD_REPORT_ID = ? ";
	String updateBufferIneligibleForSnapshotQuery 	= "UPDATE REG_REP_EOD_REPORT SET IS_BUFFER_ELIGIBLE = 0 WHERE SWAP_TRADE_ID = ? AND JURISDICTION = ? AND ASSET_CLASS = ? AND IS_ACTIVE = '1' AND REPORT_TYPE = 'Snapshot' ";
	String updateBufferIneligibleQuery 				= "UPDATE REG_REP_EOD_REPORT SET IS_BUFFER_ELIGIBLE = 0 WHERE SWAP_TRADE_ID = ? AND JURISDICTION = ? AND ASSET_CLASS = ? AND IS_ACTIVE = '1' ";
	
	String updateActiveFlagEodIDQuery 				= "UPDATE REG_REP_EOD_REPORT SET IS_ACTIVE = :newIsActive,IS_BUFFER_ELIGIBLE = :newIsBufferEligible FROM REG_REP_EOD_REPORT WHERE IS_ACTIVE = :oldIsActive AND JURISDICTION = :jurisdiction AND ASSET_CLASS = :assetClass AND EOD_REPORT_ID in ( :eodRepIds ) ";
	String updateActiveFlagForAction				= "UPDATE REG_REP_EOD_REPORT SET IS_ACTIVE = ? WHERE ACTION_TYPE = ? AND IS_ACTIVE = ? AND JURISDICTION = ? AND ASSET_CLASS = ? AND REPORT_TYPE = ? ";
	String updateActiveFlagForUSICancel				= "UPDATE REG_REP_EOD_REPORT SET IS_ACTIVE = ? WHERE EVENT_TYPE = ? AND IS_ACTIVE = ? AND JURISDICTION = ?  AND ASSET_CLASS = ? AND REPORT_TYPE = ? ";
	String updateLastActiveForCancelQuery 			= "UPDATE REG_REP_EOD_REPORT SET IS_ACTIVE = ? WHERE IS_ACTIVE = ? AND JURISDICTION = ? AND ASSET_CLASS = ? AND REPORT_TYPE = ? ";
	String updateExpriredTradesquery 				= "UPDATE REG_REP_EOD_REPORT SET IS_ACTIVE = ? WHERE EXPIRED_ON is not null AND IS_ACTIVE = ? AND JURISDICTION = ? AND ASSET_CLASS = ? AND REPORT_TYPE = ? ";
	String allocatedNotionalQuery 					= "SELECT SUM(l.NOTIONAL) from  REG_REP_MESSAGE m, REG_REP_PRODUCT p, REG_REP_LEG l where m.REG_REP_MESSAGE_ID=p.REG_REP_MESSAGE_ID  "+
													  "and m.LIFECYCLE_EVENT_TYPE='New Allocated' and m.MESSAGE_TYPE='SDR_TRADE' and l.REG_REP_PRODUCT_ID=p.REG_REP_PRODUCT_ID and l.REG_REP_LEG_ID=1 and m.PREV_USI =?";
	String unallocatedBlockTradesQry				= "SELECT DISTINCT r.SWAP_TRADE_ID from REG_REP_EOD_REPORT r where r.IS_ACTIVE='1' and r.IS_BUFFER_ELIGIBLE=1 and r.REPORT_TYPE='Snapshot'   and r.SWAP_TRADE_ID in "
						+ " (SELECT SWAP_TRADE_ID from REG_REP_MESSAGE where LIFECYCLE_EVENT_TYPE='Block Trade' and ASSET_CLASS in ('InterestRate','ForeignExchange') and MESSAGE_TYPE='SDR_TRADE')";
	
	String selectPreviousSnapshot =  "select rp.SWAP_TRADE_ID from REG_REP_EOD_REPORT rp where rp.REPORT_TYPE = 'Snapshot' and rp.INSERT_TIMESTAMP < convert(date, getutcdate(), 101) and rp.IS_ACTIVE = '1' and rp.SWAP_TRADE_ID = ?";
	String todaysSnapshot =	          "select rp.SWAP_TRADE_ID from REG_REP_EOD_REPORT rp where rp.REPORT_TYPE = 'Snapshot' and convert(date, rp.INSERT_TIMESTAMP, 101)   = convert(date, getutcdate(), 101) and rp.IS_BUFFER_ELIGIBLE = 1 and rp.SWAP_TRADE_ID = ?";
	
	String selectValRepTradeData =  "select SWAP_TRADE_ID,isnull(TRADE_USI,TRADE_UTI) usi_uti,EVENT_TYPE from  REG_REP_EOD_REPORT where IS_ACTIVE = '1' and IS_BUFFER_ELIGIBLE=1 and JURISDICTION =? and ASSET_CLASS =?  and REPORT_TYPE = 'Valuation' ";
			
										
	@Override
    public RegRepEodReport mapRow(ResultSet rs, int row) throws SQLException
    {
		RegRepEodReport currRegRepEodReport = new RegRepEodReport();
		currRegRepEodReport.setEodReportId(rs.getString(1));
		currRegRepEodReport.setSwapTradeId(rs.getString(2));
		currRegRepEodReport.setAssetClass(rs.getString(3));
		currRegRepEodReport.setJurisdiction(rs.getString(4));
		currRegRepEodReport.setEvntType(rs.getString(5));
		currRegRepEodReport.setActionType(rs.getString(6));
		currRegRepEodReport.setTradeStatus(rs.getString(7));
		currRegRepEodReport.setSrcMessageId(rs.getString(8));
		currRegRepEodReport.setIsActive(rs.getString(9));
		currRegRepEodReport.setExpiredOn(rs.getDate(10));
		currRegRepEodReport.setInsertTimeStamp(rs.getTimestamp(11));
		currRegRepEodReport.setReportType(rs.getString(12));
		currRegRepEodReport.setIsBufferEligible(rs.getInt(13));
		currRegRepEodReport.setCobDate(rs.getDate(14));
		currRegRepEodReport.setTradeUSI(rs.getString(15));
		currRegRepEodReport.setTradeUTI(rs.getString(16));
	    return currRegRepEodReport;
    }
	
	public boolean insertRegRepEodReport(RegRepEodReport regRepEodReport)
	{
		
		boolean successful = false;
		 jdbcTemplate.update(insertQuery, new Object[] {regRepEodReport.getEodReportId(), regRepEodReport.getSwapTradeId(), regRepEodReport.getAssetClass(),
				 regRepEodReport.getJurisdiction(), regRepEodReport.getEvntType(), regRepEodReport.getActionType(), 
				 regRepEodReport.getTradeStatus(), regRepEodReport.getSrcMessageId(), regRepEodReport.getIsActive(),
				 regRepEodReport.getExpiredOn(), regRepEodReport.getInsertTimeStamp(), 	 regRepEodReport.getReportType(), 
				 regRepEodReport.getIsBufferEligible(),regRepEodReport.getCobDate(),
				 regRepEodReport.getTradeUSI(),regRepEodReport.getTradeUTI() });
		 
		 successful = true;
		return successful;
		
	}
	
	public int updateEodActiveRepFlag(RegRepEodReport regRepEodReport)
	{
		int updatedRecords=0;
		updatedRecords=jdbcTemplate.update(updateActiveFlagTradeidRepQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass(),regRepEodReport.getReportType()});
		
		return updatedRecords;
	}
	
	
	public int updateEodActiveFlag(RegRepEodReport regRepEodReport)
	{
		int updatedRecords=0;
		updatedRecords=jdbcTemplate.update(updateActiveFlagTradeidQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass()});
		
		return updatedRecords;
	}
	
	
	public List<RegRepEodReport> getEodReportId(RegRepEodReport regRepEodReport)
	{
		
		List<RegRepEodReport> queryResult = jdbcTemplate.query(reportIdQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass(), regRepEodReport.getReportType()},this);
		
		return queryResult;
	}
	
	public List<RegRepEodReport> findLastActiveTrades(RegRepEodReport regRepEodReport)
	{
		
		List<RegRepEodReport> queryResult = jdbcTemplate.query(findLastActivequery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass()},this);
		
		return queryResult;
	}
	
	public boolean updateBufferEligible(RegRepEodReport regRepEodReport,String eodRepId)
	{
		boolean successful = false;
		jdbcTemplate.update(updateBufferEligibleQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass(),regRepEodReport.getReportType(),eodRepId });
		successful= true;
		
		return successful;
	}
	
	public boolean updateActiveFlag(String newIsActive,String newBufferEligible, String oldIsActive, RegRepEodReport regRepEodReport,List<String> eodRepIds)
	{
		boolean successful = false;

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("newIsActive", newIsActive);
		params.put("newIsBufferEligible", Integer.valueOf(newBufferEligible));
		params.put("oldIsActive", oldIsActive);
		params.put("jurisdiction", regRepEodReport.getJurisdiction());
		params.put("assetClass", regRepEodReport.getAssetClass());
		params.put("eodRepIds", eodRepIds);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		 namedParameterJdbcTemplate.update(updateActiveFlagEodIDQuery, params);
		successful= true;
		
		return successful;
	}
	
	public boolean updateActiveFlagForAction(String newFlagVal,RegRepEodReport regRepEodReport)
	{
		boolean successful = false;
		String usiCancel = "USI Cancel";
		jdbcTemplate.update(updateActiveFlagForAction, new Object[] {newFlagVal,regRepEodReport.getActionType(),regRepEodReport.getIsActive(),regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass(),regRepEodReport.getReportType()});
		// running again to update USI Cancel event type submissions to 0 for Equity USI Cancel scenario
		jdbcTemplate.update(updateActiveFlagForUSICancel, new Object[] {newFlagVal,usiCancel,regRepEodReport.getIsActive(),regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass(),regRepEodReport.getReportType()});
		successful= true;
		
		return successful;
	}
	
	public boolean updateLastActiveForCancel(String newFlagVal,RegRepEodReport regRepEodReport)
	{
		boolean successful = false;
		jdbcTemplate.update(updateLastActiveForCancelQuery, new Object[] {newFlagVal,regRepEodReport.getIsActive(),regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass(),regRepEodReport.getReportType()});
		successful= true;
		
		return successful;
	}
	
	public boolean updateExpriredTrades(String newFlagVal,RegRepEodReport regRepEodReport)
	{
		boolean successful = false;
		jdbcTemplate.update(updateExpriredTradesquery, new Object[] {newFlagVal,regRepEodReport.getIsActive(),regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass(),regRepEodReport.getReportType()});
		successful= true;
		
		return successful;
	}
	
	public boolean updateBufferIneligible(RegRepEodReport regRepEodReport)
	{
		boolean successful = false;
		jdbcTemplate.update(updateBufferIneligibleQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass()});
		successful= true;
		
		return successful;
	}
	
	public boolean updateEodBufferIneligibleForSnapshot(RegRepEodReport regRepEodReport)
	{
		boolean successful = false;
		jdbcTemplate.update(updateBufferIneligibleForSnapshotQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(),regRepEodReport.getAssetClass()});
		successful= true;
		
		return successful;
	}
	
    //queryForInt deprecated in spring4
	public boolean IsValuationExist(RegRepEodReport regRepEodReport)
	{
		boolean valExist = false;
		@SuppressWarnings("deprecation")
		//Integer count = jdbcTemplate.queryForInt(valuationCheckQuery, new Object[]{regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction()});
		Integer count = jdbcTemplate.queryForObject(valuationCheckQuery, new Object[]{regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction()}, Integer.class);
		
		if (count != null && count >=1)
			valExist = true;
		
		return valExist;
	}
	
	/**
	 * Get the Sum of notional's for allocated trades based on the block usi 
	 * @param usi
	 * @return
	 */
	
	public BigDecimal getAllocatedNotionalForBlockTrade(String usi)
	{
	
		BigDecimal retValue = jdbcTemplate.queryForObject(allocatedNotionalQuery, new Object[]{usi}, BigDecimal.class);
			
		return retValue;
	}
	
	/**
	 * List of the trades of Block trades where the allocation is missing
	 * 
	 */
	public List<String> getUnallocatedBlockTradeIds()
	{
		List<String> retList = jdbcTemplate.queryForList(unallocatedBlockTradesQry, String.class);
		
		return retList;
	}
	
	/**
	 * returns list of trades which are in active status and message type of snapshot and insert timestamp is greater than today
	 * 
	 */
	public List<String> getPreviousActiveSnapshots(String tradeId)
	{
		List<String> retList = jdbcTemplate.queryForList(selectPreviousSnapshot,new Object[]{tradeId}, String.class);
		
		return retList;
	}
	/**
	 * returns list of trade ids which are received today for given tradeID 
	 * 
	 */
	public List<String> getTodaysSnapshots(String tradeId)
	{
		List<String> retList = jdbcTemplate.queryForList(todaysSnapshot,new Object[]{tradeId}, String.class);
		
		return retList;
	}
	
	/**
	 * returns list of trades for which Valuation data does not exit in REG_REP_EOD_EXT_VAL_DATA table
	 * 
	 */
	public List<Map<String,String>> getTradeIdsWithOutValData(String jurisdiction, String assetClass)
	{
		
		@SuppressWarnings("unchecked")
		List<Map<String,String>> retList = jdbcTemplate.query(selectValRepTradeData,new Object[]{jurisdiction, assetClass},(RowMapper<Map<String, String>>) (rs, rowNum) -> {
			Map<String,String> eodTradeMap=new HashMap<String, String>();
			
			eodTradeMap.put(Constants.TRADE_ID, rs.getString(1));
			eodTradeMap.put(Constants.USI_UTI, rs.getString(2));
			eodTradeMap.put(Constants.MARKET_TYPE, rs.getString(3));
			
			return eodTradeMap;
		});
		
		return retList;
	}
	
	
}
