package com.wellsfargo.regulatory.persister.dao;

import java.util.List;

import com.wellsfargo.regulatory.commons.cache.beans.RealtimeConfigData;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;

public interface RegRepDomainMapDao 
{
	List<RegRepDomainMapping> getDomainMappings() throws Exception;
	
	List<RealtimeConfigData> getRealtimeConfigData() throws Exception;
}
