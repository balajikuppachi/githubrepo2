package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepDocumentation;

public interface RegRepDocumentationDao extends Serializable, Dao<RegRepDocumentation>
{

}
