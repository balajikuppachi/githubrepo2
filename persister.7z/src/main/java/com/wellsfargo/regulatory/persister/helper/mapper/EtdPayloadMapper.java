package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * 
 * @author Raji komatreddy
 *
 */
public class EtdPayloadMapper
{
	private static Logger logger = Logger.getLogger(RegRepMessageMapper.class.getName());
	
	public EtdPayload createFromContext(ReportingContext context)
	{
		logger.debug("inside EtdPayloadMapper createFromContext method");
		String payload = null;
		String messageId = null;
		String payloadType = null;
		
		if(context == null)
		{
			return null;
		}
		
		messageId = context.getMessageId();
		payload = context.getPayload();
		payloadType = context.getMessageSource();
		
		EtdPayload etdPayload = new EtdPayload();
		
		Date currDate = new Date();
		
		etdPayload.setMessageId(messageId);
		etdPayload.setPayload(payload);
		etdPayload.setPayloadType(payloadType);
		etdPayload.setCreateDatetime(currDate);
		
		logger.debug("exiting EtdPayloadMapper createFromContext method" );
		
		return etdPayload;
		
	}
	
	public EtdPayload entryForRegRepCollateral()
	{
		logger.debug("inside EtdPayloadMapper createForRegRepCollateral method");
		String payload = null;
		String messageId = null;
		String payloadType = null;
		messageId = ReportingDataUtils.generateMessageId();		
		
		payload = "Place holder for RegRepCollateral process";
		payloadType = Constants.EOD_REGREP_COLLATERALVALUE;
		
		EtdPayload etdPayload = new EtdPayload();
		
		Date currDate = new Date();
		
		etdPayload.setMessageId(messageId);
		etdPayload.setPayload(payload);
		etdPayload.setPayloadType(payloadType);
		etdPayload.setCreateDatetime(currDate);
		
		logger.debug("exiting EtdPayloadMapper createFromContext method" );
		
		return etdPayload;
		
	}

}
