package com.wellsfargo.regulatory.persister.etd.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdException;

public interface EtdExceptionDao extends Serializable, Dao<EtdException>
{

}
