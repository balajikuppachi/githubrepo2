package com.wellsfargo.regulatory.persister.dto;

import java.util.Date;

public class RegRepEodSubmissionTracker {

	private Long submissionId;
	private String eodReportId;
	private String regRepMessageId;
	private String tradeId;
	private String tradeUsi;
	private String tradeUti;
	private String eventType;
	private String reportType;
	private String jurisdiction;
	private String assetClass;
	private String repository;
	private String party1LeiPrefix;
	private String party1Lei;
	private String party2LeiPrefix;
	private String party2Lei;
	private String sentTo;
	private String sentBy;
	private String dataSubmitter;
	private String responseStatus;
	private Date cobDate;
	private Date createDateTime;
	private Date updateDateTime;
	
	
	public Long getSubmissionId() {
		return submissionId;
	}
	public void setSubmissionId(Long submissionId) {
		this.submissionId = submissionId;
	}
	public String getEodReportId() {
		return eodReportId;
	}
	public void setEodReportId(String eodReportId) {
		this.eodReportId = eodReportId;
	}
	public String getRegRepMessageId() {
		return regRepMessageId;
	}
	public void setRegRepMessageId(String regRepMessageId) {
		this.regRepMessageId = regRepMessageId;
	}
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getTradeUsi() {
		return tradeUsi;
	}
	public void setTradeUsi(String tradeUsi) {
		this.tradeUsi = tradeUsi;
	}
	public String getTradeUti() {
		return tradeUti;
	}
	public void setTradeUti(String tradeUti) {
		this.tradeUti = tradeUti;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getRepository() {
		return repository;
	}
	public void setRepository(String repository) {
		this.repository = repository;
	}
	public String getParty1LeiPrefix() {
		return party1LeiPrefix;
	}
	public void setParty1LeiPrefix(String party1LeiPrefix) {
		this.party1LeiPrefix = party1LeiPrefix;
	}
	public String getParty1Lei() {
		return party1Lei;
	}
	public void setParty1Lei(String party1Lei) {
		this.party1Lei = party1Lei;
	}
	public String getParty2LeiPrefix() {
		return party2LeiPrefix;
	}
	public void setParty2LeiPrefix(String party2LeiPrefix) {
		this.party2LeiPrefix = party2LeiPrefix;
	}
	public String getParty2Lei() {
		return party2Lei;
	}
	public void setParty2Lei(String party2Lei) {
		this.party2Lei = party2Lei;
	}
	public String getSentTo() {
		return sentTo;
	}
	public void setSentTo(String sentTo) {
		this.sentTo = sentTo;
	}
	public String getSentBy() {
		return sentBy;
	}
	public void setSentBy(String sentBy) {
		this.sentBy = sentBy;
	}
	public String getDataSubmitter() {
		return dataSubmitter;
	}
	public void setDataSubmitter(String dataSubmitter) {
		this.dataSubmitter = dataSubmitter;
	}
	public String getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}
	public Date getCobDate() {
		return cobDate;
	}
	public void setCobDate(Date cobDate) {
		this.cobDate = cobDate;
	}
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
	public Date getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((assetClass == null) ? 0 : assetClass.hashCode());
		result = prime * result + ((cobDate == null) ? 0 : cobDate.hashCode());
		result = prime * result
				+ ((createDateTime == null) ? 0 : createDateTime.hashCode());
		result = prime * result
				+ ((dataSubmitter == null) ? 0 : dataSubmitter.hashCode());
		result = prime * result
				+ ((eodReportId == null) ? 0 : eodReportId.hashCode());
		result = prime * result
				+ ((eventType == null) ? 0 : eventType.hashCode());
		result = prime * result
				+ ((jurisdiction == null) ? 0 : jurisdiction.hashCode());
		result = prime * result
				+ ((party1Lei == null) ? 0 : party1Lei.hashCode());
		result = prime * result
				+ ((party1LeiPrefix == null) ? 0 : party1LeiPrefix.hashCode());
		result = prime * result
				+ ((party2Lei == null) ? 0 : party2Lei.hashCode());
		result = prime * result
				+ ((party2LeiPrefix == null) ? 0 : party2LeiPrefix.hashCode());
		result = prime * result
				+ ((regRepMessageId == null) ? 0 : regRepMessageId.hashCode());
		result = prime * result
				+ ((reportType == null) ? 0 : reportType.hashCode());
		result = prime * result
				+ ((repository == null) ? 0 : repository.hashCode());
		result = prime * result
				+ ((responseStatus == null) ? 0 : responseStatus.hashCode());
		result = prime * result + ((sentBy == null) ? 0 : sentBy.hashCode());
		result = prime * result + ((sentTo == null) ? 0 : sentTo.hashCode());
		result = prime * result
				+ ((submissionId == null) ? 0 : submissionId.hashCode());
		result = prime * result + ((tradeId == null) ? 0 : tradeId.hashCode());
		result = prime * result
				+ ((tradeUsi == null) ? 0 : tradeUsi.hashCode());
		result = prime * result
				+ ((tradeUti == null) ? 0 : tradeUti.hashCode());
		result = prime * result
				+ ((updateDateTime == null) ? 0 : updateDateTime.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegRepEodSubmissionTracker other = (RegRepEodSubmissionTracker) obj;
		if (assetClass == null) {
			if (other.assetClass != null)
				return false;
		} else if (!assetClass.equals(other.assetClass))
			return false;
		if (cobDate == null) {
			if (other.cobDate != null)
				return false;
		} else if (!cobDate.equals(other.cobDate))
			return false;
		if (createDateTime == null) {
			if (other.createDateTime != null)
				return false;
		} else if (!createDateTime.equals(other.createDateTime))
			return false;
		if (dataSubmitter == null) {
			if (other.dataSubmitter != null)
				return false;
		} else if (!dataSubmitter.equals(other.dataSubmitter))
			return false;
		if (eodReportId == null) {
			if (other.eodReportId != null)
				return false;
		} else if (!eodReportId.equals(other.eodReportId))
			return false;
		if (eventType == null) {
			if (other.eventType != null)
				return false;
		} else if (!eventType.equals(other.eventType))
			return false;
		if (jurisdiction == null) {
			if (other.jurisdiction != null)
				return false;
		} else if (!jurisdiction.equals(other.jurisdiction))
			return false;
		if (party1Lei == null) {
			if (other.party1Lei != null)
				return false;
		} else if (!party1Lei.equals(other.party1Lei))
			return false;
		if (party1LeiPrefix == null) {
			if (other.party1LeiPrefix != null)
				return false;
		} else if (!party1LeiPrefix.equals(other.party1LeiPrefix))
			return false;
		if (party2Lei == null) {
			if (other.party2Lei != null)
				return false;
		} else if (!party2Lei.equals(other.party2Lei))
			return false;
		if (party2LeiPrefix == null) {
			if (other.party2LeiPrefix != null)
				return false;
		} else if (!party2LeiPrefix.equals(other.party2LeiPrefix))
			return false;
		if (regRepMessageId == null) {
			if (other.regRepMessageId != null)
				return false;
		} else if (!regRepMessageId.equals(other.regRepMessageId))
			return false;
		if (reportType == null) {
			if (other.reportType != null)
				return false;
		} else if (!reportType.equals(other.reportType))
			return false;
		if (repository == null) {
			if (other.repository != null)
				return false;
		} else if (!repository.equals(other.repository))
			return false;
		if (responseStatus == null) {
			if (other.responseStatus != null)
				return false;
		} else if (!responseStatus.equals(other.responseStatus))
			return false;
		if (sentBy == null) {
			if (other.sentBy != null)
				return false;
		} else if (!sentBy.equals(other.sentBy))
			return false;
		if (sentTo == null) {
			if (other.sentTo != null)
				return false;
		} else if (!sentTo.equals(other.sentTo))
			return false;
		if (submissionId == null) {
			if (other.submissionId != null)
				return false;
		} else if (!submissionId.equals(other.submissionId))
			return false;
		if (tradeId == null) {
			if (other.tradeId != null)
				return false;
		} else if (!tradeId.equals(other.tradeId))
			return false;
		if (tradeUsi == null) {
			if (other.tradeUsi != null)
				return false;
		} else if (!tradeUsi.equals(other.tradeUsi))
			return false;
		if (tradeUti == null) {
			if (other.tradeUti != null)
				return false;
		} else if (!tradeUti.equals(other.tradeUti))
			return false;
		if (updateDateTime == null) {
			if (other.updateDateTime != null)
				return false;
		} else if (!updateDateTime.equals(other.updateDateTime))
			return false;
		return true;
	}

	
	

}
