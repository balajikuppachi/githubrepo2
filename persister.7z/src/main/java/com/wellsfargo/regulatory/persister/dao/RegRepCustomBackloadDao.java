package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepCustomBackload;

public interface RegRepCustomBackloadDao extends Serializable, Dao<RegRepCustomBackload> {	

}
