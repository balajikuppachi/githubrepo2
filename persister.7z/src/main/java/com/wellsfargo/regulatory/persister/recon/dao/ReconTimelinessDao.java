package com.wellsfargo.regulatory.persister.recon.dao;

import java.util.List;

import com.wellsfargo.regulatory.persister.recon.dto.ReconTimelinessDomain;
import com.wellsfargo.regulatory.commons.exceptions.ReconException;;

public interface ReconTimelinessDao {

	/** 
	 * Returns all rows from the domain_values table that match the criteria ''.
	 */
	public List<ReconTimelinessDomain> findAll() throws ReconException;
	
}
