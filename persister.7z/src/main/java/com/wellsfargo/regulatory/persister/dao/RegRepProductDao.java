package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepProduct;

public interface RegRepProductDao extends Dao<RegRepProduct>, Serializable
{

}
