package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepLifecycle;

public interface RegRepLifecycleDao extends Dao<RegRepLifecycle>, Serializable
{

}
