/**
 * 
 */
package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dto.CollateralizationType;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodToReport;


/**
 * @author Pavan.Siram
 *
 */
@Component
public class RegRepEodToReportDaoImpl  implements RowMapper<RegRepEodToReport> 
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	String TO_REPORTING_QUERY=" select * from REG_REP_RECON_TRIOPTIMA recon where"
			+ " recon.ASSET_CLASS=? and recon.REPORT_TYPE=? and recon.REPOSITORY=? and IS_ACTIVE = '1' ";
	
	String TRADE_LEVEL_COLLATERALIZATION=" select distinct t.TRADE_ID, t.COLLATERALIZATION from REG_REP_TRADE_COLLATERAL t, REG_REP_MESSAGE i where i.ASSET_CLASS = ? "
 			+" AND t.TRADE_ID = i.SWAP_TRADE_ID and t.SRC_SYSTEM = 'STIERS_CALYPSO_CALRATES' "
 			+" AND i.REG_REP_MESSAGE_ID in (select nr.REG_REP_MESSAGE_ID from REG_REP_RECON_TRIOPTIMA nr where nr.REPORT_TYPE = ? "
 			+ "and nr.REPOSITORY = ? and nr.IS_ACTIVE = '1') ";
 			
 
	@Override
    public RegRepEodToReport mapRow(ResultSet rs, int row) throws SQLException
    {
		RegRepEodToReport currRegRepEodToReport = new RegRepEodToReport();
		currRegRepEodToReport.setTradeId(rs.getString("TRADE_ID"));
		currRegRepEodToReport.setAssetclass(rs.getString("ASSET_CLASS"));
		currRegRepEodToReport.setIsActive(rs.getString("IS_ACTIVE"));
		currRegRepEodToReport.setJurisdiction(rs.getString("JURISDICTION"));
		currRegRepEodToReport.setRegRepMessageId(rs.getString("REG_REP_MESSAGE_ID"));
		currRegRepEodToReport.setUsi(rs.getString("USI"));
		currRegRepEodToReport.setReportType(rs.getString("REPORT_TYPE"));
		currRegRepEodToReport.setRepository(rs.getString("REPOSITORY"));
		currRegRepEodToReport.setMessage(rs.getString("OUTPUT_MESSAGE"));
		currRegRepEodToReport.setEquityTemplate(rs.getString("EQUITY_TEMPLATE"));
		currRegRepEodToReport.setUpdateTimestamp(rs.getDate("UPDATE_TIMESTAMP"));
		currRegRepEodToReport.setCreateDateTime(rs.getDate("INSERT_TIMESTAMP"));
		
	    return currRegRepEodToReport;
    }
	

	public List<RegRepEodToReport> findAllTrades(String assetClass, String reportType,String jurisdiction){
		
		List<RegRepEodToReport> queryResult = jdbcTemplate.query(TO_REPORTING_QUERY, new Object[] {assetClass,reportType,jurisdiction},this);
		
		return queryResult;
	}
	

	public List<CollateralizationType> fetchCollateralizationType(String assetClass, String msgType,  String repository) {
		List<CollateralizationType> collateral= jdbcTemplate.query(TRADE_LEVEL_COLLATERALIZATION,new Object[] {assetClass,msgType,repository}, new RowMapper() {
			public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
				final CollateralizationType c = new CollateralizationType();
				c.setTradeID(rs.getString("TRADE_ID"));
				c.setcollateralizationType(rs.getString("COLLATERALIZATION"));
				return c;
		} });
	return collateral;
	}
	
	
	public String fetchCollateralizationTypeFX(String tradeID ) {
		String collQueryFX = "select COLLATERALIZATION	from REG_REP_TRADE_COLLATERALIZATION where TRADE_ID = ?  and SRC_SYSTEM = 'STIERS_CALYPSO_CALRATES' ";
		List<String> collateral = jdbcTemplate.queryForList(collQueryFX,String.class,new Object[]{tradeID});
		if (collateral == null || collateral.size() == 0 || collateral.get(0) == null) {
			return null;
		}
		else return collateral.get(0);
	}
}

