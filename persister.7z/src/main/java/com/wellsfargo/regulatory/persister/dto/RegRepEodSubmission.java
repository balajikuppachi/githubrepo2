package com.wellsfargo.regulatory.persister.dto;

import java.util.Date;

public class RegRepEodSubmission {

	private String eodReportId;	
	private String sdrReport;	
	private String sdrResponse;
	private String status;	
	private Date asOfDate;
	private Date insertTimestamp;
	private Date submissionTimestamp;
	private String assetClass;
	private String tradeId;
	private String reportType;
	private Long submissionId;
	private Date eodReportTimestamp;
	private Date cobDate;
    private String regRepMessageId;
    private String jurisdiction;
    private String eventType;
    private String tradeUsi;
    private String tradeUti;
	
	
	public RegRepEodSubmission(){
		
		super();
	}
		
	public RegRepEodSubmission(String eodReportId, String sdrReport,
			String severity, String sdrResponse, String status, Date asOfDate,
			Date insertTimestamp, Date submissionTimestamp, Long submissionId,Date cobDate) {
		super();
		this.eodReportId = eodReportId;
		this.sdrReport = sdrReport;		
		this.sdrResponse = sdrResponse;
		this.status = status;
		this.asOfDate = asOfDate;
		this.insertTimestamp = insertTimestamp;
		this.submissionTimestamp = submissionTimestamp;
		this.cobDate = cobDate;
		this.jurisdiction = jurisdiction;
		this.eventType = eventType;
		this.tradeUsi = tradeUsi;
		this.tradeUti = tradeUti;
		this.setSubmissionId(submissionId);
	}	
	
	
	public String getEodReportId() {
		return eodReportId;
	}
	public void setEodReportId(String eodReportId) {
		this.eodReportId = eodReportId;
	}
	public String getSdrReport() {
		return sdrReport;
	}
	public void setSdrReport(String sdrReport) {
		this.sdrReport = sdrReport;
	}	
	public String getSdrResponse() {
		return sdrResponse;
	}
	public void setSdrResponse(String sdrResponse) {
		this.sdrResponse = sdrResponse;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}
	public Date getInsertTimestamp() {
		return insertTimestamp;
	}
	public void setInsertTimestamp(Date insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}
	
	public Date getSubmissionTimestamp() {
		return submissionTimestamp;
	}
	public void setSubmissionTimestamp(Date submissionTimestamp) {
		this.submissionTimestamp = submissionTimestamp;
	}
	
	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getTradeUsi() {
		return tradeUsi;
	}

	public void setTradeUsi(String tradeUsi) {
		this.tradeUsi = tradeUsi;
	}

	public String getTradeUti() {
		return tradeUti;
	}

	public void setTradeUti(String tradeUti) {
		this.tradeUti = tradeUti;
	}


	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	
	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public Long getSubmissionId() {
		return submissionId;
	}

	public void setSubmissionId(Long submissionId) {
		this.submissionId = submissionId;
	}

	public Date getEodReportTimestamp() {
		return eodReportTimestamp;
	}

	public void setEodReportTimestamp(Date eodReportTimestamp) {
		this.eodReportTimestamp = eodReportTimestamp;
	}

	public Date getCobDate() {
		return cobDate;
	}

	public void setCobDate(Date cobDate) {
		this.cobDate = cobDate;
	}

	public String getRegRepMessageId()
	{
		return regRepMessageId;
	}

	public void setRegRepMessageId(String regRepMessageId)
	{
		this.regRepMessageId = regRepMessageId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((asOfDate == null) ? 0 : asOfDate.hashCode());
		result = prime * result
				+ ((assetClass == null) ? 0 : assetClass.hashCode());
		result = prime * result + ((cobDate == null) ? 0 : cobDate.hashCode());
		result = prime * result
				+ ((eodReportId == null) ? 0 : eodReportId.hashCode());
		result = prime
				* result
				+ ((eodReportTimestamp == null) ? 0 : eodReportTimestamp
						.hashCode());
		result = prime * result
				+ ((eventType == null) ? 0 : eventType.hashCode());
		result = prime * result
				+ ((insertTimestamp == null) ? 0 : insertTimestamp.hashCode());
		result = prime * result
				+ ((jurisdiction == null) ? 0 : jurisdiction.hashCode());
		result = prime * result
				+ ((regRepMessageId == null) ? 0 : regRepMessageId.hashCode());
		result = prime * result
				+ ((reportType == null) ? 0 : reportType.hashCode());
		result = prime * result
				+ ((sdrReport == null) ? 0 : sdrReport.hashCode());
		result = prime * result
				+ ((sdrResponse == null) ? 0 : sdrResponse.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((submissionId == null) ? 0 : submissionId.hashCode());
		result = prime
				* result
				+ ((submissionTimestamp == null) ? 0 : submissionTimestamp
						.hashCode());
		result = prime * result + ((tradeId == null) ? 0 : tradeId.hashCode());
		result = prime * result
				+ ((tradeUsi == null) ? 0 : tradeUsi.hashCode());
		result = prime * result
				+ ((tradeUti == null) ? 0 : tradeUti.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegRepEodSubmission other = (RegRepEodSubmission) obj;
		if (asOfDate == null) {
			if (other.asOfDate != null)
				return false;
		} else if (!asOfDate.equals(other.asOfDate))
			return false;
		if (assetClass == null) {
			if (other.assetClass != null)
				return false;
		} else if (!assetClass.equals(other.assetClass))
			return false;
		if (cobDate == null) {
			if (other.cobDate != null)
				return false;
		} else if (!cobDate.equals(other.cobDate))
			return false;
		if (eodReportId == null) {
			if (other.eodReportId != null)
				return false;
		} else if (!eodReportId.equals(other.eodReportId))
			return false;
		if (eodReportTimestamp == null) {
			if (other.eodReportTimestamp != null)
				return false;
		} else if (!eodReportTimestamp.equals(other.eodReportTimestamp))
			return false;
		if (eventType == null) {
			if (other.eventType != null)
				return false;
		} else if (!eventType.equals(other.eventType))
			return false;
		if (insertTimestamp == null) {
			if (other.insertTimestamp != null)
				return false;
		} else if (!insertTimestamp.equals(other.insertTimestamp))
			return false;
		if (jurisdiction == null) {
			if (other.jurisdiction != null)
				return false;
		} else if (!jurisdiction.equals(other.jurisdiction))
			return false;
		if (regRepMessageId == null) {
			if (other.regRepMessageId != null)
				return false;
		} else if (!regRepMessageId.equals(other.regRepMessageId))
			return false;
		if (reportType == null) {
			if (other.reportType != null)
				return false;
		} else if (!reportType.equals(other.reportType))
			return false;
		if (sdrReport == null) {
			if (other.sdrReport != null)
				return false;
		} else if (!sdrReport.equals(other.sdrReport))
			return false;
		if (sdrResponse == null) {
			if (other.sdrResponse != null)
				return false;
		} else if (!sdrResponse.equals(other.sdrResponse))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (submissionId == null) {
			if (other.submissionId != null)
				return false;
		} else if (!submissionId.equals(other.submissionId))
			return false;
		if (submissionTimestamp == null) {
			if (other.submissionTimestamp != null)
				return false;
		} else if (!submissionTimestamp.equals(other.submissionTimestamp))
			return false;
		if (tradeId == null) {
			if (other.tradeId != null)
				return false;
		} else if (!tradeId.equals(other.tradeId))
			return false;
		if (tradeUsi == null) {
			if (other.tradeUsi != null)
				return false;
		} else if (!tradeUsi.equals(other.tradeUsi))
			return false;
		if (tradeUti == null) {
			if (other.tradeUti != null)
				return false;
		} else if (!tradeUti.equals(other.tradeUti))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RegRepEodSubmission [eodReportId=" + eodReportId
				+ ", sdrReport=" + sdrReport 
				+ ", sdrResponse=" + sdrResponse + ", status=" + status
				+ ", asOfDate=" + asOfDate 
				+ ", cobDate=" + cobDate + ", insertTimestamp="
				+ insertTimestamp + ", submissionTimestamp=" + submissionTimestamp +"]";
	}

}
