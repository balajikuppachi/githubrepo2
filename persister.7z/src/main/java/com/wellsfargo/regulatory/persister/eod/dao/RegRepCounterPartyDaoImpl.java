package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.dto.RegRepParty;
/**
 * 
 * @author Raji Komatreddy
 *
 */

@Component
public class RegRepCounterPartyDaoImpl implements RowMapper<RegRepParty>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	String selectCptyInfo = "select rp.REG_REP_PARTY_ID, rp.REG_REP_MESSAGE_ID, rp.PARTY_NAME, rp.ADDRESS1,"
			               + " rp.ADDRESS2,  rp.CITY, rp.STATE, rp.ZIP, rp.COUNTRY, rp.LEI, rp.LEI_PREFIX, rp.LEI_VALUE, "
			               + "rp.DESIGNATION, rp.US_PERSON, rp.EMIR_TAXANOMY from REG_REP_PARTY rp, REG_REP_MESSAGE rm "
			               + "	where rm.REG_REP_MESSAGE_ID = rp.REG_REP_MESSAGE_ID and rm.MESSAGE_TYPE = 'SDR_TRADE' "
			               + " and rm.SWAP_TRADE_ID = ? and rp.LEI = ?	order by rm.REG_REP_MESSAGE_TIMESTAMP desc";
	
	public List<RegRepParty> getCptyInfo(String tradeId, String cptyLei)
	{
		List<RegRepParty> regRepPartyList = null;
		regRepPartyList = jdbcTemplate.query(selectCptyInfo, new Object [] {tradeId, cptyLei}, this);
		
		return regRepPartyList;
		
	}

	@Override
    public RegRepParty mapRow(ResultSet rs, int rowNum) throws SQLException
    {
		RegRepParty currRegRepParty = new RegRepParty();
		  currRegRepParty.setPartyName(rs.getString("PARTY_NAME"));
		  currRegRepParty.setAddress1(rs.getString("ADDRESS1"));
		  currRegRepParty.setAddress2(rs.getString("ADDRESS2"));
		  currRegRepParty.setCity(rs.getString("CITY"));
		  currRegRepParty.setState(rs.getString("STATE"));
		  currRegRepParty.setZip(rs.getString("ZIP"));
		  currRegRepParty.setLei(rs.getString("LEI"));
		  currRegRepParty.setLeiPrefix(rs.getString("LEI_PREFIX"));
		  currRegRepParty.setLeiValue(rs.getString("LEI_VALUE"));
		  currRegRepParty.setDesignation(rs.getString("DESIGNATION"));
		  currRegRepParty.setUsPerson(rs.getString("US_PERSON"));
		  currRegRepParty.setEmirTaxanomy(rs.getString("EMIR_TAXANOMY"));
		  
	    return currRegRepParty;
    }
	
	

}
