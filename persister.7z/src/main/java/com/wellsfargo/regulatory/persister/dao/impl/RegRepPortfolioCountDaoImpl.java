package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepPortfolioCountDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPortfolioCount;

public class RegRepPortfolioCountDaoImpl extends AbstractDaoImpl<RegRepPortfolioCount> 
									implements RegRepPortfolioCountDao{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3557354097676540318L;

	@Override
	public Class<RegRepPortfolioCount> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepPortfolioCount.class;
	}
	
	@SuppressWarnings("unchecked")
    @Override
    @Transactional
    public RegRepPortfolioCount getPortfolioCountByLeiAndAsset(
			String lei, String assetClass) {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepPortfolioCount result = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepPortfolioCount.GET_COUNT_BY_LEI_AND_ASSET);
			queryObject.setString("lei", lei);
			queryObject.setString("assetClass", assetClass);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				for (Object[] obj: objs)
				{
					result = new RegRepPortfolioCount();
					result.setAssetClass(assetClass);
					result.setCounterpartyDsig((String)obj[0]);
					result.setCounterpartyLei(lei);
					result.setCounterpartyName(null==(String)obj[1] ? "NotAvailable" : (String)obj[1]);
					result.setCountId((Long)obj[2]);
					result.setRegRepCount((Long)obj[3]);				

				}
			}

		}
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);		
		}
		return result;
    }
	
}
