package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepKeywordDao;
import com.wellsfargo.regulatory.persister.dto.RegRepKeyword;

public class RegRepKeywordDaoImpl extends AbstractDaoImpl<RegRepKeyword> implements RegRepKeywordDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8439240107283217376L;

	@Override
	public Class<RegRepKeyword> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepKeyword.class;
	}
	

}
