package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.Date;
import java.util.List;
import java.util.function.Function;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.wellsfargo.regulatory.persister.dao.RegRepExceptionDao;
import com.wellsfargo.regulatory.persister.dto.RegRepException;

public class RegRepExceptionDaoImpl extends AbstractDaoImpl<RegRepException> implements RegRepExceptionDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8903834844036892902L;

	@Override
	public Class<RegRepException> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepException.class;
	}
	


	public Function<Criteria, Criteria> filter(Date start, Date end, List<String> assetClasses, List<String> jurisdictions, boolean orderByTimestamp)
	{
		return criteria -> 
		{
			restrict(criteria, start, end, jurisdictions, assetClasses);
			if (orderByTimestamp)
			{
				criteria.addOrder(Order.asc("regRepExceptionTimestamp"));
			}
			
			return criteria;
		};
	}

	public void restrict(Criteria criteria, Date start, Date end, List<String> jurisdictions, List<String> assetClasses)
	{
		criteria.add(Restrictions.gt("regRepExceptionTimestamp", start)).add(Restrictions.le("regRepExceptionTimestamp", end));
	}
}
