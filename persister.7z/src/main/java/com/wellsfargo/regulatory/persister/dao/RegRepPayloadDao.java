package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepPayload;

public interface RegRepPayloadDao extends Serializable, Dao<RegRepPayload>
{
	
	public RegRepPayload findPayloadByRegRepMessageId(String msgId);

}
