package com.wellsfargo.regulatory.persister.dto.logging.impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.persister.dto.RegRepException;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;
import com.wellsfargo.regulatory.persister.dto.logging.RegRepExceptionDao;

public class RegRepExceptionDaoImpl implements RegRepExceptionDao
{

	// private JdbcTemplate jdbcTemplate;
	//
	// public RegRepExceptionDaoImpl(JdbcTemplate jdbcTemplate) {
	// this.jdbcTemplate = jdbcTemplate;
	// }
	//
	// //@Override
	// public boolean insertRegRepException(RegRepException exceptionObject) {
	// boolean successful = false;
	// String query = QueryMaster.INSERT_REG_REP_EXCEPTION;
	//
	// jdbcTemplate.update(query, new Object[]{exceptionObject.getSdrMessageId(),
	// exceptionObject.getExceptionCode(),
	// exceptionObject.getExceptionDescription(), exceptionObject.getExceptionStatus(),
	// exceptionObject.getExceptionTimestamp(), exceptionObject.getExceptionType(),
	// exceptionObject.getExceptionSeverity()});
	//
	// successful = true;
	//
	// return successful;
	// }
	//
	// //@Override
	// public RegRepException getExceptionsByMessageId(String messageId) {
	// // TODO Auto-generated method stub
	// return null;
	// }

}
