package com.wellsfargo.regulatory.persister.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.persister.recon.dto.RegRepIceOpenTransaction;

/**
 * @author Raji Komatreddy
 */

public class RegRepIceOpenTransactionMapper implements RowMapper<RegRepIceOpenTransaction>
{

	@Override
	public RegRepIceOpenTransaction mapRow(ResultSet resultSet, int rowNum) throws SQLException
	{
		RegRepIceOpenTransaction iceOpenTransaction = new RegRepIceOpenTransaction();

		iceOpenTransaction.setTvProductId(resultSet.getString("tv_product_id"));
		iceOpenTransaction.setTvProductName(resultSet.getString("tv_product_name"));
		iceOpenTransaction.setTradeDate(resultSet.getDate("trade_date").toString());
		iceOpenTransaction.setLifeCycleEventStatus(resultSet.getString("life_cycle_event_status"));
		//iceOpenTransaction.setLifecycleEventTimestamp(resultSet.getDate("lifecycleEvent_timestamp").toString());
		iceOpenTransaction.setBuyer(resultSet.getString("buyer"));
		iceOpenTransaction.setSeller(resultSet.getString("seller"));
		iceOpenTransaction.setBuyerParent(resultSet.getString("buyer_parent"));
		iceOpenTransaction.setSellerParent(resultSet.getString("seller_parent"));
		iceOpenTransaction.setUsReportingEntityPetData(resultSet.getString("us_reporting_entity_petData"));
		iceOpenTransaction.setUsReportingEntityContinuationData(resultSet.getString("us_reporting_entity_continuationData"));
		iceOpenTransaction.setBuyerLei(resultSet.getString("buyer_lei"));
		iceOpenTransaction.setSellerLei(resultSet.getString("seller_lei"));
		iceOpenTransaction.setBuyerSenderTradeRefId(resultSet.getString("buyer_sender_tradeRefId"));
		iceOpenTransaction.setSellerSenderTradeRefId(resultSet.getString("sellerSenderTradeRefId"));
		iceOpenTransaction.setFirstReportedSdr(resultSet.getString("first_reported_sdr"));
		iceOpenTransaction.setUsiUti(resultSet.getString("usi_uti"));
		iceOpenTransaction.setTradeStatus(resultSet.getString("trade_status"));

		return iceOpenTransaction;
	}

}
