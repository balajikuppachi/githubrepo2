package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobExecutionDetails;

/**
 * @author Raji Komatreddy DAO implementation to get data from REG_REP_EOD_JOB_EXECUTION_DETAILS
 */
@Component
public class RegRepEodJobExecutionDetailsDaoImpl implements RowMapper<RegRepEodJobExecutionDetails>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	String insertSql = "INSERT INTO REG_REP_EOD_JOB_EXECUTION_DETAILS " + "(job_details_id,as_of_date,file_name,job_status,records_total,records_loaded,error_details,update_datetime) VALUES "
	        + "(?, ?,?, ?,?,?,?,?)";

	String updateSql = "update REG_REP_EOD_JOB_EXECUTION_DETAILS "
			+ "set job_status = ? , error_details = ?, update_datetime = getutcdate() where job_execution_id = ?";

	@Override
	public RegRepEodJobExecutionDetails mapRow(ResultSet rs, int row) throws SQLException
	{
		RegRepEodJobExecutionDetails currJobExecutionDtls = new RegRepEodJobExecutionDetails();
		currJobExecutionDtls.setJobExecutionId(rs.getLong(1));
		currJobExecutionDtls.setJobDetailsId(rs.getLong(2));
		currJobExecutionDtls.setAsOfDate(rs.getDate(3));
		currJobExecutionDtls.setFileName(rs.getString(4));
		currJobExecutionDtls.setJobStatus(rs.getString(5));
		currJobExecutionDtls.setRecordsTotal(rs.getInt(6));
		currJobExecutionDtls.setRecordsLoaded(rs.getInt(7));
		currJobExecutionDtls.setErrorDetails(rs.getString(8));
		// currJobExecutionDtls.setCreateDatetime(rs.getTimestamp(9));
		currJobExecutionDtls.setUpdateDatetime(rs.getTimestamp(9));

		return currJobExecutionDtls;
	}

	public void insert(RegRepEodJobExecutionDetails jobExecutionDtls)
	{
		jdbcTemplate.update(insertSql,
		        new Object[]
		        { jobExecutionDtls.getJobDetailsId(), jobExecutionDtls.getAsOfDate(), jobExecutionDtls.getFileName(), jobExecutionDtls.getJobStatus(), jobExecutionDtls.getRecordsTotal(),
		                jobExecutionDtls.getRecordsLoaded(), jobExecutionDtls.getErrorDetails(), jobExecutionDtls.getUpdateDatetime() });
	}
	
	

	public long insertandGetId(RegRepEodJobExecutionDetails jobExecutionDtls)
	{
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator()
		{

			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException
			{
				PreparedStatement pst = conn.prepareStatement(insertSql, new String[]
				{ "id" });
				pst.setLong(1, jobExecutionDtls.getJobDetailsId());
				pst.setDate(2, jobExecutionDtls.getAsOfDate());
				pst.setString(3, jobExecutionDtls.getFileName());
				pst.setString(4, jobExecutionDtls.getJobStatus());
				pst.setInt(5, jobExecutionDtls.getRecordsTotal());
				pst.setInt(6, jobExecutionDtls.getRecordsLoaded());
				pst.setString(7, jobExecutionDtls.getErrorDetails());
				pst.setTimestamp(8, jobExecutionDtls.getUpdateDatetime());

				return pst;

			}
		}, keyHolder);
		return (Long) keyHolder.getKey().longValue();

	}
	

	public void update(String jobStatus,String excep, long jobExecutionId)
	{
		jdbcTemplate.update(updateSql,  new Object[]    {jobStatus, excep,  jobExecutionId });
	}

}
