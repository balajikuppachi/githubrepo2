package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;

public class RegRepTradeMapper {

	private static Logger logger = Logger.getLogger(RegRepTradeMapper.class.getName());

	public RegRepTrade createRegRepTrade(ReportingContext context) throws MessagingException
	{
		RegRepTrade trade 			= null;
		Date 		current_date 	= new Date();
		String 		usi 			= null;
		String 		uti 			= null;		
		String 		errorString 	= null;
		String		lce				= null;
		String		status			= null;	
		boolean 	hasExpired		= false;
		boolean 	isCleared		= false;
		String 		tradeType		= null;
		Date 		expiredOn 		= null;
		String      sdrAction       = null;
		
		if (context == null)
		{
			return null;
		}

		SdrRequest sdrReq = context.getSdrRequest();
		lce	 = context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();
		ProductKeysType productKey = sdrReq.getTrade().getTradeDetail().getProduct().getProductKeys();
		TradeHeaderType tradeHeader = sdrReq.getTrade().getTradeHeader();
		status = tradeHeader.getStatus();
		tradeType=ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);
		sdrAction = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.SDR_ACTION_DERIVED_EVENT);

		List<ReportingEligibilityType> reportingEligibility = sdrReq.getTrade().getRegulatory().getReportingEligibility();
		
		if (null == productKey)
		{
			errorString = "Invalid input data. productKey is null. Aborting Trade Object creation";
			logger.error("########## " + errorString);

			throw new MessagingException("productKey", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		usi = StringUtils.trimToEmpty(productKey.getUSI());
		uti = StringUtils.trimToEmpty(productKey.getUTI());

		if (null == usi && null == uti)
		{
			errorString = "Invalid input data. Both USI and UTI is null. Aborting Trade Object creation";
			logger.error("########## " + errorString);

			throw new MessagingException("TrdObj:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		trade = new RegRepTrade();

		trade.setSwapTradeId(StringUtils.trimToEmpty(tradeHeader.getTradeId()));
		trade.setTradeUsi(StringUtils.trimToEmpty(usi));
		trade.setTradeUti(uti);
		trade.setSrcSystemType(StringUtils.trimToEmpty(sdrReq.getSource()));
		
		hasExpired = ReportingDataUtils.hasTradeExpired(lce, status, isCleared,tradeType,sdrAction);
		Map<String,String> reportingDataDetails= ReportingDataUtils.getReportingDataDetails(reportingEligibility);
		if(hasExpired){
            expiredOn = new Date();
			trade.setIsExpired(Constants.APP_TRUE);
		}else{
			
			trade.setIsExpired(Constants.APP_FALSE);
		}		

		trade.setPrevUsi(StringUtils.trimToEmpty(productKey.getPrevUSI()));
		trade.setTradeLatestVersion(StringUtils.trimToEmpty(tradeHeader.getTradeVersion()));
		trade.setRegRepTradeTimestamp(current_date);
		trade.setLatestRegRepMessageId(StringUtils.trimToEmpty(context.getMessageId()));
		trade.setTradeFoStatus(StringUtils.trimToEmpty(tradeHeader.getStatus()));
		trade.setRegRepTradeUpdateTimestamp(current_date);
		
		trade.setLifeCycleEvent(lce);
		trade.setExpiredOn(expiredOn);
		trade.setAssetClass(sdrReq.getAssetClass());
		trade.setJurisdiction(reportingDataDetails.get(Constants.REPORTING_JURISDICTION));
		trade.setReportingParty(reportingDataDetails.get(Constants.REPORTING_PARTY));
		trade.setRepository(reportingDataDetails.get(Constants.REPORTABLE_TO));

		return trade;

	}
}
