package com.wellsfargo.regulatory.persister.exception;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class RegRepEodPersistException extends MessagingException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String description;
	private String submissionId;
	
	public RegRepEodPersistException(String exceptionCode,
			ExceptionSeverityEnum severity, ExceptionTypeEnum type,
			String message) {
		
		super(exceptionCode, severity, type, message);		
	}
	
	
	public RegRepEodPersistException(String exceptionCode,
			ExceptionSeverityEnum severity, ExceptionTypeEnum type,
			String message, Throwable cause) {
	
		super(exceptionCode, severity, type, message, cause);	
	}
	
	public void setDescription(String description){
		
		this.description = description;
	}
	
	public String getDescription(){
		
		return description;
	}
	
	public void setSubmissionId(String submissionId){
		
		this.submissionId = submissionId;
	}
	
	public String getSubmissionId(){
		
		return submissionId;
	}

}
