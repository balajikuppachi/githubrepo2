package com.wellsfargo.regulatory.persister.etd.dao.impl;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.etd.dao.EtdExceptionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdException;

public class EtdExceptionDaoImpl extends AbstractDaoImpl<EtdException> implements EtdExceptionDao
{
	/**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    
    @Override
	public Class<EtdException> getEntityClass()
	{
		return EtdException.class;
	}
	
}
