package com.wellsfargo.regulatory.persister.etd.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdCollateralDtls;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public interface EtdCollateralDtlsDao extends Serializable, Dao<EtdCollateralDtls>
{

}
