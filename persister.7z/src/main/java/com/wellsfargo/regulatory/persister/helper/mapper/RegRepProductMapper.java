package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepEquityTerms;
import com.wellsfargo.regulatory.persister.dto.RegRepExerciseProvision;
import com.wellsfargo.regulatory.persister.dto.RegRepKeyword;
import com.wellsfargo.regulatory.persister.dto.RegRepLeg;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;
import com.wellsfargo.regulatory.persister.dto.RegRepProductKeys;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepProductMapper
{

	private static Logger logger = Logger.getLogger(RegRepProductMapper.class.getName());

	public RegRepProduct createRegRepProduct(ProductType ipProduct, RegRepTradeDetail regRepTradeDetail, String parentProdutType)
	{

		RegRepProduct dbProduct = null;
		List<LegType> ipLegList = null;
		Set<RegRepLeg> dbLegSet = null;
		RegRepLeg dbLeg = null;
		RegRepLegMapper legMapper = null;
		RegRepKeywordMapper keyMapper = null;
		RegRepProductKeys dbPrdkeys = null;
		ProductKeysType ipPrdKeys = null;
		KeywordsType ipKeywordType = null;
		RegRepKeyword dbKey = null;
		Set<RegRepKeyword> dbKeywordSet = null;
		RegRepExerciseProvision dbProvision = null;
		ExerciseProvisionType ipProvision = null;
		RegRepExerciseProvisionMapper provMapper = null;
		EquityTermsType equityTerms  = null;
		RegRepEquityTermsMapper equityTermsMapper = null;
		RegRepEquityTerms  regRepEquityTerms = null;
		String productId = null; 
		int legId = 1;
		int provId = 1;

		if (null == ipProduct || null == regRepTradeDetail)
		{
			logger.debug("RegRepProduct object could not be " + "populated due to invalid incoming data");
			return dbProduct;
		}

		dbProduct = new RegRepProduct();
		dbProduct.setRegRepTradeDetail(regRepTradeDetail);

		productId = ReportingDataUtils.generateMessageId();
		dbProduct.setRegRepProductId(productId);

		ipPrdKeys = ipProduct.getProductKeys();
		dbPrdkeys = createRegRepProductKeys(dbProduct, ipPrdKeys);

		ipLegList = ipProduct.getLeg();
		if (null != ipLegList)
		{

			legMapper = new RegRepLegMapper();
			dbLegSet = new HashSet<RegRepLeg>();

			for (LegType ipLeg : ipLegList)
			{

				dbLeg = legMapper.createRegRepLeg(ipLeg, dbProduct, legId++);
				dbLegSet.add(dbLeg);
			}

		}
		else
		{
			logger.debug("Unable to persist leg details, " + "since incoming data doesn't have leg type populated");
		}

		ipKeywordType = ipProduct.getKeywords();
		if (null != ipKeywordType)
		{

			keyMapper = new RegRepKeywordMapper();
			dbKeywordSet = new HashSet<RegRepKeyword>();

			for (Keyword ipKeyword : ipKeywordType.getKeyword())
			{

				dbKey = keyMapper.createRegRepKeyword(dbProduct, null, null, ipKeyword);
				dbKeywordSet.add(dbKey);
			}

		}
		else
		{
			logger.debug("Unable to persist Product keywords, " + "since incoming data doesn't have product keywords populated");
		}

		/*
		 * ipAmortization = ipProduct.getAmortization(); if(null != ipAmortization){ amoMapper = new
		 * RegRepAmortizationMapper(); dbAmortization =
		 * amoMapper.createRegRepAmortization(dbProduct, ipAmortization); }else{
		 * logger.debug("Unable to persist Ammortization, " +
		 * "since incoming data doesn't have Ammortization details populated"); }
		 */

		ipProvision = ipProduct.getExerciseProvision();
		if (null != ipProvision)
		{

			provMapper = new RegRepExerciseProvisionMapper();
			dbProvision = provMapper.createRegRepExerciseProvision(ipProvision, dbProduct, provId++);

		}
		else
		{
			logger.debug("Unable to persist Exercise Provisions, " + "since incoming data doesn't have Exercise Provisions populated");
		}
		
		equityTerms = ipProduct.getEquityTerms();
		if(null != equityTerms)
		{
			equityTermsMapper = new RegRepEquityTermsMapper();
			regRepEquityTerms = equityTermsMapper.createRegRepEquityTerms(equityTerms, dbProduct);
			
		}
		else
		{
			logger.debug("Unable to persist EquityTerms, " + "since incoming data doesn't have EquityTerms populated");
		}
		

		if (null != ipProduct.getBuySell()) dbProduct.setBuySell(ipProduct.getBuySell().value());

		dbProduct.setProductSubType(ipProduct.getProductSubType());
		dbProduct.setProductType(ipProduct.getProductType());
		// dbProduct.setRegRepAmortization(dbAmortization);
		dbProduct.setRegRepExerciseProvision(dbProvision);
		dbProduct.setRegRepKeywords(dbKeywordSet);
		dbProduct.setRegRepLegs(dbLegSet);
		dbProduct.setRegRepParentProductType(parentProdutType);
		dbProduct.setRegRepProductKeys(dbPrdkeys);
		dbProduct.setRegRepEquityTerms(regRepEquityTerms);
		
		dbProduct.setInstrumentType(ipProduct.getInstrumentType());

		logger.debug("Successfully created REG_REP_PRODUCT object");
		return dbProduct;
	}

	private RegRepProductKeys createRegRepProductKeys(RegRepProduct dbProduct, ProductKeysType produtKey)
	{

		RegRepProductKeys prdKeys = null;

		prdKeys = new RegRepProductKeys();

		if (null == dbProduct || null == produtKey)
		{
			logger.debug("RegRepProductKeys object could not be " + "populated due to invalid incoming data");
			return prdKeys;
		}

		prdKeys.setRegRepProduct(dbProduct);

		prdKeys.setPrevUsi(produtKey.getPrevUSI());
		// prdKeys.setRegRepProductId(dbProduct.getRegRepTradeDetail().getRegRepSdrRequest().getRegRepMessage().getRegRepMessageId());
		prdKeys.setUpi(produtKey.getUPI());
		prdKeys.setUsi(produtKey.getUSI());
		prdKeys.setUti(produtKey.getUTI());

		return prdKeys;

	}

}
