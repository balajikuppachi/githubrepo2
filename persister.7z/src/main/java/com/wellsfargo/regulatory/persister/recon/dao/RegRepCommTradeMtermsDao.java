package com.wellsfargo.regulatory.persister.recon.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;

public interface RegRepCommTradeMtermsDao  extends Serializable, Dao<RegRepCommTradeMterms>
{

	public int springBatchInsert(final List<RegRepCommTradeMterms> regRepCommTradeMtermsList);
	
	public Long getCountofTransactions(Date reportDate, String sourceSystem);
	public Long getCntOfMatchedTransactions(Date reportDate, String sourceSystem, Date reportDate1,String CompareSourceSystem );
	public List<RegRepCommTradeMterms> getMatchedTransactions(Date reportDate, String sourceSystem, Date reportDate1,String CompareSourceSystem );
	public List<RegRepCommTradeMterms> getUnMatchedTransactions(Date reportDate, String sourceSystem, Date reportDate1,String CompareSourceSystem );
}
