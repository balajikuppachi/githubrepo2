package com.wellsfargo.regulatory.persister.rowMapper;

public class RegRepEodInsertRefreshMessage {
	
	private String messageId;
	
	private String payload;

	private String tradeId ;

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	
	
}
