package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepDocumentationDao;
import com.wellsfargo.regulatory.persister.dto.RegRepDocumentation;

public class RegRepDocumentationDaoImpl extends AbstractDaoImpl<RegRepDocumentation> implements RegRepDocumentationDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1951867558392343150L;

	@Override
	public Class<RegRepDocumentation> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepDocumentation.class;
	}



}
