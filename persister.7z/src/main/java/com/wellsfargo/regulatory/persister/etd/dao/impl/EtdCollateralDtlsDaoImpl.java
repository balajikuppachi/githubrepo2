package com.wellsfargo.regulatory.persister.etd.dao.impl;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.etd.dao.EtdCollateralDtlsDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdCollateralDtls;

public class EtdCollateralDtlsDaoImpl extends AbstractDaoImpl<EtdCollateralDtls> implements EtdCollateralDtlsDao
{

	
    private static final long serialVersionUID = 1L;
	@Override
    public Class<EtdCollateralDtls> getEntityClass()
    {
	    // TODO Auto-generated method stub
	    return null;
    }


}
