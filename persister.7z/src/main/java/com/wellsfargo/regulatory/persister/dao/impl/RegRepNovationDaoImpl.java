package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepNovationDao;
import com.wellsfargo.regulatory.persister.dto.RegRepNovation;

public class RegRepNovationDaoImpl extends AbstractDaoImpl<RegRepNovation> implements RegRepNovationDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2247472361387977382L;

	@Override
	public Class<RegRepNovation> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepNovation.class;
	}


}
