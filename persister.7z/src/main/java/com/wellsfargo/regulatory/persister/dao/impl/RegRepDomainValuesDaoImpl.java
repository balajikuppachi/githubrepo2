package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepDomainValuesDao;
import com.wellsfargo.regulatory.persister.dto.RegRepDomainValues;

public class RegRepDomainValuesDaoImpl extends AbstractDaoImpl<RegRepDomainValues> implements RegRepDomainValuesDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7459829006588673460L;

	@Override
	public Class<RegRepDomainValues> getEntityClass()
	{
		return RegRepDomainValues.class;
	}



}
