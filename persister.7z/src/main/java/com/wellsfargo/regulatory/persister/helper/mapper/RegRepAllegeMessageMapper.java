package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse;
import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepAllegeMessage;

/**
 * @author Raji Komatreddy
 *  helper class to populate AllegeMessage details from EOD responses
 */

@Component
public class RegRepAllegeMessageMapper
{
	private static Logger logger = Logger.getLogger(RegRepAllegeMessageMapper.class.getName());

	public RegRepAllegeMessage createRegRepAllegeMessage(ReportingContext reportingContext)
	{
		logger.debug("inside RegRepAllegeMessageMapper method");

		String sentBy = null;
		String srcMsgid = null;
		String sendTo = null;
		String status = null;
		Element originalMessage = null;
		String responseString = null;
		FpMLResponse fpMLResponse = null;
		String jurisdiction = null;
		String usiPrefix = null;
		String usi = null;
		String tradeID = null;
		String party1Lei = null;
		String party1Name = null;
		String party1Address = null;
		String party2Lei = null;
		String party2Name = null;
		String party2Address = null;
		String assetClass = null;

		fpMLResponse = reportingContext.getResponse();

		if (null == fpMLResponse)
		{
			logger.error("######### Response object is null. Returning....");
			return null;
		}

		RegRepAllegeMessage currRegRepAllegeMessage = new RegRepAllegeMessage();

		srcMsgid = fpMLResponse.getInReplyTo();
		if (null != fpMLResponse.getSendTo() && fpMLResponse.getSendTo().size() > 0) sendTo = fpMLResponse.getSendTo().get(0);

		sentBy = fpMLResponse.getSentBy();
		responseString = reportingContext.getPayload();

		if (PayloadTypeEnum.SDR_RESPONSE_ACK.equals(reportingContext.getContextType()))
		{
			status = Constants.DTCC_RESPONSE_ACK;
		}
		else if (PayloadTypeEnum.SDR_RESPONSE_NACK.equals(reportingContext.getContextType()))
		{
			/*** With-in NACK block checking for Warning status of EOD submission(s) ***/
			if (StringUtils.contains(StringUtils.trimToEmpty(responseString), ">WARNING</validation>"))
			{
				status = Constants.MSG_STATUS_WACK;
			}
			else status = Constants.DTCC_RESPONSE_NACK;
		}

		// persist allege message
		originalMessage = fpMLResponse.getOriginalMessage();
		
		//snapshot message parsing
		if (null != originalMessage && !StringUtils.equalsIgnoreCase(originalMessage.getNodeName(), Constants.VALUATION_REPORT))
		{

			currRegRepAllegeMessage.setReportType(Constants.MESSAGE_TYPE_SNAPSHOT);
			NodeList nodeList = originalMessage.getChildNodes();
			for (int i = 0; i < nodeList.getLength(); i++)
			{
				try
				{

					Node currNode = nodeList.item(i);
					// extract trade related information
					if (null != currNode && StringUtils.equalsIgnoreCase(currNode.getNodeName(), "trade"))
					{
						Element tradeElement = (Element) currNode;
						NodeList tradeList = tradeElement.getChildNodes();
						for (int t = 0; t < tradeList.getLength(); t++)
						{
							Node tradeNode = tradeList.item(t);
							if (StringUtils.equalsIgnoreCase(tradeNode.getNodeName(), "tradeHeader"))
							{
								Element tradeHeaderElement = (Element) tradeNode;
								NodeList tradeHeaderList = tradeHeaderElement.getChildNodes();
								for (int th = 0; th < tradeHeaderList.getLength(); th++)
								{
									try
									{

										Node tradeHeaderNode = tradeHeaderList.item(th);
										if (StringUtils.equalsIgnoreCase(tradeHeaderNode.getNodeName(), "partyTradeIdentifier"))
										{
											Element partyTradeIdentifierElement = (Element) tradeHeaderNode;
											NodeList partyTradeIdentifierList = partyTradeIdentifierElement.getChildNodes();
											for (int pt = 0; pt < partyTradeIdentifierList.getLength(); pt++)
											{
												try
												{

													Node partyTradeIdentifierNode = partyTradeIdentifierList.item(pt);

													if (StringUtils.equalsIgnoreCase(partyTradeIdentifierNode.getNodeName(), "issuer")) usiPrefix = getElementValue(partyTradeIdentifierNode);

													if (StringUtils.equalsIgnoreCase(partyTradeIdentifierNode.getNodeName(), "tradeId"))
													{
														Element tradeIdElement = (Element) partyTradeIdentifierNode;
														if (StringUtils.equalsIgnoreCase(tradeIdElement.getAttribute("tradeIdScheme"), "http://www.dtcc.com/internal_Referenceid"))
														{
															tradeID = getElementValue(partyTradeIdentifierNode);
														}
														else if (StringUtils.equalsIgnoreCase(tradeIdElement.getAttribute("tradeIdScheme"),
														        "http://www.fpml.org/coding-scheme/external/unique-transaction-identifier"))
														{
															usi = getElementValue(partyTradeIdentifierNode);
														}
													}
												}
												catch (Exception ex)
												{
													logger.info("Allege Message received from third party : " + originalMessage);
													logger.error("Exception occurred while parsing partyTradeIdentifier element part of response " + ex.getMessage());
												}

											}

										} // end of partyTradeIdentifier block
									}
									catch (Exception ex)
									{
										logger.error("Exception occurred while parsing tradeHeader element part of response " + ex.getMessage());
									}

								}

							} // end of tradeHeader block

						}
					}

					// extract Party related information
					if (null != currNode && StringUtils.equalsIgnoreCase(currNode.getNodeName(), "party"))
					{
						Element partyElement = (Element) currNode;
						String city = null;
						String state = null;
						String country = null;
						String postalcode = null;
						if (StringUtils.equalsIgnoreCase(partyElement.getAttribute("id"), "Party1"))
						{
							NodeList part1List = partyElement.getChildNodes();
							for (int j = 0; j < part1List.getLength(); j++)
							{
								Node party1Node = part1List.item(j);
								if (StringUtils.equalsIgnoreCase(party1Node.getNodeName(), "partyId"))
									{
									      if(null ==party1Lei)
									    	  party1Lei = getElementValue(party1Node);
									}

								if (StringUtils.equalsIgnoreCase(party1Node.getNodeName(), "partyName")) party1Name = getElementValue(party1Node);

								if (StringUtils.equalsIgnoreCase(party1Node.getNodeName(), "contactInfo"))
								{
									Element contactInfoElement = (Element) party1Node;
									NodeList contactInfoList = contactInfoElement.getChildNodes();
									for (int cl = 0; cl < contactInfoList.getLength(); cl++)
									{
										Node addressNode = contactInfoList.item(cl);
										if (StringUtils.equalsIgnoreCase(addressNode.getNodeName(), "address"))
										{
											Element addressElement = (Element) addressNode;
											NodeList addressElementList = addressElement.getChildNodes();
											for (int ci = 0; ci < addressElementList.getLength(); ci++)
											{
												Node addressDtlsNode = addressElementList.item(ci);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "city")) city = getElementValue(addressDtlsNode);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "state")) state = getElementValue(addressDtlsNode);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "country")) country = getElementValue(addressDtlsNode);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "postalCode")) postalcode = getElementValue(addressDtlsNode);

											}

										}

									}

									party1Address = city + " " + state + " " + country + " " + postalcode;

								}

							}

						}

						if (StringUtils.equalsIgnoreCase(partyElement.getAttribute("id"), "Party2"))
						{
							NodeList part2List = partyElement.getChildNodes();
							for (int k = 0; k < part2List.getLength(); k++)
							{
								Node party2Node = part2List.item(k);
								if (StringUtils.equalsIgnoreCase(party2Node.getNodeName(), "partyId")) 
								{
									if(null == party2Lei)
									   party2Lei = getElementValue(party2Node);
								}
									

								if (StringUtils.equalsIgnoreCase(party2Node.getNodeName(), "partyName")) party2Name = getElementValue(party2Node);

								if (StringUtils.equalsIgnoreCase(party2Node.getNodeName(), "contactInfo"))
								{
									Element contactInfoElement = (Element) party2Node;
									NodeList contactInfoList = contactInfoElement.getChildNodes();
									for (int cl = 0; cl < contactInfoList.getLength(); cl++)
									{
										Node addressNode = contactInfoList.item(cl);
										if (StringUtils.equalsIgnoreCase(addressNode.getNodeName(), "address"))
										{
											Element addressElement = (Element) addressNode;
											NodeList addressElementList = addressElement.getChildNodes();
											for (int ci = 0; ci < addressElementList.getLength(); ci++)
											{
												Node addressDtlsNode = addressElementList.item(ci);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "city")) city = getElementValue(addressDtlsNode);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "state")) state = getElementValue(addressDtlsNode);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "country")) country = getElementValue(addressDtlsNode);

												if (StringUtils.equalsIgnoreCase(addressDtlsNode.getNodeName(), "postalCode")) postalcode = getElementValue(addressDtlsNode);

											}

										}

									}

									party2Address = city + " " + state + " " + country + " " + postalcode;

								}

							}

						}

					}// end of party block
				}
				catch (Exception ex)
				{
					logger.info("Allege Message received from third party : " + originalMessage);
					logger.error("Exception occurred while parsing allege Snapshot response " + ex.getMessage());
				}

			}

		}
		else if (null != originalMessage)
		{
			// response could be for valuation
			try
			{
				currRegRepAllegeMessage.setReportType(Constants.MESSAGE_TYPE_VALUATION);
				NodeList nodeList = originalMessage.getChildNodes();
				for (int i = 0; i < nodeList.getLength(); i++)
				{

					Node currNode = nodeList.item(i);
					// extract trade related information
					if (null != currNode && StringUtils.equalsIgnoreCase(currNode.getNodeName(), "reportContents"))
					{
						Element reportContentsElement = (Element) currNode;
						NodeList reportContentsList = reportContentsElement.getChildNodes();

						for (int rc = 0; rc < reportContentsList.getLength(); rc++)
						{
							Node assetClassNode = reportContentsList.item(rc);
							if (StringUtils.equalsIgnoreCase(assetClassNode.getNodeName(), "primaryAssetClass")) 
								assetClass = getElementValue(assetClassNode);

						}

					} // end of reportContents section
					if (null != currNode && StringUtils.equalsIgnoreCase(currNode.getNodeName(), "party"))
					{
						Element partyElement = (Element) currNode;
						if (StringUtils.equalsIgnoreCase(partyElement.getAttribute("id"), "Party1"))
						{
							NodeList part1List = partyElement.getChildNodes();
							for (int pt = 0; pt < part1List.getLength(); pt++)
							{
								Node party1IdNode = part1List.item(pt);
								if (StringUtils.equalsIgnoreCase(party1IdNode.getNodeName(), "partyId"))
									party1Lei = getElementValue(party1IdNode);

								if (StringUtils.equalsIgnoreCase(party1IdNode.getNodeName(), "partyName"))
									party1Name = getElementValue(party1IdNode);

							}

						}

						if (StringUtils.equalsIgnoreCase(partyElement.getAttribute("id"), "Party2"))
						{
							NodeList part2List = partyElement.getChildNodes();
							for (int pt = 0; pt < part2List.getLength(); pt++)
							{
								Node party12dNode = part2List.item(pt);
								if (StringUtils.equalsIgnoreCase(party12dNode.getNodeName(), "partyId"))
									party2Lei = getElementValue(party12dNode);

								if (StringUtils.equalsIgnoreCase(party12dNode.getNodeName(), "partyName")) 
									party2Name = getElementValue(party12dNode);

							}

						}

					} // end of Party section

					if (null != currNode && StringUtils.equalsIgnoreCase(currNode.getNodeName(), "tradeValuationItem"))
					{
						Element tradeValuationItemElement = (Element) currNode;
						NodeList tradeValuationList = tradeValuationItemElement.getChildNodes();

						for (int tv = 0; tv < tradeValuationList.getLength(); tv++)
						{
							Node tradeNode = tradeValuationList.item(tv);
							if (StringUtils.equalsIgnoreCase(tradeNode.getNodeName(), "trade"))
							{
								Element tradeElement = (Element) tradeNode;
								NodeList tradeList = tradeElement.getChildNodes();

								for (int tr = 0; tr < tradeList.getLength(); tr++)
								{
									
									Node tradeHeader = tradeList.item(tr);
									if (StringUtils.equalsIgnoreCase(tradeHeader.getNodeName(), "tradeHeader"))
									{
										Element partyIdentifierElement = (Element) tradeHeader;
										NodeList partyIdentifierList = partyIdentifierElement.getChildNodes();

										for (int pi = 0; pi < partyIdentifierList.getLength(); pi++)
										{
											Node partyIdentifierNode = partyIdentifierList.item(pi);
											if (StringUtils.equalsIgnoreCase(partyIdentifierNode.getNodeName(), "partyTradeIdentifier"))
											{
												Element issuerElement = (Element) partyIdentifierNode;
												NodeList issuerList = issuerElement.getChildNodes();
												
												for (int il = 0; il < issuerList.getLength(); il++)
												{
													Node issuerNode = issuerList.item(il);
													if (StringUtils.equalsIgnoreCase(issuerNode.getNodeName(), "issuer"))
													{
														usiPrefix = getElementValue(issuerNode);

													}
													if (StringUtils.equalsIgnoreCase(issuerNode.getNodeName(), "tradeId"))
													{
														usi = getElementValue(issuerNode);

													}
													
												}
												
												
												
											}											
																	

										}

									}

								}

							}

						}

					} // end of tradeValuationItem section

				}

			}
			catch (Exception ex)
			{
				logger.info("Allege Message received from third party : " + originalMessage);
				logger.error("Exception occurred while parsing allege valuation response " + ex.getMessage());
			}

		}

		currRegRepAllegeMessage.setInreplyto(srcMsgid);
		currRegRepAllegeMessage.setSentBy(sentBy);
		currRegRepAllegeMessage.setSentTo(sendTo);
		currRegRepAllegeMessage.setStatus(status);
		currRegRepAllegeMessage.setJurisdiction(jurisdiction);
		currRegRepAllegeMessage.setUsiPrefix(usiPrefix);
		currRegRepAllegeMessage.setUsi(usi);
		currRegRepAllegeMessage.setTradeID(tradeID);
		currRegRepAllegeMessage.setParty1Lei(party1Lei);
		currRegRepAllegeMessage.setParty1Name(party1Name);
		currRegRepAllegeMessage.setParty1Address(party1Address);
		currRegRepAllegeMessage.setParty2Lei(party2Lei);
		currRegRepAllegeMessage.setParty2Name(party2Name);
		currRegRepAllegeMessage.setParty2Address(party2Address);

		logger.debug("exiting RegRepAllegeMessageMapper method");
		return currRegRepAllegeMessage;

	}

	private String getElementValue(Node node)
	{
		String elementValue = null;
		Element partyIdElement = (Element) node;
		elementValue = partyIdElement.getTextContent();

		return elementValue;

	}

}
