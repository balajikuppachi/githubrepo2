package com.wellsfargo.regulatory.persister.main;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodPayloadDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodPayload;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodReport;

/**
 * @author 	Amit Rana
 * @date 	06/24/2015
 * @version 1.0
 */

public class EodDriver 
{
	private static Logger logger = Logger.getLogger(EodDriver.class.getName());

	@Value("${regRep.wf.cme.leis}")
	private  String cmeClearedLeis; 
	

	
	@Autowired
	private EodPersistenceDriver eodPersistenceDriver;

	@Autowired
	private RegRepEodPayloadDaoImpl regRepEodPayloadDaoImpl;

	public static final Pattern messageIdPattern= Pattern.compile("<messageId messageIdScheme=\"http://www.wellsfargo.com/msg_id\">.*?</messageId>", Pattern.DOTALL);
	
	public void persist(ReportingContext context) 
	{
		logger.debug("Entering persist method");
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.EodDriver);

		boolean success 			= false;
		String jurisdiction 		= null;
		String srcMsgid 			= null;
		boolean isActiveStatus 		= true;
		String reportType 			= null;
		String eodRefreshRptType	= null;
		String  eodRefreshJurisdiction = null;
		
		if(null == context)
		{
			logger.error("######### Null context recieved.");
			return;
		}		

		try
		{
			if (! GeneralUtils.IsListNullOrEmpty(context.getReportTypes()))
			{
				reportType = context.getReportTypes().iterator().next();	
			}
			
			srcMsgid = context.getSrcMessageId();
			jurisdiction = StringUtils.join(context.getCurrJurisdiction(), Constants.COMMA);
			
			if (jurisdiction!=null)
			jurisdiction=jurisdiction.contains(Constants.JURISDICTION_CANADA_SHORT)?Constants.JURISDICTION_CAD:jurisdiction;
			
			RegRepEodReport regRepEodReportDto = prepareDtoFromContext(context, jurisdiction, reportType);		

				
			if (context.isEodValuationRefresh())
			{
				if (reportType == null || jurisdiction == null)
				{
					logger.info(" >>>>>>>>> ReportType / Jurisdiction is empty. No reports will be generated <<<<<<<<< ");
					return;
				}
					
				if (! eodPersistenceDriver.isValuationExist(context, regRepEodReportDto))
				{
					/*** Inserting a new record in the EOD Report table ***/
					success = eodPersistenceDriver.insertRegRepEodReport(context, isActiveStatus, regRepEodReportDto);
	
					if(success)
					/*** Inserting the corresponding record in the EOD payload table ***/
					success = eodPersistenceDriver.insertRegRepEodPayload(context, regRepEodReportDto);
				}
				
			} 
			else if (context.isEodRefresh())
			{
				
				eodRefreshRptType = context.getEodRefreshRptType();
				eodRefreshJurisdiction = context.getEodRefreshJurisdiction();
				
				if ( reportType!= null && eodRefreshRptType!=null && eodRefreshRptType.equals(reportType) &&
						jurisdiction!= null && eodRefreshJurisdiction!=null && jurisdiction.equals(eodRefreshJurisdiction))
				{
					StringBuffer newPayload = new StringBuffer();
				    try 
				    {
				    	 /**Update messageID**/
					    Matcher messId = messageIdPattern.matcher(context.getPayload());
					    if(messId.find()) 
					    {
					    	
					    	 String messIdPath = messId.group();
					    	 messIdPath = messIdPath.replaceFirst("<messageId messageIdScheme=\"http://www.wellsfargo.com/msg_id\">.*</messageId>",
					    			 "<messageId messageIdScheme=\"http://www.wellsfargo.com/msg_id\">"+context.getEodRefreshRptId()+"</messageId>");
					    	 messId.appendReplacement(newPayload, messIdPath);
					    }
					    
					    messId.appendTail(newPayload);
					    
					    context.setPayload(newPayload.toString());
				    }
				    catch (Exception e) 
				    {
				    	logger.error("Exception while updating the EOD refresh payload", e);
					}
					success = eodPersistenceDriver.updateRegRepEodPayloadForRefresh(context);
					
					
				}
			else
					return;
			}
			else if (!context.isReportingParty() )
			{				
				 // make the previous events as buffer ineligible 				 
				success = updateRegRepEodReportBufferIneligible(context,regRepEodReportDto);
			}
			else if( context.isCleared() && Constants.MESSAGE_TYPE_SNAPSHOT.equals(reportType))
			{
				//make previous snapshot ingligible
				success = updateBufferIneligibleForSnapShot(context,regRepEodReportDto);
			}
			else
			{					
					/*** Checking if a previous active event exists for the same tradeid ***/ 
					success 	= updateRegRepEodReportActiveFlag(context, regRepEodReportDto);							

				if(success)
					/*** Inserting a new record in the EOD Report table ***/
					success = eodPersistenceDriver.insertRegRepEodReport(context, isActiveStatus, regRepEodReportDto);
	
				if(success)
					/*** Inserting the corresponding record in the EOD payload table ***/
					success = eodPersistenceDriver.insertRegRepEodPayload(context, regRepEodReportDto);			
	
				if(Constants.Cancel.equals(regRepEodReportDto.getActionType()))
				{
					if(success)				
						/*** Explicit handling of cancel trades ***/				
						success = eodPersistenceDriver.updateLastActive(context, regRepEodReportDto);							
		
					if(success)				
						/*** Explicit handling of cancel trades ***/				
						success = eodPersistenceDriver.turnOffTodayCancel(context, regRepEodReportDto);				
				}	
			}

			
		}
		catch(Exception e)
		{
			logger.error("Error while persisting in to REG_REP_EOD_PAYLOAD or REG_REP_EOD_REPORT the message id : "+srcMsgid,e);
			success=false;
		}
	
		if(success)
			logger.info("Sucessfully persisted EOD record for "+context.getReportTypes());

		logger.debug("Exiting persist method");
	}

	
	
	private boolean updateRegRepEodReportActiveFlag(ReportingContext context, RegRepEodReport regRepEodReportDto)
	{
		logger.info("Entering updateRegRepEodReportActiveFlag method");
		
		boolean	success 	= false;
		KeywordsType keywordsType        = null;
		String sdrAction                 = null;
		String eventType            = null;
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.EodDriver);
		keywordsType = context.getSdrRequest().getTrade().getRegulatory().getKeywords();
		sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);
		
		eventType = context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();
		
		//usi uti unlock scenario, do not update previous entries in case SDR_Action_New as sdrAction - this is 
		// duplicate entry we are making in EodReport table to persist both exit and new messages for Snapshot message
		
		// incase of Equity USI Change lifecycle event - don not deactivate previous exit message
	    
	    	
		if(StringUtils.equalsIgnoreCase(sdrAction, Constants.SDR_ACTION_NEW) || StringUtils.equalsIgnoreCase(eventType, Constants.EVENT_TYPE_USI_CHANGE))
		{
			success = true;			
		}			
		else if(Constants.Cancel.equals(regRepEodReportDto.getActionType()))
		{
			/***This is the case where we make both previouse SS/VAL as not eligible for the UNDO cases - Since we are generating only SS for UNDO*/			
			success = eodPersistenceDriver.updateEodActiveFlag(context, regRepEodReportDto,false);	
		}else 
		{	/**Normal previous version trade update*/			
			success = eodPersistenceDriver.updateEodActiveFlag(context, regRepEodReportDto,true);	
		}
	
			return success;
	}

	
	private boolean updateRegRepEodReportBufferIneligible(ReportingContext context,RegRepEodReport dto)
	{
		boolean	success 	= false;
		logger.info("Entering updateRegRepEodReportBufferIneligible method");
		
		success = eodPersistenceDriver.updateEodBufferIneligible(context, dto);
		
		return success;
		
	}
	
	private boolean updateBufferIneligibleForSnapShot(ReportingContext context,RegRepEodReport dto)
	{
		boolean	success 	= false;
		logger.info("Entering updateBufferIneligibleForSnapShot method");
		
		success = eodPersistenceDriver.updateEodBufferIneligibleForSnapshot(context, dto);
		
		return success;
		
	}
	
	
	public void persistEodResponse(ReportingContext context) 
	{
		logger.info("Entering persistEodResponse method");
		
		if(context!= null)
		{
			logger.info("PersistEodResponse for message id : "+context.getMessageId());
			AbstractDriver.setMDCInfo(context, AbstractDriver.EodDriver);
			//	persist EodSubmission Response into EodSubmissionResponse and EodException tables
			eodPersistenceDriver.insertRegRepEodSubmissionResponse(context);
		}

	}

	public List<RegRepEodPayload>  findEodMsgByTradeIdAndReportType(String tradeId, String reportType,  String jurisdiction)
    {
		logger.debug("Entering findEodMsgByTradeIdAndReportType method");
		List<RegRepEodPayload> lastReportedBuffer=null;
		
		try
		{ 
			
			RegRepEodReport regRepEodReport=new RegRepEodReport();
			regRepEodReport.setSwapTradeId(tradeId);
			regRepEodReport.setReportType(reportType);
			regRepEodReport.setJurisdiction(jurisdiction);
			
			lastReportedBuffer = regRepEodPayloadDaoImpl.getLastReportedBuffer(regRepEodReport);
		}
		catch(Exception ex)
		{
			logger.error(" ################### ERROR While retrieving previous record from  REG_REP_EOD_REPORT  & REG_REP_EOD_PAYLOAD for tradeId :  \n" + tradeId);
			logger.error("Error While retrieving record from  REG_REP_EOD_REPORT  & REG_REP_EOD_PAYLOAD since ",ex);
			
		}
		
		return lastReportedBuffer;

	}
	
	
	private RegRepEodReport prepareDtoFromContext(ReportingContext context,	String jurisdiction, String reportType) throws MessagingException 
	{
		RegRepEodReport dto=new RegRepEodReport();
		dto.setEodReportId(context.getMessageId());
		dto.setSwapTradeId(context.getSwapTradeId());
		dto.setAssetClass(context.getAssetClass());
		
		if (ReportingDataUtils.isCMEClearing(context,cmeClearedLeis)){
			dto.setJurisdiction(Constants.JURISDICTION_CFTC + Constants.KEY_SEPERATOR+Constants.CME);
		} else {
			dto.setJurisdiction(jurisdiction);
		}dto.setReportType(reportType);
		dto.setActionType(context.getSdrRequest().getTrade().getTradeHeader().getAction());
		dto.setEvntType(context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType());
		dto.setTradeStatus(context.getSdrRequest().getTrade().getTradeHeader().getStatus());
		dto.setSrcMessageId(context.getSrcMessageId());
		dto.setIsBufferEligible(1);
		return dto;
	}

}
