package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepOrigPayload;

public class RegRepOrigPayloadMapper {
	
	private static Logger logger = Logger.getLogger(RegRepOrigPayloadMapper.class.getName());

	public RegRepOrigPayload createDefaultOrigPayloadMessage(Message<?> message, String msgType
			,RegRepMessage regRepMessage)
	{

		logger.debug("Generating an message object for Orig Payload");

		RegRepOrigPayload 	dbMessage 		= null;		
		String				extMessageId	= null;
		String				payload			= null;	
		String 				originalPayload = null;
		ReportingContext	context			= null;
		String				sdrMessageId	= null;

		
		if(null == message){
			
			logger.error("Null Incoming message. Quiting Orig Payload creation");
			return dbMessage;			
		}
		
		if(null == msgType){
			
			logger.error("Null MessageType. Quiting Orig Payload creation");
			return dbMessage;			
		}
		
		if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext)){
			
			logger.error("Invalid incoming context. Quiting Orig Payload creation");
			return dbMessage;	
		}
		
		if(null == regRepMessage){
			
			logger.error("Null Incoming DB message. Quiting Orig Payload creation");
			return dbMessage;			
		}
		
		context = (ReportingContext)message.getPayload();
		
		sdrMessageId = context.getMessageId();
		
		if(null != message.getHeaders()){			
		
				if(null == message.getHeaders().get("origStv")){
					
					//payload = "This should be a payload only for DEV -Env testing.";
					
					originalPayload = context.getPayload();
					
					if (originalPayload.contains("</confirmation>"))
					
						payload = "Confirm Alert, doesn't have STV";
					
					else
					
						payload = "No Data Found";
					
				}else{
					
					payload = (String)message.getHeaders().get("origStv");
				}
				
				if(null == message.getHeaders().get("messageId")){
					
					extMessageId = "DEV-MsgId-Test";
				}	else{
					
					extMessageId = (String)message.getHeaders().get("messageId");
				}
		}
		
			
		dbMessage = new RegRepOrigPayload();
		
		dbMessage.setRegRepMessage(regRepMessage);
		dbMessage.setExternalMessageId(extMessageId);
		dbMessage.setPayload(payload);
		dbMessage.setPayloadTimestamp(new Date());
		dbMessage.setType(msgType);
				
		return dbMessage;
	}
	
	public RegRepOrigPayload createResponseOrigPayloadMessage(String extMessageId, 
			Message<?> message, RegRepMessage regRepMessage){
		
		RegRepOrigPayload 	dbMessage 	= null;
		ReportingContext	context 	= null;
		
		if(null == message){
			
			logger.error("Null Incoming message. Quiting Response Orig Payload creation");
			return dbMessage;			
		}
		
		if(null == regRepMessage){
			
			logger.error("Null Incoming reg rep message. Quiting Response Orig Payload creation");
			return dbMessage;			
		}
		
		if(null == extMessageId){
			
			logger.error("Null Incoming ext messageId. Quiting Response Orig Payload creation");
			return dbMessage;			
		}
		
		if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext)){
			
			logger.error("Invalid incoming context. Quiting Response Orig Payload creation");
			return dbMessage;	
		}
		
		context = (ReportingContext)message.getPayload();
		
		if(null == context.getPayload()){
			
			logger.error("Null incoming message payload. Quiting Response Orig Payload creation");
			return dbMessage;	
		}
		
		dbMessage = new RegRepOrigPayload();
		
		dbMessage.setRegRepMessage(regRepMessage);
		dbMessage.setExternalMessageId(extMessageId);
		dbMessage.setPayload(context.getPayload());
		dbMessage.setPayloadTimestamp(new Date());
		dbMessage.setType(PayloadTypeEnum.REG_REP_RESPONSE.name());
				
		return dbMessage;
	}
	

}
