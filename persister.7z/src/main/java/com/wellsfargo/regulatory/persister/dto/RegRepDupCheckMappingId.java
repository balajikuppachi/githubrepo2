package com.wellsfargo.regulatory.persister.dto;

public class RegRepDupCheckMappingId  implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sdrProductType;
	private String ignoreXpath;
	private String reportType;
	
	
	public String getSdrProductType() {
		return sdrProductType;
	}
	public void setSdrProductType(String sdrProductType) {
		this.sdrProductType = sdrProductType;
	}
	public String getIgnoreXpath() {
		return ignoreXpath;
	}
	public void setIgnoreXpath(String ignoreXpath) {
		this.ignoreXpath = ignoreXpath;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	public RegRepDupCheckMappingId(String sdrProductType, String ignoreXpath,
			String reportType) {
		super();
		this.sdrProductType = sdrProductType;
		this.ignoreXpath = ignoreXpath;
		this.reportType = reportType;
	}
	
	
	public RegRepDupCheckMappingId() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ignoreXpath == null) ? 0 : ignoreXpath.hashCode());
		result = prime * result
				+ ((sdrProductType == null) ? 0 : sdrProductType.hashCode());
		result = prime * result
				+ ((reportType == null) ? 0 : reportType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegRepDupCheckMappingId other = (RegRepDupCheckMappingId) obj;
		if (ignoreXpath == null) {
			if (other.ignoreXpath != null)
				return false;
		} else if (!ignoreXpath.equals(other.ignoreXpath))
			return false;
		if (sdrProductType == null) {
			if (other.sdrProductType != null)
				return false;
		} else if (!sdrProductType.equals(other.sdrProductType))
			return false;
		if (reportType == null) {
			if (other.reportType != null)
				return false;
		} else if (!reportType.equals(other.reportType))
			return false;
		
		return true;
	}
	
	@Override
	public String toString() {
		return "RegRepDupCheckMappingId [sdrProductType=" + sdrProductType
				+ ", ignoreXpath=" + ignoreXpath 
				+ ", reportType=" + reportType + "]";
	}

}
