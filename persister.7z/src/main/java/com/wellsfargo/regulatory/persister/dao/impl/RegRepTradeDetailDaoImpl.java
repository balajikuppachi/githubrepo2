package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepTradeDetailDao;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;

public class RegRepTradeDetailDaoImpl extends AbstractDaoImpl<RegRepTradeDetail> implements RegRepTradeDetailDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6896312734649563095L;

	@Override
	public Class<RegRepTradeDetail> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepTradeDetail.class;
	}


}
