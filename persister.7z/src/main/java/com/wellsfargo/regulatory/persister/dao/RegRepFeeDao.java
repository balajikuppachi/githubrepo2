package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepFee;

public interface RegRepFeeDao extends Serializable, Dao<RegRepFee>
{

}
