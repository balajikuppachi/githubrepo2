package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepProcessLogDao;
import com.wellsfargo.regulatory.persister.dto.RegRepProcessLog;

public class RegRepProcessLogDaoImpl extends AbstractDaoImpl<RegRepProcessLog> implements RegRepProcessLogDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2444516016578336282L;

	@Override
	public Class<RegRepProcessLog> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepProcessLog.class;
	}


}
