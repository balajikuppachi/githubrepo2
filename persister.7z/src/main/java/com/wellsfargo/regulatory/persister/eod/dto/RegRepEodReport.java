package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class RegRepEodReport implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String eodReportId ;
	private String swapTradeId;
	private String assetClass;
	private String jurisdiction;
	private String evntType;
	private String actionType;
	private String tradeStatus;
	private String srcMessageId;
	private String isActive;
	private Date expiredOn;
	private Timestamp insertTimeStamp;
	private String reportType;
	private int isBufferEligible;
	private Date cobDate;
	private String tradeUSI;
	private String tradeUTI;
	
	public String getTradeUSI() {
		return tradeUSI;
	}
	public void setTradeUSI(String tradeUSI) {
		this.tradeUSI = tradeUSI;
	}
	public String getTradeUTI() {
		return tradeUTI;
	}
	public void setTradeUTI(String tradeUTI) {
		this.tradeUTI = tradeUTI;
	}
	public String getEodReportId()
	{
		return eodReportId;
	}
	public void setEodReportId(String eodReportId)
	{
		this.eodReportId = eodReportId;
	}
	public String getSwapTradeId()
	{
		return swapTradeId;
	}
	public void setSwapTradeId(String swapTradeId)
	{
		this.swapTradeId = swapTradeId;
	}
	public String getAssetClass()
	{
		return assetClass;
	}
	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}
	public String getJurisdiction()
	{
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction)
	{
		this.jurisdiction = jurisdiction;
	}
	public String getEvntType()
	{
		return evntType;
	}
	public void setEvntType(String evntType)
	{
		this.evntType = evntType;
	}
	public String getActionType()
	{
		return actionType;
	}
	public void setActionType(String actionType)
	{
		this.actionType = actionType;
	}
	public String getTradeStatus()
	{
		return tradeStatus;
	}
	public void setTradeStatus(String tradeStatus)
	{
		this.tradeStatus = tradeStatus;
	}
	public String getSrcMessageId()
	{
		return srcMessageId;
	}
	public void setSrcMessageId(String srcMessageId)
	{
		this.srcMessageId = srcMessageId;
	}
	public String getIsActive()
	{
		return isActive;
	}
	public void setIsActive(String isActive)
	{
		this.isActive = isActive;
	}
	
	public Timestamp getInsertTimeStamp()
	{
		return insertTimeStamp;
	}
	public void setInsertTimeStamp(Timestamp insertTimeStamp)
	{
		this.insertTimeStamp = insertTimeStamp;
	}
	public String getReportType()
	{
		return reportType;
	}
	public void setReportType(String reportType)
	{
		this.reportType = reportType;
	}
	public int getIsBufferEligible()
	{
		return isBufferEligible;
	}
	public void setIsBufferEligible(int isBufferEligible)
	{
		this.isBufferEligible = isBufferEligible;
	}
	public Date getExpiredOn()
	{
		return expiredOn;
	}
	public void setExpiredOn(Date expiredOn)
	{
		this.expiredOn = expiredOn;
	}
	public Date getCobDate() {
		return cobDate;
	}
	public void setCobDate(Date cobDate) {
		this.cobDate = cobDate;
	}
	
	
	
	
	
	
	
	   
	   
	  

}
