package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepMappingBussaccidLei;

public interface RegRepMappingBussAccLeiDao extends Serializable, Dao<RegRepMappingBussaccidLei> {

	List<RegRepMappingBussaccidLei> fetchAllDistinctLegalIds();

}
