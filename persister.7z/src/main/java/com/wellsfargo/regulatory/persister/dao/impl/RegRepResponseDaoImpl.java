package com.wellsfargo.regulatory.persister.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepResponseDao;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;

public class RegRepResponseDaoImpl extends AbstractDaoImpl<RegRepResponse> implements RegRepResponseDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5922015120483864618L;


	@Override
	public Class<RegRepResponse> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepResponse.class;
	}
	
	@SuppressWarnings("unchecked")
    @Override
    @Transactional
    public List<RegRepResponse> loadRegRepRptsByRespId(List<String> responseIds)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepResponse result = null;
		List<RegRepResponse> resultList = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepResponse.GET_RESPONSE_BY_RESPONSE_IDs);
			queryObject.setParameterList("responseIds", responseIds);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				resultList = new ArrayList<RegRepResponse>(100);

				for (Object[] obj: objs)
				{
					result = new RegRepResponse();
					result.setRegRepSdrResponseId((String)obj[0]);
					result.setAcknowledgementStatus((String)obj[1]);
					result.setAcknowledgementTimestamp((Timestamp)obj[2]);
					result.setInReplyTo((String)obj[3]);
					result.setExternalMessageId((String)obj[4]);						
					result.setSentBy((String)obj[5]);
					result.setSentTo((String)obj[6]);

					resultList.add(result);
				}
			}

		}
		finally 
		{

			SessionFactoryUtils.closeSession(session);
			
/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return resultList;
    }
	
	public String getLastSubmissionStatus(String regRepMsgID)
	{
	

		Session session = null;
		Query queryObject = null;
		List<String> objs = null;

		session = openSession();
		queryObject = session.getNamedQuery(RegRepResponse.GET_RESPONSE_STATUS_BY_MSG_ID);
		queryObject.setParameter("regRepMsgId", regRepMsgID);
		objs = queryObject.list();
		Optional<String> ofNullable = objs.stream().filter(s-> s!=null  ).findFirst();

		return ofNullable.isPresent()?ofNullable.get():null;
    
	}
	

}
