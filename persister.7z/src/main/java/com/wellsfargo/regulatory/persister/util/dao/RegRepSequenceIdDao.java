package com.wellsfargo.regulatory.persister.util.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportData;
import com.wellsfargo.regulatory.persister.util.dto.RegRepSequenceId;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public interface RegRepSequenceIdDao extends Serializable, Dao<RegRepSequenceId>
{
	public RegRepSequenceId getNextRegRepSequnceId(String queryName, int sequenceCode);
	public List<RegRepReconReportData> getReconReportData(Date reportDate, String source1, String source2);

}
