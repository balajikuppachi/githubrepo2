package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse.Reason;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.etd.dto.EtdException;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class EtdExceptionMapper
{
	private static Logger logger = Logger.getLogger(EtdTradeJurisdictionMapper.class.getName());

	public EtdException populateEtdException(Reason reason) throws EtdMessageException
	{
		logger.info("inside EtdExceptionMapper populateEtdException method");
		EtdException currEtdException = new EtdException();
		Date current_date = new Date();

	/**
	  	int id = -1;
	 

		try
		{
			id = SequenceIdHelper.getMaxSequence("etdExceptionSequence");
		}
		catch (EtdMessageException e)
		{
			logger.error("exception occurred inside EtdExceptionMapper" + e.getMessage());
			throw new EtdMessageException("Etd:Excp:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, e.getMessage() + " payload : " + reason.description, reason.ProblemLocationValue, e);
		}
		catch (Exception e)
		{
			logger.error("exception occurred inside EtdExceptionMapper" + e.getMessage());
			throw new EtdMessageException("Etd:Excp:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, e.getMessage() + " payload : " + reason.description, reason.ProblemLocationValue, e);
		}
		*/

		EtdPayload currEtdPayload = new EtdPayload();
		currEtdPayload.setMessageId(reason.ProblemLocationValue);	// message id

		currEtdException.setExceptionCode(reason.reasonCode);
		currEtdException.setExceptionDesc(reason.description);
		currEtdException.setExceptionType(reason.type.toString());
		//currEtdException.setExceptionId(id);
		currEtdException.setEtdPayload(currEtdPayload);
		currEtdException.setCreateDatetime(current_date);

		logger.info("exiting EtdExceptionMapper populateEtdException method");

		return currEtdException;
	}

}
