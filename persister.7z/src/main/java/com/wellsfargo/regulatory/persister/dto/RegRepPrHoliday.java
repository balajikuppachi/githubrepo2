package com.wellsfargo.regulatory.persister.dto;

import java.io.Serializable;
import java.util.Date;

public class RegRepPrHoliday implements Serializable {

	private static final long serialVersionUID = 7024727810146348693L;
	public final static String GET_DATE = "loadRegRepHoliday"; 
	
	private int id;
	private String name;
	private Date date;
	private String comments;

	public RegRepPrHoliday() {}

	public RegRepPrHoliday(int id, String name, Date date, String comments){
		this.id = id;
		this.name = name;
		this.date = date;
		this.comments = comments;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString()
	{
		return "RegRepPrHoliday [id=" + id + ", name=" + name+ ", date=" + date + ", comments=" + comments + "]";
	}
}
