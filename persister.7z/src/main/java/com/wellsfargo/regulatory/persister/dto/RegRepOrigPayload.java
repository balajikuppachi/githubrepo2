package com.wellsfargo.regulatory.persister.dto;

import java.io.Serializable;
import java.util.Date;

public class RegRepOrigPayload implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long regRepOrigMessageId;	
	private RegRepMessage regRepMessage;
	private String externalMessageId;
	private String payload;
	private Date payloadTimestamp;
	private String type;
	
	public RegRepOrigPayload()
	{
	}

	public RegRepOrigPayload(String externalMessageId, String payload,
			Date payloadTimestamp, String type) {
		super();
		
		this.externalMessageId = externalMessageId;
		this.payload = payload;
		this.payloadTimestamp = payloadTimestamp;
		this.type = type;
	}

	public RegRepMessage getRegRepMessage() {
		return regRepMessage;
	}

	public void setRegRepMessage(RegRepMessage regRepMessage) {
		this.regRepMessage = regRepMessage;
	}

	public String getExternalMessageId() {
		return externalMessageId;
	}

	public void setExternalMessageId(String externalMessageId) {
		this.externalMessageId = externalMessageId;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public Date getPayloadTimestamp() {
		return payloadTimestamp;
	}

	public void setPayloadTimestamp(Date payloadTimestamp) {
		this.payloadTimestamp = payloadTimestamp;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getRegRepOrigMessageId() {
		return regRepOrigMessageId;
	}

	public void setRegRepOrigMessageId(Long regRepOrigMessageId) {
		this.regRepOrigMessageId = regRepOrigMessageId;
	}
}
