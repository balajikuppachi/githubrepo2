package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepPeriodDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPeriod;

public class RegRepPeriodDaoImpl extends AbstractDaoImpl<RegRepPeriod> implements RegRepPeriodDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 76060714244436123L;

	@Override
	public Class<RegRepPeriod> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepPeriod.class;
	}

}
