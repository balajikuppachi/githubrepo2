package com.wellsfargo.regulatory.persister.dto.logging;

import com.wellsfargo.regulatory.commons.beans.RegRepException;

public interface RegRepExceptionDao
{
	// public boolean insertRegRepException(RegRepException exception);
	// public RegRepException getExceptionsByMessageId(String messageId);
}
