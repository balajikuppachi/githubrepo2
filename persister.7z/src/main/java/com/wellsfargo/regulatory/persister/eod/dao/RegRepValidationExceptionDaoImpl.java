package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.eod.dto.RegRepValidationException;

/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class RegRepValidationExceptionDaoImpl  implements RowMapper<RegRepValidationException>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	String insertSql = "insert into REG_REP_VALIDATION_EXCEPTION "
			+ "(message_id, tradeid, exception_code, exception_type, description, user_id, comments, create_datetime, update_datetime)values"
			+ " (?, ?, ?, ?, ?, ?, ?, getDate(), getDate())";

	@Override
    public RegRepValidationException mapRow(ResultSet rs, int row) throws SQLException
    {
		RegRepValidationException regRepValidationException = new RegRepValidationException();
		regRepValidationException.setMessageId(rs.getString("message_id"));
		regRepValidationException.setTradeid(rs.getString("tradeid"));
		regRepValidationException.setExceptionCode(rs.getString("exception_code"));
		regRepValidationException.setExceptionType(rs.getString("exception_type"));
		regRepValidationException.setDescription(rs.getString("description"));
		regRepValidationException.setUserId(rs.getString("user_id"));
		regRepValidationException.setComments(rs.getString("comments"));
		
	    return regRepValidationException;
    }
	
	public void insert(RegRepValidationException regRepValidationException)
	{
		jdbcTemplate.update(insertSql,
		        new Object[] {regRepValidationException.getMessageId(), regRepValidationException.getTradeid(), regRepValidationException.getExceptionCode(),
				regRepValidationException.getExceptionType(), regRepValidationException.getDescription(), regRepValidationException.getUserId(),
				regRepValidationException.getComments()});
	}

}
