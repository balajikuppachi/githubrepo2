package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.DocumentationType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepDocumentation;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public class RegRepDocumentationMapper
{

	private static Logger logger = Logger.getLogger(RegRepDocumentationMapper.class.getName());

	public RegRepDocumentation createRegRepDocumentation(DocumentationType ipDocument, RegRepTradeDetail regRepTradeDetail)
	{
		RegRepDocumentation documentation = null;

		if (null == ipDocument || null == regRepTradeDetail)
		{
			logger.debug("RegRepDocumentation object could not be " + "populated due to invalid incoming data");
			return documentation;
		}

		documentation = new RegRepDocumentation();

		documentation.setContractualTermsSupplementDate(CalendarUtils.toDate(ipDocument.getContractualTermsSupplementDate()));
		documentation.setContractualTermsSupplementTypr(ipDocument.getContractualTermsSupplementType());
		documentation.setDtccMatrixParticipant(ConversionUtils.booleanToDbString(ipDocument.isDtccMatrixParticipant()));
		documentation.setMasterAgreementDate(CalendarUtils.toDate(ipDocument.getMasterAgreementDate()));
		documentation.setMasterAgreementType(ipDocument.getMasterAgreementType());
		// documentation.setRegRepMessageId(regRepTradeDetail.getRegRepSdrRequest().getRegRepMessage().getRegRepMessageId());
		documentation.setRegRepTradeDetail(regRepTradeDetail);

		return documentation;
	}

}
