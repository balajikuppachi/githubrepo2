package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepKeyword;
import com.wellsfargo.regulatory.persister.dto.RegRepLifecycle;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepTradeHeaderMapper
{

	private static Logger logger = Logger.getLogger(RegRepTradeHeaderMapper.class.getName());

	public RegRepTradeHeader createRegRepTradeHeader(RegRepSdrRequest dbRequest, TradeHeaderType ipHeader)
	{
		RegRepTradeHeader dbHeader 				= null;
		RegRepKeywordMapper keywordMapper 		= null;
		RegRepKeyword dbKey 					= null;
		Set<RegRepKeyword> dbKeySet 			= null;
		KeywordsType ipKeys 					= null;
		LifeCycleType ipLifecycle 				= null;
		RegRepLifeCycleMapper lifecyclenMapper 	= null;
		RegRepLifecycle dbLifecycle 			= null;

		if (null == dbRequest || null == ipHeader)
		{
			logger.debug("RegRepTradeHeader object could not be " + "populated due to invalid incoming data");
			return dbHeader;
		}

		dbHeader = new RegRepTradeHeader();
		dbHeader.setRegRepSdrRequest(dbRequest);

		ipKeys = ipHeader.getKeywords();
		
		if (null != ipKeys)
		{
			keywordMapper 	= new RegRepKeywordMapper();
			dbKeySet 		= new HashSet<RegRepKeyword>(5);

			for (Keyword ipKey : ipKeys.getKeyword())
			{
				dbKey = keywordMapper.createRegRepKeyword(null, null, dbHeader, ipKey);
				dbKeySet.add(dbKey);
			}
		}

		ipLifecycle = ipHeader.getLifeCycle();
		if (null != ipLifecycle)
		{
			lifecyclenMapper = new RegRepLifeCycleMapper();
			dbLifecycle = lifecyclenMapper.createRegRepLifecycle(dbHeader, ipLifecycle);
		}

		dbHeader.setAction(ipHeader.getAction());
		dbHeader.setBookName(ipHeader.getBookName());
		dbHeader.setComment(ipHeader.getComment());
		dbHeader.setEnteredUser(ipHeader.getEnteredUser());
		dbHeader.setEnteredDateTime(CalendarUtils.toDate(ipHeader.getEnteredDateTime()));
		dbHeader.setExecutionDateTime(CalendarUtils.toDate(ipHeader.getExecutionDateTime()));

		if (null != ipHeader.getExecutionVenueType()) 
			dbHeader.setExecutionVenueType(ipHeader.getExecutionVenueType().value());
		
		dbHeader.setExecutionVenue(ipHeader.getExecutionVenue());

		// dbHeader.setIsAffliateTrade(ConversionUtils.booleanToDbString(ipHeader.isIsAffiliateTrade()));
		dbHeader.setRegRepKeywords(dbKeySet);
		dbHeader.setRegRepLifecycle(dbLifecycle);

		/*
		 * @Comment : Amit Rana Need not be set, else hibernate creates a duplicate object
		 * dbHeader.setRegRepMessageId(dbHeader.getRegRepMessageId());
		 */

		dbHeader.setStatus(ipHeader.getStatus());		
		dbHeader.setTradeDate(CalendarUtils.toDate(ipHeader.getTradeDate()));
		dbHeader.setTradeId(ipHeader.getTradeId());
		dbHeader.setTraderName(ipHeader.getTraderName());
		
		String versionNum = ipHeader.getTradeVersion();
		if (null == versionNum) 
			logger.warn(">>>>>>>>> tradeVersion is NULL in input SDR XML <<<<<<<<< ");
		else 
			//dbHeader.setTradeVersion(Long.toString(versionNum));
			dbHeader.setTradeVersion(versionNum);

		if (null != ipHeader.getVerificationMethod()) 
			dbHeader.setVerificationMethod(ipHeader.getVerificationMethod().value());
		
		dbHeader.setEcnSource(ipHeader.getEcnSource());
		dbHeader.setProcessingOrgLei(ipHeader.getProcessingOrgLEI());
		dbHeader.setCounterPartyLei(ipHeader.getCounterpartyLEI());
		dbHeader.setCalculationAgentCity(ipHeader.getCalculationAgentCity());
		dbHeader.setCalculationAgentId(ipHeader.getCalculationAgentId());
		
		if(null != ipHeader.getCalculationAgentParty())
			dbHeader.setCalculationAgentParty(ipHeader.getCalculationAgentParty().value());
		
		dbHeader.setBrokerLEI(ipHeader.getBrokerLEI());
		dbHeader.setClearingBrokerLEI(ipHeader.getClearingBrokerLEI());
		dbHeader.setExecutionAgentLEI(ipHeader.getExecutionAgentLEI());
		dbHeader.setSecondaryTradeId(ipHeader.getSecondaryTradeId());
		dbHeader.setIsPosition(ConversionUtils.booleanToDbString(ipHeader.isIsPosition()));
		dbHeader.setIsBackload(ConversionUtils.booleanToDbString(ipHeader.isBackload()));		
		
		/*** Start LEI Changes ***/ 
		
		dbHeader.setProcessingOrgLEIPrefix(StringUtils.trimToEmpty(ipHeader.getProcessingOrgLEIPrefix()));
		dbHeader.setProcessingOrgLEIValue(StringUtils.trimToEmpty(ipHeader.getProcessingOrgLEIValue()));
		
		dbHeader.setCounterpartyLEIPrefix(StringUtils.trimToEmpty(ipHeader.getCounterpartyLEIPrefix()));
		dbHeader.setCounterpartyLEIValue(StringUtils.trimToEmpty(ipHeader.getCounterpartyLEIValue()));
		
		dbHeader.setBrokerLEIPrefix(StringUtils.trimToEmpty(ipHeader.getBrokerLEIPrefix()));
		dbHeader.setBrokerLEIValue(StringUtils.trimToEmpty(ipHeader.getBrokerLEIValue()));

		dbHeader.setClearingBrokerLEIPrefix(StringUtils.trimToEmpty(ipHeader.getClearingBrokerLEIPrefix()));
		dbHeader.setClearingBrokerLEIValue(StringUtils.trimToEmpty(ipHeader.getClearingBrokerLEIValue()));

		dbHeader.setExecutionAgentLEIPrefix(StringUtils.trimToEmpty(ipHeader.getExecutionAgentLEIPrefix()));
		dbHeader.setExecutionAgentLEIValue(StringUtils.trimToEmpty(ipHeader.getExecutionAgentLEIValue()));
		dbHeader.setTradeUpdateDatetime(CalendarUtils.toDate(ipHeader.getTradeUpdateDatetime()));
		dbHeader.setMessageUpdateDateTime(CalendarUtils.toDate(ipHeader.getMessageUpdateDateTime()));
		dbHeader.setOrigExecutionDateTime(CalendarUtils.toDate(ipHeader.getOrigExecutionDateTime()));
		dbHeader.setTradeAction(ipHeader.getTradeAction());
		dbHeader.setSdrAction(ipHeader.getSdrAction());
		
		/*** End LEI Changes ***/ 

		return dbHeader;
	}

}
