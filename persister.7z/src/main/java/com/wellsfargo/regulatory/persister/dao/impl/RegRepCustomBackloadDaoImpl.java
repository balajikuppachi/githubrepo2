package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepCustomBackloadDao;
import com.wellsfargo.regulatory.persister.dto.RegRepCustomBackload;

public class RegRepCustomBackloadDaoImpl   extends AbstractDaoImpl<RegRepCustomBackload> implements RegRepCustomBackloadDao {
	
	private static final long serialVersionUID = 4806208231160083034L;

	@Override
	public Class<RegRepCustomBackload> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepCustomBackload.class;
	}

}
