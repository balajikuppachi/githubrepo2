package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepTradeHeaderDao;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

public class RegRepTradeHeaderDaoImpl extends AbstractDaoImpl<RegRepTradeHeader> implements RegRepTradeHeaderDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2606453608335405056L;

	@Override
	public Class<RegRepTradeHeader> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepTradeHeader.class;
	}

}
