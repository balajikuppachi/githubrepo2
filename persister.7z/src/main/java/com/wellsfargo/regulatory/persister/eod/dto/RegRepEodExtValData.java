package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class ValuationFromCdbo.
 */
public class RegRepEodExtValData implements Serializable
{
	/** 
	 * This attribute maps to the column fo_trade_id in the valuation_from_cdbo table.
	 */
	protected String foTradeId;

	/** 
	 * This attribute maps to the column source_system in the valuation_from_cdbo table.
	 */
	protected String sourceSystem;

	/** 
	 * This attribute maps to the column status in the valuation_from_cdbo table.
	 */
	protected String status;

	/** 
	 * This attribute maps to the column npv_value in the valuation_from_cdbo table.
	 */
	protected BigDecimal npvValue;

	/** 
	 * This attribute maps to the column npv_date in the valuation_from_cdbo table.
	 */
	protected Date npvDate;

	/** 
	 * This attribute maps to the column npv_Currency in the valuation_from_cdbo table.
	 */
	protected String npvCurrency;

	
	/** The notional current. */
	protected String notionalCurrent;
	
	/** The pay notional. */
	protected String payNotional;
	
	/** The recv notional. */
	protected String recvNotional;
	
	
	/** The pay currency. */
	protected String payCurrency;
	
	/** The recv currency. */
	protected String recvCurrency;
	
	/**
	 * Method 'ValuationFromCdbo'.
	 */
	public RegRepEodExtValData()
	{
	}

	/**
	 * Method 'getFoTradeId'.
	 *
	 * @return String
	 */
	public String getFoTradeId()
	{
		return foTradeId;
	}

	/**
	 * Method 'setFoTradeId'.
	 *
	 * @param foTradeId the new fo trade id
	 */
	public void setFoTradeId(String foTradeId)
	{
		this.foTradeId = foTradeId;
	}

	/**
	 * Method 'getSourceSystem'.
	 *
	 * @return String
	 */
	public String getSourceSystem()
	{
		return sourceSystem;
	}

	/**
	 * Method 'setSourceSystem'.
	 *
	 * @param sourceSystem the new source system
	 */
	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	/**
	 * Method 'getStatus'.
	 *
	 * @return String
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * Method 'setStatus'.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * Method 'getNpvValue'.
	 *
	 * @return BigDecimal
	 */
	public BigDecimal getNpvValue()
	{
		return npvValue;
	}

	/**
	 * Method 'setNpvValue'.
	 *
	 * @param npvValue the new npv value
	 */
	public void setNpvValue(BigDecimal npvValue)
	{
		this.npvValue = npvValue;
	}

	/**
	 * Method 'getNpvDate'.
	 *
	 * @return Date
	 */
	public Date getNpvDate()
	{
		return npvDate;
	}

	/**
	 * Method 'setNpvDate'.
	 *
	 * @param npvDate the new npv date
	 */
	public void setNpvDate(Date npvDate)
	{
		this.npvDate = npvDate;
	}

	/**
	 * Method 'getNpvCurrency'.
	 *
	 * @return String
	 */
	public String getNpvCurrency()
	{
		return npvCurrency == null ? null : npvCurrency.trim();
	}

	/**
	 * Method 'setNpvCurrency'.
	 *
	 * @param npvCurrency the new npv Currency
	 */
	public void setNpvCurrency(String npvCurrency)
	{
		this.npvCurrency = npvCurrency;
	}

	
	/**
	 * Gets the notional current.
	 *
	 * @return the notionalCurrent
	 */
	public String getNotionalCurrent() {
		return notionalCurrent;
	}

	/**
	 * Sets the notional current.
	 *
	 * @param notionalCurrent the notionalCurrent to set
	 */
	public void setNotionalCurrent(String notionalCurrent) {
		this.notionalCurrent = notionalCurrent;
	}

	/**
	 * Gets the pay notional.
	 *
	 * @return the payNotional
	 */
	public String getPayNotional() {
		return payNotional;
	}

	/**
	 * Sets the pay notional.
	 *
	 * @param payNotional the payNotional to set
	 */
	public void setPayNotional(String payNotional) {
		this.payNotional = payNotional;
	}

	/**
	 * Gets the recv notional.
	 *
	 * @return the recvNotional
	 */
	public String getRecvNotional() {
		return recvNotional;
	}

	/**
	 * Sets the recv notional.
	 *
	 * @param recvNotional the recvNotional to set
	 */
	public void setRecvNotional(String recvNotional) {
		this.recvNotional = recvNotional;
	}

	/**
	 * Gets the pay currency.
	 *
	 * @return the payCurrency
	 */
	public String getPayCurrency() {
		return payCurrency;
	}

	/**
	 * Sets the pay currency.
	 *
	 * @param payCurrency the payCurrency to set
	 */
	public void setPayCurrency(String payCurrency) {
		this.payCurrency = payCurrency;
	}

	/**
	 * Gets the recv currency.
	 *
	 * @return the recvCurrency
	 */
	public String getRecvCurrency() {
		return recvCurrency;
	}

	/**
	 * Sets the recv currency.
	 *
	 * @param recvCurrency the recvCurrency to set
	 */
	public void setRecvCurrency(String recvCurrency) {
		this.recvCurrency = recvCurrency;
	}

	/**
	 * Method 'equals'.
	 *
	 * @param _other the _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof RegRepEodExtValData)) {
			return false;
		}
		
		final RegRepEodExtValData _cast = (RegRepEodExtValData) _other;
		if (foTradeId == null ? _cast.foTradeId != foTradeId : !foTradeId.equals( _cast.foTradeId )) {
			return false;
		}
		
		if (sourceSystem == null ? _cast.sourceSystem != sourceSystem : !sourceSystem.equals( _cast.sourceSystem )) {
			return false;
		}
		
		if (status == null ? _cast.status != status : !status.equals( _cast.status )) {
			return false;
		}
		
		if (npvValue == null ? _cast.npvValue != npvValue : !npvValue.equals( _cast.npvValue )) {
			return false;
		}
		
		if (npvDate == null ? _cast.npvDate != npvDate : !npvDate.equals( _cast.npvDate )) {
			return false;
		}
		
		if (npvCurrency == null ? _cast.npvCurrency != npvCurrency : !npvCurrency.equals( _cast.npvCurrency )) {
			return false;
		}
		if (notionalCurrent == null ? _cast.notionalCurrent != notionalCurrent : !notionalCurrent.equals( _cast.notionalCurrent )) {
			return false;
		}
		if (payNotional == null ? _cast.payNotional != payNotional : !payNotional.equals( _cast.payNotional )) {
			return false;
		}
		if (recvNotional == null ? _cast.recvNotional != recvNotional : !recvNotional.equals( _cast.recvNotional )) {
			return false;
		}
		if (recvCurrency == null ? _cast.recvCurrency != recvCurrency : !recvCurrency.equals( _cast.recvCurrency )) {
			return false;
		}if (payCurrency == null ? _cast.payCurrency != payCurrency : !payCurrency.equals( _cast.payCurrency )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'.
	 *
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (foTradeId != null) {
			_hashCode = 29 * _hashCode + foTradeId.hashCode();
		}
		
		if (sourceSystem != null) {
			_hashCode = 29 * _hashCode + sourceSystem.hashCode();
		}
		
		if (status != null) {
			_hashCode = 29 * _hashCode + status.hashCode();
		}
		
		if (npvValue != null) {
			_hashCode = 29 * _hashCode + npvValue.hashCode();
		}
		
		if (npvDate != null) {
			_hashCode = 29 * _hashCode + npvDate.hashCode();
		}
		
		if (npvCurrency != null) {
			_hashCode = 29 * _hashCode + npvCurrency.hashCode();
		}
		if (notionalCurrent != null) {
			_hashCode = 29 * _hashCode + notionalCurrent.hashCode();
		}
		if (payNotional != null) {
			_hashCode = 29 * _hashCode + payNotional.hashCode();
		}
		if (recvNotional != null) {
			_hashCode = 29 * _hashCode + recvNotional.hashCode();
		}
		if (payCurrency != null) {
			_hashCode = 29 * _hashCode + payCurrency.hashCode();
		}
		if (recvCurrency != null) {
			_hashCode = 29 * _hashCode + recvCurrency.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'.
	 *
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.wf.df.sdr.dto.ValuationFromCdbo: " );
		ret.append( "foTradeId=" + foTradeId );
		ret.append( ", sourceSystem=" + sourceSystem );
		ret.append( ", status=" + status );
		ret.append( ", npvValue=" + npvValue );
		ret.append( ", npvDate=" + npvDate );
		ret.append( ", npvCurrency=" + npvCurrency );
		ret.append( ", notionalCurrent=" + notionalCurrent );
		ret.append( ", payNotional=" + payNotional );
		ret.append( ", recvNotional=" + recvNotional );
		ret.append( ", payCurrency=" + payCurrency );
		ret.append( ", recvCurrency=" + recvCurrency );
		return ret.toString();
	}

}
