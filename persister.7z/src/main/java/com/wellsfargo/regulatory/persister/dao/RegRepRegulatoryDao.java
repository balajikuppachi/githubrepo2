package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepRegulatory;

public interface RegRepRegulatoryDao extends Dao<RegRepRegulatory>, Serializable
{

	/**
	 * To retrieve REG_REP_REGULATORY records based on USI
	 */
	public List<RegRepRegulatory> loadRegRepRegulatoriesByUSI(String uSI);

	/**
	 * To retrieve REG_REP_REGULATORY records based on REG_REP_MESSAGE_ID
	 */
	public List<RegRepRegulatory> loadRegRepRegulatoriesByMsgId(String messageId);
}
