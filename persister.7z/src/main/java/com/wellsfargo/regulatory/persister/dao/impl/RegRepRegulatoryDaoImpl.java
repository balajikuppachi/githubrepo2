package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.persister.dao.RegRepRegulatoryDao;
import com.wellsfargo.regulatory.persister.dto.RegRepRegulatory;

public class RegRepRegulatoryDaoImpl extends AbstractDaoImpl<RegRepRegulatory> implements RegRepRegulatoryDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2341680308634065795L;

	@Override
	public Class<RegRepRegulatory> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepRegulatory.class;
	}

	/**
	 * Retrieve REG_REP_REGULATORY records based on USI
	 */
	@SuppressWarnings("unchecked")
	public List<RegRepRegulatory> loadRegRepRegulatoriesByUSI(String uSI)
	{
		// TODO Auto-generated method stub
		// return findByNamedQuery(RegRepRegulatory.GET_REGULATORY_BY_USI, new Object[]{uSI});
		return null;
	}

	/**
	 * Retrieve REG_REP_REGULATORY records based on REG_REP_MESSAGE_ID
	 */
	public List<RegRepRegulatory> loadRegRepRegulatoriesByMsgId(String messageId)
	{
		// TODO Auto-generated method stub
		return null;
	}


}
