package com.wellsfargo.regulatory.persister.etd.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class EtdExceptionExtnDao
{

	private JdbcTemplate jdbcTemplate;

	public EtdExceptionExtnDao(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public Long findFeedIdInRange(Long from, Long to)
	{
		List<Long> maxIdList = jdbcTemplate.queryForList("SELECT MAX(exception_id) FROM ETD_EXCEPTION WHERE exception_id >= ? AND exception_id <= ?", Long.class, from, to);

		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null)
		{
			return null;
		}
		else
		{
			return maxIdList.get(0);
		}
	}

}
