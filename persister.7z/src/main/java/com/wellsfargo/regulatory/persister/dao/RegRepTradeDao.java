package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepTrade;

public interface RegRepTradeDao extends Serializable, Dao<RegRepTrade>
{

	/**
	 * To retrieve REG_REP_TRADE records based on TRADE_USI_PREFIX and TRADE_USI_VALUE
	 */

	public List<RegRepTrade> loadRegRepTradesByUSI(String usiPrefix, String usiValue);
	
	public RegRepTrade findByPrimaryKeyNS (String swapTradeId);
}
