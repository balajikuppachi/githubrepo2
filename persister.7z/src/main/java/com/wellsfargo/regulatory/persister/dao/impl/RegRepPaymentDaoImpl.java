package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepPaymentDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPayment;

public class RegRepPaymentDaoImpl extends AbstractDaoImpl<RegRepPayment> implements RegRepPaymentDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8135134172235860906L;

	@Override
	public Class<RegRepPayment> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepPayment.class;
	}

}
