package com.wellsfargo.regulatory.persister.etd.dao.impl;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeBatchOutputDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeBatchOutput;

public class EtdTradeBatchOutputDaoImpl extends AbstractDaoImpl<EtdTradeBatchOutput> implements EtdTradeBatchOutputDao
{
	/**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    
    @Override
	public Class<EtdTradeBatchOutput> getEntityClass()
	{
		return EtdTradeBatchOutput.class;
	}


}
