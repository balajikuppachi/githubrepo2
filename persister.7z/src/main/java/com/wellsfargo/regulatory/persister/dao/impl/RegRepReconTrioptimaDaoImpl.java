package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepReconTrioptimaDao;
import com.wellsfargo.regulatory.persister.dto.RegRepReconTrioptima;

public class RegRepReconTrioptimaDaoImpl  extends AbstractDaoImpl<RegRepReconTrioptima> implements RegRepReconTrioptimaDao
{	
	   /**
	 * 
	 */
	private static final long serialVersionUID = 7756903292797841122L;
	
	private JdbcTemplate m_jdbcTemplate;
	    
	    public JdbcTemplate getJdbcTemplate() 
	    {
	        return m_jdbcTemplate;
	    }

	    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) 
	    {
	        m_jdbcTemplate = jdbcTemplate;
	    }

	@Override
	public Class<RegRepReconTrioptima> getEntityClass() {
		return RegRepReconTrioptima.class;
	}

	@Override
	@Transactional
	public RegRepReconTrioptima findByPrimaryKeyNS(String trade) {

		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepReconTrioptima result = null;
		
		try 
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepReconTrioptima.GET_TRADE_BY_TRADE_ID);
			queryObject.setString("trdID", trade);
			objs = queryObject.list();
		
			if (objs!=null && !objs.isEmpty())
			{
				for (Object[] obj: objs)
					
					
				{
					result = new RegRepReconTrioptima();
					result.setTradeID((String)obj[0]);
					result.setMessageId((String)obj[1]);
					result.setReportType((String)obj[2]);
					result.setIsActive((String)obj[3]);
					result.setJurisdiction((String)obj[4]);
					result.setRepository((String)obj[5]);
					result.setAssetClass((String)obj[6]);
					result.setUsi((String)obj[7]);
					result.setOutputMessage((String)obj[8]);
					result.setEquityTemplate((String)obj[9]);
					result.setInsertTimeStamp((java.util.Date)obj[10]);
				}
			
			}
		} 
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);

/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return result;
    
	}

}
