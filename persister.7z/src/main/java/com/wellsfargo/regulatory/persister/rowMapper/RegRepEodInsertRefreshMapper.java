package com.wellsfargo.regulatory.persister.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RegRepEodInsertRefreshMapper implements RowMapper<RegRepEodInsertRefreshMessage> {

	@Override
	public RegRepEodInsertRefreshMessage mapRow(ResultSet rs, int rowNum)
			throws SQLException {
			
		RegRepEodInsertRefreshMessage refreshMessage = new RegRepEodInsertRefreshMessage();
				
		refreshMessage.setMessageId(rs.getString("REG_REP_MESSAGE_ID"));
		refreshMessage.setTradeId(rs.getString("SWAP_TRADE_ID"));
		refreshMessage.setPayload(rs.getString("PAYLOAD"));
				
		return refreshMessage;
	}

}
