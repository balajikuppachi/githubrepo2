package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.ConfirmationType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepConfirmation;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;

/**
 * @author Amit Rana
 * @date 05/06/2015
 * @version 1.0
 */

public class RegRepConfirmationMapper 
{
	private static Logger logger = Logger.getLogger(RegRepConfirmationMapper.class.getName());

	public RegRepConfirmation createRegRepConfirmation(RegRepSdrRequest dbrequest, ConfirmationType confirmation)
	{
		logger.debug("Entering createRegRepConfirmation() method");

		RegRepConfirmation dbConfirmation = null;

		if (null == dbrequest || null == confirmation)
		{
			logger.warn("^^^^^^ RegRepClearing object could not be populated due to invalid incoming data");
			return dbConfirmation;
		}

		dbConfirmation = new RegRepConfirmation();	
		
		dbConfirmation.setDocumentId(confirmation.getDocumentId());
		dbConfirmation.setIsPaper(ConversionUtils.booleanToDbString(confirmation.isIsPaper()));
		//dbConfirmation.setRegRepConfirmationId(confirmation.get);
		dbConfirmation.setRegRepSdrRequest(dbrequest);
		dbConfirmation.setSourceSystem(confirmation.getSourceSystem());
		dbConfirmation.setSwapTradeId(confirmation.getTradeId());
		dbConfirmation.setTradeVersion(confirmation.getTradeVersion());
		dbConfirmation.setUsi((null == confirmation.getUSI()) ? "NotAvailable" : confirmation.getUSI());
		dbConfirmation.setConfirmationDate(CalendarUtils.toDate(confirmation.getConfirmationDateTime()));

		logger.debug("Leaving createRegRepConfirmation() method");

		return dbConfirmation;
	}

}
