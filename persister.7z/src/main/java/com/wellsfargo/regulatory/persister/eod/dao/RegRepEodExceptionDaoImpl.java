package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodException;

@Component
public class RegRepEodExceptionDaoImpl implements RowMapper<RegRepEodException>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public RegRepEodException mapRow(ResultSet arg0, int arg1) throws SQLException
	{
		RegRepEodException currRegRepEodException = new RegRepEodException();

		return currRegRepEodException;
	}

	public int batchInsertEodException(List<RegRepEodException> eodExceptionList)
	{
		String sql = "INSERT INTO REG_REP_EOD_EXCEPTION (SUBMISSION_ID, CODE, DESCRIPTION, TYPE, SEVERITY, STATUS, INSERT_TIMESTAMP) VALUES (?, ?, ?, ?, ?, ?, ?) ";

		jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
		{

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException
			{
				RegRepEodException currRegRepEodException = eodExceptionList.get(i);

				ps.setLong(1, currRegRepEodException.getSubmissionId());
				ps.setString(2, currRegRepEodException.getCode());
				ps.setString(3, currRegRepEodException.getDescription());
				ps.setString(4, currRegRepEodException.getType());
				ps.setString(5, currRegRepEodException.getSeverity());
				ps.setString(6, currRegRepEodException.getStatus());
				ps.setTimestamp(7, currRegRepEodException.getInsertTimeStamp());

			}

			@Override
			public int getBatchSize()
			{
				return eodExceptionList.size();
			}
		});

		return eodExceptionList.size();
	}

}
