package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepPortfolioCount;

public interface RegRepPortfolioCountDao extends Dao<RegRepPortfolioCount>, Serializable {
	
	public RegRepPortfolioCount getPortfolioCountByLeiAndAsset(String lei, String assetClass);

}
