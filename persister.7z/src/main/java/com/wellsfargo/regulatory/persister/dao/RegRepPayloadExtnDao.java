package com.wellsfargo.regulatory.persister.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class RegRepPayloadExtnDao
{
	private JdbcTemplate jdbcTemplate;

	public RegRepPayloadExtnDao(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public Long findFeedIdInRange(Long from, Long to)
	{
		List<Long> maxIdList = jdbcTemplate.queryForList("SELECT MAX(REG_REP_PAYLOAD_ID) FROM REG_REP_PAYLOAD WHERE REG_REP_PAYLOAD_ID >= ? AND REG_REP_PAYLOAD_ID <= ?", Long.class, from, to);

		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null)
		{
			return null;
		}
		else
		{
			return maxIdList.get(0);
		}
	}
}
