package com.wellsfargo.regulatory.persister.helper.mapper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.collateral.dto.RegRepCollateralAgreements;
import com.wellsfargo.regulatory.commons.etd.bo.dtcc.ETDDtccTemplate;
import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdCollateralDtls;
import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdValuationDtls;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;

/**
 * @author Raji Komatreddy
 */
public class EtdTradeJurisdictionMapper
{
	private static Logger logger = Logger.getLogger(EtdTradeJurisdictionMapper.class.getName());

	public EtdTradeJurisdiction populateEtdTradeJurisdiction(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		logger.debug("inside EtdTradeJurisdictionMapper  populateEtdTradeJurisdiction method");
		EtdTradeJurisdiction currEtdTradeJurisdiction = new EtdTradeJurisdiction();
		Date current_date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(EtdConstants.ETD_COBDATE_FORMAT);
		String cobDate = dateFormat.format(current_date);

		SdrRequest sdrRequest = null;
		TradeType trade = null;
		TradeHeaderType tradeHeader = null;
		String dtccOutMsg = null;
		RegulatoryType regulatory = null;
		String msgType = null;
		Boolean isPosition = false;
		String sourceSystemMessageId = null;
		String delegatedReporting = null;
		String submittedFor = null;
		ReportingEligibilityType reportingEligibility = null;

		/**
		 * int id = -1; try { id = SequenceIdHelper.getMaxSequence("etdTradeJurisdictionSequence");
		 * } catch (EtdMessageException e) { throw new EtdMessageException("EtdTradeJuris:1",
		 * ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, e.getMessage() + " payload : "
		 * + context.getPayload(), etdPayload.getMessageId(), e); } catch (Exception e) { throw new
		 * EtdMessageException("EtdTradeJuris:2", ExceptionSeverityEnum.ERROR,
		 * ExceptionTypeEnum.ETD_ERROR, e.getMessage() + " payload : " + context.getPayload(),
		 * etdPayload.getMessageId(), e); }
		 */

		// currEtdTradeJurisdiction.setJurisdictionId(id);
		currEtdTradeJurisdiction.setCobDate(cobDate);
		currEtdTradeJurisdiction.setCreateDatetime(current_date);
		currEtdTradeJurisdiction.setUpdateDatetime(current_date);
		currEtdTradeJurisdiction.setEtdPayload(etdPayload);
		currEtdTradeJurisdiction.setState(EtdConstants.ETD_TRADE_STATE_TO_DTCC);
		currEtdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_BATCHED);
		currEtdTradeJurisdiction.setJurisdiction(EtdConstants.ESMA_RPT_JURISDICTION);
		currEtdTradeJurisdiction.setRepository(EtdConstants.ETD_RPT_REPOSITORY);
		currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_TRUE);

		sdrRequest = context.getSdrRequest();
		if (null != sdrRequest)
		{
			sourceSystemMessageId = sdrRequest.getMessageId();
			currEtdTradeJurisdiction.setSourceSystemMessageId(sourceSystemMessageId);
			trade = sdrRequest.getTrade();
			if (null != trade)
			{
				regulatory = trade.getRegulatory();
				tradeHeader = trade.getTradeHeader();

			}

			if (null != tradeHeader)
			{
				isPosition = tradeHeader.isIsPosition();
				currEtdTradeJurisdiction.setTradeId(StringUtils.trimToEmpty(tradeHeader.getTradeId()));
			}

			if (null != isPosition) msgType = isPosition ? EtdConstants.ETD_MSG_POSITION : EtdConstants.ETD_MSG_TRANSACTION;

			if (regulatory != null)
			{
				reportingEligibility = regulatory.getReportingEligibility().get(0);

				if (null != reportingEligibility)
				{
					delegatedReporting = reportingEligibility.getDelegatedReporting();
				}

				if (null != reportingEligibility.getReportingParty())
				{
					submittedFor = reportingEligibility.getReportingParty().value();

					// if reportingparty is THEM and delegatedReporting is true - make IsReportable
					// as false
					// SDR need to supress reporting in this case
					if (null != submittedFor && null != delegatedReporting && submittedFor.equalsIgnoreCase(UsThemEnum.THEM.toString())
					        && delegatedReporting.equalsIgnoreCase(EtdConstants.ETD_DELEGATED_REPORT_TRUE))
					{
						currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_FALSE);
					}
				}

				List<Keyword> keyWordList = regulatory.getKeywords().getKeyword();
				for (Keyword currKeyword : keyWordList)
				{
					if (currKeyword.getName().equalsIgnoreCase(EtdConstants.DTCC_OUT_MSG))
					{
						dtccOutMsg = currKeyword.getValue();
					}

				}
			}
		}
		if (msgType != null)
		{
			currEtdTradeJurisdiction.setMsgType(msgType);
		}
		else
		{
			currEtdTradeJurisdiction.setMsgType(EtdConstants.ETD_MSG_TRANSACTION);

		}
		currEtdTradeJurisdiction.setOutputMessage(dtccOutMsg);

		logger.debug("exiting EtdTradeJurisdictionMapper  populateEtdTradeJurisdiction method");

		return currEtdTradeJurisdiction;
	}
	
	public EtdTradeJurisdiction populateEtdTradeJurisdictionForCompressionMsg(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		logger.debug("inside EtdTradeJurisdictionMapper  populateEtdTradeJurisdictionForCompressionMsg method");
		EtdTradeJurisdiction currEtdTradeJurisdiction = new EtdTradeJurisdiction();
		Date current_date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(EtdConstants.ETD_COBDATE_FORMAT);
		String cobDate = dateFormat.format(current_date);

		SdrRequest sdrRequest = null;
		TradeType trade = null;
		TradeHeaderType tradeHeader = null;
		String dtccOutMsgCompression = null;
		RegulatoryType regulatory = null;
		Boolean isPosition = false;
		String sourceSystemMessageId = null;
		String delegatedReporting = null;
		String submittedFor = null;
		ReportingEligibilityType reportingEligibility = null;

		currEtdTradeJurisdiction.setCobDate(cobDate);
		currEtdTradeJurisdiction.setCreateDatetime(current_date);
		currEtdTradeJurisdiction.setUpdateDatetime(current_date);
		currEtdTradeJurisdiction.setEtdPayload(etdPayload);
		currEtdTradeJurisdiction.setState(EtdConstants.ETD_TRADE_STATE_TO_DTCC);
		currEtdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_BATCHED);
		currEtdTradeJurisdiction.setJurisdiction(EtdConstants.ESMA_RPT_JURISDICTION);
		currEtdTradeJurisdiction.setRepository(EtdConstants.ETD_RPT_REPOSITORY);
		currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_TRUE);

		sdrRequest = context.getSdrRequest();
		if (null != sdrRequest)
		{
			sourceSystemMessageId = sdrRequest.getMessageId();
			currEtdTradeJurisdiction.setSourceSystemMessageId(sourceSystemMessageId);
			trade = sdrRequest.getTrade();
			if (null != trade)
			{
				regulatory = trade.getRegulatory();
				tradeHeader = trade.getTradeHeader();

			}

			if (null != tradeHeader)
			{
				isPosition = tradeHeader.isIsPosition();
				currEtdTradeJurisdiction.setTradeId(StringUtils.trimToEmpty(tradeHeader.getTradeId()));
			}

			if (regulatory != null)
			{
				reportingEligibility = regulatory.getReportingEligibility().get(0);

				if (null != reportingEligibility)
				{
					delegatedReporting = reportingEligibility.getDelegatedReporting();
				}

				if (null != reportingEligibility.getReportingParty())
				{
					submittedFor = reportingEligibility.getReportingParty().value();

					if (null != submittedFor && null != delegatedReporting && submittedFor.equalsIgnoreCase(UsThemEnum.THEM.toString())
					        && delegatedReporting.equalsIgnoreCase(EtdConstants.ETD_DELEGATED_REPORT_TRUE))
					{
						currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_FALSE);
					}
				}

				List<Keyword> keyWordList = regulatory.getKeywords().getKeyword();
				for (Keyword currKeyword : keyWordList)
				{
					if (currKeyword.getName().equalsIgnoreCase(EtdConstants.DTCC_OUT_MSG_COMPRESSION))
					{
						dtccOutMsgCompression = currKeyword.getValue();
					}

				}
			}
		}
		
		currEtdTradeJurisdiction.setMsgType(EtdConstants.ETD_MSG_COMPRESSION);
		currEtdTradeJurisdiction.setOutputMessage(dtccOutMsgCompression);

		logger.debug("exiting EtdTradeJurisdictionMapper  populateEtdTradeJurisdictionForCompressionMsg method");

		return currEtdTradeJurisdiction;
	}

	public EtdTradeJurisdiction populateEtdTradeJurisdiction(RegRepEtdValuationDtls regRepEtdValuationDtls) throws EtdMessageException
	{
		EtdTradeJurisdiction currEtdTradeJurisdiction = new EtdTradeJurisdiction();
		Date current_date = new Date();
		String reportable = null;

		if (null == regRepEtdValuationDtls) return null;
		currEtdTradeJurisdiction.setCobDate(regRepEtdValuationDtls.getCobDate());
		currEtdTradeJurisdiction.setMsgType(EtdConstants.VALUATION_RPT);
		currEtdTradeJurisdiction.setSourceSystemMessageId(regRepEtdValuationDtls.getSrcSysMessageId());
		currEtdTradeJurisdiction.setCreateDatetime(current_date);
		currEtdTradeJurisdiction.setUpdateDatetime(current_date);

		EtdPayload currEtdPayload = new EtdPayload();
		currEtdPayload.setMessageId(regRepEtdValuationDtls.getMessageId());
		currEtdTradeJurisdiction.setEtdPayload(currEtdPayload);

		currEtdTradeJurisdiction.setTradeId(regRepEtdValuationDtls.getTradeId());
		currEtdTradeJurisdiction.setState(EtdConstants.ETD_TRADE_STATE_TO_DTCC);

		reportable = regRepEtdValuationDtls.getReportable();
		if (reportable != null && reportable.equalsIgnoreCase(EtdConstants.ETD_FALSE))
		{
			currEtdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_BATCHED);
		}
		else
		{
			currEtdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_SUBMITTED);

		}		
		currEtdTradeJurisdiction.setJurisdiction(EtdConstants.ESMA_RPT_JURISDICTION);
		currEtdTradeJurisdiction.setRepository(EtdConstants.ETD_RPT_REPOSITORY);
		if (reportable != null && reportable.equalsIgnoreCase(EtdConstants.ETD_FALSE))
		{
			currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_FALSE);
		}
		else
		{
			currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_TRUE);
		}

		return currEtdTradeJurisdiction;

	}

	public EtdTradeJurisdiction populateEtdTradeJurisdiction(RegRepEtdCollateralDtls regRepEtdCollateralDtls) throws EtdMessageException
	{
		EtdTradeJurisdiction currEtdTradeJurisdiction = new EtdTradeJurisdiction();
		Date current_date = new Date();

		if (null == regRepEtdCollateralDtls) return null;
		currEtdTradeJurisdiction.setCobDate(regRepEtdCollateralDtls.getCobDate());
		currEtdTradeJurisdiction.setMsgType(EtdConstants.ETD_COLLATERL_VALUE_MSG);
		currEtdTradeJurisdiction.setSourceSystemMessageId(regRepEtdCollateralDtls.getSrcSysMessageId());
		currEtdTradeJurisdiction.setCreateDatetime(current_date);
		currEtdTradeJurisdiction.setUpdateDatetime(current_date);

		EtdPayload currEtdPayload = new EtdPayload();
		currEtdPayload.setMessageId(regRepEtdCollateralDtls.getMessageId());
		currEtdTradeJurisdiction.setEtdPayload(currEtdPayload);

		currEtdTradeJurisdiction.setTradeId(regRepEtdCollateralDtls.getTradePartyLei());
		currEtdTradeJurisdiction.setState(EtdConstants.ETD_TRADE_STATE_TO_DTCC);
		
		if (null != regRepEtdCollateralDtls.getSuppressReporting() && regRepEtdCollateralDtls.getSuppressReporting().equalsIgnoreCase(EtdConstants.ETD_TRUE))
		{
			currEtdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_BATCHED);
		}
		else
		{
			currEtdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_SUBMITTED);
		}
		
		
		currEtdTradeJurisdiction.setJurisdiction(EtdConstants.ESMA_RPT_JURISDICTION);
		currEtdTradeJurisdiction.setRepository(EtdConstants.ETD_RPT_REPOSITORY);

		if (null != regRepEtdCollateralDtls.getSuppressReporting() && regRepEtdCollateralDtls.getSuppressReporting().equalsIgnoreCase(EtdConstants.ETD_TRUE))
		{
			currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_FALSE);

		}
		else
		{
			currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_TRUE);
		}

		return currEtdTradeJurisdiction;

	}
	
	public EtdTradeJurisdiction insertForRegRepCollateralMsg( RegRepCollateralAgreements regRepCollateralAgreements) throws EtdMessageException
	{
		EtdTradeJurisdiction currEtdTradeJurisdiction = new EtdTradeJurisdiction();
		
		Date current_date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(EtdConstants.ETD_COBDATE_FORMAT);
		String cobDate = dateFormat.format(current_date);

		if (null == regRepCollateralAgreements) return null;
		currEtdTradeJurisdiction.setCobDate(cobDate);
		currEtdTradeJurisdiction.setMsgType(Constants.EOD_REGREP_COLLATERALVALUE);
		//currEtdTradeJurisdiction.setSourceSystemMessageId(regRepEtdCollateralDtls.getSrcSysMessageId());
		currEtdTradeJurisdiction.setCreateDatetime(current_date);
		currEtdTradeJurisdiction.setUpdateDatetime(current_date);

		EtdPayload currEtdPayload = new EtdPayload();
		currEtdPayload.setMessageId(regRepCollateralAgreements.getMessageId());
		currEtdTradeJurisdiction.setEtdPayload(currEtdPayload);

	//	currEtdTradeJurisdiction.setTradeId(regRepEtdCollateralDtls.getTradePartyLei());
		currEtdTradeJurisdiction.setState(EtdConstants.ETD_TRADE_STATE_TO_DTCC);
		
		currEtdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_BATCHED);		
		
		currEtdTradeJurisdiction.setJurisdiction(EtdConstants.ESMA_RPT_JURISDICTION);
		currEtdTradeJurisdiction.setRepository(EtdConstants.ETD_RPT_REPOSITORY);
		
		currEtdTradeJurisdiction.setIsReportable(EtdConstants.ETD_TRUE);	

		return currEtdTradeJurisdiction;

	}

}
