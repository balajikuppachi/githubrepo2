package com.wellsfargo.regulatory.persister.helper.mapper;

public enum PeriodEnums {


	D(1),W(2),M(3),Y(4),T(5);
	
	private final Integer value;

	PeriodEnums(int num)
	{
		value=num;
	}
	
	public int getValue() {
		return value;
	}
	
	 public static Integer enumValue(String v) {
		 
		 if(null != v)
		 {
	        for (PeriodEnums c: PeriodEnums.values()) {
	            if (v.equals(c.toString())) {
	                return c.value;
	            }
	        }
	        
		 } 
	        throw new IllegalArgumentException(v);
	    }
}
