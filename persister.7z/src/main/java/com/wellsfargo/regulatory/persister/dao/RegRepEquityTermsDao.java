package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepEquityTerms;

public interface RegRepEquityTermsDao extends Dao<RegRepEquityTerms>, Serializable
{
	
	public List<RegRepEquityTerms> loadRegRepEuqityTermsByUsi(String usi);

}
