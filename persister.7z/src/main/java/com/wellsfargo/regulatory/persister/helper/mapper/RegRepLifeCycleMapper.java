package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.NovationType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepClearing;
import com.wellsfargo.regulatory.persister.dto.RegRepLifecycle;
import com.wellsfargo.regulatory.persister.dto.RegRepNovation;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepLifeCycleMapper
{

	private static Logger logger = Logger.getLogger(RegRepLifeCycleMapper.class.getName());

	public RegRepLifecycle createRegRepLifecycle(RegRepTradeHeader dbTradeHeader, LifeCycleType iplifecycle)
	{

		RegRepLifecycle dbLifecycle = null;
		ClearingType ipClearing = null;
		RegRepClearingMapper clearingMapper = null;
		RegRepClearing dbClearing = null;
		NovationType ipNovation = null;
		RegRepNovationMapper novationMapper = null;
		RegRepNovation dbNovation = null;

		if (null == dbTradeHeader || null == iplifecycle)
		{
			logger.debug("RegRepLifecycle object could not be " + "populated due to invalid incoming data");
			return dbLifecycle;
		}

		dbLifecycle = new RegRepLifecycle();
		dbLifecycle.setRegRepTradeHeader(dbTradeHeader);

		ipClearing = iplifecycle.getClearing();
		if (null != ipClearing)
		{

			clearingMapper = new RegRepClearingMapper();
			dbClearing = clearingMapper.createRegRepClearing(ipClearing, dbLifecycle);
		}

		ipNovation = iplifecycle.getNovation();
		if (null != ipNovation)
		{

			novationMapper = new RegRepNovationMapper();
			dbNovation = novationMapper.createRegRepNovation(dbLifecycle, ipNovation);
		}

		dbLifecycle.setAllocatedFrom(iplifecycle.getAllocatedFrom());
		dbLifecycle.setCounterpartyAffirmedTimestamp(CalendarUtils.toDate(iplifecycle.getCounterpartyAffirmedTimestamp()));
		dbLifecycle.setEventEffectiveDate(CalendarUtils.toDate(iplifecycle.getEventEffectiveDate()));
		dbLifecycle.setEventExecutionDateTime(CalendarUtils.toDate(iplifecycle.getEventExecutionDateTime()));
		dbLifecycle.setEventType(iplifecycle.getEventType());
		dbLifecycle.setInternalConfirmRequired(ConversionUtils.booleanToDbString(iplifecycle.isInternalConfirmRequired()));
		dbLifecycle.setOriginalNotional(ConversionUtils.bigDecimalToDouble(iplifecycle.getOriginalNotional()));
		dbLifecycle.setParentSubAllocated(ConversionUtils.booleanToDbString(iplifecycle.isParentSubAllocated()));
		dbLifecycle.setPortfolioCompression(iplifecycle.getPortfolioCompression());
		dbLifecycle.setRegRepClearing(dbClearing);

		/*
		 * @Comment : Amit Rana Need not be set, else hibernate creates a duplicate object
		 * dbLifecycle.setRegRepMessageId(dbTradeHeader.getRegRepMessageId());
		 */

		dbLifecycle.setRegRepNovation(dbNovation);
		dbLifecycle.setTransferFrom(iplifecycle.getTransferFrom());
		
		dbLifecycle.setAllocationAgent(iplifecycle.getAllocationAgent());
		
		if(null != iplifecycle.getAllocationTrade())
			dbLifecycle.setAllocationTrade(iplifecycle.getAllocationTrade().value());
		
		dbLifecycle.setPostEventEffectiveDate(CalendarUtils.toDate(iplifecycle.getPostEventEffectiveDate()));
		dbLifecycle.setPostEventTransactionDate(CalendarUtils.toDate(iplifecycle.getPostEventTransactionDate()));

		return dbLifecycle;
	}

}
