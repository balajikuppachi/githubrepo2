package com.wellsfargo.regulatory.persister.etd.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeDtls;

public interface EtdTradeDtlsDao extends Serializable, Dao<EtdTradeDtls>
{

}
