package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;

public interface RegRepDsMappingDao extends Serializable {

	List<RegRepDomainMapping> findAll();

}
