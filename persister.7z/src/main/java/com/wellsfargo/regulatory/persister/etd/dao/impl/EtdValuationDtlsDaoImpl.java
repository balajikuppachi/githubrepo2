package com.wellsfargo.regulatory.persister.etd.dao.impl;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.etd.dao.EtdValuationDtlsDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdValuationDtls;

public class EtdValuationDtlsDaoImpl extends AbstractDaoImpl<EtdValuationDtls> implements EtdValuationDtlsDao
{
	/**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    
    @Override
	public Class<EtdValuationDtls> getEntityClass()
	{
		return EtdValuationDtls.class;
	}
    

}
