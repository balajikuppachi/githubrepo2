package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepLifecycleDao;
import com.wellsfargo.regulatory.persister.dto.RegRepLifecycle;

public class RegRepLifecycleDaoImpl extends AbstractDaoImpl<RegRepLifecycle> implements RegRepLifecycleDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2970268564527128873L;

	@Override
	public Class<RegRepLifecycle> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepLifecycle.class;
	}


}
