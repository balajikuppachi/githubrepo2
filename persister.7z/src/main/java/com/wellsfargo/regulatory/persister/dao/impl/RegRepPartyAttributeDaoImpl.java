package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepPartyAttributeDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPartyAttribute;

public class RegRepPartyAttributeDaoImpl extends AbstractDaoImpl<RegRepPartyAttribute> implements RegRepPartyAttributeDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1005712922466554931L;

	@Override
	public Class<RegRepPartyAttribute> getEntityClass()
	{
		// TODO Auto-generated method stub
		return null;
	}



}
