package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodExtValData;

@Component
public class RegRepEodExtValDataDaoImpl implements RowMapper<RegRepEodExtValData>

{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${regRep.eod.cdbo.env}")
	String CDBO_ENV;

	@Value("${regRep.eod.galaxy.env}") 
	String EQUITY_ENVI;
	
	public List<RegRepEodExtValData> getNpvData(List<String> tradeIds )
	{
	
		Map<String,Object>  params = new HashMap<String, Object>();
		
		params.put("reportIds", tradeIds);
		String npvQuery = "SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM REG_REP_EOD_EXT_VAL_DATA WHERE fo_trade_id in (:reportIds) ";
		NamedParameterJdbcTemplate namedParameterJdbcTemplate=new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		List<RegRepEodExtValData> queryresult = namedParameterJdbcTemplate.query(npvQuery, params,this);
		return queryresult;
	}

	public List<RegRepEodExtValData> getNpvData( )
	{
		String npvQuery = "SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM REG_REP_EOD_EXT_VAL_DATA WHERE source_system = '"+  CDBO_ENV  + "'";
		List<RegRepEodExtValData> queryresult = jdbcTemplate.query(npvQuery, this);
		return queryresult;
	}
	
	public List<RegRepEodExtValData> getEquityNpvData()
	{
		String npvQuery = "SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM REG_REP_EOD_EXT_VAL_DATA WHERE source_system in ('"+EQUITY_ENVI+"')";
		List<RegRepEodExtValData> queryresult = jdbcTemplate.query(npvQuery, this);
		return queryresult;
	}
	
	public List<RegRepEodExtValData> getNpvDataByTradeId(String tradeId  )
	{
		String npvQuery = "SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM REG_REP_EOD_EXT_VAL_DATA WHERE fo_trade_id = ? ";
		List<RegRepEodExtValData> queryresult = jdbcTemplate.query(npvQuery ,new Object[]{tradeId }, this);
		return queryresult;
	}

	@Override
	public RegRepEodExtValData mapRow(ResultSet rs, int rowNum)		throws SQLException 
	{
		RegRepEodExtValData dto = new RegRepEodExtValData();
		dto.setFoTradeId( rs.getString( 1 ) );
		dto.setSourceSystem( rs.getString( 2 ) );
		dto.setStatus( rs.getString( 3 ) );
		dto.setNpvValue( rs.getBigDecimal(4));
		dto.setNpvDate( rs.getTimestamp(5 ) );
		dto.setNpvCurrency( rs.getString( 6 ) );
		dto.setNotionalCurrent( rs.getString( 7 ) );
		dto.setPayNotional( rs.getString( 8 ) );
		dto.setRecvNotional( rs.getString( 9 ) );
		dto.setPayCurrency( rs.getString( 10 ) );
		dto.setRecvCurrency( rs.getString( 11 ) );
		return dto;

	}

}
