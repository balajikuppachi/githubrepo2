package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author Raji Komatreddy
 */
public class RegRepAllegeMessage implements Serializable
{
	private static final long serialVersionUID = 1L;

	private long allegeMessageId;	
	private String inreplyto;
	private String sentBy;
	private String sentTo;
	private String status;
	private String reportType;
	private String jurisdiction;
	private String usiPrefix;
	private String usi;
	private String tradeID;
	private String party1Lei;
	private String party1Name;
	private String party1Address;
	private String party2Lei;
	private String party2Name;
	private String party2Address;	
	private Timestamp createDatetime;

	public long getAllegeMessageId()
	{
		return allegeMessageId;
	}

	public void setAllegeMessageId(long allegeMessageId)
	{
		this.allegeMessageId = allegeMessageId;
	}
	

	public String getInreplyto()
	{
		return inreplyto;
	}

	public void setInreplyto(String inreplyto)
	{
		this.inreplyto = inreplyto;
	}

	public String getSentBy()
	{
		return sentBy;
	}

	public void setSentBy(String sentBy)
	{
		this.sentBy = sentBy;
	}

	public String getSentTo()
	{
		return sentTo;
	}

	public void setSentTo(String sentTo)
	{
		this.sentTo = sentTo;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getReportType()
	{
		return reportType;
	}

	public void setReportType(String reportType)
	{
		this.reportType = reportType;
	}

	public String getJurisdiction()
	{
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction)
	{
		this.jurisdiction = jurisdiction;
	}

	public String getUsiPrefix()
	{
		return usiPrefix;
	}

	public void setUsiPrefix(String usiPrefix)
	{
		this.usiPrefix = usiPrefix;
	}

	public String getUsi()
	{
		return usi;
	}

	public void setUsi(String usi)
	{
		this.usi = usi;
	}

	public String getTradeID()
	{
		return tradeID;
	}

	public void setTradeID(String tradeID)
	{
		this.tradeID = tradeID;
	}

	public String getParty1Lei()
	{
		return party1Lei;
	}

	public void setParty1Lei(String party1Lei)
	{
		this.party1Lei = party1Lei;
	}

	public String getParty1Name()
	{
		return party1Name;
	}

	public void setParty1Name(String party1Name)
	{
		this.party1Name = party1Name;
	}

	public String getParty1Address()
	{
		return party1Address;
	}

	public void setParty1Address(String party1Address)
	{
		this.party1Address = party1Address;
	}

	public String getParty2Lei()
	{
		return party2Lei;
	}

	public void setParty2Lei(String party2Lei)
	{
		this.party2Lei = party2Lei;
	}

	public String getParty2Name()
	{
		return party2Name;
	}

	public void setParty2Name(String party2Name)
	{
		this.party2Name = party2Name;
	}

	public String getParty2Address()
	{
		return party2Address;
	}

	public void setParty2Address(String party2Address)
	{
		this.party2Address = party2Address;
	}

	

	public Timestamp getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Timestamp createDatetime)
	{
		this.createDatetime = createDatetime;
	}

}
