package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepEquityTerms;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;

public class RegRepEquityTermsMapper
{
	private static Logger logger = Logger.getLogger(RegRepExerciseProvisionMapper.class.getName());
	
	public RegRepEquityTerms createRegRepEquityTerms(EquityTermsType equityTerms,  RegRepProduct dbProduct)
	{
		RegRepEquityTerms regRepEquityTerms = null;
		
		if (null == equityTerms || null == dbProduct)
		{
			logger.debug("RegRepEquityTerms object could not be " + "populated due to invalid incoming data");
			return regRepEquityTerms;
		}
		
		regRepEquityTerms= new RegRepEquityTerms();
		regRepEquityTerms.setRegRepProduct(dbProduct);
		//regRepEquityTerms.setRegRepProductId(dbProduct.getRegRepProductId());
		regRepEquityTerms.setVegaNotional(ConversionUtils.bigDecimalToDouble(equityTerms.getVegaNotional()));
		regRepEquityTerms.setChangeInVegaNotional(ConversionUtils.bigDecimalToDouble(equityTerms.getChangeInVegaNotional()));	
		
		
		if(equityTerms.isNonStandardFlag())		
			regRepEquityTerms.setNonStandardFlag(Constants.RULES_APP_TRUE);
		else
			regRepEquityTerms.setNonStandardFlag(Constants.RULES_APP_FALSE);
			
		if(equityTerms.isEmbeddedOption())		
			regRepEquityTerms.setEmbeddedOption(Constants.RULES_APP_TRUE);
		else
			regRepEquityTerms.setEmbeddedOption(Constants.RULES_APP_FALSE);
		
		regRepEquityTerms.setValuationFrequencyPeriod(equityTerms.getValuationFrequencyPeriod());
		Integer valFreqPeriodMul = ConversionUtils.bigDecimalToInteger(equityTerms.getValuationFrequencyPeriodMultiplier());
		if(null != valFreqPeriodMul){
			regRepEquityTerms.setValuationFrequencyPeriodMultiplier(valFreqPeriodMul);
		} 
		regRepEquityTerms.setFinalValuationDate(CalendarUtils.toDate(equityTerms.getFinalValuationDate()));
		regRepEquityTerms.setEquityVarianceStrikePrice(ConversionUtils.bigDecimalToDouble(equityTerms.getEquityVarianceStrikePrice()));
		
		
		return regRepEquityTerms;
		
	}

}
