package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodPayload;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodReport;

/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class RegRepEodPayloadDaoImpl implements RowMapper<RegRepEodPayload>
{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	String insertQuery = "INSERT INTO REG_REP_EOD_PAYLOAD (EOD_REPORT_ID, PAYLOAD, REPORT_TYPE, PAYLOAD_TMESTAMP) VALUES(?, ?, ?, ?)";
	
	String updateValuationActiveFlagQuery = " delete from REG_REP_EOD_PAYLOAD where REPORT_TYPE = 'Valuation' and EOD_REPORT_ID in ( select rp.EOD_REPORT_ID from REG_REP_EOD_REPORT rp  where  rp.SWAP_TRADE_ID = ? and  "
			+ " rp.IS_ACTIVE = '1' and rp.JURISDICTION = ?  and rp.ASSET_CLASS  =  ?  and rp.REPORT_TYPE = 'Valuation' )"; 
	
	String latestEodPayloadQuery = "select  TOP 1 ep.PAYLOAD,rp.ACTION_TYPE,rp.EVENT_TYPE,rp.EOD_REPORT_ID,rp.COB_DATE from REG_REP_EOD_REPORT rp, REG_REP_EOD_PAYLOAD  ep where rp.EOD_REPORT_ID = ep.EOD_REPORT_ID  and "
			+ "rp.SWAP_TRADE_ID = ? and ep.REPORT_TYPE = ? and rp.JURISDICTION = ? order by rp.INSERT_TIMESTAMP desc";

	String updateEodPayloadQryForRefresh = "UPDATE REG_REP_EOD_PAYLOAD SET PAYLOAD = ? WHERE EOD_REPORT_ID = ? ";
	
	@Override
    public RegRepEodPayload mapRow(ResultSet rs, int row) throws SQLException
    {
		RegRepEodPayload currRegRepEodPayload = new RegRepEodPayload();
	    return currRegRepEodPayload;
    }
	
	public boolean insertRegRepPayload(RegRepEodPayload regRepEodPayload)
	{
		boolean successful = false;
		jdbcTemplate.update(insertQuery, new Object[] {regRepEodPayload.getEodReportId(), regRepEodPayload.getPayload(),
				             regRepEodPayload.getReportType(), regRepEodPayload.getPayloadTimeStamp()});
		successful= true;
		
		return successful;
	}
	
	public boolean updateRegRepEodPayloadForRefresh(ReportingContext rptContext)
	{
		boolean successful = false;
		
		jdbcTemplate.update(updateEodPayloadQryForRefresh, new Object[]{rptContext.getPayload(), rptContext.getEodRefreshRptId()});
		successful = true;
		
		return successful;
	}
	
	
	public boolean deleteValuationFromEodPayload(RegRepEodReport regRepEodReport)
	{
		boolean successful = false;
		jdbcTemplate.update(updateValuationActiveFlagQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getJurisdiction(), regRepEodReport.getAssetClass() });
		successful= true;
		
		return successful;
	}
	
	public List<RegRepEodPayload> getLastReportedBuffer(RegRepEodReport regRepEodReport)
	{
		
		List<RegRepEodPayload> queryResult = jdbcTemplate.query(latestEodPayloadQuery, new Object[] {regRepEodReport.getSwapTradeId(), regRepEodReport.getReportType(),regRepEodReport.getJurisdiction()},new RowMapper() {
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				RegRepEodPayload regRepEodPayload=new RegRepEodPayload();
				regRepEodPayload.setPayload(rs.getString(1));
				regRepEodPayload.setReportType(rs.getString(2));
				regRepEodPayload.setLifeCycleEvent(rs.getString(3));
				regRepEodPayload.setEodReportId(rs.getString(4));
				regRepEodPayload.setPayloadTimeStamp(rs.getTimestamp(5));
				return regRepEodPayload;
			}
			
		});
		return queryResult;
	}
	

}
