package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepNovation;

public interface RegRepNovationDao extends Dao<RegRepNovation>, Serializable
{

}
