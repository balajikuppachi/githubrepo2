package com.wellsfargo.regulatory.persister.helper;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse;
import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.enums.RegRepMessageTypeEum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepMessageRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepMessageRegulatoryId;
import com.wellsfargo.regulatory.persister.dto.RegRepPayload;
import com.wellsfargo.regulatory.persister.dto.RegRepPortfolioCount;
import com.wellsfargo.regulatory.persister.dto.RegRepReconTrioptima;
import com.wellsfargo.regulatory.persister.dto.RegRepReport;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMappingId;
import com.wellsfargo.regulatory.persister.etd.dto.EtdCollateralDtls;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeDtls;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;
import com.wellsfargo.regulatory.persister.etd.dto.EtdValuationDtls;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdCollateralDtlsMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdTradeDtlsMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdTradeJurisdictionMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdValuationDtlsMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepMessageMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepPayloadMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepPortfolioCountMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepReconMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepResponseMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepSdrRequestMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepTradeMapper;
import com.wellsfargo.regulatory.persister.trioptima.parser.RegRepTrioptimaParser;

public class XmlToDtoHelper
{
	private static Logger logger = Logger.getLogger(XmlToDtoHelper.class.getName());

	public String populateTrade(ReportingContext context, RegRepMessage payloadMessage) throws MessagingException
	{
		logger.debug("Entering populateTrade() method");
		
		RegRepSdrRequestMapper reqMapper 	= new RegRepSdrRequestMapper();
		RegRepMessageMapper msgMapper 		= new RegRepMessageMapper();
		RegRepTradeMapper tradeMapper 		= new RegRepTradeMapper();

		Set<RegRepMessage> messages = new HashSet<RegRepMessage>();
		// Set<RegRepPayload> payloads = new HashSet<RegRepPayload>();
		RegRepTrade trade = tradeMapper.createRegRepTrade(context);

		/*** payload message will either be a new nessage or the updated message in case the payload has already been persisted ***/
		payloadMessage = msgMapper.createMessageFromInputXML(context, trade, null, payloadMessage);
		
		// RegRepPayload payload = createPayloadFromInputXML(context, message);
		Set<RegRepMessageRegulatory> regs = createMessageRegulatoryFromInputXML(context, payloadMessage);

		if (PayloadTypeEnum.REG_REP_XML.equals(context.getContextType())
				|| PayloadTypeEnum.REG_REP_FILTERED.equals(context.getContextType())) 
			payloadMessage.setRegRepSdrRequest(reqMapper.createSdrRequest(context, payloadMessage));

		payloadMessage.setRegRepMessageRegulatories(regs);
		messages.add(payloadMessage);
		trade.setRegRepMessages(messages);

		logger.debug(" Populated Trade with swap trade Id: " + trade.getSwapTradeId() + " for Persistence Type:  " + context.getContextType());

		logger.debug("Leaving populateTrade() method");

		return trade.getSwapTradeId();
	}

	public RegRepReport populateReport(ReportingContext context, RegRepMessage message, RegRepTrade trade) throws MessagingException
	{
		logger.debug("Entering populateReport() method");

		Set<RegRepMessageRegulatory> regs 	= null;
		RegRepMessageMapper msgMapper 		= new RegRepMessageMapper();
		RegRepPayloadMapper payloadMapper 	= new RegRepPayloadMapper();
		RegRepMessage repMessage 			= null;
		RegRepReport report 				= null;
		Set<RegRepPayload> payloads 		= new HashSet<RegRepPayload>();
		RegRepPayload payload 				= null;

		repMessage 	= msgMapper.createMessageFromInputXML(context, trade, null, null);
		regs 		= createMessageRegulatoryFromInputXML(context, repMessage);
		report 		= createReportFromInputXML(context, repMessage);

		repMessage.setRegRepMessageBySrcRegRepMessageId(message);
		payload = payloadMapper.createRegRepPayload(context, repMessage);
		payloads.add(payload);

		repMessage.setRegRepPayloads(payloads);
		repMessage.setRegRepMessageRegulatories(regs);
		repMessage.setRegRepReport(report);

		report.setRegRepMessage(repMessage);
		logger.debug(" Populated Report with: " + repMessage.getRegRepMessageId() + " for Persistence Type:  " + context.getContextType());
		
		logger.debug("Leaving populateReport() method");

		return report;
	}

	/**
	 * @author Amit Rana
	 * @param context
	 * @param parentMessage
	 * @return regRepMessage
	 * @throws MessagingException
	 */
	public RegRepMessage populateResponse(ReportingContext context, RegRepMessage parentMessage, RegRepTrade trade, RegRepMessage payloadMessage) throws MessagingException
	{
		logger.debug("Entering populateResponse() method");

		String errorString = null;
		FpMLResponse response = null;
		RegRepResponseMapper resMapper = null;
		RegRepResponse dbResponse = null;
		RegRepMessageMapper msgMapper = null;

		if (null == context)
		{
			errorString = "Unable to populate RegRepResponse since incoming context was null";
			logger.error("########## " + errorString);

			throw new MessagingException("Dto-hlpr:122", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		response = context.getResponse();

		if (null == response)
		{
			errorString = "No response embedded inside context";
			logger.error("########## " + errorString);

			return payloadMessage;
		}

		if (null == parentMessage)
		{
			/*
			 * This is where we are the non reporting party. Need to handle this separately by
			 * matching trade details. Returning for now.
			 */
			payloadMessage.setMessageType(RegRepMessageTypeEum.SDR_NRP_NOTIFICATION.type());
			payloadMessage.setIsReportingParty(Constants.APP_FALSE);

			// Since lazy loaded false, trade object should be null inside message
			payloadMessage.setRegRepTrade(trade);

			logger.info("An NRP trade persisted with messageId :" + payloadMessage.getRegRepMessageId());

		}
		else
		{
			// Setting the the parent(source) message of response
			payloadMessage.setRegRepMessageBySrcRegRepMessageId(parentMessage);

			msgMapper = new RegRepMessageMapper();
			payloadMessage = msgMapper.createMessageFromInputXML(context, trade, parentMessage, payloadMessage);
		}

		resMapper = new RegRepResponseMapper();

		if (PayloadTypeEnum.SDR_RESPONSE_ACK.equals(context.getContextType()))
		{
			dbResponse = resMapper.createRegRepResponse(response, payloadMessage, Constants.DTCC_RESPONSE_ACK);
		}
		else if (PayloadTypeEnum.SDR_RESPONSE_NACK.equals(context.getContextType()))
		{
			dbResponse = resMapper.createRegRepResponse(response, payloadMessage, Constants.DTCC_RESPONSE_NACK);
		}

		payloadMessage.setRegRepResponse(dbResponse);

		logger.info(" Populated Response with: " + payloadMessage.getRegRepMessageId() + " for Persistence Type:  <<<<<< " + context.getContextType() + " >>>>>> ");

		logger.debug("Leaving populateResponse() method");

		return payloadMessage;

	}

	public RegRepMessage createPayloadFromInputXML(ReportingContext context, RegRepMessage message) throws MessagingException
	{
		logger.debug("Entering createPayloadFromInputXML() method");

		Set<RegRepPayload> payloadSet = null;
		RegRepPayloadMapper payloadMapper = null;
		RegRepPayload payload = null;

		payloadMapper = new RegRepPayloadMapper();

		payload = payloadMapper.createRegRepPayload(context, message);

		if (null != payload)
		{
			payloadSet = new HashSet<RegRepPayload>();
			payloadSet.add(payload);
		}

		message.setRegRepPayloads(payloadSet);

		logger.debug("Leaving createPayloadFromInputXML() method");

		return message;
	}

	private RegRepReport createReportFromInputXML(ReportingContext context, RegRepMessage message)
	{
		logger.debug("Entering createReportFromInputXML() method");

		RegRepReport repObject = new RegRepReport();

		List<String> reportTypes = context.getReportTypes();
		if (reportTypes != null && !reportTypes.isEmpty())
		{
			repObject.setSdrMessageType(reportTypes.get(0));
		}

		repObject.setSubmissionTimestamp(context.getSubmissionTimestamp());
		repObject.setIsAcknowledged(Constants.APP_PENDING);
		repObject.setIsCompliant(Constants.APP_FALSE);
		repObject.setIsDuplicate(ConversionUtils.booleanToDbString(context.isDuplicateReport()));

		repObject.setRegRepMessage(message);

		logger.debug("Leaving createReportFromInputXML() method");

		return repObject;
	}

	public Set<RegRepMessageRegulatory> createMessageRegulatoryFromInputXML(ReportingContext context, RegRepMessage message)
	{
		logger.debug("Entering createMessageRegulatoryFromInputXML() method");

		RegRepMessageRegulatory msgRegulatory 			= null;
		RegRepMessageRegulatoryId msgRegulatoryId 		= null;
		Set<RegRepMessageRegulatory> msgRegulatories 	= new HashSet<RegRepMessageRegulatory>();
		String[] ipRegulatory 							= null;

		int id = 1;

		if (PayloadTypeEnum.REG_REP_XML.equals(context.getContextType()) || PayloadTypeEnum.REG_REP_FILTERED.equals(context.getContextType()))
		{
			logger.debug("Inside if-block createMessageRegulatoryFromInputXML():PayloadTypeEnum.REG_REP_XML|REG_REP_FILTERED ");
			
			for (ReportingEligibilityType reportingEligibility : context.getSdrRequest().getTrade().getRegulatory().getReportingEligibility())
			{
				msgRegulatory 	= new RegRepMessageRegulatory();
				msgRegulatoryId = new RegRepMessageRegulatoryId();
				msgRegulatoryId.setRegRepMessageId(message.getRegRepMessageId());
				msgRegulatoryId.setRegRepMessageRegulatoryId(id++);

				if (null != reportingEligibility.getReportingJurisdiction()) msgRegulatory.setReportingJurisdiction(reportingEligibility.getReportingJurisdiction().value());

				if (null != reportingEligibility.getReportingParty()) 
					msgRegulatory.setReportingParty(reportingEligibility.getReportingParty().value());
				else
					msgRegulatory.setReportingParty(Constants.NOT_AVAILABLE);
								
				if (null != reportingEligibility.getRepository()) msgRegulatory.setRepository(reportingEligibility.getRepository().value());

				msgRegulatory.setId(msgRegulatoryId);
				msgRegulatory.setRegRepMessage(message);
				msgRegulatories.add(msgRegulatory);
			}
		}
		else if (PayloadTypeEnum.FpML.equals(context.getContextType()) )
		{
			logger.debug("Inside else-if-block createMessageRegulatoryFromInputXML():PayloadTypeEnum.FpML ");
			
			for (String reg : context.getCurrJurisdiction())
			{
				if (null == reg) continue;

				for (String jurs : context.getRegulatories().keySet())
				{
					if (null != jurs && jurs.startsWith(reg))
					{
						msgRegulatory = new RegRepMessageRegulatory();
						msgRegulatoryId = new RegRepMessageRegulatoryId();
						msgRegulatoryId.setRegRepMessageId(message.getRegRepMessageId());
						msgRegulatoryId.setRegRepMessageRegulatoryId(id++);

						ipRegulatory = jurs.split(Constants.UNDERSCORE);
						
						if (null != ipRegulatory)
						{
							if (ipRegulatory.length > 0)
							{
								msgRegulatory.setReportingJurisdiction(ipRegulatory[0]);
							}

							if (ipRegulatory.length > 1)
							{
								msgRegulatory.setRepository(ipRegulatory[1]);
							}

							msgRegulatory.setReportingParty(UsThemEnum.US.value());
						}

						msgRegulatory.setId(msgRegulatoryId);
						msgRegulatory.setRegRepMessage(message);
						msgRegulatories.add(msgRegulatory);
					}
				}

			}
		}
		else if (PayloadTypeEnum.SDR_RESPONSE_ACK.equals(context.getContextType()) || PayloadTypeEnum.SDR_RESPONSE_NACK.equals(context.getContextType()))
		{
			logger.debug("Inside else-if-block createMessageRegulatoryFromInputXML():PayloadTypeEnum.SDR_RESPONSE_ACK|SDR_RESPONSE_NACK ");

			if (context.getRegulatories() == null || context.getRegulatories().isEmpty())
				return null;
			
			for (String jurs : context.getRegulatories().keySet())
			{

				msgRegulatory = new RegRepMessageRegulatory();
				msgRegulatoryId = new RegRepMessageRegulatoryId();
				msgRegulatoryId.setRegRepMessageId(message.getRegRepMessageId());
				msgRegulatoryId.setRegRepMessageRegulatoryId(id++);

				ipRegulatory = jurs.split(Constants.UNDERSCORE);
				
				if (null != ipRegulatory)
				{
					if (ipRegulatory.length > 0)
					{
						msgRegulatory.setReportingJurisdiction(ipRegulatory[0]);
					}

					if (ipRegulatory.length > 1)
					{
						msgRegulatory.setRepository(ipRegulatory[1]);
					}
					
					msgRegulatory.setReportingParty(UsThemEnum.US.value());
				}
				
				msgRegulatory.setId(msgRegulatoryId);
				msgRegulatory.setRegRepMessage(message);
				msgRegulatories.add(msgRegulatory);
			}
		}

		logger.debug("Leaving createMessageRegulatoryFromInputXML() method");

		return msgRegulatories;
	}

	public RegRepUniqueIdentifierMapping getUniqueIdentifierObject(SdrRequest request)
	{
		logger.debug("Entering getUniqueIdentifierObject() method");

		RegRepUniqueIdentifierMapping usiMap = null;
		String value = ReportingDataUtils.getKeyWordContents(request.getTrade().getRegulatory().getKeywords(), Constants.IS_GTR_USI);
		String usiValue = ReportingDataUtils.getKeyWordContents(request.getTrade().getRegulatory().getKeywords(), Constants.USI_VALUE);
	
		/**Do persist in REG_REP_UNIQUE_IDENTIFIER_MAPPING only if the a record is not available for this trade*/
		if (ConversionUtils.stringToBoolean(value) && StringUtils.equalsIgnoreCase(Constants.GTRCREATE, usiValue))
		{
			usiMap = new RegRepUniqueIdentifierMapping();
			usiMap.setCreateDatetime(CalendarUtils.getCurrentDateInUTC());
			usiMap.setCurrentValue(Constants.NULL);
			usiMap.setUpdateDatetime(CalendarUtils.getCurrentDateInUTC());

			RegRepUniqueIdentifierMappingId id = new RegRepUniqueIdentifierMappingId();
			id.setIdentifierType(Constants.USI);
			id.setJurisdiction(Constants.CFTC);
			id.setRepository(Constants.DTCC);
			id.setTradeId(request.getTrade().getTradeHeader().getTradeId());

			usiMap.setId(id);
		}

		logger.debug("Leaving getUniqueIdentifierObject() method");

		return usiMap;
	}

	/**
	 * populates EtdTradeDtls and EtdTradeJurisdiction details using mapper classes
	 * 
	 * @param context
	 * @param etdPayload
	 * @return
	 */

	public EtdTradeDtls createEtdTradeDtlsFromInputXml(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		logger.debug("Entering createEtdTradeDtlsFromInputXml() method");

		EtdTradeDtlsMapper etdTradeDtlsMapper = new EtdTradeDtlsMapper();
		//EtdTradeJurisdictionMapper etdTradeJurisdictionMapper = new EtdTradeJurisdictionMapper();

		//Set<EtdTradeJurisdiction> etdTradeJurisdictionSet = new HashSet<EtdTradeJurisdiction>();

		EtdTradeDtls currEtdTradeDtls = etdTradeDtlsMapper.populateEtdTradeDtls(context, etdPayload);
		// EtdTradeJurisdiction currEtdTradeJurisdiction =
		// etdTradeJurisdictionMapper.populateEtdTradeJurisdiction(context, etdPayload);

		// etdTradeJurisdictionSet.add(currEtdTradeJurisdiction);

		etdPayload.setEtdTradeDtls(currEtdTradeDtls);
		// etdPayload.setEtdTradeJurisdictions(etdTradeJurisdictionSet);

		logger.debug("Leaving createEtdTradeDtlsFromInputXml() method");

		return currEtdTradeDtls;
	}
	
	
	public EtdTradeJurisdiction createEtdTradeJurisDictionFromInputXml(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		logger.debug("Entering createEtdTradeJurisDictionFromInputXml() method");

		EtdTradeJurisdictionMapper etdTradeJurisdictionMapper = new EtdTradeJurisdictionMapper();

		Set<EtdTradeJurisdiction> etdTradeJurisdictionSet = new HashSet<EtdTradeJurisdiction>();

		EtdTradeJurisdiction currEtdTradeJurisdiction = etdTradeJurisdictionMapper.populateEtdTradeJurisdiction(context, etdPayload);
		etdTradeJurisdictionSet.add(currEtdTradeJurisdiction);
		
		etdPayload.setEtdTradeJurisdictions(etdTradeJurisdictionSet);

		logger.debug("Leaving createEtdTradeJurisDictionFromInputXml() method");

		return currEtdTradeJurisdiction;

	}
	
	public EtdTradeJurisdiction createEtdTradeJurisDictionForCompressionMsg(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		logger.debug("Entering createEtdTradeJurisDictionForCompressionMsg() method");

		EtdTradeJurisdictionMapper etdTradeJurisdictionMapper = new EtdTradeJurisdictionMapper();

		Set<EtdTradeJurisdiction> etdTradeJurisdictionSet = new HashSet<EtdTradeJurisdiction>();

		EtdTradeJurisdiction compressionEtdTradeJurisdiction = etdTradeJurisdictionMapper.populateEtdTradeJurisdictionForCompressionMsg(context, etdPayload);
		etdTradeJurisdictionSet.add(compressionEtdTradeJurisdiction);
		
		etdPayload.setEtdTradeJurisdictions(etdTradeJurisdictionSet);

		logger.debug("Leaving createEtdTradeJurisDictionForCompressionMsg() method");

		return compressionEtdTradeJurisdiction;

	}

	public EtdValuationDtls createEtdValuationDtlsFromInputXml(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		EtdValuationDtlsMapper etdValuationDtlsMapper = new EtdValuationDtlsMapper();
		EtdValuationDtls currEtdValuationDtls = etdValuationDtlsMapper.populateEtdValuationDtls(context, etdPayload);

		return currEtdValuationDtls;
	}

	public EtdCollateralDtls createEtdCollateralDtlsFromInputXml(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		EtdCollateralDtlsMapper etdCollateralDtlsMapper = new EtdCollateralDtlsMapper();
		EtdCollateralDtls currEtdCollateralDtls = etdCollateralDtlsMapper.populateEtdCollateralDtls(context, etdPayload);

		return currEtdCollateralDtls;
	}

	public RegRepMessage updateMessageFlags(RegRepMessage message, ReportingContext context)
	{
		logger.debug("Entering updateMessageFlags() method");

		if(null == message || null == context) return message;
		
		message.setIsReportingParty(ConversionUtils.booleanToDbString(context.isReportingParty()));
		message.setIsReportable(ConversionUtils.booleanToDbString(context.isReportable()));
		message.setIsFiltered(ConversionUtils.booleanToDbString(context.isFiltered()));
		message.setIsInvalid(ConversionUtils.booleanToDbString(context.isInvalid()));
		
		message.setRegRepMessagUpdateTimestamp(new Date());

		logger.debug("Leaving updateMessageFlags() method");

		return message;
	}

	public RegRepSdrRequest populateSdrRequest(RegRepMessage message, ReportingContext context)
	{
		logger.debug("Entering populateSdrRequest() method");

		RegRepSdrRequest request 			= null;
		RegRepSdrRequestMapper reqMapper 	= null;

		if (null == message || null == context)
			return request;

		try 
		{
			reqMapper = new RegRepSdrRequestMapper();
			message.setMessageType(RegRepMessageTypeEum.REG_REP_CONF_ALERT.name());

			request = reqMapper.createSdrRequest(context, message);

		} 
		catch (MessagingException e) 
		{
			logger.error("Failed to create confirmation object. ", e);
		}

		logger.debug("Leaving populateSdrRequest() method");
		
		return request;
	}
	
	public RegRepPortfolioCount populateCount(RegRepPortfolioCount dbCount, String status, ReportingContext context, boolean isCleared)
	{
		logger.debug("Entering populateCount() method");

		RegRepPortfolioCountMapper 	mapper 		= null;
		RegRepPortfolioCount		tempCount	= null;	
		String						lce			= null;
		boolean 					newCount	= false;
		boolean 					hasExpired	= false;	
		String tradeType= null,sdrAction=null;
		
		if(null == context)
			return dbCount;
		
		mapper 		= new RegRepPortfolioCountMapper();
		lce	 		= context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();
		tradeType	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);
		sdrAction = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.SDR_ACTION_DERIVED_EVENT);
		
		if(null == dbCount)
		{
			newCount = true;
			dbCount = mapper.createRegRepPortfolioCount(context);
		}
		else
		{
			tempCount = mapper.createRegRepPortfolioCount(context);
			
			if(null != tempCount)
			{
				dbCount.setCounterpartyName(tempCount.getCounterpartyName());
				dbCount.setCounterpartyDsig(tempCount.getCounterpartyDsig());
				dbCount.setUpdateTimestamp(tempCount.getUpdateTimestamp());
			}
		}
		
		if(null != lce)
			hasExpired = ReportingDataUtils.hasTradeExpired(lce, status, isCleared,tradeType,sdrAction);
		
		if(hasExpired)
		{
			if(dbCount.getRegRepCount() > 0)
				dbCount.setRegRepCount(dbCount.getRegRepCount() - 1L);
		}
		else
		{
			if(!newCount)
				dbCount.setRegRepCount(dbCount.getRegRepCount() + 1L);
		}
		
		logger.debug("Leaving populateCount() method");

		return dbCount;
	}
	
	public RegRepReconTrioptima createReconMapper(ReportingContext context, boolean isTradeActive, RegRepReconTrioptima regRepRecon, RegRepTrioptimaParser regRepTrioptimaParser)
	{
		logger.debug("Entering Create Recon method");
		RegRepReconMapper reconMapper = new RegRepReconMapper();
				
		regRepRecon = reconMapper.mapRegRepRecon(context, isTradeActive, regRepRecon, regRepTrioptimaParser);
		
		return regRepRecon;
	}

}
