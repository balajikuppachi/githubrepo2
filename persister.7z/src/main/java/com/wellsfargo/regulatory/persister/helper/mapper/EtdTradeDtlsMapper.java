package com.wellsfargo.regulatory.persister.helper.mapper;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeDtls;

/**
 * @author Raji Komatreddy
 */
public class EtdTradeDtlsMapper
{
	private static Logger logger = Logger.getLogger(RegRepMessageMapper.class.getName());

	public EtdTradeDtls populateEtdTradeDtls(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{

		Date current_date = new Date();
		String usi = null;
		String uti = null;
		EtdTradeDtls etdTrade = null;
		String errorString = null;
		String party1LeiPrefix = null;
		String party1LeiValue = null;
		String party2LeiPrefix = null;
		String party2LeiValue = null;
		Boolean isPosition = false;
		LifeCycleType lifeCycle = null;

		if (context == null)
		{
			return null;
		}

		SdrRequest sdrReq = context.getSdrRequest();
		ProductKeysType productKey = sdrReq.getTrade().getTradeDetail().getProduct().getProductKeys();
		TradeHeaderType tradeHeader = sdrReq.getTrade().getTradeHeader();

		etdTrade = new EtdTradeDtls();

		SimpleDateFormat dateFormat = new SimpleDateFormat(EtdConstants.ETD_COBDATE_FORMAT);
		String cobDate = dateFormat.format(current_date);

		if (null == productKey)
		{
			errorString = "Invalid input data. productKey is null. Aborting Trade Object creation";
			logger.error("########## " + errorString);

			throw new EtdMessageException("EtdTradeDtlsMapper:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		if (null != tradeHeader)
		{
			party1LeiPrefix = StringUtils.substringBefore(tradeHeader.getProcessingOrgLEI(), ":");
			party1LeiValue = StringUtils.substringAfter(tradeHeader.getProcessingOrgLEI(), ":");

			party2LeiPrefix = StringUtils.substringBefore(tradeHeader.getCounterpartyLEI(), ":");
			party2LeiValue = StringUtils.substringAfter(tradeHeader.getCounterpartyLEI(), ":");

			String msgType = null;
			isPosition = tradeHeader.isIsPosition();
			msgType = isPosition ? EtdConstants.ETD_MSG_POSITION : EtdConstants.ETD_MSG_TRANSACTION;

			lifeCycle = tradeHeader.getLifeCycle();

			etdTrade.setCobDate(cobDate);
			etdTrade.setAssetClass(sdrReq.getAssetClass());
			etdTrade.setMsgType(msgType);
			etdTrade.setParty1Lei(party1LeiValue);
			etdTrade.setParty2Lei(party2LeiValue);
			etdTrade.setEventType(tradeHeader.getAction());
		}

		usi = StringUtils.trimToEmpty(productKey.getUSI());
		uti = StringUtils.trimToEmpty(productKey.getUTI());

		if (null == usi && null == uti)
		{
			errorString = "Invalid input data. Both USI and UTI is null. Aborting Trade Object creation";
			logger.error("########## " + errorString);

			throw new EtdMessageException("EtdTradeDtlsMapper:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		etdTrade.setTradeId(StringUtils.trimToEmpty(tradeHeader.getTradeId()));
		etdTrade.setUsi(usi);
		etdTrade.setUti(uti);
		etdTrade.setSrcSystemType(StringUtils.trimToEmpty(sdrReq.getSource()));
		etdTrade.setPreviousUsi(StringUtils.trimToEmpty(productKey.getPrevUSI()));
		if (null != tradeHeader.getTradeVersion()) etdTrade.setTradeVersion(tradeHeader.getTradeVersion());
		etdTrade.setCreateDatetime(current_date);
		etdTrade.setMessageId(StringUtils.trimToEmpty(context.getMessageId()));
		etdTrade.setTradeStatus(StringUtils.trimToEmpty(tradeHeader.getStatus()));
		etdTrade.setUpdateDatetime(current_date);
		etdTrade.setEtdPayload(etdPayload);

		return etdTrade;

	}

}
