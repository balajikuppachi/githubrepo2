package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.Set;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.DocumentationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeInfoType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartiesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.persister.dto.RegRepDocumentation;
import com.wellsfargo.regulatory.persister.dto.RegRepFee;
import com.wellsfargo.regulatory.persister.dto.RegRepParty;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepTradeDetailMapper
{

	private static Logger logger = Logger.getLogger(RegRepTradeDetailMapper.class.getName());

	public RegRepTradeDetail createRegRepTradeDetail(TradeDetailType ipTradeDetail, RegRepSdrRequest regRepSdrRequest)
	{

		RegRepTradeDetail tradeDetail = null;
		FeeInfoType ipFee = null;
		TradePartiesType ipParties = null;
		ProductType ipProduct = null;
		DocumentationType documentation = null;
		RegRepFeeMapper feeMapper = null;
		RegRepPartyMapper ptyMapper = null;
		RegRepDocumentationMapper docMapper = null;
		RegRepDocumentation dbDocumentation = null;
		Set<RegRepFee> feeSet = null;
		Set<RegRepParty> partySet = null;
		Set<RegRepProduct> productSet = null;
		RegRepFee fee = null;
		RegRepParty dbParty = null;
		int feeId = 1;
		int partyId = 1;

		if (null == ipTradeDetail || null == regRepSdrRequest)
		{
			logger.debug("RegRepTradeDetail object could not be " + "populated due to invalid incoming data");
			return tradeDetail;
		}

		documentation = ipTradeDetail.getDocumentation();
		ipFee = ipTradeDetail.getFeeInfo();
		ipParties = ipTradeDetail.getTradeParties();
		ipProduct = ipTradeDetail.getProduct();
		docMapper = new RegRepDocumentationMapper();

		tradeDetail = new RegRepTradeDetail();

		tradeDetail.setRegRepSdrRequest(regRepSdrRequest);

		dbDocumentation = docMapper.createRegRepDocumentation(documentation, tradeDetail);

		if (null != ipFee)
		{

			feeMapper = new RegRepFeeMapper();
			feeSet = new HashSet<RegRepFee>(5);

			for (FeeType feeType : ipFee.getFee())
			{
				fee = feeMapper.createRegRepFee(feeType, tradeDetail, feeId);
				feeSet.add(fee);
				feeId++;
			}
		}
		else
		{
			logger.debug("Unable to persist fee info, " + "since incoming data doesn't have fee type populated");
		}

		if (null != ipParties)
		{

			ptyMapper = new RegRepPartyMapper();
			partySet = new HashSet<RegRepParty>();

			for (TradePartyType ipParty : ipParties.getParty())
			{
				dbParty = ptyMapper.createRegRepParty(ipParty, tradeDetail, partyId);
				partySet.add(dbParty);
				partyId++;
			}
		}
		else
		{
			logger.debug("Unable to persist Parties, " + "since incoming data doesn't have Trade Parties populated");
		}

		if (null != ipProduct)
		{

			productSet = new HashSet<RegRepProduct>();
			getProducSet(ipProduct, productSet, tradeDetail, null);

		}
		else
		{
			logger.debug("Unable to persist Parties, " + "since incoming data doesn't have Trade Parties populated");
		}

		tradeDetail.setRegRepDocumentation(dbDocumentation);
		tradeDetail.setRegRepFees(feeSet);

		/*
		 * @Comment : Amit Rana Need not be set, else hibernate creates a duplicate object
		 * tradeDetail.setRegRepMessageId(regRepSdrRequest.getRegRepMessage().getRegRepMessageId());
		 */

		tradeDetail.setRegRepParties(partySet);
		tradeDetail.setRegRepProducts(productSet);

		logger.debug("Successfully created REG_REP_TRADE_DETAIL object");
		return tradeDetail;
	}

	private Set<RegRepProduct> getProducSet(ProductType ipProduct, Set<RegRepProduct> productSet, RegRepTradeDetail tradeDetail, String parentProductType)
	{

		RegRepProductMapper productMapper = null;
		RegRepProduct dbProduct = null;

		if (null == ipProduct || null == productSet)
		{
			logger.debug("Product list object could not be " + "populated due to invalid incoming data");
			return productSet;
		}

		productMapper = new RegRepProductMapper();
		dbProduct = productMapper.createRegRepProduct(ipProduct, tradeDetail, parentProductType);
		productSet.add(dbProduct);

		for (ProductType subProduct : ipProduct.getProduct())
		{

			if (null != subProduct)
			{

				getProducSet(subProduct, productSet, tradeDetail, ipProduct.getProductType());
			}
		}

		return productSet;
	}

}
