package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.AmortizationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.StepParamsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.StepScheduleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.StepType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepAmortization;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;
import com.wellsfargo.regulatory.persister.dto.RegRepStep;
import com.wellsfargo.regulatory.persister.dto.RegRepStepId;
import com.wellsfargo.regulatory.persister.dto.RegRepStepParams;
import com.wellsfargo.regulatory.persister.dto.RegRepStepSchedule;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepAmortizationMapper
{

	private static Logger logger = Logger.getLogger(RegRepAmortizationMapper.class.getName());

	public RegRepAmortization createRegRepAmortization(RegRepProduct dbProduct, AmortizationType ipAmortization)
	{

		RegRepAmortization dbAmortization = null;
		boolean isStepSchedule = false;
		boolean isStepParam = false;
		StepParamsType stepParam = null;
		StepScheduleType stepSchedule = null;
		RegRepStepParams dbStepParams = null;
		RegRepStepSchedule dbStepSchedule = null;

		if (null == dbProduct || null == ipAmortization)
		{
			logger.debug("RegRepAmortization object could not be " + "populated due to invalid incoming data");
			return dbAmortization;
		}

		dbAmortization = new RegRepAmortization();
		dbAmortization.setRegRepProduct(dbProduct);
		// dbAmortization.setRegRepAmortizationId(dbProduct.getRegRepProductId());

		stepParam = ipAmortization.getStepParams();
		stepSchedule = ipAmortization.getStepSchedule();

		if (null != stepParam)
		{
			isStepParam = true;
			dbStepParams = createStepParams(stepParam, dbAmortization);
		}

		if (null != stepSchedule)
		{
			isStepSchedule = true;
			dbStepSchedule = createStepSchedule(stepSchedule, dbAmortization);
		}

		dbAmortization.setIsStepParams(ConversionUtils.booleanToDbString(isStepParam));
		dbAmortization.setIsStepSchedule(ConversionUtils.booleanToDbString(isStepSchedule));

		dbAmortization.setRegRepStepParams(dbStepParams);
		dbAmortization.setRegRepStepSchedule(dbStepSchedule);

		return dbAmortization;
	}

	private RegRepStepParams createStepParams(StepParamsType ipStepParam, RegRepAmortization dbAmortization)
	{

		RegRepStepParams stepParams = null;

		if (null == ipStepParam || null == dbAmortization)
		{
			logger.debug("RegRepStepParams object could not be " + "populated due to invalid incoming data");
			return stepParams;
		}

		stepParams = new RegRepStepParams();

		stepParams.setDayCountFraction(ipStepParam.getDayCountFraction());
		stepParams.setFirstStepDate(CalendarUtils.toDate(ipStepParam.getFirstStepDate()));
		stepParams.setLastStepDate(CalendarUtils.toDate(ipStepParam.getLastStepDate()));
		stepParams.setRegRepAmortization(dbAmortization);
		// stepParams.setRegRepStepParamsId(dbAmortization.getRegRepProduct().getRegRepProductId());
		stepParams.setStepAmount(ipStepParam.getStepAmount() + "");
		stepParams.setStepFrequency(ipStepParam.getStepFrequency());
		stepParams.setStepRate(ipStepParam.getStepRate() + "");

		return stepParams;
	}

	private RegRepStepSchedule createStepSchedule(StepScheduleType ipStepShedule, RegRepAmortization dbAmortization)
	{

		RegRepStepSchedule stepSchedule = null;
		List<StepType> ipSteps = null;
		RegRepStep dbStep = null;
		Set<RegRepStep> dbStepsSet = null;
		int stepId = 1;

		if (null == ipStepShedule || null == dbAmortization)
		{
			logger.debug("RegRepStepSchedule object could not be " + "populated due to invalid incoming data");
			return stepSchedule;
		}

		stepSchedule = new RegRepStepSchedule();
		stepSchedule.setRegRepAmortization(dbAmortization);
		// stepSchedule.setRegRepStepScheduleId(dbAmortization.getRegRepProduct().getRegRepProductId());

		ipSteps = ipStepShedule.getStep();

		if (null != ipSteps)
		{

			dbStepsSet = new HashSet<RegRepStep>(8);
			for (StepType ipStep : ipSteps)
			{

				dbStep = createRegRepStep(stepSchedule, ipStep, stepId++);
				dbStepsSet.add(dbStep);
			}

		}
		else
		{
			logger.debug("Unable to persist steps, " + "since step schedule data doesn't have steps populated");
		}

		stepSchedule.setInitialValue(ipStepShedule.getInitialValue() + "");
		stepSchedule.setRegRepSteps(dbStepsSet);

		return stepSchedule;
	}

	private RegRepStep createRegRepStep(RegRepStepSchedule dbSchedule, StepType ipStep, int id)
	{

		RegRepStep dbStep = null;
		RegRepStepId stepid = null;

		if (null == dbSchedule || null == ipStep)
		{
			logger.debug("RegRepStep object could not be " + "populated due to invalid incoming data");
			return dbStep;
		}

		dbStep = new RegRepStep();
		dbStep.setRegRepStepSchedule(dbSchedule);

		stepid = createRegRepStepId(dbSchedule, id);
		dbStep.setId(stepid);

		dbStep.setStepDate(CalendarUtils.toDate(ipStep.getStepDate()));
		dbStep.setStepValue(ipStep.getStepValue() + "");

		return dbStep;
	}

	private RegRepStepId createRegRepStepId(RegRepStepSchedule dbSchedule, int id)
	{

		RegRepStepId stepId = null;

		if (null == dbSchedule)
		{
			logger.debug("RegRepStepId object could not be " + "populated due to invalid incoming data");
			return stepId;
		}

		stepId = new RegRepStepId();

		stepId.setRegRepStepId(dbSchedule.getRegRepAmortization().getRegRepProduct().getRegRepProductId());
		stepId.setSequenceId(id);

		return stepId;
	}

}
