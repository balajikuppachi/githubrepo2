package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepProcessLog;

public interface RegRepProcessLogDao extends Dao<RegRepProcessLog>, Serializable
{

}
