package com.wellsfargo.regulatory.persister.recon.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepIceOpenTransaction;

public interface RegRepIceOpenTransactionDao extends Dao<RegRepIceOpenTransaction>, Serializable{

	List<RegRepIceOpenTransaction> findAll(Date date);

}
