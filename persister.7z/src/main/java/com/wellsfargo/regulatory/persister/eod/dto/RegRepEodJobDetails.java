package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 
 * @author Raji Komatreddy
 * DTO ojbect for REG_REP_EOD_JOB_DETAILS
 *
 */
public class RegRepEodJobDetails implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private long jobDetailsId;
	private String jobType;
	private String jobName;
	private String jobDesc;
	private String jobFreq;
	private Timestamp createDatetime;
	private String onDemandParams;
	private String reportType;
	private String assetClass;
	private String jurisdiction;

	public long getJobDetailsId()
	{
		return jobDetailsId;
	}

	public void setJobDetailsId(long jobDetailsId)
	{
		this.jobDetailsId = jobDetailsId;
	}

	public String getJobType()
	{
		return jobType;
	}

	public void setJobType(String jobType)
	{
		this.jobType = jobType;
	}

	public String getJobName()
	{
		return jobName;
	}

	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}

	public String getJobDesc()
	{
		return jobDesc;
	}

	public void setJobDesc(String jobDesc)
	{
		this.jobDesc = jobDesc;
	}

	public String getJobFreq()
	{
		return jobFreq;
	}

	public void setJobFreq(String jobFreq)
	{
		this.jobFreq = jobFreq;
	}

	public Timestamp getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Timestamp createDatetime)
	{
		this.createDatetime = createDatetime;
	}
	
	public String getOnDemandParams()
	{
		return onDemandParams;
	}

	public void setOnDemandParams(String onDemandParams)
	{
		this.onDemandParams = onDemandParams;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	@Override
    public String toString()
    {
	    StringBuilder builder = new StringBuilder();
	    builder.append("RegRepEodJobDetails [jobDetailsId=");
	    builder.append(jobDetailsId);
	    builder.append(", jobType=");
	    builder.append(jobType);
	    builder.append(", jobName=");
	    builder.append(jobName);
	    builder.append(", jobDesc=");
	    builder.append(jobDesc);
	    builder.append(", jobFreq=");
	    builder.append(jobFreq);
	    builder.append(", createDatetime=");
	    builder.append(createDatetime);
	    builder.append(", onDemandParams=");
	    builder.append(onDemandParams);
	    builder.append(", reportType=");
	    builder.append(reportType);
	    builder.append(", assetClass=");
	    builder.append(assetClass);
	    builder.append(", jurisdiction=");
	    builder.append(jurisdiction);
	    builder.append("]");
	    return builder.toString();
    }	


}
