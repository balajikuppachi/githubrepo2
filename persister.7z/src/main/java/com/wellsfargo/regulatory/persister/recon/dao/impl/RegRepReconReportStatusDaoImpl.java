package com.wellsfargo.regulatory.persister.recon.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepReconReportStatusDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportStatus;

/**
 * @author Raji Komatreddy
 */
public class RegRepReconReportStatusDaoImpl extends AbstractDaoImpl<RegRepReconReportStatus> implements RegRepReconReportStatusDao
{

	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(RegRepReconReportStatusDaoImpl.class.getName());
	
    private JdbcTemplate m_jdbcTemplate;
    
    public JdbcTemplate getJdbcTemplate() 
    {
        return m_jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) 
    {
        m_jdbcTemplate = jdbcTemplate;
    }

	@Override
	public Class<RegRepReconReportStatus> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepReconReportStatus.class;
	}


	//getSession() method deprecated in Spring4
	@SuppressWarnings("unchecked")
	public RegRepReconReportStatus getReconReportStatusByReportDate(Date reportDate, String sourceSystem)
	{
		Query queryObject = null;
		RegRepReconReportStatus regRepReconReportStatus = null;
		List<Object[]> objs = null;
		Object reconReportObj = null;
		try
		{
			//queryObject = getSession().getNamedQuery(RegRepReconReportStatus.GET_RECON_REPORT_STATUS_BY_REPORTDATE);
			queryObject =   currentSession().getNamedQuery(RegRepReconReportStatus.GET_RECON_REPORT_STATUS_BY_REPORTDATE);
			queryObject.setDate("reportDate", reportDate);
			queryObject.setString("sourceSystem", sourceSystem);
			objs = queryObject.list();

			if (null != objs && objs.size() > 0)
			{
				reconReportObj = objs.get(0);
				if (reconReportObj instanceof RegRepReconReportStatus)
				{
					regRepReconReportStatus = (RegRepReconReportStatus) reconReportObj;
				}
			}

		}
		catch (Exception ex)
		{
			logger.error("Exception occurred inside RegRepReconReportStatusDaoImpl: while getting data from RegRepReconReportStatus " 
		                        + ExceptionUtils.getStackTrace(ex));
			return regRepReconReportStatus;
		}

		return regRepReconReportStatus;

	}

}
