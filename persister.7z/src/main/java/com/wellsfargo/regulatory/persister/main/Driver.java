package com.wellsfargo.regulatory.persister.main;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.enums.RegRepMessageTypeEum;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.commons.utils.ResponseUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepExceptionDao;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageRegulatoryDao;
import com.wellsfargo.regulatory.persister.dao.RegRepOrigPayloadDao;
import com.wellsfargo.regulatory.persister.dao.RegRepPayloadDao;
import com.wellsfargo.regulatory.persister.dao.RegRepPortfolioCountDao;
import com.wellsfargo.regulatory.persister.dao.RegRepReconTrioptimaDao;
import com.wellsfargo.regulatory.persister.dao.RegRepReportDao;
import com.wellsfargo.regulatory.persister.dao.RegRepSdrRequestDao;
import com.wellsfargo.regulatory.persister.dao.RegRepTradeDao;
import com.wellsfargo.regulatory.persister.dao.RegRepUniqueIdentifierMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepMessageRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepOrigPayload;
import com.wellsfargo.regulatory.persister.dto.RegRepPortfolioCount;
import com.wellsfargo.regulatory.persister.dto.RegRepReconTrioptima;
import com.wellsfargo.regulatory.persister.dto.RegRepReport;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;
import com.wellsfargo.regulatory.persister.etd.dao.EtdCollateralDtlsDao;
import com.wellsfargo.regulatory.persister.etd.dao.EtdPayloadDao;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeDtlsDao;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dao.EtdValuationDtlsDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdCollateralDtls;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeDtls;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;
import com.wellsfargo.regulatory.persister.etd.dto.EtdValuationDtls;
import com.wellsfargo.regulatory.persister.helper.XmlToDtoHelper;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdPayloadMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepMessageMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepOrigPayloadMapper;
import com.wellsfargo.regulatory.persister.trioptima.parser.RegRepTrioptimaParser;

/**
 * @author Pavithrini Kota
 * @date 08/23/2014
 * @version 1.0
 */

public class Driver
{
	private RegRepMessageDao regRepMessageDao;
	private RegRepTradeDao regRepTradeDao;
	private RegRepPayloadDao regRepPayloadDao;
	private RegRepReportDao regRepReportDao;
	private RegRepMessageRegulatoryDao regRepMessageRegulatoryDao;
	private RegRepUniqueIdentifierMappingDao regRepUniqueIdentifierMappingDao;
	private RegRepSdrRequestDao regRepSdrRequestDao;
	private RegRepExceptionDao regRepExceptionDao;
	private RegRepOrigPayloadDao regRepOrigPayloadDao;
	private RegRepPortfolioCountDao portfolioCountDao;
	private String inputMessageSource;
	private String responseMessageSource;
	private EtdPayloadDao etdPayloadDao;
	private EtdTradeDtlsDao etdTradeDtlsDao;
	private EtdTradeJurisdictionDao etdTradeJurisdictionDao;
	private EtdValuationDtlsDao etdValuationDtlsDao;
	private EtdCollateralDtlsDao etdCollateralDtlsDao;
	private RegRepReconTrioptimaDao regRepReconTrioptimaDao;
	private RegRepTrioptimaParser regRepTrioptimaParser;

	private static Logger logger = Logger.getLogger(Driver.class.getName());

	public RegRepTradeDao getRegRepTradeDao()
	{
		return regRepTradeDao;
	}

	public void setRegRepTradeDao(RegRepTradeDao regRepTradeDao)
	{
		this.regRepTradeDao = regRepTradeDao;
	}

	public void persistResponse(Message<?> message) throws MessagingException
	{
		logger.debug("Entering persistResponse() method");
		
		String errorString 						= null;
		RegRepOrigPayloadMapper payloadMapper 	= null;
		RegRepOrigPayload origPayload 			= null;
		String msgSource 						= null;
		RegRepMessage regRepMessage 			= null;
		String parentMessageId 					= null;
		String sdrMessageId 					= null;
		String extMessageId 					= null;
		RegRepTrade tradeObject 				= null;

		/*** No checks performed, based on the assumption that sanity check is done by the calling method. ***/
		// return;

		ReportingContext context = (ReportingContext) message.getPayload();
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		if (null == context.getMessageId())
		{
			errorString = "Null incoming message Id. Response persistance failed";
			logger.error("########## " + errorString);

			// throw new MessagingException("Prst:Res:1", ExceptionSeverityEnum.ERROR,
			// ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		/*
		 * This block is to persist the payload with a blank message only. Once the message/response
		 * is parsed this blank message is appropriately updated.
		 */

		logger.info("Persisting Response for messageId : " + context.getMessageId());

		try
		{

			msgSource = context.getMessageSource();

			if (null == msgSource || inputMessageSource.equals(msgSource))
			{
				payloadMapper 	= new RegRepOrigPayloadMapper();
				sdrMessageId 	= context.getMessageId();

				if (null != message.getHeaders())
				{
					if (null == message.getHeaders().get("messageId"))
						extMessageId = "DEV-MsgId-Test";
					else
						extMessageId = (String)message.getHeaders().get("messageId");
				}

				logger.debug("Fetching message object for the reg rep response....");
				
				// Context will have swap trade id set only after sdrRequest's persistence 
				if(null != context.getSwapTradeId())
				{
					regRepMessage = regRepMessageDao.findMsgAndTradeByPrimaryKeyNS(sdrMessageId);
					
					/*** Message Found ***/
					if(null != regRepMessage)
						tradeObject = regRepTradeDao.findByPrimaryKeyNS(context.getSwapTradeId());
				}
				else
				{
					regRepMessage = regRepMessageDao.findByPrimaryKeyNS(sdrMessageId);
					
					if(null != regRepMessage && null != regRepMessage.getSwapTradeId())
					{
						tradeObject = regRepTradeDao.findByPrimaryKeyNS(regRepMessage.getSwapTradeId());						
					}
					else
					{
						tradeObject = null;					
					}					
				}

				if (null == regRepMessage)
				{
					logger.error("######### Unable to find the Reg Rep Message for message id --> " + sdrMessageId);
					return;
				}			

			}
			else if (responseMessageSource.equals(msgSource))
			{
				parentMessageId = context.getResponse().getInReplyTo();
				
				if (null != parentMessageId)
				{
					logger.debug("Fetching message object for the report....");
					
					regRepMessage 	= regRepMessageDao.findMsgAndTradeByPrimaryKeyNS(parentMessageId);
					tradeObject 	=  regRepTradeDao.findByPrimaryKeyNS(regRepMessage.getSwapTradeId());

					if (null != regRepMessage)
					{
						logger.debug("Fetching message object for the request....");
						regRepMessage = regRepMessage.getRegRepMessageBySrcRegRepMessageId();
					}

					if (null == regRepMessage)
					{
						logger.error("######### Unable to find the RegRepMessage for message id --> " + sdrMessageId);
						return;
					}
				}

				extMessageId = regRepMessage.getExternalMessageId();
				if (null == extMessageId) extMessageId = "dummyMessagedId";
			} 
			else if (null != msgSource && msgSource.equalsIgnoreCase(Constants.FPML_REPORT_TYPE))
			{
				sdrMessageId = context.getSrcMessageId();
				
				if(null != context.getSwapTradeId())
				{
					regRepMessage = regRepMessageDao.findMsgAndTradeByPrimaryKeyNS(sdrMessageId);
					
					/*** Message Found ***/
					if(null != regRepMessage)
						tradeObject = regRepTradeDao.findByPrimaryKeyNS(context.getSwapTradeId());
				}
				else
				{
					regRepMessage = regRepMessageDao.findByPrimaryKeyNS(sdrMessageId);
					
					if(null != regRepMessage.getSwapTradeId())
					{
						tradeObject = regRepTradeDao.findByPrimaryKeyNS(regRepMessage.getSwapTradeId());						
					}
					else
					{
						tradeObject = null;					
					}					
				}

				if (null == regRepMessage)
				{
					logger.error("######### Unable to find the RegRepMessage for message id --> " + sdrMessageId);
					return;
				}
				
				extMessageId = regRepMessage.getExternalMessageId();
				if (null == extMessageId) extMessageId = "dummyMessagedId";
			}

			// -- Embedding the complete trade object
			// findMsgAndTradeByPrimaryKeyNS -- gets the entire trade object
			regRepMessage.setRegRepTrade(tradeObject);

			if (null == regRepMessage.getRegRepTrade() || null == regRepMessage.getRegRepTrade().getSwapTradeId()) 
				regRepMessage.setRegRepTrade(null);

			payloadMapper 	= new RegRepOrigPayloadMapper();
			origPayload 	= payloadMapper.createResponseOrigPayloadMessage(extMessageId, message, regRepMessage);

			logger.debug("DB call initiated for Response message payload persistence....");
			regRepOrigPayloadDao.save(origPayload);

			logger.info("Response successfully persisted");
		}
		catch (Exception e)
		{

			errorString = "Response persistence failed as : " + e.getMessage();
			logger.error("########## " + errorString);

			// throw new MessagingException("Rsp:prst:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		logger.debug("Leaving persistResponse() method");

		return;
	}

	public void persistPayload(Message<?> message) throws MessagingException
	{
		logger.debug("Entering persistResponse() method");

		String errorString 					= null;
		XmlToDtoHelper xmlToDtoHelper 		= null;
		String msgSource 					= null;
		EtdPayloadMapper etdPayloadMapper 	= null;
		EtdPayload etdPayload 				= null;
		RegRepMessageMapper msgMapper 		= null;
		RegRepMessage regRepMessage 		= null;
		RegRepOrigPayloadMapper payloadMapper = null;
		RegRepOrigPayload origPayload 		= null;

		/*** No checks performed, based on the assumption that sanity check is done by the calling method. ***/
		ReportingContext context = (ReportingContext) message.getPayload();
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		xmlToDtoHelper = new XmlToDtoHelper();
		
		if (null == context.getMessageId())
		{
			errorString = "Null incoming message Id. Payload persistance failed";
			logger.error("########## " + errorString);

			throw new MessagingException("Persist-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		/*
		 * This block is to persist the payload with a blank message only. Once the message/response
		 * is parsed this blank message is appropriately updated.
		 */

		logger.info("Persisting payload for messageId : " + context.getMessageId());
		// Persist into ETD_PAYLOAD if msgSource is of ETD_REQUEST

		try
		{
			msgSource = context.getMessageSource();
			
			if (msgSource != null && EtdConstants.ETD_REQUEST.equalsIgnoreCase(msgSource))
			{
				etdPayloadMapper 	= new EtdPayloadMapper();
				etdPayload 			= etdPayloadMapper.createFromContext(context);
				
				logger.debug("DB call initiated for payload persistence in ETD_PAYLOAD table....");
				etdPayloadDao.save(etdPayload);
			}
			else
			{
				msgMapper 		= new RegRepMessageMapper();
				regRepMessage 	= msgMapper.createDefaultRegRepMessage(context.getMessageId(), RegRepMessageTypeEum.REG_REP_PAYLOAD);
				xmlToDtoHelper.createPayloadFromInputXML(context, regRepMessage);

				logger.debug("DB call initiated for payload persistence....");
				regRepMessageDao.save(regRepMessage);

				if (null == msgSource || inputMessageSource.equals(msgSource))
				{
					payloadMapper 	= new RegRepOrigPayloadMapper();
					origPayload 	= payloadMapper.createDefaultOrigPayloadMessage(message, PayloadTypeEnum.STV.name(), regRepMessage);
					
					logger.debug("DB call initiated for original message payload persistence....");
					regRepOrigPayloadDao.save(origPayload);
				}
			}

			logger.info("Payload successfully persisted");
		}
		catch (Exception e)
		{

			errorString = "Payload persistence failed as : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Pyld:prst:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		logger.debug("Leaving persistResponse() method");

		return;

	}

	public void persist(ReportingContext context) throws MessagingException
	{
		logger.debug("Entering persist() method");

		String errorString 				= null;
		XmlToDtoHelper helper 			= null;
		String payloadType 				= null;
		String parentMessageId 			= null;
		RegRepMessage parentMessage 	= null;
		RegRepMessage message 			= null;
		RegRepReport report 			= null;
		RegRepUniqueIdentifierMapping uniqueUsi = null;
		RegRepTrade trade 				= null;
		RegRepTrade parentTrade 		= null;
		String msgSource 				= null;
		EtdPayload etdPayload 			= null;
		Boolean valuationAlert 			= false;
		Boolean collateralAlert 		= false;
		String tradeId 					= null;
		RegRepSdrRequest request 		= null;

		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		if (null == context)
		{
			errorString = "Null incoming context. Persistance failed";
			logger.error("########## " + errorString);

			throw new MessagingException("Persist-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		helper = new XmlToDtoHelper();

//		synchronized (this)
//		{
			try
			{
				if (null != context.getContextType()) payloadType = context.getContextType().name();

				if (PayloadTypeEnum.REG_REP_XML.name().equals(payloadType))
				{
					handleRegRepXMLPayload(context, helper);
				}
				else if (PayloadTypeEnum.FpML.name().equals(payloadType))
				{
					handleFPMLPayload(context, helper);
				}
				else if (PayloadTypeEnum.SDR_RESPONSE_ACK.name().equals(payloadType) || PayloadTypeEnum.SDR_RESPONSE_NACK.name().equals(payloadType))
				{
					handleResponseAckNackPayload(context, helper, parentMessage, parentTrade);
				}
				else if (PayloadTypeEnum.REG_REP_FILTERED.name().equals(payloadType))
				{
					/*** Bypassing Duplicate report filter ***/
					if (context.isDuplicateReport()) return;

					/*** This is exclusively for the cases when message has not been parsed -  USE Case - Input Data Validation failed ***/
					if (null == context.getSdrRequest())
					{
						logger.debug("Getting original payload message....");
						message = regRepMessageDao.findByPrimaryKey(context.getMessageId());
						message.setIsInvalid(ConversionUtils.booleanToDbString(context.isInvalid()));

						logger.debug("Persisting updated message....");
						regRepMessageDao.saveOrUpdate(message);
						
						logger.debug("Persisted updated message");

						return;
					}
					
					if(null != context.getReportingStatus()
							&& !context.getReportingStatus().getReportStatus()
							&& null != context.getReportingStatus().getReportReason()
							&& NotReportingReasonEnum.INVALID_TRADE.equals(context.getReportingStatus().getReportReason()))
					{
						handleFilteredInValidTrade(context, helper);		
						
						return;
					}

					if ((null != context.getRulesResultsContext() 
							&& null != context.getRulesResultsContext().getFilterValidationResultList() 
							&& context.getRulesResultsContext().getFilterValidationResultList().size() > 0) 
							|| !context.isReportingParty())
					{
						if(null == context.getSwapTradeId())
						{
							message = regRepMessageDao.findByPrimaryKeyNS(context.getMessageId());
							
							if(null != message)
							{
								if(message.getSwapTradeId() != null)
								{
									trade = regRepTradeDao.findByPrimaryKeyNS(message.getSwapTradeId());									
								}
								
								message.setRegRepTrade(trade);
							}
						}
						else
						{
							message = regRepMessageDao.findMsgAndTradeByPrimaryKeyNS(context.getMessageId());
						}
							
						message = helper.updateMessageFlags(message, context);

						logger.debug("DB call initiated for filtered message persistence....");
						regRepMessageDao.saveOrUpdate(message);

						logger.info(" Filtered Trade, Message  and Payload with USI " + message.getTradeUsi() + " successfully persisted ");
					}
				}

			}
			catch (Exception e)
			{
				errorString = "Failed to persist data for payloadType(" + payloadType + ") productType(" + context.getProductType() + ") subProductType(" + context.getSubProductType() + "). Reason : " + e.getMessage();
				logger.error("########## " + errorString, e);

				throw new MessagingException("Driver-19", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
			}
//		}
			
			logger.debug("Leaving persist() method");

	}

	private void handleFilteredInValidTrade(ReportingContext context, XmlToDtoHelper helper) throws MessagingException 
	{
		RegRepMessage message;
		String tradeId;
		RegRepSdrRequest request;
		RegRepSdrRequest dbRequest;
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		message = regRepMessageDao.findByPrimaryKey(context.getMessageId());
		
		if(null == message)
		{
			throw new MessagingException("prstnc:7", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Failed to find RegRepPayload Message", context.getMessageId(), context.getSwapTradeId());
		}						
		
		tradeId = helper.populateTrade(context, message);
		
		if(null == message.getRegRepTrade() || null == message.getRegRepTrade().getSwapTradeId())
		{
			logger.error("######### One of the mandatory RegRepTrade fields were null, hence skipping trade persistence");
			
			message.setRegRepTrade(null);
		}
		
		message.setSwapTradeId(tradeId);
		
		logger.debug("DB call initiated for message BO persistence....");
		regRepMessageDao.saveOrUpdate(message);
		
		context.setSwapTradeId(tradeId);
		logger.info(" Incoming Trade, Message  and Payload with USI " + message.getTradeUsi() + " successfully persisted ");

		// FIXME: Hibernate should be doing this implicitly
		logger.debug("DB call initiated for message regulatory persistence....");
		for (RegRepMessageRegulatory msgReg : message.getRegRepMessageRegulatories())
		{		
			regRepMessageRegulatoryDao.saveOrUpdate(msgReg);
		}
		
		logger.info(" Successfuly persisted message regulatories for the Trade ");

		if (null != message.getRegRepSdrRequest())
		{
			dbRequest = regRepSdrRequestDao.findByPrimaryKey(context.getMessageId());
			if (null == dbRequest)
			{
				logger.debug("DB call initiated for sdr request persistance....");
				regRepSdrRequestDao.saveOrUpdate(message.getRegRepSdrRequest());
				logger.info("SdrRequest successfully persisted");
			}
		}
	}

	private void handleResponseAckNackPayload(ReportingContext context, XmlToDtoHelper helper, RegRepMessage parentMessage, RegRepTrade parentTrade) throws MessagingException 
	{
		String parentMessageId;
		RegRepMessage message;
		RegRepReport report;
		
		logger.info("Getting the message object of the persisted payload ....");
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		// message = regRepMessageDao.findByPrimaryKey(context.getMessageId());
		message = regRepMessageDao.findByPrimaryKeyNS(context.getMessageId());
		
		/*** Amit Rana - This is the Id sent back by DTCC. It is the same id that we embedded in the outgoing report. ***/
		parentMessageId = context.getResponse().getInReplyTo();
		
		if (null != parentMessageId)
		{
			// parentMessage = regRepMessageDao.findByPrimaryKey(parentMessageId);
			parentMessage = regRepMessageDao.findByPrimaryKeyNS(parentMessageId);

			if (null != parentMessage)
			{
				parentTrade = regRepTradeDao.findByPrimaryKeyNS(parentMessage.getRegRepTrade().getSwapTradeId());
			}
		}

		/*** So as to not duplicate regulatories ***/
		context.getRegulatories().clear();
		message = helper.populateResponse(context, parentMessage, parentTrade, message);

		/*** Update the report status ***/
		/*** Updating the acknowledgement status of the report ***/
		if (null != parentMessage)
		{
			report = regRepReportDao.findByPrimaryKey(parentMessageId);
			
			/*** To avoid NullPointer being thrown, check for return report object ***/
			if(null != report)
			{
				report.setIsAcknowledged(Constants.YES);
				regRepReportDao.saveOrUpdate(report);
			}
		}

		if (null != message)
		{
			logger.debug("DB call initiated for response persistence....");
			regRepMessageDao.saveOrUpdate(message);
		}

		if (message.getRegRepExceptions() != null && !message.getRegRepExceptions().isEmpty() && null != parentMessage)
		{				
			/*** Dont save exception for NRP nack ***/
			regRepExceptionDao.saveOrUpdateAll(message.getRegRepExceptions());
		}

		logger.info("Incoming Response " + context.getContextType().type() + " Message and Payload with MessageId " + message.getRegRepMessageId() + " successfully persisted ");

		/*** enrichResponse is to set up jurisdiction, repository details inside the context. These would be required to compute compliance key. ***/
		enrichResponse(parentMessage, context);
		logger.info("Enriched response details with parent report data");
		
		/*** persist the regulatories for response message ***/
		Set<RegRepMessageRegulatory> respRegulatories = helper.createMessageRegulatoryFromInputXML(context, message);

		if (respRegulatories != null && !respRegulatories.isEmpty())
		{
			regRepMessageRegulatoryDao.saveOrUpdateAll(respRegulatories);
			
			logger.info("Saving message regulatories for response message");
		}
	}

	private void handleFPMLPayload(ReportingContext context, XmlToDtoHelper helper) throws MessagingException 
	{
		String parentMessageId;
		RegRepMessage parentMessage;
		RegRepReport report;
		RegRepUniqueIdentifierMapping uniqueUsi;
		RegRepTrade trade;
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);
		
		parentMessageId = context.getSrcMessageId();

		logger.info("Getting the parent message object for the report ....");
		parentMessage = regRepMessageDao.findByPrimaryKeyNS(parentMessageId);
		
		trade = regRepTradeDao.findByPrimaryKeyNS(parentMessage.getRegRepTrade().getSwapTradeId());
		//context.setSubmissionTimestamp(CalendarUtils.getCurrentDateInUTC()); // TODO: Move this to a "higher" level so it accurately reflects the *submission* time, not the persistence time.
		context.setSubmissionTimestamp(new Date());
		
		report = helper.populateReport(context, parentMessage, trade);
		regRepMessageDao.saveOrUpdate(report.getRegRepMessage());
		
		logger.debug("DB call initiated for fpml message persistence....");
		regRepReportDao.saveOrUpdate(report);
		
		logger.info(" Incoming Report type " + context.getReportTypes().get(0) + " Message and Payload with MessageId " + report.getRegRepReportId() + " successfully persisted ");

		// FIXME: Hibernate should be doing this implicitly
		logger.debug("DB call initiated for message regulatory persistence....");
		for (RegRepMessageRegulatory msgReg : report.getRegRepMessage().getRegRepMessageRegulatories())
		{
			regRepMessageRegulatoryDao.saveOrUpdate(msgReg);
		}
		
		uniqueUsi = helper.getUniqueIdentifierObject(context.getSdrRequest());
		if (null != uniqueUsi)
		{
			logger.debug("DB call initiated for unique Identifier persistence....");
			regRepUniqueIdentifierMappingDao.saveOrUpdate(uniqueUsi);
			
			logger.debug(" Entry created in Unique Identifier table for -->  " + uniqueUsi.getId().getTradeId());
		}

		logger.info(" Successfuly persisted message regulatories for the Trade ");
	}

	private void handleRegRepXMLPayload(ReportingContext context, XmlToDtoHelper helper) throws EtdMessageException, MessagingException 
	{
		RegRepMessage message;
		String msgSource;
		Boolean valuationAlert;
		Boolean collateralAlert;
		String tradeId;
		RegRepSdrRequest request;
		
		logger.info("Getting the message object from the payload ....");
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		msgSource 			= context.getMessageSource();
		valuationAlert 		= context.isValuationAlert();
		collateralAlert 	= context.isCollateralAlert();

		if (msgSource != null && EtdConstants.ETD_REQUEST.equalsIgnoreCase(msgSource))
		{
			handleETDMessageSource(context, helper, valuationAlert, collateralAlert);
		}
		else
		{
			if(context.getConfirmationAlert())
			{
				handleConfirmationAlert(context, helper);														
			}
			else
			{
				message = regRepMessageDao.findByPrimaryKey(context.getMessageId());
				tradeId = helper.populateTrade(context, message);
				message.setSwapTradeId(tradeId);
				
				logger.debug("DB call initiated for message BO persistence....");
				regRepMessageDao.saveOrUpdate(message);
				context.setSwapTradeId(tradeId);
				
				logger.info(" Incoming Trade, Message  and Payload with USI " + message.getTradeUsi() + " successfully persisted ");

				// FIXME: Hibernate should be doing this implicitly
				logger.debug("DB call initiated for message regulatory persistence....");
				for (RegRepMessageRegulatory msgReg : message.getRegRepMessageRegulatories())
				{
					regRepMessageRegulatoryDao.saveOrUpdate(msgReg);
				}
				
				logger.info(" Successfuly persisted message regulatories for the Trade ");
				
				if (null != message.getRegRepSdrRequest())
				{								
					/*** If it's custom EOD refresh, we need not store the SDR request object ***/
					if(null != context.getSdrRequest() && null != context.getSdrRequest().getTrade()
						&& null != context.getSdrRequest().getTrade().getCustomBackload()
						&& null != context.getSdrRequest().getTrade().getCustomBackload().isIsCustomEodRefresh()
						&& true!= context.getSdrRequest().getTrade().getCustomBackload().isIsCustomEodRefresh())
					{
						logger.info(" If it's custom EOD refresh, we need not store the SDR request object");
					}
					else
					{
						/*** Only for non-confirmation messages ***/
						if(!context.getPayload().contains(Constants.ConfirmationKey + Constants.UNDERSCORE))
						{
							request = message.getRegRepSdrRequest();

							logger.debug("DB call initiated for sdr request persistance....");
							regRepSdrRequestDao.saveOrUpdate(request);
							
							logger.info("SdrRequest successfully persisted");
						}	
					}
				}							
			}
		}
	}

	
	private void handleConfirmationAlert(ReportingContext context, XmlToDtoHelper helper) 
	{
		RegRepMessage message;
		RegRepSdrRequest request;
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		message = regRepMessageDao.findByPrimaryKey(context.getMessageId());							
		request = helper.populateSdrRequest(message, context);
		
		try
		{
			if(null != request)								
				regRepSdrRequestDao.saveOrUpdate(request);
		}
		catch(Exception e)
		{
			logger.error("######### Filed to persist confirmation bo ",e);								
		}
	}

	private void handleETDMessageSource(ReportingContext context, XmlToDtoHelper helper, Boolean valuationAlert, Boolean collateralAlert) throws EtdMessageException 
	{
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		EtdPayload etdPayload;
		etdPayload = etdPayloadDao.findByPrimaryKey(context.getMessageId());

		if (null != valuationAlert && valuationAlert == Boolean.TRUE)
		{
			EtdValuationDtls currEtdValuationDtls = helper.createEtdValuationDtlsFromInputXml(context, etdPayload);
			etdValuationDtlsDao.save(currEtdValuationDtls);

			logger.debug("Finished saving to ETD valuation tables from .. persistence Driver....");
		}
		else if (null != collateralAlert && collateralAlert == Boolean.TRUE)
		{
			EtdCollateralDtls currEtdCollateralDtls = helper.createEtdCollateralDtlsFromInputXml(context, etdPayload);
			// EtdValuationDtls currEtdValuationDtls = helper.createEtdValuationDtlsFromInputXml(context, etdPayload);
			etdCollateralDtlsDao.save(currEtdCollateralDtls);

			logger.debug("Finished saving to ETD Collateral tables from .. persistence Driver....");
		}
		else
		{
			// update EtdPayload object with EtdTradeDtls and ETdTradeJurisdiction data
			EtdTradeDtls trdDtls = helper.createEtdTradeDtlsFromInputXml(context, etdPayload);
			logger.debug("DB call initiated for message BO persistence....");
			// etdPayloadDao.saveOrUpdate(etdPayload);
			etdTradeDtlsDao.save(trdDtls);

			EtdTradeJurisdiction etdTradeJurisdiction = helper.createEtdTradeJurisDictionFromInputXml(context, etdPayload);
			etdTradeJurisdictionDao.save(etdTradeJurisdiction);
			logger.debug("Finished saving to ETD tables from .. persistence Driver....");
			
			if(StringUtils.equalsIgnoreCase(etdTradeJurisdiction.getMsgType(), EtdConstants.ETD_MSG_TRANSACTION))
			{
				
				SdrRequest sdrRequest = context.getSdrRequest();
				TradeHeaderType tradeHeader = null;
				TradeType trade = null;
				String action = null;
				
				if(null != sdrRequest) 
				{
					trade = sdrRequest.getTrade();
					tradeHeader = trade.getTradeHeader();
					action = tradeHeader.getAction();
				}
				
				if(StringUtils.equalsIgnoreCase(action, EtdConstants.ETD_ACTION_NEW))
				{
					EtdTradeJurisdiction compressionEtdTradeJurisdiction = helper.createEtdTradeJurisDictionForCompressionMsg(context, etdPayload);
					etdTradeJurisdictionDao.save(compressionEtdTradeJurisdiction);
					
					logger.debug("Finished saving Compression msg to ETD tables from .. persistence Driver....");
				}
			}
		}
	}

	/**
	 * @author Amit Rana
	 * @param parentMessage
	 * @param ctxt
	 */

	private void enrichResponse(RegRepMessage parentMessage, ReportingContext ctxt)
	{
		logger.debug("Entering enrichResponse() method");

		String[] jurisdictions 	= null;
		String[] repositories 	= null;
		Date execTime 			= null;
		List<RegRepMessageRegulatory> regulatories = null;
		String regRepReportType = null;
		int index 				= 0;
		String lce 				= null;
		String pMsgid 			= null;
		RegRepSdrRequest request = null;
		RegRepMessage rMsg 		= null;

		if (null == ctxt)
		{
			logger.error("########## Failed to embedded response details, since incoming data was null");
			return;
		}

		AbstractDriver.setMDCInfo(ctxt, AbstractDriver.Driver);

		if (null == parentMessage)
		{
			ctxt.setSrcMessageId(null);
			return;
		}
		else
		{
			ctxt.setSrcMessageId(parentMessage.getRegRepMessageId());
		}
		
		lce = parentMessage.getLifecycleEventType();
		
		if(null != lce)
		{
			if(Constants.Origination.equals(lce) || Constants.EVENT_TYPE_NEW.equals(lce) || Constants.NONE.equalsIgnoreCase(lce))
			{
				execTime = parentMessage.getTradeExecutionTimestamp();
			}
			else
			{
				rMsg		= parentMessage.getRegRepMessageBySrcRegRepMessageId();
				
				if(null != rMsg)
				{
					pMsgid		= rMsg.getRegRepMessageId();
					
					if(null != pMsgid)
					{
						request 	= regRepSdrRequestDao.findByPrimaryKey(pMsgid);
						
						if(null != request && null != request.getRegRepTradeHeader() && null != request.getRegRepTradeHeader().getRegRepLifecycle())
							execTime	= request.getRegRepTradeHeader().getRegRepLifecycle().getEventExecutionDateTime();
					}					
				}			
			}
		}
		else
		{
			execTime = parentMessage.getTradeExecutionTimestamp();
		}		
		

		// FIXME: Hibernate should be doing this implicitly
		logger.debug("DB call initiated for getting message regulatory....");

		regulatories = regRepMessageRegulatoryDao.findByMessageId(parentMessage.getRegRepMessageId());

		logger.debug("Loaded message regulatories");

		if (null != regulatories)
		{
			jurisdictions 	= new String[regulatories.size()];
			repositories 	= new String[regulatories.size()];

			for (RegRepMessageRegulatory msgReg : regulatories)
			{
				jurisdictions[index] 	= msgReg.getReportingJurisdiction();
				repositories[index] 	= msgReg.getRepository();

				index++;
			}
		}

		logger.info(" Successfuly persisted message regulatories for the Trade ");

		/*** This is ensure that report type was not confirm and if it was, update the report type ***/
		if (null != parentMessage.getRegRepReport())
		{
			if (null != parentMessage.getRegRepReport().getSdrMessageType())
			{
				regRepReportType = parentMessage.getRegRepReport().getSdrMessageType();

				if (Constants.MESSAGE_TYPE_CONF.equalsIgnoreCase(regRepReportType))
				{
					if (null != ctxt.getResponse()) ctxt.getResponse().setParentreportType(Constants.MESSAGE_TYPE_CONF);
				}
			}
		}

		ResponseUtils.embeddParentReportDetails(jurisdictions, repositories, execTime, ctxt);

		logger.debug("Completed Reponse context modification with report details");
	}

	public void updateComplianceStatus(String regRepMessageId, boolean isCompliant)
	{
		logger.debug("Entering updateComplianceStatus() method");
		
		RegRepMessage parentMessage = null;
		RegRepReport report 		= null;
		String compliantString 		= null;

		if (null == regRepMessageId)
		{
			logger.error("########## Failed to updtae the compliance status for report," + " since incoming messageId was null");
			return;
		}

		parentMessage = regRepMessageDao.findByPrimaryKeyNS(regRepMessageId);

		if (null == parentMessage)
		{
			logger.error("########## Failed to fetch message object based on the messageId");
			return;
		}

		// report = parentMessage.getRegRepReport();
		report = regRepReportDao.findByPrimaryKey(parentMessage.getRegRepMessageId());
		if (null == report)
		{
			logger.error("########## Failed to fetch report object from the message");
			return;
		}

		compliantString = ConversionUtils.booleanToDbString(isCompliant);

		report.setIsCompliant(compliantString);

		logger.debug("DB call initiated....inside updateComplianceStatus");
		
		regRepReportDao.saveOrUpdate(report);

		logger.debug("Sucessfully updated complaince details for the report");
	}

	public void createDtoObjects()
	{

	}
	
	public void updatePortfolioCount(ReportingContext context) 
	{	
		logger.debug("Entering updatePortfolioCount() method");

		String status 			= null;
		TradeHeaderType header 	= null;
		String cpLei 			= null;
		String assetClass 		= null;
		RegRepPortfolioCount regRepPortfolioCount = null;
		XmlToDtoHelper helper 	= null;
		String tradeId 			= null;
		RegRepTrade tradeObj 	= null;
		LifeCycleType lifecycle = null;
		ClearingType clearing 	= null;
		boolean isCleared 		= false;
		String tradeType = null,sdrAction=null;
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		try
		{
			header	= context.getSdrRequest().getTrade().getTradeHeader();
		}
		catch(Exception e)
		{
			logger.error("######### Error :: Failed to read the trade header for portfolio count update. Quitting for this transaction");
			return;
		}
		
		if(null == header)
		{
			logger.error("######### Error :: Trade header is found null while portfolio count update. Quitting update for this transaction");
			return;
		}

		cpLei 		= header.getCounterpartyLEI();
		assetClass	= context.getAssetClass();
		status 		= header.getStatus();
		tradeId		= header.getTradeId();

		if(null == cpLei)
		{
			logger.error("######### Error :: Failed to read cpunterparty lei. Quitting for this transaction");
			return;
		}
		
		if(null == assetClass)
		{
			logger.error("######### Error :: Failed to read asset class. Quitting for this transaction");
			return;
		}
		
		lifecycle = header.getLifeCycle();
		tradeType=ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);		
		sdrAction = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.SDR_ACTION_DERIVED_EVENT);
	
		tradeObj = regRepTradeDao.findByPrimaryKeyNS(tradeId);
		
		if(tradeObj != null)
		{			
			if(!ReportingDataUtils.hasTradeExpired(context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType(), status, isCleared,tradeType,sdrAction))
				return;
		}

		regRepPortfolioCount = portfolioCountDao.getPortfolioCountByLeiAndAsset(cpLei, assetClass);

		helper = new XmlToDtoHelper();
		regRepPortfolioCount = helper.populateCount(regRepPortfolioCount, status, context, isCleared);
		
		try
		{
			portfolioCountDao.saveOrUpdate(regRepPortfolioCount);
		}
		catch(Exception e)
		{
			logger.error("######### Error :: Failed to update portfolio Count. \n "+ExceptionUtils.getFullStackTrace(e));			
		}	
	}
	
	public void updateRecon(ReportingContext context) {
		
		logger.debug("Entering updateRecon() method");

		String status 			= null;
		TradeHeaderType header 	= null;
		String assetClass 		= null;
		XmlToDtoHelper helper 	= null;
		String tradeId 			= null;
		LifeCycleType lifecycle = null;
		ClearingType clearing 	= null;
		boolean isCleared 		= context.isCleared();
		String tradeType 		= null;
		boolean isTradeActive 	= false;
		RegRepReconTrioptima regRepRecon = null;
		String marketType 		= null;
		Date current_date = new Date();
		String sdrAction   =    null;
		RegRepTrioptimaParser trioptimaParser;
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.Driver);

		try
		{
			header	= context.getSdrRequest().getTrade().getTradeHeader();
		}
		catch(Exception e)
		{
			logger.error("######### Error :: Failed to read the trade header for portfolio count update. Quitting for this transaction");
			return;
		}
		
		if(null == header)
		{
			logger.error("######### Error :: Trade header is found null while portfolio count update. Quitting update for this transaction");
			return;
		}

		assetClass	= context.getAssetClass();
		status 		= header.getStatus();
		tradeId		= header.getTradeId();
				
		lifecycle 	= header.getLifeCycle();
		tradeType	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);	
		marketType	= context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();
		sdrAction = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.SDR_ACTION_DERIVED_EVENT);
		TradeHeaderType tradeHeader = context.getSdrRequest().getTrade().getTradeHeader();
		
			regRepRecon = regRepReconTrioptimaDao.findByPrimaryKeyNS(tradeId);
			
			if(null != tradeHeader.getLifeCycle()
					&& null != tradeHeader.getLifeCycle().getClearing()
					&& null != tradeHeader.getLifeCycle().getClearing().isClearedTrade())		
				
				isCleared = tradeHeader.getLifeCycle().getClearing().isClearedTrade();	
						
			isTradeActive = ReportingDataUtils.hasTradeExpired(context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType(), status, isCleared,tradeType,sdrAction);
				
			if(isTradeActive)
			{
				logger.debug("Trade Expired");
			}
			else
			{
					logger.debug("Trade Active");
					isTradeActive = true;
			}
					
			if(null != regRepRecon && isCleared || (Constants.Reportable456.equals(tradeType) && Constants.Novation_RP.equals(marketType)))
			{
				regRepReconTrioptimaDao.delete(regRepRecon);
			}
				
			if(!isCleared ) {
					
				helper = new XmlToDtoHelper();
				regRepRecon 	= helper.createReconMapper(context, isTradeActive, regRepRecon, regRepTrioptimaParser);
									
				if(null != regRepRecon) {
					regRepReconTrioptimaDao.saveOrUpdate(regRepRecon);
					logger.debug("Recon successfully persisted");
					}
				}
			
	}

	public RegRepMessageDao getRegRepMessageDao()
	{
		return regRepMessageDao;
	}

	public void setRegRepMessageDao(RegRepMessageDao regRepMessageDao)
	{
		this.regRepMessageDao = regRepMessageDao;
	}

	public RegRepPayloadDao getRegRepPayloadDao()
	{
		return regRepPayloadDao;
	}

	public void setRegRepPayloadDao(RegRepPayloadDao regRepPayloadDao)
	{
		this.regRepPayloadDao = regRepPayloadDao;
	}

	public RegRepReportDao getRegRepReportDao()
	{
		return regRepReportDao;
	}

	public void setRegRepReportDao(RegRepReportDao regRepReportDao)
	{
		this.regRepReportDao = regRepReportDao;
	}

	public RegRepMessageRegulatoryDao getRegRepMessageRegulatoryDao()
	{
		return regRepMessageRegulatoryDao;
	}

	public void setRegRepMessageRegulatoryDao(RegRepMessageRegulatoryDao regRepMessageRegulatoryDao)
	{
		this.regRepMessageRegulatoryDao = regRepMessageRegulatoryDao;
	}

	public void setRegRepUniqueIdentifierMappingDao(RegRepUniqueIdentifierMappingDao regRepUniqueIdentifierMappingDao)
	{
		this.regRepUniqueIdentifierMappingDao = regRepUniqueIdentifierMappingDao;
	}

	public RegRepSdrRequestDao getRegRepSdrRequestDao()
	{
		return regRepSdrRequestDao;
	}

	public void setRegRepSdrRequestDao(RegRepSdrRequestDao regRepSdrRequestDao)
	{
		this.regRepSdrRequestDao = regRepSdrRequestDao;
	}

	public RegRepExceptionDao getRegRepExceptionDao()
	{
		return regRepExceptionDao;
	}

	public void setRegRepExceptionDao(RegRepExceptionDao regRepExceptionDao)
	{
		this.regRepExceptionDao = regRepExceptionDao;
	}

	public void setEtdPayloadDao(EtdPayloadDao etdPayloadDao)
	{
		this.etdPayloadDao = etdPayloadDao;
	}

	public void setInputMessageSource(String inputMessageSource)
	{
		this.inputMessageSource = inputMessageSource;
	}

	public void setResponseMessageSource(String responseMessageSource)
	{
		this.responseMessageSource = responseMessageSource;
	}
	
	public void setPortfolioCountDao(RegRepPortfolioCountDao portfolioCountDao)
	{
		this.portfolioCountDao = portfolioCountDao;
	}

	public void setEtdTradeDtlsDao(EtdTradeDtlsDao etdTradeDtlsDao)
	{
		this.etdTradeDtlsDao = etdTradeDtlsDao;
	}

	public void setEtdTradeJurisdictionDao(EtdTradeJurisdictionDao etdTradeJurisdictionDao)
	{
		this.etdTradeJurisdictionDao = etdTradeJurisdictionDao;
	}

	public void setEtdValuationDtlsDao(EtdValuationDtlsDao etdValuationDtlsDao)
	{
		this.etdValuationDtlsDao = etdValuationDtlsDao;
	}

	public void setRegRepOrigPayloadDao(RegRepOrigPayloadDao regRepOrigPayloadDao)
	{
		this.regRepOrigPayloadDao = regRepOrigPayloadDao;
	}
	public EtdCollateralDtlsDao getEtdCollateralDtlsDao()
	{
		return etdCollateralDtlsDao;
	}

	public void setEtdCollateralDtlsDao(EtdCollateralDtlsDao etdCollateralDtlsDao)
	{
		this.etdCollateralDtlsDao = etdCollateralDtlsDao;
	}
	
	public void setRegRepReconTrioptimaDao(RegRepReconTrioptimaDao regRepReconTrioptimaDao)
	{
		this.regRepReconTrioptimaDao = regRepReconTrioptimaDao;
	}
	
	public RegRepReconTrioptimaDao getRegRepReconTrioptimaDao()
	{
		return regRepReconTrioptimaDao;
	}
	
	public void setRegRepTrioptimaParser(RegRepTrioptimaParser regRepTrioptimaParser)
	{
		this.regRepTrioptimaParser = regRepTrioptimaParser;
	}
	public RegRepTrioptimaParser getRegRepTrioptimaParser()
	{
		return regRepTrioptimaParser;
	}
}
