package com.wellsfargo.regulatory.persister.recon.dao.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepIceOpenTransactionDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepIceOpenTransaction;

@Transactional
@Repository
public class RegRepIceOpenTransactionDaoImpl extends AbstractDaoImpl<RegRepIceOpenTransaction> implements
		RegRepIceOpenTransactionDao {
	
	/**
	 * 
	 */
	
	/*private static final String GET_ICE_DATA = "select * from 
";*/
	private static final long serialVersionUID = 9013397903590131807L;

	@Override
	public Class<RegRepIceOpenTransaction> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepIceOpenTransaction.class;
	}
	
	public List<RegRepIceOpenTransaction> findAll(Date date) {
		List <RegRepIceOpenTransaction> regRepIceOpenTransaction = null;
		
		java.sql.Date convertedDate = null;
		String convertedString=null;
		if(null != date){
			DateFormat  dateFormat = new SimpleDateFormat("yyyy-MM-dd");			 
			convertedString =dateFormat.format(date);
			 java.util.Date parsedUtilDate;
			try {
				parsedUtilDate = dateFormat.parse(convertedString);
				convertedDate= new java.sql.Date(parsedUtilDate.getTime());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		regRepIceOpenTransaction= findByNamedQuery(RegRepIceOpenTransaction.GET_ICE_DATA, new Object[]	
				{ convertedDate });
		 return regRepIceOpenTransaction;
	}
	
}
