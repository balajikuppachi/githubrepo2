package com.wellsfargo.regulatory.persister.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepReportDao;
import com.wellsfargo.regulatory.persister.dto.RegRepReport;

public class RegRepReportDaoImpl extends AbstractDaoImpl<RegRepReport> implements RegRepReportDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3557354107676540338L;

	@Override
	public Class<RegRepReport> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepReport.class;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<RegRepReport> loadRegRepRptsByExternalMsgId(String externalMsgId) 
	{
		// TODO Auto-generated method stub
		return findByNamedQuery(RegRepReport.GET_REPORTS_BY_EXTERNAL_MSG_ID, new Object[]{ externalMsgId });
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<RegRepReport> loadRegRepRptsBySwapTradeId(String tradeId) 
	{
		// TODO Auto-generated method stub
		return findByNamedQuery(RegRepReport.GET_REPORTS_BY_SWAP_TRADE_ID, new Object[] { tradeId });
	}	

	
	@SuppressWarnings("unchecked")
    @Override
    @Transactional
    public List<RegRepReport> loadRegRepRptsByReportId(List<String> reportIds)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepReport result = null;
		List<RegRepReport> resultList = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepReport.GET_REPORTS_BY_REPORT_IDs);
			queryObject.setParameterList("reportIds", reportIds);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				resultList = new ArrayList<RegRepReport>(100);
				
				for (Object[] obj: objs)
				{
					result = new RegRepReport();
					result.setRegRepReportId((String)obj[0]);
					result.setSdrMessageType((String)obj[1]);
					result.setIsCompliant((String)obj[2]);					
					result.setSubmissionTimestamp((Timestamp)obj[3]);
					result.setIsAcknowledged((String)obj[4]);
					result.setIsDuplicate((String)obj[5]);
										
					resultList.add(result);
				}
			}

		}
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);
			
/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return resultList;
    }

}
