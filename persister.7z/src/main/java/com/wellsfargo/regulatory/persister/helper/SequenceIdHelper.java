package com.wellsfargo.regulatory.persister.helper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.factory.FactoryException;
import com.wellsfargo.regulatory.persister.dao.DataSourceDao;

public class SequenceIdHelper extends DataSourceDao
{
	@Autowired static RegRepPayLoadSequence regRepPayLoadSequence;
	
	@Autowired static EtdTradeJurisdictionSequence etdTradeJurisdictionSequence;
	
	@Autowired static EtdTradeBatchOutputSequence etdTradeBatchOutputSequence;
	
	@Autowired static EtdExceptionSequence etdExceptionSequence;

	private static Logger logger = Logger.getLogger(SequenceIdHelper.class.getName());

	public static Integer getMaxSequence(String tableName, String columnName) throws MessagingException
	{
		logger.debug("Getting the maxId for " + columnName + " from " + tableName);

		Integer maxId = -1;
		Statement stmt = null;
		ResultSet rst = null;

		Connection con = getConnection();

		try
		{
			stmt = con.createStatement();
			rst = stmt.executeQuery("select max(" + columnName + ") as " + columnName + " from " + tableName);

			while (rst.next())
			{

				maxId = rst.getInt(columnName);
			}
		}
		catch (SQLException e)
		{

			logger.error("Unable to determine max sequence id" + e);
			throw new MessagingException("2DB", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage());
		}
		finally
		{
			closeResources(con, stmt, rst);
		}

		logger.debug("Max Id returned is " + maxId);
		return maxId;
	}

	public static Integer getMaxSequence(String beanName) throws MessagingException, FactoryException, EtdMessageException
	{
		logger.debug("Entering getMaxSequence, maxId for Bean " + beanName);

		int seqId = -100;

		//RegRepPayLoadSequence regRepPayLoadSequence = (RegRepPayLoadSequence) RegulatoryBeanFactory.getBean(beanName);
		// Tweak for now, since bean factory doesn't load eagerly

		if("regRepPayLoadSequence".equals(beanName))
		{
			seqId = Integer.parseInt(regRepPayLoadSequence.getNextId().toString());
		}
		else if("etdTradeJurisdictionSequence".equals(beanName))
		{
			seqId = Integer.parseInt(etdTradeJurisdictionSequence.getNextId().toString());
		}
		else if("etdTradeBatchOutputSequence".equals(beanName))
		{
			seqId = Integer.parseInt(etdTradeBatchOutputSequence.getNextId().toString());
		}
		else if("etdExceptionSequence".equals(beanName))
		{
			seqId = Integer.parseInt(etdExceptionSequence.getNextId().toString());
		}

		logger.debug("Leaving getMaxSequence, maxId for Bean " + beanName + ": Id:" + seqId);

		return seqId;
	}

	public static void setRegRepPayLoadSequence(
			RegRepPayLoadSequence regRepPayLoadSequence) {
		SequenceIdHelper.regRepPayLoadSequence = regRepPayLoadSequence;
	}

	public static void setEtdTradeJurisdictionSequence(EtdTradeJurisdictionSequence etdTradeJurisdictionSequence)
	{
		SequenceIdHelper.etdTradeJurisdictionSequence = etdTradeJurisdictionSequence;
	}

	public static void setEtdTradeBatchOutputSequence(EtdTradeBatchOutputSequence etdTradeBatchOutputSequence)
	{
		SequenceIdHelper.etdTradeBatchOutputSequence = etdTradeBatchOutputSequence;
	}

	public static void setEtdExceptionSequence(EtdExceptionSequence etdExceptionSequence)
	{
		SequenceIdHelper.etdExceptionSequence = etdExceptionSequence;
	}
}
