package com.wellsfargo.regulatory.persister;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateCallback;

import com.wellsfargo.regulatory.commons.cache.beans.RealtimeConfigData;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;
import com.wellsfargo.regulatory.persister.dao.RegRepDomainMapDao;

public class RegRepDomainMapDaoImpl extends BaseDAOImpl implements RegRepDomainMapDao, Serializable
{
	private static final long serialVersionUID = -8700782598675765434L;

	@SuppressWarnings("unchecked")
	public List<RegRepDomainMapping> getDomainMappings() throws Exception 
	{
		Object list = getHibernateTemplate().execute(new HibernateCallback() 
		{
			@SuppressWarnings("rawtypes")
			public Object doInHibernate(Session session) 
			{
				List regRepDomainMappings = session.createQuery("FROM RegRepDomainMapping").list();
				return regRepDomainMappings;
			}
		});
		  
		return (List<RegRepDomainMapping>)list;
	}


	@SuppressWarnings("unchecked")
	public List<RealtimeConfigData> getRealtimeConfigData() throws Exception 
	{
		Object list = getHibernateTemplate().execute(new HibernateCallback() 
		{
			@SuppressWarnings("rawtypes")
			public Object doInHibernate(Session session) 
			{
				List realtimeConfigData = session.createQuery("FROM RealtimeConfigData").list();
				return realtimeConfigData;
			}
		});
		  
		return (List<RealtimeConfigData>)list;
	}

}
