package com.wellsfargo.regulatory.persister.recon.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepReconReportDataDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportData;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class RegRepReconReportDataDaoImpl extends AbstractDaoImpl<RegRepReconReportData> implements RegRepReconReportDataDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private DataSource dataSource;
	private SimpleJdbcCall simpleJdbcCall;
	private String reconProc;
	
	public static final String REPORT_US = "US";
	public static final String REPORT_THEM = "THEM";

	
    private JdbcTemplate m_jdbcTemplate;
    
    public JdbcTemplate getJdbcTemplate() 
    {
        return m_jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) 
    {
        m_jdbcTemplate = jdbcTemplate;
    }

	
	@Override
	public Class<RegRepReconReportData> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepReconReportData.class;
	}

	@SuppressWarnings("unchecked")
	public List<RegRepReconReportData> getReconReportData(Date reportDate, String source1, String source2)
	{
		List<RegRepReconReportData> regRepReconReportDataList = new ArrayList<RegRepReconReportData>();
		this.simpleJdbcCall = new SimpleJdbcCall(dataSource).withProcedureName(reconProc);
		SqlParameterSource in = new MapSqlParameterSource().addValue("reportDate", reportDate).addValue("source1", source1).addValue("source2", source2);
		Map<String, Object> out = simpleJdbcCall.execute(in);

		Object reconResultsSet = out.get("#result-set-1");
		
		//if there is no data in DB for report date return null
		if(null == reconResultsSet) return null;
		
		String reconResultsString = reconResultsSet.toString();
		String[] reconResultsArray = reconResultsString.split("}");

		RegRepReconReportData currRegRepReconReportData = null;

		for (String resultObj : reconResultsArray)
		{
			currRegRepReconReportData = regRepReconReportDataRowMapper(resultObj);

			if (null != currRegRepReconReportData) regRepReconReportDataList.add(currRegRepReconReportData);

		}

		// return ((List<T>) getNextSequenceIdUsingStoredProc(queryName, sequenceCode));
		return regRepReconReportDataList;
	}

	private RegRepReconReportData regRepReconReportDataRowMapper(String resultObjStr)
	{
		RegRepReconReportData currRegRepReconReportData = new RegRepReconReportData();
		String[] currResultObjSet = null;
		String updatedKeyValueStr1 = null;
		String updatedKeyValueStr = null;

		if (StringUtils.isNotBlank(resultObjStr))
		{
			currResultObjSet = resultObjStr.split(",");

			for (String keyValueString : currResultObjSet)
			{

				updatedKeyValueStr1 = StringUtils.replaceChars(keyValueString.trim(), "{", "");
				updatedKeyValueStr = StringUtils.replaceChars(updatedKeyValueStr1, "[", "");

				String key = StringUtils.substringBefore(updatedKeyValueStr, "=").trim();
				String value = StringUtils.substringAfter(updatedKeyValueStr, "=").trim();

				if (StringUtils.isNotBlank(key))
				{
					if (key.equalsIgnoreCase("category")) currRegRepReconReportData.setCategory(value);
					if (key.equalsIgnoreCase("row_id1")) currRegRepReconReportData.setRow_id1(value);
					if (key.equalsIgnoreCase("trade_id1")) currRegRepReconReportData.setTrade_id1(value);
					if (key.equalsIgnoreCase("sender_trade_ref_id1")) currRegRepReconReportData.setSender_trade_ref_id1(value);
					if (key.equalsIgnoreCase("usi1")) currRegRepReconReportData.setUsi1(value);
					if (key.equalsIgnoreCase("trade_date1")) currRegRepReconReportData.setTrade_date1(value);
					if (key.equalsIgnoreCase("start_date1")) currRegRepReconReportData.setStart_date1(value);
					if (key.equalsIgnoreCase("maturity_date1")) currRegRepReconReportData.setMaturity_date1(value);
					if (key.equalsIgnoreCase("OurName1")) currRegRepReconReportData.setOurName1(value);
					if (key.equalsIgnoreCase("OurLEI1")) currRegRepReconReportData.setOurLEI1(value);
					if (key.equalsIgnoreCase("CptyName1")) currRegRepReconReportData.setCptyName1(value);
					if (key.equalsIgnoreCase("CptyLEI1")) currRegRepReconReportData.setCptyLEI1(value);
					if (key.equalsIgnoreCase("rp1"))
						{
						    if(null != value && !value.equalsIgnoreCase("null"))
						    {
						    	 String currRp1 =  StringUtils.isNotBlank(value) && value.trim().equalsIgnoreCase("1")?REPORT_US:REPORT_THEM;		
								 currRegRepReconReportData.setRp1(currRp1);
						    }
						   
						}

					if (key.equalsIgnoreCase("row_id2")) currRegRepReconReportData.setRow_id2(value);
					if (key.equalsIgnoreCase("trade_id2")) currRegRepReconReportData.setTrade_id2(value);
					if (key.equalsIgnoreCase("sender_trade_ref_id2")) currRegRepReconReportData.setSender_trade_ref_id2(value);
					if (key.equalsIgnoreCase("usi2")) currRegRepReconReportData.setUsi2(value);
					if (key.equalsIgnoreCase("trade_date2")) currRegRepReconReportData.setTrade_date2(value);
					if (key.equalsIgnoreCase("start_date2")) currRegRepReconReportData.setStart_date2(value);
					if (key.equalsIgnoreCase("maturity_date2")) currRegRepReconReportData.setMaturity_date2(value);
					if (key.equalsIgnoreCase("OurName2")) currRegRepReconReportData.setOurName2(value);
					if (key.equalsIgnoreCase("OurLEI2")) currRegRepReconReportData.setOurLEI2(value);
					if (key.equalsIgnoreCase("CptyName2")) currRegRepReconReportData.setCptyName2(value);
					if (key.equalsIgnoreCase("CptyLEI2")) currRegRepReconReportData.setCptyLEI2(value);
					if (key.equalsIgnoreCase("rp2"))
					{
					    if(null != value && !value.equalsIgnoreCase("null"))
					    {
					    	String currRp2 =  StringUtils.isNotBlank(value) && value.trim().equalsIgnoreCase("1")?REPORT_US:REPORT_THEM;		
							currRegRepReconReportData.setRp2(currRp2);
					    }
						
					}

				}

			}

		}

		return currRegRepReconReportData;
	}

	public DataSource getDataSource()
	{
		return dataSource;
	}

	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}

	public String getReconProc()
	{
		return reconProc;
	}

	public void setReconProc(String reconProc)
	{
		this.reconProc = reconProc;
	}

}
