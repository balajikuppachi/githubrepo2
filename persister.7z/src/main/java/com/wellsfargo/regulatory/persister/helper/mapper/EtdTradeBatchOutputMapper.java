package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeBatchOutput;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class EtdTradeBatchOutputMapper
{
	private static Logger logger = Logger.getLogger(EtdTradeJurisdictionMapper.class.getName());

	public EtdTradeBatchOutput populateEtdTradeBatchOut(EtdTradeBatchOutput inEtdTradeBatchOut)  throws EtdMessageException
	{
		logger.info("inside EtdTradeBatchOutputMapper populateEtdTradeBatchOut method");
		Date current_date = new Date();
		/**
		int id = -1;

		try
		{
			id = SequenceIdHelper.getMaxSequence("etdTradeBatchOutputSequence");
		}
		
		catch (Exception e)
		{
			throw new EtdMessageException("EtdBatchOut:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, e.getMessage() ,Integer.toString(id), e);
		}
		*/
		//inEtdTradeBatchOut.setBatchId(id);
		inEtdTradeBatchOut.setCreateDatetime(current_date);
		inEtdTradeBatchOut.setRepository(EtdConstants.ESMA_RPT_JURISDICTION);
		
		
		logger.info("exiting EtdTradeBatchOutputMapper populateEtdTradeBatchOut method");
		
		return inEtdTradeBatchOut;
		
	}
}
