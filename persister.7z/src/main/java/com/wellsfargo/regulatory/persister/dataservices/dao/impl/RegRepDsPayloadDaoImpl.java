package com.wellsfargo.regulatory.persister.dataservices.dao.impl;

import java.util.List;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.dataservices.dao.RegRepDsPayloadDao;
import com.wellsfargo.regulatory.persister.dataservices.dto.RegRepDsPayload;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

public class RegRepDsPayloadDaoImpl extends AbstractDaoImpl<RegRepDsPayload> implements RegRepDsPayloadDao{
	 /**
	 * 
	 */
	private static final long serialVersionUID = -8256819076241960493L;

	@Override
		public Class<RegRepDsPayload> getEntityClass()
		{
			return RegRepDsPayload.class;
		}

	@SuppressWarnings("unchecked")
	@Override
	public RegRepDsPayload loadDsMsgByMessageIdAndType(String messageId,
			String payLoadType) {
		
		List<RegRepDsPayload> list =  findByNamedQuery(RegRepDsPayload.GET_DS_MSGS_BY_MSGID_TYPE, new Object[]
				{ messageId, payLoadType });
		if (list != null && !list.isEmpty())
			return list.get(0);
		
		return null;
		
	}
}
