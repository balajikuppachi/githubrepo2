package com.wellsfargo.regulatory.persister.etd.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

public class EtdTradeJurisdictionExtnDao
{

	private JdbcTemplate jdbcTemplate;

	private static Logger logger = Logger.getLogger(EtdTradeJurisdictionExtnDao.class.getName());
	
	private String valuationSql = " select  count(*) from ETD_VALUATION_DTLS ev ,"
			+ "	  ( select * from ETD_TRADE_JURISDICTION etj1"
			+ "                     where etj1.create_datetime in "
			+ "         ( select max(etj2.create_datetime)   from ETD_TRADE_JURISDICTION etj2"
			+ "                       where etj2.cob_date = ? and   etj2.isReportable = 'true' and"
			+ "					  etj2.msg_type = 'Position' group by etj2.trade_id )) etj where "
			+ "      ev.trade_id = etj.trade_id and  ev.cob_date = etj.cob_date"
			+ "      and etj.msg_type = 'Position' and 		"
			+ "     etj.cob_date = ?";
	
	private String collateralSql = "   select  count(*)   from ETD_COLLATERAL_DTLS ecd  where  ecd.suppressReporting = 'false' and ecd.cob_date = ?";
	
	private String valuationNotReportableSql = " select  count(*) from ETD_VALUATION_DTLS ev ,"
			+ "	  ( select * from ETD_TRADE_JURISDICTION etj1"
			+ "                     where etj1.create_datetime in "
			+ "         ( select max(etj2.create_datetime)   from ETD_TRADE_JURISDICTION etj2"
			+ "                       where etj2.cob_date = ? and   etj2.isReportable = 'false' and "
			+ "					  etj2.msg_type = 'Position' group by etj2.trade_id )) etj where "
			+ "      ev.trade_id = etj.trade_id and  ev.cob_date = etj.cob_date"
			+ "      and etj.msg_type = 'Position' and 		"
			+ "     etj.cob_date = ?";
	
	private String collateralNotReportableSql = "   select  count(*)   from ETD_COLLATERAL_DTLS ecd  where  ecd.suppressReporting = 'true' and ecd.cob_date = ?";

	public EtdTradeJurisdictionExtnDao(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public Long findFeedIdInRange(Long from, Long to)
	{
		List<Long> maxIdList = jdbcTemplate.queryForList("SELECT MAX(jurisdiction_id) FROM ETD_TRADE_JURISDICTION WHERE jurisdiction_id >= ? AND jurisdiction_id <= ?", Long.class, from, to);

		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null)
		{
			return null;
		}
		else
		{
			return maxIdList.get(0);
		}
	}

	// returns count of records existing in EtdTradeJurisdiction table 
	// for given message type and Date	
	public int getCntOfTransactionRecords(String msgType, String asOfDate)
	{
		int cntOfrecs = 0;	

		List<Long> countList = jdbcTemplate.queryForList("SELECT  count(*) FROM ETD_TRADE_JURISDICTION where isReportable = 'true' and msg_type = ? and  cob_date = ?",  Long.class, msgType, asOfDate);
		if(countList != null)
		{
			cntOfrecs =  countList.get(0).intValue();
		}
		
		return cntOfrecs;
	}
	
	
		public int getCntOfTransactionNonReportableRecords(String msgType, String asOfDate)
		{
			int cntOfrecs = 0;	

			List<Long> countList = jdbcTemplate.queryForList("SELECT  count(*) FROM ETD_TRADE_JURISDICTION where isReportable = 'false' and msg_type = ? and  cob_date = ?",  Long.class, msgType, asOfDate);
			if(countList != null)
			{
				cntOfrecs =  countList.get(0).intValue();
			}
			
			return cntOfrecs;
		}
	
	//gets Valuation record count for given asOfDate
	public int getCntOfValuationRecords( String asOfDate)
	{
		int cntOfrecs = 0;	

		List<Long> countList = jdbcTemplate.queryForList(valuationSql,  Long.class, asOfDate, asOfDate);
		if(countList != null)
		{
			cntOfrecs =  countList.get(0).intValue();
		}
		
		return cntOfrecs;
	}
	
	//gets Valuation record count for given asOfDate
	public int getCntOfValuationNonReportableRecords( String asOfDate)
	{
		int cntOfrecs = 0;	

		List<Long> countList = jdbcTemplate.queryForList(valuationNotReportableSql,  Long.class, asOfDate, asOfDate);
		if(countList != null)
		{
			cntOfrecs =  countList.get(0).intValue();
		}
		
		return cntOfrecs;
	}
	
	//gets Collateral record count for given asOfDate
	public int getCntOfCollateralRecords( String asOfDate)
	{
		int cntOfrecs = 0;	

		List<Long> countList = jdbcTemplate.queryForList(collateralSql,  Long.class, asOfDate);
		if(countList != null)
		{
			cntOfrecs =  countList.get(0).intValue();
		}
		
		return cntOfrecs;
	}
	
	public int getCntOfCollateralNonReportableRecords( String asOfDate)
	{
		int cntOfrecs = 0;	

		List<Long> countList = jdbcTemplate.queryForList(collateralNotReportableSql,  Long.class, asOfDate);
		if(countList != null)
		{
			cntOfrecs =  countList.get(0).intValue();
		}
		
		return cntOfrecs;
	}


	
}
