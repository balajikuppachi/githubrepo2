package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepPrCidDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPrCid;

public class RegRepPrCidDaoImpl  extends AbstractDaoImpl<RegRepPrCid> implements RegRepPrCidDao {

	private static final long serialVersionUID = 4806208231160083034L;

	@Override
	public Class<RegRepPrCid> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepPrCid.class;
	}

}

