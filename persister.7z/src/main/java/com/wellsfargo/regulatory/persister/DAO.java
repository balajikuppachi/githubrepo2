
package com.wellsfargo.regulatory.persister;

import java.io.Serializable;

public interface DAO 
{

    /**
     * @param persistentObj
     */
    void delete(Object persistentObj);

    /**
     * @param
     */
    @SuppressWarnings("rawtypes")
	void delete(Long id, Class clazz);

    /**
     * @param id
     * @param clazz
     * @return
     */
    @SuppressWarnings("rawtypes")
	Object load(Serializable id, Class clazz);
    
    
    /**
     * @param persistentObj
     */
    void saveOrUpdate(Object persistentObj);
    
    
    /**
     * @param persistentObj
     */
    void save(Object persistentObj);
    
    
    /**
     * @param persistentObj
     */
    void update(Object persistentObj);

    
//    /**
//     * @param persistentObj
//     */
//    Integer getCount(Class clazz);
//

}
