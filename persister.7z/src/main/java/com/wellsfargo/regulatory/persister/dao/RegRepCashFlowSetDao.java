package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepCashFlowSet;

public interface RegRepCashFlowSetDao extends Dao<RegRepCashFlowSet>, Serializable
{

}
