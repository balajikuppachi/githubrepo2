package com.wellsfargo.regulatory.persister.dto;

import java.io.Serializable;

public class RegRepTradeCollateral implements Serializable{

	private String tradeId;
	private String legalId;
	private String srcSystem;
	private String productType;
	private String tickerId;
	private String collateralization;
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getLegalId() {
		return legalId;
	}
	public void setLegalId(String legalId) {
		this.legalId = legalId;
	}
	public String getSrcSystem() {
		return srcSystem;
	}
	public void setSrcSystem(String srcSystem) {
		this.srcSystem = srcSystem;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getTickerId() {
		return tickerId;
	}
	public void setTickerId(String tickerId) {
		this.tickerId = tickerId;
	}
	public String getCollateralization() {
		return collateralization;
	}
	public void setCollateralization(String collateralization) {
		this.collateralization = collateralization;
	}

}
