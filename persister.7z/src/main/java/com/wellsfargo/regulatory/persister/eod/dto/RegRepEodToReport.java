/**
 * 
 */
package com.wellsfargo.regulatory.persister.eod.dto;

import java.util.Date;

import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;

/**
 * @author Pavan.Siram
 *
 */
public class RegRepEodToReport {
	
	protected String tradeId;
	protected String regRepMessageId;
	protected String reportType;
	protected String isActive;
	protected String jurisdiction;
	protected String assetclass;
	protected String usi;
	protected String repository;
	protected String message; 
	protected String equityTemplate;
	protected RegRepTrioptima regRepTrioptima;
	protected Date updateDateTime;
	protected Date createDateTime;
	
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getRegRepMessageId() {
		return regRepMessageId;
	}
	public void setRegRepMessageId(String regRepMessageId) {
		this.regRepMessageId = regRepMessageId;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getAssetclass() {
		return assetclass;
	}
	public void setAssetclass(String assetclass) {
		this.assetclass = assetclass;
	}
	public String getUsi() {
		return usi;
	}
	public void setUsi(String usi) {
		this.usi = usi;
	}
	public String getRepository() {
		return repository;
	}
	public void setRepository(String repository) {
		this.repository = repository;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void setEquityTemplate(String equityTemplate) {
		this.equityTemplate = equityTemplate;
	}
	public String getEquityTemplate() {
		return equityTemplate;
	}
	public void setRegRepTrioptima(RegRepTrioptima regRepTrioptima) {
		this.regRepTrioptima = regRepTrioptima;
	}
	public RegRepTrioptima getRegRepTrioptima() {
		return regRepTrioptima;
	}
	public Date getUpdateTimestamp() {
		return updateDateTime;
	}
	public void setUpdateTimestamp(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
	
	
	

}
