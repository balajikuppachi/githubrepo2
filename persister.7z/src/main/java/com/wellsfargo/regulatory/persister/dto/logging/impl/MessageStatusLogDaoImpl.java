package com.wellsfargo.regulatory.persister.dto.logging.impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.beans.MessageStatusLog;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;
import com.wellsfargo.regulatory.persister.dto.logging.MessageStatusLogDao;

public class MessageStatusLogDaoImpl implements MessageStatusLogDao
{

	private JdbcTemplate jdbcTemplate;

	public boolean insertMessageStatus(MessageStatusLog statusLogObject)
	{
		boolean successful = false;
		String query = QueryMaster.INSERT_MESSAGE_STATUS;

		jdbcTemplate.update(query, new Object[]
		{ statusLogObject.getSdrMessageId(), statusLogObject.getTimeStamp(), statusLogObject.getChannelName(), statusLogObject.getReferenceQuery() });

		successful = true;

		return successful;
	}

	public MessageStatusLog getMessageStatusById(String id)
	{
		MessageStatusLog statusLogObject = null;

		return statusLogObject;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

}
