package com.wellsfargo.regulatory.persister;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

/**
 * @author Rama Nuti - u363026
 */

public abstract class BaseDAOImpl extends HibernateDaoSupport implements DAO 
{
	
	@Autowired
    @Qualifier("strSessionFactory")
    SessionFactory sessionFactory;
	
    @Autowired
    public void init(SessionFactory factory) 
    {
        setSessionFactory(factory);
    }
    
	public void delete(final Object persistentObj) 
	{
        getHibernateTemplate().delete(persistentObj);
    }

    @SuppressWarnings("rawtypes")
	public void delete(Long id, Class clazz) 
    {
        Object obj = this.load(id, clazz);
        getHibernateTemplate().delete(obj);
    }

    @SuppressWarnings("rawtypes")
	public Object load(final Serializable id, final Class clazz) 
    {
        Object retObj = null;
        List items = (List) getHibernateTemplate().execute(new HibernateCallback() 
        {
        	public Object doInHibernate(Session session) 
        	{
        		List items = session.createQuery("select item from " + clazz.getName() + " item where item.id = :id").setParameter("id", id).list();
        		return items;
        	}
        });
        
        if (items.size() > 0) 
        {
            retObj = (Object) items.get(0);
        }
        
        return retObj;
    }

    public void save(Object persistentObj) 
    {
        getHibernateTemplate().save(persistentObj);
    }

    public void saveOrUpdate(Object persistentObj) 
    {
        getHibernateTemplate().saveOrUpdate(persistentObj);
    }

    public void update(final Object persistentObj) 
    {
        getHibernateTemplate().update(persistentObj);
    }
    
}
