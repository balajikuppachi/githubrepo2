package com.wellsfargo.regulatory.persister.etd.dao.impl;

import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.etd.dao.EtdPayloadDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;

public class EtdPayloadDaoImpl extends AbstractDaoImpl<EtdPayload> implements EtdPayloadDao
{

	/**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    
    @Override
	public Class<EtdPayload> getEntityClass()
	{
		return EtdPayload.class;
	}
    
    
    @SuppressWarnings("unchecked")
    public List<EtdPayload> getEtdPayLoadByCreateDate(Date createFromDate, Date createToDate)
    {
    	return findByNamedQuery(EtdPayload.GET_ETD_PAYLOAD_BY_CREATEDATE, new Object[] { createFromDate, createToDate});
    }


}
