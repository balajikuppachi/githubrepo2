package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepSdrRequestDao;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;

public class RegRepSdrRequestDaoImpl extends AbstractDaoImpl<RegRepSdrRequest> implements RegRepSdrRequestDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7692792753063225199L;

	@Override
	public Class<RegRepSdrRequest> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepSdrRequest.class;
	}

	
}
