package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepLeg;

public interface RegRepLegDao extends Dao<RegRepLeg>, Serializable
{

}
