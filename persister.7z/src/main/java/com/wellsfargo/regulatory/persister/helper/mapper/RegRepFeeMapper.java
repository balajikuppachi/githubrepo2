package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepFee;
import com.wellsfargo.regulatory.persister.dto.RegRepFeeId;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public class RegRepFeeMapper
{
	private static Logger logger = Logger.getLogger(RegRepFeeMapper.class.getName());

	public RegRepFee createRegRepFee(FeeType ipFee, RegRepTradeDetail regRepTradeDetail, int id)
	{
		RegRepFee fee = null;
		RegRepFeeId feeId = null;

		if (null == ipFee || null == regRepTradeDetail)
		{
			logger.debug("Fee object could not be " + "populated due to invalid incoming data");
			return fee;
		}

		fee = new RegRepFee();
		fee.setRegRepTradeDetail(regRepTradeDetail);

		feeId = createRegRepFeeId(fee, id);

		fee.setAmount(ConversionUtils.bigDecimalToDouble(ipFee.getAmount()));
		fee.setCurrency(ipFee.getCurrency());
		fee.setFeeDate(CalendarUtils.toDate(ipFee.getDate()));
		fee.setId(feeId);
		fee.setPayerLei(ipFee.getPayerLEI());
		fee.setReceiverLei(ipFee.getReceiverLEI());
		fee.setType(fee.getType());
		
		/*** Start LEI Changes ***/ 
		
		fee.setPayerLEIPrefix(StringUtils.trimToEmpty(ipFee.getPayerLEIPrefix()));
		fee.setPayerLEIValue(StringUtils.trimToEmpty(ipFee.getPayerLEIValue()));

		fee.setReceiverLEIPrefix(StringUtils.trimToEmpty(ipFee.getReceiverLEIPrefix()));
		fee.setReceiverLEIValue(StringUtils.trimToEmpty(ipFee.getReceiverLEIValue()));

		/*** End LEI Changes ***/ 
		
		return fee;
	}

	private RegRepFeeId createRegRepFeeId(RegRepFee fee, int id)
	{
		RegRepFeeId feeId = null;

		if (null == fee)
		{
			logger.debug("FeeId object could not be " + "populated due to invalid incoming data");
			return feeId;
		}

		feeId = new RegRepFeeId();

		feeId.setRegRepFeeId(id);
		feeId.setRegRepMessageId(fee.getRegRepTradeDetail().getRegRepSdrRequest().getRegRepMessage().getRegRepMessageId());

		return feeId;
	}

}
