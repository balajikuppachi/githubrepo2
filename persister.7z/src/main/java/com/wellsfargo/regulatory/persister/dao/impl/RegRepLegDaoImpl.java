package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepLegDao;
import com.wellsfargo.regulatory.persister.dto.RegRepLeg;

public class RegRepLegDaoImpl extends AbstractDaoImpl<RegRepLeg> implements RegRepLegDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6207840665611952415L;

	@Override
	public Class<RegRepLeg> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepLeg.class;
	}



}
