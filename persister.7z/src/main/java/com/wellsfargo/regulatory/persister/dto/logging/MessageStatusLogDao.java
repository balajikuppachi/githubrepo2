package com.wellsfargo.regulatory.persister.dto.logging;

import com.wellsfargo.regulatory.commons.beans.MessageStatusLog;

public interface MessageStatusLogDao
{
	public boolean insertMessageStatus(MessageStatusLog statusLogObject);

	public MessageStatusLog getMessageStatusById(String id);
}
