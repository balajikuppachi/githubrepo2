package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse.Reason;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepException;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepExceptionMapper
{
	private static Logger logger = Logger.getLogger(RegRepExceptionMapper.class.getName());

	public RegRepException createRegRepException(RegRepMessage dbMessage, Reason reason)
	{
		RegRepException dbException = null;
		String exceptionId = null;

		if (null == reason)
		{
			logger.debug("RegRepException object could not be populated due to null incoming reason object");
			return dbException;
		}

		dbException = new RegRepException();
		exceptionId = ReportingDataUtils.generateMessageId();

		dbException.setRegRepMessage(dbMessage);
		// dbException.setCode((reason.reasonCode == null ? "99999" : reason.reasonCode));

		dbException.setCode(reason.reasonCode);
		// dbException.setDescription((reason.description == null) ? "#### Exception Occured" :
		// reason.description);

		dbException.setDescription(reason.description);
		dbException.setRegRepExceptionId(exceptionId);
		dbException.setRegRepExceptionTimestamp(new Date());

		// if (null != reason.severity) dbException.setSeverity((reason.severity.type() == null ?
		// "SEVIORTY-DEFAULT" : reason.severity.type()));
		dbException.setSeverity(reason.severity.type());

		dbException.setStatus(Constants.EXCEPTION_OPEN_STATUS);

		// if (null != reason.type) dbException.setType((StringUtils.trimToNull(reason.type.type())
		// == null ? "EXCEPTION" : reason.type.type()));
		dbException.setType(reason.type.type());

		return dbException;
	}
}
