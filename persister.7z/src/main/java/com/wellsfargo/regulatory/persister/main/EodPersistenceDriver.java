package com.wellsfargo.regulatory.persister.main;

import static com.wellsfargo.regulatory.commons.keywords.Constants.APP_FALSE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.APP_TRUE;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse;
import com.wellsfargo.regulatory.commons.beans.FpMLResponse.Reason;
import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmissionTracker;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepAllegeMessageDao;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepAllegePayloadDao;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodExceptionDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodPayloadDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodReportDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodSubmissionResponseDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodSubmissionsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodSubmissionsTrackerDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepAllegeMessage;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepAllegePayload;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodException;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodPayload;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodReport;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodSubmissionResponse;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepAllegeMessageMapper;

/**
 * @author Shreekar
 * @date 10/10/2015
 * @version 1.0
 */
@Component
public class EodPersistenceDriver
{
	private static Logger logger = Logger.getLogger(EodPersistenceDriver.class.getName());

	@Autowired
	private RegRepEodReportDaoImpl regRepEodReportDaoImpl;

	@Autowired
	private RegRepEodPayloadDaoImpl regRepEodPayloadDaoImpl;

	@Autowired
	private RegRepEodSubmissionsDaoImpl regRepEodSubmissionsDaoImpl;

	@Autowired
	private RegRepEodSubmissionResponseDaoImpl regRepEodSubmissionResponseDaoImpl;

	@Autowired
	private RegRepEodExceptionDaoImpl regRepEodExceptionDaoImpl;

	@Autowired
	private RegRepEodSubmissionsTrackerDaoImpl regRepEodSubmissionsTrackerDaoImpl;

	@Autowired
	private RegRepAllegeMessageDao regRepAllegeMessageDao;

	@Autowired
	private RegRepAllegePayloadDao regRepAllegePayloadDao;

	@Autowired
	private RegRepAllegeMessageMapper regRepAllegeMessageMapper;

	public boolean insertRegRepEodPayload(ReportingContext context, RegRepEodReport regRepEodReportDto)
	{
		logger.debug("Entering insertRegRepEodPayload method");

		boolean success = false;
		Date pldTime = null;

		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);

		pldTime = CalendarUtils.getCurrentDateInUTC();

		try
		{

			RegRepEodPayload regRepEodPayload = new RegRepEodPayload();
			regRepEodPayload.setPayload(context.getPayload());
			regRepEodPayload.setEodReportId(regRepEodReportDto.getEodReportId());
			regRepEodPayload.setReportType(regRepEodReportDto.getReportType());
			regRepEodPayload.setPayloadTimeStamp(new Timestamp(pldTime.getTime()));

			regRepEodPayloadDaoImpl.insertRegRepPayload(regRepEodPayload);

			logger.info("Successfully inserted the record into REG_REP_EOD_PAYLOAD table");
			success = true;

		}
		catch (Exception e)
		{
			logger.error("######### Error while inserting record into REG_REP_EOD_PAYLOAD table ", e);
			success = false;
		}

		logger.debug("Exiting insertRegRepEodPayload method");
		return success;
	}

	public boolean insertRegRepEodReport(ReportingContext context, boolean isActiveStatus, RegRepEodReport regRepEodReportDto)
	{
		logger.debug("Entering insertRegRepEodReport method");

		boolean success = false;
		boolean expired = false;
		String isActive = null;
		Date insertTs = null;
		Date expiredOn = null;
		String lifeCycleEvent = null;
		String status = null;
		String tradeType = null;
		String transactionType = null;
		boolean isClearedTrade = false;
		String reportType = null;
		String tradeUSI = null;
		String tradeUTI = null;
		KeywordsType keywordsType = null;
		String sdrAction = null;
		String eventType = null;
		String jurisdiction = null;
		boolean isBlockTrade = false;

		try
		{

			AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);
			status = regRepEodReportDto.getTradeStatus();
			tradeType = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);
			transactionType = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.MARKET_TRANSACTION_TYPE_DOMAIN_VALUE);
			lifeCycleEvent = regRepEodReportDto.getEvntType();
			keywordsType = context.getSdrRequest().getTrade().getRegulatory().getKeywords();
			sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);
			isClearedTrade = context.isCleared();
			expired = ReportingDataUtils.hasTradeExpired(lifeCycleEvent, status, isClearedTrade, tradeType, sdrAction);
			reportType = regRepEodReportDto.getReportType();
			tradeUSI = context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().getUSI();
			tradeUTI = context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().getUTI();
			jurisdiction = regRepEodReportDto.getJurisdiction();
			isBlockTrade = isBlockTrade(context, regRepEodReportDto, lifeCycleEvent, reportType, tradeUSI, jurisdiction);

			if (expired) expiredOn = new Date();

			/***
			 * If expired or cleared trade or block trade or undo events [Cancel] set Buffer
			 * in-eligible for Snapshot reporting
			 */
			if ((expired && !Constants.Exit.equalsIgnoreCase(transactionType)) || isClearedTrade || isBlockTrade || Constants.Cancel.equals(regRepEodReportDto.getActionType()))
			{
				regRepEodReportDto.setIsBufferEligible(0);
			}

			isActive = isActiveStatus ? APP_TRUE : APP_FALSE;
			insertTs = CalendarUtils.getCurrentDateInUTC();

			regRepEodReportDto.setIsActive(isActive);
			regRepEodReportDto.setExpiredOn((null == expiredOn) ? null : (new java.sql.Date(expiredOn.getTime())));
			regRepEodReportDto.setInsertTimeStamp(new Timestamp(insertTs.getTime()));
			regRepEodReportDto.setCobDate(new Date());
			regRepEodReportDto.setTradeUSI(tradeUSI);
			regRepEodReportDto.setTradeUTI(tradeUTI);

			eventType = context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();

			// usi unlock scenario - after exiting the old trade, new Trade has to be sent to
			// process next business day
			if ((StringUtils.equalsIgnoreCase(sdrAction, Constants.SDR_ACTION_NEW) || StringUtils.equalsIgnoreCase(eventType, Constants.EVENT_TYPE_USI_CHANGE)))
			{
				Date cobDate = new Date();
				Calendar calendar = Calendar.getInstance();
				int day = calendar.get(Calendar.DAY_OF_WEEK);
				if (day == 6)
				{
					cobDate = DateUtils.addDays(cobDate, 3);
				}
				else
				{
					cobDate = DateUtils.addDays(cobDate, 1);
				}
				isActive = Constants.APP_LAST_ACTIVE_STATUS;

				regRepEodReportDto.setIsActive(isActive);
				regRepEodReportDto.setCobDate(cobDate);

			}

			regRepEodReportDaoImpl.insertRegRepEodReport(regRepEodReportDto);

			logger.info("Successfully inserted the record into REG_REP_EOD_REPORT table");
			success = true;
		}
		catch (Exception e)
		{
			logger.error("######### Error while inserting record into REG_REP_EOD_REPORT table ", e);
			success = false;
		}
		logger.debug("Exiting insertRegRepEodReport method");
		return success;
	}

	public boolean updateEodActiveFlag(ReportingContext context, RegRepEodReport regRepEodReportDto, boolean reportSpecificUpdate)
	{
		logger.info("Entering updateSnapshotActiveFlag method");

		boolean success = false;
		int updtaedRecs = 0;

		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);

		if (reportSpecificUpdate) updtaedRecs = regRepEodReportDaoImpl.updateEodActiveRepFlag(regRepEodReportDto);
		else updtaedRecs = regRepEodReportDaoImpl.updateEodActiveFlag(regRepEodReportDto);

		success = true;

		logger.info("Successfully updated is_active flag for " + updtaedRecs + " Snapshot records in the REG_REP_EOD_REPORT table");
		return success;
	}

	public boolean turnOffTodayCancel(ReportingContext context, RegRepEodReport regRepEodReportDto)
	{
		Timestamp insertDateTime = null;
		Timestamp timeY = null;
		boolean runUpdate = false;
		String tradeId = null;
		String actionType = null;
		String reportId = null;
		List<String> idList = new ArrayList<String>();
		boolean success = false;

		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);

		List<RegRepEodReport> cancelTrades = regRepEodReportDaoImpl.findLastActiveTrades(regRepEodReportDto);
		try
		{

			for (RegRepEodReport regRepEodReport : cancelTrades)
			{
				actionType = regRepEodReport.getActionType();
				if (Constants.Cancel.equals(actionType))
				{
					reportId = regRepEodReport.getEodReportId();
					idList.add(reportId);
					continue;
				}
				insertDateTime = regRepEodReport.getInsertTimeStamp();
				break;
			}

			if (!GeneralUtils.IsListNullOrEmpty(idList))
			{
				int count = regRepEodSubmissionsDaoImpl.getEodReportId(idList);

				if (count > 0)
				{
					runUpdate = true;
				}
				else
				{
					// No active trade drop was found
					if (null == insertDateTime)
					{
						logger.error("######### No non-retracted events were found for the tradeId " + tradeId + ". Quitting further processesing this tradeId");
						return success;
					}

					timeY = new Timestamp(CalendarUtils.getYesterday(19, 30, 00).getTime());

					/*** Time stamp of the last active trade drop was before 7:30 pm yesterday ***/
					if (insertDateTime.compareTo(timeY) < 0)
					{
						/***
						 * Normal process should be followed. We need to report retraction in this
						 * case
						 ***/
						runUpdate = false;
					}
					else
					{
						/***
						 * After 7:30 trade drop was received. Need not report retraction message so
						 * update it to false;
						 ***/
						runUpdate = true;
					}
				}

				if (runUpdate)
				{
					regRepEodReportDaoImpl.updateActiveFlag(Constants.APP_FALSE, Constants.APP_FALSE, Constants.APP_TRUE, regRepEodReportDto, idList);
					success = true;
				}

			}
		}
		catch (Exception e)
		{
			logger.error("######### Error reverting Active Flag for Snapshots for Cancel trade drop. ", e);
			success = false;
		}
		return success;
	}

	public boolean updateLastActive(ReportingContext context, RegRepEodReport regRepEodReportDto)
	{
		logger.debug("Entering updateLastActive with tradeId ");

		String actionType = null;
		String reportId = null;
		boolean success = false;
		List<String> idList = new ArrayList<String>();
		List<String> idBufferEligibleList = new ArrayList<String>();
		boolean foundActive = false;

		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);

		String reportType[] =
		{ "Snapshot", "Valuation" };

		String prevEvent = null;
		/** Retrieve the undo market type **/
		String undoEvent[] = StringUtils.split(regRepEodReportDto.getEvntType(), Constants.HYPHEN);
		if (!GeneralUtils.IsNull(undoEvent) && undoEvent.length > 1) prevEvent = StringUtils.substring(undoEvent[1].trim(), 0, 4);

		List<RegRepEodReport> lastActiveTrades = regRepEodReportDaoImpl.findLastActiveTrades(regRepEodReportDto);
		try
		{

			for (RegRepEodReport regRepEodReport : lastActiveTrades)
			{
				actionType = regRepEodReport.getActionType();
				if (Constants.Cancel.equals(actionType))
				{
					reportId = Constants.CANCEL;
				}
				else
				{
					if (Constants.CANCEL.equals(reportId))
					{
						
						boolean isSameDay=DateUtils.isSameDay(regRepEodReport.getCobDate(),Calendar.getInstance().getTime());
						
						/**STR-505: Only do active for the T trades but not on T+1**/
						if(!isSameDay)
						{
							foundActive=false;
							logger.error("No action to take on T+1 undo event");
							break;
						}
						
						/**
						 * Lookup for previous market type of the trades for which we need to apply
						 * the current undo action [Both VAL/SS], make isBufferEligible=0 for those
						 * market type.
						 **/
						if (!GeneralUtils.IsNullOrBlank(regRepEodReport.getEvntType()) && StringUtils.startsWith(regRepEodReport.getEvntType(), prevEvent)
						        && ArrayUtils.contains(reportType, regRepEodReport.getReportType()))
						{
							logger.debug("updateLastActive with status isBufferEligible=0 for : " + regRepEodReport.getEodReportId());
							idBufferEligibleList.add(regRepEodReport.getEodReportId());
						}

						/**
						 * Lookup for previous market type of the trades for which we need to apply
						 * the current undo action [Both VAL/SS] to make previous LCE as report able.
						 **/
						if (!GeneralUtils.IsNullOrBlank(regRepEodReport.getEvntType()) && !StringUtils.startsWith(regRepEodReport.getEvntType(), prevEvent)
						        && ArrayUtils.contains(reportType, regRepEodReport.getReportType()))
						{
							logger.debug("updateLastActive with status isActive=1 for : " + regRepEodReport.getEodReportId());
							idList.add(regRepEodReport.getEodReportId());
							reportType = (String[]) ArrayUtils.removeElement(reportType, regRepEodReport.getReportType());
							foundActive = true;
							if (reportType.length <= 0) break;
						}

					}
				}

			}

			if (!foundActive)
			{
				logger.error("No last retracted event was found. Returnnig.");
				return success;
			}

			/*** Update the active flag for last valid trade drop ***/
			if(!GeneralUtils.IsListNullOrEmpty(idList))
				success = regRepEodReportDaoImpl.updateActiveFlag(Constants.APP_TRUE, Constants.APP_TRUE, Constants.APP_FALSE, regRepEodReportDto, idList);

			if(!GeneralUtils.IsListNullOrEmpty(idBufferEligibleList))
				success = regRepEodReportDaoImpl.updateActiveFlag(Constants.APP_FALSE, Constants.APP_FALSE, Constants.APP_FALSE, regRepEodReportDto, idBufferEligibleList);

			success = true;
		}
		catch (Exception e)
		{
			logger.error("######### Error Updating the last valid active flag for Snapshots ", e);
			success = false;
		}

		logger.debug("Exiting updateLastActive with status " + success);
		return success;
	}

	public List<RegRepEodSubmission> getExistingSubmissionRecord(RegRepEodSubmission regRepEodSubmission)
	{
		logger.debug("Entering getExistingSubmissionRecord ");
		List<RegRepEodSubmission> queryResult = null;
		try
		{
			queryResult = regRepEodSubmissionsDaoImpl.getExistingSubmissionRecord(regRepEodSubmission);

		}
		catch (Exception ex)
		{
			logger.error("######### exception occurred inside getExistingSubmissionRecord method " + ExceptionUtils.getFullStackTrace(ex));

		}

		return queryResult;
	}

	/**
	 * @param reportingContext
	 * insert EodSubmissionResponse
	 */
	public void insertRegRepEodSubmissionResponse(ReportingContext reportingContext)
	{
		String sentBy = null;
		String srcMsgid = null;
		String sendTo = null;
		Date creationDate = null;
		String status = null;
		FpMLResponse fpMLResponse = null;
		String responseString = null;
		List<Reason> reasons = null;
		String submitId = null;
		long submitIdLong = 0;
		String eodReportId = null;
		String[] sentByArray = null;
		boolean currEnvWellsSub = false;		
		RegRepAllegeMessage currRegRepAllegeMessage = null;
		

		RegRepEodSubmission currRegRepEodSubmission = new RegRepEodSubmission();
		RegRepEodSubmissionResponse currSubmissionResp = new RegRepEodSubmissionResponse();
		List<RegRepEodException> regRepEodExceptionList = new ArrayList<RegRepEodException>();

		fpMLResponse = reportingContext.getResponse();

		if (null == fpMLResponse)
		{
			logger.error("######### Response object is null. Returning....");
			return;
		}
		srcMsgid = fpMLResponse.getInReplyTo();

		/*** srcMsGid comes with EOD submission and EodReportID separated by colon (:) ***/
		if (StringUtils.isNotBlank(srcMsgid))
		{
			int numParams = 0;
			sentByArray = srcMsgid.split(":");
			numParams = sentByArray.length;

			if (numParams >= 2)
			{
				submitId = sentByArray[0];
				eodReportId = sentByArray[1];
			}
			else
			{
				submitId = sentByArray[0];
			}
		}

		if (null != fpMLResponse.getSendTo() && fpMLResponse.getSendTo().size() > 0) 
			sendTo = fpMLResponse.getSendTo().get(0);

		sentBy = fpMLResponse.getSentBy();
		creationDate = CalendarUtils.toUtcDateFromGregorianCalUtcDate(fpMLResponse.getCreationTimestamp());
		responseString = reportingContext.getPayload();

		if (PayloadTypeEnum.SDR_RESPONSE_ACK.equals(reportingContext.getContextType()))
		{
			status = Constants.DTCC_RESPONSE_ACK;
		}
		else if (PayloadTypeEnum.SDR_RESPONSE_NACK.equals(reportingContext.getContextType()))
		{
			/*** With-in NACK block checking for Warning status of EOD submission(s) ***/
			if (StringUtils.contains(StringUtils.trimToEmpty(responseString), ">WARNING</validation>"))
			{
				status = Constants.MSG_STATUS_WACK;
			}
			else status = Constants.DTCC_RESPONSE_NACK;
		}

		try
		{
			if (StringUtils.isNotBlank(eodReportId)) 
				eodReportId = eodReportId.trim();

			if (StringUtils.isNotBlank(submitId)) 
				submitId = submitId.trim();

			currRegRepEodSubmission.setEodReportId(eodReportId);

			if (StringUtils.isNotBlank(submitId) && StringUtils.isNumeric(submitId))
			{
				submitIdLong = new Long(submitId);
				currRegRepEodSubmission.setSubmissionId(submitIdLong);
			}

			// get Existing record from EodSubmission Table for the EodReportID and SubmissionID
			List<RegRepEodSubmission> eodSubmissionList = getExistingSubmissionRecord(currRegRepEodSubmission);

			for (RegRepEodSubmission currSub : eodSubmissionList)
			{
				if (StringUtils.endsWithIgnoreCase(eodReportId, currSub.getEodReportId()))
				{
					currEnvWellsSub = true;
					break;
				}
			}

			if (currEnvWellsSub)
			{
				currSubmissionResp.setSubmissionId(submitIdLong);
				currSubmissionResp.setSdrResponse(responseString);
				currSubmissionResp.setStatus(status);
				currSubmissionResp.setSentBy(sentBy);
				currSubmissionResp.setSentTo(sendTo);
				currSubmissionResp.setCreationTimeStamp((null == creationDate) ? null : new Timestamp(creationDate.getTime()));
				currSubmissionResp.setInsertTimeStamp(new Timestamp(CalendarUtils.getCurrentDateInUTC().getTime()));

				// insert into EodSubmissionResponse table
				regRepEodSubmissionResponseDaoImpl.insertRegRepEodSubmissionResponse(currSubmissionResp);

				/** Below code is to update the REG_REP_EOD_SUBMISSION_TRACKER */
				RegRepEodSubmissionTracker regRepEodSubmissionTracker = new RegRepEodSubmissionTracker();
				regRepEodSubmissionTracker.setEodReportId(eodReportId);
				regRepEodSubmissionTracker.setSubmissionId(submitIdLong);
				regRepEodSubmissionTracker.setSentBy(sentBy);
				regRepEodSubmissionTracker.setSentTo(sendTo);
				regRepEodSubmissionTracker.setResponseStatus(status);
				regRepEodSubmissionsTrackerDaoImpl.updateResponseDetails(regRepEodSubmissionTracker);

				/***
				 * If response=NACK, then try getting the reason details and persist in database
				 ***/
				reasons = fpMLResponse.getReasons();

				if (null != reasons && reasons.size() > 0)
				{

					for (Reason reason : reasons)
					{
						if (null == reason) continue;
						RegRepEodException currRegRepEodException = new RegRepEodException();
						currRegRepEodException.setSubmissionId(submitIdLong);
						currRegRepEodException.setCode(reason.reasonCode);
						currRegRepEodException.setDescription(reason.description);
						currRegRepEodException.setType(reason.type + "");
						currRegRepEodException.setSeverity(reason.severity + "");
						currRegRepEodException.setStatus(Constants.EXCEPTION_OPEN_STATUS);
						currRegRepEodException.setInsertTimeStamp(new Timestamp(CalendarUtils.getCurrentDateInUTC().getTime()));

						regRepEodExceptionList.add(currRegRepEodException);

					}

					regRepEodExceptionDaoImpl.batchInsertEodException(regRepEodExceptionList);

				}
			}
			else
			{
				logger.info(">>>>>>>>> BELOW RESPONSE COULD BE RESULT OF SUBMISSION FROM DIFFERENT ENVIRONMENT/PLATFORM OR IT IS NOT WELLS FARGO SUBMISSION <<<<<<<<<  \n " 
			                           + StringUtils.substring(responseString, 0, 550));
				
				//prepare allegeMessage by parsing original message content from response
				currRegRepAllegeMessage = regRepAllegeMessageMapper.createRegRepAllegeMessage(reportingContext);
				long allegeMsgId = 0;

				allegeMsgId = regRepAllegeMessageDao.insertandGetId(currRegRepAllegeMessage);

				if (allegeMsgId > 0)
				{
					RegRepAllegePayload currRegRepAllegePayload = new RegRepAllegePayload();
					currRegRepAllegePayload.setAllegeMessageId(allegeMsgId);
					currRegRepAllegePayload.setPayload(responseString);

					if (StringUtils.equalsIgnoreCase(currRegRepAllegeMessage.getReportType(), Constants.MESSAGE_TYPE_SNAPSHOT)) 
						currRegRepAllegePayload.setPayloadType(Constants.MESSAGE_TYPE_SNAPSHOT);
					 if (StringUtils.equalsIgnoreCase(currRegRepAllegeMessage.getReportType(), Constants.MESSAGE_TYPE_VALUATION)) 
						currRegRepAllegePayload.setPayloadType(Constants.MESSAGE_TYPE_VALUATION);

					regRepAllegePayloadDao.insertRegRepAllegePayload(currRegRepAllegePayload);
				}

			}
		}
		catch (Exception ex)
		{
			logger.error("######### exception occurred inside insertRegRepEodSubmissionResponse method " + ExceptionUtils.getFullStackTrace(ex));
			logger.info("Not able to persist following response in EodSubmissionResponse table : /n" + fpMLResponse.getOriginalMessage());

		}
	}

	public boolean updateRegRepEodPayloadForRefresh(ReportingContext context)
	{
		logger.info("Entering updateRegRepEodPayloadForRefresh method");

		boolean success = false;

		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);

		regRepEodPayloadDaoImpl.updateRegRepEodPayloadForRefresh(context);
		success = true;

		logger.info("Successfully updated Eod Payload for refresh service with report Id " + context.getEodRefreshRptId());
		return success;
	}

	public boolean updateEodBufferIneligible(ReportingContext context, RegRepEodReport dto)
	{
		logger.info("Entering updateEodBufferIneligible method");

		boolean success = false;

		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);
		regRepEodReportDaoImpl.updateBufferIneligible(dto);

		logger.info("Successfully updated Eod Report for buffer ineligibility ");
		return success;
	}

	public boolean updateEodBufferIneligibleForSnapshot(ReportingContext context, RegRepEodReport dto)
	{
		logger.info("Entering updateEodBufferIneligibleForSnapshot method");

		boolean success = false;

		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);
		regRepEodReportDaoImpl.updateEodBufferIneligibleForSnapshot(dto);

		logger.info("Successfully updated Eod Report for buffer ineligibility ");
		return success;
	}

	public boolean isValuationExist(ReportingContext context, RegRepEodReport dto)
	{
		logger.info("Entering isValuationExist method");

		boolean isValExist = false;
		AbstractDriver.setMDCInfo(context, AbstractDriver.EodPersistenceDriver);
		isValExist = regRepEodReportDaoImpl.IsValuationExist(dto);

		return isValExist;

	}

	private boolean isBlockTrade(ReportingContext context, RegRepEodReport regRepEodReportDto, String lifeCycleEvent, String reportType, String tradeUSI, String jurisdiction)
	{

		/**
		 * Block Trade check Block trade Snapshot needs to be sent only when the allocations for
		 * Block Trade aren't complete.
		 */
		boolean isBlock = false;
		BigDecimal blockTradeNotional;
		if (Constants.BLOCK_TRADE.equals(lifeCycleEvent))
		{
			blockTradeNotional = context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getOriginalNotional();
			BigDecimal allocatedNotional = null;

			if (jurisdiction != null && Constants.JURISDICTION_CFTC.equals(jurisdiction)) allocatedNotional = regRepEodReportDaoImpl.getAllocatedNotionalForBlockTrade(tradeUSI);

			if (allocatedNotional != null && blockTradeNotional != null)
			{
				if (blockTradeNotional.compareTo(allocatedNotional) > 0)
				{
					isBlock = true;
				}

			}
		}
		return isBlock;
	}

}
