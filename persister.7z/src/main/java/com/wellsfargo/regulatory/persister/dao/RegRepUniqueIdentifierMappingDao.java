package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;

public interface RegRepUniqueIdentifierMappingDao extends Dao<RegRepUniqueIdentifierMapping>, Serializable
{
	public List<RegRepUniqueIdentifierMapping> loadUniqueIdentifierByTradeId(String tradeId);
}
