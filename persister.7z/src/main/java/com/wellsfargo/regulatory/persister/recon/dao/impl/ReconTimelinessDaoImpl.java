package com.wellsfargo.regulatory.persister.recon.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.ReconException;
import com.wellsfargo.regulatory.persister.recon.dao.ReconTimelinessDao;
import com.wellsfargo.regulatory.persister.recon.dto.ReconTimelinessDomain;



public class ReconTimelinessDaoImpl  implements RowMapper<ReconTimelinessDomain>,ReconTimelinessDao {

	protected JdbcTemplate jdbcTemplate;

	public ReconTimelinessDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return ReconTimelinessDomain
	 */
	@Override
	public ReconTimelinessDomain mapRow(ResultSet rs, int row) throws SQLException
	{
		ReconTimelinessDomain dto = new ReconTimelinessDomain();
		dto.setSystem(rs.getString(1));
		dto.setAssetClass(rs.getString(2));
		dto.setProduct(rs.getString(3));
		dto.setSubProduct(rs.getString(4));
		dto.setFoExecDate(Long.parseLong(null!=rs.getString(5)?rs.getString(5):"0"));
		dto.setExecutionDate(Long.parseLong(null!=rs.getString(6)?rs.getString(6):"0"));
		dto.setFoTlcExecDate(Long.parseLong(null!=rs.getString(7)?rs.getString(7):"0"));
		dto.setFoMarketType(rs.getString(8));
		dto.setFoTradeStatus(rs.getString(9));
		dto.setFoTradeId(rs.getString(10));
		dto.setFoTradeVersion(rs.getString(11));
		dto.setFoUsi(rs.getString(12));
		dto.setFoSdrEligibleTrade(rs.getString(13));
		dto.setReportingParty(rs.getString(14));
		dto.setSdrEligibility(rs.getString(15));
		dto.setFoRepFlag(rs.getString(16));
		dto.setFoSdrReportable(rs.getString(17));
		dto.setFoJurisdiction(rs.getString(18));
		dto.setCptyClassification(rs.getString(19));
		dto.setReportingJurisdiction(rs.getString(20));
		dto.setIrsRecvTimestamp(Long.parseLong(null!=rs.getString(21)?rs.getString(21):"0"));
		dto.setIrsSendId(rs.getString(22));
		dto.setIrsTradeId(rs.getString(23));
		dto.setIrsTradeVersion(rs.getString(24));
		dto.setIrsUsi(rs.getString(25));
		dto.setIrsDtccUsi(rs.getString(26));
		dto.setIrsTradeStatus(rs.getString(27));
		dto.setIrsTransactionType(rs.getString(28));
		dto.setIrsRepFlag(rs.getString(29));
		dto.setIrsReportUploadTime(Long.parseLong(null!=rs.getString(30)?rs.getString(30):"0"));
		dto.setIrsMsgType(rs.getString(31));
		dto.setIrsMsgStatus(rs.getString(32));
		dto.setIrsDescription(rs.getString(33));
		dto.setGtrAction(rs.getString(34));
		dto.setGtrUsi(rs.getString(35));
		dto.setDtccRespRecv(rs.getString(36));
		dto.setDtccRespAcceptance(rs.getString(37));
		dto.setSdrSubmissionTime(Long.parseLong(null!=rs.getString(38)?rs.getString(38):"0"));
		dto.setGtrTransType(rs.getString(39));
		dto.setGtrRepFlag(rs.getString(40));
		dto.setGtrAssetClass(rs.getString(41));
		dto.setGtrTradeParty1ReferenceNumber(rs.getString(42));
		dto.setGtrMessageType(rs.getString(43));
		dto.setGtrExecutionTime(Long.parseLong(null!=rs.getString(44)?rs.getString(44):"0"));
		dto.setReconId(rs.getString(45));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recon_timeliness_view";
	}

	/** 
	 * Returns all rows from the timeliness table that match the criteria ''.
	 */
	@Transactional
	public List<ReconTimelinessDomain> findAll() throws ReconException
	{
		String errorString = null;
		try {
			return jdbcTemplate.query("SELECT system,asset_class,product,sub_product,fo_exec_date,execution_date,fo_tlc_exec_date,fo_market_type,fo_trade_status,fo_trade_id,fo_trade_version,fo_usi,fo_sdr_eligible_trade,reporting_party,sdr_eligibility,fo_rep_flag,fo_sdr_reportable,fo_jurisdiction,fo_cpty_clarification,fo_reporting_jurisdiction,irs_recv_timestamp,irs_send_id,irs_trade_id,irs_trade_version,irs_usi,irs_dtcc_usi,irs_trade_status,irs_trans_type,irs_rep_flag,irs_report_upload_time,irs_message_type,irs_msg_status,irs_description,gtr_action,gtr_usi,gtr_resp_recv,gtr_resp_acceptance,gtr_submission_time,gtr_trans_type,gtr_rep_flag,gtr_asset_class,gtr_trade_party_1_reference_number,gtr_message_type,gtr_exec_time,f_recon_id FROM " + getTableName(), this);
		}
		catch (Exception ex) {
			errorString = "Exception occurred inside ReconTimelinessDaoImpl:  " + ExceptionUtils.getFullStackTrace(ex);		
			throw new ReconException("ReconTimelinessDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.RECON_ERROR, errorString);
		}
		
	}
	

}
