package com.wellsfargo.regulatory.persister.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;

public class RegRepEodPayloadRowMapper implements RowMapper<RegRepEodSubmission>{
	
	@Override
	public RegRepEodSubmission mapRow(ResultSet rs, int rowNum) throws SQLException {
 
		RegRepEodSubmission payload = new RegRepEodSubmission();
		
		payload.setSdrReport(rs.getString("PAYLOAD"));
		payload.setEodReportId(rs.getString("EOD_REPORT_ID"));
		payload.setAssetClass(rs.getString("ASSET_CLASS"));
		payload.setTradeId(rs.getString("SWAP_TRADE_ID"));
		payload.setReportType(rs.getString("REPORT_TYPE"));
		payload.setEodReportTimestamp(rs.getTimestamp("INSERT_TIMESTAMP"));
		payload.setRegRepMessageId(rs.getString("SRC_MESSAGE_ID"));	
		payload.setJurisdiction(rs.getString("JURISDICTION"));	
		payload.setEventType(rs.getString("EVENT_TYPE"));	
		payload.setTradeUsi(rs.getString("TRADE_USI"));	
		payload.setTradeUti(rs.getString("TRADE_UTI"));	
		
		return payload;
	}


}
