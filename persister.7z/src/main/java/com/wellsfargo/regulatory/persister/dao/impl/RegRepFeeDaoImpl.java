package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepFeeDao;
import com.wellsfargo.regulatory.persister.dto.RegRepFee;

public class RegRepFeeDaoImpl extends AbstractDaoImpl<RegRepFee> implements RegRepFeeDao
{

	private static final long serialVersionUID = -2937939103661610662L;

	@Override
	public Class<RegRepFee> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepFee.class;
	}
	


}
