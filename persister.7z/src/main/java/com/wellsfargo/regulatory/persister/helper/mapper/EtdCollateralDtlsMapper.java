package com.wellsfargo.regulatory.persister.helper.mapper;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CollateralValueType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.persister.etd.dto.EtdCollateralDtls;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;

/**
 * @author Raji Komatreddy
 */
public class EtdCollateralDtlsMapper
{
	private static Logger logger = Logger.getLogger(EtdCollateralDtlsMapper.class.getName());

	public EtdCollateralDtls populateEtdCollateralDtls(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		logger.info("inside EtdCollateralDtlsMapper populateEtdValuationDtls method");
		Date current_date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(EtdConstants.ETD_COBDATE_FORMAT);
		String cobDate = dateFormat.format(current_date);

		SdrRequest sdrRequest = null;
		CollateralValueType collateralValue = null;

		String srcSysMessageId = null;

		EtdCollateralDtls currEtdCollateralDtls = new EtdCollateralDtls();

		sdrRequest = context.getSdrRequest();

		currEtdCollateralDtls.setCobDate(cobDate);
		currEtdCollateralDtls.setCreateDatetime(current_date);
		currEtdCollateralDtls.setEtdPayload(etdPayload);

		if (null != sdrRequest)
		{
			srcSysMessageId = sdrRequest.getMessageId();
			currEtdCollateralDtls.setSrcSysMessageId(srcSysMessageId);

			collateralValue = sdrRequest.getCollateral();
			if (null != collateralValue)
			{
				currEtdCollateralDtls.setAction(collateralValue.getAction());
				currEtdCollateralDtls.setCurrency(collateralValue.getCurrency());
				currEtdCollateralDtls.setDataSubmitterLei(collateralValue.getDataSubmitterLEI());
				currEtdCollateralDtls.setExecutionagentLei(collateralValue.getExecutionAgentLEI());
				if (null != collateralValue.isExecutionAgentMaskingIndicator()) currEtdCollateralDtls.setExecutionAgentMaskInd(collateralValue.isExecutionAgentMaskingIndicator().toString());
				currEtdCollateralDtls.setPortfolioCode(collateralValue.getPortfolioCode());
				currEtdCollateralDtls.setPortfolioIndicator(collateralValue.getPortfolioIndicator());
				if (null != collateralValue.getReportingDate()) currEtdCollateralDtls.setReportingDate(CalendarUtils.xmlGregCalToCustomFormat(collateralValue.getReportingDate(), null));
				currEtdCollateralDtls.setTradePartyLei(collateralValue.getTradePartyLEI());

				if (null != collateralValue.getValuationDate()) currEtdCollateralDtls.setValuationDate(CalendarUtils.xmlGregCalToUtcFormat(collateralValue.getValuationDate()));
				currEtdCollateralDtls.setValue(collateralValue.getValue());
				
				if(null !=  collateralValue.isSuppressReporting() && collateralValue.isSuppressReporting())
				{
					currEtdCollateralDtls.setSuppressReporting(EtdConstants.ETD_TRUE);	
				}
				else
				{
					currEtdCollateralDtls.setSuppressReporting(EtdConstants.ETD_FALSE);	
				}
				

			}

		}

		logger.info("exiting EtdValuationDtlsMapper populateEtdValuationDtls method");

		return currEtdCollateralDtls;

	}

}
