package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepMappingBussAccLeiDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMappingBussaccidLei;
import com.wellsfargo.regulatory.persister.dto.RegRepMappingBussaccidLeiId;

@Transactional
@Repository
public class RegRepMappingBussAccLeiDaoImpl extends AbstractDaoImpl<RegRepMappingBussaccidLei> implements RegRepMappingBussAccLeiDao 
{
	private static final String QUERY_FOR_DISTINCT_LEGAL_IDS = "select distinct regRepMappingBussaccidLei.legal_id,  regRepMappingBussaccidLei.lei, regRepMappingBussaccidLei.bus_acc_id, regRepMappingBussaccidLei.legal_name  from REG_REP_MAPPING_BUSSACCID_LEI regRepMappingBussaccidLei";
	
	public List<RegRepMappingBussaccidLei> fetchAllDistinctLegalIds() 
	{
		SQLQuery query = findByNamedNativeQuery(QUERY_FOR_DISTINCT_LEGAL_IDS);
		List<RegRepMappingBussaccidLei> bussaccidLeis = new ArrayList<RegRepMappingBussaccidLei>();
		
		List<Object[]> tempList = query.list();
		tempList.stream().forEach((record)->{
			RegRepMappingBussaccidLei bussaccidLei = new RegRepMappingBussaccidLei();
			RegRepMappingBussaccidLeiId id = new RegRepMappingBussaccidLeiId();
			id.setLegalId((String) record[0]);
			id.setLei((String) record[1]);
			id.setBusAccId((String) record[2]);
			id.setLegalName((String) record[3]);
			bussaccidLei.setId(id);
			bussaccidLeis.add(bussaccidLei);
			
		});
		
		return bussaccidLeis;
	}
	
	@Override
	public Class<RegRepMappingBussaccidLei> getEntityClass() 
	{
		// TODO Auto-generated method stub
		return RegRepMappingBussaccidLei.class;
	}
	

}
