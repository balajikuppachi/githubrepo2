package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;

/**
 * @author Raji Komatreddy
 *  DAO class to access data from REG_REP_EOD_JON_DETAILS
 */
@Component
public class RegRepEodJobDetailsDaoImpl implements RowMapper<RegRepEodJobDetails>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	String sql = "select * from REG_REP_EOD_JOB_DETAILS where job_name = ? and report_type= ? and jurisdiction=?  and asset_class = ?";

	public RegRepEodJobDetails findByJobName(String jobName, String reportType, String jurisdiction, String assetClass) throws SQLException
	{
		List<RegRepEodJobDetails> regRepEodJobDetails = null;
		
		regRepEodJobDetails=jdbcTemplate.query(sql, new Object[]{ jobName,reportType,jurisdiction,assetClass}, this);

		if(GeneralUtils.IsListNullOrEmpty(regRepEodJobDetails))
			return null;
		return regRepEodJobDetails.get(0);
	}

	@Override
	public RegRepEodJobDetails mapRow(ResultSet rs, int row) throws SQLException
	{
		RegRepEodJobDetails currRegRepEodJobDetails = new RegRepEodJobDetails();
		currRegRepEodJobDetails.setJobDetailsId(rs.getLong(1));
		currRegRepEodJobDetails.setJobType(rs.getString(2));
		currRegRepEodJobDetails.setJobName(rs.getString(3));
		currRegRepEodJobDetails.setJobDesc(rs.getString(4));
		currRegRepEodJobDetails.setJobFreq(rs.getString(5));
		currRegRepEodJobDetails.setCreateDatetime(rs.getTimestamp(6));
		currRegRepEodJobDetails.setReportType(rs.getString(7));
		currRegRepEodJobDetails.setJurisdiction(rs.getString(8));
		currRegRepEodJobDetails.setAssetClass(rs.getString(9));
		return currRegRepEodJobDetails;
	}

}
