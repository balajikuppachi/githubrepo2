package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.eod.dto.RegRepAllegePayload;

/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class RegRepAllegePayloadDao implements RowMapper<RegRepAllegePayload>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	String insertSql = "INSERT INTO REG_REP_ALLEGE_PAYLOAD (allege_message_id,payload_type,payload) VALUES (?, ?, ?)";

	@Override
    public RegRepAllegePayload mapRow(ResultSet rs, int rowNum) throws SQLException
    {
		RegRepAllegePayload currRegRepAllegePayload = new RegRepAllegePayload();
	    return currRegRepAllegePayload;
    }
	
	public void insertRegRepAllegePayload(RegRepAllegePayload regRepAllegePayload)
	{		
		jdbcTemplate.update(insertSql, new Object[] {regRepAllegePayload.getAllegeMessageId(), regRepAllegePayload.getPayloadType(),
				regRepAllegePayload.getPayload()});		
	}

}
