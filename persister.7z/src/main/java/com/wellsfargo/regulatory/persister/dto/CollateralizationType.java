package com.wellsfargo.regulatory.persister.dto;


public class CollateralizationType {
	
	String tradeID;
	
	String collateralizationType;
	
	public String getTradeID() {
		return tradeID;
	}
	public void setTradeID(String tradeID) {
		this.tradeID = tradeID;
	}
	public String getcollateralizationType() {
		return collateralizationType;
	}
	public void setcollateralizationType(String collateralizationType) {
		this.collateralizationType = collateralizationType;
	}
}
