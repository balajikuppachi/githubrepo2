package com.wellsfargo.regulatory.persister.etd.dao.impl;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;


public class EtdTradeJurisdictionDaoImpl extends AbstractDaoImpl<EtdTradeJurisdiction> implements EtdTradeJurisdictionDao
{
	/**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    
    @Override
	public Class<EtdTradeJurisdiction> getEntityClass()
	{
		return EtdTradeJurisdiction.class;
	}


}
