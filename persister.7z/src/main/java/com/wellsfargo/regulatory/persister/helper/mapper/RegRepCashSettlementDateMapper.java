package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType.PaymentDates;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType.ValuationDates;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepCashSettlement;
import com.wellsfargo.regulatory.persister.dto.RegRepCashSettlementTypeDate;
import com.wellsfargo.regulatory.persister.dto.RegRepCashSettlementTypeDateId;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepCashSettlementDateMapper
{

	private static Logger logger = Logger.getLogger(RegRepCashSettlementDateMapper.class.getName());

	public RegRepCashSettlementTypeDate createCashSettlementTypeDate(RegRepCashSettlement dbCashSettlement, ValuationDates ipValDate, PaymentDates ipPayDate, int id)
	{

		RegRepCashSettlementTypeDate dbDate = null;
		RegRepCashSettlementTypeDateId dbDateId = null;
		String dateType = null;

		if (null == dbCashSettlement || (null == ipValDate && null == ipPayDate))
		{
			logger.debug("RegRepCashSettlementTypeDate object could not be " + "populated due to invalid incoming data");
			return dbDate;
		}

		dbDate = new RegRepCashSettlementTypeDate();
		dbDate.setRegRepCashSettlement(dbCashSettlement);

		dbDateId = createRegRepCashSettlementTypeDateId(dbDate, id);
		dbDate.setId(dbDateId);

		if (null != ipValDate)
		{

			dateType = Constants.DATE_TYPE_VALUATION;
			dbDate.setCashSettlementDate(CalendarUtils.toDate(ipValDate.getValuationDate()));

		}
		else if (null != ipPayDate)
		{

			dateType = Constants.DATE_TYPE_PAYMENT;
			dbDate.setCashSettlementDate(CalendarUtils.toDate(ipPayDate.getPaymentDate()));
		}

		dbDate.setCashSettlementDateType(dateType);

		return dbDate;
	}

	private RegRepCashSettlementTypeDateId createRegRepCashSettlementTypeDateId(RegRepCashSettlementTypeDate dbDate, int id)
	{

		RegRepCashSettlementTypeDateId dateId = null;

		if (null == dbDate)
		{
			logger.debug("RegRepCashSettlementTypeDateId object could not be " + "populated due to invalid incoming data");
			return dateId;
		}

		dateId = new RegRepCashSettlementTypeDateId();

		dateId.setRegRepCashSettlementTypeDateId(id);
		dateId.setRegRepCashSettlementId(dbDate.getRegRepCashSettlement().getRegRepCashSettlementId());

		return dateId;
	}

}
