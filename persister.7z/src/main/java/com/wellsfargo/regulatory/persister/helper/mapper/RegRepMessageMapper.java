package com.wellsfargo.regulatory.persister.helper.mapper;

import static com.wellsfargo.regulatory.commons.keywords.Constants.Bilateral;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CustomBackloadType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.enums.RegRepMessageTypeEum;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepCustomBackload;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepMessageMapper
{

	private static Logger logger = Logger.getLogger(RegRepMessageMapper.class.getName());

	public RegRepMessage createDefaultRegRepMessage(String sdrMessageId, RegRepMessageTypeEum msgType)
	{

		logger.debug("Generating an empty default message object for persistence");

		RegRepMessage dbMessage = null;

		if (StringUtils.isBlank(sdrMessageId))
		{

			logger.error("Failed to create DB Message since message id provided was null");
			return dbMessage;
		}

		dbMessage = new RegRepMessage();

		dbMessage.setRegRepMessageId(sdrMessageId);
		dbMessage.setLifecycleEventType(Constants.VALUE_TYPE_INDETERMINED);
		dbMessage.setRegRepMessageTimestamp(new Date());

		dbMessage.setIsClearedTrade(Constants.APP_FALSE);
		dbMessage.setIsSwapswireTrade(Constants.APP_FALSE);

		dbMessage.setIsReportingParty(Constants.APP_TRUE);
		dbMessage.setIsReportable(Constants.APP_TRUE);
		dbMessage.setIsFiltered(Constants.APP_FALSE);
		dbMessage.setIsInvalid(Constants.APP_FALSE);
		dbMessage.setMessageType(msgType.type());
		

		logger.debug("Returning generated empty default message");
		return dbMessage;
	}

	public RegRepMessage createMessageFromInputXML(ReportingContext context, RegRepTrade trade, 
			RegRepMessage parentMessage, RegRepMessage msgToUpdate)
	{

		LegType 						leg 				= null;
		TradeHeaderType 				tradeHeader 		= null;
		List<LegType> 					legs 				= null;
		ProductKeysType 				productKey 			= null;
		ProductType 					product 			= null;
		SdrRequest 						sdrRequest 			= null;
		LifeCycleType 					lifeCycle 			= null;
		PayloadTypeEnum 				contextType 		= null;		
		TradeType						tradeType			= null;
		CustomBackloadType				backloadType		= null;
		TradeDetailType					tradeDetailType		= null;
		String							eventType			= null;
		ClearingType					clearing			= null;
		boolean 						isCustomBackload 	= false;
		RegRepCustomBackloadMapper		backloadMapper		= null;
		Set<RegRepCustomBackload>		regRepCustBackloads	= null; 
				
		if (context == null)	
			return null;
		
		if (null == msgToUpdate)
			msgToUpdate = new RegRepMessage();
		
		sdrRequest = context.getSdrRequest();

		if (null != sdrRequest){

			msgToUpdate.setExternalMessageId(sdrRequest.getMessageId());
			msgToUpdate.setAssetClass(sdrRequest.getAssetClass());


			tradeType 		= sdrRequest.getTrade();
			
			if(null != tradeType){

				tradeHeader 	= tradeType.getTradeHeader();
				tradeDetailType = tradeType.getTradeDetail();
				backloadType	= tradeType.getCustomBackload();


				if(null != tradeHeader){

					msgToUpdate.setActionType(tradeHeader.getAction());
					msgToUpdate.setTradeExecutionTimestamp(CalendarUtils
							.toDate(tradeHeader.getExecutionDateTime()));
					msgToUpdate.setTradeExecutionVenue(tradeHeader
							.getExecutionVenue());
					msgToUpdate.setTradeStatus(tradeHeader.getStatus());

					msgToUpdate.setEntityLei(tradeHeader.getProcessingOrgLEI());
					msgToUpdate.setCounterpartyLei(tradeHeader.getCounterpartyLEI());
					
					msgToUpdate.setIsSwapswireTrade(ConversionUtils.booleanToDbString(ReportingDataUtils
							.isSwapWireTrade(tradeHeader)));

					lifeCycle = tradeHeader.getLifeCycle();

					if(null != lifeCycle){

						msgToUpdate.setLifecycleEventType(
								StringUtils.trimToEmpty(lifeCycle.getEventType()));

						eventType = lifeCycle.getEventType();

						if(null != eventType){

							eventType = eventType.toUpperCase();

							if(eventType.contains(Bilateral))								
								msgToUpdate.setIsClearedTrade(Constants.APP_TRUE);
						}

						clearing = lifeCycle.getClearing();

						if(null != clearing){

							if(clearing.isClearedTrade()!=null && clearing.isClearedTrade())
								msgToUpdate.setIsClearedTrade(Constants.APP_TRUE);
						}						
					}			
					
					
					if(null != backloadType){
						
						isCustomBackload = backloadType.isIsCustomBackload();
						
						backloadMapper 		= new RegRepCustomBackloadMapper();
						regRepCustBackloads	= backloadMapper.createRegRepCustomBackload(backloadType, msgToUpdate);
						msgToUpdate.setRegRepCustomBackloads(regRepCustBackloads);
					}
					
					if (isCustomBackload)						
						msgToUpdate.setRegRepMessageTimestamp(CalendarUtils.toDate(backloadType.getOrginalEnteredDateTime()));					
				}						

				if(null != tradeDetailType){

					product = tradeDetailType.getProduct();

					if(null != product){
						
						msgToUpdate.setProductType(product.getProductType());
						msgToUpdate.setProductSubType(product.getProductSubType());			

						productKey = product.getProductKeys();

						if(null != productKey){

							msgToUpdate.setTradeUsi(StringUtils.trimToEmpty(productKey.getUSI()));
							msgToUpdate.setTradeUti(productKey.getUTI());
							msgToUpdate.setPrevUsi(productKey.getPrevUSI());
						}
					}

					legs = product.getLeg();

					if (!GeneralUtils.IsListNullOrEmpty(legs))
					{
						leg = legs.get(0);

						if (leg != null && leg.getNotional() != null)
						{
							msgToUpdate.setTradeNotional(leg.getNotional().doubleValue());
						}
					}
				}								
			}
			
			contextType = context.getContextType();
			if (null != contextType){

				if (PayloadTypeEnum.FpML.equals(contextType)){

					msgToUpdate.setMessageType(RegRepMessageTypeEum.SDR_REPORT.type());
				}else if (PayloadTypeEnum.REG_REP_XML.equals(contextType)){
					
					if (context.getPayload().contains(Constants.ConfirmationKey + Constants.UNDERSCORE))

						msgToUpdate.setMessageType(RegRepMessageTypeEum.REG_REP_CONF_ALERT.type());
					else
						msgToUpdate.setMessageType(RegRepMessageTypeEum.SDR_TRADE.type());

				}else if (PayloadTypeEnum.SDR_RESPONSE_ACK.equals(contextType) || PayloadTypeEnum.SDR_RESPONSE_NACK.equals(contextType)){

					msgToUpdate.setMessageType(RegRepMessageTypeEum.SDR_RESPONSE.type());
				}else if (PayloadTypeEnum.REG_REP_FILTERED.equals(contextType)){

					msgToUpdate.setMessageType(RegRepMessageTypeEum.SDR_TRADE.type());
				}
			}

		}else{

			// - This is only in case of a response && and a Reporting Party response
			if (null != parentMessage)
			{

				msgToUpdate.setActionType(parentMessage.getActionType());
				msgToUpdate.setIsClearedTrade(parentMessage.getIsClearedTrade());
				msgToUpdate.setLifecycleEventType(parentMessage.getLifecycleEventType());
				
				//For GTR trades need to copy USI from the derived context object
				if (context.getUsi() == null){
					msgToUpdate.setTradeUsi(StringUtils.trimToEmpty(parentMessage.getTradeUsi()));
				}else{
					msgToUpdate.setTradeUsi(StringUtils.trimToEmpty(context.getUsi()));
				}
				
				msgToUpdate.setTradeUti(parentMessage.getTradeUti());
				msgToUpdate.setIsSwapswireTrade(parentMessage.getIsSwapswireTrade());
				msgToUpdate.setTradeExecutionTimestamp(parentMessage.getTradeExecutionTimestamp());
				msgToUpdate.setAssetClass(parentMessage.getAssetClass());
				msgToUpdate.setProductType(parentMessage.getProductType());
				msgToUpdate.setProductSubType(parentMessage.getProductSubType());
				msgToUpdate.setTradeStatus(parentMessage.getTradeStatus());

				msgToUpdate.setMessageType(RegRepMessageTypeEum.SDR_RESPONSE.type());
				msgToUpdate.setIsReportingParty(Constants.APP_TRUE);
				
				msgToUpdate.setEntityLei(parentMessage.getEntityLei());
				msgToUpdate.setCounterpartyLei(parentMessage.getCounterpartyLei());
				msgToUpdate.setTradeNotional(parentMessage.getTradeNotional());
				msgToUpdate.setTradeExecutionVenue(parentMessage.getTradeExecutionVenue());
				
			}

		}

		msgToUpdate.setIsReportingParty(ConversionUtils.booleanToDbString(context.isReportingParty()));
		msgToUpdate.setIsReportable(ConversionUtils.booleanToDbString(context.isReportable()));
		msgToUpdate.setIsFiltered(ConversionUtils.booleanToDbString(context.isFiltered()));
		msgToUpdate.setIsInvalid(ConversionUtils.booleanToDbString(context.isInvalid()));
		msgToUpdate.setRegRepMessageId(context.getMessageId());
	
		msgToUpdate.setRegRepMessagUpdateTimestamp(new Date());

		msgToUpdate.setRegRepTrade(trade);
		
		msgToUpdate = harmonizeMessage(msgToUpdate);

		return msgToUpdate;
	}
	
	
	public RegRepMessage harmonizeMessage(RegRepMessage msg){
		
		if(null == msg)
			return msg;
		
		if(null == msg.getLifecycleEventType())
			msg.setLifecycleEventType("");
		
		if(null == msg.getIsClearedTrade())
			msg.setIsClearedTrade(Constants.APP_FALSE);
		
		if(null == msg.getIsSwapswireTrade())
			msg.setIsSwapswireTrade(Constants.APP_FALSE);
		
//		if(null == msg.getMessageType())
//			msg.settMessageType(RegRepMessageTypeEum.);
		
		if(null == msg.getIsReportable())
			msg.setIsReportable(Constants.APP_TRUE);
		
		if(null == msg.getIsReportingParty())
			msg.setIsReportingParty(Constants.APP_TRUE);
		
		if(null == msg.getIsFiltered())
			msg.setIsFiltered(Constants.APP_FALSE);
		
		if(null == msg.getIsInvalid())
			msg.setIsInvalid(Constants.APP_FALSE);
		
		if(null == msg.getRegRepMessageTimestamp())
			msg.setRegRepMessageTimestamp(new Date());
		
		
		return msg;
	}
			

}
