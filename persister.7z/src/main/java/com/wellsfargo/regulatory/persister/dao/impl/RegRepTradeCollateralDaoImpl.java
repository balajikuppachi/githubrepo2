package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.dao.RegRepTradeCollateralDao;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeCollateral;


public class RegRepTradeCollateralDaoImpl extends AbstractDaoImpl<RegRepTradeCollateral> implements RegRepTradeCollateralDao {
	
	private JdbcTemplate jdbcTemplate;
	
	private static String EQTICKER_QUERY = "SELECT TRADE_ID, LEGAL_ID, SRC_SYSTEM, PRODUCT_TYPE	, TICKER_ID, COLLATERALIZATION FROM REG_REP_TRADE_COLLATERALIZATION WHERE TICKER_ID = ? and SRC_SYSTEM = ? ORDER BY TRADE_ID";
	private static String TICKER_QUERY = "SELECT TRADE_ID, LEGAL_ID, SRC_SYSTEM, PRODUCT_TYPE	, TICKER_ID, COLLATERALIZATION FROM REG_REP_TRADE_COLLATERALIZATION WHERE TRADE_ID = ? and SRC_SYSTEM = ? ORDER BY TRADE_ID";

	public RegRepTradeCollateralDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public Class<RegRepTradeCollateral> getEntityClass() {
		// TODO Auto-generated method stub
		return RegRepTradeCollateral.class;
	}

	@Override
	public List<RegRepTradeCollateral> findWhereEQTickerIDSourceEquals(String tickerID, String srcSystem) {
		
		List<RegRepTradeCollateral> collateralList = new ArrayList<RegRepTradeCollateral>();
		try {
			 List<Map<String, Object>> objectMap = jdbcTemplate.queryForList(EQTICKER_QUERY, tickerID, srcSystem);
			 for(Map rows: objectMap) {
				 RegRepTradeCollateral regRepTradeCollateral = new RegRepTradeCollateral();
				 
				 regRepTradeCollateral.setTradeId((String) rows.get("TRADE_ID"));
				 regRepTradeCollateral.setLegalId((String)rows.get("LEGAL_ID"));
				 regRepTradeCollateral.setSrcSystem((String)rows.get("SRC_SYSTEM"));
				 regRepTradeCollateral.setProductType((String)rows.get("PRODUCT_TYPE"));
				 regRepTradeCollateral.setTickerId((String)rows.get("TICKER_ID"));
				 regRepTradeCollateral.setCollateralization((String)rows.get("COLLATERALIZATION"));
				 collateralList.add(regRepTradeCollateral);
			 }
			 
		}
		catch (Exception e) {
			
		}
		
		 return collateralList;
		
		
	}

	@Override
	public List<RegRepTradeCollateral> findWhereTradeIdSourceEquals(String trade_id, String srcSystem) {
		List<RegRepTradeCollateral> collateralList = new ArrayList<RegRepTradeCollateral>();
		try {
			 List<Map<String, Object>> objectMap = jdbcTemplate.queryForList(TICKER_QUERY, trade_id, srcSystem);
			 for(Map rows: objectMap) {
				 RegRepTradeCollateral regRepTradeCollateral = new RegRepTradeCollateral();
				 
				 regRepTradeCollateral.setTradeId((String) rows.get("TRADE_ID"));
				 regRepTradeCollateral.setLegalId((String)rows.get("LEGAL_ID"));
				 regRepTradeCollateral.setSrcSystem((String)rows.get("SRC_SYSTEM"));
				 regRepTradeCollateral.setProductType((String)rows.get("PRODUCT_TYPE"));
				 regRepTradeCollateral.setTickerId((String)rows.get("TICKER_ID"));
				 regRepTradeCollateral.setCollateralization((String)rows.get("COLLATERALIZATION"));
				 collateralList.add(regRepTradeCollateral);
			 }
			 
		}
		catch (Exception e) {
			
		}
		
		 return collateralList;
	}
	
	
	

}
