package com.wellsfargo.regulatory.persister.dataservices.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.dataservices.dto.RegRepDsPayload;


public interface RegRepDsPayloadDao  extends Serializable, Dao<RegRepDsPayload>
{
	public RegRepDsPayload loadDsMsgByMessageIdAndType(String messageId, String payLoadType);
}
