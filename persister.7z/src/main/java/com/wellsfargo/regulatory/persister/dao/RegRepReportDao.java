package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepReport;

public interface RegRepReportDao extends Dao<RegRepReport>, Serializable
{
	/***
	 * 
	 * @param externalMsgId
	 * @return reports
	 */
	public List<RegRepReport> loadRegRepRptsByExternalMsgId(String externalMsgId);
	
	/**
	 * 
	 * @param tradeId
	 * @return reports
	 */
	public List<RegRepReport> loadRegRepRptsBySwapTradeId(String tradeId);

	List<RegRepReport> loadRegRepRptsByReportId(List<String> reportIds);
	
}
