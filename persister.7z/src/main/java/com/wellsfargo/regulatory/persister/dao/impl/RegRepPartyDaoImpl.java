package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepPartyDao;
import com.wellsfargo.regulatory.persister.dto.RegRepParty;

public class RegRepPartyDaoImpl extends AbstractDaoImpl<RegRepParty> implements RegRepPartyDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6355687634193731179L;

	@Override
	public Class<RegRepParty> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepParty.class;
	}


}
