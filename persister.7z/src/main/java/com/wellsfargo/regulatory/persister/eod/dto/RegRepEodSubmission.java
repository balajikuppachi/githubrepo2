package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class RegRepEodSubmission implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private long submissionId;
	private String eodReportId ;
	private Date asOfDate;
	private String sdrReport;
	private String status;
	private String swapTrade;
	private String reportType;
	private Timestamp insertTimeStamp;
	private Timestamp submissionTimeStamp;
	
	public long getSubmissionId()
	{
		return submissionId;
	}
	public void setSubmissionId(long submissionId)
	{
		this.submissionId = submissionId;
	}
	public String getEodReportId()
	{
		return eodReportId;
	}
	public void setEodReportId(String eodReportId)
	{
		this.eodReportId = eodReportId;
	}
	public Date getAsOfDate()
	{
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}
	public String getSdrReport()
	{
		return sdrReport;
	}
	public void setSdrReport(String sdrReport)
	{
		this.sdrReport = sdrReport;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public String getSwapTrade()
	{
		return swapTrade;
	}
	public void setSwapTrade(String swapTrade)
	{
		this.swapTrade = swapTrade;
	}
	public String getReportType()
	{
		return reportType;
	}
	public void setReportType(String reportType)
	{
		this.reportType = reportType;
	}
	public Timestamp getInsertTimeStamp()
	{
		return insertTimeStamp;
	}
	public void setInsertTimeStamp(Timestamp insertTimeStamp)
	{
		this.insertTimeStamp = insertTimeStamp;
	}
	public Timestamp getSubmissionTimeStamp()
	{
		return submissionTimeStamp;
	}
	public void setSubmissionTimeStamp(Timestamp submissionTimeStamp)
	{
		this.submissionTimeStamp = submissionTimeStamp;
	}
	

}
