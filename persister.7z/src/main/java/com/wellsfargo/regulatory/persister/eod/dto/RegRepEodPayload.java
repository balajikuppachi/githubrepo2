package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class RegRepEodPayload implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private long eodPayloadId;
	private String eodReportId ;
	private String payload;
	private String reportType;
	private Timestamp  payloadTimeStamp;
	private String lifeCycleEvent;
	
	public long getEodPayloadId()
	{
		return eodPayloadId;
	}
	public void setEodPayloadId(long eodPayloadId)
	{
		this.eodPayloadId = eodPayloadId;
	}
	public String getEodReportId()
	{
		return eodReportId;
	}
	public void setEodReportId(String eodReportId)
	{
		this.eodReportId = eodReportId;
	}
	public String getPayload()
	{
		return payload;
	}
	public void setPayload(String payload)
	{
		this.payload = payload;
	}
	public String getReportType()
	{
		return reportType;
	}
	public void setReportType(String reportType)
	{
		this.reportType = reportType;
	}
	public Timestamp getPayloadTimeStamp()
	{
		return payloadTimeStamp;
	}
	public void setPayloadTimeStamp(Timestamp payloadTimeStamp)
	{
		this.payloadTimeStamp = payloadTimeStamp;
	}
	public String getLifeCycleEvent() {
		return lifeCycleEvent;
	}
	public void setLifeCycleEvent(String lifeCycleEvent) {
		this.lifeCycleEvent = lifeCycleEvent;
	}
	
	

}
