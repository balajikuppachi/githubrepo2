package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepCashSettlement;
import com.wellsfargo.regulatory.persister.dto.RegRepExerciseDate;
import com.wellsfargo.regulatory.persister.dto.RegRepExerciseDateId;
import com.wellsfargo.regulatory.persister.dto.RegRepExerciseProvision;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepExerciseProvisionMapper
{

	private static Logger logger = Logger.getLogger(RegRepExerciseProvisionMapper.class.getName());

	public RegRepExerciseProvision createRegRepExerciseProvision(ExerciseProvisionType ipProvision, RegRepProduct dbProduct, int id)
	{

		RegRepExerciseProvision dbProvision = null;
		RegRepCashSettlementMapper cshSettlementMapper = null;
		Set<RegRepCashSettlement> cshSettlementSet = null;
		RegRepCashSettlement dbCshSettlement = null;
		CashSettlementType ipCashSettlementType = null;
		RegRepExerciseDate dbDate = null;
		Set<RegRepExerciseDate> dbDateSet = null;
		List<ExerciseProvisionType.ExerciseDates> ipDates = null;
		int exDateId = 1;

		if (null == ipProvision || null == dbProduct)
		{
			logger.debug("RegRepExerciseProvision object could not be " + "populated due to invalid incoming data");
			return dbProvision;
		}

		dbProvision = new RegRepExerciseProvision();
		dbProvision.setRegRepProduct(dbProduct);

		// dbProvisionId= createExerciseProvisionId(dbProvision, id);
		// dbProvision.setId(dbProvisionId);
		dbProvision.setRegRepExerciseProvisionId(dbProduct.getRegRepProductId());

		ipCashSettlementType = ipProvision.getCashSettlement();
		if (null != ipCashSettlementType)
		{

			cshSettlementMapper = new RegRepCashSettlementMapper();
			// cshSettlementSet = new HashSet<RegRepCashSettlement>(1); // This has been done since
			// hibernate strangely generated a set for cash settlement.

			dbCshSettlement = cshSettlementMapper.createRegRepCashSettlement(dbProvision, ipCashSettlementType);
			// cshSettlementSet.add(dbCshSettlement);

		}
		else
		{
			logger.debug("Unable to persist cash setlement, " + "since incoming data doesn't have cash settlement populated");
		}

		ipDates = ipProvision.getExerciseDates();
		if (null != ipDates)
		{

			dbDateSet = new HashSet<RegRepExerciseDate>(5);

			for (ExerciseProvisionType.ExerciseDates ipDate : ipDates)
			{

				dbDate = createRegRepExerciseDate(dbProvision, ipDate, exDateId++);
				dbDateSet.add(dbDate);
			}
		}
		else
		{
			logger.debug("Unable to persist exercise dates, " + "since incoming data doesn't have cash  exercise dates");
		}

		dbProvision.setCommencementDate(CalendarUtils.toDate(ipProvision.getCommencementDate()));
		dbProvision.setEarliestExerciseTime(CalendarUtils.toDate(ipProvision.getEarliestExerciseTime()));
		dbProvision.setEventType(ipProvision.getEventType());

		if (null != ipProvision.getExerciseDateBusinessDayConvention()) dbProvision.setExerciseDateBusinessdayConvention(ipProvision.getExerciseDateBusinessDayConvention().value());

		dbProvision.setExerciseDateHolidays(ipProvision.getExerciseDateHolidays());

		if (null != ipProvision.getExerciseType()) dbProvision.setExerciseType(ipProvision.getExerciseType().value());

		dbProvision.setExpirationDate(CalendarUtils.toDate(ipProvision.getExpirationDate()));
		dbProvision.setExpirationTime(CalendarUtils.toDate(ipProvision.getExpirationTime()));
		dbProvision.setLatestExerciseTime(CalendarUtils.toDate(ipProvision.getLatestExerciseTime()));
		dbProvision.setOptional(ConversionUtils.booleanToDbString(ipProvision.isOptional()));
		dbProvision.setRegRepCashSettlement(dbCshSettlement);
		dbProvision.setRegRepExerciseDates(dbDateSet);

		return dbProvision;
	}

	private RegRepExerciseDate createRegRepExerciseDate(RegRepExerciseProvision dbProvision, ExerciseProvisionType.ExerciseDates ipDate, int id)
	{

		RegRepExerciseDate dbDate = null;
		RegRepExerciseDateId dbDateId = null;

		if (null == dbProvision || null == ipDate)
		{
			logger.debug("RegRepExerciseProvision object could not be " + "populated due to invalid incoming data");
			return dbDate;
		}

		dbDate = new RegRepExerciseDate();
		dbDate.setRegRepExerciseProvision(dbProvision);

		dbDateId = createExerciseDateId(dbDate, id);
		dbDate.setId(dbDateId);

		dbDate.setExerciseDate(CalendarUtils.toDate(ipDate.getExerciseDate()));
		dbDate.setExerciseFee(ipDate.getExerciseFee() + "");

		return dbDate;
	}

	private RegRepExerciseDateId createExerciseDateId(RegRepExerciseDate dbDate, int id)
	{

		RegRepExerciseDateId dateId = null;

		if (null == dbDate)
		{
			logger.debug("RegRepExerciseDateId object could not be " + "populated due to invalid incoming data");
			return dateId;
		}

		dateId = new RegRepExerciseDateId();

		dateId.setRegRepExerciseDateId(dbDate.getRegRepExerciseProvision().getRegRepExerciseProvisionId());
		dateId.setSequenceId(id);

		return dateId;
	}
}
