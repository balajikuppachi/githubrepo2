package com.wellsfargo.regulatory.persister.dto;

import java.util.Date;

public class RegRepPrCid implements java.io.Serializable {

	private static final long serialVersionUID = 2129564974662950508L;

	private int id;
	private Date asOfDate;
	private String fullName;
	private int legalId;

	public RegRepPrCid() {}

	public RegRepPrCid(int id, Date asOfDate, String fullName) {
		this.id = id;
		this.asOfDate = asOfDate;
		this.fullName = fullName;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getLegalId() {
	    return legalId;
	}

	public void setLegalId(int legalId) {
	    this.legalId = legalId;
	}
}
