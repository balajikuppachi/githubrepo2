package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;

import org.hibernate.Criteria;

/**
 * Interface for generic DAO operations.
 * 
 * @param <T>
 * the generic type
 */
public interface Dao<T>
{

	public T findByPrimaryKey(Serializable id);

	public T load(Serializable id);

	public List<T> loadAll();

	public T save(T t);

	public void saveOrUpdate(T t);

	public void saveOrUpdateAll(Collection<T> col);

	public void update(T t);

	public void delete(T t);

	public void deleteAll(Collection<T> col);

	public void merge(Collection<T> col);

	public T merge(T t);

	public T findSingle(Function<Criteria, Criteria> callback);

	public List<T> find(Function<Criteria, Criteria> callback);
	
	public int count(Function<Criteria, Criteria> callback);

	int countDistinct(String propertyName, Function<Criteria, Criteria> callback);
	
	public String columnName(String propertyName);
	
	public int bulkUpdate(String queryString, Object[] values);	
	
	List<Object[]> findMembers(Function<Criteria, Criteria> callback);

}
