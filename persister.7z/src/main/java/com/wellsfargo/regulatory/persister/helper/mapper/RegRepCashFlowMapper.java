package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepCashFlowSet;
import com.wellsfargo.regulatory.persister.dto.RegRepCashFlowSetId;
import com.wellsfargo.regulatory.persister.dto.RegRepLeg;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public class RegRepCashFlowMapper
{

	private static Logger logger = Logger.getLogger(RegRepCashFlowMapper.class.getName());

	public RegRepCashFlowSet createCashFlowSet(CashFlowType.CashFlow ipCashFlow, RegRepLeg ipLeg, int id)
	{

		RegRepCashFlowSet cashFlow = null;
		RegRepCashFlowSetId cashFlowSetId = null;

		if (null == ipLeg || null == ipCashFlow)
		{
			logger.debug("RegRepCashFlowSet object could not be " + "populated due to invalid incoming data");
			return cashFlow;
		}

		cashFlow = new RegRepCashFlowSet();
		cashFlow.setRegRepLeg(ipLeg);

		cashFlowSetId = createCashFlowSetId(cashFlow, id);

		cashFlow.setCashFlowAmount(ConversionUtils.bigDecimalToDouble(ipCashFlow.getCashflowAmount()));
		cashFlow.setCashFlowCurrency(ipCashFlow.getCashflowCurrency());
		cashFlow.setCashFlowRate(ConversionUtils.bigDecimalToDouble(ipCashFlow.getCashflowRate()));
		cashFlow.setCashFlowType(ipCashFlow.getCashflowType());
		cashFlow.setEndDate(CalendarUtils.toDate(ipCashFlow.getEndDate()));
		cashFlow.setId(cashFlowSetId);
		cashFlow.setPaymentDate(CalendarUtils.toDate(ipCashFlow.getPaymentDate()));
		cashFlow.setQuantityAmount(ConversionUtils.bigDecimalToDouble(ipCashFlow.getQuantityAmount()));
		cashFlow.setResetDate(CalendarUtils.toDate(ipCashFlow.getResetDate()));
		cashFlow.setStartDate(CalendarUtils.toDate(ipCashFlow.getStartDate()));

		return cashFlow;
	}

	private RegRepCashFlowSetId createCashFlowSetId(RegRepCashFlowSet ipCashFlow, int id)
	{

		RegRepCashFlowSetId cashFlowId = null;

		if (null == ipCashFlow)
		{
			logger.debug("RegRepCashFlowSetId object could not be " + "populated due to invalid incoming data");
			return cashFlowId;
		}

		cashFlowId = new RegRepCashFlowSetId();

		cashFlowId.setRegRepCashFlowSetId(id);
		cashFlowId.setRegRepLegId(ipCashFlow.getRegRepLeg().getId().getRegRepLegId());
		cashFlowId.setRegRepProductId(ipCashFlow.getRegRepLeg().getRegRepProduct().getRegRepProductId());

		return cashFlowId;
	}
}
