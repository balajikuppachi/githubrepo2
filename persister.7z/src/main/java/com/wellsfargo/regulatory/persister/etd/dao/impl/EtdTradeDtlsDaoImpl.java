package com.wellsfargo.regulatory.persister.etd.dao.impl;

import com.wellsfargo.regulatory.persister.dao.impl.AbstractDaoImpl;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeDtlsDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeDtls;

public class EtdTradeDtlsDaoImpl extends AbstractDaoImpl<EtdTradeDtls> implements EtdTradeDtlsDao
{
	/**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    
    @Override
	public Class<EtdTradeDtls> getEntityClass()
	{
		return EtdTradeDtls.class;
	}
    

}
