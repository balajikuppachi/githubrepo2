package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepPeriod;

public interface RegRepPeriodDao extends Dao<RegRepPeriod>, Serializable
{

}
