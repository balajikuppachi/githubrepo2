package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepClearingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepClearing;

public class RegRepClearingDaoImpl extends AbstractDaoImpl<RegRepClearing> implements RegRepClearingDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5768487216297788952L;

	@Override
	public Class<RegRepClearing> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepClearing.class;
	}



}
