package com.wellsfargo.regulatory.persister.dto;

import java.util.Date;

public class RegRepDupCheckMapping implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private RegRepDupCheckMappingId id;
	private String pathDesc;
	private Date createDatetime;
	
	public RegRepDupCheckMapping(RegRepDupCheckMappingId id, String pathDesc,
			Date createDatetime) {
		super();
		this.id = id;
		this.pathDesc = pathDesc;
		this.createDatetime = createDatetime;
	}
	
	public RegRepDupCheckMapping() {
		super();		
	}
		

	public RegRepDupCheckMappingId getId() {
		return id;
	}

	public void setId(RegRepDupCheckMappingId id) {
		this.id = id;
	}

	public String getPathDesc() {
		return pathDesc;
	}

	public void setPathDesc(String pathDesc) {
		this.pathDesc = pathDesc;
	}

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	@Override
	public String toString() {
		return "RegRepDupCheckMapping [id=" + id + ", pathDesc=" + pathDesc
				+ ", createDatetime=" + createDatetime + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createDatetime == null) ? 0 : createDatetime.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((pathDesc == null) ? 0 : pathDesc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegRepDupCheckMapping other = (RegRepDupCheckMapping) obj;
		if (createDatetime == null) {
			if (other.createDatetime != null)
				return false;
		} else if (!createDatetime.equals(other.createDatetime))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (pathDesc == null) {
			if (other.pathDesc != null)
				return false;
		} else if (!pathDesc.equals(other.pathDesc))
			return false;
		return true;
	}
	
	
	
	

}
