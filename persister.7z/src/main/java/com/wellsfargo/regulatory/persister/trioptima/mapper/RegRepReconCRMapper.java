package com.wellsfargo.regulatory.persister.trioptima.mapper;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.InstrumentIdType.InstrumentId;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

public class RegRepReconCRMapper {
	
	private static Logger logger = Logger.getLogger(RegRepReconCRMapper.class
			.getName());
	
	public RegRepTrioptima mapCRrows(ReportingContext context,TradeDetailType tradeDetail, ProductType product,RegRepTrioptima regRepTrioptima,
			BigDecimal parentOriginalNotional, String marketType)
	{

	
	String buyer 					= null;
	String weBuySell 				= null;
	List<InstrumentId> instrument 	= null;
	String cptyPartId 				= null;
	String rpPartyId 				= null;
	String cptyPartyName 			= null;
	BigDecimal fixedRate1 			= null;
	String freqPeriosMul 	  		= null;
	String paymentFreq 				= null;
	String isoCurrency 				= null;
	StringBuilder freqMulStrB 		= new StringBuilder();
	String currency					= null;
	BigDecimal notional 			= null;
	PayReceiveEnum	payReceiveEnum  = null;
	
	if(!tradeDetail.getTradeParties().getParty().isEmpty())
	{	
		cptyPartId 			= tradeDetail.getTradeParties().getParty().get(0).getDtccParticipantId();
		rpPartyId 			= tradeDetail.getTradeParties().getParty().get(1).getDtccParticipantId();
		cptyPartyName 		= tradeDetail.getTradeParties().getParty().get(0).getPartyName();
	}
	
	if(!product.getLeg().isEmpty())
	{	
		notional 		= product.getLeg().get(0).getNotional();
		payReceiveEnum 	= product.getLeg().get(0).getPayReceive();
		fixedRate1 		= product.getLeg().get(0).getFixedRate();
		isoCurrency 	= StringUtils.join(new String[] { Constants.ISO_CURRENCY_EXCEPTION,product.getLeg().get(0).getNotionalCurrency() },Constants.UNDERSCORE);
	}
	
	if(!GeneralUtils.IsNull(payReceiveEnum))
	{
		if(payReceiveEnum.compareTo(PayReceiveEnum.PAY) == 0) 
		{	
			weBuySell = Constants.Buy;
		}
		else
		{
			weBuySell = Constants.Sell;
		}
	}
	
	if (!Constants.Sell.equalsIgnoreCase(weBuySell)) 
	{
			buyer = Constants.LEI_PREFIX + ":"+ rpPartyId.substring(4);
	}
	else
	{
		if (Constants.NONE.equalsIgnoreCase(cptyPartId) || (GeneralUtils.IsNull(cptyPartId)))
			buyer = Constants.INTERNAL + ":" + cptyPartyName;
		else
			buyer = Constants.LEI_PREFIX + ":"+ cptyPartId.substring(4);
	}
	
	instrument 		= product.getCdsTerms().getReferenceInformation().getReferenceObligation().getInstrumentIds().getInstrumentId();
	freqPeriosMul 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.PAYMENT_FREQ_MULTIPLIER + "1");
	paymentFreq 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.PAYMENT_FREQ_PERIOD + "1");
	currency 		= getDomain(isoCurrency);
	
	if (!GeneralUtils.IsNullOrBlank(freqPeriosMul))
	{
		freqMulStrB = freqMulStrB.append(freqPeriosMul);
		
	} 
	if (!GeneralUtils.IsNullOrBlank(paymentFreq))
	{
		freqMulStrB = freqMulStrB.append(":").append(paymentFreq);
	}
		{
			regRepTrioptima.setBuyer(buyer);
			if(!product.getLeg().isEmpty())
			{
				regRepTrioptima.setEffectiveDate(CalendarUtils.xmlGregCalToCustomFormat(product.getLeg().get(0).getStartDate(), null));
				regRepTrioptima.setSchedTerminationDate(CalendarUtils.xmlGregCalToCustomFormat(product.getLeg().get(0).getEndDate(), null));
			}
			
			if (!GeneralUtils.IsNull(fixedRate1)) 
			{
				regRepTrioptima.setFixedRateLeg1(fixedRate1);
			}
		
			for(int i=0; i<instrument.size(); i++)
			{
				String value =  instrument.get(i).getValue();
				if(!GeneralUtils.IsNullOrBlank(value) && !Constants.NOT_FOUND.equalsIgnoreCase(value)) 
				{
					regRepTrioptima.setUnderlyingAsset(value);
					break;
				} 
			}
			if(GeneralUtils.IsNull(regRepTrioptima.getUnderlyingAsset()))
			{
				regRepTrioptima.setUnderlyingAsset(product.getCdsTerms().getIndexInformation().getIndexName());
			}

			if (!GeneralUtils.IsNull(parentOriginalNotional)	&& Constants.Partial_Term_Voluntary.equals(marketType)) 
			{
				regRepTrioptima.setNotionalAmountLeg1(getTerminatedNotional(notional, parentOriginalNotional));
			} 
			else 
			{
				regRepTrioptima.setNotionalAmountLeg1(notional);
			}
			
			if(GeneralUtils.IsNull(currency))
			{
				regRepTrioptima.setNotionalCurrencyLeg1(currency);
			}
			else if(!product.getLeg().isEmpty())
			{
				regRepTrioptima.setNotionalCurrencyLeg1(product.getLeg().get(0).getNotionalCurrency());
			}
			
			if (!GeneralUtils.IsNull(freqMulStrB))
			{
				regRepTrioptima.setPaymentFreqMultiplierLeg1(freqMulStrB.toString());
			} 
		}
		return regRepTrioptima;
}
	
	private BigDecimal getTerminatedNotional(BigDecimal current, BigDecimal parentNotional) {
		BigDecimal remaining = null;
		MathContext mc = new MathContext(2);

		if (!GeneralUtils.IsNull(current) && !GeneralUtils.IsNull(parentNotional))
			try {
				remaining = parentNotional.subtract(current, mc);
			} catch (Exception ee) {
				logger.debug("Remaining Notional Failed, Returning the value as is.", ee);
			}
		return remaining;
	}

	public String getDomain(String domain) {
		String domainRet = null;
		DomainMappingCache cache = DomainMappingCache.getInstance();
		domainRet = cache.getValue(domain);
		if (!GeneralUtils.IsNull(domainRet)) 
		{
			return domainRet;
		} 
		else
			return null;
	}
}
