package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;
import com.wellsfargo.regulatory.persister.dao.RegRepDsMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepDomainValues;

public class RegRepDsMappingDaoImpl extends AbstractDaoImpl<RegRepDomainValues> implements RegRepDsMappingDao{
	
	private static final long serialVersionUID = 1L;
	
	public static final String GET_ALL_DS_MAPPING = "SELECT * FROM REG_REP_DATA_SERVICES_MAPPING";

	private static Logger logger = Logger.getLogger(RegRepDsMappingDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public RegRepDsMappingDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<RegRepDomainMapping> findAll()
	{
		logger.debug("Entering findAll() method");

		RegRepDomainMapping config = null;

		String query = GET_ALL_DS_MAPPING;

		List<RegRepDomainMapping> configs = new ArrayList<RegRepDomainMapping>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

		for (Map<String, Object> row : rows)
		{
			config = new RegRepDomainMapping();

			config.setDomainName((String) row.get("DOMAIN_NAME"));
			config.setSrcCode((String) row.get("SRC_CODE"));
			config.setDtccCode((String) (row.get("DTCC_CODE")));

			configs.add(config);
		}

		logger.debug("Leaving findAll() method");

		return configs;
	}

	@Override
	public Class<RegRepDomainValues> getEntityClass() {
		// TODO Auto-generated method stub
		return null;
	}
}
