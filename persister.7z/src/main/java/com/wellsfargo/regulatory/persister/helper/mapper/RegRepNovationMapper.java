package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.NovationType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepLifecycle;
import com.wellsfargo.regulatory.persister.dto.RegRepNovation;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepNovationMapper
{
	private static Logger logger = Logger.getLogger(RegRepNovationMapper.class.getName());

	public RegRepNovation createRegRepNovation(RegRepLifecycle dbLifecycle, NovationType ipNovation)
	{

		RegRepNovation dbnovation = null;

		if (null == dbLifecycle || null == ipNovation)
		{
			logger.debug("RegRepNovation object could not be " + "populated due to invalid incoming data");
			return dbnovation;
		}

		dbnovation = new RegRepNovation();
		dbnovation.setRegRepLifecycle(dbLifecycle);

		// dbnovation.setEffectiveDate(CalendarUtils.toDate(ipNovation.getEffectiveDate()));
		dbnovation.setNovatedAmount(ConversionUtils.bigDecimalToDouble(ipNovation.getNovatedAmount()));
		dbnovation.setNovationDate(CalendarUtils.toDate(ipNovation.getNovationDate()));

		/*
		 * @Comment : Amit Rana Need not be set, else hibernate creates a duplicate object
		 * dbnovation.setRegRepMessageId(dbLifecycle.getRegRepMessageId());
		 */

		dbnovation.setRemainingAmount(ConversionUtils.bigDecimalToDouble(ipNovation.getRemainingAmount()));
		dbnovation.setRole(ipNovation.getRole());
		dbnovation.setTransferorLei(ipNovation.getTransferorLEI());
		dbnovation.setTransfereeLei(ipNovation.getTransfereeLEI());
		dbnovation.setRemainingPartyLei(ipNovation.getRemainingPartyLEI());

		/*** Start LEI Changes ***/ 
		
		dbnovation.setTransferorLEIPrefix(StringUtils.trimToEmpty(ipNovation.getTransferorLEIPrefix()));
		dbnovation.setTransferorLEIValue(StringUtils.trimToEmpty(ipNovation.getTransferorLEIValue()));

		dbnovation.setTransfereeLEIPrefix(StringUtils.trimToEmpty(ipNovation.getTransfereeLEIPrefix()));
		dbnovation.setTransfereeLEIValue(StringUtils.trimToEmpty(ipNovation.getTransfereeLEIValue()));

		dbnovation.setRemainingPartyLEIPrefix(StringUtils.trimToEmpty(ipNovation.getRemainingPartyLEIPrefix()));
		dbnovation.setRemainingPartyLEIValue(StringUtils.trimToEmpty(ipNovation.getRemainingPartyLEIValue()));

		/*** End LEI Changes ***/

		
		
		return dbnovation;
	}

}
