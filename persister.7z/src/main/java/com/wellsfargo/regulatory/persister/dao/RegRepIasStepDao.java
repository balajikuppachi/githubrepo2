package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepIasStep;

public interface RegRepIasStepDao extends Dao<RegRepIasStep>, Serializable
{

}
