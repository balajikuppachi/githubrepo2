package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

import org.hibernate.Criteria;

import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

public interface RegRepMessageDao extends Serializable, Dao<RegRepMessage>
{

	/**
	 * Used to get REG_REP_MESSAGE records based on TRADE_USI_PREFIX and TRADE_USI_VALUE
	 * 
	 * @param usiPrefix
	 * @param usiValue
	 * @return
	 */
	public List<RegRepMessage> loadRegRepMsgsByUSI(String usi);

	/**
	 * Used to get REG_REP_MESSAGE records based on SWAP_TRADE_ID
	 * 
	 * @param swapTradeId
	 * @return
	 */
	public List<RegRepMessage> loadRegRepMsgsBySwapTradeId(String swapTradeId);

	/**
	 * Used to get REG_REP_MESSAGE records based on COUNTERPARTY_LEI
	 * 
	 * @param counterPartyLEI
	 * @return
	 */
	public List<RegRepMessage> loadRegRepMsgsByCounterPartyLEI(String counterPartyLEI);
		
	public RegRepMessage findByPrimaryKeyNS(String msgId);
	
	public Set<RegRepMessage> loadRegRepMessagesForSrcMsgId(String msgId);
	
	public RegRepMessage findByTradeIdAndReportTypeNS(String tradeId, String reportType,  String jurisdiction);
	
	public RegRepMessage findMsgAndTradeByPrimaryKeyNS(String msgId);	
	
	List<RegRepMessage> findMsgAndTradeBetweenATime(Date startTime, Date endTime);	

	public Function<Criteria, Criteria> filter(Date start, Date end, List<String> assetClasses, List<String> jurisdictions, boolean orderByTimestamp);
	
	void restrict(Criteria criteria, Date start, Date end);
	
	void restrict(Criteria criteria, List<String> jurisdictions, List<String> assetClasses);
	
	public List<RegRepMessage> findByTradeIdAndJurisdictionNS(String tradeId,String jurisdiction);
	
	public List<RegRepMessage> loadRegRepMsgsByExtrnlMsgId(String externalMsgId);
}