package com.wellsfargo.regulatory.persister.recon.dao;

import java.io.Serializable;
import java.util.Date;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportStatus;


/**
 * 
 * @author Raji Komatreddy
 *
 */
public interface RegRepReconReportStatusDao extends Serializable, Dao<RegRepReconReportStatus>
{
	public RegRepReconReportStatus getReconReportStatusByReportDate(Date reportDate, String sourceSystem);

}
