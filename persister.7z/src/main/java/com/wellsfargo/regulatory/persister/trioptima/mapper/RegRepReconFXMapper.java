package com.wellsfargo.regulatory.persister.trioptima.mapper;

import java.util.List;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.OptionTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;

public class RegRepReconFXMapper {
	
	public RegRepTrioptima mapFXrows(ReportingContext context,ProductType product,RegRepTrioptima regRepTrioptima,
			TradeHeaderType tradeHeader)
	{

		String optionStyle = null;
		
		List<LegType> legs = product.getLeg();
		{
			if(!GeneralUtils.IsNull(product.getExerciseProvision()))
			{
				optionStyle = product.getExerciseProvision().getExerciseType().value();
				regRepTrioptima.setExpirationDate(CalendarUtils.xmlGregCalToCustomFormat(product.getExerciseProvision().getExpirationDate(), null));
			}
			
			regRepTrioptima.setEffectiveDate(CalendarUtils.xmlGregCalToCustomFormat(tradeHeader.getTradeDate(), null));
			regRepTrioptima.setFxDeliveryType("");
			
			if (!GeneralUtils.IsNull(optionStyle))
			{
				regRepTrioptima.setOptionStyle(optionStyle);
			}
			
			if (!GeneralUtils.IsNull(legs) && !legs.isEmpty()) 
			{
				for (LegType leg : legs) 
				{
					if (!GeneralUtils.IsNull(leg.getOptionType())) 
					{
						if (leg.getOptionType().compareTo(OptionTypeEnum.CALL) == 0) 
						{
							regRepTrioptima.setNotionalAmountLeg1(leg.getNotional());
							regRepTrioptima.setNotionalCurrencyLeg1(leg.getNotionalCurrency());
						}
						if (leg.getOptionType().compareTo(OptionTypeEnum.PUT) == 0) 
						{
							regRepTrioptima.setNotionalAmountLeg2(leg.getNotional());
							regRepTrioptima.setNotionalCurrencyLeg2(leg.getNotionalCurrency());
						}
					}
				}
			}
		}
	
		return regRepTrioptima;
	}

}
