package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepClearing;
import com.wellsfargo.regulatory.persister.dto.RegRepLifecycle;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepClearingMapper
{
	private static Logger logger = Logger.getLogger(RegRepClearingMapper.class.getName());

	public RegRepClearing createRegRepClearing(ClearingType ipClearing, RegRepLifecycle dbLifecycle)
	{

		RegRepClearing dbClearing = null;

		if (null == ipClearing || null == dbLifecycle)
		{
			logger.debug("RegRepClearing object could not be " + "populated due to invalid incoming data");
			return dbClearing;
		}

		dbClearing = new RegRepClearing();
		dbClearing.setRegRepLifecycle(dbLifecycle);

		dbClearing.setBilateralTrade(ipClearing.getBilateralTradeId());
		dbClearing.setClearedDateTime(CalendarUtils.toDate(ipClearing.getClearedDateTime()));
		dbClearing.setClearedTrade(ConversionUtils.booleanToDbString(ipClearing.isClearedTrade()));
		dbClearing.setClearingHouseLei(ipClearing.getClearingHouseLEI());
		dbClearing.setClearingTradeId(ipClearing.getClearingTradeId());
		// dbClearing.setEcnSource(ipClearing.getEcnSource());

		/*
		 * @Comment : Amit Rana Need not be set, else hibernate creates a duplicate object
		 * dbClearing.setRegRepMessageId(dbClearing.getRegRepLifecycle().getRegRepMessageId());
		 */

		/*** Start LEI Changes ***/ 
		dbClearing.setClearingHouseLEIPrefix(StringUtils.trimToEmpty(ipClearing.getClearingHouseLEIPrefix()));
		dbClearing.setClearingHouseLEIValue(StringUtils.trimToEmpty(ipClearing.getClearingHouseLEIValue()));
		/*** End LEI Changes ***/

		
		return dbClearing;
	}

}
