package com.wellsfargo.regulatory.persister.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * @author 	Amit Rana
 * @date 	08/23/2015
 * @version 1.0
 */

public class RegRepEodCustomRefreshMapper implements RowMapper<RegRepEodRefreshMessage> {
	
	@Override
	public RegRepEodRefreshMessage mapRow(ResultSet rs, int rowNum) throws SQLException {

		RegRepEodRefreshMessage refreshMessage = new RegRepEodRefreshMessage();
				
		
		refreshMessage.setMessageId(rs.getString("REG_REP_MESSAGE_ID"));
		refreshMessage.setEodReportId(rs.getString("EOD_REPORT_ID"));
		refreshMessage.setPayload(rs.getString("PAYLOAD"));
		refreshMessage.setReportType(rs.getString("REPORT_TYPE"));
		refreshMessage.setJurisdiction(rs.getString("JURISDICTION"));
		
		return refreshMessage;
	}
}
