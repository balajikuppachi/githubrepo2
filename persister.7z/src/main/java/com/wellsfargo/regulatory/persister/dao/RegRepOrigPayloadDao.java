package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepOrigPayload;

public interface RegRepOrigPayloadDao extends Dao<RegRepOrigPayload>, Serializable{

}
