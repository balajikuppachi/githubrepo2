package com.wellsfargo.regulatory.persister.dao.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageRegulatoryDao;
import com.wellsfargo.regulatory.persister.dao.RegRepReportDao;
import com.wellsfargo.regulatory.persister.dao.RegRepResponseDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepMessageRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepReport;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;

@Component
public class DataService {
	
	@Autowired
	private RegRepMessageDao 			regRepMessageDao;
	@Autowired
	private RegRepReportDao 			regRepReportDao;
	@Autowired
	private RegRepResponseDao 			regRepRespDao;
	@Autowired
	private RegRepMessageRegulatoryDao 	regRepRegpDao;
		
	/**
	 * 
	 * Returns Message based between a start time and end time.
	 * These messages have their respective Reports/Responses populated
	 */
	public Map<String, RegRepMessage> getMessagesByTime(Date startTime, Date endTime,
			boolean withExceptions){
		
//		public void getMessagesByTime(Message<?> message){
		
		List<RegRepMessage> 			messages 	= null;
		List<RegRepReport> 				reports 	= null;
		List<RegRepResponse> 			responses 	= null;
		List<RegRepMessageRegulatory> 	regulatories= null;
		
		RegRepMessage rrMsg = null;
		
		String type = null;
		Map<String, RegRepMessage> 	msgMap = null;
		Map<String, RegRepReport> 	rptMap = null;
		Map<String, RegRepResponse> rspMap = null;
		List<String> reportIdList	= new ArrayList<String>(100);
		List<String> rspIdList		= new ArrayList<String>(100);
		List<String> regIdList		= new ArrayList<String>(100);
				
		Set<RegRepMessageRegulatory> set = null;
		
		/*
			Date startTime = new Date();		
			startTime = DateUtils.addDays(startTime, -100);
			Date endTime = DateUtils.addDays(startTime, 500);
		*/
			
		try{
				
			messages = regRepMessageDao.findMsgAndTradeBetweenATime(startTime, endTime);
			
			if(null == messages || messages.size() < 1){
							
				return msgMap;
			}else{
				
				msgMap = new HashMap<String, RegRepMessage>(messages.size());
			}
						
			for(RegRepMessage msg : messages){				
				
				type = msg.getMessageType();
				
				if(null == type)
					continue;
				
				if("SDR_TRADE".equalsIgnoreCase(type)){
					
					regIdList.add(msg.getRegRepMessageId());
				}else if("SDR_REPORT".equalsIgnoreCase(type)){
					
					reportIdList.add(msg.getRegRepMessageId());
					regIdList.add(msg.getRegRepMessageId());
				}else if("SDR_RESPONSE".equalsIgnoreCase(type)){
					
					rspIdList.add(msg.getRegRepMessageId());
				}else{
										
					continue;
				}
				
				msgMap.put(msg.getRegRepMessageId(), msg);
			}
	
			reports 	= regRepReportDao.loadRegRepRptsByReportId(reportIdList);
			responses	= regRepRespDao.loadRegRepRptsByRespId(rspIdList);
			
			for(int i=0;i<regIdList.size();){
				
				int j = i+100;
				
				if(j > regIdList.size())
					j = regIdList.size(); 
				
				
				if(null == regulatories)
					regulatories= regRepRegpDao.loadRegulatoryByMsgId(regIdList.subList(i, j));					
				else				
					regulatories.addAll(regRepRegpDao.loadRegulatoryByMsgId(regIdList.subList(i, j)));
				
				i = j;
				
			}
			
//			regulatories= regRepRegpDao.loadRegulatoryByMsgId(regIdList);
					
			if(null != reports && reports.size() > 0){
				
				rptMap = new WeakHashMap<String, RegRepReport>(reports.size());
				
				for(RegRepReport rpt : reports){
					
					if(null == rpt)
						continue;
					
					rrMsg = msgMap.get(rpt.getRegRepReportId());			
					rrMsg.setRegRepReport(rpt);
					
					rptMap.put(rpt.getRegRepReportId(), rpt);
				}
				
			}
			
			
			if(null != responses && responses.size() > 0){
				
				rspMap = new WeakHashMap<String, RegRepResponse>(responses.size());
								
				for(RegRepResponse rsp : responses){
					
					if(null == rsp)
						continue;
					
					rrMsg = msgMap.get(rsp.getRegRepSdrResponseId());			
					rrMsg.setRegRepResponse(rsp);
										
					rspMap.put(rsp.getRegRepSdrResponseId(), rsp);
				}
			}
			
			
			if(null != regulatories && regulatories.size() > 0){
												
				for(RegRepMessageRegulatory reg : regulatories){
					
					if(null == reg)
						continue;
					
					rrMsg = msgMap.get(reg.getId().getRegRepMessageId());
					
					set = rrMsg.getRegRepMessageRegulatories();
					
					if(null == set)
						set = new HashSet<RegRepMessageRegulatory>(5);
					
					set.add(reg);
					
					rrMsg.setRegRepMessageRegulatories(set);
				}
			}
			
			
			
		}finally{
			
			if(null != rspMap){
				rspMap.clear();
				rspMap = null;
			}
			
			if(null != rptMap){
				rptMap.clear();
				rptMap = null;
			}
			
			if(null != messages){
				messages.clear();
				messages = null;
			}
			
			if(null != reports){
				reports.clear();
				reports = null;
			}
			
			if(null != responses){
				responses.clear();
				responses = null;
			}
			
			if(null != reportIdList){
				reportIdList.clear();
				reportIdList = null;
			}
			
			if(null != rspIdList){
				rspIdList.clear();
				rspIdList = null;			
			}			
			
		}
		
		return msgMap;
	}

}
