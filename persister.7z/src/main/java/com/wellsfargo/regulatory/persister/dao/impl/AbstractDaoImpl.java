package com.wellsfargo.regulatory.persister.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.persister.entity.AbstractEntityPersister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.Dao;

public abstract class AbstractDaoImpl<T> extends HibernateDaoSupport implements Dao<T>, java.io.Serializable
{
	private static final long serialVersionUID = -7326908098645707824L;

	public abstract Class<T> getEntityClass();


	@Autowired
    @Qualifier("strSessionFactory")
    SessionFactory sessionFactory;
	
    @Autowired
    public void init(SessionFactory factory) 
    {
        setSessionFactory(factory);
    }

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	public T load(Serializable id)
	{
		return (T) getHibernateTemplate().load(getEntityClass(), id);
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	public List<T> loadAll()
	{
		return getHibernateTemplate().loadAll(getEntityClass());
	}

	@Transactional(readOnly = false)
	public T save(T t)
	{
		getHibernateTemplate().save(t);
		return t;
	}

	@Transactional(readOnly = false)
	public void saveOrUpdate(T t)
	{
		//getHibernateTemplate().setCheckWriteOperations(false);
		getHibernateTemplate().saveOrUpdate(t);
	}

	@Transactional(readOnly = false)
	public T merge(T t)
	{
		getHibernateTemplate().merge(t);
		return t;
	}

	
	// this method is deprecated from HibernateTemple4, hence using 
	//simple save method in a for loop
	@Transactional(readOnly = false)
	public void saveOrUpdateAll(Collection<T> col)
	{
		for(java.util.Iterator<T> it = col.iterator(); it.hasNext();)
		{
			getHibernateTemplate().saveOrUpdate(it.next());
		}
		//getHibernateTemplate().saveOrUpdateAll(col);
	}


	@Transactional(readOnly = false)
	public void merge(Collection<T> col)
	{
		getHibernateTemplate().merge(col);
	}

	@Transactional(readOnly = false)
	public void update(T t)
	{
		getHibernateTemplate().update(t);
	}

	@Transactional(readOnly = false)
	public void delete(T t)
	{
		getHibernateTemplate().delete(t);
	}

	@Transactional(readOnly = false)
	public void deleteAll(Collection<T> col)
	{
		getHibernateTemplate().deleteAll(col);
	}

	/**
	 * Returns a list of entities based on a dynamic criteria object. Implementations will specify
	 * how the criteria is built via the buildHibernateCriteria() method.
	 *
	 * @see buildHibernateCriteria(Object criteria)
	 */
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	protected List<T> findByCriteria(Object criteria)
	{
		return (List<T>) getHibernateTemplate().findByCriteria(buildHibernateCriteria(criteria));
	}

	/**
	 * Default implementation returns null. Override to build actual criteria
	 *
	 * @param criteria
	 * @return
	 */
	protected DetachedCriteria buildHibernateCriteria(Object criteria)
	{
		return null;
	}

	// -------------------------------------------------------------------------
	// Convenience finder methods
	// -------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	public T findByPrimaryKey(Serializable id)
	{
		return (T) getHibernateTemplate().get(getEntityClass(), id);
	}

	/**
	 * To return list of non single Entity/Domain type results. Searches the database using the
	 * named query and values. Returns a list of Objects.
	 *
	 * @param returnType
	 * expected data type of the objects to be returned
	 * @param queryName
	 * query name
	 * @param values
	 * parameter values to be bound to the named query
	 * @return list of objects
	 */
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	protected List findByNamedQuery(String queryName)
	{
		return getHibernateTemplate().findByNamedQuery(queryName);
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	protected List findByNamedQuery(String queryName, Object value)
	{
		return getHibernateTemplate().findByNamedQuery(queryName, value);
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	protected List findByNamedQuery(String queryName, Object[] values)
	{
		return getHibernateTemplate().findByNamedQuery(queryName, values);
	}

	@Transactional(readOnly = false)
	public int bulkUpdate(String queryName, Object value)
	{
		return getHibernateTemplate().bulkUpdate(queryName, value);
	}

	@Transactional(readOnly = false)
	public int bulkUpdate(String queryString, Object[] values)
	{
		return getHibernateTemplate().bulkUpdate(queryString, values);

	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	protected SQLQuery findByNamedNativeQuery(String queryName)
	{
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		return session.createSQLQuery(queryName);
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	protected Session openSession()
	{
		return getHibernateTemplate().getSessionFactory().openSession();
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	public T findSingle(Function<Criteria, Criteria> callback)
	{
		Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
		Criteria criteria = session.createCriteria(getEntityClass());
		callback.apply(criteria);
		return (T) criteria.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	public List<T> find(Function<Criteria, Criteria> callback)
	{
		Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
		Criteria criteria = session.createCriteria(getEntityClass());
		callback.apply(criteria);
		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly = false)
	public List<Object[]> findMembers(Function<Criteria, Criteria> callback)
	{
		Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
		Criteria criteria = session.createCriteria(getEntityClass());
		callback.apply(criteria);
		
		return criteria.list();
	}
	
	@Transactional(readOnly = false)
	public int count(Function<Criteria, Criteria> callback)
	{
		Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
		Criteria criteria = session.createCriteria(getEntityClass());
		callback.apply(criteria);
		return (int)criteria.setProjection(Projections.rowCount()).uniqueResult();
	}

	@Transactional(readOnly = false)
	public int countDistinct(String propertyName, Function<Criteria, Criteria> callback)
	{
		Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
		Criteria criteria = session.createCriteria(getEntityClass());
		/*criteria = */ callback.apply(criteria);
		return (int)criteria.setProjection(Projections.countDistinct(propertyName)).uniqueResult();
	}

	public String columnName(String propertyName)
	{
		AbstractEntityPersister meta = ((AbstractEntityPersister) getSessionFactory().getClassMetadata(getEntityClass()));
		return meta.getPropertyColumnNames(propertyName)[0];
	}

	// execute stored procedure using execute method of HibernateTemplate class

	/*@SuppressWarnings("rawtypes")
    public List getNextSequenceIdUsingStoredProc(String queryName, int sequenceCode)
	{
		//Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Query query = session.getNamedQuery(queryName).setParameter("sequenceCode", sequenceCode);
		      query.setResultTransformer(Transformers.aliasToBean(RegRepSequenceId.class)); 
		List resultList = query.list();
		return resultList;

	}*/
	
	@SuppressWarnings("unchecked")
	protected List find(String query)
	{
		return getHibernateTemplate().find(query);
	}
}