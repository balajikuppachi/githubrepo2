package com.wellsfargo.regulatory.persister.helper.mapper;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.MeasureType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ValuationItemType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ValuationType;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.etd.dto.EtdValuationDtls;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;

public class EtdValuationDtlsMapper
{
	private static Logger logger = Logger.getLogger(EtdValuationDtlsMapper.class.getName());

	public EtdValuationDtls populateEtdValuationDtls(ReportingContext context, EtdPayload etdPayload) throws EtdMessageException
	{
		logger.info("inside EtdValuationDtlsMapper populateEtdValuationDtls method");
		Date current_date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(EtdConstants.ETD_COBDATE_FORMAT);
		String cobDate = dateFormat.format(current_date);

		SdrRequest sdrRequest = null;
		ValuationType valuation = null;
		ValuationItemType valuationItem = null;
		MeasureType measure = null;
		String srcSysMessageId = null;

		EtdValuationDtls currEtdValuationDtls = new EtdValuationDtls();

		sdrRequest = context.getSdrRequest();

		currEtdValuationDtls.setCobDate(cobDate);
		currEtdValuationDtls.setCreateDatetime(current_date);
		currEtdValuationDtls.setEtdPayload(etdPayload);

		if (null != sdrRequest)
		{
			srcSysMessageId = sdrRequest.getMessageId();
			currEtdValuationDtls.setSrcSysMessageId(srcSysMessageId);

			valuation = sdrRequest.getValuation();
			if (null != valuation)
			{
								
				valuationItem = valuation.getValuationItem().get(0);
				if (null != valuationItem)
				{
					currEtdValuationDtls.setTradeId(valuationItem.getTradeId());
				
					measure = valuationItem.getMeasure().get(0);
					if(null != measure)
					{
						currEtdValuationDtls.setMeasureType(measure.getMeasureType());
						currEtdValuationDtls.setMeasureValue(Double.toString(measure.getValue()));
						currEtdValuationDtls.setCurrency(measure.getCurrency());
						currEtdValuationDtls.setValuationDate( measure.getValuationDate().toString());
						
					}

				}

			}

		}
		
		logger.info("exiting EtdValuationDtlsMapper populateEtdValuationDtls method");

		return currEtdValuationDtls;

	}

}
