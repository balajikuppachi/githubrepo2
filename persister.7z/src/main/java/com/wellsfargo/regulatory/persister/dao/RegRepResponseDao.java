package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepResponse;

public interface RegRepResponseDao extends Dao<RegRepResponse>, Serializable
{

	List<RegRepResponse> loadRegRepRptsByRespId(List<String> reportIds);
	public String getLastSubmissionStatus(String regRepMsgID);

}
