package com.wellsfargo.regulatory.persister.util.dataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;

public class ConnectionManager 
{
	private static Logger logger = Logger.getLogger(ConnectionManager.class.getName());
	
	/*** 
	 * BasicDataSource is everything for basic needs. It creates internally a PoolableDataSource and an ObjectPool.
	 * BasicDataSource is thread-safe, but you should take care to use appropriate accessors rather than accessing protected fields directly to ensure thread-safety.
	 ***/
	private static BasicDataSource connectionPool;
	
	public static void setDataSource(BasicDataSource dataSource) 
	{
		ConnectionManager.connectionPool = dataSource;
	}

	//private static HikariDataSource connectionPool;
	//public static void setDataSource(HikariDataSource dataSource) 
	//{
	//	ConnectionManager.connectionPool = dataSource;
	//}

	private JdbcTemplate m_jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() 
	{
		return m_jdbcTemplate;
	}
		
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) 
	{
		m_jdbcTemplate = jdbcTemplate;
	}
	
	public Connection getConnection()
	{
		logger.debug("Getting a new connection from the pool");
		
		Connection 	connection	= null;	
		
		try
		{
			//connection 	= connectionPool.getConnection();
			
			connection = DataSourceUtils.getConnection(getJdbcTemplate().getDataSource());
			
			logger.debug(null != connection ? "Sucessfully obtained a new connection" : "Failed to get a connection");
			
			if(null != connection)
			{
				connection.setAutoCommit(false);
				logger.debug("Turned off the auto commit property for the connection");
			}
		}
		catch(Exception e)
		{
			logger.error("######### Failed to get the connection ",e);
			return connection;
		}
		
		logger.debug(null != connection ? "Returning a new connection from the pool" : "");
		return connection;
	}

	public void closeConnection(Connection connection)
	{
		logger.debug("Closing the connection ");
		
		if(null == connection)
			return;
		
		try
		{
			connection.setAutoCommit(true);
			logger.debug("Turned on the auto commit property for the connection");
			
			DataSourceUtils.releaseConnection(connection, getJdbcTemplate().getDataSource());
			
			logger.debug("Closed the connection successfully");
		}
		catch(Exception e)
		{
			logger.error("######### Failed to get the connection ",e);
			return;
		}
		
		logger.debug("Connection closed");
		return;
	}

	public void closeStatement(Statement statement)
	{
		logger.debug("Closing the Statement ");
		
		try
		{
			JdbcUtils.closeStatement(statement);
				
			logger.debug("Closed the Statement successfully");
		}
		catch(Exception e)
		{
			logger.error("######### Failed to get the Statement ",e);
			return;
		}
		
		logger.debug("Statement closed");
		return;
	}

	public void closeResultSet(ResultSet resultSet)
	{
		logger.debug("Closing the ResultSet ");
		
		try
		{
			JdbcUtils.closeResultSet(resultSet);
			logger.debug("Closed the ResultSet successfully");
		}
		catch(Exception e)
		{
			logger.error("######### Failed to get the ResultSet ",e);
			return;
		}
		
		logger.debug("ResultSet closed");
		return;
	}

	public void rollbackTransaction(Connection connection)
	{
		logger.debug("Rolling back the transaction");
		
		if(null == connection)
			return;
		
		try 
		{
			connection.rollback();
			logger.debug("Succesfully rolled back the transaction.");			
		} 
		catch (SQLException e) 
		{
			logger.error("######### Failed to roll back the transaction.");	
		}
		
		logger.debug("Transaction rolled back");		
	}

	public void commitTransaction(Connection connection)
	{
		logger.debug("Commiting the transaction");
		
		if(null == connection)
			return;
		
		try 
		{
			connection.commit();
			logger.debug("Succesfully commited the transaction.");			
		} 
		catch (SQLException e) 
		{
			logger.error("######### Failed to commit the transaction.");	
		}
		
		logger.debug("Transaction commited");		
	}

	
	
}
