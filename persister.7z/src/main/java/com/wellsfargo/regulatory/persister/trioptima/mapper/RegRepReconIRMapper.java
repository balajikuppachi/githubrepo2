package com.wellsfargo.regulatory.persister.trioptima.mapper;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PayReceiveEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.helper.mapper.PeriodEnums;

public class RegRepReconIRMapper 
{
	private static Logger logger = Logger.getLogger(RegRepReconIRMapper.class
			.getName());
	
	public RegRepTrioptima mapIRrows(ReportingContext context,TradeDetailType tradeDetail, ProductType product,RegRepTrioptima regRepTrioptima,
			BigDecimal parentOriginalNotional, String marketType, String dtccProdType)
	{
	BuySellEnum buyorSell = tradeDetail.getProduct().getBuySell();
	
	String index1tenor	 = null;
	String leg1index	 = null;
	String index2tenor	 = null;
	String leg2index	 = null;
	
	List<LegType> legs = product.getLeg();

	if (!GeneralUtils.IsNull(legs) && !legs.isEmpty()) {

		for (LegType leg : legs) {

			if (leg.getLegId() == 1) {

				String freqPeriosMul 		= null;
				String paymentFreq 			= null;
				BigDecimal fixedRate1 		= null;
				String isoCurrency			= null;
				String dayCount1_domain_key	= null;
				BigDecimal calcNotional 	= null;
				String resetFreq			= null;
				StringBuilder freqMulStrB 	= new StringBuilder();

				index1tenor 		 = leg.getIndexTenor();
				leg1index 			 = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.FLOATING_RATE_INDEX + "1");	
				dayCount1_domain_key = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.DAY_COUNT + "1");	
				fixedRate1 			 = leg.getFixedRate();
				
				try 
				{
					calcNotional 	= irNotional(parentOriginalNotional,leg.getNotional(), marketType, leg.getFixedFloat(),leg.getAmortizationFrequency(),
							leg.getAmortizationType(),  leg.getCashFlowSet() );
				} 
				catch (Exception ex) 
				{
					logger.debug("Cannot Calculate Notional");
				}

				isoCurrency 	= StringUtils.join(new String[] {Constants.ISO_CURRENCY_EXCEPTION,leg.getNotionalCurrency() },Constants.UNDERSCORE);								
				paymentFreq 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.PAYMENT_FREQ_PERIOD + "1");
				freqPeriosMul 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.PAYMENT_FREQ_MULTIPLIER + "1");
				resetFreq		= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.RESET_FREQ_PERIOD + "1");
				
				if (!GeneralUtils.IsNullOrBlank(freqPeriosMul))
				{
					freqMulStrB = freqMulStrB.append(freqPeriosMul);
					
				} 
				if (!GeneralUtils.IsNullOrBlank(paymentFreq))
				{
					freqMulStrB = freqMulStrB.append(":").append(paymentFreq);
				}
				
				{
					if(dtccProdType.contains(Constants.PRODUCT_TYPE_SWAPTION) || dtccProdType.contains(Constants.PRODUCT_TYPE_EXOTIC) ||
							dtccProdType.contains(Constants.PRODUCT_TYPE_FRA) || dtccProdType.contains(Constants.PRODUCT_TYPE_CAPFLOOR))
					{
						if(buyorSell.value().equalsIgnoreCase(Constants.BUY)) 
						{
							regRepTrioptima.setBuyer(Constants.PARTY1.toLowerCase());
							regRepTrioptima.setSeller(Constants.PARTY2.toLowerCase());
						}
						else 
						{
							regRepTrioptima.setBuyer(Constants.PARTY2.toLowerCase());
							regRepTrioptima.setSeller(Constants.PARTY1.toLowerCase());
						}
					}
					
					regRepTrioptima.setDayCountFractionLeg1(dayCount1_domain_key);
					regRepTrioptima.setEffectiveDateLeg1(CalendarUtils.xmlGregCalToCustomFormat(leg.getStartDate(), null));
					if (!GeneralUtils.IsNull(fixedRate1))
					{
						regRepTrioptima.setFixedRateLeg1(fixedRate1);
					}
					if (leg.getFixedFloat().compareTo(FixedFloatEnum.FLOAT) == 0)
					{
						regRepTrioptima.setFloatingRateIndexLeg1(leg1index);
						regRepTrioptima.setFloatingRateTenorLeg1(resetFreq);
					}
					
					regRepTrioptima.setNotionalAmountLeg1(calcNotional);
					if(!GeneralUtils.IsNullOrBlank(getDomain(isoCurrency)))
						regRepTrioptima.setNotionalCurrencyLeg1(getDomain(isoCurrency));
					else 
						regRepTrioptima.setNotionalCurrencyLeg1(leg.getNotionalCurrency());
					
					regRepTrioptima.setPaymentFreqLeg1(paymentFreq);
					
					if(!GeneralUtils.IsNull(freqMulStrB)) 
					{
						regRepTrioptima.setPaymentFreqMultiplierLeg1(freqMulStrB.toString());
					}
					
					regRepTrioptima.setResetFreq1(index1tenor);
					regRepTrioptima.setTerminationDateLeg1(CalendarUtils.xmlGregCalToCustomFormat(leg.getEndDate(), null));
					if(leg.isSwaptionStraddle()) {
						regRepTrioptima.setOptionType(Constants.STRADDLE);
					} 
					
					if(!dtccProdType.contains(Constants.PRODUCT_TYPE_EXOTIC) &&
							!dtccProdType.contains(Constants.PRODUCT_TYPE_FRA) && !dtccProdType.contains(Constants.PRODUCT_TYPE_CAPFLOOR))
					{
						if(leg.getPayReceive().compareTo(PayReceiveEnum.PAY) == 0) {
							regRepTrioptima.setLeg1Payer(Constants.PARTY1.toLowerCase());
							regRepTrioptima.setLeg2Payer(Constants.PARTY2.toLowerCase());
						} else {
							regRepTrioptima.setLeg1Payer(Constants.PARTY2.toLowerCase());
							regRepTrioptima.setLeg2Payer(Constants.PARTY1.toLowerCase());
						}
					}
				}	
			}
			if (leg.getLegId() == 2) {

				String paymentFreq 			= null;
				BigDecimal fixedRate2 		= null;
				BigDecimal calcNotional 	= null;
				String isoCurrency			= null;
				String dayCount2_domain_key	= null;
				String resetFreq 			= null;

				index2tenor 	   	 = leg.getIndexTenor();
				paymentFreq 		 = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.PAYMENT_FREQ_PERIOD + "2");
				leg2index			 = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.FLOATING_RATE_INDEX + "2");
				resetFreq			 = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.RESET_FREQ_PERIOD + "2");
				dayCount2_domain_key = ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getKeywords(), Constants.DAY_COUNT + "2");	
				fixedRate2 			 = leg.getFixedRate();
			
				try 
				{
					calcNotional = irNotional(parentOriginalNotional,leg.getNotional(), marketType,leg.getFixedFloat(),leg.getAmortizationFrequency(),
							leg.getAmortizationType(), leg.getCashFlowSet());
				}
				catch (Exception ex) 
				{
					logger.debug("Cannot Calculate Notional");
				}
				isoCurrency = StringUtils.join(new String[] {Constants.ISO_CURRENCY_EXCEPTION,leg.getNotionalCurrency() },Constants.UNDERSCORE);

				{
					regRepTrioptima.setDayCountFractionLeg2(dayCount2_domain_key);
					regRepTrioptima.setEffectiveDateLeg2(CalendarUtils.xmlGregCalToCustomFormat(leg.getStartDate(), null));
					if (!GeneralUtils.IsNull(fixedRate2))
					{
						regRepTrioptima.setFixedRateLeg2(fixedRate2);
					}

					if (leg.getFixedFloat().compareTo(FixedFloatEnum.FLOAT) == 0)
					{
						regRepTrioptima.setFloatingRateIndexLeg2(leg2index);
						regRepTrioptima.setFloatingRateTenorLeg2(resetFreq);
					}
					
					regRepTrioptima.setNotionalAmountLeg2(calcNotional);
					if(!GeneralUtils.IsNullOrBlank(getDomain(isoCurrency)))
						regRepTrioptima.setNotionalCurrencyLeg2(getDomain(isoCurrency));
					else 
						regRepTrioptima.setNotionalCurrencyLeg2(leg.getNotionalCurrency());
					regRepTrioptima.setPaymentFreqLeg2(paymentFreq);
					regRepTrioptima.setResetFreq2(index2tenor);
				}
			}
		}
	}
	ExerciseProvisionType exerProvType = product.getExerciseProvision();

	if (!GeneralUtils.IsNull(exerProvType) && Constants.CREDIT.equalsIgnoreCase(exerProvType.getEventType()))
	{
		regRepTrioptima.setOptionalEarlyTermination(exerProvType.getExerciseType().value());
	}

	if(!GeneralUtils.IsNullOrBlank(dtccProdType) && dtccProdType.contains(Constants.BASIS)) 
	{
		String party = FlippingoffField(index1tenor, index2tenor, leg1index, leg2index);
		if(Constants.PARTY2.equals(party)) 
		{
			regRepTrioptima = flipBasisParty2(regRepTrioptima);
		}

	}
	return regRepTrioptima;
	
	
}


	public String FlippingoffField( String index1tenor, String index2tenor,String leg1index, String leg2index) {

			if ((!GeneralUtils.IsNull(leg1index) && (!GeneralUtils.IsNull(leg2index))))
			{
				if (leg1index.compareToIgnoreCase(leg2index) < 0)
				{
					return Constants.PARTY1;
				}
				if (leg1index.compareToIgnoreCase(leg2index) > 0)
				{
					return Constants.PARTY2;
				}
				if (leg1index.compareToIgnoreCase(leg2index) == 0) 
				{
					String period1 = splitTenor(index1tenor)[0];
					String muliplier1 = splitTenor(index1tenor)[1];
					String period2 = splitTenor(index2tenor)[0];
					String muliplier2 = splitTenor(index2tenor)[1];

					if (PeriodEnums.enumValue(period1) < PeriodEnums.enumValue(period2))
					{
						return Constants.PARTY1;
					}
					if (PeriodEnums.enumValue(period1) > PeriodEnums.enumValue(period2))
					{
						return Constants.PARTY2;
					}
					if (PeriodEnums.enumValue(period1) == PeriodEnums.enumValue(period2))
					{
						if (Integer.valueOf(muliplier1) <= Integer.valueOf(muliplier2))
							return Constants.PARTY1;
						else
							return Constants.PARTY2;
					}
				}
			}
		return Constants.PARTY1;
	}
	public String[] splitTenor(String tenor) {
		String tenorPeriod = Constants.EMPTY_STRING;
		String tenorMultiplier = Constants.EMPTY_STRING;
		char[] charArr = tenor.toCharArray();

		for (int i = 0; i < charArr.length; i++) 
		{
			if (Character.isDigit(charArr[i]))
				tenorMultiplier += charArr[i];
			else
				tenorPeriod += charArr[i];
		}
		return new String[] { tenorPeriod, tenorMultiplier };
	}

	
	public RegRepTrioptima flipBasisParty2(RegRepTrioptima regRepTrioptima) 
	{
		String dayCountFracLeg1 		= regRepTrioptima.getDayCountFractionLeg1();
		String dayCountFracLeg2 		= regRepTrioptima.getDayCountFractionLeg2();
		String effectiveDateLeg1		= regRepTrioptima.getEffectiveDateLeg1();
		String effectiveDateLeg2		= regRepTrioptima.getEffectiveDateLeg2();
		BigDecimal fixedRateLeg1		= regRepTrioptima.getFixedRateLeg1();
		BigDecimal fixedRateLeg2		= regRepTrioptima.getFixedRateLeg2();
		String floatingRateLeg1 		= regRepTrioptima.getFloatingRateIndexLeg1();
		String floatingRateLeg2 		= regRepTrioptima.getFloatingRateIndexLeg2();
		String floatingTenorLeg1		= regRepTrioptima.getFloatingRateTenorLeg1();
		String floatingTenorLeg2		= regRepTrioptima.getFloatingRateTenorLeg2();
		String leg1Payer 				= regRepTrioptima.getLeg1Payer();
		String leg2Payer 				= regRepTrioptima.getLeg2Payer();
		BigDecimal notionalAmountLeg1	= regRepTrioptima.getNotionalAmountLeg1();
		BigDecimal notionalAmountLeg2	= regRepTrioptima.getNotionalAmountLeg2();
		String notionalCurrLeg1 		= regRepTrioptima.getNotionalCurrencyLeg1();
		String notionalCurrLeg2 		= regRepTrioptima.getNotionalCurrencyLeg2();
		String paymentFreqLeg1  		= regRepTrioptima.getPaymentFreqLeg1();
		String paymentFreqLeg2  		= regRepTrioptima.getPaymentFreqLeg2();
		String resetFreqLeg1    		= regRepTrioptima.getResetFreq1();
		String resetFreqLeg2 			= regRepTrioptima.getResetFreq2();
		
		regRepTrioptima.setDayCountFractionLeg1(dayCountFracLeg2);
		regRepTrioptima.setDayCountFractionLeg2(dayCountFracLeg1);
		regRepTrioptima.setEffectiveDateLeg1(effectiveDateLeg2);
		regRepTrioptima.setEffectiveDateLeg2(effectiveDateLeg1);
		regRepTrioptima.setFixedRateLeg1(fixedRateLeg2);
		regRepTrioptima.setFixedRateLeg2(fixedRateLeg1);
		regRepTrioptima.setFloatingRateIndexLeg1(floatingRateLeg2);
		regRepTrioptima.setFloatingRateIndexLeg2(floatingRateLeg1);
		regRepTrioptima.setFloatingRateTenorLeg1(floatingTenorLeg2);
		regRepTrioptima.setFloatingRateTenorLeg2(floatingTenorLeg1);
		regRepTrioptima.setLeg1Payer(leg2Payer);
		regRepTrioptima.setLeg2Payer(leg1Payer);
		regRepTrioptima.setNotionalAmountLeg1(notionalAmountLeg2);
		regRepTrioptima.setNotionalAmountLeg2(notionalAmountLeg1);
		regRepTrioptima.setNotionalCurrencyLeg1(notionalCurrLeg2);
		regRepTrioptima.setNotionalCurrencyLeg2(notionalCurrLeg1);
		regRepTrioptima.setPaymentFreqLeg1(paymentFreqLeg2);
		regRepTrioptima.setPaymentFreqLeg2(paymentFreqLeg1);
		regRepTrioptima.setResetFreq1(resetFreqLeg2);
		regRepTrioptima.setResetFreq2(resetFreqLeg1);
		
	return regRepTrioptima;
	}
	
	public BigDecimal irNotional(BigDecimal parentNotional, BigDecimal notional, String marketType, FixedFloatEnum legType, 
			String legAmortFrequency, String legAmortType, CashFlowType cashFlow) {

		if (!GeneralUtils.IsNull(parentNotional) && Constants.Partial_Term_Voluntary.equals(marketType)) 
		{
			return getTerminatedNotional(notional, parentNotional);
		}

		if ((!GeneralUtils.IsNull(legType) && legType.compareTo(FixedFloatEnum.FIXED) == 0) || ((!GeneralUtils.IsNull(legType) && legType.compareTo(FixedFloatEnum.FLOAT) == 0))) 
		{
			if (!GeneralUtils.IsNull(legAmortFrequency) && "ZC".equals(legAmortFrequency)) 
			{
				if (!GeneralUtils.IsNull(legAmortType) && "Bullet".equals(legAmortType)) 
				{
					if (!GeneralUtils.IsNull(cashFlow)) 
					{
						if(!cashFlow.getCashFlow().isEmpty())
						return cashFlow.getCashFlow().get(0).getCashflowAmount();
						
					} 
					else 
					{
						logger.debug("LegCashFlowInterest unavailable for Fixed/ZC/Bullet");
					}
				}
			}
		}
		return notional;
	}



	private BigDecimal getTerminatedNotional(BigDecimal current, BigDecimal parentNotional) {
		BigDecimal remaining = null;
		MathContext mc = new MathContext(2);

		if (!GeneralUtils.IsNull(current) && !GeneralUtils.IsNull(parentNotional))
			try {
				remaining = parentNotional.subtract(current, mc);
			} catch (Exception ee) {
				logger.debug("Remaining Notional Failed, Returning the value as is.", ee);
			}
		return remaining;
	}

	public String getDomain(String domain) {
		String domainRet = null;
		DomainMappingCache cache = DomainMappingCache.getInstance();
		domainRet = cache.getValue(domain);
		if (!GeneralUtils.IsNull(domainRet)) 
		{
			return domainRet;
		} 
		else
			return null;
	}
}
