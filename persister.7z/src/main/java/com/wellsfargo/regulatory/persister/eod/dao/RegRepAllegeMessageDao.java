package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.eod.dto.RegRepAllegeMessage;

/**
 * 
 * @author Raji Komatreddy
 *
 */

@Component
public class RegRepAllegeMessageDao implements RowMapper<RegRepAllegeMessage>
{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	String insertSql = "INSERT INTO REG_REP_ALLEGE_MESSAGE (report_type,inreplyto,sent_by,sent_to,status,jurisdiction,usi_prefix,usi,"
			+ "trade_id,party1_lei, party1_name,party1_address,party2_lei,party2_name,party2_address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	@Override
    public RegRepAllegeMessage mapRow(ResultSet arg0, int arg1) throws SQLException
    {
		RegRepAllegeMessage currRegRepAllegeMessage = new RegRepAllegeMessage();
	    
	    return currRegRepAllegeMessage;
    }
	
	public long insertandGetId(RegRepAllegeMessage regRepAllegeMessage)
	{
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator()
		{

			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException
			{
				PreparedStatement pst = conn.prepareStatement(insertSql, new String[]
				{ "id" });
				pst.setString(1, regRepAllegeMessage.getReportType());
				pst.setString(2, regRepAllegeMessage.getInreplyto());
				pst.setString(3, regRepAllegeMessage.getSentBy());
				pst.setString(4, regRepAllegeMessage.getSentTo());
				pst.setString(5, regRepAllegeMessage.getStatus());
				pst.setString(6, regRepAllegeMessage.getJurisdiction());
				pst.setString(7, regRepAllegeMessage.getUsiPrefix());
				pst.setString(8, regRepAllegeMessage.getUsi());
				pst.setString(9, regRepAllegeMessage.getTradeID());
				pst.setString(10, regRepAllegeMessage.getParty1Lei());
				pst.setString(11, regRepAllegeMessage.getParty1Name());
				pst.setString(12, regRepAllegeMessage.getParty1Address());
				pst.setString(13, regRepAllegeMessage.getParty2Lei());
				pst.setString(14, regRepAllegeMessage.getParty2Name());
				pst.setString(15, regRepAllegeMessage.getParty2Address());									

				return pst;
			}
		}, keyHolder);
		return (Long) keyHolder.getKey().longValue();

	}

}
