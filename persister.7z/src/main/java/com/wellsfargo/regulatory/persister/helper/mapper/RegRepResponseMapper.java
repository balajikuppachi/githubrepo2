package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse;
import com.wellsfargo.regulatory.commons.beans.FpMLResponse.Reason;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.RegRepMessageTypeEum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepException;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;

import static com.wellsfargo.regulatory.commons.keywords.Constants.MSG_STATUS_WACK;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepResponseMapper
{
	private static Logger logger = Logger.getLogger(RegRepResponseMapper.class.getName());

	/**
	 * @param ReportingContext
	 * @param Parent
	 * RegRepMessage
	 * @param RegRepResponse
	 * @throws MessagingException
	 */
	public RegRepResponse createRegRepResponse(FpMLResponse response, RegRepMessage dbMessage, String responseType) throws MessagingException
	{
		RegRepResponse dbResponse = null;
		String errorString = null;
		List<Reason> reasons = null;
		RegRepExceptionMapper excMapper = null;
		RegRepException dbException = null;
		Set<RegRepException> exceptionSet = null;

		if (null == response || (null == dbMessage))
		{
			errorString = "Unable to populate RegRepResponse since incoming context was null";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp-Mpr:122", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		dbResponse = new RegRepResponse();
		dbMessage.setRegRepResponse(dbResponse);

		dbResponse.setAcknowledgementStatus(responseType);
		if(null != response.getCreationTimestamp())
		{
			dbResponse.setAcknowledgementTimestamp(CalendarUtils.toDate(response.getCreationTimestamp()));
		}
		    
		dbResponse.setRegRepMessage(dbMessage);
		dbResponse.setInReplyTo((response.getInReplyTo() == null ? RegRepMessageTypeEum.SDR_NRP_NOTIFICATION.type() : response.getInReplyTo()));
		dbResponse.setSentBy((response.getSentBy() == null ? RegRepMessageTypeEum.SDR_NRP_NOTIFICATION.type() : response.getSentBy()));
		dbResponse.setExternalMessageId(response.getExternalMessageId());

		for (String sendTo : response.getSendTo())
		{
			if (null != sendTo)
			{
				if (null != dbResponse.getSentTo())
				{
					dbResponse.setSentTo(dbResponse.getSentTo() + "," + sendTo);
				}
				else
				{
					dbResponse.setSentTo(sendTo);
				}
			}
		}

		
		
		// - In case of a NACK
		reasons = response.getReasons();
		if (null != reasons && reasons.size() > 0)
		{
			excMapper = new RegRepExceptionMapper();
			exceptionSet = new HashSet<RegRepException>(3);
			
			//for (Reason reason : reasons)
			//{
			//	if(null == reason) continue;
				
			//	if(ExceptionTypeEnum.SDR_WARNING.equals(reason.type))
			//	{
			//		dbResponse.setAcknowledgementStatus(MSG_STATUS_WACK);
			//	}
			//}

			for (Reason reason : reasons)
			{
				if(null == reason) continue;

				if(ExceptionTypeEnum.SDR_WARNING.equals(reason.type))
				{
					dbResponse.setAcknowledgementStatus(MSG_STATUS_WACK);
				}
				
				dbException = excMapper.createRegRepException(dbMessage, reason);
				exceptionSet.add(dbException);
			}

			
			dbMessage.setRegRepExceptions(exceptionSet);
		}

		return dbResponse;
	}

}
