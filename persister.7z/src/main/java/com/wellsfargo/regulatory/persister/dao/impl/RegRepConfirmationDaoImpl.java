package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.RegRepConfirmationDao;
import com.wellsfargo.regulatory.persister.dto.RegRepConfirmation;

public class RegRepConfirmationDaoImpl extends 
		AbstractDaoImpl<RegRepConfirmation> implements RegRepConfirmationDao {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5768487216297788943L;

	@Override
	public Class<RegRepConfirmation> getEntityClass()
	{
		// TODO Auto-generated method stub
		return null;
	}


}
