package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.sql.Date;

/**
 * 
 * @author Raji Komatreddy
 * DTO object for REG_REP_EOD_JOB_EXECUTION_DETAILS
 *
 */
public class RegRepEodJobExecutionDetails implements Serializable
{
    private static final long serialVersionUID = 1L;
    
	private long jobExecutionId;
	private long jobDetailsId;
	private Date asOfDate;
	private String fileName;
	private String jobStatus;
	private int recordsTotal;
	private int recordsLoaded;
	private String errorDetails;
	private Timestamp createDatetime;
	private Timestamp updateDatetime;

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public long getJobDetailsId()
	{
		return jobDetailsId;
	}

	public void setJobDetailsId(long jobDetailsId)
	{
		this.jobDetailsId = jobDetailsId;
	}

	public Date getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String getJobStatus()
	{
		return jobStatus;
	}

	public void setJobStatus(String jobStatus)
	{
		this.jobStatus = jobStatus;
	}

	public int getRecordsTotal()
	{
		return recordsTotal;
	}

	public void setRecordsTotal(int recordsTotal)
	{
		this.recordsTotal = recordsTotal;
	}

	public int getRecordsLoaded()
	{
		return recordsLoaded;
	}

	public void setRecordsLoaded(int recordsLoaded)
	{
		this.recordsLoaded = recordsLoaded;
	}

	public String getErrorDetails()
	{
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails)
	{
		this.errorDetails = errorDetails;
	}

	public Timestamp getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Timestamp createDatetime)
	{
		this.createDatetime = createDatetime;
	}

	public Timestamp getUpdateDatetime()
	{
		return updateDatetime;
	}

	public void setUpdateDatetime(Timestamp updateDatetime)
	{
		this.updateDatetime = updateDatetime;
	}

	@Override
    public String toString()
    {
	    StringBuilder builder = new StringBuilder();
	    builder.append("RegRepEodJobExecutionDetails [jobExecutionId=");
	    builder.append(jobExecutionId);
	    builder.append(", jobDetailsId=");
	    builder.append(jobDetailsId);
	    builder.append(", asOfDate=");
	    builder.append(asOfDate);
	    builder.append(", fileName=");
	    builder.append(fileName);
	    builder.append(", jobStatus=");
	    builder.append(jobStatus);
	    builder.append(", recordsTotal=");
	    builder.append(recordsTotal);
	    builder.append(", recordsLoaded=");
	    builder.append(recordsLoaded);
	    builder.append(", errorDetails=");
	    builder.append(errorDetails);
	    builder.append(", createDatetime=");
	    builder.append(createDatetime);
	    builder.append(", updateDatetime=");
	    builder.append(updateDatetime);
	    builder.append("]");
	    return builder.toString();
    }

	
}
