package com.wellsfargo.regulatory.persister.dao;

import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepCollateralAgreements;

public interface RegRepCollateralAgreementsDao extends Dao<RegRepCollateralAgreements> {

	List<RegRepCollateralAgreements> findAll();

}
