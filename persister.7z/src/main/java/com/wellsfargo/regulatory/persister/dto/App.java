package com.wellsfargo.regulatory.persister.dto;

/**
 * Hello world!
 */
public class App
{
	public static void main(String[] args)
	{
		System.out.println("Hello World!");
	}
}
