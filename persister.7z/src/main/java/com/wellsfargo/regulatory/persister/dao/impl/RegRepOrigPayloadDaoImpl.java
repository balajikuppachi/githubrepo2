package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepOrigPayloadDao;
import com.wellsfargo.regulatory.persister.dto.RegRepOrigPayload;

public class RegRepOrigPayloadDaoImpl extends AbstractDaoImpl<RegRepOrigPayload> implements RegRepOrigPayloadDao{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3557354107676540318L;
	
	@Override
	public Class<RegRepOrigPayload> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepOrigPayload.class;
	}

	
}
