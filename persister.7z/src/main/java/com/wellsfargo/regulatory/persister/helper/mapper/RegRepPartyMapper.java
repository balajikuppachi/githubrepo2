package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.PartyAttributesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PartyAttributesType.Attribute;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepParty;
import com.wellsfargo.regulatory.persister.dto.RegRepPartyAttribute;
import com.wellsfargo.regulatory.persister.dto.RegRepPartyAttributeId;
import com.wellsfargo.regulatory.persister.dto.RegRepPartyId;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepPartyMapper
{
	private static Logger logger = Logger.getLogger(RegRepPartyMapper.class.getName());

	public RegRepParty createRegRepParty(TradePartyType ipParty, RegRepTradeDetail regRepTradeDetail, int id)
	{
		RegRepParty dbParty 				= null;
		RegRepPartyId dbPartyId 			= null;
		PartyAttributesType attributes 		= null;
		Set<RegRepPartyAttribute> dbPtyAttributes = null;
		RegRepPartyAttribute dbPtyAttribute = null;
		int attrbId = 1;

		if (null == ipParty || null == regRepTradeDetail)
		{
			logger.debug("RegRepParty object could not be " + "populated due to invalid incoming data");
			return dbParty;
		}

		dbParty = new RegRepParty();
		dbParty.setRegRepTradeDetail(regRepTradeDetail);

		dbPartyId 	= createRegRepPartyId(dbParty, id);
		attributes 	= ipParty.getPartyAttributes();
		
		dbParty.setId(dbPartyId);
		
		if (null != attributes)
		{
			dbPtyAttributes = new HashSet<RegRepPartyAttribute>(5);

			for (Attribute attribute : attributes.getAttribute())
			{
				dbPtyAttribute = createPartyAttribute(attribute, dbParty, attrbId);
				dbPtyAttributes.add(dbPtyAttribute);
				attrbId++;
			}
		}
		else
		{
			logger.debug("Unable to poplulate Attributes, " + "since incoming data doesn't have attributes populated");
		}

		dbParty.setAddress2(ipParty.getAddress2());
		dbParty.setAddress1(ipParty.getAddress1());
		dbParty.setBusinessAccountId(ipParty.getBusinessAccountId());
		dbParty.setCity(ipParty.getCity());
		dbParty.setCountry(ipParty.getCountry());
		
		if (null != ipParty.getClassification()) dbParty.setClassification(ipParty.getClassification().value());
		if (null != ipParty.getDesignation()) dbParty.setDesignation(ipParty.getDesignation().value());

		dbParty.setDtccParticipantId(ipParty.getDtccParticipantId());
		dbParty.setEmirClearingThreshold(ConversionUtils.booleanToDbString(ipParty.isEmirClearingThreshold()));
		dbParty.setEmirDirectlyLinked(ConversionUtils.booleanToDbString(ipParty.isEmirDirectlyLinked()));
		dbParty.setEmirFinancialEntity(ConversionUtils.booleanToDbString(ipParty.isEmirFinancialEntity()));
		dbParty.setEmirRegionEea(ipParty.getEmirRegionEEA());
		dbParty.setEmirTaxanomy(ipParty.getEmirTaxonomy());
		dbParty.setEmirTradingCapacity(ipParty.getEmirTradingCapacity());
		dbParty.setEndUserException(ConversionUtils.booleanToDbString(ipParty.getEndUserException()));
		// dbParty.setId(dbPartyId);
		dbParty.setIsFcm(ConversionUtils.booleanToDbString(ipParty.isIsFCM()));
		dbParty.setLei(ipParty.getLEI());
		dbParty.setPartyName(ipParty.getPartyName());
		dbParty.setRegRepPartyAttributes(dbPtyAttributes);
		dbParty.setState(ipParty.getState());
		dbParty.setFinancialEntity(ConversionUtils.booleanToDbString(ipParty.isFinancialEntity()));
		dbParty.setUsPerson(ConversionUtils.booleanToDbString((ipParty.isUsPerson())));
		dbParty.setZip(ipParty.getZip());

		
		/*** Start LEI Changes ***/ 
		
		dbParty.setLeiPrefix(StringUtils.trimToEmpty(ipParty.getLEIPrefix()));
		dbParty.setLeiValue(StringUtils.trimToEmpty(ipParty.getLEIValue()));

		dbParty.setBrokerLEIPrefix(StringUtils.trimToEmpty(ipParty.getBrokerLEIPrefix()));
		dbParty.setBrokerLEIValue(StringUtils.trimToEmpty(ipParty.getBrokerLEIValue()));

		dbParty.setClearingBrokerLEIPrefix(StringUtils.trimToEmpty(ipParty.getClearingBrokerLEIPrefix()));
		dbParty.setClearingBrokerLEIValue(StringUtils.trimToEmpty(ipParty.getClearingBrokerLEIValue()));

		dbParty.setExecutionAgentLEIPrefix(StringUtils.trimToEmpty(ipParty.getExecutionAgentLEIPrefix()));
		dbParty.setExecutionAgentLEIValue(StringUtils.trimToEmpty(ipParty.getExecutionAgentLEIValue()));

		dbParty.setBeneficiaryIdLEIPrefix(StringUtils.trimToEmpty(ipParty.getBeneficiaryIdLEIPrefix()));
		dbParty.setBeneficiaryIdLEIValue(StringUtils.trimToEmpty(ipParty.getBeneficiaryIdLEIValue()));

		/*** End LEI Changes ***/
		
		return dbParty;
	}

	private RegRepPartyId createRegRepPartyId(RegRepParty party, int id)
	{
		RegRepPartyId partyId = null;

		if (null == party)
		{
			logger.debug("RegRepPartyId object could not be " + "populated due to invalid incoming data");
			return partyId;
		}

		partyId = new RegRepPartyId();

		partyId.setRegRepPartyId(id);
		partyId.setRegRepMessageId(party.getRegRepTradeDetail().getRegRepSdrRequest().getRegRepMessage().getRegRepMessageId());

		return partyId;
	}

	private RegRepPartyAttribute createPartyAttribute(Attribute attribute, RegRepParty party, int id)
	{

		RegRepPartyAttribute ptyAttribute = null;
		RegRepPartyAttributeId attrId = null;

		if (null == party || null == attribute)
		{
			logger.debug("RegRepPartyAttribute object could not be " + "populated due to invalid incoming data");
			return ptyAttribute;
		}

		ptyAttribute = new RegRepPartyAttribute();
		ptyAttribute.setRegRepParty(party);

		attrId = createRegRepAttributeId(party, id);

		ptyAttribute.setId(attrId);
		ptyAttribute.setName(attribute.getName());
		ptyAttribute.setValue(attribute.getValue());

		return ptyAttribute;
	}

	private RegRepPartyAttributeId createRegRepAttributeId(RegRepParty party, int id)
	{

		RegRepPartyAttributeId partyAttributeId = null;

		if (null == party)
		{
			logger.debug("RegRepPartyAttributeId object could not be " + "populated due to invalid incoming data");
			return partyAttributeId;
		}

		partyAttributeId = new RegRepPartyAttributeId();

		partyAttributeId.setRegRepPartyId(party.getId().getRegRepPartyId());
		partyAttributeId.setRegRepMessageId(party.getRegRepTradeDetail().getRegRepSdrRequest().getRegRepMessage().getRegRepMessageId());
		partyAttributeId.setRegRepPartyAttributeId(id);

		return partyAttributeId;
	}
}
