package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepPrCid;

public interface RegRepPrCidDao extends Dao<RegRepPrCid>, Serializable {}
