package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.Set;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType.PaymentDates;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType.ValuationDates;
import com.wellsfargo.regulatory.persister.dto.RegRepCashSettlement;
import com.wellsfargo.regulatory.persister.dto.RegRepCashSettlementTypeDate;
import com.wellsfargo.regulatory.persister.dto.RegRepExerciseProvision;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepCashSettlementMapper
{

	private static Logger logger = Logger.getLogger(RegRepCashSettlementMapper.class.getName());

	public RegRepCashSettlement createRegRepCashSettlement(RegRepExerciseProvision dbProvision, CashSettlementType ipCashSettlement)
	{

		RegRepCashSettlement dbCashSettlement = null;
		RegRepCashSettlementDateMapper dateMapper = null;
		RegRepCashSettlementTypeDate dbDate = null;
		Set<RegRepCashSettlementTypeDate> dbDates = null;
		int dbDateId = 1;

		if (null == dbProvision || null == ipCashSettlement)
		{
			logger.debug("RegRepCashSettlement object could not be " + "populated due to invalid incoming data");
			return dbCashSettlement;
		}

		dateMapper = new RegRepCashSettlementDateMapper();
		dbDates = new HashSet<RegRepCashSettlementTypeDate>(5);

		dbCashSettlement = new RegRepCashSettlement();
		dbCashSettlement.setRegRepExerciseProvision(dbProvision);

		dbCashSettlement.setRegRepCashSettlementId(dbProvision.getRegRepExerciseProvisionId());
		dbCashSettlement.setCurrency(ipCashSettlement.getCurrency());

		if (null != ipCashSettlement.getPaymentDateBusinessDayConvention()) dbCashSettlement.setPaymentDateBusinessdayConvention(ipCashSettlement.getPaymentDateBusinessDayConvention().value());

		dbCashSettlement.setPaymentDateHolidays(ipCashSettlement.getPaymentDateHolidays());
		dbCashSettlement.setQuoteType(ipCashSettlement.getQuoteType());

		// call here based on the incoming date type
		if (ipCashSettlement.getPaymentDates() != null)
		{

			for (PaymentDates payDate : ipCashSettlement.getPaymentDates())
			{

				dbDate = dateMapper.createCashSettlementTypeDate(dbCashSettlement, null, payDate, dbDateId++);
				dbDates.add(dbDate);
			}
		}

		if (ipCashSettlement.getValuationDates() != null)
		{

			for (ValuationDates valDate : ipCashSettlement.getValuationDates())
			{

				dbDate = dateMapper.createCashSettlementTypeDate(dbCashSettlement, valDate, null, dbDateId++);
				dbDates.add(dbDate);
			}
		}

		dbCashSettlement.setSettleMethod(ipCashSettlement.getSettleMethod());

		if (null != ipCashSettlement.getPaymentDateBusinessDayConvention()) dbCashSettlement.setValuationDateBusinessdayConvention(ipCashSettlement.getValuationDateBusinessDayConvention().value());

		dbCashSettlement.setValuationDateHolidays(ipCashSettlement.getValuationDateHolidays());

		dbCashSettlement.setRegRepCashSettlementTypeDates(dbDates);

		return dbCashSettlement;

	}

}
