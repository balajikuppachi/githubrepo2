package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepRulesConfig;
import com.wellsfargo.regulatory.persister.dao.RegRepRulesConfigDao;

public class RegRepRulesConfigDaoImpl extends AbstractDaoImpl<RegRepRulesConfig> implements RegRepRulesConfigDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8683770829290676857L;

	@Override
	public Class<RegRepRulesConfig> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepRulesConfig.class;
	}	
 

}
