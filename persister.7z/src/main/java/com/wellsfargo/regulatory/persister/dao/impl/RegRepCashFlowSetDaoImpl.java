package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepCashFlowSetDao;
import com.wellsfargo.regulatory.persister.dto.RegRepCashFlowSet;

public class RegRepCashFlowSetDaoImpl extends AbstractDaoImpl<RegRepCashFlowSet> implements RegRepCashFlowSetDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1112152512042158299L;

	@Override
	public Class<RegRepCashFlowSet> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepCashFlowSet.class;
	}

	

    
}
