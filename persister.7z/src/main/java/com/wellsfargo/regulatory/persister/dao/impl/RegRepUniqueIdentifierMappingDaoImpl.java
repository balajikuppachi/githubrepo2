package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.List;

import com.wellsfargo.regulatory.persister.dao.RegRepUniqueIdentifierMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;

public class RegRepUniqueIdentifierMappingDaoImpl extends AbstractDaoImpl<RegRepUniqueIdentifierMapping> implements RegRepUniqueIdentifierMappingDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5386040627454828115L;

	@Override
	public Class<RegRepUniqueIdentifierMapping> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepUniqueIdentifierMapping.class;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RegRepUniqueIdentifierMapping> loadUniqueIdentifierByTradeId(
			String tradeId) {
		
		return findByNamedQuery(RegRepUniqueIdentifierMapping.GET_UNIQUE_IDENTIFIER_BY_USI, new Object[]
				{ tradeId });

	}
}
