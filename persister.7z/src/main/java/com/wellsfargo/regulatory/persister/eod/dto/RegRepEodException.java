package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author Raji Komatreddy
 */
public class RegRepEodException implements Serializable
{
	private static final long serialVersionUID = 1L;

	private long exceptoinId;
	private long submissionId;
	private String code;
	private String description;
	private String type;
	private String severity;
	private String status;
	private Timestamp insertTimeStamp;

	public long getExceptoinId()
	{
		return exceptoinId;
	}

	public void setExceptoinId(long exceptoinId)
	{
		this.exceptoinId = exceptoinId;
	}

	public long getSubmissionId()
	{
		return submissionId;
	}

	public void setSubmissionId(long submissionId)
	{
		this.submissionId = submissionId;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getSeverity()
	{
		return severity;
	}

	public void setSeverity(String severity)
	{
		this.severity = severity;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public Timestamp getInsertTimeStamp()
	{
		return insertTimeStamp;
	}

	public void setInsertTimeStamp(Timestamp insertTimeStamp)
	{
		this.insertTimeStamp = insertTimeStamp;
	}

}
