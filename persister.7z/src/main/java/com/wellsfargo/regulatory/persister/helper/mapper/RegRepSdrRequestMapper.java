package com.wellsfargo.regulatory.persister.helper.mapper;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ConfirmationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepConfirmation;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepSdrRequestMapper
{
	private static Logger logger = Logger.getLogger(RegRepSdrRequestMapper.class.getName());

	public RegRepSdrRequest createSdrRequest(ReportingContext context, RegRepMessage message) throws MessagingException
	{
		logger.debug("Entering createSdrRequest() method");

		RegRepSdrRequest dbRequest 				= null;
		SdrRequest ipRequest 					= null;
		RegulatoryType regulatory 				= null;
		RegRepRegulatory dbRegulatory 			= null;
		RegRepRegulatoryMapper regMapper 		= null;
		RegRepTradeDetailMapper trdDetMapper 	= null;
		RegRepConfirmationMapper confMapper 	= null;
		TradeDetailType ipTradeDetail 			= null;
		TradeType ipTrade 						= null;
		RegRepTradeDetail dbTradeDetail 		= null;
		TradeHeaderType ipTradeHeader 			= null;
		RegRepTradeHeaderMapper trdHeaderMapper = null;
		RegRepTradeHeader dbTradeHeader 		= null;
		RegRepConfirmation confirmation 		= null;
		ConfirmationType ipConfirm 				= null;

		if (null == context || null == message) 
			throw new MessagingException("12dB", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Unable to craeate RegRepSdrRequest Object due to invalid Message | Context object");

		ipRequest = context.getSdrRequest();

		if (null == ipRequest)
		{
			logger.warn("^^^^^^ Unable to persist sdrRequest, " + "since incoming data doesn't have sdrRequest populated");
			return dbRequest;
		}		

		ipTrade 	= ipRequest.getTrade();
		ipConfirm 	= ipRequest.getConfirmation();

		if (null == ipTrade && null == ipConfirm)
		{
			logger.warn("^^^^^^ Unable to persist Trade, " + "since incoming data doesn't have Trade/Confirmation populated");
			return dbRequest;
		}
		
		dbRequest = new RegRepSdrRequest();
		dbRequest.setRegRepMessage(message);
		
		if(null != ipConfirm)
		{	
			confMapper		= new RegRepConfirmationMapper();
			confirmation 	= confMapper.createRegRepConfirmation(dbRequest, ipConfirm);
		}
			
		if(null != ipTrade)
		{
			regulatory = ipTrade.getRegulatory();
			
			if (null != regulatory)
			{
				regMapper 		= new RegRepRegulatoryMapper();
				dbRegulatory 	= regMapper.createRegRepRegulatory(regulatory, dbRequest);
			}
	
			ipTradeDetail = ipTrade.getTradeDetail();
			if (null != ipTradeDetail)
			{
				trdDetMapper 	= new RegRepTradeDetailMapper();
				dbTradeDetail 	= trdDetMapper.createRegRepTradeDetail(ipTradeDetail, dbRequest);
			}
	
			ipTradeHeader = ipTrade.getTradeHeader();
			if (null != ipTradeHeader)
			{
				trdHeaderMapper = new RegRepTradeHeaderMapper();
				dbTradeHeader 	= trdHeaderMapper.createRegRepTradeHeader(dbRequest, ipTradeHeader);
			}
		}	

		dbRequest.setAssetClass(ipRequest.getAssetClass());
		dbRequest.setCreateDateTime(CalendarUtils.toDate(ipRequest.getCreateDateTime()));
		
		if(context.isConfirmationAlert())
		{
			dbRequest.setIsConfirmation(Constants.APP_TRUE);
			dbRequest.setIsTrade(Constants.APP_FALSE);
		}
		else
		{
			dbRequest.setIsConfirmation(Constants.APP_FALSE);
			dbRequest.setIsTrade(Constants.APP_TRUE);			
		}
		
		dbRequest.setIsValuation(Constants.APP_FALSE);

		/*
		 * @Comment : Amit Rana Need not be set, else hibernate creates a duplicate object
		 * dbRequest.setRegRepMessageId(regRepMessageId);
		 */

		dbRequest.setRegRepRegulatory(dbRegulatory);
		dbRequest.setRegRepTradeDetail(dbTradeDetail);
		dbRequest.setRegRepTradeHeader(dbTradeHeader);
		dbRequest.setRegRepConfirmation(confirmation);
		dbRequest.setSourceSystem(ipRequest.getSource());
				
		logger.debug("Successfully created REG_REP_SDR_REQUEST object");
		
		return dbRequest;
	}
}
