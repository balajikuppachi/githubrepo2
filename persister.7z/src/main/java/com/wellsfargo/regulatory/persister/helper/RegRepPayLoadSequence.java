package com.wellsfargo.regulatory.persister.helper;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.persister.dao.RegRepPayloadExtnDao;

public class RegRepPayLoadSequence
{
	private Logger logger = Logger.getLogger(getClass());

	private AtomicLong nextId = new AtomicLong();

	private RegRepPayloadExtnDao regRepPayloadExtnDao;

	// Long idMin = (long) 01;
	// Long idMax = (long) 99990009;

	Long idMin;
	Long idMax;

	public void initialize()
	{
		if (idMin == null)
		{
			idMin = 0l;
		}

		if (idMax == null)
		{
			idMax = Long.MAX_VALUE;
		}

		Long maxId = regRepPayloadExtnDao.findFeedIdInRange(idMin, idMax);

		if (maxId == null)
		{
			nextId.set(idMin);
		}
		else
		{
			nextId.set(maxId + 1);
		}

		logger.info("RegRepPayLoad Id started with " + nextId.get() + " and max " + idMax);
	}

	// TODO: AZ - This implementation is not cluster friendly as it assumes that
	// only one instance of the application can work with the DB
	public BigDecimal getNextId()
	{
		long id = nextId.getAndIncrement();

		if (id > idMax)
		{
			throw new IllegalStateException("RegRepPayLoadId max reached, configured range is " + idMin + "-" + idMax + ". Use idMin and idMax application properties to set a different range");
		}
		return BigDecimal.valueOf(id);
	}

	public void setRegRepPayloadExtnDao(RegRepPayloadExtnDao regRepPayloadExtnDao)
	{
		this.regRepPayloadExtnDao = regRepPayloadExtnDao;
	}

	public Long getIdMin()
	{
		return idMin;
	}

	public void setIdMin(Long idMin)
	{
		this.idMin = idMin;
	}

	public Long getIdMax()
	{
		return idMax;
	}

	public void setIdMax(Long idMax)
	{
		this.idMax = idMax;
	}

}
