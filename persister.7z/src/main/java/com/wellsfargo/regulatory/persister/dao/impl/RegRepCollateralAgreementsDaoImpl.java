package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.persister.dao.RegRepCollateralAgreementsDao;
import com.wellsfargo.regulatory.persister.dto.RegRepCollateralAgreements;
import com.wellsfargo.regulatory.persister.dto.RegRepCollateralAgreementsId;
import com.wellsfargo.regulatory.persister.dto.RegRepMappingBussaccidLei;

@Transactional
@Repository

public class RegRepCollateralAgreementsDaoImpl extends AbstractDaoImpl<RegRepCollateralAgreements>
		implements RegRepCollateralAgreementsDao {

	private static final String QUERY_FOR_AGREEMENTS = "select regRepCollateralAgreements.agreement_id,regRepCollateralAgreements.agreement_type,regRepCollateralAgreements.shortname,regRepCollateralAgreements.margin_type,regRepCollateralAgreements.ext_agreement_type,regRepCollateralAgreements.cid_legal,regRepCollateralAgreements.collateralization from REG_REP_COLLATERAL_AGREEMENTS regRepCollateralAgreements";
	
	
	@Override
	public Class<RegRepCollateralAgreements> getEntityClass() {
		// TODO Auto-generated method stub
		return RegRepCollateralAgreements.class;
	}

	public List<RegRepCollateralAgreements> findAll() {
		
		//List<RegRepCollateralAgreements> collateralAgreements =  findByNamedQuery(QUERY_FOR_AGREEMENTS);
		List<RegRepCollateralAgreements> collateralAgreements = new ArrayList<RegRepCollateralAgreements>();
		SQLQuery query = findByNamedNativeQuery(QUERY_FOR_AGREEMENTS);
		List<Object[]> resultList = query.list();
		
		resultList.stream().forEach((record)->{
			RegRepCollateralAgreements regrepcollAgreements = new RegRepCollateralAgreements();
			RegRepCollateralAgreementsId id = new RegRepCollateralAgreementsId();
			id.setAgreementId((String) record[0]);
			id.setAgreementType((String) record[1]);
			id.setShortname((String) record[2]);
			id.setMarginType((String)record[3]);
			id.setExtAgreementType((String)record[4]);
			id.setCidLegal((String) record[5]);
			id.setCollateralization((String) record[6]);
			regrepcollAgreements.setId(id);
			collateralAgreements.add(regrepcollAgreements);
			
		});
		
		return collateralAgreements;
	}

	

}
