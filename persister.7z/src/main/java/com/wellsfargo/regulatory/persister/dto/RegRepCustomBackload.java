package com.wellsfargo.regulatory.persister.dto;

import java.io.Serializable;
import java.util.Date;

public class RegRepCustomBackload  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long backloadId;
	private RegRepMessage regRepMessage;	
	private String isCustomBackload;
	private String backloadReason;
	private String isSdrLive;
	private Date orginalEnteredDateTime;
	private String v7ProductType;
	private String v7ProductSubType;
	private String v7AssetClass;
	private Long sendId;
	private String isCustomEodRefresh;
	private String customEodRefreshReason;
	
	public RegRepCustomBackload(Long backloadId, RegRepMessage regRepMessage,			
			String isCustomBackload, String backloadReason, String isSdrLive,
			Date orginalEnteredDateTime, String v7ProductType,
			String v7ProductSubType, String v7AssetClass, Long sendId) {
		super();
		this.backloadId = backloadId;
		this.regRepMessage = regRepMessage;
		this.isCustomBackload = isCustomBackload;
		this.backloadReason = backloadReason;
		this.isSdrLive = isSdrLive;
		this.orginalEnteredDateTime = orginalEnteredDateTime;
		this.v7ProductType = v7ProductType;
		this.v7ProductSubType = v7ProductSubType;
		this.v7AssetClass = v7AssetClass;
		this.sendId = sendId;
	}

	public RegRepCustomBackload() {
		
		super();		
	}

	public Long getBackloadId() {
		return backloadId;
	}

	public void setBackloadId(Long backloadId) {
		this.backloadId = backloadId;
	}

	public RegRepMessage getRegRepMessage() {
		return regRepMessage;
	}

	public void setRegRepMessage(RegRepMessage regRepMessage) {
		this.regRepMessage = regRepMessage;
	}

	public String getIsCustomBackload() {
		return isCustomBackload;
	}

	public void setIsCustomBackload(String isCustomBackload) {
		this.isCustomBackload = isCustomBackload;
	}

	public String getBackloadReason() {
		return backloadReason;
	}

	public void setBackloadReason(String backloadReason) {
		this.backloadReason = backloadReason;
	}

	public String getIsSdrLive() {
		return isSdrLive;
	}

	public void setIsSdrLive(String isSdrLive) {
		this.isSdrLive = isSdrLive;
	}

	public Date getOrginalEnteredDateTime() {
		return orginalEnteredDateTime;
	}

	public void setOrginalEnteredDateTime(Date orginalEnteredDateTime) {
		this.orginalEnteredDateTime = orginalEnteredDateTime;
	}

	public String getV7ProductType() {
		return v7ProductType;
	}

	public void setV7ProductType(String v7ProductType) {
		this.v7ProductType = v7ProductType;
	}

	public String getV7ProductSubType() {
		return v7ProductSubType;
	}

	public void setV7ProductSubType(String v7ProductSubType) {
		this.v7ProductSubType = v7ProductSubType;
	}

	public String getV7AssetClass() {
		return v7AssetClass;
	}

	public void setV7AssetClass(String v7AssetClass) {
		this.v7AssetClass = v7AssetClass;
	}

	public Long getSendId() {
		return sendId;
	}

	public void setSendId(Long sendId) {
		this.sendId = sendId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((backloadId == null) ? 0 : backloadId.hashCode());
		result = prime * result
				+ ((backloadReason == null) ? 0 : backloadReason.hashCode());
		result = prime
				* result
				+ ((isCustomBackload == null) ? 0 : isCustomBackload.hashCode());
		result = prime * result
				+ ((isSdrLive == null) ? 0 : isSdrLive.hashCode());
		result = prime
				* result
				+ ((orginalEnteredDateTime == null) ? 0
						: orginalEnteredDateTime.hashCode());		
		result = prime * result
				+ ((regRepMessage == null) ? 0 : regRepMessage.hashCode());		
		result = prime * result + ((sendId == null) ? 0 : sendId.hashCode());		
		result = prime * result
				+ ((v7AssetClass == null) ? 0 : v7AssetClass.hashCode());
		result = prime
				* result
				+ ((v7ProductSubType == null) ? 0 : v7ProductSubType.hashCode());
		result = prime * result
				+ ((v7ProductType == null) ? 0 : v7ProductType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegRepCustomBackload other = (RegRepCustomBackload) obj;
		if (backloadId == null) {
			if (other.backloadId != null)
				return false;
		} else if (!backloadId.equals(other.backloadId))
			return false;
		if (backloadReason == null) {
			if (other.backloadReason != null)
				return false;
		} else if (!backloadReason.equals(other.backloadReason))
			return false;
		if (isCustomBackload == null) {
			if (other.isCustomBackload != null)
				return false;
		} else if (!isCustomBackload.equals(other.isCustomBackload))
			return false;
		if (isSdrLive == null) {
			if (other.isSdrLive != null)
				return false;
		} else if (!isSdrLive.equals(other.isSdrLive))
			return false;
		if (orginalEnteredDateTime == null) {
			if (other.orginalEnteredDateTime != null)
				return false;
		} else if (!orginalEnteredDateTime.equals(other.orginalEnteredDateTime))
			return false;	
		if (regRepMessage == null) {
			if (other.regRepMessage != null)
				return false;
		} else if (!regRepMessage.equals(other.regRepMessage))
			return false;		
		if (sendId == null) {
			if (other.sendId != null)
				return false;
		} else if (!sendId.equals(other.sendId))
			return false;		
		if (v7AssetClass == null) {
			if (other.v7AssetClass != null)
				return false;
		} else if (!v7AssetClass.equals(other.v7AssetClass))
			return false;
		if (v7ProductSubType == null) {
			if (other.v7ProductSubType != null)
				return false;
		} else if (!v7ProductSubType.equals(other.v7ProductSubType))
			return false;
		if (v7ProductType == null) {
			if (other.v7ProductType != null)
				return false;
		} else if (!v7ProductType.equals(other.v7ProductType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RegRepCustomBackload [backloadId=" + backloadId
				+ ", regRepMessage=" + regRepMessage				
				+ ", isCustomBackload=" + isCustomBackload
				+ ", backloadReason=" + backloadReason + ", isSdrLive="
				+ isSdrLive + ", orginalEnteredDateTime="
				+ orginalEnteredDateTime + ", v7ProductType=" + v7ProductType
				+ ", v7ProductSubType=" + v7ProductSubType + ", v7AssetClass="
				+ v7AssetClass + ", sendId=" + sendId + "]";
	}

	public String getIsCustomEodRefresh() {
		return isCustomEodRefresh;
	}

	public void setIsCustomEodRefresh(String isCustomEodRefresh) {
		this.isCustomEodRefresh = isCustomEodRefresh;
	}

	public String getCustomEodRefreshReason() {
		return customEodRefreshReason;
	}

	public void setCustomEodRefreshReason(String customEodRefreshReason) {
		this.customEodRefreshReason = customEodRefreshReason;
	}
}
