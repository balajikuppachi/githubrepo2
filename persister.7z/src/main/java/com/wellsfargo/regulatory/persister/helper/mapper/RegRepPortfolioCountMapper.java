package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartiesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.persister.dto.RegRepPortfolioCount;

/**
 * @author Amit Rana
 * @date 06/08/2015
 * @version 1.0
 */

public class RegRepPortfolioCountMapper {
	
	private static Logger logger = Logger.getLogger(RegRepPortfolioCountMapper.class.getName());

	public RegRepPortfolioCount createRegRepPortfolioCount(ReportingContext context)
	{
		RegRepPortfolioCount 	dbCount 	= null;
		String 					assetClass	= null;
		String 					lei			= null;
		String					cpName		= null;
		long					count		= 1L;
		String					cpDesig		= null;
		SdrRequest				request 	= null;
		TradeType				trade		= null;
		TradePartiesType		parties		= null;
		TradeHeaderType			header		= null;
		TradeDetailType			details		= null;
		
		logger.debug("Entering createRegRepPortfolioCount");
				
		if(null == context)
			return dbCount;

		assetClass 	= context.getAssetClass();
		request 	= context.getSdrRequest();
		
		if(null == request)
			return dbCount;
		
		trade = request.getTrade();
		
		if(null == trade)
			return dbCount;
		
		header = trade.getTradeHeader();
		
		if(null == header)
			return dbCount;
		
		lei = header.getCounterpartyLEI();
		
		details = trade.getTradeDetail();
		
		if(null == details)
			return dbCount;
		
		parties = details.getTradeParties();
		
		if(null != parties){
		
			for(TradePartyType party : parties.getParty()){
				
				if(party.getLEI().equals(lei)){
					
					if(null != party.getDesignation())
						cpDesig = party.getDesignation().name();
					
					cpName	= party.getPartyName();
					
					break;
				}
			}
		}
		
		
		dbCount = new RegRepPortfolioCount();
		dbCount.setAssetClass(assetClass);
		dbCount.setCounterpartyDsig(cpDesig);
		dbCount.setCounterpartyLei(lei);
		dbCount.setCounterpartyName(cpName);
		dbCount.setRegRepCount(count);
		dbCount.setUpdateTimestamp(new Date());
		
		logger.debug("Exiting createRegRepPortfolioCount");
		return dbCount;		
	}

}
