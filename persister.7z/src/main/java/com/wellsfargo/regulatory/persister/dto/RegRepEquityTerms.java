package com.wellsfargo.regulatory.persister.dto;

import java.io.Serializable;
import java.util.Date;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class RegRepEquityTerms implements Serializable
{
    private static final long serialVersionUID = 1L;
    
    private String regRepProductId;
    private Double vegaNotional;
    private Double changeInVegaNotional;
    private String nonStandardFlag;
    private String embeddedOption;
    private String valuationFrequencyPeriod;
    private int valuationFrequencyPeriodMultiplier;
    private Date finalValuationDate;
    private Double equityVarianceStrikePrice;
    private RegRepProduct regRepProduct;
   
 // Get REG_REP_REPORT record based on EXTERNAL_MSG_ID
 	public final static String GET_EQUITY_TERMS_BY_USI = "loadRegRepEuqityTermsByUsi";
    
    public RegRepEquityTerms()
    {
    	
    }
    public RegRepEquityTerms(RegRepProduct regRepProduct)
    {
    	this.regRepProduct = regRepProduct;
    	 
    }
    
	public RegRepEquityTerms(String regRepProductId, RegRepProduct regRepProduct, Double vegaNotional, Double changeInVegaNotional, String nonStandardFlag, String embeddedOption, String valuationFrequencyPeriod,
            int valuationFrequencyPeriodMultiplier, Date finalValuationDate, Double equityVarianceStrikePrice)
    {
	    super();
	    this.regRepProductId = regRepProductId;
	    this.regRepProduct = regRepProduct;
	    this.vegaNotional = vegaNotional;
	    this.changeInVegaNotional = changeInVegaNotional;
	    this.nonStandardFlag = nonStandardFlag;
	    this.embeddedOption = embeddedOption;
	    this.valuationFrequencyPeriod = valuationFrequencyPeriod;
	    this.valuationFrequencyPeriodMultiplier = valuationFrequencyPeriodMultiplier;
	    this.finalValuationDate = finalValuationDate;
	    this.equityVarianceStrikePrice = equityVarianceStrikePrice;
    }
	
	
	public String getRegRepProductId()
	{
		return regRepProductId;
	}

	public void setRegRepProductId(String regRepProductId)
	{
		this.regRepProductId = regRepProductId;
	}

	public RegRepProduct getRegRepProduct()
	{
		return regRepProduct;
	}
	public void setRegRepProduct(RegRepProduct regRepProduct)
	{
		this.regRepProduct = regRepProduct;
	}
	public Double getVegaNotional()
	{
		return vegaNotional;
	}
	public void setVegaNotional(Double vegaNotional)
	{
		this.vegaNotional = vegaNotional;
	}
	public Double getChangeInVegaNotional()
	{
		return changeInVegaNotional;
	}
	public void setChangeInVegaNotional(Double changeInVegaNotional)
	{
		this.changeInVegaNotional = changeInVegaNotional;
	}
	public String getNonStandardFlag()
	{
		return nonStandardFlag;
	}
	public void setNonStandardFlag(String nonStandardFlag)
	{
		this.nonStandardFlag = nonStandardFlag;
	}
	public String getEmbeddedOption()
	{
		return embeddedOption;
	}
	public void setEmbeddedOption(String embeddedOption)
	{
		this.embeddedOption = embeddedOption;
	}
	public String getValuationFrequencyPeriod()
	{
		return valuationFrequencyPeriod;
	}
	public void setValuationFrequencyPeriod(String valuationFrequencyPeriod)
	{
		this.valuationFrequencyPeriod = valuationFrequencyPeriod;
	}
	public int getValuationFrequencyPeriodMultiplier()
	{
		return valuationFrequencyPeriodMultiplier;
	}
	public void setValuationFrequencyPeriodMultiplier(int valuationFrequencyPeriodMultiplier)
	{
		this.valuationFrequencyPeriodMultiplier = valuationFrequencyPeriodMultiplier;
	}
	public Date getFinalValuationDate()
	{
		return finalValuationDate;
	}
	public void setFinalValuationDate(Date finalValuationDate)
	{
		this.finalValuationDate = finalValuationDate;
	}
	public Double getEquityVarianceStrikePrice()
	{
		return equityVarianceStrikePrice;
	}
	public void setEquityVarianceStrikePrice(Double equityVarianceStrikePrice)
	{
		this.equityVarianceStrikePrice = equityVarianceStrikePrice;
	}

}
