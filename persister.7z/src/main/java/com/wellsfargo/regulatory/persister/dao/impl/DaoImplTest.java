package com.wellsfargo.regulatory.persister.dao.impl;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.dao.RegRepFraDao;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepPayloadDao;
import com.wellsfargo.regulatory.persister.dao.RegRepPeriodDao;
import com.wellsfargo.regulatory.persister.dao.RegRepProductDao;
import com.wellsfargo.regulatory.persister.dao.RegRepTradeDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepPayload;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;

public class DaoImplTest
{

	public static void main(String s[])
	{

		RegRepPayloadDao rrpld;
		RegRepTradeDao rrtd;
		RegRepMessageDao rrmd;
		RegRepFraDao rrfd;
		RegRepProductDao rrpd;
		RegRepPeriodDao rrperiodDao;
		try
		{
			System.out.println("Testing ..");

			ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:META-INF/hibernate-context.xml");
			applicationContext.start();

			// RegRepTrade
			String b1 = "1";

			RegRepTrade rrt = new RegRepTrade();
			rrt.setSwapTradeId("SWAP0023");
			rrt.setTradeUsi("USI00003");
			rrt.setTradeUti("UTI00003");
			rrt.setSrcSystemType("SOURCE003");
			rrt.setIsExpired("N");
			rrt.setTradeLatestVersion(b1);
			rrt.setRegRepTradeTimestamp(new Date());
			rrtd = (RegRepTradeDao) applicationContext.getBean("regRepTradeDao", RegRepTradeDao.class);
			// rrtd.save(rrt);

			// RegRepMessage
			RegRepMessage rrm = new RegRepMessage();
			rrm.setRegRepMessageId("MSGID003");
			rrm.setTradeUsi("USI00003");
			rrm.setTradeUti("UTI00003");
			// rrm.setRegRepMessageId("SRC_MSG_ID3");
			rrm.setLifecycleEventType("AMENDMENT");
			rrm.setActionType("NEW");
			// rrm.setIsReportable("Y");
			rrm.setIsClearedTrade("N");
			rrm.setIsSwapswireTrade("N");
			// rrm.setRegRepTrade(rrt);
			rrm.setRegRepMessageTimestamp(new Date());

			rrmd = (RegRepMessageDao) applicationContext.getBean("regRepMessageDao", RegRepMessageDao.class);

			// rrmd.save(rrm);

			// RegRepPayload
			RegRepPayload rrpl = new RegRepPayload();

			rrpl.setPayload("Just testing 223 .fregfdg.");
			// rrpl.setRegRepMessage(rrm);
			rrpl.setRegRepPayloadId(3L);
			rrpl.setRegRepPayloadTimestamp(new Date());
			rrpld = (RegRepPayloadDao) applicationContext.getBean("regRepPayloadDao", RegRepPayloadDao.class);
			// rrpld.save(rrpl);
			// List<RegRepMessage> l = rrmd.loadRegRepMsgsByUSI( "USI00003");
			// System.out.println("user defined query returns: "+l.size());

			Set<RegRepPayload> rrps = new HashSet<RegRepPayload>();
			rrps.add(rrpl);
			rrpl.setRegRepMessage(rrm);
			rrm.setRegRepPayloads(rrps);
			rrm.setRegRepTrade(rrt);
			Set<RegRepMessage> rrms = new HashSet<RegRepMessage>();
			rrms.add(rrm);
			rrt.setRegRepMessages(rrms);
			rrtd.saveOrUpdate(rrt);
			applicationContext.registerShutdownHook();
		}
		catch (Exception e)
		{
			System.out.println("Error in saving the record..");
			e.printStackTrace();
		}

	}
}
