package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepPartyAttribute;

public interface RegRepPartyAttributeDao extends Dao<RegRepPartyAttribute>, Serializable
{

}
