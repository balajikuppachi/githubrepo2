package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepPayload;
import com.wellsfargo.regulatory.persister.helper.SequenceIdHelper;

public class RegRepPayloadMapper
{
	private static Logger logger = Logger.getLogger(RegRepPayloadMapper.class.getName());

	public RegRepPayload createRegRepPayload(ReportingContext context, RegRepMessage message) throws MessagingException
	{
		logger.debug("Generating a new payload object");

		RegRepPayload payload = new RegRepPayload();
		int id = -1;

	/*	try
		{
			// id = SequenceIdHelper.getMaxSequence("REG_REP_PAYLOAD", "REG_REP_PAYLOAD_ID");

			//id = SequenceIdHelper.getMaxSequence("regRepPayLoadSequence");
		}
		catch (MessagingException e)
		{
			throw new MessagingException("create:payload:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage() + " payload : " + context.getPayload(),
			        message.getRegRepMessageId(), e);
		}
		catch (Exception e)
		{
			throw new MessagingException("create:payload:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage() + " payload : " + context.getPayload(),
			        message.getRegRepMessageId(), e);
		}*/

		payload.setRegRepPayloadTimestamp(new Date());
		payload.setPayload(context.getPayload());
		payload.setType(context.getMessageSource());
		//payload.setRegRepPayloadId(id + 1);
		payload.setRegRepMessage(message);

		logger.debug("Returning the new payload object");
		return payload;
	}

}
