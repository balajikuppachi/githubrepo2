package com.wellsfargo.regulatory.persister.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;
import com.wellsfargo.regulatory.persister.helper.DaoFilters;

public class RegRepMessageDaoImpl extends AbstractDaoImpl<RegRepMessage> implements RegRepMessageDao
{
	private static final long serialVersionUID = -5101765154130610758L;



	@Override
	public Class<RegRepMessage> getEntityClass()
	{
		return RegRepMessage.class;
	}

	/**
	 * Retrieve REG_REP_MESSAGE records based on TRADE_USI_PREFIX and TRADE_USI_VALUE
	 *
	 * @param usiPrefix
	 * @param usiValue
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RegRepMessage> loadRegRepMsgsByUSI(String usi)
	{
		return findByNamedQuery(RegRepMessage.GET_MESSAGES_BY_USI, new Object[]
		{ usi });
	}

	/**
	 * To retrieve REG_REP_MESSAGE records based on SWAP_TRADE_ID
	 *
	 * @param swapTradeId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RegRepMessage> loadRegRepMsgsBySwapTradeId(String swapTradeId)
	{
		return findByNamedQuery(RegRepMessage.GET_MESSAGES_BY_SWAP_TRADEID, new Object[]
		{ swapTradeId });
	}

	/**
	 * To retrieve REG_REP_MESSAGE records based on COUNTERPARTY_LEI
	 *
	 * @param counterPartyLEI
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RegRepMessage> loadRegRepMsgsByCounterPartyLEI(String counterPartyLEI)
	{
		// TODO Auto-generated method stub
		return findByNamedQuery(RegRepMessage.GET_MESSAGES_BY_CTRPARTY_LEI, new Object[]
		{ counterPartyLEI });
	}

	/**
	 * To retrieve REG_REP_MESSAGE records based on External Message Id
	 *
	 * @param externalMsgId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<RegRepMessage> loadRegRepMsgsByExtrnlMsgId(String externalMsgId)
	{
		// TODO Auto-generated method stub
		return findByNamedQuery(RegRepMessage.GET_MESSAGES_BY_EXTERNAL_MSG_ID, new Object[]
		{ externalMsgId });
	}

	@SuppressWarnings("unchecked")
    @Override
    public RegRepMessage findByPrimaryKeyNS(String msgId)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepMessage result = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepMessage.GET_MSG_BY_MSG_ID);
			queryObject.setString("regRepMsgId", msgId);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				for (Object[] obj: objs)
				{
					result = new RegRepMessage();
					result.setRegRepMessageId((String)obj[0]);
					result.setTradeUsi(StringUtils.trimToEmpty((String)obj[1]));
					result.setTradeUti((String)obj[2]);

					if (result.getRegRepTrade() == null )
					{
						RegRepTrade trade = new RegRepTrade();
						trade.setTradeUsi(StringUtils.trimToEmpty((String)obj[1]));
						trade.setTradeUti((String)obj[2]);						
						result.setRegRepTrade(trade);
					}
					
					result.getRegRepTrade().setSwapTradeId((String)obj[3]);
					result.setSwapTradeId((String)obj[3]);

					String srcMsgId = (String)obj[4];
					if (! GeneralUtils.IsNullOrBlank(srcMsgId))
					{
						RegRepMessage srcMsg = findByPrimaryKeyNS(srcMsgId);
						srcMsg.getRegRepMessagesForSrcRegRepMessageId().add(result);
						result.setRegRepMessageBySrcRegRepMessageId(srcMsg);
					}
					
					result.setLifecycleEventType((String)obj[5]);
					result.setActionType((String)obj[6]);
					result.setEntityLei((String)obj[7]);
					result.setCounterpartyLei((String)obj[8]);
					result.setIsClearedTrade((String)obj[9]);
					result.setIsSwapswireTrade((String)obj[10]);
					result.setExternalMessageId((String)obj[11]);
					result.setMessageType((String)obj[12]);
					result.setPrevUsi((String)obj[13]);
					result.setIsReportable((String)obj[14]);
					result.setIsReportingParty((String)obj[15]);
					String parentMsgId = (String)obj[16];
					
					if (! GeneralUtils.IsNullOrBlank(parentMsgId))
					{
						RegRepMessage parentMsg = findByPrimaryKeyNS(parentMsgId);
						parentMsg.getRegRepMessagesForRegRepParentMessageId().add(result);
						result.setRegRepMessageByRegRepParentMessageId(parentMsg);
					}
					
					result.setRegRepMessageTimestamp((Timestamp)obj[17] );
					result.setIsInvalid((String)obj[18]);
					result.setIsFiltered((String)obj[19]);
					result.setTradeExecutionTimestamp((Timestamp)obj[20]);
					result.setAssetClass((String)obj[21]);
					result.setProductType((String)obj[22]);
					result.setProductSubType((String)obj[23]);
					result.setTradeStatus((String)obj[24]);					
				}
			}

		}
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);
			
/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return result;
    }


	@SuppressWarnings("unchecked")
	@Override
    public Set<RegRepMessage> loadRegRepMessagesForSrcMsgId(String msgId)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		Set<RegRepMessage> result = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepMessage.GET_MSGS_FOR_SRC_MSG_ID);
			queryObject.setString("srcMsgId", msgId);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				for (Object[] obj: objs)
				{
					RegRepMessage regRepMsg = new RegRepMessage();
					regRepMsg.setRegRepMessageId((String)obj[0]);
					regRepMsg.setTradeUsi(StringUtils.trimToEmpty((String)obj[1]));
					regRepMsg.setTradeUti((String)obj[2]);

					if (regRepMsg.getRegRepTrade() == null )
					{
						RegRepTrade trade = new RegRepTrade();
						trade.setTradeUsi(StringUtils.trimToEmpty((String)obj[1]));
						trade.setTradeUti((String)obj[2]);
						regRepMsg.setRegRepTrade(trade);
					}
					regRepMsg.getRegRepTrade().setSwapTradeId((String)obj[3]);

					String srcMsgId = (String)obj[4];
					if (! GeneralUtils.IsNullOrBlank(srcMsgId))
					{
						RegRepMessage srcMsg = findByPrimaryKeyNS(srcMsgId);
						regRepMsg.getRegRepMessagesForSrcRegRepMessageId().add(srcMsg);
						srcMsg.setRegRepMessageBySrcRegRepMessageId(regRepMsg);
					}
					
					regRepMsg.setLifecycleEventType((String)obj[5]);
					regRepMsg.setActionType((String)obj[6]);
					regRepMsg.setEntityLei((String)obj[7]);
					regRepMsg.setCounterpartyLei((String)obj[8]);
					regRepMsg.setIsClearedTrade((String)obj[9]);
					regRepMsg.setIsSwapswireTrade((String)obj[10]);
					regRepMsg.setExternalMessageId((String)obj[11]);
					regRepMsg.setMessageType((String)obj[12]);
					regRepMsg.setPrevUsi((String)obj[13]);
					regRepMsg.setIsReportable((String)obj[14]);
					regRepMsg.setIsReportingParty((String)obj[15]);

					String parentMsgId = (String)obj[16];
					if (! GeneralUtils.IsNullOrBlank(parentMsgId)){
						RegRepMessage parentMsg = findByPrimaryKeyNS(parentMsgId);
						regRepMsg.getRegRepMessagesForRegRepParentMessageId().add(parentMsg);
					}
					regRepMsg.setRegRepMessageTimestamp((Timestamp)obj[17] );
					regRepMsg.setIsInvalid((String)obj[18]);
					regRepMsg.setIsFiltered((String)obj[19]);
					regRepMsg.setAssetClass((String)obj[20]);
					regRepMsg.setProductType((String)obj[21]);
					regRepMsg.setProductSubType((String)obj[22]);
					regRepMsg.setTradeStatus((String)obj[23]);					
					
					if (result == null){
						result = new HashSet<RegRepMessage>();
					}
									
					result.add(regRepMsg);
				}
			}

		}
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);

/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return result;
    }
	
	
	@SuppressWarnings("unchecked")
    @Override
    public RegRepMessage findByTradeIdAndReportTypeNS(String tradeId, String reportType, String jurisdiction)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepMessage result = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepMessage.GET_MSGS_FOR_TRADE_ID_AND_REPORT_TYPE);
			queryObject.setString("tradeId", tradeId);
			queryObject.setString("reportType", reportType);
			queryObject.setString("jur", jurisdiction);
			objs = queryObject.list();
			
			for (Object[] obj : objs) 
			{
				if(!GeneralUtils.IsNull(obj) && obj.length>0)
				{
					result = new RegRepMessage();
					result.setRegRepMessageId((String)obj[0]);
					result.setActionType((String)obj[1]);
					result.setLifecycleEventType((String)obj[2]);
					break;
				}	
			}
			
			
			
			
		}catch(Exception e){
			
			logger.error("Error while getting messages using trade id and message type : "+e);
			
		}
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);

/*			if (session!= null ){
				session.flush();
				session.close();
			}
*/		}
		
		return result;
	}
	
	
	@SuppressWarnings("unchecked")
    @Override
    public RegRepMessage findMsgAndTradeByPrimaryKeyNS(String msgId)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepMessage result = null;

		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepMessage.GET_MSG_AND_TRADE_BY_MSG_ID);
			queryObject.setString("regRepMsgId", msgId);
			objs = queryObject.list();

			if (objs!=null && !objs.isEmpty())
			{
				for (Object[] obj: objs)
				{
					result = new RegRepMessage();
					result.setRegRepMessageId((String)obj[0]);
					result.setTradeUsi(StringUtils.trimToEmpty((String)obj[1]));
					result.setTradeUti((String)obj[2]);

					if (result.getRegRepTrade() == null )
					{
						RegRepTrade trade = new RegRepTrade();
						
						trade.setSwapTradeId((String)obj[25]);						
						trade.setTradeUsi(StringUtils.trimToEmpty((String)obj[26]));
						trade.setTradeUti((String)obj[27]);
						trade.setSrcSystemType((String)obj[28]);
						trade.setIsExpired((String)obj[29]);
						trade.setPrevUsi((String)obj[30]);
						trade.setLatestRegRepMessageId((String)obj[31]);
						trade.setTradeFoStatus((String)obj[32]);
						trade.setTradeLatestVersion((String)obj[33]);
						trade.setRegRepTradeTimestamp((Timestamp)obj[34]);
						trade.setRegRepTradeUpdateTimestamp((Timestamp)obj[35]);
						
						result.setRegRepTrade(trade);
					}
					
					//result.getRegRepTrade().setSwapTradeId((String)obj[3]);
					result.setSwapTradeId((String)obj[3]);

					String srcMsgId = (String)obj[4];
					if (! GeneralUtils.IsNullOrBlank(srcMsgId))
					{
						RegRepMessage srcMsg = findByPrimaryKeyNS(srcMsgId);
						srcMsg.getRegRepMessagesForSrcRegRepMessageId().add(result);
						result.setRegRepMessageBySrcRegRepMessageId(srcMsg);
					}
					
					result.setLifecycleEventType((String)obj[5]);
					result.setActionType((String)obj[6]);
					result.setEntityLei((String)obj[7]);
					result.setCounterpartyLei((String)obj[8]);
					result.setIsClearedTrade((String)obj[9]);
					result.setIsSwapswireTrade((String)obj[10]);
					result.setExternalMessageId((String)obj[11]);
					result.setMessageType((String)obj[12]);
					result.setPrevUsi((String)obj[13]);
					result.setIsReportable((String)obj[14]);
					result.setIsReportingParty((String)obj[15]);
					String parentMsgId = (String)obj[16];
					
					if (! GeneralUtils.IsNullOrBlank(parentMsgId))
					{
						RegRepMessage parentMsg = findByPrimaryKeyNS(parentMsgId);
						parentMsg.getRegRepMessagesForRegRepParentMessageId().add(result);
						result.setRegRepMessageByRegRepParentMessageId(parentMsg);
					}
					
					result.setRegRepMessageTimestamp((Timestamp)obj[17] );
					result.setIsInvalid((String)obj[18]);
					result.setIsFiltered((String)obj[19]);
					result.setTradeExecutionTimestamp((Timestamp)obj[20]);
					result.setAssetClass((String)obj[21]);
					result.setProductType((String)obj[22]);
					result.setProductSubType((String)obj[23]);
					result.setTradeStatus((String)obj[24]);					

				}
			}

		}
		finally 
		{
			
			SessionFactoryUtils.closeSession(session);

/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return result;
    }
	
	
	
	@SuppressWarnings({ "unchecked", "deprecation" })
    @Override
    public List<RegRepMessage> findMsgAndTradeBetweenATime(Date startTime, Date endTime)
    {
		Session session = null;
		Query queryObject = null;
		List<Object> queryResults = null;		
		RegRepMessage msg = null;
		List<RegRepMessage> result = null;
		Object[] arrayObject	= null;
		try
		{	
			startTime.setYear(-10);
			session = openSession();
			queryObject = session.getNamedQuery(RegRepMessage.GET_MSG_AND_TRADE_BY_TIME);
			queryObject.setTimestamp("startTime", startTime);
			queryObject.setTimestamp("endTime", endTime);
			queryResults = queryObject.list();

			if (queryResults!=null && !queryResults.isEmpty())
			{
				
				result = new ArrayList<RegRepMessage>(20);
				
				for(Object objs : queryResults){
				
					if(null == objs){						
						continue;
					}else{
						
						arrayObject = (Object[])objs;
						
						if(arrayObject.length < 1){
							continue;
						}
					}				
					
					msg = new RegRepMessage();
					msg.setRegRepMessageId((String)arrayObject[0]);
					msg.setTradeUsi(StringUtils.trimToEmpty((String)arrayObject[1]));
					msg.setTradeUti((String)arrayObject[2]);

					if (msg.getRegRepTrade() == null )
					{
						RegRepTrade trade = new RegRepTrade();
						
						trade.setSwapTradeId((String)arrayObject[25]);						
						trade.setTradeUsi(StringUtils.trimToEmpty((String)arrayObject[26]));
						trade.setTradeUti((String)arrayObject[27]);
						trade.setSrcSystemType((String)arrayObject[28]);
						trade.setIsExpired((String)arrayObject[29]);
						trade.setPrevUsi((String)arrayObject[30]);
						trade.setLatestRegRepMessageId((String)arrayObject[31]);
						trade.setTradeFoStatus((String)arrayObject[32]);
						trade.setTradeLatestVersion((String)arrayObject[33]);
						trade.setRegRepTradeTimestamp((Timestamp)arrayObject[34]);
						trade.setRegRepTradeUpdateTimestamp((Timestamp)arrayObject[35]);
						
						msg.setRegRepTrade(trade);
					}
					msg.getRegRepTrade().setSwapTradeId((String)arrayObject[3]);

					String srcMsgId = (String)arrayObject[4];
					if (! GeneralUtils.IsNullOrBlank(srcMsgId))
					{
						RegRepMessage srcMsg = findByPrimaryKeyNS(srcMsgId);
						srcMsg.getRegRepMessagesForSrcRegRepMessageId().add(msg);
						msg.setRegRepMessageBySrcRegRepMessageId(srcMsg);
					}
					
					msg.setLifecycleEventType((String)arrayObject[5]);
					msg.setActionType((String)arrayObject[6]);
					msg.setEntityLei((String)arrayObject[7]);
					msg.setCounterpartyLei((String)arrayObject[8]);
					msg.setIsClearedTrade((String)arrayObject[9]);
					msg.setIsSwapswireTrade((String)arrayObject[10]);
					msg.setExternalMessageId((String)arrayObject[11]);
					msg.setMessageType((String)arrayObject[12]);
					msg.setPrevUsi((String)arrayObject[13]);
					msg.setIsReportable((String)arrayObject[14]);
					msg.setIsReportingParty((String)arrayObject[15]);
					String parentMsgId = (String)arrayObject[16];
					
					if (! GeneralUtils.IsNullOrBlank(parentMsgId))
					{
						RegRepMessage parentMsg = findByPrimaryKeyNS(parentMsgId);
						parentMsg.getRegRepMessagesForRegRepParentMessageId().add(msg);
						msg.setRegRepMessageByRegRepParentMessageId(parentMsg);
					}
					
					msg.setRegRepMessageTimestamp((Timestamp)arrayObject[17] );
					msg.setIsInvalid((String)arrayObject[18]);
					msg.setIsFiltered((String)arrayObject[19]);
					msg.setTradeExecutionTimestamp((Timestamp)arrayObject[20]);
					msg.setAssetClass((String)arrayObject[21]);
					msg.setProductType((String)arrayObject[22]);
					msg.setProductSubType((String)arrayObject[23]);
					msg.setTradeStatus((String)arrayObject[24]);
					
					result.add(msg);
				}			
				
			}

		}catch(Exception e){
			
			logger.error(e);
			
		}finally 
		{
			
			SessionFactoryUtils.closeSession(session);

/*			if (session!= null )
			{
				session.flush();
				session.clear();
				session.close();
			}
*/		}

		return result;
    }
	
	
	public Function<Criteria, Criteria> filter(Date start, Date end, List<String> assetClasses, List<String> jurisdictions, boolean orderByTimestamp)
	{
		return criteria -> 
		{
			restrict(criteria, start, end);
			DaoFilters.addRestrictionIn(criteria, "regRepSdrRequest", "assetClass", assetClasses);
			DaoFilters.addRestrictionIn(criteria, "regRepMessageRegulatories", "reportingJurisdiction", jurisdictions);
			
			if (orderByTimestamp)
			{
				criteria.addOrder(Order.asc("regRepMessageTimestamp"));
			}
			
			return criteria;
		}; 
	}

	public void restrict(Criteria criteria, Date start, Date end){
		criteria.add(Restrictions.ge("regRepMessageTimestamp", start))
				.add(Restrictions.lt("regRepMessageTimestamp", end))
				.add(Restrictions.ne("messageType", "SDR_NRP_NOTIFICATION"))
				.add(Restrictions.not(Restrictions.like("regRepMessageId", "%:UNCGHT"))) // CJS: TODO: Make this optional?
				.setFetchMode("regRepResponse", FetchMode.JOIN)
				.setFetchMode("regRepReport", FetchMode.JOIN)
				.setFetchMode("regRepMessageRegulatories", FetchMode.JOIN)
				.setFetchMode("regRepParties", FetchMode.JOIN)
				.setFetchMode("regRepExceptions", FetchMode.JOIN)
				.setFetchMode("regRepSdrRequest", FetchMode.JOIN)
				.setFetchMode("regRepPartyAttributes", FetchMode.JOIN)
//				.setFetchMode("id", FetchMode.JOIN)
				.setFetchMode("regRepTradeHeader", FetchMode.JOIN)
				.setFetchMode("regRepRegulatory", FetchMode.JOIN)
				.setFetchMode("regRepConfirmation", FetchMode.JOIN)
				.setFetchMode("regRepTradeDetail", FetchMode.JOIN)
				.setFetchMode("regRepLifecycle", FetchMode.JOIN)
//				.setFetchMode("regRepKeywords", FetchMode.JOIN)
//				.setFetchMode("regRepReportingEligibilities", FetchMode.JOIN)
				.setFetchMode("regRepPayloads", FetchMode.JOIN)
				.setFetchMode("regRepOrigPayload", FetchMode.JOIN)
//				.setFetchMode("regRepMessage", FetchMode.JOIN)
//				.setFetchMode("", FetchMode.JOIN)
//				.setFetchMode("", FetchMode.JOIN)
				;
	}
	
	public void restrict(Criteria criteria, List<String> jurisdictions, List<String> assetClasses)
	{
		DaoFilters.addRestrictionIn(criteria.createCriteria("regRepMessageRegulatories"), "reportingJurisdiction", jurisdictions);
		DaoFilters.addRestrictionIn(criteria.createCriteria("regRepSdrRequestForSrcRegRepMessageId"), "assetClass", assetClasses);
	}
	
	@SuppressWarnings("unchecked")
    @Override
    public List<RegRepMessage> findByTradeIdAndJurisdictionNS(String tradeId, String jurisdiction)
    {
		Session session = null;
		Query queryObject = null;
		List<Object[]> objs = null;
		RegRepMessage result = null;
		List<RegRepMessage> resultList=new ArrayList<RegRepMessage>();
		try
		{
			session = openSession();
			queryObject = session.getNamedQuery(RegRepMessage.GET_MSGS_FOR_TRADE_ID_AND_JURISDICTION);
			queryObject.setString("tradeId", tradeId);
			queryObject.setString("jur", jurisdiction);
			objs = queryObject.list();
	
			for (Object[] obj : objs) 
			{
				if(!GeneralUtils.IsNull(obj) && obj.length>0)
				{
					result = new RegRepMessage();
					result.setRegRepMessageId((String)obj[0]);
					result.setActionType((String)obj[1]);
					result.setLifecycleEventType((String)obj[2]);
					result.setRegRepMessageTimestamp((Timestamp)obj[3]);
					resultList.add(result);
				}	
			}
			
			
		}catch(Exception e){
			
			logger.error("Error while getting messages using trade id and jurisdiction : "+e);
			
		}
		finally 
		{
			SessionFactoryUtils.closeSession(session);
		}
		
		return resultList;
	}


}
