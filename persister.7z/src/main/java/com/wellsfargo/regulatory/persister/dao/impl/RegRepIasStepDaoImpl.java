package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepIasStepDao;
import com.wellsfargo.regulatory.persister.dto.RegRepIasStep;

public class RegRepIasStepDaoImpl extends AbstractDaoImpl<RegRepIasStep> implements RegRepIasStepDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6520113368001089698L;

	@Override
	public Class<RegRepIasStep> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepIasStep.class;
	}

	


}
