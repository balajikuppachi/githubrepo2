package com.wellsfargo.regulatory.persister.rowMapper;

public class RegRepEodRefreshMessage {

	private String messageId;
	
	private String payload;

	private String eodReportId ;
	
	private String reportType;
	
	private String jurisdiction;
	
	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getEodReportId() {
		return eodReportId;
	}

	public void setEodReportId(String eodReportId) {
		this.eodReportId = eodReportId;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	
}
