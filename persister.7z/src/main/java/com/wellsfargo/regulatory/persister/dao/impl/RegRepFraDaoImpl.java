package com.wellsfargo.regulatory.persister.dao.impl;

import com.wellsfargo.regulatory.persister.dao.RegRepFraDao;
import com.wellsfargo.regulatory.persister.dto.RegRepFra;

public class RegRepFraDaoImpl extends AbstractDaoImpl<RegRepFra> implements RegRepFraDao
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5761951754858166218L;

	@Override
	public Class<RegRepFra> getEntityClass()
	{
		// TODO Auto-generated method stub
		return RegRepFra.class;
	}

}
