package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepParty;

public interface RegRepPartyDao extends Dao<RegRepParty>, Serializable
{

}
