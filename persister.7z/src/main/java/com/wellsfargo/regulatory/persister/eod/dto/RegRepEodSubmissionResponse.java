package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class RegRepEodSubmissionResponse implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private long responseId;
	private long submissionId;
	private String sdrResponse;
	private String status;
	private String sentBy;
	private String sentTo;
	private Timestamp creationTimeStamp;
	private Timestamp insertTimeStamp;
	
	
	public long getResponseId()
	{
		return responseId;
	}
	public void setResponseId(long responseId)
	{
		this.responseId = responseId;
	}
	public long getSubmissionId()
	{
		return submissionId;
	}
	public void setSubmissionId(long submissionId)
	{
		this.submissionId = submissionId;
	}
	public String getSdrResponse()
	{
		return sdrResponse;
	}
	public void setSdrResponse(String sdrResponse)
	{
		this.sdrResponse = sdrResponse;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public String getSentBy()
	{
		return sentBy;
	}
	public void setSentBy(String sentBy)
	{
		this.sentBy = sentBy;
	}
	public String getSentTo()
	{
		return sentTo;
	}
	public void setSentTo(String sentTo)
	{
		this.sentTo = sentTo;
	}
	public Timestamp getCreationTimeStamp()
	{
		return creationTimeStamp;
	}
	public void setCreationTimeStamp(Timestamp creationTimeStamp)
	{
		this.creationTimeStamp = creationTimeStamp;
	}
	public Timestamp getInsertTimeStamp()
	{
		return insertTimeStamp;
	}
	public void setInsertTimeStamp(Timestamp insertTimeStamp)
	{
		this.insertTimeStamp = insertTimeStamp;
	}
	
	

}
