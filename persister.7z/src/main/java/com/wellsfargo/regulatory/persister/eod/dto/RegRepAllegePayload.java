package com.wellsfargo.regulatory.persister.eod.dto;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class RegRepAllegePayload implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private long payloadId;
	private long allegeMessageId;
	private String payloadType;
	private String payload;
	private Timestamp  createDatetime;
	
	
	public long getPayloadId()
	{
		return payloadId;
	}
	public void setPayloadId(long payloadId)
	{
		this.payloadId = payloadId;
	}
	public long getAllegeMessageId()
	{
		return allegeMessageId;
	}
	public void setAllegeMessageId(long allegeMessageId)
	{
		this.allegeMessageId = allegeMessageId;
	}
	public String getPayloadType()
	{
		return payloadType;
	}
	public void setPayloadType(String payloadType)
	{
		this.payloadType = payloadType;
	}
	public String getPayload()
	{
		return payload;
	}
	public void setPayload(String payload)
	{
		this.payload = payload;
	}
	public Timestamp getCreateDatetime()
	{
		return createDatetime;
	}
	public void setCreateDatetime(Timestamp createDatetime)
	{
		this.createDatetime = createDatetime;
	}

}
