package com.wellsfargo.regulatory.persister.etd.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
/**
 * 
 * @author Raji Komatreddy
 *
 */
public class EtdTradeBatchOutputExtnDao
{

	private JdbcTemplate jdbcTemplate;

	public EtdTradeBatchOutputExtnDao(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public Long findFeedIdInRange(Long from, Long to)
	{
		List<Long> maxIdList = jdbcTemplate.queryForList("select  MAX(batch_id)  from ETD_TRADE_BATCH_OUTPUT WHERE batch_id >= ? and batch_id <= ?", Long.class, from, to);

		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null)
		{
			return null;
		}
		else
		{
			return maxIdList.get(0);
		}
	}

}
