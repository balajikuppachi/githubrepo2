package com.wellsfargo.regulatory.persister.trioptima.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityUnderlyingAssetType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;

public class RegRepReconEQMapper {
	
	public RegRepTrioptima mapEQrows(ReportingContext context,TradeDetailType tradeDetail, ProductType product,RegRepTrioptima regRepTrioptima,
			String template)
	{
		
		BuySellEnum buyorSell 	= tradeDetail.getProduct().getBuySell();
		String isoCurrency 		= null;
		String notionalCurr		= null;
		
		ArrayList<String> array1 = new ArrayList<String>();
		ArrayList<String> array2 = new ArrayList<String>();
		List<EquityUnderlyingAssetType> equityUnderlyingAsset = tradeDetail.getProduct().getEquityTerms().getUnderlyingAsset();
		
		if(!GeneralUtils.IsNull(equityUnderlyingAsset) && !equityUnderlyingAsset.isEmpty())
		{	
			notionalCurr= equityUnderlyingAsset.get(0).getNotionalCurrency();
		}
		
		{
			if(!tradeDetail.getTradeParties().getParty().isEmpty())
			{
				regRepTrioptima.setCptyId(tradeDetail.getTradeParties().getParty().get(0).getPartyName());
			}
			if(regRepTrioptima.getExecutionVenue().contains(":OFF_FACILITY"))
			{
				regRepTrioptima.setExecutionVenue(":OffFacility");
			}
			
			if(buyorSell.value().equalsIgnoreCase(Constants.BUY)) 
			{
				regRepTrioptima.setBuyer(regRepTrioptima.getTradeParty1());
				regRepTrioptima.setSeller(regRepTrioptima.getTradeParty2());
			}
			else 
			{
				regRepTrioptima.setBuyer(regRepTrioptima.getTradeParty2());
				regRepTrioptima.setSeller(regRepTrioptima.getTradeParty1());
			}
			if(!GeneralUtils.IsNullOrBlank(template))
			{		
				if(template.contains(Constants.VARIANCE)) 
				{
					BigDecimal notional = tradeDetail.getProduct().getEquityTerms().getVegaNotional();
					regRepTrioptima.setNotionalAmountLeg1(notional);
					
					if(!GeneralUtils.IsNull(notionalCurr))
					{
						isoCurrency 	= StringUtils.join(new String[] {Constants.ISO_CURRENCY_EXCEPTION,notionalCurr },Constants.UNDERSCORE);
						isoCurrency 	= getDomain(isoCurrency);
							
						if(!GeneralUtils.IsNullOrBlank(isoCurrency))
							regRepTrioptima.setNotionalCurrencyLeg1(isoCurrency);
						else 
							regRepTrioptima.setNotionalCurrencyLeg1(notionalCurr);
					}
						
					
					regRepTrioptima.setStrikePrice(tradeDetail.getProduct().getEquityTerms().getEquityVarianceStrikePrice());
					
					//STR-506
					
					if(null != tradeDetail.getProduct().getEquityTerms())
					{
						regRepTrioptima.setUpfrontFee(null != tradeDetail.getProduct().getEquityTerms().getEquityVarianceStrikePrice() ? tradeDetail.getProduct().getEquityTerms().getEquityVarianceStrikePrice().toString() : null);
						regRepTrioptima.setUpfrontFeeCurr(null != tradeDetail.getProduct().getEquityTerms().getEquityVarianceStrikePrice() ? tradeDetail.getProduct().getEquityTerms().getEquityVarianceStrikePrice().toString() : null);
					}
				}
				
				//STR-506
				if(template.contains(Constants.EqTemplate_OPT)) 
				{
					if(null != tradeDetail.getFeeInfo())
					{
						if(null != tradeDetail.getFeeInfo().getFee() && !tradeDetail.getFeeInfo().getFee().isEmpty()){
							
							FeeType feeType = tradeDetail.getFeeInfo().getFee().get(0);
							
							if(null != feeType){
								regRepTrioptima.setUpfrontFee(null != feeType.getAmount() ? feeType.getAmount().toString() : null);
								regRepTrioptima.setUpfrontFeeCurr(feeType.getCurrency());
							}
						}
					}
				}
				
				//STR-506
				if(template.contains(Constants.EqTemplate_StructuredProduct)) 
				{
					if(null != tradeDetail.getFeeInfo())
					{
						if(null != tradeDetail.getFeeInfo().getFee() && !tradeDetail.getFeeInfo().getFee().isEmpty()){
						
							FeeType feeType = tradeDetail.getFeeInfo().getFee().get(0);
							
							if(null != feeType && (null != feeType.getType() && feeType.getType().equalsIgnoreCase(Constants.FeeType_Premium)))
							{
								regRepTrioptima.setUpfrontFee(null != feeType.getAmount() ? feeType.getAmount().toString() : null);
								regRepTrioptima.setUpfrontFeeCurr(feeType.getCurrency());
							}
						}
					}
				}
				
				if(template.contains(Constants.CFD)) 
				{
					if(!GeneralUtils.IsNull(equityUnderlyingAsset) && !equityUnderlyingAsset.isEmpty())
					{
						regRepTrioptima.setUnderlyingAssetNumberOfUnits(equityUnderlyingAsset.get(0).getNumberOfUnits());
					}
					if(!GeneralUtils.IsNull(product.getLeg() ) && !product.getLeg().isEmpty())
					{
						regRepTrioptima.setEffectiveDate(CalendarUtils.xmlGregCalToCustomFormat(product.getLeg().get(0).getStartDate(), null));
					}
				}
				{
					regRepTrioptima.setTerminationDateLeg1(CalendarUtils.xmlGregCalToCustomFormat(tradeDetail.getProduct().getEquityTerms().getFinalValuationDate(), null));
				}
				if(GeneralUtils.IsNull(regRepTrioptima.getTerminationDateLeg1()) && !GeneralUtils.IsNull(tradeDetail.getProduct().getExerciseProvision()))
				{
					regRepTrioptima.setTerminationDateLeg1(CalendarUtils.xmlGregCalToCustomFormat(tradeDetail.getProduct().getExerciseProvision().getExpirationDate(), null));
				}
				if(GeneralUtils.IsNull(regRepTrioptima.getTerminationDateLeg1()) && !GeneralUtils.IsNull(product.getLeg()) && !product.getLeg().isEmpty())
				{
					if(!GeneralUtils.IsNull(product.getLeg().get(0).getEndDate()))
						{
							regRepTrioptima.setTerminationDateLeg1(CalendarUtils.xmlGregCalToCustomFormat(product.getLeg().get(0).getEndDate(), null));
						}
				}
			}
			
			if (!GeneralUtils.IsNull(equityUnderlyingAsset)) {
				for (int i = 0; i < equityUnderlyingAsset.size(); i++)
				{
					String instrumentID1 = null;
					String instrumentID2 = null;
					
					instrumentID1 = equityUnderlyingAsset.get(i).getInstrumentId();
					array1.add(instrumentID1);
					
					instrumentID2 = equityUnderlyingAsset.get(i).getInstrumentIdType();
					if(Constants.BASKET.equalsIgnoreCase(instrumentID2))
					{
						instrumentID2 = toProperCase(instrumentID2);
					}
					if(Constants.SHARE.equalsIgnoreCase(instrumentID2) ||Constants.INDEX_UPPERCASE.equalsIgnoreCase(instrumentID2))
						instrumentID2="RIC";
					
					array2.add(instrumentID2);
				}
			}
		
			if(!GeneralUtils.IsNull(array1))
			{
				regRepTrioptima.setUnderlyingAsset(convertListToDelimitedString(array1, Constants.SEMICOLON));
				
			}
			if(!GeneralUtils.IsNull(array2))
			{
				regRepTrioptima.setUnderlyingAssetIdentifierType(convertListToDelimitedString(array2, Constants.SEMICOLON));
				
			}
			
			}	

		return regRepTrioptima;
	}
	public String getDomain(String domain) {
		String domainRet = null;
		DomainMappingCache cache = DomainMappingCache.getInstance();
		domainRet = cache.getValue(domain);
		if (!GeneralUtils.IsNull(domainRet)) 
		{
			return domainRet;
		} 
		else
			return null;
	}
	public static String convertListToDelimitedString(List<String> coll, String delim) {
		if (GeneralUtils.IsNull(coll)) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		Iterator<String> it = coll.iterator();
		String value = null;
		while (it.hasNext()) {
			
			value = it.next();
			if(value == null || "null".equalsIgnoreCase(value))
				continue;
			
			sb.append(value);
			if (it.hasNext()) {
				sb.append(delim);
			}
		}
		return sb.toString();
	}
	private String toProperCase(String s) {
	    return s.substring(0, 1).toUpperCase() +
	               s.substring(1).toLowerCase();
	}
}
