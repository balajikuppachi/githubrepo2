package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepKeyword;
import com.wellsfargo.regulatory.persister.dto.RegRepRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepReportingEligibility;
import com.wellsfargo.regulatory.persister.dto.RegRepReportingEligibilityId;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepRegulatoryMapper
{

	private static Logger logger = Logger.getLogger(RegRepRegulatoryMapper.class.getName());

	public RegRepRegulatory createRegRepRegulatory(RegulatoryType ipRegulatory, RegRepSdrRequest regRepSdrRequest)
	{

		RegRepRegulatory regulatory = null;
		RegRepKeywordMapper keyMapper = null;
		KeywordsType ipKeys = null;
		RegRepKeyword dbKey = null;
		Set<RegRepKeyword> keywordSet = null;
		Set<RegRepReportingEligibility> repElgSet = null;
		RegRepReportingEligibility dbRepElg = null;
		List<ReportingEligibilityType> ipRepElgs = null;
		int elgId = 1;

		if (null == regRepSdrRequest || null == ipRegulatory)
		{
			logger.debug("RegRepRegulatory object could not be " + "populated due to invalid incoming data");
			return regulatory;
		}

		regulatory = new RegRepRegulatory();
		regulatory.setRegRepSdrRequest(regRepSdrRequest);

		/*
		 * @Comment : Amit Rana Need not be set, else hibernate creates a duplicate object
		 * regulatory.setRegRepMessageId(regRepSdrRequest.getRegRepMessage().getRegRepMessageId());
		 */

		ipKeys = ipRegulatory.getKeywords();
		if (null != ipKeys)
		{

			keyMapper = new RegRepKeywordMapper();
			keywordSet = new HashSet<RegRepKeyword>();

			for (Keyword ipKey : ipKeys.getKeyword())
			{

				dbKey = keyMapper.createRegRepKeyword(null, regulatory, null, ipKey);
				keywordSet.add(dbKey);
			}
		}
		else
		{
			logger.debug("Unable to persist Regulatory keys, " + "since incoming data doesn't have keys populated");
		}

		ipRepElgs = ipRegulatory.getReportingEligibility();
		if (null != ipRepElgs)
		{

			repElgSet = new HashSet<RegRepReportingEligibility>();

			for (ReportingEligibilityType ipEligibility : ipRepElgs)
			{
				dbRepElg = createRegRepReportingEligibility(regulatory, ipEligibility, elgId++);
				repElgSet.add(dbRepElg);
			}
		}
		else
		{
			logger.debug("Unable to persist reporting eligibilities, " + "since incoming data doesn't have reporting eligibilities populated");
		}

		regulatory.setBonafideHedgeExemption(ipRegulatory.getBonafideHedgeExemption());

		if (null != ipRegulatory.getCollateralizationType()) 
			regulatory.setCollateralizationType(ipRegulatory.getCollateralizationType().value());

		regulatory.setExtraLegalLanguage(ipRegulatory.getExtraLegalLanguage());

		if (null != ipRegulatory.getFeeReportingParty()) regulatory.setFeeReportingParty(ipRegulatory.getFeeReportingParty().value());

		regulatory.setFeeUsi(ipRegulatory.getFeeUSI());
		regulatory.setFirstReportedSdr(ipRegulatory.getFirstReportedSDR());
		regulatory.setHistoricalSwap(ConversionUtils.booleanToDbString(ipRegulatory.isHistoricalSwap()));
		regulatory.setMixedSwapSdr(ipRegulatory.getMixedSwapSDR());
		regulatory.setRegRepKeywords(keywordSet);
		regulatory.setRegRepReportingEligibilities(repElgSet);
		regulatory.setSwapPurpose(ipRegulatory.getSwapPurpose());
		regulatory.setVoluntaryReporting(ConversionUtils.booleanToDbString(ipRegulatory.isVoluntaryReporting()));

		logger.debug("Successfully created REG_REP_REGULATORY object");
		return regulatory;
	}

	private RegRepReportingEligibility createRegRepReportingEligibility(RegRepRegulatory dbRegulatory, ReportingEligibilityType ipEligibility, int id)
	{

		RegRepReportingEligibility dbEligibility = null;
		RegRepReportingEligibilityId dbEligibilityId = null;

		if (null == dbRegulatory || null == ipEligibility)
		{
			logger.debug("RegRepReportingEligibility object could not be " + "populated due to invalid incoming data");
			return dbEligibility;
		}

		dbEligibility = new RegRepReportingEligibility();
		dbEligibility.setRegRepRegulatory(dbRegulatory);

		dbEligibilityId = createRegRepReportingEligibilityId(dbEligibility, id);

		dbEligibility.setDelegatedReporting(ipEligibility.getDelegatedReporting());
		dbEligibility.setId(dbEligibilityId);

		if (null != ipEligibility.getReportingJurisdiction()) dbEligibility.setReportingJurisdiction(ipEligibility.getReportingJurisdiction().value());

		if (null != ipEligibility.getReportingParty()) 
			dbEligibility.setReportingParty(ipEligibility.getReportingParty().value());
		else
			dbEligibility.setReportingParty(Constants.NOT_AVAILABLE);
		
		if (null != ipEligibility.getRepository()) dbEligibility.setRepository(ipEligibility.getRepository().value());

		dbEligibility.setSubJurisdiction(ipEligibility.getSubJurisdictions());

		logger.debug("Successfully created REG_REP_REGULATORY_ELIGIBILITY object");
		return dbEligibility;
	}

	private RegRepReportingEligibilityId createRegRepReportingEligibilityId(RegRepReportingEligibility dbRepElg, int id)
	{

		RegRepReportingEligibilityId elgId = null;

		if (null == dbRepElg)
		{
			logger.debug("RegRepReportingEligibilityId object could not be " + "populated due to invalid incoming data");
			return elgId;
		}

		elgId = new RegRepReportingEligibilityId();

		elgId.setRegRepMessageId(dbRepElg.getRegRepRegulatory().getRegRepSdrRequest().getRegRepMessage().getRegRepMessageId());
		elgId.setRegRepReportingEligibilityId(id);

		logger.debug("Successfully created REG_REP_REGULATORY_ID object");
		return elgId;
	}

}
