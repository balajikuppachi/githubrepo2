package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepReconTrioptima;

public interface RegRepReconTrioptimaDao extends Dao<RegRepReconTrioptima> ,Serializable 
{
	public RegRepReconTrioptima findByPrimaryKeyNS(String msgId);
}
