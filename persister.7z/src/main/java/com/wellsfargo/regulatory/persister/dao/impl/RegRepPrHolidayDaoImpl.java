package com.wellsfargo.regulatory.persister.dao.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.wellsfargo.regulatory.persister.dao.RegRepPrHolidayDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPrHoliday;

public class RegRepPrHolidayDaoImpl extends AbstractDaoImpl<RegRepPrHoliday> implements RegRepPrHolidayDao {

	private static final long serialVersionUID = 4806208231160083034L;

	@Override
	public Class<RegRepPrHoliday> getEntityClass()
	{
		return RegRepPrHoliday.class;
	}

    public List<RegRepPrHoliday> findDate(Date date) {
		// TODO Auto-generated method stub
		java.sql.Date convertedDate = null;
		String convertedString=null;
		List<RegRepPrHoliday> holidayList =null;
		if(null != date){
			DateFormat  dateFormat = new SimpleDateFormat("yyyy-MM-dd");			 
			convertedString =dateFormat.format(date);
			 java.util.Date parsedUtilDate;
			try {
				parsedUtilDate = dateFormat.parse(convertedString);
				convertedDate= new java.sql.Date(parsedUtilDate.getTime());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 holidayList=findByNamedQuery(RegRepPrHoliday.GET_DATE, new Object[]
				{ convertedDate });
		 
		 return holidayList;
	}

}
