package com.wellsfargo.regulatory.persister.etd.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dao.Dao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;

public interface EtdTradeJurisdictionDao extends Serializable, Dao<EtdTradeJurisdiction>
{

}
