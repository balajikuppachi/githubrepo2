package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepClearing;

public interface RegRepClearingDao extends Serializable, Dao<RegRepClearing>
{

}
