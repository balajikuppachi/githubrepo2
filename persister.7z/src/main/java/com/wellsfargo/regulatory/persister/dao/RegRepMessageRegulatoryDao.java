package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.regulatory.persister.dto.RegRepMessageRegulatory;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;

public interface RegRepMessageRegulatoryDao extends Serializable, Dao<RegRepMessageRegulatory>
{

	List<RegRepMessageRegulatory> findByMessageId(String msgId);

	List<RegRepMessageRegulatory> loadRegulatoryByMsgId(List<String> msgIds);
}
