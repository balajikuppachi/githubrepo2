package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepDomainValues;

public interface RegRepDomainValuesDao extends Serializable, Dao<RegRepDomainValues>
{

}
