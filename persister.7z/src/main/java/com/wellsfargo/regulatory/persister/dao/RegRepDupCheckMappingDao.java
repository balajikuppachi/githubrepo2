package com.wellsfargo.regulatory.persister.dao;

import java.io.Serializable;

import com.wellsfargo.regulatory.persister.dto.RegRepDupCheckMapping;

public interface RegRepDupCheckMappingDao  extends Serializable, Dao<RegRepDupCheckMapping>{

}
