package com.wellsfargo.regulatory.persister.helper.mapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepCashFlowSet;
import com.wellsfargo.regulatory.persister.dto.RegRepLeg;
import com.wellsfargo.regulatory.persister.dto.RegRepLegId;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public class RegRepLegMapper
{

	private static Logger logger = Logger.getLogger(RegRepProductMapper.class.getName());

	public RegRepLeg createRegRepLeg(LegType ipLeg, RegRepProduct dbproduct, int id)
	{

		RegRepLeg dbLeg = null;
		Set<RegRepCashFlowSet> dbCshFlowSet = null;
		List<CashFlowType.CashFlow> ipCshFlowSet = null;
		RegRepCashFlowMapper cshFlowMapper = null;
		RegRepCashFlowSet dbCshFlow = null;
		RegRepLegId dbLegId = null;
		int cshFlowId = 1;

		if (null == ipLeg || null == dbproduct)
		{
			logger.debug("RegRepLeg object could not be " + "populated due to invalid incoming data");
			return dbLeg;
		}

		dbLeg = new RegRepLeg();
		dbLeg.setRegRepProduct(dbproduct);

		dbLegId = createRegRepLegId(dbLeg, id);
		dbLeg.setId(dbLegId);

		if (null != ipLeg.getCashFlowSet())
		{
			ipCshFlowSet = ipLeg.getCashFlowSet().getCashFlow();
		}
		if (null != ipCshFlowSet)
		{

			dbCshFlowSet = new HashSet<RegRepCashFlowSet>();
			cshFlowMapper = new RegRepCashFlowMapper();

			for (CashFlowType.CashFlow cashFlow : ipCshFlowSet)
			{
				dbCshFlow = cshFlowMapper.createCashFlowSet(cashFlow, dbLeg, cshFlowId++);
				dbCshFlowSet.add(dbCshFlow);
			}
		}
		else
		{
			logger.debug("Unable to persist cash flow, " + "since incoming data doesn't have Cash Flow populated");
		}

		dbLeg.setAmortizationFrequency(ipLeg.getAmortizationFrequency());
		dbLeg.setAmortizationType(ipLeg.getAmortizationType());
		dbLeg.setAutoExercise(ConversionUtils.booleanToDbString(ipLeg.isAutoExercise()));

		if (null != ipLeg.getAveragingMethod()) dbLeg.setAveragingMethod(ipLeg.getAveragingMethod().value());

		if (null != ipLeg.getBusinessDayConvention()) dbLeg.setBusinessDayConvention(ipLeg.getBusinessDayConvention().value());

		if (null != ipLeg.getCompoundingMethod()) dbLeg.setCompoundingMethod(ipLeg.getCompoundingMethod().value());

		dbLeg.setCurrency(ipLeg.getDayCountFraction());
		dbLeg.setDayCountFraction(ipLeg.getDayCountFraction());

		if (null != ipLeg.getEmbeddedOptionType()) dbLeg.setEmbeddedOptionType(ipLeg.getEmbeddedOptionType().value());

		dbLeg.setEndDate(CalendarUtils.toDate(ipLeg.getEndDate()));
		dbLeg.setExercisedDate(CalendarUtils.toDate(ipLeg.getExercisedDate()));
		dbLeg.setFirstPaymentDate(CalendarUtils.toDate(ipLeg.getFirstPaymentDate()));

		if (null != ipLeg.getFixedFloat()) dbLeg.setFixedFloat(ipLeg.getFixedFloat().value());

		dbLeg.setFixedRate(ConversionUtils.bigDecimalToDouble(ipLeg.getFixedRate()));

		if (null != ipLeg.getFraDiscounting()) dbLeg.setFraDiscounting(ipLeg.getFraDiscounting().value());
		dbLeg.setIndexCurrency(ipLeg.getIndexCurrency());
		dbLeg.setIndexFactor("" + ipLeg.getIndexFactor());
		dbLeg.setIndexName(ipLeg.getIndexName());
		dbLeg.setIndexSource(ipLeg.getIndexSource());
		dbLeg.setIndexTenor(ipLeg.getIndexTenor());
		dbLeg.setInitialInflationRate((ConversionUtils.bigDecimalToDouble(ipLeg.getInitialInflationRate())));
		dbLeg.setInterpIndexTenor(ipLeg.getInterpIndexTenor());

		if (null != ipLeg.getInterpolationMethod()) dbLeg.setInterpolationMethod(ipLeg.getInterpolationMethod().value());

		if (null != ipLeg.getMaximumNotional()) dbLeg.setMaximumNotional(ConversionUtils.bigDecimalToDouble(ipLeg.getMaximumNotional()));
		if (null != ipLeg.getMinimumNotional()) dbLeg.setMinNotional(ConversionUtils.bigDecimalToDouble(ipLeg.getMinimumNotional()));
		dbLeg.setMultipleExercise(ConversionUtils.booleanToDbString(ipLeg.isMultipleExercise()));

		if (null != ipLeg.getNotional()) dbLeg.setNotional(ConversionUtils.bigDecimalToDouble(ipLeg.getNotional()));

		dbLeg.setNotionalCurrency(ipLeg.getNotionalCurrency());
		dbLeg.setOptionStrike(ConversionUtils.bigDecimalToDouble(ipLeg.getOptionStrike()));

		if (null != ipLeg.getOptionType()) dbLeg.setOptionType(ipLeg.getOptionType().value());

		dbLeg.setPartialExercise(ConversionUtils.booleanToDbString(ipLeg.isPartialExercise()));

		if (null != ipLeg.getPaymentDateOffset()) dbLeg.setPaymentDateOffset(ipLeg.getPaymentDateOffset());

		if (null != ipLeg.getPaymentDateOffsetDayType()) dbLeg.setPaymentDateOffsetDayType(ipLeg.getPaymentDateOffsetDayType().value());

		if (null != ipLeg.getPaymentFrequency()) dbLeg.setPaymentFrequency(ipLeg.getPaymentFrequency());

		if (null != ipLeg.getPaymentFrom()) dbLeg.setPaymentFrom(ipLeg.getPaymentFrom());

		if (null != ipLeg.getPaymentHolidays()) dbLeg.setPaymentHolidays(ipLeg.getPaymentHolidays());

		if (null != ipLeg.getPayReceive()) dbLeg.setPayRecieve(ipLeg.getPayReceive().value());

		if (null != ipLeg.getPayRelativeTo()) dbLeg.setPayRelativeTo(ipLeg.getPayRelativeTo().value());

		if (null != ipLeg.getPrice()) dbLeg.setPrice(ConversionUtils.bigDecimalToDouble(ipLeg.getPrice()));

		dbLeg.setPriceCurrency(ipLeg.getPriceCurrency());
		dbLeg.setPriceUnit(ipLeg.getPriceUnit());

		if (null != ipLeg.getQuantityFrequency()) dbLeg.setQuantityFrequency(ipLeg.getQuantityFrequency().value());

		dbLeg.setQuantityUnit(ipLeg.getQuantityUnit());
		dbLeg.setRegRepCashFlowSets(dbCshFlowSet);

		if (null != ipLeg.getResetOffsetDayType()) dbLeg.setResetOffsetDayType(ipLeg.getResetOffsetDayType().value());

		if (null != ipLeg.getResetType()) dbLeg.setResetType(ipLeg.getResetType());

		if (null != ipLeg.getRollConvention()) dbLeg.setRollConvention(ipLeg.getRollConvention());

		if (null != ipLeg.getRoundingDirection()) dbLeg.setRoundingDirection(ipLeg.getRoundingDirection());

		if (null != ipLeg.getRoundingPrecision()) dbLeg.setRoundingPrecision((int) ipLeg.getRoundingPrecision());

		if (null != ipLeg.getSettlementCurrency()) dbLeg.setSettlementCurrency(ipLeg.getSettlementCurrency());
		if (null != ipLeg.getSettlementDate()) dbLeg.setSettlementDate(CalendarUtils.toDate(ipLeg.getSettlementDate()));

		if (null != ipLeg.getSettlementFrequency()) dbLeg.setSettlementFrequency(ipLeg.getSettlementFrequency().value());

		if (null != ipLeg.getSettlementType()) dbLeg.setSettlementType(ipLeg.getSettlementType().value());

		if (null != ipLeg.getSpread()) dbLeg.setSpread(ConversionUtils.bigDecimalToDouble(ipLeg.getSpread()));

		if (null != ipLeg.getStartDate()) dbLeg.setStartDate(CalendarUtils.toDate(ipLeg.getStartDate()));

		if (null != ipLeg.getStubPeriodType()) dbLeg.setStubPeriodType(ipLeg.getStubPeriodType().value());

		dbLeg.setSwaptionStraddle(ConversionUtils.booleanToDbString(ipLeg.isSwaptionStraddle()));
		if (null != ipLeg.getTotalQuantity()) dbLeg.setTotalQuantity(ConversionUtils.bigDecimalToDouble(ipLeg.getTotalQuantity()));
		
		dbLeg.setPricingCalendar(ipLeg.getPricingCalendar());
		dbLeg.setResetFrequency(ipLeg.getResetFrequency());

		return dbLeg;
	}

	private RegRepLegId createRegRepLegId(RegRepLeg dbLeg, int id)
	{

		RegRepLegId legId = null;

		if (null == dbLeg)
		{
			logger.debug("RegRepLegId object could not be " + "populated due to invalid incoming data");
			return legId;
		}

		legId = new RegRepLegId();
		legId.setRegRepLegId(id);
		legId.setRegRepProductId(dbLeg.getRegRepProduct().getRegRepProductId());

		return legId;
	}
}
