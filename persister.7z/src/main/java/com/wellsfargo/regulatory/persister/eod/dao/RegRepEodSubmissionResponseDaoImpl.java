package com.wellsfargo.regulatory.persister.eod.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodSubmissionResponse;

/**
 * @author Raji Komatreddy DAO implementation to insert and update EodSubmissionResponse table
 */
@Component
public class RegRepEodSubmissionResponseDaoImpl implements RowMapper<RegRepEodSubmissionResponse>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	String insertQuery = "INSERT INTO REG_REP_EOD_SUBMISSION_RESPONSE (SUBMISSION_ID, SDR_RESPONSE, STATUS, SENT_BY,"
	        + "  SEND_TO, CREATION_TIMESTAMP, INSERT_TIMESTAMP) VALUES (?, ?, ?, ?, ?, ?, ?) ";

	@Override
	public RegRepEodSubmissionResponse mapRow(ResultSet arg0, int arg1) throws SQLException
	{
		RegRepEodSubmissionResponse currRegRepEodSubmissionResponse = new RegRepEodSubmissionResponse();

		return currRegRepEodSubmissionResponse;
	}

	public boolean insertRegRepEodSubmissionResponse(RegRepEodSubmissionResponse response)
	{
		boolean successful = false;
		jdbcTemplate.update(insertQuery, new Object[] {response.getSubmissionId(), response.getSdrResponse(), response.getStatus(),
				response.getSentBy(), response.getSentTo(), response.getCreationTimeStamp(), response.getInsertTimeStamp()});

		successful = true;
		return successful;
	}

}
