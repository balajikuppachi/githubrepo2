package com.wellsfargo.regulatory.persister;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.junit.Before;
import org.junit.Test;

import com.wellsfargo.regulatory.persister.dao.RegRepRegulatoryDao;
import com.wellsfargo.regulatory.persister.dto.RegRepRegulatory;

public class RegRepRegulatoryDaoImplTest {
private Mockery context = new Mockery();
	
	RegRepRegulatoryDao dao ;
	@Before
	public void SetUp(){
		 dao =	context.mock(RegRepRegulatoryDao.class);
	}
	
	@Test
	public void findByPrimaryKey(){
		final RegRepRegulatory obj = new RegRepRegulatory();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).findByPrimaryKey(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.findByPrimaryKey("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void load(){
		final RegRepRegulatory obj = new RegRepRegulatory();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).load(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.load("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void save(){
		final RegRepRegulatory obj = new RegRepRegulatory();
	
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).save(with(any(RegRepRegulatory.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.save(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void saveOrUpdate(){
		final RegRepRegulatory obj = new RegRepRegulatory();
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).saveOrUpdate(with(any(RegRepRegulatory.class)));
			inSequence(s);
		}});
		dao.saveOrUpdate(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void delete(){
		final Sequence s = context.sequence("seq");
		final RegRepRegulatory obj = new RegRepRegulatory();
		context.checking( new Expectations(){{
			oneOf(dao).delete(with(any(RegRepRegulatory.class)));
			inSequence(s);
		}});
		dao.delete(obj);
		context.assertIsSatisfied();
	}
	
}
