package com.wellsfargo.regulatory.persister;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.junit.Before;
import org.junit.Test;

import com.wellsfargo.regulatory.persister.dao.RegRepSdrRequestDao;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;

public class RegRepSdrRequestDaoImplTest {
private Mockery context = new Mockery();
	
	RegRepSdrRequestDao dao ;
	@Before
	public void SetUp(){
		 dao =	context.mock(RegRepSdrRequestDao.class);
	}
	
	@Test
	public void findByPrimaryKey(){
		final RegRepSdrRequest obj = new RegRepSdrRequest();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).findByPrimaryKey(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.findByPrimaryKey("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void load(){
		final RegRepSdrRequest obj = new RegRepSdrRequest();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).load(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.load("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void save(){
		final RegRepSdrRequest obj = new RegRepSdrRequest();
	
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).save(with(any(RegRepSdrRequest.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.save(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void saveOrUpdate(){
		final RegRepSdrRequest obj = new RegRepSdrRequest();
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).saveOrUpdate(with(any(RegRepSdrRequest.class)));
			inSequence(s);
		}});
		dao.saveOrUpdate(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void delete(){
		final Sequence s = context.sequence("seq");
		final RegRepSdrRequest obj = new RegRepSdrRequest();
		context.checking( new Expectations(){{
			oneOf(dao).delete(with(any(RegRepSdrRequest.class)));
			inSequence(s);
		}});
		dao.delete(obj);
		context.assertIsSatisfied();
	}
	
}
