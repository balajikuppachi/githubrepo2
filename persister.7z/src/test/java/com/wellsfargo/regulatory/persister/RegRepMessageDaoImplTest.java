package com.wellsfargo.regulatory.persister;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.junit.Before;
import org.junit.Test;

import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

public class RegRepMessageDaoImplTest {
private Mockery context = new Mockery();
	
	RegRepMessageDao dao ;
	@Before
	public void SetUp(){
		 dao =	context.mock(RegRepMessageDao.class);
	}
	
	@Test
	public void findByPrimaryKey(){
		final RegRepMessage obj = new RegRepMessage();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).findByPrimaryKey(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.findByPrimaryKey("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void load(){
		final RegRepMessage obj = new RegRepMessage();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).load(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.load("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void save(){
		final RegRepMessage obj = new RegRepMessage();
	
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).save(with(any(RegRepMessage.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.save(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void saveOrUpdate(){
		final RegRepMessage obj = new RegRepMessage();
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).saveOrUpdate(with(any(RegRepMessage.class)));
			inSequence(s);
		}});
		dao.saveOrUpdate(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void delete(){
		final Sequence s = context.sequence("seq");
		final RegRepMessage obj = new RegRepMessage();
		context.checking( new Expectations(){{
			oneOf(dao).delete(with(any(RegRepMessage.class)));
			inSequence(s);
		}});
		dao.delete(obj);
		context.assertIsSatisfied();
	}
	
}
