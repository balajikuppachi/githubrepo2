package com.wellsfargo.regulatory.persister;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.junit.Before;
import org.junit.Test;

import com.wellsfargo.regulatory.persister.dao.RegRepCashFlowSetDao;
import com.wellsfargo.regulatory.persister.dto.RegRepCashFlowSet;

public class RegRepCashFlowSetDaoImpTest {
private Mockery context = new Mockery();
	
	RegRepCashFlowSetDao dao ;
	@Before
	public void SetUp(){
		 dao =	context.mock(RegRepCashFlowSetDao.class);
	}
	
	@Test
	public void findByPrimaryKey(){
		final RegRepCashFlowSet obj = new RegRepCashFlowSet();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).findByPrimaryKey(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.findByPrimaryKey("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void load(){
		final RegRepCashFlowSet obj = new RegRepCashFlowSet();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).load(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.load("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void save(){
		final RegRepCashFlowSet obj = new RegRepCashFlowSet();
	
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).save(with(any(RegRepCashFlowSet.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.save(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void saveOrUpdate(){
		final RegRepCashFlowSet obj = new RegRepCashFlowSet();
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).saveOrUpdate(with(any(RegRepCashFlowSet.class)));
			inSequence(s);
		}});
		dao.saveOrUpdate(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void delete(){
		final Sequence s = context.sequence("seq");
		final RegRepCashFlowSet obj = new RegRepCashFlowSet();
		context.checking( new Expectations(){{
			oneOf(dao).delete(with(any(RegRepCashFlowSet.class)));
			inSequence(s);
		}});
		dao.delete(obj);
		context.assertIsSatisfied();
	}
	
}
