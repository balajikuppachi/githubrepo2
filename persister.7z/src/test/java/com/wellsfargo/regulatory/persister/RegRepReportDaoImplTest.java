package com.wellsfargo.regulatory.persister;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.junit.Before;
import org.junit.Test;

import com.wellsfargo.regulatory.persister.dao.RegRepReportDao;
import com.wellsfargo.regulatory.persister.dto.RegRepReport;

public class RegRepReportDaoImplTest {
private Mockery context = new Mockery();
	
	RegRepReportDao dao ;
	@Before
	public void SetUp(){
		 dao =	context.mock(RegRepReportDao.class);
	}
	
	@Test
	public void findByPrimaryKey(){
		final RegRepReport obj = new RegRepReport();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).findByPrimaryKey(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.findByPrimaryKey("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void load(){
		final RegRepReport obj = new RegRepReport();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).load(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.load("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void save(){
		final RegRepReport obj = new RegRepReport();
	
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).save(with(any(RegRepReport.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.save(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void saveOrUpdate(){
		final RegRepReport obj = new RegRepReport();
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).saveOrUpdate(with(any(RegRepReport.class)));
			inSequence(s);
		}});
		dao.saveOrUpdate(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void delete(){
		final Sequence s = context.sequence("seq");
		final RegRepReport obj = new RegRepReport();
		context.checking( new Expectations(){{
			oneOf(dao).delete(with(any(RegRepReport.class)));
			inSequence(s);
		}});
		dao.delete(obj);
		context.assertIsSatisfied();
	}
	
}
