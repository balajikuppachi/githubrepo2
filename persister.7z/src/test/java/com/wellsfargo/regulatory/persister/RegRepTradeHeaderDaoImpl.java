package com.wellsfargo.regulatory.persister;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.junit.Before;
import org.junit.Test;

import com.wellsfargo.regulatory.persister.dao.RegRepTradeHeaderDao;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

public class RegRepTradeHeaderDaoImpl {
private Mockery context = new Mockery();
	
	RegRepTradeHeaderDao dao ;
	@Before
	public void SetUp(){
		 dao =	context.mock(RegRepTradeHeaderDao.class);
	}
	
	@Test
	public void findByPrimaryKey(){
		final RegRepTradeHeader obj = new RegRepTradeHeader();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).findByPrimaryKey(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.findByPrimaryKey("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void load(){
		final RegRepTradeHeader obj = new RegRepTradeHeader();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).load(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.load("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void save(){
		final RegRepTradeHeader obj = new RegRepTradeHeader();
	
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).save(with(any(RegRepTradeHeader.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.save(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void saveOrUpdate(){
		final RegRepTradeHeader obj = new RegRepTradeHeader();
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).saveOrUpdate(with(any(RegRepTradeHeader.class)));
			inSequence(s);
		}});
		dao.saveOrUpdate(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void delete(){
		final Sequence s = context.sequence("seq");
		final RegRepTradeHeader obj = new RegRepTradeHeader();
		context.checking( new Expectations(){{
			oneOf(dao).delete(with(any(RegRepTradeHeader.class)));
			inSequence(s);
		}});
		dao.delete(obj);
		context.assertIsSatisfied();
	}
	
}
