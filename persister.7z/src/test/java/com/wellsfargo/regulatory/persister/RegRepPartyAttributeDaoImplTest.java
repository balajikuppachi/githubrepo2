package com.wellsfargo.regulatory.persister;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.junit.Before;
import org.junit.Test;

import com.wellsfargo.regulatory.persister.dao.RegRepPartyAttributeDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPartyAttribute;
import com.wellsfargo.regulatory.persister.dto.RegRepPartyAttributeId;

public class RegRepPartyAttributeDaoImplTest {
private Mockery context = new Mockery();
	
	RegRepPartyAttributeDao dao ;
	@Before
	public void SetUp(){
		 dao =	context.mock(RegRepPartyAttributeDao.class);
	}
	
	@Test
	public void findByPrimaryKey(){
		final RegRepPartyAttribute obj = new RegRepPartyAttribute();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).findByPrimaryKey(with(any(RegRepPartyAttributeId.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.findByPrimaryKey("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void load(){
		final RegRepPartyAttribute obj = new RegRepPartyAttribute();
		
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).load(with(any(String.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.load("test");
		context.assertIsSatisfied();
	}
	
	@Test
	public void save(){
		final RegRepPartyAttribute obj = new RegRepPartyAttribute();
	
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).save(with(any(RegRepPartyAttribute.class)));
			returnValue(obj);
			inSequence(s);
		}});
		dao.save(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void saveOrUpdate(){
		final RegRepPartyAttribute obj = new RegRepPartyAttribute();
		final Sequence s = context.sequence("seq");
		context.checking( new Expectations(){{
			oneOf(dao).saveOrUpdate(with(any(RegRepPartyAttribute.class)));
			inSequence(s);
		}});
		dao.saveOrUpdate(obj);
		context.assertIsSatisfied();
	}
	
	@Test
	public void delete(){
		final Sequence s = context.sequence("seq");
		final RegRepPartyAttribute obj = new RegRepPartyAttribute();
		context.checking( new Expectations(){{
			oneOf(dao).delete(with(any(RegRepPartyAttribute.class)));
			inSequence(s);
		}});
		dao.delete(obj);
		context.assertIsSatisfied();
	}
	
}
