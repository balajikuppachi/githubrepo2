package com.bala.ehCache;

public class RegRepLcEventHierarchy
{
	private int lcEventHierarchyId;
	private String eventName;
	private String parentEventNames;

	public int getLcEventHierarchyId()
	{
		return lcEventHierarchyId;
	}

	public void setLcEventHierarchyId(int lcEventHierarchyId)
	{
		this.lcEventHierarchyId = lcEventHierarchyId;
	}

	public String getEventName()
	{
		return eventName;
	}

	public void setEventName(String eventName)
	{
		this.eventName = eventName;
	}

	public String getParentEventNames()
	{
		return parentEventNames;
	}

	public void setParentEventNames(String parentEventNames)
	{
		this.parentEventNames = parentEventNames;
	}

}
