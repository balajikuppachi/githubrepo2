package com.bala.ehCache;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bala.ehCacheTest.App;

public class RegRepLcEventHierarchyCacheMain {
	
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:/ehcache/spring/applicationContext.xml";
	private static final Logger logger = Logger.getLogger(App.class);
	
    public static void main( String[] args )
    {
    	logger.info("App execution started ...");	
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		applicationContext.start();
		
		//InstantiationHelper.loadCache();
		
		applicationContext.registerShutdownHook();
			
		
		applicationContext.close();
		logger.info("App done ...");
		
    }

}
