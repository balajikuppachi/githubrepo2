package com.bala.ehCache;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.bala.ehCache.RegRepLcEventHierarchy;

/**
 * @author Raji Komatreddy
 */

@Component
public class RegRepLcEventHierarchyDaoImpl implements RowMapper<RegRepLcEventHierarchy>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	private String selectAllSql = "select  event_name, parent_event_names from REG_REP_LC_EVENT_HIERARCHY";

	private String selectEventSql = "select  event_name, parent_event_names from REG_REP_LC_EVENT_HIERARCHY where event_name = ?";

	//@Override
	public RegRepLcEventHierarchy mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		RegRepLcEventHierarchy currRegRepLcEventHierarchy = new RegRepLcEventHierarchy();

		currRegRepLcEventHierarchy.setEventName(rs.getString("event_name"));
		currRegRepLcEventHierarchy.setParentEventNames(rs.getString("parent_event_names"));

		return currRegRepLcEventHierarchy;
	}

	public List<RegRepLcEventHierarchy> getAllEvents()
	{
		List<RegRepLcEventHierarchy> regRepLcEventHierarchyList = null;
		regRepLcEventHierarchyList = jdbcTemplate.query(selectAllSql, this);

		return regRepLcEventHierarchyList;

	}

	public List<RegRepLcEventHierarchy> getEvent(String childEvent)
	{
		List<RegRepLcEventHierarchy> regRepLcEventHierarchyList = null;
		regRepLcEventHierarchyList = jdbcTemplate.query(selectEventSql, new Object[] { childEvent }, this);
		return regRepLcEventHierarchyList;
	}

}
