package com.bala.ehCacheTest;


/**
 * Class contains constants used across the application
 *
 * @author 	Amit Rana
 * @date 	08/23/2014
 * @version 1.0
 */

public class Constants
{
	// Terms
	public final static String STS 									= "Standard Terms Supplement";
	public final static String DTCC_STS_VALUE 						= "StandardTermsSupplement";
	public final static String AsSpecifiedInStandardTermsSupplement = "AsSpecifiedInStandardTermsSupplement";
	public final static String AsSpecifiedInMasterAgreement 		= "AsSpecifiedInMasterAgreement";
	public final static String KEY_SEPERATOR 						= "_";
	public final static String DRL 									= "DRL";
	public final static String RULE_TYPE_FILTER 					= "filter";
	public final static String RULE_TYPE_POPULATE 					= "populate";
	public final static String RULE_TYPE_REPORTS 					= "reports";
	public final static String RULE_TYPE_ENRICH 					= "enrich";
	public final static String JURISDICTION_CFTC 					= "CFTC";
	public final static String REPOSITORY_DTCC 						= "DTCC";
	public final static String JURISDICTION_ESMA 					= "ESMA";
	public final static String JURISDICTION_SEC 					= "SEC";
	public final static String REPOSITORY_ICE 						= "ICE";
	public final static String JURISDICTION_CANADA 					= "CANADA";
	public final static String JURISDICTION_CAD 					= "CAD";
	public final static String JURISDICTION_CANADA_SHORT 			= "CA.";
	public final static String DATA_REPOSITORY 						= "DATA_Repository";
	public final static String REPORTING_JURISDICTION 				= "Reporting_Jurisdiction";
	public final static String REPORTING_APP 						= "REG_REP";

	// asset type and report type
	public static final String ASSET_CLASS_INTEREST_RATE 			= "InterestRate";
	public static final String ASSET_CLASS_CREDIT 					= "Credit";
	public static final String ASSET_CLASS_EQUITY 					= "Equity";
	public static final String ASSET_CLASS_FOREX 					= "ForeignExchange";
	public static final String FX 									= "FX";
	public static final String ASSET_CLASS_COMMODITY 				= "Commodity";

	public static final String RATE 								= "RATE";
	public static final String MESSAGE_TYPE_RT 						= "RT";
	public static final String MESSAGE_TYPE_PET 					= "PET";
	public static final String MESSAGE_TYPE_CONF 					= "Confirm";
	public static final String MESSAGE_TYPE_SNAPSHOT 				= "Snapshot";
	public static final String MESSAGE_TYPE_VALUATION 				= "Valuation";
	public static final String MESSAGE_TYPE_DOCUMENT 				= "Document";
	public static final String MESSAGE_TYPE_SNAPSHOTBACKLOAD 		= "SnapshotBackload";
	public static final String MESSAGE_TYPE_DEFAULT 				= "Default";
	public static final String MESSAGE_TYPE_SNAPSHOT_NR 			= "Snapshot_NR";
	public static final String MESSAGE_TYPE_VALUATION_NR 			= "Valuation_NR";
	public static final String ERROR_MSG_SEPARATOR 					= "|||";
	public static final String SRC_FIELD_SEPARATOR 					= "\\|";
	public static final String TRANS_ID_SEPARATOR 					= ":";
	public static final String SINGLE_FORWARD_SLASH 				= "\\";
	public static final String DOUBLE_FORWARD_SLASH 				= "\\\\";
	public static final String BACKSLASH 							= "/";
	public static final String MESSAGE_TYPE_SNAPSHOT_TO 			= "Snapshot_TO";
	public static final String MESSAGE_TYPE_SNAPSHOT_REC 			= "Snapshot_REC";
	public static final String VALUATION_REPORT 			        = "valuationReport";
	
	

	// Use comma as a separator;
	// Only those commas are treated as separators that have an even or zero
	// number of quotes to the right of them
	// This is to ignore those commas that are part of the data and thus are
	// surrounded with quotes.
	public static final String COMMA_SEPARATOR_REGEX 				= ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";

	// public static final String T_TRADE = "trade";
	public static final String NEW_LINE 							= "\n";
	public static final String COMMA 								= ",";
	public static final String SINGLE_QUOTE 						= "'";
	public static final String SPACE 								= " ";
	public static final String PIPE 								= "|";
	public static final String COLON 								= ":";
	public static final String PERCENTAGE 							= "%";
	public static final String OPEN_BRACKET 						= "(";
	public static final String CLOSE_BRACKET 						= ")";
	
	public static final String EMPTY_STRING 						= "";
	public static final String ALLOW_EMPTY_ON_REQD 					= "ALLOW_EMPTY_ON_REQD";
	public static final String STOP_EMPTY_ON_COND 					= "STOP_EMPTY_ON_COND";

	public static final String PERIOD 								= ".";
	public static final String HYPHEN 								= "-";
	public static final String EXCEPTION 							= "***EXCEPTION***";
	public static final String VALUE_NA 							= "";
	public static final String NONE 								= "NONE";
	public final static String NOT_FOUND 							= "NOT FOUND";
	public static final String TRUE 								= "true";
	public static final String FALSE 								= "false";
	public static final String YES 									= "Yes";
	public static final String NEGATIVE_ONE 						= "-1";

	public static final String WELLS 								= "WFARGO";
	public static final String WELLS_FARGO 							= "Wells Fargo";
	public static final String WELLSFARGO 							= "WellsFargo";

	// Additional source fields that we use internally
	public static final String SEND_ID 								= "sendId";
	public static final String BUFFER_ID 							= "bufferId";
	public static final String MESSAGE_TYPE 						= "messageType";
	public static final String MESSAGE_ORIGIN 						= "messageOrigin";

	// Document msg variables
	public static final String PAPER_FLAG 							= "PaperFlag";

	// Confirm field names
	public static final String CONFIRM_DATETIME 					= "confirmDateTime";
	public static final String CONFIRM_PLATFORM 					= "confirmPlatform";
	public static final String CONFIRM_DOCUMENT_ID 					= "confirmDocumentId";

	// Confirm platform
	public static final String CONFIRM_PLATFORM_SCRITTURA 			= "Scrittura";

	// Message origin
	public static final String MESSAGE_ORIGIN_SCRITTURA_RATES 		= "ScritturaRates";
	public static final String MESSAGE_ORIGIN_SCRITTURA_CREDIT 		= "ScritturaCredit";
	public static final String MESSAGE_ORIGIN_SCRITTURA_GALAXY 		= "ScritturaGalaxy";
	public static final String MESSAGE_ORIGIN_SCRITTURA_ENDUR 		= "ScritturaEndur";
	public static final String MESSAGE_ORIGIN_CALYPSO_RATES 		= "CalypsoRates";
	public static final String MESSAGE_ORIGIN_CALYPSO_CREDIT 		= "CalypsoCredit";
	public static final String MESSAGE_ORIGIN_ENDUR_COMMODITY 		= "EndurCommodity";
	public static final String MESSAGE_ORIGIN_GALAXY 				= "Galaxy";
	public static final String MESSAGE_ORIGIN_CDBO 					= "CDBO";

	// Message status
	public static final String MSG_STATUS_READY_TO_SEND 			= "READY_TO_SEND";
	public static final String MSG_STATUS_NOT_TO_SEND 				= "NOT_TO_SEND";
	public static final String MSG_STATUS_FEE_TRADE_NOT_TO_SEND 	= "FEE_TRADE_NOT_TO_SEND";
	public static final String MSG_STATUS_ADDED_TO_CSV 				= "ADDED_TO_CSV";
	public static final String MSG_STATUS_RESENT 					= "RESENT";
	public static final String MSG_STATUS_ACCEPTED 					= "ACCEPTED";
	public static final String MSG_STATUS_REJECTED 					= "REJECTED";
	public static final String MSG_STATUS_DUPLICATE 				= "DUPLICATE";
	public static final String MSG_STATUS_PUBLISHED 				= "PUBLISHED";
	public static final String MSG_STATUS_NOT_PUBLISHED 			= "NOT_PUBLISHED";
	public static final String MSG_STATUS_TRACE_ID_NOT_FOUND 		= "TRACE_ID_NOT_FOUND";
	public static final String MSG_STATUS_NOT_ADDED_TO_MQ 			= "NOT_ADDED_TO_MQ";
	public static final String MSG_STATUS_WARNING 					= "WARNING";
	public static final String MSG_STATUS_WACK 						= "Conditionally Accepted";

	public static final String DEFAULT 								= "DEFAULT";
	public static final String FREQUENCY_PA 						= "PA";
	public static final String FREQUENCY_MTH 						= "MTH";
	public static final String FREQUENCY_SA 						= "SA";
	public static final String FREQUENCY_QTR 						= "QTR";
	public static final String FREQUENCY_WK 						= "WK";
	public static final String FREQUENCY_BIWK 						= "BIWK";
	public static final String FREQUENCY_BIM 						= "BIM";
	public static final String FREQUENCY_DLY 						= "DLY";
	public static final String FREQUENCY_ZC 						= "ZC";
	public static final String FREQUENCY_LUN 						= "LUN";
	public static final String FREQUENCY_5W 						= "5W";
	public static final String FREQUENCY_13W 						= "13W";
	public static final String FREQUENCY_26W 						= "26W";

	// Constants being used in rules
	public static final String DTCC 								= "DTCC";
	public static final String ICE 									= "ICE";
	public static final String CME 									= "CME";
	public static final String INTERNAL 							= "Internal";
	public static final String INTERNAL_LEI_PREFIX 					= "INTERNAL";
	public static final String LEG_FIXED 							= "Fixed";
	public static final String LEG_FLOATING 						= "Floating";
	public static final String CME_FULL								= "Chicago Mercantile Exchange";

	public static final String FIELD_REQUIRED 						= "R";
	public static final String FIELD_CONDITIONAL 					= "C";
	public static final String FIELD_OPTIONAL 						= "O";
	public static final String FIELD_NOT_APPLICABLE 				= "NA";

	public static final String PRODUCT_TYPE_CAPFLOOR 				= "CapFloor";
	public static final String PRODUCT_TYPE_EXOTIC 					= "Exotic";
	public static final String PRODUCT_TYPE_GENERIC					= "GenericProduct";
	public static final String PRODUCT_TYPE_FRA 					= "Fra";
	public static final String PRODUCT_TYPE_FPA 					= "FPA";
	public static final String PRODUCT_TYPE_TREASURY_LOCK 			= "TreasuryLock";
	public static final String PRODUCT_TYPE_CANCELLABLE_SWAP 		= "CancellableSwap";
	public static final String PRODUCT_TYPE_LCDS 					= "LCDS";
	public static final String PRODUCT_TYPE_CDS 					= "CDS";
	public static final String PRODUCT_TYPE_CDX 					= "CDX";
	public static final String PRODUCT_TYPE_RECOVERY_LOCK 			= "Recovery Lock";
	public static final String PRODUCT_TYPE_FIXED_REOCVERY 			= "Fixed Recovery";
	public static final String PRODUCT_TYPE_TOTAL_RETURN_SWAP 		= "TotalReturnSwap";
	public static final String PRODUCT_TYPE_STRUCTURED_PRODUCT 		= "StructuredProduct";
	public static final String PRODUCT_TYPE_STRUCTURED_MUNI 		= "StructuredMuni";
	public static final String PRODUCT_TYPE_RISK_PARTICIPATION_SWAP = "RiskParticipationSwap";
	public static final String SOVEREIGN 							= "Sovereign";
	public static final String PRODUCT_TYPE_XCCY 					= "CrossCurrency";
	public static final String PRODUCT_TYPE_CDSIndexOption 			= "CDSIndexOption";
	public static final String PRODUCT_TYPE_MMD_RATE_LOCK 			= "MMDRateLock";

	public static final String PRODUCT_SUB_TYPE_CORRIDOR 			= "Corridor";

	public static final String SWAPTION_EXERCISE_BERMUDAN 			= "Bermudan";
	public static final String SWAPTION_EXERCISE_EUROPEAN 			= "European";
	public static final String SWAPTION_EXERCISE_AMERICAN 			= "American";
	public static final String RTP 									= "RTP";
	public static final String RTR 									= "RTR";
	public static final String PARTY2 								= "Party2";
	public static final String PARTY1 								= "Party1";
	public static final String OPTION_STRADDLE 						= "Straddle";
	public static final String OPTION_CALL 							= "Straddle";
	public static final String OPTION_PUT 							= "Straddle";

	// public static final String COUNTERPARTY = "Counterparty";
	
	/*** trade status values ***/
	public static final String TRADE_STATUS_TO_BE_VER 				= "TO_BE_VER";
	public static final String TRADE_STATUS_TOBE_VER 				= "TOBE_VER";
	public static final String TRADE_STATUS_TOBE_ASSIGNED 			= "TOBE_ASSIGNED";
	public static final String DAY_ASSIGNED 						= "DAY_ASSIGNED";
	public static final String DAY_PENDING 							= "DAY_PENDING";

	public static final String TRADE_STATUS_TO_BE_MAT 				= "TO_BE_MAT";
	public static final String TRADE_STATUS_ECN_EARLY_RISK 			= "ECN_EARLY_RISK";
	public static final String TRADE_STATUS_BOOKED 					= "BOOKED";
	public static final String TRADE_STATUS_PRE_BOOKED 				= "PRE_BOOKED";
	public static final String TRADE_STATUS_CH_TO_BE_VER 			= "CH_TO_BE_VER";
	// public static final String TRADE_STATUS_DAY_INVALID = "DAY_INVALID";
	public static final String TRADE_STATUS_CANCELED 				= "CANCELED";
	public static final String TRADE_STATUS_SHADOW_TERM 			= "SHADOW_TERM";
	public static final String TRADE_STATUS_PRE_NOVATED 			= "PRE_NOVATED";
	public static final String TRADE_STATUS_EXERCISED 				= "EXERCISED";
	public static final String TRADE_STATUS_MATURED 				= "MATURED";
	public static final String TRADE_STATUS_SETTLED 				= "SETTLED";
	public static final String TRADE_STATUS_NETTED 					= "NETTED";
	public static final String TRADE_STATUS_EXPIRED 				= "EXPIRED";
	public static final String TRADE_STATUS_VERIFIED 				= "VERIFIED";
	public static final String TRADE_STATUS_NC_PENDING 				= "NC_PENDING";
	public static final String TRADE_STATUS_PENDING 				= "PENDING";
	public static final String TRADE_STATUS_NC_CONSENT_PEND 		= "NC_CONSENT_PEND";
	public static final String TRADE_STATUS_NC_CANCELED 			= "NC_CANCELED";
	public static final String TRADE_STATUS_TRADER_REVIEW 			= "TRADER_REVIEW";
	public static final String TRADE_STATUS_TRADER_REV 				= "TRADER_REV";
	public static final String TRADE_STATUS_PARTIAL_ASSIGNED 		= "PARTIAL_ASSIGNED";

	public static final String Percentage 							= "Percentage";
	public static final String Buy 									= "Buy";
	public static final String Sell 								= "Sell";
	public static final String LEI_PREFIX 							= "DTCC";

	// DTCC Doc Action and Transaction Values
	public static final String Novation 							= "Novation";
	public static final String Unwind 								= "Unwind";
	public static final String Exercise 							= "Exercise";
	public static final String Exercise_Physical 					= "Exercise - Physical";
	public static final String Amendment 							= "Amendment";
	public static final String Increase 							= "Increase";
	public static final String Termination 							= "Termination";
	public static final String Exit 								= "Exit";
	public static final String Confirmation 						= "Confirmation";
	public static final String ConfirmationKey 						= "|Confirmation|";
	public static final String Trade 								= "Trade";
	public static final String Cancel 								= "Cancel";
	public static final String APPLICABLE 							= "Applicable";
	public static final String New 									= "New";
	public static final String Modify 								= "Modify";
	public static final String NOT_APPLICABLE 						= "Not Applicable";
	public static final String NOT_AVAILABLE 						= "Not Available";
	public static final String Cancellation 						= "Cancellation";
	public static final String Backload 							= "Backload";
	public static final String Historical 							= "Historical";
	public static final String CorporateAction 						= "CorporateAction";
	public static final String Origination 							= "Origination";
	public static final String GLOBAL_CANCEL 						= "GlobalCancel";
	public static final String Bilateral_Cleared 					= "Bilateral - Cleared";
	public static final String Full_Unwind 							= "Full Unwind";
	public static final String CANCELLED 							= "Cancelled";

	public static final String CashPrice_Alternate 					= "Cash Price - Alternate";
	public static final String CashPrice 							= "CashPrice";
	public static final String CashPrice_PerYieldCurve 				= "Par Yield Curve - unadj.";
	public static final String CashPrice_CrossCurrency 				= "Cross Currency";

	public static final String UnCollateralized 					= "Uncollateralized";
	public static final String FullyCollateralized 					= "FullyCollateralized";
	public static final String PartiallyCollateralized 				= "PartiallyCollateralized";
	public static final String OneWayCollateralized 				= "One-WayCollateralized";
	public static final String Fully 								= "Fully";
	public static final String Partially 							= "Partially";
	public static final String OneWay 								= "OneWay";
	public static final String Variation 							= "Variation";
	public static final String Initial 								= "Initial";
	public static final String Exchange 							= "Exchange";
	public static final String Bilateral 							= "BILATERAL";
	public static final String ISDA 								= "ISDA";
	public static final String ALL 									= "All";
	public static final String TBD 									= "TBD";
	public static final String Novation_Trade 						= "Novation-Trade";
	public static final String NovationTrade 						= "NovationTrade";
	public static final String NovationTradeForCredit 				= "Novation Trade";

	// Market type values
	public static final String Novation_EE 							= "Novation - EE";
	public static final String Novation_OR 							= "Novation - OR";
	public static final String Novation_RP 							= "Novation - RP";
	public static final String PartialNovation_OR 					= "Partial Novation - OR";
	public static final String PartialNovation_RP 					= "Partial Novation - RP";
	public static final String Termination_Voluntary 				= "Termination - Voluntary";
	public static final String Termination_Involuntary 				= "Termination - Involuntary";
	public static final String Partial_Term_Voluntary 				= "Partial Term - Voluntary";
	public static final String NovationWFRole_Transferee 			= "Transferee";
	public static final String NovationWFRole_Transferor 			= "Transferor";
	public static final String NovationWFRole_RemainingParty 		= "Remaining Party";
	public static final String WachoviaRole_EE 						= "EE";
	public static final String WachoviaRole_OR 						= "OR";
	public static final String WachoviaRole_RP 						= "RP";
	public static final String Credit_Novation_OR 					= "Credit Novation - OR";
	public static final String Credit_Novation_EE 					= "Credit Novation - EE";
	public static final String Credit_Novation_RP 					= "Credit Novation - RP";
	public static final String Credit_Partial_Novation_OR 			= "Credit Partial Novation - OR";
	public static final String Credit_Partial_Novation_EE 			= "Credit Partial Novation - EE";
	public static final String Credit_Partial_Novation_RP 			= "Credit Partial Novation - RP";
	public static final String Compressed_Term 						= "Compressed - Term";
	public static final String Compressed_PartialTerm 				= "Compressed - Partial Term";
	public static final String Compressed_New 						= "Compressed - New";
	public static final String Compressed_Amend 					= "Compressed - Amend";
	public static final String Undo_Term 							= "Undo - Term";
	public static final String Undo_Partial_Term 					= "Undo - Partial Term";
	public static final String Undo_Amend 							= "Undo - Amend";
	public static final String Undo_Exercise 						= "Undo - Exercise";
	public static final String Undo_Novate 							= "Undo - Novate";
	public static final String Undo_SETTLED 						= "Undo - Settled";
	public static final String Undo_EXPIRED 						= "Undo - Expired";
	public static final String Undo_CANCELLATION 					= "Undo - Cancellation";
	public static final String Undo_MATURE 							= "Undo - Mature";
	public static final String Undo_Partial_Novate					= "Undo - Partial Novate";
	public static final String Undo_Netted_Full						= "Undo - Netted - Full";
	
	
	public static final String Amendment_Price_Forming 				= "Amendment (Price Forming)";
	public static final String Amendment_Non_Price_Forming 			= "Amendment (Non Price Forming)";
	public static final String MATURE 								= "Mature";
	public static final String EXPIRY 								= "Expiry";
	public static final String SETTLED 								= "Settled";
	public static final String EXPIRED 								= "Expired";
	public static final String CANCEL_ALLICATION 					= "Cancel - Allocation";
	public static final String NETTED_FULL 							= "Netted - Full";
	public static final String CANCEL_PARTIAL_TERM					= "Cancel - Partial Term - Vol";
	public static final String CANCEL_PARTIAL_NOVATION				= "Cancel - Partial Novation";
	public static final String CANCEL_NOVATION_RP					= "Cancel - Novation - RP";
	public static final String CANCEL_PARTIAL_NOVATION_RP			= "Cancel - Partial Novation - RP";
	
	public static final String FeeType_Fee 							= "FEE";
	public static final String FeeType_TerminationFee 				= "TERMINATION_FEE";
	public static final String FeeType_Termination 					= "TERMINATION";
	public static final String FeeType_NovationFee 					= "NOVATION_FEE";
	public static final String FeeType_Premium 						= "PREMIUM";

	public static final String BLOCK_TRADE 							= "Block Trade";
	public static final String BACKLOAD_LIVE 						= "live";
	public static final String BACKLOAD_DEAD 						= "dead";
	public static final String HISTORICAL_LIVE 						= "historical-live";
	public static final String HISTORICAL_DEAD 						= "historical-dead";
	public static final String CFTC = "CFTC";

	public static final String OLD_USI_PREFIX 						= "1031234567";
	public static final String WELLS_USI_PREFIX 					= "1030399337";
	public static final CharSequence RATES_EXOTIC 					= "InterestRate:Exotic";
	public static final String EmbeddedOptionOnSwap 				= "EmbeddedOptionOnSwap";
	public static final String SEMICOLON 							= ";";
	public static final String Unverified 							= "Unverified";

	/** Forex **/
	public static final String MESSAGE_TYPE_FX_HISTORYSNAPSHOT 		= "Historical Snapshot";
	public static final String FOREX_OPTION 						= "Option";
	public static final String FOREX_FORWARD 						= "Forward";
	public static final String PRODUCT_TYPE_FXCASH 					= "FXCash";
	public static final String PRODUCT_TYPE_FXSWAP 					= "FXSwap";
	public static final String FOREX_SWAP_LEG 						= "ForexSwapLegType";
	public static final String FOREX_SWAP_LEG_NEAR 					= "NL";
	public static final String FOREX_SWAP_LEG_FAR 					= "FL";
	public static final String FOREX_SWAP_LEG_INDEX 				= "ForexSwapLegIndex";
	public static final String PRODUCT_TYPE_FOREX_SWAP_SINGLE_LEG 	= "FxSingleLeg";

	public static final String UNDERSCORE 							= "_";

	/*** Equity Templates ***/
	public static final String EqTemplate_Document 					= "Equity-Document";
	public static final String EqTemplate_VS 						= "Equity-VS";
	public static final String EqTemplate_ES_PSA_CFD 				= "Equity-ES_PSA_CFD";
	public static final String EqTemplate_StructuredProduct 		= "Equity-StructuredProduct";
	public static final String EqTemplate_FWD 						= "Equity-FWD";
	public static final String Equity_Valuation 					= "Equity-Valuation";
	public static final String EqTemplate_OPT 						= "Equity-OPT";

	public static final String XX 									= "XX";
	public static final String PMINUS 								= "P-";
	public static final String CMINUS 								= "C-";
	public static final String YY 									= "YY";
	public static final String USNY 								= "USNY";
	public static final String CA_PERIOD = "CA.";
	public static final String CAD = "CAD";

	public static final String SDR_REPORTABLE 						= "SDR_REPORTABLE";
	public static final String SDR_REPORTABLE_TRUE 					= "TRUE";
	public static final String REG_REP_TEMP 						= "TEMP";
	public static final String REG_REP_MESSAGE_ID 					= "regRepMessageId";
	public static final String REG_REP_MESSAGE_TYPE 				= "regRepMessageType";

	/*** Commodities stuff ***/
	public final static String SDRMessageID 						= "tradeConfirmUId";
	public final static String ICEMessageType 						= "ICEMessageType";
	public static final String ICEMessageAction 					= "ICEMessageAction";
	public static final String SenderTradeRefId 					= "SenderTradeRefId";
	public static final String ConfirmationFile 					= "ConfirmationFile";
	public static final String ConfirmationTime 					= "ConfirmationTime";
	public static final String CollateralizationType 				= "CollateralizationType";
	public final static String ICEMessageTypeKey 					= "{ICEMessageType}=";
	public final static String SDRMessagekey 						= "{tradeConfirmUId}=";
	public static final String ICEMessageActionKey 					= "{ICEMessageAction}=";
	public static final String SenderTradeRefIdKey 					= "{SenderTradeRefId}=";
	public static final String ConfirmationFileKey 					= "{ConfirmationFile}=";
	public static final String ConfirmationTimeKey 					= "{ConfirmationTime}=";
	public static final String CollateralizationTypeKey 			= "{CollateralizationType}=";
	public static final String ConfirmationBufferId 				= "{ConfirmationBufferId}=";

	public static final String SwaptionDealReferenceUniqueID 		= "SwaptionDealReferenceUniqueID";
	public static final String SwaptionDealReferenceUniqueIDKey 	= "{SwaptionDealReferenceUniqueID}=";
	public static final String AffiliateDefaultDate 				= "AffiliateDefaultDate";
	public static final String IsWellsSeller 						= "IsWellsSeller";
	public static final String AffiliateDefaultDateKey 				= "{AffiliateDefaultDate}=";

	public static final String IsWellsSellerKey 					= "{IsWellsSeller}=";

	public static final String BO_STATUS 							= "bo_status";
	public static final String BO_STATUS_DESC 						= "bo_status_desc";
	public static final String BO_CONFIRM_BUYER_INDEX 				= "bo_confirm_buyer_index";
	public static final String BO_CONFIRM_SELLER_INDEX 				= "bo_confirm_seller_index";
	public static final String BO_CONFIRM_REFERENCE_PRICE 			= "bo_confirm_reference_price";

	public static final String STATUS 								= "Status";
	public static final String TRACEID 								= "TraceId";
	public static final String SENDID 								= "SendId";
	public static final String TRADE_CONFIRM_UID 					= "tradeConfirmUId";
	public static final String MESSAGETYPE 							= "MessageType";
	public static final String CREATIONTIMESTAMP 					= "CreationTimestamp";

	public static final String ECONFIRM_SELLER 						= "econfirm_seller";
	public static final String ECONFIRM_SENDER_TRADE_REF_ID 		= "econfirm_senderTradeRefId";
	public static final String ECONFIRM_BROKER 						= "econfirm_broker";
	public static final String ECONFIRM_TRADEDATE 					= "econfirm_tradeDate";
	
	public static final String ECONFIRM_BUYER_US_REGULATORY_DESIGNATION 		= "econfirm_buyerUSRegulatoryDesignation";
	public static final String ECONFIRM_US_REPORTING_ENTITY_CONTINUATION_DATA 	= "econfirm_usReportingEntityContinuationData";
	public static final String ECONFIRM_US_REPORTING_ENTITY_PET_DATA 			= "econfirm_usReportingEntityPETData";
	public static final String ECONFIRM_COUNTER_PARTY_STATUS 					= "econfirm_counterpartyStatus";
	public static final String ECONFIRM_USI 									= "econfirm_usi";
	public static final String ECONFIRM_SELLER_US_REGULATORY_DESIGNATION 		= "econfirm_sellerUSRegulatoryDesignation";
	public static final String ECONFIRM_US_REPORTING_ENTITY_VALUATION_DATA 		= "econfirm_usReportingEntityValuationData";
	
	public static final String ECONFIRM_TRACEID 					= "econfirm_traceId";
	public static final String ECONFIRM_BUYER 						= "econfirm_buyer";
	public static final String ECONFIRM_COUNTER_PARTY_STATUS_DATE 	= "econfirm_counterpartyStatusDate";
	public static final String ECONFIRM_SUBMISSION_COMPANY 			= "econfirm_submissionCompany";
	public static final String ECONFIRM_SELLER_LEI 					= "econfirm_sellerLEI";
	public static final String ECONFIRM_FIRST_REPORTED_SDR 			= "econfirm_firstReportedSDR";
	public static final String ECONFIRM_STATUS 						= "econfirm_status";
	public static final String ECONFIRM_TYPE 						= "econfirm_type";
	public static final String ECONFIRM_DESCRIPTION 				= "econfirm_description";
	public static final String ECONFIRM_CODE 						= "econfirm_code";
	public static final String ECONFIRM_STATUSDATE 					= "econfirm_statusDate";
	public static final String COMM_PHYS 							= "COMM-PHYS";

	// ICE Message Types
	public final static String ICE_SUBMIT_TRADE 					= "2";
	public final static String ICE_CANCEL_DISPUTE_TRADE 			= "5";
	public final static String ICE_PAPER_CONFIRM 					= "39";
	public final static String ICE_LIFECYCLE_EVENT 					= "37";
	public final static String ICE_VALUATION 						= "35";
	public final static String ICE_BACKLOADED 						= "31";
	public static final String ENCONNECT 							= "Enconnect";
	public static final String MATCHED 								= "MATCHED";
	public static final String PENDING 								= "PENDING";
	public static final String PMATCHED 							= "PMATCHED";
	public static final String PPENDING 							= "PPENDING";
	public static final String UNMATCHED 							= "UNMATCHED";
	public static final String ERROR 								= "ERROR";
	public static final String ECONFIRM_TYPE_EXCEPTION 				= "Exception";
	public static final String SUCCESS 								= "SUCCESS";
	public static final String ASSIGNED 							= "ASSIGNED";
	public static final String PCANCELED 							= "PCANCELED";
	public static final String CANCELED 							= "CANCELED";

	// ICE MEssage Actions
	public static final String SUBMIT = "SUBMIT";
	public static final String CORRECT_ERRORS_DISPUTE 				= "CORRECT ERRORS(DISPUTE)";
	public static final String UNDO_CORRECT_ERRORS_UNDISPUTE 		= "UNDO CORRECT ERRORS(UNDISPUTE)";
	public static final String UNDO_CORRECT_ERRORS 					= "UNDO CORRECT ERRORS";
	public static final String REQUEST_TO_CORRECT_ERRORS_DISPUTE 	= "REQUEST TO CORRECT ERRORS(DISPUTE)";
	public static final String REQUEST_TO_MODIFY_TERMS 				= "REQUEST TO MODIFY TERMS";
	public static final String REQUEST_TO_NOVATE 					= "REQUEST TO NOVATE";
	public static final String NOVATE_STEP_IN_SUBMIT 				= "NOVATESTEPINSUBMIT";
	public static final String REQUEST_TO_OPTION_EXERCISE 			= "REQUEST TO OPTION EXERCISE";
	public static final String REQUEST_TO_BUST 						= "REQUEST TO BUST";
	public static final String REQUEST_TO_EARLY_TERMINATE 			= "REQUEST TO EARLY TERMINATE";
	public static final String BOOKED 								= "BOOKED";
	public static final String AMEND 								= "AMEND";
	public static final String NOVATION 							= "NOVATION";
	public static final String EXERCISE 							= "Exercise";
	public static final String BUYOUT 								= "BUYOUT";
	public static final String SIMPLE 								= "SIMPLE";
	public static final String SAME 								= "SAME";
	public static final String Same_Profile 						= "Same Profile";
	public static final String CANCEL 								= "CANCEL";
	public static final String CANCEL_TRADE 						= "CANCEL_TRADE";
	public static final String REQUEST_TO_DCO_GIVEUP 				= "REQUEST TO DCO GIVEUP";
	public static final String NC_ACCEPTED_OR 						= "NC_ACCEPTED_OR";

	public static final String PREFIX_ASTERISK 						= "**";
	public static final String REFERENCE_PRICE 						= "ReferencePrice";
	public static final String SELLER_PAY_INDEX 					= "SellerPayIndex";
	public static final String BUYER_PAY_INDEX 						= "BuyerPayIndex";

	public final static String GTRCREATE 							= "GTRCREATE";
	public static final String PostAllocation 						= "PostAllocation";
	public static final String PreAllocation 						= "PreAllocation";

	public static final String STV_STRING 							= "StvString";
	public static final String ECONFIRM_VALUATIONTYPE 				= "econfirm_valuationType";
	public static final String ECONFIRM_VALUATIONDATE 				= "econfirm_valuationDate";
	public static final String VALUATION_NOTIFICATION_EMAIL_CONTENT = "Status: {0} out of {1} records succeeded.{2}Valuation file {3} has been submitted to ICE. {4}Response from ICE can be found at:{5}{6}Please contact G=Global Commodities Support <GlobalCommoditiesSupport@wellsfargo.com> with any questions.{7}*Please do not reply to this email, SDRBridgeICENotification email account cannot receive emails and is used for sending ICE notification emails only*.{8}This email is subject to a disclaimer, please click on the following link or cut and paste the link into the address bar of your browser.{9}https://www.wellsfargo.com/com/disclaimer/ged5";
	public static final String VALUATION_NOTIFICATION_EMAIL_SUBJECT = "Notification from Endur environment {0} : Submission of valuation xml {1} resulted in {2} out of {3} records succeeded.";
	public static final String LEGS_ASSOCIATED 						= "legs_associated";
	public static final String VALIDATE 							= "VALIDATE";

	public static final String PAYER 								= "Payer ";
	public static final String RECEIVER 							= "Receiver";
	public static final String FREEFORMATTEXT 						= "FREEFORMATTEXT";
	public static final String FAFFIL 								= "FAFFIL";
	public static final String AFFIL 								= "AFFIL";
	public static final String AFFILIATEEXEMPTION 					= "AFFILIATEEXEMPTION";

	public static final String CALYPSO_CANCELED 					= "CANCELED_TRADE";
	public static final String CREDITDEFAULTSWAP 					= "CreditDefaultSwap";

	public static final String NON_AFFILIATE_TRADE 					= "NON_AFFILIATE_TRADE";
	public static final String Notional_Amount 						= "Notional_Amount";
	public static final String Notional_Currency 					= "Notional_Currency";
	public static final String UPI 									= "UPI";
	public static final String ENC_RECON 							= "ENC_RECON";
	public static final String OFFFACILITY 							= "Off-Facility";
	public static final String SEF 									= "SEF";

	public static final String Reportable123 						= "Reportable123";
	public static final String NonReportable123 					= "NonReportable123";
	public static final String Reportable456 						= "Reportable456";
	public static final String NonReportable456 					= "NonReportable456";

	public static final String TradeType123_456 					= "TradeType123_456";
	public static final String Upfront 								= "UPFRONT";
	public static final String Compressed 							= "Compressed";
	public static final String CALYPSO_USI 							= "CALYPSO_USI";
	public static final String CALYPSO_TRADE_ID	 					= "CALYPSO_TRADE_ID";
	public static final String CALYPSO_USI_PREVIOUS 				= "CALYPSO_USI_PREVIOUS";
	public static final String CALYPSO_ASSET_CLASSES 				= "CALYPSO_ASSET_CLASSES";
	public static final String Undo 								= "Undo";

	// EMIR calculation constants
	public static final String DTCCUS 								= "DTCCUS";
	public static final String DTCCEU 								= "DTCCEU";
	public static final String DTCCCAD 								= "DTCCCAD";
	public static final String DTCCGTR 								= "DTCCGTR";
	public static final String ESMA 								= "ESMA";
	
	// public static final String
	public static final String EEA 									= "EEA";
	public static final String NonEEA 								= "nonEEA";
	public static final String PRINCIPAL 							= "Principal";
	public static final String EMIR 								= "EMIR";
	public static final String EMIR_DELEGATED_FULL 					= "Full";
	public static final String EMIR_DELEGATED_INDEPENDENT 			= "Independent";

	public static final String REPORTABLE_TO 						= "REPORTABLE_TO";
	public static final String REPORTABLE_TO_DTCC 					= "REPORTABLE_TO_DTCC";
	public static final String REPORTABLE_TO_EMIR 					= "REPORTABLE_TO_EMIR";
	public static final String DELEGATE_REPORTABLE_TO_EMIR 			= "DELEGATE_REPORTABLE_TO_EMIR";
	public static final String DELEGATE_REPORTABLE_TO_DTCC 			= "DELEGATE_REPORTABLE_TO_DTCC";

	public static final String TEMP_UTI_PREFIX 						= "SDRGeneratedUTI_";
	public static final String LifeCycleEvent_Error 				= "Error";
	public static final String LifeCycleEvent_Modify 				= "Modify";
	public static final String NOT_CONFIRMED 						= "NotConfirmed";
	public static final String AGREEMNT_DATE_2002 					= "2002";
	public static final String CALYPSO_UTI 							= "CALYPSO_UTI";
	public static final String CALYPSO_UTI_PREVIOUS 				= "CALYPSO_UTI_PREVIOUS";

	public static final String DataSubmitterMessageID 				= "Data Submitter Message ID";
	public static final String DataSubmitterMessageId 				= "Data Submitter Message Id";
	public static final String BOTH 								= "BOTH";

	public static final String TO_REPOSITORY_IDENTIFIER 			= "_Repository_";

	public static final String APP_TRUE 							= "1";
	public static final String APP_FALSE 							= "0";
	public static final String APP_PENDING 							= "Pending";
	public static final String APP_LAST_ACTIVE_STATUS 				= "2";

	// Used for Excel Rules
	public static final String RULES_APP_TRUE 						= "Y";
	public static final String RULES_APP_FALSE 						= "N";
	public static final String RULES_APP_NA 						= "NA";

	// Role type
	public static final String WELLSFARGO_ROLE_TYPE 				= "ProcessingOrg";
	public static final String COUNTERPARTY_ROLE_TYPE 				= "Counterparty";
	public static final String NOVATION_ROLE_TYPE 					= "NovationRole";

	public static final String APP_NOT_APPLICABLE 					= "NA";
	public static final String APP_YES_TYPE 						= "Y";

	// ECN SOURCES for checking swap wire trade or not.
	public static final String ECN_SWAPSWIRE 						= "ECN_SWAPSWIRE";
	public static final String ECN_BLOOMBERG 						= "ECN_BLOOMBERG";
	public static final String ECN_TRADEWEB 						= "ECN_TRADEWEB";
	public static final String ECN_MARKITWIRE 						= "MarkitWire";
	public static final String ECN_DTCC 						    = "DTCC";
	
	// ECN source for IsBBGBillateralTrade
	public static final String ECN_BLOOMBERG_VCON 					= "BLOOMBERG_VCON";

	// CLEARING House for IsBBGBillateralTrade
	public static final String ICECREDIT_CLEARING_HOUSE 			= "ICECREDIT";

	// Reporting counter parties for valuation
	public static final String VALUATION_RP1 						= "LEI:1591718";
	public static final String VALUATION_RP2 						= "LEI_CME";
	public static final String VALUATION_RP3 						= "LEI_LCH";

	// Rules Enrichment derived function names
	public static final String ENRICH_DERIVED_SWAPWIRETRADE 			= "IsSwapWireTrade";
	public static final String ENRICH_DERIVED_NOVATION_FEE_TRADE 		= "IsNovationFeeTrade";
	public static final String ENRICH_DERIVED_CREDIT_NOVATION_FEE_TRADE = "IsCrNovationFeeTrade";
	public static final String ENRICH_DERIVED_SEF_TRADE 				= "IsSefTrade";
	public static final String ENRICH_DERIVED_CREDIT_DOC_ACTION 		= "CrDocAction";
	public static final String ENRICH_DERIVED_CREDIT_NOVATION_CANCELLED = "CrIsNovationCancelled";
	public static final String ENRICH_DERIVED_CREDIT_TERM_FEE_TRADE 	= "CrIsTerminationFeeTrade";
	public static final String ENRICH_DERIVED_TRADE_EXECUTED_TODAY 		= "IsTradeExecutedToday";
	public static final String ENRICH_DERIVED_123TRADE 					= "Is123Trade";
	public static final String ENRICH_DERIVED_SEND_BACKLOAD 			= "SendBackload";
	public static final String ENRICH_DERIVED_ALLOCATED_TRADE 			= "IsAllocatedTrade";
	public static final String ENRICH_DERIVED_BBG_BILATERAL_TRADE 		= "IsBBGBilateralTrade";
	public static final String ENRICH_DERIVED_TRADE_ACCEPTED 			= "IsTradeAccepted";
	public static final String ENRICH_DERIVED_TRADER_REVIEW_ELIGIBLE 	= "IsTraderReviewEligible";
	public static final String ENRICH_DERIVED_MARKIT_WIRE 				= "IsMarkItWire";
	public static final String ENRICH_DERIVED_PAPER_FLAG 				= "IsPaperFlag";
	public static final String ENRICH_DERIVED_NEW_TRADE 				= "IsNewTrade";
	public static final String ENRICH_DERIVED_DTCC_TRADE_OK_FLAG 		= "DTCCTradeOKFlag";
	public static final String ENRICH_DERIVED_RATE_REPORTED_AS_CREDIT 	= "IsRateReportedAsCredit";

	// KEYWORDS ENRICHMENT
	public static final String PAYMENT_FREQ_PERIOD 						= "PaymentFreqPeriod";
	public static final String PAYMENT_FREQ_MULTIPLIER 					= "PaymentFreqMultiplier";
	public static final String FLOATING_RATE_INDEX 						= "FloatingRateIndex";
	public static final String PAYMENT_PERIOD 							= "PRD";
	public static final String PERIOD_MULTIPLIER 						= "PML";
	public static final String INDEX_MULTIPLIER 						= "IndexMultiplier";
	public static final String INDEX_PERIOD 							= "IndexPeriod";
	public static final String FPML_PRODUCT_TYPE 						= "FpmlProductType";
	public static final String PREMIUM_PAYER 							= "premiumPayer";
	public static final String PREMIUM_RECEIVER 						= "premiumReceiver";
	public static final String LIFE_CYCLE_EVENT 						= "LCE";
	public static final String PRICE_NOTATION_PRICE						= "priceNotationPrice";
	public static final String PRICE_NOTATION_PRICE_TYPE				= "priceNotationPriceType";
	
	
	public static final String RESET_FREQ_PERIOD 						= "ResetFreqPeriod";
	public static final String RESET_FREQ_MULTIPLIER 					= "ResetFreqMultiplier";
	
	public static final String ONBEHALF_OF_PARTY						= "onBehalfOfParty";
	public static final String REPORTING_OBLIGATION						= "repObligation";
	public static final String SUBMITTER_OBLIGATION						= "submitterObligation"; 		
			
	public static final String DATE_TYPE_PAYMENT 						= "PAYMENT";
	public static final String DATE_TYPE_VALUATION 						= "VALUATION";

	public static final String EVENT_TYPE_NEW 							= "New Deal";
	public static final String DTCC_EVENT_TYPE_NEW 						= "Trade";
	public static final String EVENT_TYPE_AMENDMENT_PRICE_FORMING 		= "Amendment (Price Forming)";
	public static final String DTCC_EVENT_TYPE_AMENDMENT 				= "Amendment";
	public static final String EVENT_TYPE_AMENDMENT_NON_PRICE_FORMING 	= "Amendment (Non Price Forming)";
	public static final String EVENT_TYPE_PARTIAL_TERM_VOLUNTRY 		= "Partial Term - Voluntary";
	public static final String EVENT_TYPE_TERM_VOLUNTRY 				= "Termination - Voluntary";
	public static final String CREDIT_DEFAULT_DOCUMENT_ACTION 			= "NA";
	public static final String DTCC_EVENT_TYPE_TERMINATION 				= "Termination";
	public static final String DTCC_EVENT_TYPE_WITHDRAWAL 				= "Withdrawal";

	public static final String INPUT_FILE_NAME 							= "sdr.xml";
	public static final String RESPONSE_FILE_NAME 						= "response.xml";

	public static final String FPML 									= "fpml";
	public static final String MAPPER_DIR 								= "mappers";

	public static final String DS_PAYMENT_PERIOD 						= "DS_PRD";

	// DTCC response status
	public static final String DTCC_RESPONSE_ACK 						= "Accepted";
	public static final String DTCC_RESPONSE_NACK 						= "Rejected";
	public static final String DTCC_RESPONSE_WARN	 					= "Warning";
	public static final String DTCC_RESPONSE_PASS 						= "Passed";

	public static final String RESPONSE_MESSAGE_ID 						= "messageId";
	public static final String RESPONSE_SDR_REQ 						= "SDR_REQ";
	public static final String RESPONSE_SDR_RES 						= "SDR_RES";
	public static final String RESPONSE_INACTIVE_CAD 					= "INACTIVE_CAD";
	public static final String RESPONSE_GTR_USI 						= "GTR_USI";

	// Object Factories qualifiers
	public static final String SDR_REQUEST_OBJ_FACTORY 					= "com.wellsfargo.regulatory.commons.bo.sdrRequest.ObjectFactory";
	public static final String FPML_PET_RES_OBJ_FACTORY 				= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.ObjectFactory";
	public static final String FPML_RT_RES_OBJ_FACTORY 					= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency.ObjectFactory";

	// NameSpace qualifiers
	public static final String FPML_NS_TRANSPARENCY 					= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency";
	public static final String FPML_NS_RECORDKEEPING 					= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping";

	// FpML namespace types
	public static final String FPML_PET_ACK_NS_TYPE 					= "nonpublicExecutionReportAcknowledgement";
	public static final String FPML_PET_NACK_NS_TYPE 					= "nonpublicExecutionReportException";
	public static final String FPML_RT_ACK_NS_TYPE 						= "publicExecutionReportAcknowledgement";
	public static final String FPML_RT_NACK_NS_TYPE 					= "publicExecutionReportException";
	public static final String FPML_RT_NS_TYPE 							= "publicExecutionReport";
	public static final String FPML_PET_NS_TYPE 						= "nonpublicExecutionReport";

	public static final String FPML_VAL_ACK_NS_TYPE 					= "valuationReportAcknowledgement";
	public static final String FPML_VAL_NACK_NS_TYPE 					= "valuationReportException";

	// FpML class qualifiers
	public static final String FPML_PET_RES_NACK_CLASS 					= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.Exception";
	public static final String FPML_PET_RES_ACK_CLASS 					= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.Acknowledgement";
	public static final String FPML_RT_RES_NACK_CLASS 					= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency.Exception";
	public static final String FPML_RT_RES_ACK_CLASS 					= "com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency.Acknowledgement";

	public static final String EXCEPTION_OPEN_STATUS 					= "Open";
	public static final String EXCEPTION_CLOSED_STATUS 					= "Closed";
	public static final String EXCEPTION_ASSIGNED_STATUS 				= "Assigned";

	public static final String FpML_MSG_ID_XPATH 						= "/header/messageId/value";
	public static final String VALUE_TYPE_INDETERMINED 					= "Indetermined";

	public static final String USI 										= "USI";
	public static final String UTI 										= "UTI";
	public static final String PRODUCT_TYPE_SWAPTION 					= "Swaption";
	public static final String PRODUCT_TYPE_BOND_OPTION 				= "BondOption";
	public static final String PRODUCT_TYPE_FX_OPTION 					= "FXOption";
	public static final String PRODUCT_TYPE_SWAP						= "Swap";

	public static final String FPML_REPORT_TYPE 						= "FPML_REPORT";
	public static final String NULL 									= null;

	// - keywords
	public static final String IS_GTR_USI 								= "isGtrUsi";
	public static final String USI_VALUE 								= "usiValue";
	public static final String USI_PREFIX 								= "usiPrefix";
	public static final String SEND_TO 									= "sendTo";
	public static final String SEND_BY 									= "sendBy";
	public static final String SUPERVISORY_BODY 						= "supervisoryBody";
	public static final String DTCC_PRD_ID 								= "dtccPrdId";
	public static final String COUNTERPARTY_WITHOUT_PREFIX 				= "counterPartyWithoutPrefix";
	public static final String EQUITY_SWAP_UNDERLYER_TYPE 				= "EquitySwapUnderlyerType";
	public static final String EQUITY_SWAP_SINGLE_NAME_UNDERLYER 		= "SingleName";
	public static final String EQUITY_SWAP_INDEX_UNDERLYER 				= "SingleIndex";
	public static final String EQUITY_SWAP_BASKET_UNDERLYER 			= "Basket";
	public static final String COUNTERPARTY_SCHEMA 						= "counterPartySchema";
	public static final String WF_PARTY_SCHEMA 							= "wfPartySchema";
	public static final String WF_PARTY_SCHEMA1 						= "wfPartySchema1";
	public static final String EMIR_DELEGATE_REPORT 					= "isEmirDelegateRpt";
	public static final String INTRAGROUP								= "intraGroup";
	public static final String CFTC_FINANCIAL_ENTITY 					= "cftcFinEntity";
	public static final String ESMA_FINANCIAL_ENTITY					= "esmaFinEntity";
	public static final String FINANCIAL								= "Financial";
	public static final String NON_FINANCIAL							= "NonFinancial";
	public static final String INTER_AFFILIATE							= "isInterAffiliate";
	public static final String VEGA_NOTIONAL							= "vegaNotional";
	public static final String CHANGE_IN_VEGA_NOTIONAL					= "changeInVegaNotional";
		
	public static final String AS_OF_DATE 								= "asOfdate";
	public static final String AS_OF_TIME 								= "asOfTime";
	public static final String TRADINGEVENT_AGREEMENTDATE 				= "tradingEventAgreementDate";
	
	public static final String PARTIAL_TERMINATION_AMOUNT 				= "partialTermAmount";

	// is used only for Credit PET messages
	public static final String CREDIT_CONFIRMATION_TYPE 				="confirmationType";
	
	public static final String CAD_ADDITIONAL_REPOSITORY 				="cadAdditionalRepository";

	// Used for Novation events
	public static final String TRANSFEROR_PARTY							= "transferorParty";
	public static final String TRANSFEREE_PARTY 						= "transfereeParty";
	public static final String REMAINING_PARTY 							= "remainingParty";
	public static final String FINAL_COUNTERPARTY 						= "finalParty";
	public static final String TRADE_TYPE 								= "tradeType";

	public static final String wf_affiliate_leis						= "CICI:YJLNZ4REDJZWRWLDCF04,CICI:PBLD0EJDB5FWOLXP3B76,CICI:549300BP3GCQLUK01Z83,CICI:5493005TMTXI4INO0I83,CICI:549300HRDKHM4D1NW549,CICI:549300BGUD1BTMY91368,CICI:VYVVCKR63DVZZN70PB21,CICI:549300BG1MMJ25R8B561,CICI:549300CIKTPQU21N8X32,CICI:OT19FZZ6Z7A27CCLDY33,CICI:BWS7DNS2Z4NPKPNYKL75,CICI:HC7W1GOP6HSKCVZVFE74,CICI:54930031XOZN1O5V7X78,CICI:SX0CI4F7GVW5530ZMN03";
	public static final String wf_lei									= "KB1H1DSPRFMYMCUFXT09";
	public static final String EligibleJurisdictions					= "CFTC,CA.QC.AMF,CA.MB.MSC,CA.ON.OSC,NONE,ESMA,SEC";
	
	public static final String OTHER									= "Other";
	public static final String STRING_TO_REMOVE							= "**** Remove This String ****";
	
	// Party2 Schema values
	public static final String CICI_INTERIUM_SCHEMA 					= "http://www.fpml.org/coding-scheme/external/cftc/interim-compliant-identifier";
	public static final String WF_INTERNAL_TRADE_SCHEMA 				= "http://www.dtcc.com/participant-internal-identifier";
	public static final String LEI_SCHEMA 								= "http://www.fpml.org/coding-scheme/external/iso17442";
	public static final String DTCC_SCHEMA 								= "http://www.dtcc.com/coding-scheme/party-id";
	public static final String AVOX_SCHEMA 								= "http://www.fpml.org/coding-scheme/external/party-id/AVID";
	public static final String SWIFTBIC_SCHEMA 							= "http://www.fpml.org/ext/iso9362";
	public static final String EIC_SCHEMA 								= "http://www.fpml.org/coding-scheme/external/party-id/EFET";

	//NULL Usage condition used for message Generator
	public static final String NULL_USAGE_VALUE 						= "**NULL**";
	
	public static final String STATUS_SUBMITTED 						= "Submitted";
	
	// eod constants
	
	public static final String EOD_JOB_PROCESSING 						= "processing";
	public static final String EOD_JOB_SUCCESS 							= "success";
	public static final String EOD_JOB_ERROR 							= "error";
	public static final String EOD_JOB_NAME 							= "eodJobName";
	public static final String EOD_JOB_HEADER_AS_OF_DATE 				= "asOfDate";
	public static final String EOD_JOB_COB_DATE                         = "eodCobDate";
	public static final String EOD_JOB_EXECUTION_ID 					= "jobExecutionId";
	public static final String EOD_JOB_WARNING 							= "warning";
	
	public static final String EOD_FULL_REPORT_JOB 					    = "FullReportGenSvc";
	public static final String EOD_DELTA_REPORT_JOB 				    = "DeltaReportGenSvc";
	public static final String EOD_COMB_REPORT_JOB 					    = "CombinedReportGenSvc";
	public static final String EOD_ESMA_COLLATERALVALUE_JOB 			= "EsmaCollateralValueGenSvc";
	
	public static final String EOD_REPORT_TO_JOB 					    = "TOReportGenSvc";
	public static final String EOD_REPORT_TO_GALAXY_JOB 			    = "TOReportGalaxyGenSvc";
	public static final String EOD_REPORT_REFRESH_JOB 					= "EodReportRefreshSvc";
	public static final String EOD_REPORT_INSERT_BUFFER_JOB 			= "EodReportInsertBufferSvc";
	public static final String EOD_REPORT_INSERT_VALUATION_JOB 			= "EodValuationInsertSvc";
			
	public static final String EOD_SNAPSHOT_SUBM_ONDEMAND_JOB 			= "EodSnapShotSubmitOnDemand";
	public static final String EOD_SNAPSHOT_ONDEMAND_JOB_PARAMS 		= "OnDemandJobParams";
	
	public static final String EOD_REGREP_COLLATERALVALUE 				= "RegRep_CollateralValue";
	public static final String EOD_COLLATERALVALUE_MSG_ID 				= "messageId";
	public static final String NULL_STRING 								= "NULL_STRING";
	
	public static final String SNAPSHOT_TAG 							= "<reportingPurpose>Snapshot</reportingPurpose>";
	public static final String VALUATION_TAG 							= "<reportingPurpose>Valuation</reportingPurpose>";	
	
	//EMIR Transaction type enricher keyword
	public static final String MARKET_TRANSACTION_TYPE_DOMAIN_VALUE		= "transactionType";
	//EMIR Transaction type domain value
	public static final String TRANSACTION_TYPE							= "TRANSACTION_TYPE";
	public static final String TRANSACTION_TYPE_SS						= "TRANSACTION_TYPE_SS";
	public static final String DTCC_LCE 								= "DTCC_LCE";
	
	//EMIR action type enricher keyword
	public static final String MARKET_ACTION_TYPE_DOMAIN_VALUE			= "actionType";
	public static final String CLEARING_STATUS_KEYWORD					= "clearingStatus";
	
	//EMIR action type domain value
	public static final String ACTION_TYPE								= "ACTION_TYPE";
	public static final String ACTION_TYPE_SS							= "ACTION_TYPE_SS";
	
	//Action type constant - ADDED WITH ESMA REPORTING CHANGE
	public static final String ACTION_TYPE_CANCEL						= "C";	// BUSINESS EVENTS - Termination Full~ AND Termination Partial AND Exit
	public static final String ACTION_TYPE_ERROR						= "E";	// BUSINESS EVENTS - Global Cancel (Withdrawing the trade)
	public static final String ACTION_TYPE_MODIFY						= "M";  // BUSINESS EVENTS - Modify
	public static final String ACTION_TYPE_NEW							= "N"; 	// BUSINESS EVENTS - New Trade AND AMENDMENT
	public static final String ACTION_TYPE_NA							= "NA";
	public static final String ACTION_TYPE_O							= "O";
	public static final String ACTION_TYPE_VALUATION_UPDATE				= "V";
	public static final String ACTION_TYPE_COMPRESSION					= "Z";
	
	//Life Cycle Event Constants - ADDED WITH ESMA REPORTING CHANGE
	public static final String lCE_TYPE_AMENDMENT						= "Amendment";
	public static final String LCE_TYPE_CANCEL							= "Cancel";
	public static final String LCE_TYPE_COMPRESSION						= "Compression";
	public static final String LCE_TYPE_ERROR							= "Error";
	public static final String LCE_TYPE_EXERCICE						= "Exercise";
	public static final String LCE_TYPE_INCREASE						= "Increase";
	public static final String LCE_TYPE_NOVATION						= "Novation";
	public static final String LCE_TYPE_NOVATIONTRADE					= "NovationTrade";
	public static final String LCE_TYPE_NOVATION_TRADE					= "Novation-Trade";
	public static final String LCE_TYPE_PARTIALTERMINATION				= "PartialTermination";
	public static final String LCE_TYPE_TERMINATION						= "Termination";
	public static final String LCE_TYPE_TRADE							= "Trade";
	
	//ESMA L2 LEI Prefixes 
	public static final String PREFIX_LEI 								= "LEI";
	public static final String PREFIX_CICI 								= "CICI";
	
	//Enricher keyword - Intent to clear
	public static final String INTENT_TO_CLEAR 							= "intentToClear";
	
	//parent keywords added as is from calypso
	public static final String Parent_KW_USI_CURRENT 					= "Parent.KW.USI_CURRENT";
	public static final String Parent_KW_UTI_CURRENT 					= "Parent.KW.UTI_CURRENT";
	public static final String Parent_KW_LEI_CP 						= "Parent.KW.LEI_CP";
	public static final String KW_CCP 									= "KW.CCP";
	public static final String KW_SDR_MarketType 						= "KW.SDR_MarketType";
	public static final String SDR_ACTION						        = "SDR_Action";
	public static final String USI_CANCEL						        = "USI_Cancel";
	public static final String UTI_CANCEL						        = "UTI_Cancel";
	public static final String USI_CHANGE						        = "USI Change";
	public static final String SDR_ACTION_DERIVED_EVENT				    = "SDR_ACTION_DERIVED_EVENT";
	public static final String SDR_ACTION_EXIT				            = "SDR_Action_Exit";
	public static final String SDR_ACTION_NEW				            = "SDR_Action_New";
	public static final String EVENT_TYPE_USI_CHANGE				    = "USI Change";
	public static final String EQUITY_USI_CANCEL					    = "USI Cancel";
	public static final String SDR_MO_ALERT_APPROVED					= "SDR_MO_ALERT_APPROVED";
	
	public static final String LEI_CHANGE						        = "LEI Change";
	
	//Enricher keyword - Leg 1 Index Factor
	public static final String LEG_INDEX_FACTOR1 						= "leg1IndexFactor";
	//Enricher keyword - Leg 2 Index Factor
	public static final String LEG_INDEX_FACTOR2						= "leg2IndexFactor";	
	public static final String VAL_DATA_MISSING                         = "val_data_missing";
	public static final String SEVERITY_CRITICAL                        = "critical";
	public static final String INPUT_DATA_ERROR                         = "INPUT_DATA_ERROR";
	public static final String VALUATION_DATA_MISSING_LIST              = "VALUATION_DATA_MISSING_LIST";
	
	
	public final static String[] EXIT_TRADE_EXPIRE_LIST = new String[]
			{
				Termination_Involuntary, 
				Termination_Voluntary, 
				EXERCISE, 
				Bilateral_Cleared, 
				Compressed_Term, 
				Compressed_PartialTerm,
				Full_Unwind,
				Cancellation,
				CANCELLED,
				Novation_OR,
				Credit_Novation_OR,
				MATURE,
				EXPIRY,
				SETTLED,
				EXPIRED,
				CANCEL_ALLICATION,
				NETTED_FULL,
				EQUITY_USI_CANCEL,
				CANCEL_PARTIAL_NOVATION,
				CANCEL_NOVATION_RP,
				CANCEL_PARTIAL_TERM,
				CANCEL_PARTIAL_NOVATION_RP
			};

	public final static String[] EXIT_TRADE_STATUS_LIST = new String[]
			{
				TRADE_STATUS_MATURED, 
				TRADE_STATUS_SETTLED, 
				TRADE_STATUS_EXPIRED, 
				TRADE_STATUS_NETTED
			};

	public final static String[] EXIT_NOVATION_RP_LEVEL_2 = new String[]
			{
				NonReportable123, 
				NonReportable456 
			};

	public final static String[] IR_PROD_MAND_PAYMENT_FREQ = new String[]
			{
				"CancellableSwap",
				"CapFloor",
				"NDS",
				"Swap",
				"XCCySwap",
				"SpreadCapFloorCMS"
			};
	
	public final static String IR_PROD_MAND_PAYMENT_FREQ2 = "Swaption";
	
	public static final String JURISDICTION 						= "Jurisdiction";
	public static final String REPORT_TYPE 							= "ReportType";
	public static final String EOD_JOB_INFO 						= "EodJobInfo";
	public static final String ASSET_CLASS 							= "AssetClass";
	public static final String EOD_DAY_FRACTION 					= "DayFraction";
	public static final String Trade_Exit 							= "Trade/Exit";
	public static final String N_A 									= "N/A";
	public static final String PartialNovation 					    = "Partial Novation";
	
	public static final String CLOSE_OF_BUSINESS_DATE				= "CLOSE_OF_BUSINESS_DATE";
	public static final String UTCDATEFORMAT						= "yyyy-MM-dd HH:mm:ss";
	public static final String DATEFORMAT							= "yyyy-MM-dd";
	public static final String UTC_TIMEZONE							= "UTC";
	public static final String END_USER_EXCEPTION = "END_USER_EXCEPTION";
	public static final String COUNTERPARTY 						= "Counterparty";
	public static final String REPORTING_PARTY 						= "REPORTING_PARTY";
	public static final String EOD_JOB_VAL_TIME 					= "EOD_JOB_VAL_TIME";
	public static final Object LEG1_PAYER 							= "LEG1_PAYER";
	public static final Object LEG2_PAYER 							= "LEG2_PAYER";
	public static final Object CR_BUYER_LEI 						= "CR_BUYER_LEI";
	public static final String FEDFUNDS 							= "FEDFUNDS";
	public static final String DAY_COUNT 							= "DCF";
	public static final String BASIS 								= "Basis";
	public static final String ISO_CURRENCY_EXCEPTION 				= "ISOCurrencyException";
	public static final String CREDIT 								= "Credit";
	public static final String STRADDLE 							= "Straddle";
	public static final String FREQUENCY_PERIOD 					= "PRD";
	public static final String MQ_PUBLISH_ISSUE 					= "MQ_PUBLISH_ISSUE";
	public static final String BUY 									= "BUY";
	public static final String INDEX 								= "Index";
	
	public static final String PC = "PC";
	public static final String OW = "OW";
	public static final String FC = "FC";
	public static final String UC = "UC";
	public static final String One_Way = "One-Way";
	
	
	public static final String TRIOPTIMA_REPORT_CONTENT_SYSID_IR				= "40750";
	public static final String TRIOPTIMA_REPORT_CONTENT_SYSID_CREDIT			= "40750";
	public static final String TRIOPTIMA_REPORT_CONTENT_SYSID_EQUITY			= "40750";
	public static final String TRIOPTIMA_REPORT_CONTENT_SYSID_COMMODITY			= "40750";
	public static final String TRIOPTIMA_REPORT_CONTENT_SYSID_FOREIGNEXCHANGE	= "40872";
	public static final String TRIOPTIMA_REPORT_CONTENT_DOCUMENT_SYSID			= "40768";
	public static final String TRIOPTIMA_REPORT_CONTENT_SYSID_COLLATERAL		= "60359";

	public static final String TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_CREDIT		= "3TWF";
	public static final String TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_EQUITY		= "4TWF";
	public static final String TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_FOREX		= "5TWF";
	public static final String TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_INTERESTRATE	= "6TWF";
	public static final String TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_COLLATERAL	= "0TWF";

	public static final String TRIOPTIMA_REPORT_CONTENT_SUBORIGINATOR			= "0000";
	public static final String TRIOPTIMA_REPORT_CONTENT_MULTIBATCHINDICATOR		= "N";
	public static final String TRIOPTIMA_REPORT_CONTENT_VARLENINDICATOR			= "*";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST1	= "HDR.S";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST2	= ".E";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST3	= "00";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST4	= ".C";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST5	= ".S";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST1	= "END.S";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST2	= ".E";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST3	= "00";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST4	= ".C";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST5	= ".S";
	public static final String TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST1		= "*";
	public static final String TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST2		= "O";
	public static final String TRIOPTIMA_REPORT_CONTENT_APP_TRAILER_CONST1		= "*";
	public static final String TRIOPTIMA_REPORT_CONTENT_APP_TRAILER_CONST2		= "-END";
	public static final String TRIOPTIMA_REPORT_CONTENT_FUTUREUSE47SPACE		= "%47s";
	public static final String TRIOPTIMA_REPORT_CONTENT_FUTUREUSE15SPACE		= "%15s";
	public static final String TRIOPTIMA_REPORT_CONTENT_FUTUREUSE1SPACE			= "%1s";
	public static final String TRIOPTIMA_REPORT_CONTENT_APP_HEADER_SUBMISSION_DATE		= "yyyy-MM-dd";
	public static final String TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_SUBMISSION_DATE	= "MMddyyyy";
	public static final String ASSET_CLASS_COLLATERAL 							= "COLLATERAL";
	public static final String VARIANCE 										= "Equity-VS";
	public static final String CFD 												= "Equity-ES_PSA_CFD";
	public static final String BASKET 											= "BASKET";
	public static final String INDEX_UPPERCASE 									= "INDEX";
	public static final String SHARE 											= "SHARE";
	public static final String EQUITY_UPI_TEMPLATE 								= "EquityUpiTemplate";
	public static final String RECON 											= "Recon";
	
	public static final String FX_SWAP_FAR_LEG 									= "FL";
	public static final String FX_SWAP_NEAR_LEG 								= "NL";
	public static final String PRODUCT_TYPE_FXForward							= "FXForward";
	public static final String FX_VALUE_DATE 									= "fxValueDate";
	public static final String COLLATERAL_TOTAL = "COLLATERAL_TOTAL";
	public static final String PRODUCT_TYPE_MBS="MBS";	
	public static final String StandardTermsSupplement="StandardTermsSupplement";
	public static final String PRODUCT_TYPE_MBX = "MBX";
	public static final String CreditIndex ="2003CreditIndex";
	public static final String PRODUCT_TYPE_ELCDS = "ELCDS";
	public static final String CDSonLeveragedLoans = "CDSonLeveragedLoans";
	public static final String PRODUCT_TYPE_EMBS = "EMBS";
	public static final String EuropeanCMBS="EuropeanCMBS";	
	
	public static final String COLLATERAL_PORTFOLIO_CODE = "COLLATERAL_PORTFOLIO_CODE";
	public static final String COLLATERAL_PRINCIPAL_ID = "COLLATERAL_PRINCIPAL_ID";
	public static final String COLLATERAL_CACCY = "COLLATERAL_CACCY";
	public static final String COLLATERAL_COLL_PORTFOLIO = "COLLATERAL_COLL_PORTFOLIO";
	
	// Country  type
	public static final String WELLSFARGO_CTRY_TYPE 							= "Party1Ctry";
	public static final String COUNTERPARTY_CTRY_TYPE 							= "Party2Ctry";
	public static final String USA 												= "USA";
	public static final String NON_USA 											= "NonUSA";
	public static final String TRADE_ID											= "Trade ID";
	public static final String USI_UTI 											= "USI/UTI";
	public static final String MARKET_TYPE 										= "Market Type";
	public static final String VALUATION_MAIL_TEMPLATE 							= "VAL_MAIL_TEMPLATE";
	
	
	public static final String PRODUCT_TYPE_CDSIndex 						= "CDSIndex";
	public static final String CDX_HY_INDEX 								= "CDX.NA.HY.";
	public static final String PRICENOTATION 								= "PriceNotation";
	public static final String BASISPOINTS 									= "BasisPoints";
	public static final String ADDITIONALPRICENOTATION 						= "AdditionalPriceNotation";
	public static final String PRICE 										= "Price";
	
	public static final String RefEntityQuoteValue1							= "RefEntityQuoteValue1";
	public static final String RefEntityQuoteValue2							= "RefEntityQuoteValue2";
	public static final String RefEntityMeasureType1						= "RefEntityMeasureType1";
	public static final String RefEntityMeasureType2						= "RefEntityMeasureType2";
	public static final String RefEntityQuoteUnit1							= "RefEntityQuoteUnit1";
	public static final String RefEntityQuoteUnit2							= "RefEntityQuoteUnit2";
	public static final String RESEND_SDR 									= "RESEND_SDR";
	public static final String AMEND_KWD_SDR 								= "AMEND_KWD_SDR";
	public static final String AMEND_KEYWORD 								= "AMEND_KEYWORD";
	public static final String[] NO_REALTIME_REPORTS_REQD 					= new String[]	{SDR_ACTION_EXIT,SDR_ACTION_NEW,RESEND_SDR,AMEND_KWD_SDR,AMEND_KEYWORD};
	public static final String[] UNDO_LCE_LIST								= new String[]	{Undo_Amend, Undo_Term, Undo_Partial_Term, Undo_Exercise, Undo_Novate, Undo_SETTLED, Undo_EXPIRED, Undo_CANCELLATION, Undo_MATURE, Undo_Partial_Novate, Undo_Netted_Full};
	public static final String UNDO_MODIFIED								= "Undo Modified";
	public static final String[] UNDO_MODIFIED_LCE_LIST						= new String[]	{Termination_Involuntary,Termination_Voluntary,Partial_Term_Voluntary,Exercise_Physical,Novation_RP,Novation_OR,SETTLED,EXPIRED,Cancellation,MATURE,PartialNovation_OR,PartialNovation_RP,NETTED_FULL,Exercise};
	public static final String[] UNDO_LCE_RT_RETRACT_LIST					= new String[]	{Undo_Amend, Undo_Term, Undo_Partial_Term, Undo_Novate,Undo_CANCELLATION, Undo_Partial_Novate};
	public static final String MESSAGE_TYPE_SNAPSHOT_TO_NO_UNDERSCORE 		= "SnapshotTO";


}
