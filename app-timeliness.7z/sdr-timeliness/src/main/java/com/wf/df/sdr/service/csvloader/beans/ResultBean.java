package com.wf.df.sdr.service.csvloader.beans;

public class ResultBean {
	
	private String imsSrcTradeVersion;
	private String imsSrcTradeId;
	private String irsSendId;
	private String imsUsi;
	private String imsSrcTlcEvent;
	private String imsCreateDatetime;
	private String bdCreateDatetime;
	private String imsExecDatetime;
	private String mapIrsDtccUsi;
	private String irsAssetClass;
	private String irsExecDateTime;
	private String irsProductType;
	
	public String getImsSrcTradeVersion() {
		return imsSrcTradeVersion;
	}
	public void setImsSrcTradeVersion(String imsSrcTradeVersion) {
		this.imsSrcTradeVersion = imsSrcTradeVersion;
	}
	public String getImsSrcTradeId() {
		return imsSrcTradeId;
	}
	public void setImsSrcTradeId(String imsSrcTradeId) {
		this.imsSrcTradeId = imsSrcTradeId;
	}
	public String getIrsSendId() {
		return irsSendId;
	}
	public void setIrsSendId(String irsSendId) {
		this.irsSendId = irsSendId;
	}
	public String getImsUsi() {
		return imsUsi;
	}
	public void setImsUsi(String imsUsi) {
		this.imsUsi = imsUsi;
	}
	public String getImsSrcTlcEvent() {
		return imsSrcTlcEvent;
	}
	public void setImsSrcTlcEvent(String imsSrcTlcEvent) {
		this.imsSrcTlcEvent = imsSrcTlcEvent;
	}
	public String getImsCreateDatetime() {
		return imsCreateDatetime;
	}
	public void setImsCreateDatetime(String imsCreateDatetime) {
		this.imsCreateDatetime = imsCreateDatetime;
	}
	public String getBdCreateDatetime() {
		return bdCreateDatetime;
	}
	public void setBdCreateDatetime(String bdCreateDatetime) {
		this.bdCreateDatetime = bdCreateDatetime;
	}
	public String getImsExecDatetime() {
		return imsExecDatetime;
	}
	public void setImsExecDatetime(String imsExecDatetime) {
		this.imsExecDatetime = imsExecDatetime;
	}
	public String getMapIrsDtccUsi() {
		return mapIrsDtccUsi;
	}
	public void setMapIrsDtccUsi(String mapIrsDtccUsi) {
		this.mapIrsDtccUsi = mapIrsDtccUsi;
	}
	public String getIrsAssetClass() {
		return irsAssetClass;
	}
	public void setIrsAssetClass(String irsAssetClass) {
		this.irsAssetClass = irsAssetClass;
	}
	public String getIrsExecDateTime() {
		return irsExecDateTime;
	}
	public void setIrsExecDateTime(String irsExecDateTime) {
		this.irsExecDateTime = irsExecDateTime;
	}
	public String getIrsProductType() {
		return irsProductType;
	}
	public void setIrsProductType(String irsProductType) {
		this.irsProductType = irsProductType;
	}

	@Override
	public String toString() {
		return "ResultBean [imsSrcTradeVersion=" + imsSrcTradeVersion
				+ ", imsSrcTradeId=" + imsSrcTradeId + ", irsSendId="
				+ irsSendId + ", imsUsi=" + imsUsi + ", imsSrcTlcEvent="
				+ imsSrcTlcEvent + ", imsCreateDatetime=" + imsCreateDatetime
				+ ", bdCreateDatetime=" + bdCreateDatetime
				+ ", imsExecDatetime=" + imsExecDatetime + ", mapIrsDtccUsi="
				+ mapIrsDtccUsi + ", irsAssetClass=" + irsAssetClass
				+ ", irsExecDateTime=" + irsExecDateTime + ", irsProductType="
				+ irsProductType + "]";
	}
	
}