package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.ReconTimelinessIrsGtrDomain;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public interface ReconTimelinessIrsGtrDao {

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(ReconTimelinessIrsGtrDomain dto);

	/** 
	 * Returns all rows from the domain_values table that match the criteria ''.
	 */
	public List<ReconTimelinessIrsGtrDomain> findAll(String reconId) throws TimelinessDomainException;
	
	/** 
	 * Returns all rows from the domain_values table that match the criteria ''.
	 */
	public List<ReconTimelinessIrsGtrDomain> findAllByAssetClass(String reconId, String assetClass) throws TimelinessDomainException;
	
	public int updateDtccDetailsUsingIrsKey(ReconTimelinessIrsGtrDomain dto) throws TimelinessDomainException;
	
	public int updateEqDtccDetails(ReconTimelinessIrsGtrDomain dto) throws TimelinessDomainException;
	
	public void updateCommGtrDetails(ReconTimelinessIrsGtrDomain dto) throws TimelinessDomainException;
	
}
