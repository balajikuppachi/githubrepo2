package com.wf.df.sdr.dto;

import org.springframework.stereotype.Component;

@Component
public class ReconTimelinessIrsGtrDomain {

	private String irsSystem;
	private String irsAssetClass;
	private String irsProduct;
	private String irsSubProduct;
	private Long irsRecvTimestamp;
	private String irsSendId;
	private String irsTradeId;
	private String irsTradeVersion;
	private String irsUsi;
	private String irsDtccUsi;
	private String irsTransType;
	private Long irsExecTime;
	private String irsTradeStatus;
	private Long irsReportUploadTime;
	private String irsMessageType;
	private String irsMsgStatus;
	private String irsDescription;
	private String irsRepFlag;
	private String gtrAction;
	private String gtrAssetClass;
	private String gtrTradeParty1ReferenceNumber;
	private String gtrUsi;
	private String gtrRespRecv;
	private String gtrRespAcceptance;
	private Long gtrSubmissionTime;
	private String gtrMessageType;
	private String gtrTransType;
	private String gtrRepFlag;
	private String reconId;
	private Long gtrExecTime;
	
	public String getIrsSystem() {
		return irsSystem;
	}
	public void setIrsSystem(String irsSystem) {
		this.irsSystem = irsSystem;
	}
	public String getIrsAssetClass() {
		return irsAssetClass;
	}
	public void setIrsAssetClass(String irsAssetClass) {
		this.irsAssetClass = irsAssetClass;
	}
	public String getIrsProduct() {
		return irsProduct;
	}
	public void setIrsProduct(String irsProduct) {
		this.irsProduct = irsProduct;
	}
	public String getIrsSubProduct() {
		return irsSubProduct;
	}
	public void setIrsSubProduct(String irsSubProduct) {
		this.irsSubProduct = irsSubProduct;
	}
	public Long getIrsRecvTimestamp() {
		return irsRecvTimestamp;
	}
	public void setIrsRecvTimestamp(Long irsRecvTimestamp) {
		this.irsRecvTimestamp = irsRecvTimestamp;
	}
	public String getIrsSendId() {
		return irsSendId;
	}
	public void setIrsSendId(String irsSendId) {
		this.irsSendId = irsSendId;
	}
	public String getIrsTradeId() {
		return irsTradeId;
	}
	public void setIrsTradeId(String irsTradeId) {
		this.irsTradeId = irsTradeId;
	}
	public String getIrsTradeVersion() {
		return irsTradeVersion;
	}
	public void setIrsTradeVersion(String irsTradeVersion) {
		this.irsTradeVersion = irsTradeVersion;
	}
	public String getIrsUsi() {
		return irsUsi;
	}
	public void setIrsUsi(String irsUsi) {
		this.irsUsi = irsUsi;
	}
	public String getIrsDtccUsi() {
		return irsDtccUsi;
	}
	public void setIrsDtccUsi(String irsDtccUsi) {
		this.irsDtccUsi = irsDtccUsi;
	}
	public String getIrsTransType() {
		return irsTransType;
	}
	public void setIrsTransType(String irsTransType) {
		this.irsTransType = irsTransType;
	}
	public Long getIrsExecTime() {
		return irsExecTime;
	}
	public void setIrsExecTime(Long irsExecTime) {
		this.irsExecTime = irsExecTime;
	}
	public String getIrsTradeStatus() {
		return irsTradeStatus;
	}
	public void setIrsTradeStatus(String irsTradeStatus) {
		this.irsTradeStatus = irsTradeStatus;
	}
	public Long getIrsReportUploadTime() {
		return irsReportUploadTime;
	}
	public void setIrsReportUploadTime(Long irsReportUploadTime) {
		this.irsReportUploadTime = irsReportUploadTime;
	}
	public String getIrsMessageType() {
		return irsMessageType;
	}
	public void setIrsMessageType(String irsMessageType) {
		this.irsMessageType = irsMessageType;
	}
	public String getIrsMsgStatus() {
		return irsMsgStatus;
	}
	public void setIrsMsgStatus(String irsMsgStatus) {
		this.irsMsgStatus = irsMsgStatus;
	}
	public String getIrsDescription() {
		return irsDescription;
	}
	public void setIrsDescription(String irsDescription) {
		this.irsDescription = irsDescription;
	}
	public String getIrsRepFlag() {
		return irsRepFlag;
	}
	public void setIrsRepFlag(String irsRepFlag) {
		this.irsRepFlag = irsRepFlag;
	}
	public void setGtrAction(String gtrAction) {
		this.gtrAction = gtrAction;
	}
	public String getGtrAction() {
		return gtrAction;
	}
	public String getGtrAssetClass() {
		return gtrAssetClass;
	}
	public void setGtrAssetClass(String gtrAssetClass) {
		this.gtrAssetClass = gtrAssetClass;
	}
	public String getGtrTradeParty1ReferenceNumber() {
		return gtrTradeParty1ReferenceNumber;
	}
	public void setGtrTradeParty1ReferenceNumber(
			String gtrTradeParty1ReferenceNumber) {
		this.gtrTradeParty1ReferenceNumber = gtrTradeParty1ReferenceNumber;
	}
	public String getGtrUsi() {
		return gtrUsi;
	}
	public void setGtrUsi(String gtrUsi) {
		this.gtrUsi = gtrUsi;
	}
	public String getGtrRespRecv() {
		return gtrRespRecv;
	}
	public void setGtrRespRecv(String gtrRespRecv) {
		this.gtrRespRecv = gtrRespRecv;
	}
	public String getGtrRespAcceptance() {
		return gtrRespAcceptance;
	}
	public void setGtrRespAcceptance(String gtrRespAcceptance) {
		this.gtrRespAcceptance = gtrRespAcceptance;
	}
	public Long getGtrSubmissionTime() {
		return gtrSubmissionTime;
	}
	public void setGtrSubmissionTime(Long gtrSubmissionTime) {
		this.gtrSubmissionTime = gtrSubmissionTime;
	}
	public String getGtrMessageType() {
		return gtrMessageType;
	}
	public void setGtrMessageType(String gtrMessageType) {
		this.gtrMessageType = gtrMessageType;
	}
	public String getGtrTransType() {
		return gtrTransType;
	}
	public void setGtrTransType(String gtrTransType) {
		this.gtrTransType = gtrTransType;
	}
	public String getGtrRepFlag() {
		return gtrRepFlag;
	}
	public void setGtrRepFlag(String gtrRepFlag) {
		this.gtrRepFlag = gtrRepFlag;
	}
	public String getReconId() {
		return reconId;
	}
	public void setReconId(String reconId) {
		this.reconId = reconId;
	}
	
	public Long getGtrExecTime() {
		return gtrExecTime;
	}
	public void setGtrExecTime(Long gtrExecTime) {
		this.gtrExecTime = gtrExecTime;
	}
	@Override
	public String toString() {
		return "ReconTimelinessIrsGtrDomain [irsSystem=" + irsSystem
				+ ", irsAssetClass=" + irsAssetClass + ", irsProduct="
				+ irsProduct + ", irsSubProduct=" + irsSubProduct
				+ ", irsRecvTimestamp=" + irsRecvTimestamp + ", irsSendId="
				+ irsSendId + ", irsTradeId=" + irsTradeId
				+ ", irsTradeVersion=" + irsTradeVersion + ", irsUsi=" + irsUsi
				+ ", irsDtccUsi=" + irsDtccUsi + ", irsTransType="
				+ irsTransType + ", irsExecTime=" + irsExecTime
				+ ", irsTradeStatus=" + irsTradeStatus
				+ ", irsReportUploadTime=" + irsReportUploadTime
				+ ", irsMessageType=" + irsMessageType + ", irsMsgStatus="
				+ irsMsgStatus + ", irsDescription=" + irsDescription
				+ ", irsRepFlag=" + irsRepFlag + ", gtrAction=" + gtrAction
				+ ", gtrAssetClass=" + gtrAssetClass
				+ ", gtrTradeParty1ReferenceNumber="
				+ gtrTradeParty1ReferenceNumber + ", gtrUsi=" + gtrUsi
				+ ", gtrRespRecv=" + gtrRespRecv + ", gtrRespAcceptance="
				+ gtrRespAcceptance + ", gtrSubmissionTime="
				+ gtrSubmissionTime + ", gtrMessageType=" + gtrMessageType
				+ ", gtrTransType=" + gtrTransType + ", gtrRepFlag="
				+ gtrRepFlag + ", reconId=" + reconId + "]";
	}
}
