package com.wf.df.sdr.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.report.ReconTimelinessDebugReportGenerator;
import com.wf.df.sdr.report.ReportGenerator;
import com.wf.df.sdr.service.csvloader.GalaxyReader;



@Component
@ManagedResource(description="CSV Reading and Report Generation")
public class TimelinessDebugReportGeneration {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	ReconTimelinessDebugReportGenerator repGen;
	
	@Autowired
	GalaxyReader galaxyReader;
		
	@ManagedOperation(description="CSV Reading and Report Generation")
	public void invokeEoDBufferGenerator(String reconId) throws FileNotFoundException, IOException, ParseException {
		logger.info("In TimelinessDebugReportGeneration");
		try{
		repGen.csvGenerate(reconId);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
