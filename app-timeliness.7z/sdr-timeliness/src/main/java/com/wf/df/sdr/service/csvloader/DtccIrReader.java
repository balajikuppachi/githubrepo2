package com.wf.df.sdr.service.csvloader;

import java.io.InputStream;
import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.service.csvloader.beans.DtccIrBean;
import com.wf.df.sdr.service.csvloader.common.CommonLoader;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DataReader;
import com.wf.df.sdr.service.csvloader.common.DateUtil;
import com.wf.df.sdr.service.csvloader.common.SdrSnapshotReader;

@Component
public class DtccIrReader extends CommonLoader<DtccIrBean>{

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new SdrSnapshotReader(inputStream,4);
	}
	
	@Override
	public boolean validate(DtccIrBean bean) {
		if(bean.getMessageType().equals(Constants.RT) || bean.getMessageType().equals(Constants.PET))
			return true;
		else
			return false;
	}

	@Override
	public DtccIrBean parseRecord(String[] fields) throws ParseException {
		DtccIrBean bean = new DtccIrBean();
		bean.setGtrAction(fields[0]);
		bean.setTransactionType(fields[1]);
		bean.setMessageType(fields[2]);
		bean.setUsiNamespace(fields[3]);
		bean.setUsi(fields[4]);
		bean.setAssetClass(fields[5]);
		bean.setProductType(fields[6]);
		bean.setStatus(fields[7]);
		bean.setErrorReason(fields[8]);
		bean.setSubmissionDateTime(DateUtil.getTimestampFromStringIr(fields[11]));
		bean.setTradeParty1ReferenceNumber(fields[20]);
		if(!TimelinessUtils.IsNullOrBlank(fields[13]))
			bean.setExecutionTimeStamp(DateUtil.getTimestampFromStringIr(fields[13]));
		//Execution Timestamp reading from submission report column index:13
		//this field need to add in report(Data submitter ID)
		//bean.setDataSubmitter(fields[49]);
		
		return bean;
	}
	
}
