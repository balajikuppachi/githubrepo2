package com.wf.df.sdr.service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessIrsGtrDao;
import com.wf.df.sdr.dao.spring.TimelinessExtnDao;
import com.wf.df.sdr.dto.ReconTimelinessIrsGtrDomain;
import com.wf.df.sdr.service.csvloader.beans.ReconGtrBaseBean;
import com.wf.df.sdr.service.csvloader.common.Constants;

@Component
public class BaseGtrUpdaterService {
	
Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	ReconTimelinessIrsGtrDao reconTimelinessIrsGtrDao;
	
	@Autowired
	TimelinessExtnDao timelinessExtnDao;
	
	public String getLatestReconId(){
		return timelinessExtnDao.findMaxReconId();
	}
	
	public void updateForGtrInfo(List<ReconGtrBaseBean> beanList,String assetClass){
		logger.info("Starting GTR update for "+assetClass);
		Collections.sort(beanList, new DtccComparator());
		
		ReconTimelinessIrsGtrDomain domain = new ReconTimelinessIrsGtrDomain();
		
		/*
		 * Map IR fields to Timeliness columns
		 */
		for(ReconGtrBaseBean trade : beanList){
			domain.setGtrAction(trade.getGtrAction());
			domain.setGtrAssetClass(trade.getAssetClass());
			domain.setIrsTradeId(trade.getTradeParty1ReferenceNumber());
			domain.setGtrTradeParty1ReferenceNumber(trade.getTradeParty1ReferenceNumber());
			String irsUsi = Constants.EMPTY_STRING;
			if(!TimelinessUtils.IsNullOrBlank(trade.getUsiNamespace()) && !TimelinessUtils.IsNullOrBlank(trade.getUsi())){
				irsUsi = trade.getUsiNamespace()+trade.getUsi();
			} else {
				irsUsi = trade.getUsi();
			}
			domain.setIrsUsi(irsUsi);
			domain.setGtrTransType(trade.getTransactionType());
			domain.setGtrMessageType(trade.getMessageType());
			String gtrUsi = Constants.EMPTY_STRING;
			if(!TimelinessUtils.IsNullOrBlank(trade.getUsiNamespace())) {
				gtrUsi = trade.getUsiNamespace()+trade.getUsi();
			} else {
				gtrUsi = trade.getUsi();
			}
			domain.setGtrUsi(gtrUsi);
			domain.setGtrSubmissionTime(trade.getSubmissionDateTime().getTime());
			domain.setGtrRespAcceptance(trade.getStatus());
			domain.setReconId(getLatestReconId());
			domain.setGtrExecTime(!TimelinessUtils.IsNullOrBlank(trade.getExecutionTimeStamp())?trade.getExecutionTimeStamp().getTime():new Long(0));
			
			int rowsUpdated = reconTimelinessIrsGtrDao.updateDtccDetailsUsingIrsKey(domain);
			
			/*Check if this GTR record has a corresponding IRS entry else INSERT the GTR break*/
			if(0 == rowsUpdated){
				logger.debug("Inserting dtcc record for usi : " + trade.getUsiNamespace()+trade.getUsi());
				ReconTimelinessIrsGtrDomain fullRecord = new ReconTimelinessIrsGtrDomain();
				fullRecord.setIrsSystem(Constants.GTR);				
				fullRecord.setIrsAssetClass(trade.getAssetClass());			
				fullRecord.setIrsProduct(trade.getProductType());				
				fullRecord.setIrsSubProduct(Constants.EMPTY_STRING);	
				fullRecord.setIrsRecvTimestamp(0L);	
				fullRecord.setIrsSendId(Constants.EMPTY_STRING); 			
				fullRecord.setIrsTradeId(Constants.EMPTY_STRING);			
				fullRecord.setIrsTradeVersion(Constants.EMPTY_STRING);		
				fullRecord.setIrsUsi(Constants.EMPTY_STRING);					
				fullRecord.setIrsDtccUsi(Constants.EMPTY_STRING);			
				fullRecord.setIrsTransType(Constants.EMPTY_STRING);			
				fullRecord.setIrsExecTime(0L);	
				fullRecord.setIrsTradeStatus(Constants.EMPTY_STRING);		
				fullRecord.setIrsReportUploadTime(0L);	
				fullRecord.setIrsMessageType(Constants.EMPTY_STRING);		
				fullRecord.setIrsMsgStatus(Constants.EMPTY_STRING);			
				fullRecord.setIrsDescription(Constants.EMPTY_STRING);	
				fullRecord.setIrsRepFlag(Constants.N);
				
				fullRecord.setGtrAction(trade.getGtrAction());
				fullRecord.setGtrAssetClass(trade.getAssetClass());
				fullRecord.setGtrTradeParty1ReferenceNumber(trade.getTradeParty1ReferenceNumber());
				fullRecord.setGtrUsi(gtrUsi);
				fullRecord.setGtrRespRecv(Constants.Y);
				fullRecord.setGtrRespAcceptance(trade.getStatus());
				long gtrSubTime = trade.getSubmissionDateTime().getTime();
				if(!TimelinessUtils.IsNullOrBlank(gtrSubTime) && 0L!=gtrSubTime){
					fullRecord.setGtrSubmissionTime(gtrSubTime);
				} else {
					fullRecord.setGtrSubmissionTime(0L);
				}
				fullRecord.setGtrMessageType(trade.getMessageType());
				fullRecord.setGtrTransType(trade.getTransactionType());
				fullRecord.setGtrRepFlag(Constants.Y);
				fullRecord.setReconId(getLatestReconId());
				fullRecord.setGtrExecTime(!TimelinessUtils.IsNullOrBlank(trade.getExecutionTimeStamp())?trade.getExecutionTimeStamp().getTime():new Long(0));
				if(!TimelinessUtils.IsNullOrBlank(fullRecord.getReconId()))
					reconTimelinessIrsGtrDao.insert(fullRecord);
				else
					logger.info("Could not insert as the recon id is null");
			}

		}
		logger.info("Complete GTR upload for "+assetClass);

}
	
	class DtccComparator implements Comparator<ReconGtrBaseBean> {

		@Override
		public int compare(ReconGtrBaseBean bean1, ReconGtrBaseBean bean2) {
			if (bean1.getSubmissionDateTime().compareTo(
					bean2.getSubmissionDateTime()) > 0)
				return 1;
			else if (bean1.getSubmissionDateTime().compareTo(
					bean2.getSubmissionDateTime()) < 0)
				return -1;

			return 0;
		}
	}
}
