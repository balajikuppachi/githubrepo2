package com.wf.df.sdr.service.csvloader;

import java.io.InputStream;
import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.beans.GalaxyBean;
import com.wf.df.sdr.service.csvloader.common.CommonLoader;
import com.wf.df.sdr.service.csvloader.common.DataReader;
import com.wf.df.sdr.service.csvloader.common.SdrSnapshotReader;

@Component
public class GalaxyReader extends CommonLoader<GalaxyBean>{
	
	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new SdrSnapshotReader(inputStream,1);
	}
	
	@Override
	public boolean validate(GalaxyBean bean) {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	public GalaxyBean parseRecord(String[] fields) throws ParseException {
		GalaxyBean bean = new GalaxyBean();
		bean.setSystem(fields[0]);
		bean.setAssetClass(fields[1]);
		bean.setProduct(fields[2]);
		bean.setGtrName(fields[3]);
		bean.setExecutionDate(fields[4]);
		bean.setFoTradeId(fields[5]);
		bean.setTradeVersion(fields[6]);
		bean.setFoUSI(fields[7]);
		bean.setFrontOfficeFlag(fields[8]);
		bean.setBackloadFlag(fields[9]);
		bean.setReportingPartyFlag(fields[10]);
		bean.setTradeStatus(fields[11]);
		bean.setLatestAmendmentDate(fields[12]);
		bean.setLceEvent(fields[14]);
		bean.setOtcProductId(fields[13]);
		
		return bean;
	}
}
