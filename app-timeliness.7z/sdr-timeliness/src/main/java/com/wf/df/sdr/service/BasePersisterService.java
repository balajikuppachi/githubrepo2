package com.wf.df.sdr.service;

import java.math.BigDecimal;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wf.df.sdr.dao.ReconDetailsDao;
import com.wf.df.sdr.dao.spring.TimelinessExtnDao;
import com.wf.df.sdr.dto.ReconDetails;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;


public abstract class BasePersisterService {

	@Autowired
	TimelinessExtnDao timelinessExtnDao;
	
	@Autowired
	ReconDetailsDao reconDetailsDao;
	Logger logger = LoggerFactory.getLogger(getClass());
	
	public String getCurrentReconId(String source) {
		
		String value=timelinessExtnDao.findMaxReconId();
			if (value == null) {
				
				String yesterday = DateUtil.getYesterdayDateString();
				logger.info("yesterdayDate:"+yesterday);
				BigDecimal id=timelinessExtnDao.findMaxId();
				ReconDetails recon = new ReconDetails();
				recon.setId(id.add(new BigDecimal(1)));
				value = DateFormatUtils.format(DateUtil.getDateFromString(yesterday), "yyyyMMdd");
				recon.setReconId(value);
				recon.setReconFlag(Constants.TRUE);

				reconDetailsDao.insert(recon);
			} else {
				timelinessExtnDao.deleteIrs(value, source);
				timelinessExtnDao.deleteGtr(value, source);
			}
		
		return	value;
	}
}
