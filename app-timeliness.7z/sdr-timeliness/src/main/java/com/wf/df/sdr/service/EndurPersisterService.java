package com.wf.df.sdr.service;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessFODao;
import com.wf.df.sdr.dao.TimelinessDao;
import com.wf.df.sdr.dto.ReconTimelinessFO;
import com.wf.df.sdr.service.csvloader.beans.EndurBean;
import com.wf.df.sdr.service.csvloader.beans.ReconTimelinessIrsResultBean;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

@Component
public class EndurPersisterService extends BasePersisterService {

	@Autowired
	TimelinessDao timelinessDao;
	
	@Autowired
	ReconTimelinessFODao reconTimelinessFODao;
	
	/*@Value("${timeliness.date.flag}")
	boolean isDateProvided;
	
	@Value("${timeliness.date.value}")
	String dateProvided;*/
	
	/*public void persist(List<EndurBean> list){
		long elapsedTime=0L;
		for(EndurBean bean : list){
			TimelinessDomain dto = new TimelinessDomain();
			dto.setSystem(Constants.ENDUR);
			dto.setAssetClass(Constants.ASSET_CLASS_COMMODITY);
			dto.setProduct(bean.getProductId());
			if(!TimelinessUtils.IsNullOrBlank(bean.getEventDate())){
				elapsedTime=DateUtil.getDateFromEndurDateFromat(bean.getEventDate()).getTime();
				dto.setExecutionDate(elapsedTime);
				dto.setFoExecDate(elapsedTime);
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getLastUpdate())){
				elapsedTime=DateUtil.getDateFromEndurDateFromat(bean.getLastUpdate()).getTime();
				dto.setFoTlcExecDate(elapsedTime);
			} else {
				dto.setFoTlcExecDate(0L);
			}
			dto.setFoTradeStatus(bean.getStatus());
			dto.setFoMarketType(bean.getEventStatus());
			dto.setIrsReportUploadTime(0L);
			dto.setSdrSubmissionTime(0L);
			dto.setIrsRecvTimestamp(null);
			dto.setFoTradeId(bean.getSenderTradeRefId());
			dto.setFoTradeVersion(bean.getTransNumber());
			dto.setFoUsi(bean.getUsi());
			dto.setFoRepFlag(Constants.N);
			dto.setIrsRepFlag(Constants.N);
			dto.setGtrRepFlag(Constants.N);
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrReportable()) && !TimelinessUtils.IsNullOrBlank(bean.getSdrSendFlag())){
				if(Constants.ICE.equalsIgnoreCase(bean.getSdrReportable()) && Constants.YES.equalsIgnoreCase(bean.getSdrSendFlag()))
					dto.setFoRepFlag(Constants.Y);
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrSendFlag()))
				dto.setFoSdrEligibleTrade(bean.getSdrSendFlag());
			
			dto.setIrsUsi(null);
			dto.setGtrUsi(null);
			//dto.setDtccRespRecv(null);
			dto.setDtccRespAcceptance(null);
			dto.setReportingParty(bean.getRp());
			dto.setSdrEligibility(Constants.Y);
			dto.setFoSdrReportable(bean.getSdrReportable());
			if (bean.getSdrReportable().equals(Constants.ICE))
				dto.setFoJurisdiction(Constants.CFTC);
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getEventDate())){
			if(DateUtil.dateComparision(DateUtil.formatTimeStampForReport(dto.getExecutionDate()))&& !TimelinessUtils.IsNullOrBlank(bean.getSenderTradeRefId())  && !TimelinessUtils.IsNullOrBlank(bean.getTransNumber()))
					timelinessDao.insert(dto);
		}
		}
	}*/
	/*enum TradeStatus {
		Validated("BOOKED"),Matured("MATURED"),Amend("Amended"),Canceled("CANCELED"),New("New");
		  
		   String day;
		   TradeStatus(String p) {
			   day = p;
		   }
		  String showTradeStatus(){
			  return day;
		  }
		}*/
	
	public String persist(List<EndurBean> list){
		long elapsedTime=0L;
		String reconId=getCurrentReconId(Constants.ASSET_CLASS_COMMODITY);
		String dateProvided = alterReconID(reconId);
		//Map<String,ReconTimelinessFO> resultFo=new Hashtable<String,ReconTimelinessFO>();
		for(EndurBean bean : list){
			ReconTimelinessFO dto = new ReconTimelinessFO();
			dto.setFoSystem(Constants.ENDUR);
			dto.setFoAssetClass(Constants.ASSET_CLASS_COMMODITY);
			dto.setFoProduct(bean.getProductId());
			if(!TimelinessUtils.IsNullOrBlank(bean.getEventDate())){
				elapsedTime=DateUtil.getDateFromEndurDateFromat(bean.getEventDate()).getTime();
				dto.setExecutionDate(elapsedTime);
				dto.setFoExecDate(elapsedTime);
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getLastUpdate())){
				elapsedTime=DateUtil.getDateFromEndurDateFromat(bean.getLastUpdate()).getTime();
				dto.setFoTlcExecDate(elapsedTime);
			} else {
				dto.setFoTlcExecDate(0L);
			}
			/*for(TradeStatus m:TradeStatus.values()){
				if(m.name().equalsIgnoreCase(bean.getTradeStatus()))
					dto.setFoTradeStatus(m.showTradeStatus());
			}*/
			if(bean.getTradeStatus().equalsIgnoreCase("Cancelled"))
				dto.setFoTradeStatus("CANCELED");
			else
			 dto.setFoTradeStatus(bean.getTradeStatus().toUpperCase());
			
			dto.setFoMarketType(bean.getEventStatus());
			dto.setFoTradeId(bean.getSenderTradeRefId());
			dto.setFoTradeVersion(bean.getTransNumber());
			dto.setFoUsi(bean.getUsi());
			dto.setFoSdrEligibleTrade(bean.getSdrSendFlag());
			dto.setFoSdrReportable(bean.getSdrReportable());
			dto.setReportingParty(bean.getRp());
			dto.setSdrEligibility(Constants.Y);
			if(Constants.ICE.equalsIgnoreCase(bean.getSdrReportable()))
				dto.setFoJurisdiction(Constants.CFTC);
			else
				dto.setFoJurisdiction(Constants.EMPTY_STRING);
			dto.setFoRepFlag(Constants.N);
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrReportable()) && !TimelinessUtils.IsNullOrBlank(bean.getSdrSendFlag())){
				if(Constants.ICE.equalsIgnoreCase(bean.getSdrReportable()) && Constants.YES.equalsIgnoreCase(bean.getSdrSendFlag())&& Constants.YES.equalsIgnoreCase(bean.getRp()))
					dto.setFoRepFlag(Constants.Y);
			}
			dto.setReconId(reconId);
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getEventDate())){
				if((DateUtil.compareDate(dateProvided,DateUtil.formatTimeStampForReport(dto.getExecutionDate())) || DateUtil.dateComparision(DateUtil.formatTimeStampForReport(dto.getExecutionDate()))) && !TimelinessUtils.IsNullOrBlank(bean.getSenderTradeRefId())&& !TimelinessUtils.IsNullOrBlank(bean.getTransNumber()))
				{	
					//resultFo.put(dto.getFoTradeId()+":"+dto.getFoTradeVersion()+":"+dto.getFoTradeStatus(), dto);
					reconTimelinessFODao.insert(dto);
				}
			}
			
			
		}
		/*List<ReconTimelinessFO> resutlFoList=new ArrayList<ReconTimelinessFO>(resultFo.values());
		for(ReconTimelinessFO foData:resutlFoList){
			reconTimelinessFODao.insert(foData);
		}*/
		return reconId;
	}
	
	private String alterReconID(String reconID) {
		
		StringBuffer sb = new StringBuffer(reconID);
		if(reconID.length()==8){
			sb.insert(4, '-');
			sb.insert(7, '-');
		}
		return 	sb.toString();		
	}
	
}
