package com.wf.df.sdr.service.messaging;

public interface TimelinessReportGenerationRequest {
	public void submit(TimelinessReportRequest repReq);
}
