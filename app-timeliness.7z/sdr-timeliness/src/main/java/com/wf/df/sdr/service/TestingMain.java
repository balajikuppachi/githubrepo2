package com.wf.df.sdr.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.wf.df.sdr.service.csvloader.common.DateUtil;

public class TestingMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//String timeStamp="2013-01-23T09:36:15-05:00";
		String timeStamp1="2013-01-23 09:36:15.099";
		String timeStamp2="2013-01-23T09:34:19";
		try {
			Date date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(timeStamp1);
			Date date2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(timeStamp2);
			System.out.println(date1+"\n"+date2);
			long timeDiffInMilliSec = date1.getTime()-date2.getTime();
			System.out.println("Differnece : "+ timeDiffInMilliSec);
			System.out.println(DateUtil.reportFormattedTimeDifference(timeDiffInMilliSec));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
