package com.wf.df.sdr.service.csvloader.common;

import java.io.IOException;
import java.io.InputStream;

public class SdrSnapshotReader extends CsvWithHeaderReader {
	
	static int HEADER_LINES = 3;

	public SdrSnapshotReader(InputStream is) {
		super(is, HEADER_LINES);
	}
	public SdrSnapshotReader(InputStream is, int headerLines) {
		super(is, headerLines);
	}
	
	@Override
	public String[] readNext() throws IOException {
		String[] nextLine = super.readNext();
		if (nextLine != null && nextLine.length > 0 && nextLine[0] != null && nextLine[0].endsWith("-END")) {
			return null;
		}
		return nextLine;
	}
	
}
