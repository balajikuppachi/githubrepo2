package com.wf.df.sdr.service.csvloader.beans;

import java.util.Date;

public class DtccFxBean implements BaseBean{

	private String transactionType;
	private String messageType;
	private String usiPrefix;
	private String usiValue;
	private String assetClass;
	private String productType;
	private String status;
	private Date submissionDateTime;
	private String tradeParty1TransactionId;
	private String dataSubmitter;
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getUsiPrefix() {
		return usiPrefix;
	}
	public void setUsiPrefix(String usiPrefix) {
		this.usiPrefix = usiPrefix;
	}
	public String getUsiValue() {
		return usiValue;
	}
	public void setUsiValue(String usiValue) {
		this.usiValue = usiValue;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getSubmissionDateTime() {
		return submissionDateTime;
	}
	public void setSubmissionDateTime(Date submissionDateTime) {
		this.submissionDateTime = submissionDateTime;
	}
	public String getTradeParty1TransactionId() {
		return tradeParty1TransactionId;
	}
	public void setTradeParty1TransactionId(String tradeParty1TransactionId) {
		this.tradeParty1TransactionId = tradeParty1TransactionId;
	}
	public String getDataSubmitter() {
		return dataSubmitter;
	}
	public void setDataSubmitter(String dataSubmitter) {
		this.dataSubmitter = dataSubmitter;
	}
	
	@Override
	public String toString() {
		return "DtccFxBean [transactionType=" + transactionType
				+ ", messageType=" + messageType + ", usiPrefix=" + usiPrefix
				+ ", usiValue=" + usiValue + ", assetClass=" + assetClass
				+ ", productType=" + productType + ", status=" + status
				+ ", submissionDateTime=" + submissionDateTime
				+ ", tradeParty1TransactionId=" + tradeParty1TransactionId
				+ ", dataSubmitter=" + dataSubmitter + "]";
	}
	
}
