package com.wf.df.sdr.service.csvloader.beans;


public class GalaxyBean implements BaseBean{

	private String system;

	private String assetClass;

	private String product;

	private String gtrName;

	private	String executionDate;

	private	String foTradeId;

	private String tradeVersion;

	private String foUSI;

	private String frontOfficeFlag;

	private String backloadFlag;

	private String reportingPartyFlag;

	private String tradeStatus;

	private String latestAmendmentDate;
	private String otcProductId;
	
	
	private String lceEvent;

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getGtrName() {
		return gtrName;
	}

	public void setGtrName(String gtrName) {
		this.gtrName = gtrName;
	}

	public String getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(String fields) {
		this.executionDate = fields;
	}

	public String getFoTradeId() {
		return foTradeId;
	}

	public void setFoTradeId(String foTradeId) {
		this.foTradeId = foTradeId;
	}

	public String getTradeVersion() {
		return tradeVersion;
	}

	public void setTradeVersion(String tradeVersion) {
		this.tradeVersion = tradeVersion;
	}

	public String getFoUSI() {
		return foUSI;
	}

	public void setFoUSI(String foUSI) {
		this.foUSI = foUSI;
	}

	public String getFrontOfficeFlag() {
		return frontOfficeFlag;
	}

	public void setFrontOfficeFlag(String frontOfficeFlag) {
		this.frontOfficeFlag = frontOfficeFlag;
	}

	public String getBackloadFlag() {
		return backloadFlag;
	}

	public void setBackloadFlag(String backloadFlag) {
		this.backloadFlag = backloadFlag;
	}

	public String getReportingPartyFlag() {
		return reportingPartyFlag;
	}

	public void setReportingPartyFlag(String reportingPartyFlag) {
		this.reportingPartyFlag = reportingPartyFlag;
	}

	public String getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public String getLatestAmendmentDate() {
		return latestAmendmentDate;
	}

	public void setLatestAmendmentDate(String latestAmendmentDate) {
		this.latestAmendmentDate = latestAmendmentDate;
	}

	public String getLceEvent() {
		return lceEvent;
	}

	public void setLceEvent(String lceEvent) {
		this.lceEvent = lceEvent;
	}

	public String getOtcProductId() {
		return otcProductId;
	}

	public void setOtcProductId(String otcProductId) {
		this.otcProductId = otcProductId;
	}

	@Override
	public String toString() {
		return "GalaxyBean [system=" + system + ", assetClass=" + assetClass
				+ ", product=" + product + ", gtrName=" + gtrName
				+ ", executionDate=" + executionDate + ", foTradeId="
				+ foTradeId + ", tradeVersion=" + tradeVersion + ", foUSI="
				+ foUSI + ", frontOfficeFlag=" + frontOfficeFlag
				+ ", backloadFlag=" + backloadFlag + ", reportingPartyFlag="
				+ reportingPartyFlag + ", tradeStatus=" + tradeStatus
				+ ", latestAmendmentDate=" + latestAmendmentDate
				+ ", otcProductId=" + otcProductId + ", lceEvent=" + lceEvent
				+ "]";
	}

	
}
