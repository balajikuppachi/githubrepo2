package com.wf.df.sdr.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.beans.DtccIrBean;
import com.wf.df.sdr.service.csvloader.beans.ReconGtrBaseBean;
import com.wf.df.sdr.service.csvloader.common.Constants;

@Component
public class IrGtrUpdaterService extends BaseGtrUpdaterService{

	public void updateGtrCalypsoIrDetails(List<DtccIrBean> beanList){
		List<ReconGtrBaseBean> reconGtrbean=new ArrayList<ReconGtrBaseBean>();
		for(int i=0;i<beanList.size();i++){
			ReconGtrBaseBean bean=new ReconGtrBaseBean();
			BeanUtils.copyProperties(beanList.get(i), bean);
			reconGtrbean.add(bean);
		}
		updateForGtrInfo(reconGtrbean,Constants.ASSET_CLASS_INTEREST_RATE);
	}
	
}
