package com.wf.df.sdr.service;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessIrsGtrDao;
import com.wf.df.sdr.dao.spring.ReconTimelinessIrsGtrExtnDao;
import com.wf.df.sdr.dto.ReconTimelinessIrsGtrDomain;
import com.wf.df.sdr.service.csvloader.beans.ReconTimelinessIrsResultBean;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

@Component
public class CommodityIrsUpdaterService extends BaseIrsUpdaterService{
	
	@Autowired
	ReconTimelinessIrsGtrExtnDao timelinessExtnDao;
	
	@Autowired
	ReconTimelinessIrsGtrDao irsRtPetDetails;
	
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	public String updateForCommUpdate(String reconId){
		String assetClass=Constants.ASSET_CLASS_COMMODITY;
		logger.info("Updating for SENT messages for all "+assetClass+" trades");
		
		List<ReconTimelinessIrsResultBean> irsSuccessCommTrades=timelinessExtnDao.fetchImsDataForComm(reconId);	
		Map<String,ReconTimelinessIrsResultBean> resultMap=new Hashtable<String,ReconTimelinessIrsResultBean>();
		
		if(!TimelinessUtils.IsNullOrBlank(irsSuccessCommTrades) && irsSuccessCommTrades.size()>0){
			
			for(ReconTimelinessIrsResultBean result : irsSuccessCommTrades){
				resultMap.put(result.getIrsSrcTradeId()+":"+result.getIrsSrcTradeVersion()+":"+result.getIrsTradeStatus(), result);
			}
			List<ReconTimelinessIrsResultBean> resutlList=new ArrayList<ReconTimelinessIrsResultBean>(resultMap.values());
			
			for(ReconTimelinessIrsResultBean result : resutlList){
				ReconTimelinessIrsGtrDomain domain = new ReconTimelinessIrsGtrDomain();
				if(!TimelinessUtils.IsNullOrBlank(result)){
					domain.setIrsSystem(Constants.IRS);				
					domain.setIrsAssetClass(result.getIrsAssetClass());			
					domain.setIrsProduct(result.getIrsProductType());				
					domain.setIrsSubProduct(result.getIrsSubProductType());	
					
					String irsRcvTime = result.getIrsReceiveTime();
					if(!TimelinessUtils.IsNullOrBlank(irsRcvTime)){
						domain.setIrsRecvTimestamp(DateUtil.getTimestampFromStringForDiff(irsRcvTime).getTime());		
					} else {
						domain.setIrsRecvTimestamp(0L);	
					}
					
					domain.setIrsSendId(result.getIrsSendId()); 			
					domain.setIrsTradeId(result.getIrsSrcTradeId());			
					domain.setIrsTradeVersion(result.getIrsSrcTradeVersion());		
					domain.setIrsUsi(result.getIrsUsi());					
					domain.setIrsDtccUsi(result.getMapIrsDtccUsi());			
					domain.setIrsTransType(result.getIrsSrcTlcEvent());			
					
					String irsExecTime = result.getIrsExecDatetime();
					if(!TimelinessUtils.IsNullOrBlank(irsExecTime)){
						domain.setIrsExecTime(DateUtil.getTimestampFromStringForDiff(irsExecTime).getTime());			
					} else {
						domain.setIrsExecTime(0L);	
					}
					
					domain.setIrsTradeStatus(result.getIrsTradeStatus());		

					String irsReportUploadTime = result.getIrsReportUploadTime();
					if(!TimelinessUtils.IsNullOrBlank(irsReportUploadTime)){
						domain.setIrsReportUploadTime(DateUtil.getTimestampFromStringForDiff(irsReportUploadTime).getTime());	
					} else {
						domain.setIrsReportUploadTime(0L);	
					}
					
					//domain.setIrsMessageType(result.getIrsMsgType());		
					domain.setIrsMsgStatus(Constants.SENT);			
					domain.setIrsDescription(Constants.EMPTY_STRING);	
					domain.setIrsRepFlag(Constants.Y);
					domain.setGtrSubmissionTime(0L);
					domain.setGtrRepFlag(Constants.Y);
					domain.setGtrRespRecv(Constants.N);
					domain.setReconId(reconId);
					domain.setGtrExecTime(0L);
				}
				
				irsRtPetDetails.insert(domain);
			}
			logger.info("Completed IRS  SENT update for "+ assetClass);
		}
		

		/*
		 * For left over FO trades present in input_msg_store
		 * */
		List<ReconTimelinessIrsResultBean> irsLeftOverFoTrades=reconTimelinessExtnDao.getIrsLeftOverFoTradeDetailsForComm(reconId, assetClass);
		logger.info("Matching IRS for FO leftover trades count : "+irsLeftOverFoTrades.size());
		if(!TimelinessUtils.IsNullOrBlank(irsLeftOverFoTrades) && irsLeftOverFoTrades.size()>0){
			for(ReconTimelinessIrsResultBean result : irsLeftOverFoTrades){
				ReconTimelinessIrsGtrDomain domain = new ReconTimelinessIrsGtrDomain();
				if(!TimelinessUtils.IsNullOrBlank(result)){
					domain.setIrsSystem(Constants.IRS);				
					domain.setIrsAssetClass(result.getIrsAssetClass());			
					domain.setIrsProduct(result.getIrsProductType());				
					domain.setIrsSubProduct(result.getIrsSubProductType());	
					
					String irsRcvTime = result.getIrsReceiveTime();
					if(!TimelinessUtils.IsNullOrBlank(irsRcvTime)){
						domain.setIrsRecvTimestamp(DateUtil.getTimestampFromStringForDiff(irsRcvTime).getTime());		
					} else {
						domain.setIrsRecvTimestamp(0L);	
					}
					
					domain.setIrsSendId(result.getIrsSendId()); 			
					domain.setIrsTradeId(result.getIrsSrcTradeId());			
					domain.setIrsTradeVersion(result.getIrsSrcTradeVersion());		
					domain.setIrsUsi(result.getIrsUsi());					
					domain.setIrsDtccUsi(Constants.EMPTY_STRING);			
					domain.setIrsTransType(result.getIrsSrcTlcEvent());			
					
					String irsExecTime = result.getIrsExecDatetime();
					if(!TimelinessUtils.IsNullOrBlank(irsExecTime)){
						domain.setIrsExecTime(DateUtil.getTimestampFromStringForDiff(irsExecTime).getTime());			
					} else {
						domain.setIrsExecTime(0L);	
					}
					
					domain.setIrsTradeStatus(result.getIrsTradeStatus());		

					/*For trades which are not eligible for reporting no upload hence update 0*/
					domain.setIrsReportUploadTime(0L);	
					
					domain.setIrsMessageType(Constants.EMPTY_STRING);		
					domain.setIrsMsgStatus(Constants.EMPTY_STRING);			
					domain.setIrsDescription(Constants.EMPTY_STRING);	
					domain.setIrsRepFlag(Constants.Y);
					domain.setGtrSubmissionTime(0L);
					domain.setGtrRespRecv(Constants.N);
					domain.setGtrRepFlag(Constants.Y);
					domain.setReconId(reconId);
					domain.setGtrExecTime(0L);
				}
				irsRtPetDetails.insert(domain);
			}
		}
		logger.info("Completed update for left over FO trades for all "+assetClass+" trades");
		logger.info("Completed IRS updater service for "+assetClass);
		return reconId;
	}
	
}
