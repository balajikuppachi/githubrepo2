package com.wf.df.sdr.service.csvloader.beans;

public interface BaseBean {

}
