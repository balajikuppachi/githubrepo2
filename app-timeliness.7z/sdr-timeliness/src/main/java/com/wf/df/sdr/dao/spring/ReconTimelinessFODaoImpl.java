package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.ReconTimelinessFODao;
import com.wf.df.sdr.dto.ReconTimelinessFO;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public class ReconTimelinessFODaoImpl extends AbstractDAO implements ParameterizedRowMapper<ReconTimelinessFO>,ReconTimelinessFODao {

	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(ReconTimelinessFO dto) {
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( fo_system, fo_asset_class, fo_product,fo_sub_product , fo_exec_date, execution_date, fo_tlc_exec_date, fo_market_type, fo_trade_status, fo_trade_id, fo_trade_version, fo_usi, fo_sdr_eligible_trade, reporting_party, sdr_eligibility,fo_sdr_reportable, fo_jurisdiction, fo_rep_flag, recon_id, fo_cpty_clarification, fo_reporting_jurisdiction  ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", dto.getFoSystem(), dto.getFoAssetClass(), dto.getFoProduct(), dto.getFoSubProduct(),dto.getFoExecDate().longValue()+"", dto.getExecutionDate().longValue()+"", dto.getFoTlcExecDate().longValue()+"", dto.getFoMarketType(), dto.getFoTradeStatus(), dto.getFoTradeId(), dto.getFoTradeVersion(), dto.getFoUsi(), dto.getFoSdrEligibleTrade(), dto.getReportingParty(), dto.getSdrEligibility(),dto.getFoSdrReportable(),dto.getFoJurisdiction(), dto.getFoRepFlag(), dto.getReconId(), dto.getCptyClassification(), dto.getReportingJurisdiction());
		
	}
	/** 
	 * Returns all rows from the recon_timeliness_fo table that match the criteria ''.
	 */
	@Transactional
	public List<ReconTimelinessFO> findAll() throws TimelinessDomainException {
		try {
			return jdbcTemplate.query("SELECT fo_system, fo_asset_class, fo_product,fo_sub_product , fo_exec_date, execution_date, fo_tlc_exec_date, fo_market_type, fo_trade_status, fo_trade_id, fo_trade_version, fo_usi, fo_sdr_eligible_trade, reporting_party, sdr_eligibility, fo_sdr_reportable, fo_jurisdiction, fo_rep_flag,recon_id, fo_cpty_clarification, fo_reporting_jurisdiction   FROM " + getTableName()+ "", this);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return TimelinessDomain
	 */
	@Override
	public ReconTimelinessFO mapRow(ResultSet rs, int row) throws SQLException
	{
		ReconTimelinessFO dto = new ReconTimelinessFO();
		dto.setFoSystem(rs.getString(1));
		dto.setFoAssetClass(rs.getString(2));
		dto.setFoProduct(rs.getString(3));
		dto.setFoSubProduct(rs.getString(4));
		dto.setFoExecDate(Long.parseLong(null!=rs.getString(5)?rs.getString(4):"0"));
		dto.setExecutionDate(Long.parseLong(null!=rs.getString(6)?rs.getString(5):"0"));
		dto.setFoTlcExecDate(Long.parseLong(null!=rs.getString(7)?rs.getString(6):"0"));
		dto.setFoMarketType(rs.getString(8));
		dto.setFoTradeStatus(rs.getString(9));
		dto.setFoTradeId(rs.getString(10));
		dto.setFoTradeVersion(rs.getString(11));
		dto.setFoUsi(rs.getString(12));
		dto.setFoSdrEligibleTrade(rs.getString(13));
		dto.setReportingParty(rs.getString(14));
		dto.setSdrEligibility(rs.getString(15));
		dto.setFoSdrReportable(rs.getString(16));
		dto.setFoJurisdiction(rs.getString(17));
		dto.setFoRepFlag(rs.getString(18));
		dto.setReconId(rs.getString(19));
		dto.setCptyClassification(rs.getString(20));
		dto.setReportingJurisdiction(rs.getString(21));
		
		return dto;
	}
	
	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recon_timeliness_fo";
	}
	

}
