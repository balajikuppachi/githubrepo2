package com.wf.df.sdr.service.csvloader.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wf.df.sdr.commons.TimelinessUtils;

public class DateUtil {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	/*Get yesterday's date*/
	/*public static String yesterdayDate=DateUtil.getYesterdayDateString();*/
	
	private final static String OUTDATE = "9999-12-31";
	
	public static Date getDateFromString(String date){
		Date formattedDate=null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			if(StringUtils.isNotBlank(date))
				formattedDate=sdf.parse(date);
			else
				formattedDate=sdf.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static Date convertCalypsoUTCtoLocalTime(String date){
		DateTime formattedDate=null;
		DateTimeFormatter sdf =  DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ssZ");//2014-05-19T07:45:54-04:01
		sdf.withZoneUTC();
		try {
			if(StringUtils.isNotBlank(date))
				formattedDate=sdf.parseDateTime(date);
			else
				formattedDate=sdf.parseDateTime(OUTDATE+"T00:00:00EDT");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate.toDate();
	}
	
	public static Date getTimestampFromString(String date) {
		Date formattedDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			if (StringUtils.isNotBlank(date))
				formattedDate = sdf.parse(date);
			else
				formattedDate = sdf.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static Date getTimestampFromStringAcceptedEq(String date) {
		Date formattedDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			if (StringUtils.isNotBlank(date)){
				sdf.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
				formattedDate = sdf.parse(date);
			}
			else
				formattedDate = sdf.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static Date getTimestampFromStringRejectedEq(String date) {
		Date formattedDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSSSSS aaa");
		try {
			if (StringUtils.isNotBlank(date)){
				sdf.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
				formattedDate = sdf.parse(date);
			}
			else
				formattedDate = sdf.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static Date getTimestampFromStringIr(String date){
		Date formattedDate=null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T' HH:mm:ss");
		try {
			if(StringUtils.isNotBlank(date)){
				sdf.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
				formattedDate=sdf.parse(date);
			}
			else
				formattedDate=sdf.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	/*public static Date convertGalaxyUTCtoLocalTime(String utcDateTime) {
		Date localDate = null;
		SimpleDateFormat sdfParser;
		sdfParser = new SimpleDateFormat("MM/dd/yy hh:mm:ss.SSS aa zzz");
		sdfParser.setTimeZone(DateUtils.UTC_TIME_ZONE);
		try {
			if (StringUtils.isNotBlank(utcDateTime)) {
				localDate = sdfParser.parse(utcDateTime);
			} else
				localDate = sdfParser.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return localDate;
	}*/
	public static Date getTimestampFromStringCr(String date){
		Date formattedDate=null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			if(StringUtils.isNotBlank(date)){
				sdf.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
				formattedDate=sdf.parse(date);
			}
			else
				formattedDate=sdf.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static Date getTimestampFromStringFx(String date){
		Date formattedDate=null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		try {
			if(StringUtils.isNotBlank(date)){
				sdf.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
				formattedDate=sdf.parse(date);
			}
			else
				formattedDate=sdf.parse(OUTDATE+"T00:00:00Z");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static String formatTimeStampForReport(Long timeStamp){
		if(null==timeStamp)
			return "";
		else
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date(timeStamp.longValue()));
	}
    
	// 	Endur date pattern
	public static Date getDateFromEndurDateFromat(String date){
		Date formattedDate=null;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aaa");
		try {
			if(StringUtils.isNotBlank(date))
				formattedDate=sdf.parse(date);
			else
				formattedDate=sdf.parse(OUTDATE);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static Date getTimestampFromStringForDiff(String date){
		Date formattedDate=null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		try {
			if(!TimelinessUtils.IsNullOrBlank(date))
				formattedDate=sdf.parse(date);
			} catch (ParseException e) {
			e.printStackTrace();
		}
		return formattedDate;
	}

	public static String reportFormattedTimeDifference(long elapsedTimeFoSdrUpload) {
		if(elapsedTimeFoSdrUpload < 1L)
			return Constants.EMPTY_STRING;
		
		long diffSeconds = elapsedTimeFoSdrUpload / 1000 % 60;
		long diffMinutes = elapsedTimeFoSdrUpload / (60 * 1000) % 60;
		long diffHours = elapsedTimeFoSdrUpload / (60 * 60 * 1000) % 24;
		long diffDays = elapsedTimeFoSdrUpload / (24 * 60 * 60 * 1000);
		
		if(diffDays != 0)
			return diffDays+" days "+(diffHours==0?"00":diffHours<10?"0"+diffHours:diffHours)+":"+(diffMinutes==0?"00":diffMinutes<10?"0"+diffMinutes:diffMinutes)+":"+(diffSeconds==0?"00":diffSeconds<10?"0"+diffSeconds:diffSeconds);
		else
			return (diffHours==0?"00":diffHours<10?"0"+diffHours:diffHours)+":"+(diffMinutes==0?"00":diffMinutes<10?"0"+diffMinutes:diffMinutes)+":"+(diffSeconds==0?"00":diffSeconds<10?"0"+diffSeconds:diffSeconds);
	}
	
	public Date convertUTCtoLocalTime(String utcDateTime) {
		Date localDate = null;
		SimpleDateFormat sdfParser;
		//create a new Date object using the UTC timezone
		sdfParser = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssXXX");
		sdfParser.setTimeZone(DateUtils.UTC_TIME_ZONE);
		try {
			localDate = sdfParser.parse(utcDateTime);
		} catch (ParseException e) {
			logger.info("Could not parse Date:"+ utcDateTime +"\nError "+ e.getMessage());
			logger.error(e.getMessage());
		}
		return localDate;
		}
	
	public static String getYesterdayDateString() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		if(cal.get(Calendar.DAY_OF_WEEK)==2)
			cal.add(Calendar.DAY_OF_MONTH, -3);
		else
			cal.add(Calendar.DAY_OF_MONTH, -1);
		return dateFormat.format(cal.getTime());
	}
	
	public static Date convertTimeStampToDate(String timeStamp)
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		return dateFormat.parse(timeStamp);
	}
	
	public static boolean dateComparision(String dateTime){
		
		Date yesterdayDateToReturn=null,comparedDate=null;
		try {
			yesterdayDateToReturn = convertTimeStampToDate(getYesterdayDateString());
			comparedDate=convertTimeStampToDate(dateTime);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (yesterdayDateToReturn.compareTo(comparedDate) == 0)
			return true;
		
		return false;
	}
	
	public static boolean compareDate(String providedDate, String executionDate)
	{
		Date execDate = null;
		Date provDate = null;
		if(TimelinessUtils.IsNullOrBlank(providedDate) || TimelinessUtils.IsNullOrBlank(executionDate))
			return false;
		try {
			execDate = convertTimeStampToDate(executionDate);
			provDate = convertTimeStampToDate(providedDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(execDate.compareTo(provDate) == 0)
			return true;
		return false;
		
	}
}
