package com.wf.df.sdr.service;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.TimelinessDao;
import com.wf.df.sdr.dao.spring.TimelinessExtnDao;
import com.wf.df.sdr.dto.TimelinessDomain;

import com.wf.df.sdr.service.csvloader.beans.DtccCrBean;
import com.wf.df.sdr.service.csvloader.beans.DtccEqBean;
import com.wf.df.sdr.service.csvloader.beans.DtccFxBean;
import com.wf.df.sdr.service.csvloader.beans.DtccIrBean;
import com.wf.df.sdr.service.csvloader.beans.ResultBean;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

@Component
@ManagedResource(description="IRS table Updater")
public class TimelinessTableUpdaterService {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	TimelinessDao timelinessDao;
	
	@Autowired
	TimelinessExtnDao timelinessExtnDao;
	
	/*@Value("${timeliness.date.flag}")
	boolean isDateProvided;
	
	@Value("${timeliness.date.value}")
	String dateProvided;
	*/
	/*Update Timeliness Table for IRS data*/
	@ManagedOperation(description="IRS table Updater")
	public void updateForIrsInfo(){
		
		String yesterdayDate = new DateUtil().getYesterdayDateString();
		
		logger.info("Started 1STR updates for yesterday's date : "+yesterdayDate);
		
		try {
			/*Fetch all to be reported trades from Timeliness table and update the IRS details*/
			List<TimelinessDomain> reportTradeList = timelinessDao.findAll();
			
			Long elapsedTimeFoSdrUpload=0L;
			
			/*
			 * Get T-1 RT details for the trades in 1STR
			 */
			Map<String,ResultBean> irsSuccessCommTrades=timelinessExtnDao.fetchImsDataForComm(yesterdayDate); 
			Map<String,ResultBean> irsRTIRCREQTrades=timelinessExtnDao.getIrsRtDetails(yesterdayDate);
			
			for(TimelinessDomain dto : reportTradeList){
				
				boolean recordFound=false;
				
				TimelinessDomain domain = new TimelinessDomain();
				/*Set the key*/
				domain.setFoTradeId(dto.getFoTradeId());
				domain.setFoTradeVersion(dto.getFoTradeVersion());

				if(dto.getAssetClass().equals(Constants.ASSET_CLASS_COMMODITY))
				{
					if(!TimelinessUtils.IsNullOrBlank(irsSuccessCommTrades) && irsSuccessCommTrades.values().size()>0){
						String key=dto.getFoTradeId()+":"+dto.getFoTradeVersion();
						ResultBean result=irsSuccessCommTrades.get(key);
						if(!TimelinessUtils.IsNullOrBlank(result)){
							irsSuccessCommTrades.remove(key);
							recordFound=true;
							String usi=result.getImsUsi();
							String imsDate=result.getImsCreateDatetime();
							String elapsedSdrDate=result.getBdCreateDatetime();
							domain.setIrsUsi(usi);
							domain.setIrsRecvTimestamp(imsDate);
							//domain.setIrsMsgType(result.getirsmsgtype());
							//domain.setIrsMsgType(result.getirsMsgStatus());
							//domain.setIrsMsgType(result.getirsDescription());
							if(!TimelinessUtils.IsNullOrBlank(elapsedSdrDate))
								elapsedTimeFoSdrUpload=DateUtil.getTimestampFromStringForDiff(elapsedSdrDate).getTime();
							}
						}
					domain.setIrsReportUploadTime(elapsedTimeFoSdrUpload);

				} else {
					if(!TimelinessUtils.IsNullOrBlank(irsRTIRCREQTrades) && irsRTIRCREQTrades.size()>0){
						String key=dto.getFoTradeId()+":"+dto.getFoTradeVersion();
						ResultBean result=irsRTIRCREQTrades.get(key);
						if(!TimelinessUtils.IsNullOrBlank(result)){
							irsRTIRCREQTrades.remove(key);
							recordFound=true;
							String usi=result.getImsUsi();
							String irsSendId=result.getIrsSendId();
							String irsDtccUsi=result.getMapIrsDtccUsi();
							String imsDate=result.getImsCreateDatetime();
							String elapsedSdrDate=result.getBdCreateDatetime();
							String imsSrcTlsEvent=result.getImsSrcTlcEvent();
							domain.setIrsSendId(irsSendId);
							domain.setIrsUsi(usi);
							domain.setIrsDtccUsi(irsDtccUsi);
							domain.setIrsTransactionType(imsSrcTlsEvent);
							domain.setIrsRecvTimestamp(imsDate);
							//domain.setIrsMsgType(result.getirsmsgtype());
							//domain.setIrsMsgType(result.getirsMsgStatus());
							//domain.setIrsMsgType(result.getirsDescription());
							if(!TimelinessUtils.IsNullOrBlank(elapsedSdrDate))
								elapsedTimeFoSdrUpload=DateUtil.getTimestampFromStringForDiff(elapsedSdrDate).getTime();
							//elapsedTimeFoSdrUpload=DateUtil.getTimestampFromTable(elapsedSdrDate).getTime()-dto.getElapsedTimeFoSdrUpload();
						}
					}
					domain.setIrsReportUploadTime(elapsedTimeFoSdrUpload);
				}

				/*Update the existing record*/
				if(recordFound)
					timelinessDao.updateIrsDetails(domain);
				
			}
			
			/*
			 * Insert the left over trades for Commodity
			 * */
			
			for (Map.Entry<String, ResultBean> entry : irsSuccessCommTrades.entrySet()) {
				ResultBean resultValue=entry.getValue();
				TimelinessDomain timeliness=new TimelinessDomain();
				timeliness.setSystem(Constants.IRS);
				timeliness.setAssetClass(Constants.ASSET_CLASS_COMMODITY);
				timeliness.setIrsTradeId(resultValue.getImsSrcTradeId());
				timeliness.setIrsTradeVersion(resultValue.getImsSrcTradeVersion());
				timeliness.setIrsUsi(resultValue.getImsUsi());
				timeliness.setFoExecDate(0L);
				timeliness.setExecutionDate(DateUtil.getTimestampFromStringForDiff(resultValue.getImsExecDatetime()).getTime());
				timeliness.setFoTlcExecDate(0L);
				timeliness.setIrsRecvTimestamp(resultValue.getImsCreateDatetime());
				timeliness.setIrsReportUploadTime(DateUtil.getTimestampFromStringForDiff(resultValue.getBdCreateDatetime()).getTime());
				timeliness.setSdrSubmissionTime(0L);
				timeliness.setFoRepFlag(Constants.N);
				timeliness.setIrsRepFlag(Constants.N);
				timeliness.setGtrRepFlag(Constants.N);
				//domain.setIrsMsgType(result.getirsmsgtype());
				//domain.setIrsMsgType(result.getirsMsgStatus());
				//domain.setIrsMsgType(result.getirsDescription());
				timelinessDao.insert(timeliness);
				
			}
			
			/*
			 * Insert the left over trades for IR, CR and EQ
			 * */
			
			for (Map.Entry<String, ResultBean> entry : irsRTIRCREQTrades.entrySet()) {
				ResultBean resultValue=entry.getValue();
				TimelinessDomain timeliness=new TimelinessDomain();
				timeliness.setSystem(Constants.IRS);
				timeliness.setAssetClass(resultValue.getIrsAssetClass());
				timeliness.setProduct(!TimelinessUtils.IsNullOrBlank(resultValue.getIrsProductType())?resultValue.getIrsProductType():Constants.EMPTY_STRING);
				timeliness.setFoExecDate(0L);
				Date execDate = DateUtil.getTimestampFromStringForDiff(resultValue.getIrsExecDateTime());
				timeliness.setExecutionDate(!TimelinessUtils.IsNullOrBlank(execDate)?execDate.getTime():0L);
				//timeliness.setExecutionDate(0L);
				timeliness.setFoTlcExecDate(0L);
				timeliness.setIrsRecvTimestamp(resultValue.getImsCreateDatetime());
				timeliness.setIrsSendId(resultValue.getIrsSendId());
				timeliness.setIrsTradeId(resultValue.getImsSrcTradeId());
				timeliness.setIrsTradeVersion(resultValue.getImsSrcTradeVersion());
				timeliness.setIrsUsi(resultValue.getImsUsi());
				timeliness.setIrsDtccUsi(resultValue.getMapIrsDtccUsi());
				timeliness.setIrsTransactionType(!TimelinessUtils.IsNullOrBlank(resultValue.getImsSrcTlcEvent())?resultValue.getImsSrcTlcEvent():Constants.EMPTY_STRING);	// Get the data from the mapping sheet
				Date elapsedFoSdrUp = DateUtil.getTimestampFromStringForDiff(resultValue.getBdCreateDatetime());
				timeliness.setIrsReportUploadTime(!TimelinessUtils.IsNullOrBlank(elapsedFoSdrUp)?elapsedFoSdrUp.getTime():0L);
				timeliness.setSdrSubmissionTime(0L);
				timeliness.setFoRepFlag(Constants.N);
				timeliness.setIrsRepFlag(Constants.N);
				timeliness.setGtrRepFlag(Constants.N);
				//domain.setIrsMsgType(result.getirsmsgtype());
				//domain.setIrsMsgType(result.getirsMsgStatus());
				//domain.setIrsMsgType(result.getirsDescription());
				timelinessDao.insert(timeliness);
				
			}
		} catch (Exception e) {
			 logger.error(e.getMessage());
			 e.printStackTrace();
		} 
		logger.info("Completed 1STR updates");
	}
	
	/*Update Timeliness Table for IR DTCC*/
	public void updateForDtccIrInfo(List<DtccIrBean> beanList){
		Collections.sort(beanList, new DtccIrComparator());
		TimelinessDomain domain = new TimelinessDomain();
		
		/*
		 * Map IR fields to Timeliness columns
		 */
		for(DtccIrBean trade : beanList){
			domain.setAssetClass(Constants.ASSET_CLASS_INTEREST_RATE);
			domain.setIrsTradeId(trade.getTradeParty1ReferenceNumber());
			domain.setIrsUsi(trade.getUsiNamespace()+trade.getUsi());
			//domain.setIrsTransactionType(trade.getTransactionType());
			
			domain.setGtrUsi(trade.getUsiNamespace()+trade.getUsi());
			domain.setSdrSubmissionTime(trade.getSubmissionDateTime().getTime());
			domain.setDtccRespAcceptance(trade.getStatus());
			
			timelinessDao.updateDtccDetailsUsingIrsKey(domain);

		}
			/*
			String tradeDetails[]=null;
			String dataSubmitter=bean.getDataSubmitter();
			if(!TimelinessUtils.IsNullOrBlank(dataSubmitter))
				{
					if(dataSubmitter.contains(Constants.TRANS_ID_SEPARATOR)){
						tradeDetails=dataSubmitter.split(Constants.TRANS_ID_SEPARATOR);
						if(tradeDetails.length>1){
								domain.setFoTradeId(tradeDetails[0]);
								domain.setFoTradeVersion(tradeDetails[1]);
						}
					}
				}
			domain.setGtrUsi(bean.getUsiNamespace()+bean.getUsi());
			domain.setDtccRespAcceptance(bean.getStatus());
			Calculate time difference
			domain.setElapsedTimeFoResponseRt(calculateDtccTimeDifference(tradeDetails[0],tradeDetails[1],bean.getSubmissionDateTime()));
			domain.setDtccRespAcceptance(bean.getStatus());
			if(domain.getElapsedTimeFoResponseRt()!=0L)
			{
				timelinessDao.updateDtccDetails(domain);
			}
		}
	*/}
	
	
	/*Update Timeliness Table for CR DTCC*/
	public void updateForDtccCrInfo(List<DtccCrBean> beanList){
		Collections.sort(beanList, new DtccCrComparator());
		TimelinessDomain domain = new TimelinessDomain();
		/*Map CR fields to Timeliness columns*/
		for(DtccCrBean trade : beanList){
			domain.setAssetClass(Constants.ASSET_CLASS_CREDIT);
			domain.setIrsTradeId(trade.getTradeParty1ReferenceNumber());
			domain.setIrsUsi(trade.getUsi());
			//domain.setIrsTransactionType(trade.getTransactionType());
			
			domain.setGtrUsi(trade.getUsi());
			domain.setSdrSubmissionTime(trade.getSubmissionDateTime().getTime());
			domain.setDtccRespAcceptance(trade.getStatus());
			
			timelinessDao.updateDtccDetailsUsingIrsKey(domain);
		}
		/*
			String tradeDetails[]=null;
			String dataSubmitter=bean.getDataSubmitter();
			if(!TimelinessUtils.IsNullOrBlank(dataSubmitter))
			{
				if(dataSubmitter.contains(Constants.TRANS_ID_SEPARATOR)){
					tradeDetails=bean.getDataSubmitter().split(Constants.TRANS_ID_SEPARATOR);
					if(tradeDetails.length>1){
						domain.setFoTradeId(tradeDetails[0]);
						domain.setFoTradeVersion(tradeDetails[1]);
					}
				}
			}
				
			domain.setGtrUsi(bean.getUsi());
			domain.setDtccRespAcceptance(bean.getStatus());
			Calculate time difference
			domain.setElapsedTimeFoResponseRt(calculateDtccTimeDifference(tradeDetails[0],tradeDetails[1],bean.getSubmissionDateTime()));
			domain.setDtccRespAcceptance(bean.getStatus());
			if(domain.getElapsedTimeFoResponseRt()!=0L)
			{
				timelinessDao.updateDtccDetails(domain);
			}
		}*/		
	}
	
	/*Update Timeliness Table for FX DTCC*/
	public void updateForDtccFxInfo(List<DtccFxBean> beanList){
		TimelinessDomain domain = new TimelinessDomain();
		/*Map FX fields to Timeliness columns*/
		for(DtccFxBean bean : beanList){
			String tradeDetails[]=null;
			String dataSubmitter=bean.getDataSubmitter();
			if(!TimelinessUtils.IsNullOrBlank(dataSubmitter))
				{
					if(dataSubmitter.contains(Constants.TRANS_ID_SEPARATOR)){
						tradeDetails=dataSubmitter.split(Constants.TRANS_ID_SEPARATOR);
						if(tradeDetails.length>1){
								domain.setFoTradeId(tradeDetails[0]);
								domain.setFoTradeVersion(tradeDetails[1]);
						}
					}
				}
			domain.setGtrUsi(bean.getUsiPrefix()+bean.getUsiValue());
			domain.setDtccRespAcceptance(bean.getStatus());
			/*Calculate time difference*/
			domain.setSdrSubmissionTime(bean.getSubmissionDateTime().getTime());
			domain.setDtccRespAcceptance(bean.getStatus());
			if(domain.getSdrSubmissionTime()!=0L)
			{
				timelinessDao.updateDtccDetails(domain);
			}
		}
	}
	
	public void updateForDtccEqInfo(List<DtccEqBean> beanList){
				for(DtccEqBean bean : beanList){
				String tradeData[]=null;
				String party1transId=bean.getParty1TransactionId();
				//if(null!=party1transId && !party1transId.equalsIgnoreCase(Constants.EMPTY_STRING))
				if(!TimelinessUtils.IsNullOrBlank(party1transId))
				{
					if(party1transId.contains(Constants.TRANS_ID_SEPARATOR))
					{
						 tradeData= party1transId.split(Constants.TRANS_ID_SEPARATOR);
						if(tradeData.length>2)
						{
								updateEqInTimeliness(tradeData[1],tradeData[2],bean);	
						}
					}
				}
				
			}	
		}

	private void updateEqInTimeliness(String tradeId, String tradeRevision, DtccEqBean bean) {
		
		TimelinessDomain domain = new TimelinessDomain();
		domain.setFoTradeId(tradeId);
		domain.setFoTradeVersion(tradeRevision);
		domain.setGtrUsi(bean.getUsiPrefix()+bean.getUsiValue());
		/*Calculate time difference*/
		domain.setSdrSubmissionTime(bean.getSubmissionDateTime().getTime());
		domain.setDtccRespAcceptance(bean.getStatus());
		/*To avoid update call if no entry in table*/
		if(domain.getSdrSubmissionTime()!=0L)
		{
				timelinessDao.updateDtccDetails(domain);
		}				
	}
	
	/*@ManagedOperation(description="ICE Data Updater")
	public void updateICETimeliness(){
		try{
		List<TimelinessDomain> reportTradeList = timelinessDao.findWhereAssetClassEquals(Constants.ASSET_CLASS_COMMODITY);
		if(reportTradeList.size()>0){
			for(TimelinessDomain timelinessRecord:reportTradeList){
				TimelinessDomain domain =null;
				List<String> dataList= timelinessExtnDao.fetchDataForDTCCForComm(timelinessRecord.getFoTradeVersion(), timelinessRecord.getFoTradeId());
				if(dataList.size()>0){
					domain = new TimelinessDomain();
					domain.setFoTradeId(timelinessRecord.getFoTradeId());
					domain.setFoTradeVersion(timelinessRecord.getFoTradeVersion());
					String gtrUsi=dataList.get(0);
					String gtrStatus=dataList.get(1);
					domain.setGtrUsi(null!=gtrUsi?gtrUsi:null);
					domain.setDtccRespRecv(null!=gtrStatus?(gtrStatus.equals(Constants.ERROR)?Constants.NO:Constants.YES):null);
					domain.setDtccRespAcceptance(null!=gtrStatus?gtrStatus:null);
					domain.setElapsedTimeFoResponseRt(timelinessRecord.getElapsedTimeFoResponseRt());
				}
				if(null!=domain)
					timelinessDao.updateDtccDetails(domain);
			}
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}*/
	
	@ManagedOperation(description="ICE Data Updater")
	public void updateICETimeliness(){
		
		String yesterdayDate = new DateUtil().getYesterdayDateString();
		
		logger.info("Started ICE updates for date : " + yesterdayDate);
		
		try{
		List<TimelinessDomain> reportTradeList = timelinessDao.findWhereAssetClassEquals(Constants.ASSET_CLASS_COMMODITY);
		Long elapsedTimeForResponseRt=0L;
		String tradeId=null,tradeVersion=null;
		boolean flag=false;
		if(reportTradeList.size()>0){
			for(TimelinessDomain timelinessRecord:reportTradeList){
				TimelinessDomain domain =new TimelinessDomain();
				if(TimelinessUtils.IsNullOrBlank(timelinessRecord.getFoTradeId())&&TimelinessUtils.IsNullOrBlank(timelinessRecord.getFoTradeVersion())){
					tradeId=timelinessRecord.getIrsTradeId();
					tradeVersion=timelinessRecord.getIrsTradeVersion();
					//executionDate=timelinessRecord.getSdrRecvTimestamp();
					domain.setIrsTradeId(tradeId);
					domain.setIrsTradeVersion(tradeVersion);
					flag=true;
				}else{
						tradeId=timelinessRecord.getFoTradeId();
						tradeVersion=timelinessRecord.getFoTradeVersion();
						//executionDate=timelinessRecord.getExecutionDate();
						domain.setFoTradeId(tradeId);
						domain.setFoTradeVersion(tradeVersion);
				}
					
				List<String> dataList= timelinessExtnDao.fetchStatusForComm(tradeId,tradeVersion,yesterdayDate);
				if(dataList.size()>0){
					String gtrStatus=null,gtrUsi=null, mtrMsgType=null;
					String sendId = dataList.get(0);
					String traceId=dataList.get(1);
					String mappingEncStatus=dataList.get(2);
					if(mappingEncStatus.equals(Constants.SUCCESS)){
						domain.setDtccRespRecv(Constants.Y);
					}
					if(!traceId.equals(Constants.NOTFOUND) && !TimelinessUtils.IsNullOrBlank(traceId)){
						List<String> emsList= timelinessExtnDao.fetchEmsQueryResult(sendId,traceId,yesterdayDate);
						mtrMsgType=emsList.get(0);
						gtrStatus=emsList.get(1);
						gtrUsi=emsList.get(2);
						domain.setGtrUsi(gtrUsi);
					} else {
						domain.setDtccRespAcceptance(Constants.ACCEPTED);
						/*
						 * Ritesh informed to Store ICE usi same as IRS usi 
						 * since we will not have trace_id for lifecycle event 
						 * as a result endur_msg_store entry cannot be figured 
						 * for fetching USI.
						 */
						domain.setGtrUsi(timelinessRecord.getIrsUsi());
					}
					if(!TimelinessUtils.IsNullOrBlank(mtrMsgType) && !TimelinessUtils.IsNullOrBlank(gtrStatus) ) {
					 if(mtrMsgType.equals("2") && gtrStatus.equals(Constants.ERROR)){
						domain.setDtccRespAcceptance(Constants.REJECTED);
					}else if(mtrMsgType.equals("37") || mtrMsgType.equals("5")|| mtrMsgType.equals("2") )
					{
						domain.setDtccRespAcceptance(Constants.ACCEPTED);
					}
					}
					
					/**
					 * As per Ritesh we populate both the columns same value( sdr upload time,response rt)
					 */
						domain.setSdrSubmissionTime(timelinessRecord.getIrsReportUploadTime());
					
				}else{
					domain.setDtccRespRecv(Constants.N);
					domain.setSdrSubmissionTime(elapsedTimeForResponseRt);
				}
				  if(flag==true){
					  timelinessDao.updateICESTRDetails(domain);
				  }else
					  timelinessDao.updateICEDetails(domain);
			}
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		logger.info("Completed ICE updates");
	}

	class DtccIrComparator implements Comparator<DtccIrBean> {

		@Override
		public int compare(DtccIrBean bean1, DtccIrBean bean2) {
			if (bean1.getSubmissionDateTime().compareTo(
					bean2.getSubmissionDateTime()) > 0)
				return 1;
			else if (bean1.getSubmissionDateTime().compareTo(
					bean2.getSubmissionDateTime()) < 0)
				return -1;

			return 0;
		}
	}
	
	class DtccCrComparator implements Comparator<DtccCrBean> {

		@Override
		public int compare(DtccCrBean bean1, DtccCrBean bean2) {
			if (bean1.getSubmissionDateTime().compareTo(
					bean2.getSubmissionDateTime()) > 0)
				return 1;
			else if (bean1.getSubmissionDateTime().compareTo(
					bean2.getSubmissionDateTime()) < 0)
				return -1;

			return 0;
		}
	}
	
	
}
