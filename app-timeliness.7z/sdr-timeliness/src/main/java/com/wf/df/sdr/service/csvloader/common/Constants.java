package com.wf.df.sdr.service.csvloader.common;

/**
 * Class contains constants used across the application
 * 
 * @author U168247
 * 
 */
public class Constants {

	
	// asset type and report type
	public static final String ASSET_CLASS_INTEREST_RATE = "InterestRate";
	public static final String ASSET_CLASS_CREDIT = "Credit";
	public static final String ASSET_CLASS_EQUITY = "Equity";
	public static final String ASSET_CLASS_FOREX = "ForeignExchange";
	public static final String FX = "FX";
	public static final String ASSET_CLASS_COMMODITY = "Commodity";
	
	public static final String ICE = "ICE";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String ENDUR = "Endur";
	public static final String CALYPSO = "Calypso";
	public static final String GALAXY = "Galaxy";
	public static final String TRANS_ID_SEPARATOR=":";
	public static final String EMPTY_STRING="";
	public static final String ORIGINATION="Origination";
	public static final String RT="RT";
	public static final Object PET = "PET";
	public static final String Y="Y";
	public static final String N="N";
	public static final String ERROR="ERROR";
	public static final String SUCCESS="SUCCESS";
	public static final String PENDING="PENDING";
	public static final String PPENDING="PPENDING";
	public static final String ACCEPTED="ACCEPTED";
	public static final String EQ_ACCEPTED="Accepted";
	public static final String REJECTED="REJECTED";
	public static final	String NOTFOUND="NOT FOUND";
	
	public static final String FAILURE="FAILURE";
	public static final String NEW_DEAL = "New Deal";
	public static final String SEPERATOR = ",";
	public static final String TimelinessFileName = "TimelinessReport";
	public static final String QUOTES = "\"";
	public static final String IRS = "1STR";
	public static final String GTR = "GTR";
	public static final String UTC = "UTC";
	public static final String RATES = "rates";
	public static final String DTCC_CR_USI_REPLACE = "-";
	public static final String UNIQUEID = "UniqueId:";
	public static final String TimelinessDebugFileName = "TimelinessDebug_Report";
	public static final String FALSE = "FALSE";
	public static final String Compressed_Term = "Compressed - Term";
	public static final String Compressed_PartialTerm = "Compressed - Partial Term";
	public static final String TRUE = "TRUE";
	public static final String CFTC = "CFTC";
	public static final String FOR_SEPERATOR="FOR :";
	public static final String BACKSLASH = "/";
	public static final String SENT = "SENT";
	public static final String NOT_ELIGIBLE_FOR = "Not Eligible For ";
	public static final String COLON = ":";
	public static final String NOT_TO_SEND = "NOT_TO_SEND";
	public static final String DUPLICATE = "DUPLICATE";
	public static final String TIMELINESSEMAIL = "timelinessEmail";
	public static final String RECON_ID = "RECON_ID";
	public static final String US = "Us";
	public static final String NEW = "NEW";
	public static final String CFTCUS="CFTC.Us";
	public static final String CANCEL="CANCELED";
	public static final String INTERNAL = "Internal";
	public static final String NONE = "NONE";
	
}
