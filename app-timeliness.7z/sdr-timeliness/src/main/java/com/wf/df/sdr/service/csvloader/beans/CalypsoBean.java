package com.wf.df.sdr.service.csvloader.beans;


public class CalypsoBean implements BaseBean{

	private String system;
	private String tradeId;
	private String tradeVersion;
	private String tradeStatus;
	private String assetClass;
	private String productType;
	private String subProductType;
	private String tlcExecutionDatetime;
	private String emirDelegatedReportingElection;
	private String emirReportable;
	private String emirReportingParty;
	private String executionDatetime;
	private String reportingParty;
	private String sdrBackload;
	private String sdrEligible;
	private String sdrMarketType;
	private String sdrReportable;
	private String usiCurrent;
	private String utiCurrent;
	private String cptyClassification;
	private String reportingJurisdiction;
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getTradeVersion() {
		return tradeVersion;
	}
	public void setTradeVersion(String tradeVersion) {
		this.tradeVersion = tradeVersion;
	}
	public String getTradeStatus() {
		return tradeStatus;
	}
	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getSubProductType() {
		return subProductType;
	}
	public void setSubProductType(String subProductType) {
		this.subProductType = subProductType;
	}
	public String getTlcExecutionDatetime() {
		return tlcExecutionDatetime;
	}
	public void setTlcExecutionDatetime(String tlcExecutionDatetime) {
		this.tlcExecutionDatetime = tlcExecutionDatetime;
	}
	public String getEmirDelegatedReportingElection() {
		return emirDelegatedReportingElection;
	}
	public void setEmirDelegatedReportingElection(
			String emirDelegatedReportingElection) {
		this.emirDelegatedReportingElection = emirDelegatedReportingElection;
	}
	public String getEmirReportable() {
		return emirReportable;
	}
	public void setEmirReportable(String emirReportable) {
		this.emirReportable = emirReportable;
	}
	public String getEmirReportingParty() {
		return emirReportingParty;
	}
	public void setEmirReportingParty(String emirReportingParty) {
		this.emirReportingParty = emirReportingParty;
	}
	public String getExecutionDatetime() {
		return executionDatetime;
	}
	public void setExecutionDatetime(String executionDatetime) {
		this.executionDatetime = executionDatetime;
	}
	public String getReportingParty() {
		return reportingParty;
	}
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}
	public String getSdrBackload() {
		return sdrBackload;
	}
	public void setSdrBackload(String sdrBackload) {
		this.sdrBackload = sdrBackload;
	}
	public String getSdrEligible() {
		return sdrEligible;
	}
	public void setSdrEligible(String sdrEligible) {
		this.sdrEligible = sdrEligible;
	}
	public String getSdrMarketType() {
		return sdrMarketType;
	}
	public void setSdrMarketType(String sdrMarketType) {
		this.sdrMarketType = sdrMarketType;
	}
	public String getSdrReportable() {
		return sdrReportable;
	}
	public void setSdrReportable(String sdrReportable) {
		this.sdrReportable = sdrReportable;
	}
	public String getUsiCurrent() {
		return usiCurrent;
	}
	public void setUsiCurrent(String usiCurrent) {
		this.usiCurrent = usiCurrent;
	}
	public String getUtiCurrent() {
		return utiCurrent;
	}
	public void setUtiCurrent(String utiCurrent) {
		this.utiCurrent = utiCurrent;
	}
	public String getCptyClassification() {
		return cptyClassification;
	}
	public void setCptyClassification(String cptyClassification) {
		this.cptyClassification = cptyClassification;
	}
	public String getReportingJurisdiction() {
		return reportingJurisdiction;
	}
	public void setReportingJurisdiction(String reportingJurisdiction) {
		this.reportingJurisdiction = reportingJurisdiction;
	}
	
	@Override
	public String toString() {
		return "CalypsoBean [system=" + system + ", tradeId=" + tradeId
				+ ", tradeVersion=" + tradeVersion + ", tradeStatus="
				+ tradeStatus + ", assetClass=" + assetClass + ", productType="
				+ productType + ", subProductType=" + subProductType
				+ ", tlcExecutionDatetime=" + tlcExecutionDatetime
				+ ", emirDelegatedReportingElection="
				+ emirDelegatedReportingElection + ", emirReportable="
				+ emirReportable + ", emirReportingParty=" + emirReportingParty
				+ ", executionDatetime=" + executionDatetime
				+ ", reportingParty=" + reportingParty + ", sdrBackload="
				+ sdrBackload + ", sdrEligible=" + sdrEligible
				+ ", sdrMarketType=" + sdrMarketType + ", sdrReportable="
				+ sdrReportable + ", usiCurrent=" + usiCurrent
				+ ", utiCurrent=" + utiCurrent + ", cptyClassification="
				+ cptyClassification + ", reportingJurisdiction="
				+ reportingJurisdiction + "]";
	}
}
