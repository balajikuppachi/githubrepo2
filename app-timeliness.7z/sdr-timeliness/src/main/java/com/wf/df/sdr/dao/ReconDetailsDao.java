package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.ReconDetails;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public interface ReconDetailsDao {


	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(ReconDetails dto);

	/** 
	 * Returns all rows from the recon_details table that match the criteria ''.
	 */
	public List<ReconDetails> findAll() throws TimelinessDomainException;
	
	/** 
	 * updates recon_details table that match the criteria ''.
	 */
	public void UpdateReconDetails(ReconDetails dto) throws TimelinessDomainException;
}
