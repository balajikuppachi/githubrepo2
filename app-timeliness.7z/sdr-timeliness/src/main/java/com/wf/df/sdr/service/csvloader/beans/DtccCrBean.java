package com.wf.df.sdr.service.csvloader.beans;

import java.util.Date;


public class DtccCrBean implements BaseBean{

	private String gtrAction;
	private String transactionType;
	private String messageType;
	private String usiNamespace;
	private String usi;
	private String assetClass;
	private String productType;
	private String status;
	private String errorReason;
	private Date submissionDateTime;
	private String tradeParty1ReferenceNumber;
	//private String dataSubmitter;
	
	public String getGtrAction() {
		return gtrAction;
	}

	public void setGtrAction(String gtrAction) {
		this.gtrAction = gtrAction;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getUsiNamespace() {
		return usiNamespace;
	}

	public void setUsiNamespace(String usiNamespace) {
		this.usiNamespace = usiNamespace;
	}

	public String getUsi() {
		return usi;
	}

	public void setUsi(String usi) {
		this.usi = usi;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorReason() {
		return errorReason;
	}

	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}

	public Date getSubmissionDateTime() {
		return submissionDateTime;
	}

	public void setSubmissionDateTime(Date submissionDateTime) {
		this.submissionDateTime = submissionDateTime;
	}

	public String getTradeParty1ReferenceNumber() {
		return tradeParty1ReferenceNumber;
	}

	public void setTradeParty1ReferenceNumber(String tradeParty1ReferenceNumber) {
		this.tradeParty1ReferenceNumber = tradeParty1ReferenceNumber;
	}

	@Override
	public String toString() {
		return "DtccCrBean [gtrAction=" + gtrAction + ", transactionType="
				+ transactionType + ", messageType=" + messageType
				+ ", usiNamespace=" + usiNamespace + ", usi=" + usi
				+ ", assetClass=" + assetClass + ", productType=" + productType
				+ ", status=" + status + ", errorReason=" + errorReason
				+ ", submissionDateTime=" + submissionDateTime
				+ ", tradeParty1ReferenceNumber=" + tradeParty1ReferenceNumber
				+ "]";
	}
	
	/*public String getDataSubmitter() {
		return dataSubmitter;
	}

	public void setDataSubmitter(String dataSubmitter) {
		this.dataSubmitter = dataSubmitter;
	}*/

	
}
