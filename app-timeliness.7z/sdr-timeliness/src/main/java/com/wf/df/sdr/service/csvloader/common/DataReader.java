package com.wf.df.sdr.service.csvloader.common;

import java.io.Closeable;
import java.io.IOException;

public interface DataReader<T> extends Closeable {
	T readNext() throws IOException ;
	Location currentLocation();
}
