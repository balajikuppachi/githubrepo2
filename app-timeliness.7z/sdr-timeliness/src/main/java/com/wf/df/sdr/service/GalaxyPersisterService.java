package com.wf.df.sdr.service;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessFODao;
import com.wf.df.sdr.dao.TimelinessDao;
import com.wf.df.sdr.dto.ReconTimelinessFO;
import com.wf.df.sdr.service.csvloader.beans.GalaxyBean;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

@Component
public class GalaxyPersisterService extends BasePersisterService {

	@Autowired
	TimelinessDao timelinessDao;

	@Autowired
	ReconTimelinessFODao reconTimelinessFODao;
	
/*	@Value("${timeliness.date.flag}")
	boolean isDateProvided;
	
	@Value("${timeliness.date.value}")
	String dateProvided;*/
	
/*	public void persist(List<GalaxyBean> list) throws Exception{
		for(GalaxyBean bean : list){
			Check life cycle event and populate required time
			long execTime = 0L;
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getLceEvent()))
			{
			if(StringUtils.equals(bean.getLceEvent().trim(),Constants.ORIGINATION))
			{
				if(!TimelinessUtils.IsNullOrBlank(bean.getExecutionDate()))
				{
				execTime=DateUtil.getTimestampFromString(bean.getExecutionDate()).getTime();
				//execTime=DateUtil.convertGalaxyUTCtoLocalTime(bean.getExecutionDate()).getTime();
				}
			}
			else
			{
				if(!TimelinessUtils.IsNullOrBlank(bean.getLatestAmendmentDate()))
				{
					execTime=DateUtil.getTimestampFromString(bean.getLatestAmendmentDate()).getTime();
					//execTime=DateUtil.convertGalaxyUTCtoLocalTime(bean.getLatestAmendmentDate()).getTime();
				}
			}
			}
			
			
												
			TimelinessDomain dto = new TimelinessDomain();
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getExecutionDate()))
			{
				dto.setFoExecDate(DateUtil.getTimestampFromString(bean.getExecutionDate()).getTime());
			} else {
				dto.setFoExecDate(0L);
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getLatestAmendmentDate()))
			{
				dto.setFoTlcExecDate(DateUtil.getTimestampFromString(bean.getLatestAmendmentDate()).getTime());
			} else {
				dto.setFoTlcExecDate(0L);
			}
			dto.setFoMarketType(bean.getLceEvent());
			dto.setFoTradeStatus(bean.getTradeStatus());
			dto.setSystem(Constants.GALAXY);
			
			if(bean.getAssetClass().toLowerCase().contains("equity"))
			{
				dto.setAssetClass(Constants.ASSET_CLASS_EQUITY);
			}
			dto.setProduct(bean.getProduct());
			dto.setExecutionDate(execTime);
			dto.setIrsRecvTimestamp(Constants.EMPTY_STRING);
			dto.setFoTradeId(bean.getFoTradeId());
			dto.setFoTradeVersion(bean.getTradeVersion());
			dto.setFoUsi(bean.getFoUSI());
			dto.setFoSdrEligibleTrade(bean.getFrontOfficeFlag());
			
			 * Logic to set the reportable flag 
			 
			dto.setFoRepFlag(Constants.N);
			dto.setIrsRepFlag(Constants.N);
			dto.setGtrRepFlag(Constants.N);
			if(!TimelinessUtils.IsNullOrBlank(bean.getFoUSI()))
				dto.setFoRepFlag(Constants.Y);
			dto.setIrsUsi(Constants.EMPTY_STRING);
			//dto.setGtrUsi(null);
			dto.setIrsReportUploadTime(0L);
			dto.setDtccRespAcceptance(Constants.EMPTY_STRING);
			dto.setSdrSubmissionTime(0L);
			dto.setReportingParty(bean.getReportingPartyFlag());
			dto.setSdrEligibility(bean.getFrontOfficeFlag());
			
			Store in DB
			if(execTime!=0L &&DateUtil.dateComparision(DateUtil.formatTimeStampForReport(dto.getExecutionDate()))&& !TimelinessUtils.IsNullOrBlank(bean.getFoTradeId())&&!TimelinessUtils.IsNullOrBlank(bean.getTradeVersion()))
				timelinessDao.insert(dto);
		}
		}*/
	public String persist(List<GalaxyBean> list) throws Exception{
		
		//String yesterdayDate = isDateProvided ? dateProvided : DateUtil.yesterdayDate;
		
		String reconId=getCurrentReconId(Constants.ASSET_CLASS_EQUITY);
		String dateProvided = alterReconID(reconId);
		for(GalaxyBean bean : list){
			long execTime = 0L;
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getLceEvent()))
			{
			if(StringUtils.equals(bean.getLceEvent().trim(),Constants.ORIGINATION))
			{
				if(!TimelinessUtils.IsNullOrBlank(bean.getExecutionDate()))
				{
				execTime=DateUtil.getTimestampFromString(bean.getExecutionDate()).getTime();
				//execTime=DateUtil.convertGalaxyUTCtoLocalTime(bean.getExecutionDate()).getTime();
				}
			}
			else
			{
				if(!TimelinessUtils.IsNullOrBlank(bean.getLatestAmendmentDate()))
				{
					execTime=DateUtil.getTimestampFromString(bean.getLatestAmendmentDate()).getTime();
					//execTime=DateUtil.convertGalaxyUTCtoLocalTime(bean.getLatestAmendmentDate()).getTime();
				}
			}
			}

			ReconTimelinessFO dto = new ReconTimelinessFO();
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getExecutionDate()))
			{
				dto.setFoExecDate(DateUtil.getTimestampFromString(bean.getExecutionDate()).getTime());
			} else {
				dto.setFoExecDate(0L);
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getLatestAmendmentDate()))
			{
				dto.setFoTlcExecDate(DateUtil.getTimestampFromString(bean.getLatestAmendmentDate()).getTime());
			} else {
				dto.setFoTlcExecDate(0L);
			}
			dto.setFoMarketType(bean.getLceEvent());
			dto.setFoTradeStatus(bean.getTradeStatus());
			dto.setFoSystem(Constants.GALAXY);
			if(bean.getAssetClass().toLowerCase().contains("equity"))
			{
				dto.setFoAssetClass(Constants.ASSET_CLASS_EQUITY);
			}
			dto.setFoProduct(bean.getProduct());
			dto.setExecutionDate(execTime);
			dto.setFoTradeId(bean.getFoTradeId());
			dto.setFoTradeVersion(bean.getTradeVersion());
			dto.setFoUsi(bean.getFoUSI());
			dto.setFoSdrEligibleTrade(bean.getFrontOfficeFlag());
			dto.setFoSdrReportable(Constants.EMPTY_STRING);
			dto.setFoJurisdiction(Constants.EMPTY_STRING);
			dto.setFoRepFlag(Constants.N);
			if(!TimelinessUtils.IsNullOrBlank(bean.getFoUSI()) && (Constants.US.equalsIgnoreCase(bean.getReportingPartyFlag())|| StringUtils.containsIgnoreCase(bean.getReportingPartyFlag(), Constants.CFTCUS)))
				dto.setFoRepFlag(Constants.Y);
			dto.setReportingParty(bean.getReportingPartyFlag());
			dto.setSdrEligibility(bean.getFrontOfficeFlag());
			dto.setReconId(reconId);
			
			/*Store in DB*/
			if(execTime!=0L && (DateUtil.compareDate(dateProvided,DateUtil.formatTimeStampForReport(dto.getExecutionDate())) || DateUtil.dateComparision(DateUtil.formatTimeStampForReport(dto.getExecutionDate()))) && !TimelinessUtils.IsNullOrBlank(bean.getFoTradeId())&&!TimelinessUtils.IsNullOrBlank(bean.getTradeVersion()))
				{
					reconTimelinessFODao.insert(dto);
				}
			}
		return reconId;
		}
	private String alterReconID(String reconID) {
		
		StringBuffer sb = new StringBuffer(reconID);
		if(reconID.length()==8){
			sb.insert(4, '-');
			sb.insert(7, '-');
		}
		return 	sb.toString();		
	}
}
