package com.wf.df.sdr.dto;

import java.math.BigDecimal;
import java.util.Date;

public class ReconDetails {

	private BigDecimal id;
	private String	reconId;
	private String	reportFileName;
	private String	mailStatus;
	private Date 	runDate;
	private String reconFlag;
	
	/**
	 * @return the runDate
	 */
	public Date getRunDate() {
		return runDate;
	}
	/**
	 * @param runDate the runDate to set
	 */
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	/**
	 * @return the id
	 */
	public BigDecimal getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(BigDecimal id) {
		this.id = id;
	}
	/**
	 * @return the reconId
	 */
	public String getReconId() {
		return reconId;
	}
	/**
	 * @param reconId the reconId to set
	 */
	public void setReconId(String reconId) {
		this.reconId = reconId;
	}
	/**
	 * @return the reportFileName
	 */
	public String getReportFileName() {
		return reportFileName;
	}
	/**
	 * @param reportFileName the reportFileName to set
	 */
	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}
	/**
	 * @return the reconDateFlag
	 */
	public String getReconFlag() {
		return reconFlag;
	}
	/**
	 * @param reconFlag the reconFlag to set
	 */
	public void setReconFlag(String reconFlag) {
		this.reconFlag = reconFlag;
	}
	
	public String getMailStatus() {
		return mailStatus;
	}
	/**
	 * @param mailStatus the mailStatus to set
	 */
	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}
	
	
}
