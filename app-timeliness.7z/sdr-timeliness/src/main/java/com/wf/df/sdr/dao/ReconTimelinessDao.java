package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.ReconTimelinessDomain;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public interface ReconTimelinessDao {

	/** 
	 * Returns all rows from the domain_values table that match the criteria ''.
	 */
	public List<ReconTimelinessDomain> findAll() throws TimelinessDomainException;
	
}
