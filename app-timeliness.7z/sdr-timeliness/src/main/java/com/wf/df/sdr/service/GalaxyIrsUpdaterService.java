package com.wf.df.sdr.service;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.common.Constants;

@Component
@ManagedResource(description="Update Galaxy IRS details")
public class GalaxyIrsUpdaterService extends BaseIrsUpdaterService{

	@ManagedOperation(description="Trigger Galaxy IRS Upload")
	public void updateForIrsDetailsForGalaxySystem(String reconId){
			updateForIrsDetails(reconId,Constants.ASSET_CLASS_EQUITY);
		}
}
