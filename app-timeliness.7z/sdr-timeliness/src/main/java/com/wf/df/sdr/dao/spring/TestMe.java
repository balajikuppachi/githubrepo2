package com.wf.df.sdr.dao.spring;

import org.springframework.stereotype.Component;


@Component
public class TestMe {

}
