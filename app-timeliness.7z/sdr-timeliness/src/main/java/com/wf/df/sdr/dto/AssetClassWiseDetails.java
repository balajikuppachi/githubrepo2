package com.wf.df.sdr.dto;

import java.util.List;

public class AssetClassWiseDetails {

	int foCount;
	int foIrsCountForRT;
	int foIrsCountForPET;
	int gtrCountForRT;
	int gtrCountForPET;
	int gtrRejectedForRT;
	int gtrRejectedForPET;
	int tradeBreaksForFO;
	int tradeBreaksForIRS;
	int tradeBreaksForGTR;
	List<TradesCausingBreakDetails> listOfBrokenTradesForFO;
	List<TradesCausingBreakDetails> listOfBrokenTradesForIRS;
	
	public int getFoCount() {
		return foCount;
	}
	public void setFoCount(int foCount) {
		this.foCount = foCount;
	}
	public int getFoIrsCountForRT() {
		return foIrsCountForRT;
	}
	public void setFoIrsCountForRT(int foIrsCountForRT) {
		this.foIrsCountForRT = foIrsCountForRT;
	}
	public int getFoIrsCountForPET() {
		return foIrsCountForPET;
	}
	public void setFoIrsCountForPET(int foIrsCountForPET) {
		this.foIrsCountForPET = foIrsCountForPET;
	}
	public int getGtrCountForRT() {
		return gtrCountForRT;
	}
	public void setGtrCountForRT(int gtrCountForRT) {
		this.gtrCountForRT = gtrCountForRT;
	}
	public int getGtrCountForPET() {
		return gtrCountForPET;
	}
	public void setGtrCountForPET(int gtrCountForPET) {
		this.gtrCountForPET = gtrCountForPET;
	}
	public int getGtrRejectedForRT() {
		return gtrRejectedForRT;
	}
	public void setGtrRejectedForRT(int gtrRejectedForRT) {
		this.gtrRejectedForRT = gtrRejectedForRT;
	}
	public int getGtrRejectedForPET() {
		return gtrRejectedForPET;
	}
	public void setGtrRejectedForPET(int gtrRejectedForPET) {
		this.gtrRejectedForPET = gtrRejectedForPET;
	}
	public int getTradeBreaksForFO() {
		return tradeBreaksForFO;
	}
	public void setTradeBreaksForFO(int tradeBreaksForFO) {
		this.tradeBreaksForFO = tradeBreaksForFO;
	}
	public int getTradeBreaksForIRS() {
		return tradeBreaksForIRS;
	}
	public void setTradeBreaksForIRS(int tradeBreaksForIRS) {
		this.tradeBreaksForIRS = tradeBreaksForIRS;
	}
	public int getTradeBreaksForGTR() {
		return tradeBreaksForGTR;
	}
	public void setTradeBreaksForGTR(int tradeBreaksForGTR) {
		this.tradeBreaksForGTR = tradeBreaksForGTR;
	}
	public List<TradesCausingBreakDetails> getListOfBrokenTradesForFO() {
		return listOfBrokenTradesForFO;
	}
	public void setListOfBrokenTradesForFO(
			List<TradesCausingBreakDetails> listOfBrokenTradesForFO) {
		this.listOfBrokenTradesForFO = listOfBrokenTradesForFO;
	}
	public List<TradesCausingBreakDetails> getListOfBrokenTradesForIRS() {
		return listOfBrokenTradesForIRS;
	}
	public void setListOfBrokenTradesForIRS(
			List<TradesCausingBreakDetails> listOfBrokenTradesForIRS) {
		this.listOfBrokenTradesForIRS = listOfBrokenTradesForIRS;
	}
	
}
