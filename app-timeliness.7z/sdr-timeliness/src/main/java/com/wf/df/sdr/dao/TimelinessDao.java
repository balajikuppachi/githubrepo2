package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.TimelinessDomain;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public interface TimelinessDao {

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(TimelinessDomain dto);

	/** 
	 * Returns all rows from the domain_values table that match the criteria ''.
	 */
	public List<TimelinessDomain> findAll() throws TimelinessDomainException;
	
	/**
	 * Common update for the DTCC details for all 5 asset class
	 * @param dto
	 */

	public void updateDtccDetails(TimelinessDomain dto) throws TimelinessDomainException;
	
	/**
	 * Common update for the ICE details for all 5 asset class
	 * @param dto
	 */

	public void updateICEDetails(TimelinessDomain dto) throws TimelinessDomainException;
	
	/**
	 * Common update for the ICE 1STR details for all 5 asset class
	 * @param dto
	 */

	public void updateICESTRDetails(TimelinessDomain dto) throws TimelinessDomainException;
	
	
	/**
	 * Update the IRS details for all trades that are to be reported
	 * @param dto
	 * @throws TimelinessDomainException
	 */
	public void updateIrsDetails(TimelinessDomain dto) throws TimelinessDomainException;

	
	/**
	 * @param tradeParty1ReferenceNumber
	 * @return
	 * @throws TimelinessDomainException
	 */
	public String findElapsedTimeFoResponseRt(String tradeId, String tradeRevision) throws TimelinessDomainException;

	/**
	 * Set column to Y once report is printed
	 */
	public void updateReportGenerated(String uniqueFileId);
	
	/**
	 * 
	 * @param assetClass
	 * @return
	 */
	public List<TimelinessDomain> findWhereAssetClassEquals(String assetClass) throws TimelinessDomainException;

	public void updateDtccDetailsUsingIrsKey(TimelinessDomain domain) throws TimelinessDomainException;
	
	public List<TimelinessDomain> findWhereUniqueId(String uniqueFileId) throws TimelinessDomainException;
}
