package com.wf.df.sdr.service.csvloader;

import java.io.InputStream;
import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.beans.EndurBean;
import com.wf.df.sdr.service.csvloader.common.CommonLoader;
import com.wf.df.sdr.service.csvloader.common.DataReader;
import com.wf.df.sdr.service.csvloader.common.SdrSnapshotReader;

@Component
public class EndurReader extends CommonLoader<EndurBean>{
	
	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new SdrSnapshotReader(inputStream,1);
	}
	
	@Override
	public boolean validate(EndurBean bean) {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	public EndurBean parseRecord(String[] fields) throws ParseException {
		EndurBean bean = new EndurBean();
		bean.setDealTrackingNum(fields[0]);
		bean.setTradeDate(fields[1]);
		bean.setInstrument(fields[2]);
		bean.setTradeStatus(fields[3]);
		bean.setRp(fields[4]);
		bean.setParamSeqNum(fields[5]);
		bean.setUsi(fields[6]);
		bean.setProductId(fields[7]);
		bean.setUniqueId(fields[8]);
		bean.setSenderTradeRefId(fields[9]);
		bean.setLastUpdate(fields[10]);
		bean.setEventStatus(fields[11]);
		bean.setEventDate(fields[12]);
		bean.setSdrReportable(fields[13]);
		bean.setSdrSendFlag(fields[14]);
		bean.setTransNumber(fields[15]);
	
		return bean;
	}
}
