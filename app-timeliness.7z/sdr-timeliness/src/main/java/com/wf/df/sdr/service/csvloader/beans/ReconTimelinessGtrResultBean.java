package com.wf.df.sdr.service.csvloader.beans;

import org.springframework.stereotype.Component;

@Component
public class ReconTimelinessGtrResultBean {

}
