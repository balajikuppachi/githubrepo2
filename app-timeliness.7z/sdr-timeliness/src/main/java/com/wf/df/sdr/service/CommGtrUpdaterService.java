package com.wf.df.sdr.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessIrsGtrDao;
import com.wf.df.sdr.dao.spring.ReconTimelinessIrsGtrExtnDao;
import com.wf.df.sdr.dto.ReconTimelinessIrsGtrDomain;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

@Component
public class CommGtrUpdaterService extends BaseGtrUpdaterService {

	@Autowired
	ReconTimelinessIrsGtrDao reconTimelinessIrsGtrDao;
	@Autowired
	ReconTimelinessIrsGtrExtnDao reconTimelinessIrsGtrExtnDao;
	
public void updateICETimeliness(String reconId){
		
		try{
		List<ReconTimelinessIrsGtrDomain> reportTradeList = reconTimelinessIrsGtrDao.findAllByAssetClass(reconId,Constants.ASSET_CLASS_COMMODITY);
		Long elapsedTimeForResponseRt=0L;
		String tradeId=null,tradeVersion=null;
		if(reportTradeList.size()>0){
			for(ReconTimelinessIrsGtrDomain timelinessRecord:reportTradeList){
				ReconTimelinessIrsGtrDomain domain =new ReconTimelinessIrsGtrDomain();
					if(!TimelinessUtils.IsNullOrBlank(timelinessRecord.getIrsTradeId())&& !TimelinessUtils.IsNullOrBlank(timelinessRecord.getIrsTradeVersion())&& !TimelinessUtils.IsNullOrBlank(timelinessRecord.getIrsSendId())){
					tradeId=timelinessRecord.getIrsTradeId();
					tradeVersion=timelinessRecord.getIrsTradeVersion();
					domain.setIrsTradeId(tradeId);
					domain.setIrsTradeVersion(tradeVersion);
					domain.setIrsSendId(timelinessRecord.getIrsSendId());
				}
				/**
				 * As per Ritesh we populate both the columns same value( sdr upload time,response rt)
				 */
					domain.setGtrExecTime(0L);
				List<String> dataList= reconTimelinessIrsGtrExtnDao.fetchResponseFromComm(new BigDecimal(timelinessRecord.getIrsSendId()),reconId);
				if(dataList.size()>0){
					String gtrStatus=null,gtrUsi=null;
					String traceId = dataList.get(0);
					String mappingEncStatus=dataList.get(1);
					String gtrsubmissionTime=dataList.get(2);
					
					domain.setGtrSubmissionTime(DateUtil.getTimestampFromStringForDiff(gtrsubmissionTime).getTime());
 					domain.setGtrAssetClass(Constants.ASSET_CLASS_COMMODITY);
					domain.setGtrTradeParty1ReferenceNumber(timelinessRecord.getIrsTradeId());
					
					domain.setGtrRespRecv(Constants.Y);
					if(mappingEncStatus.equalsIgnoreCase(Constants.SUCCESS)){
						domain.setGtrRespAcceptance(Constants.ACCEPTED);
					}else{
						domain.setGtrRespAcceptance(Constants.REJECTED);
					}
					if(!traceId.equals(Constants.NOTFOUND) && !TimelinessUtils.IsNullOrBlank(traceId)){
						List<String> emsList= reconTimelinessIrsGtrExtnDao.fetchEndurResult(traceId,reconId);
						if(emsList.size()>0){
							gtrStatus=emsList.get(0);
							gtrUsi=emsList.get(1);
							domain.setGtrUsi(TimelinessUtils.IsNullOrBlank(gtrUsi)?timelinessRecord.getIrsUsi():gtrUsi);
						}else{
							domain.setGtrUsi(timelinessRecord.getIrsUsi());
						}
						
					} else {
						/*
						 * Ritesh informed to Store ICE usi same as IRS usi 
						 * since we will not have trace_id for lifecycle event 
						 * as a result endur_msg_store entry cannot be figured 
						 * for fetching USI.
						 */
						domain.setGtrUsi(timelinessRecord.getIrsUsi());
					}
					
					
				}else{
					domain.setGtrRespRecv(Constants.N);
					domain.setGtrSubmissionTime(elapsedTimeForResponseRt);
					domain.setGtrAssetClass(Constants.ASSET_CLASS_COMMODITY);
				}
				  
				reconTimelinessIrsGtrDao.updateCommGtrDetails(domain);
			}
		}
		}
		catch(Exception e){
			logger.error("Error while upating ICE data " + e);
		}
		logger.info("Completed ICE updates");
	}
}