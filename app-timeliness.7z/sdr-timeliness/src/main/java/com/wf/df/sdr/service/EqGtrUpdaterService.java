package com.wf.df.sdr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessIrsGtrDao;
import com.wf.df.sdr.dto.ReconTimelinessIrsGtrDomain;
import com.wf.df.sdr.service.csvloader.beans.DtccEqBean;
import com.wf.df.sdr.service.csvloader.common.Constants;

@Component
public class EqGtrUpdaterService extends BaseGtrUpdaterService{

	@Autowired
	ReconTimelinessIrsGtrDao reconTimelinessIrsGtrDao;
	
	public void updateForDtccEqInfo(List<DtccEqBean> beanList) {
		for (DtccEqBean bean : beanList) {
			String tradeData[] = null;
			String party1transId = bean.getParty1TransactionId();
			if (!TimelinessUtils.IsNullOrBlank(party1transId)) {
				if (party1transId.contains(Constants.TRANS_ID_SEPARATOR)) {
					tradeData = party1transId.split(Constants.TRANS_ID_SEPARATOR);
					if (tradeData.length > 2) {
						updateEqInTimeliness(tradeData[1], tradeData[2], bean);
					}
				}
			}

		}
	}

	private void updateEqInTimeliness(String tradeId, String tradeRevision, DtccEqBean bean) {

		ReconTimelinessIrsGtrDomain domain = new ReconTimelinessIrsGtrDomain();
		domain.setGtrAction(bean.getGtrAction());
		domain.setGtrAssetClass(bean.getAssetClass());
		domain.setIrsTradeId(tradeId);
		domain.setIrsTradeVersion(tradeRevision);
		domain.setGtrTradeParty1ReferenceNumber(bean.getParty1TransactionId());
		domain.setGtrUsi(bean.getUsiPrefix() + bean.getUsiValue());
		domain.setGtrMessageType(bean.getMessageType());
		domain.setGtrTransType(bean.getTransactionType());
		domain.setReconId(getLatestReconId());
		
		/* Calculate time difference */
		domain.setGtrSubmissionTime(bean.getSubmissionDateTime().getTime());
		domain.setGtrRespAcceptance(bean.getStatus());
		domain.setGtrExecTime(0L);
		/* To avoid update call if no entry in table */
		if (domain.getGtrSubmissionTime() != 0L) {
			int rowsUpdated = reconTimelinessIrsGtrDao.updateEqDtccDetails(domain);
			
			/*Check if this GTR record has a corresponding IRS entry else INSERT the GTR break*/
			if(0 == rowsUpdated){
				logger.debug("Inserting dtcc record for usi : " + bean.getUsiPrefix()+bean.getUsiValue());
				ReconTimelinessIrsGtrDomain fullRecord = new ReconTimelinessIrsGtrDomain();
				fullRecord.setIrsSystem(Constants.GTR);				
				fullRecord.setIrsAssetClass(bean.getAssetClass());			
				fullRecord.setIrsProduct(bean.getProductIdValue());				
				fullRecord.setIrsSubProduct(Constants.EMPTY_STRING);	
				fullRecord.setIrsRecvTimestamp(0L);	
				fullRecord.setIrsSendId(Constants.EMPTY_STRING); 			
				fullRecord.setIrsTradeId(Constants.EMPTY_STRING);			
				fullRecord.setIrsTradeVersion(Constants.EMPTY_STRING);		
				fullRecord.setIrsUsi(Constants.EMPTY_STRING);					
				fullRecord.setIrsDtccUsi(Constants.EMPTY_STRING);			
				fullRecord.setIrsTransType(Constants.EMPTY_STRING);			
				fullRecord.setIrsExecTime(0L);	
				fullRecord.setIrsTradeStatus(Constants.EMPTY_STRING);		
				fullRecord.setIrsReportUploadTime(0L);	
				fullRecord.setIrsMessageType(Constants.EMPTY_STRING);		
				fullRecord.setIrsMsgStatus(Constants.EMPTY_STRING);			
				fullRecord.setIrsDescription(Constants.EMPTY_STRING);	
				fullRecord.setIrsRepFlag(Constants.N);
				
				fullRecord.setGtrAction(bean.getGtrAction());
				fullRecord.setGtrAssetClass(bean.getAssetClass());
				fullRecord.setGtrTradeParty1ReferenceNumber(bean.getParty1TransactionId());
				fullRecord.setGtrUsi(bean.getUsiPrefix()+bean.getUsiValue());
				fullRecord.setGtrRespRecv(Constants.Y);
				fullRecord.setGtrRespAcceptance(bean.getStatus());
				long gtrSubTime = bean.getSubmissionDateTime().getTime();
				if(!TimelinessUtils.IsNullOrBlank(gtrSubTime) && 0L!=gtrSubTime){
					fullRecord.setGtrSubmissionTime(gtrSubTime);
				} else {
					fullRecord.setGtrSubmissionTime(0L);
				}
				fullRecord.setGtrMessageType(bean.getMessageType());
				fullRecord.setGtrTransType(bean.getTransactionType());
				fullRecord.setGtrRepFlag(Constants.Y);
				fullRecord.setReconId(getLatestReconId());
				fullRecord.setGtrExecTime(0L);
				if(!TimelinessUtils.IsNullOrBlank(fullRecord.getReconId()))
					reconTimelinessIrsGtrDao.insert(fullRecord);
				else
					logger.info("Could not insert as the recon id is null");
			}
		}
	}
}
