package com.wf.df.sdr.service.csvloader.beans;


public class EndurBean implements BaseBean{
	
	String dealTrackingNum;
	String assetClass;
	String tradeDate;
	String instrument;
	String status;
	String rp;
	String paramSeqNum;
	String usi;
	String productId;
	String uniqueId;
	String senderTradeRefId;
	String lastUpdate;
	String eventStatus;
	String eventDate;
	String sdrReportable;
	String sdrSendFlag;
	String transNumber;
	String tradeStatus;
	
	public String getDealTrackingNum() {
		return dealTrackingNum;
	}
	public void setDealTrackingNum(String dealTrackingNum) {
		this.dealTrackingNum = dealTrackingNum;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}	
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public String getInstrument() {
		return instrument;
	}
	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRp() {
		return rp;
	}
	public void setRp(String rp) {
		this.rp = rp;
	}
	public String getParamSeqNum() {
		return paramSeqNum;
	}
	public void setParamSeqNum(String paramSeqNum) {
		this.paramSeqNum = paramSeqNum;
	}
	public String getUsi() {
		return usi;
	}
	public void setUsi(String usi) {
		this.usi = usi;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getSenderTradeRefId() {
		return senderTradeRefId;
	}
	public void setSenderTradeRefId(String senderTradeRefId) {
		this.senderTradeRefId = senderTradeRefId;
	}
	public String getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getSdrReportable() {
		return sdrReportable;
	}
	public void setSdrReportable(String sdrReportable) {
		this.sdrReportable = sdrReportable;
	}
	public String getSdrSendFlag() {
		return sdrSendFlag;
	}
	public void setSdrSendFlag(String sdrSendFlag) {
		this.sdrSendFlag = sdrSendFlag;
	}
	
	public String getTransNumber() {
		return transNumber;
	}
	public void setTransNumber(String transNumber) {
		this.transNumber = transNumber;
	}
	/**
	 * @return the tradeStatus
	 */
	public String getTradeStatus() {
		return tradeStatus;
	}
	/**
	 * @param tradeStatus the tradeStatus to set
	 */
	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}
	@Override
	public String toString() {
		return "EndurBean [dealTrackingNum=" + dealTrackingNum
				+ ", assetClass=" + assetClass + ", tradeDate=" + tradeDate
				+ ", instrument=" + instrument + ", status=" + status + ", rp="
				+ rp + ", paramSeqNum=" + paramSeqNum + ", usi=" + usi
				+ ", productId=" + productId + ", uniqueId=" + uniqueId
				+ ", senderTradeRefId=" + senderTradeRefId + ", lastUpdate="
				+ lastUpdate + ", eventStatus=" + eventStatus + ", eventDate="
				+ eventDate + ", sdrReportable=" + sdrReportable
				+ ", sdrSendFlag=" + sdrSendFlag + "]";
	}
	
}
