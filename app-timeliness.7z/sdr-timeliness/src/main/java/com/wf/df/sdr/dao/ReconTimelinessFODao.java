package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.ReconTimelinessFO;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public interface ReconTimelinessFODao {

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(ReconTimelinessFO dto);

	/** 
	 * Returns all rows from the recon_timeliness_fo table that match the criteria ''.
	 */
	public List<ReconTimelinessFO> findAll() throws TimelinessDomainException;
	
}
