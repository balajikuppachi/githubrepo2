package com.wf.df.sdr.service.csvloader;

import java.io.InputStream;
import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.service.csvloader.beans.DtccCrBean;
import com.wf.df.sdr.service.csvloader.common.CommonLoader;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DataReader;
import com.wf.df.sdr.service.csvloader.common.DateUtil;
import com.wf.df.sdr.service.csvloader.common.SdrSnapshotReader;

@Component
public class DtccCrReader extends CommonLoader<DtccCrBean>{

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new SdrSnapshotReader(inputStream,3);
	}

	@Override
	public boolean validate(DtccCrBean bean) {
		if(bean.getMessageType().equals(Constants.RT)||bean.getMessageType().equals(Constants.PET))
			return true;
		else
			return false;
	}

	@Override
	public DtccCrBean parseRecord(String[] fields) throws ParseException {
		DtccCrBean bean = new DtccCrBean();
		bean.setGtrAction(fields[0]);
		bean.setTransactionType(fields[1]);
		bean.setMessageType(fields[2]);
	//	bean.setUsiNamespace(fields[3]);
		String usi = Constants.EMPTY_STRING;
		if(!TimelinessUtils.IsNullOrBlank(fields[3])){
			usi = fields[3];
			if(usi.contains(Constants.DTCC_CR_USI_REPLACE)){
				usi = usi.replace(Constants.DTCC_CR_USI_REPLACE, Constants.EMPTY_STRING);
			}
		}
		bean.setUsi(usi);
		bean.setAssetClass(fields[5]);
		bean.setProductType(fields[7]);
		bean.setStatus(fields[15]);
		bean.setErrorReason(fields[17]);
		bean.setSubmissionDateTime(DateUtil.getTimestampFromStringCr(fields[14]));
		bean.setTradeParty1ReferenceNumber(fields[12]);
		//this field need to add in report(Data submitter ID)
		//bean.setDataSubmitter(fields[26]);
		
		return bean;
	}
}
