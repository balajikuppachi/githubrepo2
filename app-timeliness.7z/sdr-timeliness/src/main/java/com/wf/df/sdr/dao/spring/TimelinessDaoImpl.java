package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.TimelinessDao;
import com.wf.df.sdr.dto.TimelinessDomain;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public class TimelinessDaoImpl extends AbstractDAO implements ParameterizedRowMapper<TimelinessDomain>,TimelinessDao {

	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(TimelinessDomain dto) {
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( system, asset_class, product, fo_exec_date, execution_date, fo_tlc_exec_date, fo_market_type, fo_trade_status, fo_trade_id, fo_trade_version, fo_usi, fo_sdr_eligible_trade, reporting_party, sdr_eligibility, fo_rep_flag, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trans_type, irs_rep_flag, irsReportUploadTime, gtr_usi, dtcc_resp_acceptance, sdrSubmissionTime, gtr_rep_flag, run_date, unique_file_id ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", dto.getSystem(), dto.getAssetClass(), dto.getProduct(), dto.getFoExecDate().longValue()+"", dto.getExecutionDate().longValue()+"", dto.getFoTlcExecDate().longValue()+"", dto.getFoMarketType(), dto.getFoTradeStatus(), dto.getFoTradeId(), dto.getFoTradeVersion(), dto.getFoUsi(), dto.getFoSdrEligibleTrade(), dto.getReportingParty(), dto.getSdrEligibility(), dto.getFoRepFlag(), dto.getIrsRecvTimestamp(), dto.getIrsSendId(), dto.getIrsTradeId(), dto.getIrsTradeVersion(), dto.getIrsUsi(), dto.getIrsDtccUsi(), dto.getIrsTransactionType(), dto.getIrsRepFlag(), dto.getIrsReportUploadTime().longValue()+"", dto.getGtrUsi(), dto.getDtccRespAcceptance(), dto.getSdrSubmissionTime().longValue()+"", dto.getGtrRepFlag(),  new Date(), dto.getUniqueFileId());
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return TimelinessDomain
	 */
	@Override
	public TimelinessDomain mapRow(ResultSet rs, int row) throws SQLException
	{
		TimelinessDomain dto = new TimelinessDomain();
		dto.setSystem(rs.getString(1));
		dto.setAssetClass(rs.getString(2));
		dto.setProduct(rs.getString(3));
		dto.setFoExecDate(Long.parseLong(null!=rs.getString(4)?rs.getString(4):"0"));
		dto.setExecutionDate(Long.parseLong(null!=rs.getString(5)?rs.getString(5):"0"));
		dto.setFoTlcExecDate(Long.parseLong(null!=rs.getString(6)?rs.getString(6):"0"));
		dto.setFoMarketType(rs.getString(7));
		dto.setFoTradeStatus(rs.getString(8));
		dto.setFoTradeId(rs.getString(9));
		dto.setFoTradeVersion(rs.getString(10));
		dto.setFoUsi(rs.getString(11));
		dto.setFoSdrEligibleTrade(rs.getString(12));
		dto.setReportingParty(rs.getString(13));
		dto.setSdrEligibility(rs.getString(14));
		dto.setFoRepFlag(rs.getString(15));
		dto.setIrsRecvTimestamp(rs.getString(16));
		dto.setIrsSendId(rs.getString(17));
		dto.setIrsTradeId(rs.getString(18));
		dto.setIrsTradeVersion(rs.getString(19));
		dto.setIrsUsi(rs.getString(20));
		dto.setIrsDtccUsi(rs.getString(21));
		dto.setIrsTransactionType(rs.getString(22));
		dto.setIrsRepFlag(rs.getString(23));
		dto.setIrsReportUploadTime(Long.parseLong(null!=rs.getString(24)?rs.getString(24):"0"));
		dto.setGtrUsi(rs.getString(25));
		dto.setDtccRespRecv(rs.getString(26));
		dto.setDtccRespAcceptance(rs.getString(27));
		dto.setSdrSubmissionTime(Long.parseLong(null!=rs.getString(28)?rs.getString(28):"0"));
		dto.setGtrRepFlag(rs.getString(29));
		dto.setRunDate(rs.getDate(30));
		dto.setReported(rs.getString(31));
		dto.setUniqueFileId(rs.getString(32));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "timeliness";
	}

	/** 
	 * Returns all rows from the timeliness table that match the criteria ''.
	 */
	@Transactional
	public List<TimelinessDomain> findAll() throws TimelinessDomainException
	{
		try {
			return jdbcTemplate.query("SELECT system, asset_class, product, fo_exec_date, execution_date, fo_tlc_exec_date, fo_market_type, fo_trade_status, fo_trade_id, fo_trade_version, fo_usi, fo_sdr_eligible_trade, reporting_party, sdr_eligibility, fo_rep_flag, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trans_type, irs_rep_flag, irsReportUploadTime, gtr_usi, dtcc_resp_recv, dtcc_resp_acceptance, sdrSubmissionTime, gtr_rep_flag, run_date, report_generated, unique_file_id FROM " + getTableName()+ " WHERE report_generated = ? ", this,"N");
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new TimelinessDomainException("Query failed", e);
		}
		
	}
	
	
	/**
	 * Update DTCC USI and Response time for the trade_id
	 */
	@Transactional
	public void updateDtccDetails(TimelinessDomain dto) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set gtr_usi=?, sdrSubmissionTime=?, dtcc_resp_recv='Y', dtcc_resp_acceptance=? where fo_trade_id=? and fo_trade_version=? ",
					dto.getGtrUsi(), dto.getSdrSubmissionTime().longValue()+"", dto.getDtccRespAcceptance(), dto.getFoTradeId(), dto.getFoTradeVersion());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	
	/**
	 * Update ICE USI and Response time for the trade_id
	 */
	@Transactional
	public void updateICEDetails(TimelinessDomain dto) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set gtr_usi=?, sdrSubmissionTime=?, dtcc_resp_recv=?, dtcc_resp_acceptance=? where fo_trade_id=? and fo_trade_version=? ",
					dto.getGtrUsi(), dto.getSdrSubmissionTime().longValue()+"", dto.getDtccRespRecv(), dto.getDtccRespAcceptance(), dto.getFoTradeId(), dto.getFoTradeVersion());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	
	/**
	 * Update ICE STR and Response time for the trade_id
	 */
	@Transactional
	public void updateICESTRDetails(TimelinessDomain dto) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set gtr_usi=?, sdrSubmissionTime=?, dtcc_resp_recv=?, dtcc_resp_acceptance=? where irs_trade_id=? and irs_trade_version=? ",
					dto.getGtrUsi(), dto.getSdrSubmissionTime().longValue()+"", dto.getDtccRespRecv(), dto.getDtccRespAcceptance(), dto.getIrsTradeId(), dto.getIrsTradeVersion());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	/**
	 * Update SRC USI and Response time for the trade_id
	 */
	@Transactional
	public void updateIrsDetails(TimelinessDomain dto) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set irs_send_id=?, irs_trade_id=?, irs_trade_version=?, irs_usi=?, irs_dtcc_usi=?, irs_trans_type=?, irsReportUploadTime=?, irs_recv_timestamp=? where fo_trade_id=? and fo_trade_version=?",
					dto.getIrsSendId(),dto.getFoTradeId(), dto.getFoTradeVersion(), dto.getIrsUsi(), dto.getIrsDtccUsi(), dto.getIrsTransactionType(), dto.getIrsReportUploadTime().longValue()+"", dto.getIrsRecvTimestamp(), dto.getFoTradeId(), dto.getFoTradeVersion());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}

	/**
	 * Get time FO time to calculate the difference of time
	 */
	@Transactional
	public String findElapsedTimeFoResponseRt(String tradeId, String tradeRevision)
			throws TimelinessDomainException {
		try {
			 List<String> elapsedTime = jdbcTemplate.query("SELECT sdrSubmissionTime FROM " + getTableName()+ " WHERE fo_trade_id = ? and fo_trade_version = ? and report_generated = ? ",
					new RowMapper<String>() {

						@Override
						public String mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							// TODO Auto-generated method stub
							return rs.getString(1);
						}
					},
					new Object[]{tradeId,tradeRevision,"N"});
			 if(elapsedTime.size()>0)
				 return elapsedTime.get(0);
			 return "0";
			 //return jdbcTemplate.queryForObject("SELECT sdrSubmissionTime FROM " + getTableName()+ " WHERE fo_trade_id = ? and fo_trade_version = ? and report_generated = ? ", String.class, new Object[]{tradeId,tradeRevision,"N"});
		}
		catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}	
	}

	/**
	 * Update report_generated to Y 
	 */
	@Transactional
	public void updateReportGenerated(String uniqueFileId) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set report_generated=?, unique_file_id=? where report_generated=?", "Y", uniqueFileId, "N");
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}	
	}
	
	/**
	 * For Commodity update ICE values.
	 * @param assetClass
	 * @return
	 * @throws TimelinessDomainException
	 */
	@Transactional
	public List<TimelinessDomain> findWhereAssetClassEquals(String assetClass) throws TimelinessDomainException
	{
		try {
			return jdbcTemplate.query(" SELECT system, asset_class, product, fo_exec_date, execution_date, fo_tlc_exec_date, fo_market_type, fo_trade_status, fo_trade_id, fo_trade_version, fo_usi, fo_sdr_eligible_trade, reporting_party, sdr_eligibility, fo_rep_flag, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trans_type, irs_rep_flag, irsReportUploadTime, gtr_usi, dtcc_resp_recv, dtcc_resp_acceptance, sdrSubmissionTime, gtr_rep_flag, run_date, report_generated, unique_file_id FROM  " + getTableName() + " WHERE asset_class = ? AND report_generated = ? ", this,assetClass,"N");
		}
		catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
		
	}
	
	
	@Transactional
	public void updateDtccDetailsUsingIrsKey(TimelinessDomain dto) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set gtr_usi=?, sdrSubmissionTime=?, dtcc_resp_recv='Y', dtcc_resp_acceptance=?  where irs_send_id = "+
				"(select min(irs_send_id) from timeliness where irs_trade_id=? and asset_class=? and gtr_usi is null and (irs_usi=? or irs_dtcc_usi=?))",
				dto.getGtrUsi(),dto.getSdrSubmissionTime().longValue()+"",dto.getDtccRespAcceptance(),dto.getIrsTradeId(),dto.getAssetClass(), dto.getIrsUsi(),dto.getIrsUsi());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}

	@Transactional
	public List<TimelinessDomain> findWhereUniqueId(String uniqueFileId)
			throws TimelinessDomainException {
		try {
			return jdbcTemplate.query(" SELECT system, asset_class, product, fo_exec_date, execution_date, fo_tlc_exec_date, fo_market_type, fo_trade_status, fo_trade_id, fo_trade_version, fo_usi, fo_sdr_eligible_trade, reporting_party, sdr_eligibility, fo_rep_flag, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trans_type, irs_rep_flag, irsReportUploadTime, gtr_usi, dtcc_resp_recv, dtcc_resp_acceptance, sdrSubmissionTime, gtr_rep_flag, run_date, report_generated, unique_file_id FROM  " + getTableName() + " WHERE unique_file_id = ? ", this,uniqueFileId);
		}
		catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
		
	}
	
}
