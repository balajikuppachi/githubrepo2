package com.wf.df.sdr.service.messaging;

import java.io.File;
import java.util.Map;

import com.wf.df.sdr.dto.AssetClassWiseDetails;

public class TimelinessReportRequest {
	private File fileName;
	private String reconId;
	private Map<String, AssetClassWiseDetails> msgContent;

	public TimelinessReportRequest(File fileName, String reconId, Map<String, AssetClassWiseDetails> msgContent) {
		this.fileName = fileName;
		this.reconId = reconId;
		this.msgContent = msgContent;
		
	}

	public File getFileName() {
		return fileName;
	}
	

	public String getReconId() {
		return reconId;
	}

	public Map<String, AssetClassWiseDetails> getMsgContent() {
		return msgContent;
	}

}
