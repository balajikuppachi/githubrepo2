package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.service.csvloader.beans.ResultBean;


@Repository
public class TimelinessExtnDao {
	
Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static String emsCreateDateTimeQuery=" select TOP 1 i.usi, i.create_datetime, e.create_datetime from input_msg_store i, endur_msg_store e, mapping_sdr_enconnect m where i.src_trade_version= ? and i.src_trade_id= ? "+
	" and  i.send_id=m.send_id and m.trace_id=e.trace_id and i.create_datetime=CONVERT (DATE, GETDATE(), 101) order by i.send_id desc ";
	
	//private static String irDetails=" select TOP 1 i.usi, i.create_datetime, b.create_datetime, i.src_tlc_event from input_msg_store i,batch_details b where i.src_trade_version= ?  and i.src_trade_id= ?  and i.send_id=b.send_id and b.msg_type='RT' and convert(DATE, b.create_datetime, 101)=convert(DATE, ? , 101) order by b.send_id desc ";
	
	private static String irsRtDetails="select i.src_trade_version, i.src_trade_id, i.usi, i.src_tlc_event, i.create_datetime, b.create_datetime, mud.dtccusi, i.src_asset_class,b.send_id,i.src_exec_datetime,i.src_prod_type from  input_msg_store i join batch_details b on i.send_id=b.send_id  left join mapping_usi_dtccusi mud on i.send_id=mud.send_id " + 
										"where b.msg_type='RT' and convert(DATE, b.create_datetime, 101)=? order by b.send_id";
	
	
	//private static String dtccDataFetchingQueryForComm=" select TOP 1 e.usi,m.status from input_msg_store i, endur_msg_store e,mapping_sdr_enconnect m where i.src_trade_version= ?  and i.src_trade_id= ? and i.send_id=m.send_id and m.trace_id=e.trace_id order by i.send_id desc ";
	
	private static String fetchStatusForComm=" select TOP 1 m.send_id,m.trace_id,m.status from mapping_sdr_enconnect m, input_msg_store i where i.send_id=m.send_id and i.src_trade_id=? and i.src_trade_version=? and m.status='SUCCESS' "+
												" and convert(DATE,m.create_datetime,101)=CONVERT (DATE, ?, 101) order by m.send_id desc ";
	//private static String fetchStatusTypeForComm=" select TOP 1 e.usi,m.status from input_msg_store i, endur_msg_store e,mapping_sdr_enconnect m where i.src_trade_version= ?  and i.src_trade_id= ? and i.send_id=m.send_id and m.trace_id=e.trace_id order by i.send_id desc ";
	private static String fetchEmsQueryResult=" select TOP 1 m.msg_type, e.confirm_status, e.usi from endur_msg_store e,msg_to_report m where m.send_id=? and e.trace_id=? and convert(DATE,e.create_datetime,101)=CONVERT (DATE,?, 101)";
	
	private static String imsDataComm=" select  i.usi, i.create_datetime, m.create_datetime,i.src_trade_id,i.src_trade_version,i.src_exec_datetime, i.src_prod_type, i.send_id from input_msg_store i, mapping_sdr_enconnect m where m.status='SUCCESS' and "+
	" i.send_id=m.send_id and convert(DATE,m.create_datetime,101)=CONVERT (DATE,?, 101) order by i.send_id ";
	
	private RowMapper resultBeanRowMapper = new RowMapper() {
		@Override
		public ResultBean mapRow(ResultSet rs, int rowNum) throws SQLException {
			ResultBean rb=new ResultBean();
			rb.setImsSrcTradeVersion(rs.getString(1));
			rb.setImsSrcTradeId(rs.getString(2));
			rb.setImsUsi(rs.getString(3));
			rb.setImsSrcTlcEvent(rs.getString(4));
			rb.setImsCreateDatetime(rs.getString(5));
			rb.setBdCreateDatetime(rs.getString(6));
			rb.setMapIrsDtccUsi(rs.getString(7));
			return rb;
		}
	};
	
	@Transactional
	public List<ResultBean> findDataFromIRSForComm(String trade_version,String deal_track_num) {
		final List<ResultBean> resultList =new ArrayList<ResultBean>();
		jdbcTemplate.query(emsCreateDateTimeQuery,new Object[] { trade_version,deal_track_num },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
				ResultBean resultBean=new ResultBean();
				resultBean.setImsUsi(rs.getString(1));
				resultBean.setImsCreateDatetime(rs.getString(2));
				resultBean.setBdCreateDatetime(rs.getString(3));
				resultList.add(resultBean);
				return null;
			}			
		});		
		return resultList;
	}
	
	@Transactional
	public List<String> fetchEmsQueryResult(String sendID,String traceId,String executionDate ) {
		BigDecimal sendId = new BigDecimal(sendID);
	final List<String> resultList =new ArrayList<String>();
		jdbcTemplate.query(fetchEmsQueryResult,new Object[] { sendId,traceId,executionDate },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
				
				resultList.add(rs.getString(1));
				resultList.add(rs.getString(2));
				resultList.add(rs.getString(3));
				return null;
			}			
		});		
		return resultList;
	}
	
	@Transactional
	public List<String> fetchStatusForComm(String tradeId,String tradeVersion,String executionDate) {
		
	final List<String> resultList =new ArrayList<String>();
		jdbcTemplate.query(fetchStatusForComm,new Object[] { tradeId,tradeVersion,executionDate },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
				
				resultList.add(rs.getString(1));
				resultList.add(rs.getString(2));
				resultList.add(rs.getString(3));
				return null;
			}			
		});		
		return resultList;
	}
	
	/*@Transactional
	public List<String> fetchDataForDTCCForComm(String trade_version,String deal_track_num) {
		
	final List<String> resultList =new ArrayList<String>();
		jdbcTemplate.query(dtccDataFetchingQueryForComm,new Object[] { trade_version,deal_track_num },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
				
				resultList.add(rs.getString(1));
				resultList.add(rs.getString(2));
				return null;
			}			
		});		
		return resultList;
	}
	*/
	
	/*@Transactional
	public List<ResultBean> getIrsDetails(String trade_version,String tradeId,Date executionDate) {
		
		final List<ResultBean> irDetailsList=new ArrayList<ResultBean>();
		try{
		
			jdbcTemplate.query(irDetails,new Object[]{trade_version,tradeId,executionDate},new RowMapper() {

				@Override
				public ResultBean mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					ResultBean rb=new ResultBean();
					rb.setImsUsi(rs.getString(1));
					rb.setImsCreateDatetime(rs.getString(2));
					rb.setBdCreateDatetime(rs.getString(3));
					rb.setImsSrcTlcEvent(rs.getString(4));
					irDetailsList.add(rb);
					return rb;
				}
				
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return irDetailsList;
	}*/

	@Transactional
	public Map<String,ResultBean> getIrsRtDetails(String executionDate) {

		final Map<String,ResultBean> irsRtIRCREQDetailsMap=new ConcurrentHashMap<String, ResultBean>();
	
		jdbcTemplate.query(irsRtDetails,new Object[]{executionDate},new RowMapper() {
			@Override
			public ResultBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ResultBean rb=new ResultBean();
				rb.setImsSrcTradeVersion(rs.getString(1));
				rb.setImsSrcTradeId(rs.getString(2));
				rb.setImsUsi(rs.getString(3));
				rb.setImsSrcTlcEvent(rs.getString(4));
				rb.setImsCreateDatetime(rs.getString(5));
				rb.setBdCreateDatetime(rs.getString(6));
				rb.setMapIrsDtccUsi(rs.getString(7));
				rb.setIrsAssetClass(rs.getString(8));
				rb.setIrsSendId(rs.getString(9));
				rb.setIrsExecDateTime(rs.getString(10));
				rb.setIrsProductType(rs.getString(11));
				irsRtIRCREQDetailsMap.put(rs.getString(2)+":"+rs.getString(1), rb);
				return rb;
			}
			});
		return irsRtIRCREQDetailsMap;
	}
	
	@Transactional
	public Map<String, ResultBean> fetchImsDataForComm(String executionDate) {
		final Map<String, ResultBean> resultMap =new ConcurrentHashMap<String, ResultBean>();
		jdbcTemplate.query(imsDataComm,new Object[] { executionDate },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
				ResultBean rb=new ResultBean();
				rb.setImsUsi(rs.getString(1));
				rb.setImsCreateDatetime(rs.getString(2));
				rb.setBdCreateDatetime(rs.getString(3));
				rb.setImsSrcTradeId(rs.getString(4));
				rb.setImsSrcTradeVersion(rs.getString(5));
				rb.setImsExecDatetime(rs.getString(6));
				rb.setIrsProductType(rs.getString(7));
				rb.setIrsSendId(rs.getString(8));
				resultMap.put(rb.getImsSrcTradeId()+":"+rb.getImsSrcTradeVersion(),rb);
				return null;
			}			
		});		
		return resultMap;
	}

	public String findMaxReconId() {
		List<String> maxIdList = jdbcTemplate.queryForList("select max(recon_id) from recon_details where report_file_name is null and recon_date_flag = 'TRUE'", String.class);
		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null) {
			return null;
		} else {
			return maxIdList.get(0);
		}
	}
	public BigDecimal findMaxId() {
		List<BigDecimal> maxIdList = jdbcTemplate.queryForList("select max(id) from recon_details ", BigDecimal.class);
		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null) {
			return new BigDecimal(0);
		} else {
			return maxIdList.get(0);
		}
	}
	public void deleteIrs(String reconDate, String source) {
		logger.warn("Deleting Recon Timeliness IRS Records");
		String query = "delete from recon_timeliness_fo where recon_id = ? and fo_asset_class = ?";		
		jdbcTemplate.update(query, reconDate, source );
				
		}
	public void deleteGtr(String reconDate, String source) {
		logger.warn("Deleting Recon Timeliness GTR Records");
		String query = "delete from recon_timeliness_irs_gtr where recon_id = ? and irs_asset_class = ?";		
		jdbcTemplate.update(query, reconDate, source );
			
		}
	
}
