package com.wf.df.sdr.service.messaging;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

@Component
public class TimelinessMailSender  extends JavaMailSenderImpl {
	@Value("${mail.host}") String mailHost;
	TimelinessMailSender(){
		super();
		setHost(mailHost);
		setPort(25);
		setUsername("");
		setPassword("");
		
		getJavaMailProperties().put("mail.transport.protocol", "smtp");
		getJavaMailProperties().put("mail.smtp.auth", true);
		getJavaMailProperties().put("mail.debug",true);
		getJavaMailProperties().put("mail.smtp.starttls.enable", true);		
		
	}
}
