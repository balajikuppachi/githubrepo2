package com.wf.df.sdr.report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.TimelinessDao;
import com.wf.df.sdr.dto.TimelinessDomain;
import com.wf.df.sdr.exception.report.FileGeneratorException;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

@Component
@ManagedResource(description="Generate Debug Report")
public class DebugReportGenerator {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TimelinessDao timelinessDao;
	
	@Value(".csv")
	String fileExtn;

	@Value("${file.outputFolder.Timeliness}")
	private String outputFolderNameTimeliness;

	private File outputFolderTimeliness;
	
	private int  foTotalReportableTrades=0;
	private int  irsTotalFoIRSReportableTrades=0;
	private int  irsTotalOnlyInIRSReportableTrades=0;
	private int  dtccTotalReportableTrades=0;
	private int  totalTradesFoIrsNotReportedOntimeFromIrs=0;
	private int  totalTradesOnlyIrsNotReportedOntimeFromIrs=0;
	private int  totalTradesFoGtrNotInGtrOntime=0;
	private int  totalTradesOnlyGtrNotInGtrOntime=0;
	private long elapsedTimeFOandSDRUpload=0L;
	private long elapsedTimeFoResponseRt=0L;
	

	@PostConstruct
	public void initialize() {
		outputFolderTimeliness = new File(outputFolderNameTimeliness);
		if (!outputFolderTimeliness.exists()) {
			if (!outputFolderTimeliness.mkdirs()) {
				throw new FileGeneratorException(
						"Couldn't create output folder - "
								+ outputFolderNameTimeliness);
			}
		}
	}

	@ManagedOperation(description="Trigger Debug Report")
	public void generateDebugReport(String uniqueFileId){
		csvDebugReportGenerate(uniqueFileId);
	}
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = java.lang.Throwable.class)
	public void csvDebugReportGenerate(String uniqueFileId) {
		logger.info("Reached csvGenerate");
		BufferedWriter out = null;
		generateReport(out,uniqueFileId);

	}

	private void generateReport(BufferedWriter out,String uniqueFileId) {
		//File resultingFile = null;
		File fileName =new File(outputFolderTimeliness,getFileName(uniqueFileId));
		//File tempFile = null;
		List<TimelinessDomain> dataList = timelinessDao.findWhereUniqueId(uniqueFileId);
		if(dataList.size()>0){
			try {
				//tempFile = File.createTempFile("sdr-", null);
				foTotalReportableTrades=0;
				irsTotalFoIRSReportableTrades=0;
				irsTotalOnlyInIRSReportableTrades=0;
				dtccTotalReportableTrades=0;
				totalTradesFoIrsNotReportedOntimeFromIrs=0;
				totalTradesOnlyIrsNotReportedOntimeFromIrs=0;
				totalTradesFoGtrNotInGtrOntime=0;
				totalTradesOnlyGtrNotInGtrOntime=0;
				elapsedTimeFOandSDRUpload=0L;
				elapsedTimeFoResponseRt=0L;
				
				out = new BufferedWriter(new FileWriter(fileName));
		
				writeFileHeader(out);
		
				/* write the csv file Content */
				for(TimelinessDomain dm : dataList){
					elapsedTimeFOandSDRUpload=findElapsedTime(!TimelinessUtils.IsNullOrBlank(dm.getExecutionDate())?dm.getExecutionDate():0L,dm.getIrsReportUploadTime());
					elapsedTimeFoResponseRt=findElapsedTime(!TimelinessUtils.IsNullOrBlank(dm.getExecutionDate())?dm.getExecutionDate():0L,dm.getSdrSubmissionTime());
					
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && dm.getFoRepFlag().equals(Constants.Y)) 
					{
						foTotalReportableTrades++;
						
					}
					
					/*
					 * Trades having 2 way recon : FO + IRS
					 * */
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()))
					{
						irsTotalFoIRSReportableTrades++;
					}
					
					/*
					 * Trades only in IRS
					 * */
					if(TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()))
					{
						irsTotalOnlyInIRSReportableTrades++;
					}
					
					if(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi()))
					{
						dtccTotalReportableTrades++;
					}
					
					/*
					 * Trades having 2 way recon : IRS + FO
					 * */
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && (elapsedTimeFOandSDRUpload==0L || elapsedTimeFOandSDRUpload>900000L ))
					{
						totalTradesFoIrsNotReportedOntimeFromIrs++;
					}
					
					/*
					 * Trades having only IRS info
					 * */
					if(TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && (elapsedTimeFOandSDRUpload==0L || elapsedTimeFOandSDRUpload>900000L ))
					{
						totalTradesOnlyIrsNotReportedOntimeFromIrs++;
					}
					
					/*
					 * Trades having 2 way recon : FO + GTR 
					 * */
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getGtrUsi()) && (elapsedTimeFoResponseRt==0L || elapsedTimeFoResponseRt>900000L) )
					{
						totalTradesFoGtrNotInGtrOntime++;
					}
					
					/*
					 * Trades having only GTR info
					 * */
					if(TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getGtrUsi()) && (elapsedTimeFoResponseRt==0L || elapsedTimeFoResponseRt>900000L) )
					{
						totalTradesOnlyGtrNotInGtrOntime++;
					}
					
					out.write(checkNull(dm.getSystem()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getAssetClass()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getProduct()));
					out.write(Constants.SEPERATOR);
						
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoExecDate()))
						out.write(dm.getFoExecDate() !=0L ?DateUtil.formatTimeStampForReport(dm.getFoExecDate()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					
					out.write(Constants.SEPERATOR);
					if(!TimelinessUtils.IsNullOrBlank(dm.getExecutionDate()))
						out.write(dm.getExecutionDate() !=0L ?DateUtil.formatTimeStampForReport(dm.getExecutionDate()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTlcExecDate()))
						out.write(dm.getFoTlcExecDate() !=0L ?DateUtil.formatTimeStampForReport(dm.getFoTlcExecDate()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoMarketType()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoTradeStatus()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoTradeId()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoTradeVersion()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoUsi()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoSdrEligibleTrade()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getIrsRecvTimestamp()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getIrsTradeId()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getIrsUsi()));
					out.write(Constants.SEPERATOR);
					if(!TimelinessUtils.IsNullOrBlank(dm.getIrsReportUploadTime()))
						out.write(dm.getIrsReportUploadTime()!=0L?DateUtil.formatTimeStampForReport(dm.getIrsReportUploadTime()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					out.write(checkNull(DateUtil.reportFormattedTimeDifference(elapsedTimeFOandSDRUpload)));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getGtrUsi()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getDtccRespRecv()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getDtccRespAcceptance()));
					out.write(Constants.SEPERATOR);
					if(!TimelinessUtils.IsNullOrBlank(dm.getSdrSubmissionTime()))
						out.write(dm.getSdrSubmissionTime()!=0L?DateUtil.formatTimeStampForReport(dm.getSdrSubmissionTime()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getDtccRespRecv().equals(Constants.Y) ? DateUtil.reportFormattedTimeDifference(elapsedTimeFoResponseRt):null));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getReportingParty()));
					/*out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getSdrEligibility()));*/
					out.newLine();
				}
				/*-----------------------------*/
		
				writeFileFooter(out,uniqueFileId);
		
				logger.debug("Generated file..." + fileName.getAbsolutePath() + " for "
						+ dataList.size() + " records");
		
				/*File targetFolder = null;
				targetFolder = outputFolderTimeliness;
				resultingFile = new File(targetFolder, fileName);
				FileUtils.moveFile(tempFile, resultingFile);
				*/
				logger.info("Timeliness Report generated at : " + fileName.getAbsolutePath());
				logger.info("Timeliness Report generated: records = " + dataList.size());
				
				/* Update the report_generated column to Y which is by default set to N*/
				//timelinessDao.updateReportGenerated();
			
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					out.close();
				} catch (IOException e) {
					logger.error("Could not close temporary file : "+fileName.getAbsolutePath());
				}
			}
		}else
			logger.info("No data to be reported");
	}
	
	private long findElapsedTime(Long executionDate, Long elapsedTime) {
		long diff=0L;
		if(!TimelinessUtils.IsNullOrBlank(executionDate) && !TimelinessUtils.IsNullOrBlank(elapsedTime)&&executionDate!=0L&&elapsedTime!=0L)
			diff=elapsedTime-executionDate;
		return diff;
	}

	private String checkNull(String value) {
		String val = Constants.EMPTY_STRING;
		if(StringUtils.isNotBlank(value)){
			val=value;
		}
		return Constants.QUOTES+val+Constants.QUOTES;
	}

	private void writeFileFooter(BufferedWriter out ,String uniqueFileId) {
		try {
			out.write(
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					foTotalReportableTrades+"(Total Trades to be reported FO)"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					irsTotalFoIRSReportableTrades+"(Total in Internal Reporting Solution(both in FO and IRS))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesFoIrsNotReportedOntimeFromIrs+"(Trades not reported on Time from IRS(both in FO and IRS))"+Constants.SEPERATOR+
					dtccTotalReportableTrades+"(Total Trades Reported in DTCC(both in FO and GTR))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesFoGtrNotInGtrOntime+"(Trades not in GTR on time(both in FO and GTR))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					""
				);
			out.newLine();
			
			out.write(
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					irsTotalOnlyInIRSReportableTrades+"(Total in Internal Reporting Solution(Only in IRS))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesOnlyIrsNotReportedOntimeFromIrs+"(Trades not reported on Time from IRS(Only in IRS))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesOnlyGtrNotInGtrOntime+"(Trades not in GTR on time(Only in GTR))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					""
				);
			out.newLine();
			out.write(Constants.SEPERATOR+Constants.UNIQUEID+
					Constants.SEPERATOR+uniqueFileId);
			out.newLine();
			
			/*out.write(
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					foTotalReportableTrades+Constants.SEPERATOR+
					irsTotalReportableTrades+Constants.SEPERATOR+
					dtccTotalReportableTrades+Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesNotReportedOntimeFromIrs+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesNotInGtrOntime+Constants.SEPERATOR+
					Constants.SEPERATOR+
					""
				);
			out.newLine();*/
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void writeFileHeader(BufferedWriter out) {
		try {
			out.write(
					"System"+Constants.SEPERATOR+
					"Asset Class"+Constants.SEPERATOR+
					"Product"+Constants.SEPERATOR+
					
					"FO Execution Time"+Constants.SEPERATOR+
					"Execution Time  "+Constants.SEPERATOR+
					"FO TLC Execution Time"+Constants.SEPERATOR+
					"Market Type"+Constants.SEPERATOR+
					"Trade Status"+Constants.SEPERATOR+
					
					"FO Trade ID "+Constants.SEPERATOR+
					"FO Trade Version "+Constants.SEPERATOR+
					"FO USI"+Constants.SEPERATOR+
					"FO SDR Eligible Trade"+Constants.SEPERATOR+
					"IRS Receive time"+Constants.SEPERATOR+
					"IRS Trade ID "+Constants.SEPERATOR+
					"Internal Reporting Solution USI"+Constants.SEPERATOR+
					
					"IRS RT upload time "+Constants.SEPERATOR+
					"FO vs DTCC upload"+Constants.SEPERATOR+
					
					"GTR USI From DTCC"+Constants.SEPERATOR+
					"DTCC response received?(Y/N)"+Constants.SEPERATOR+
					"DTCC response(Accepted/Rejected)"+Constants.SEPERATOR+
					"DTCC Submission Time"+Constants.SEPERATOR+
					"FO vs DTCC submission"+Constants.SEPERATOR+
					"Reporting Party"
					/*+Constants.SEPERATOR+
					"SDR Eligibility"*/
				);
			out.newLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String getFileName(String uniqueFileId) {
		//logger.info(new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date()));
		return Constants.TimelinessDebugFileName+new SimpleDateFormat("yyyyMMdd").format(new Date())+"_"+uniqueFileId+fileExtn;
	}
}
