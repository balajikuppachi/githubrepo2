package com.wf.df.sdr.report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessDao;
import com.wf.df.sdr.dao.TimelinessDao;
import com.wf.df.sdr.dao.spring.ReconTimelinessIrsGtrExtnDao;
import com.wf.df.sdr.dto.AssetClassWiseDetails;
import com.wf.df.sdr.dto.ReconTimelinessDomain;
import com.wf.df.sdr.dto.TradesCausingBreakDetails;
import com.wf.df.sdr.exception.report.FileGeneratorException;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;
import com.wf.df.sdr.service.messaging.TimelinessReportGenerationRequest;
import com.wf.df.sdr.service.messaging.TimelinessReportRequest;

@Component
public class ReconTimelinessDebugReportGenerator {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TimelinessDao timelinessDao;
	
	@Autowired
	ReconTimelinessDao reconTimelinessDao;
	
	@Autowired
	ReconTimelinessIrsGtrExtnDao reconTimelinessIrsGtrExtnDao;
	
	@Value(".csv")
	String fileExtn;

	@Value("${file.outputFolder.Timeliness}")
	private String outputFolderNameTimeliness;

	private File outputFolderTimeliness;
	
	@Value("${mail.enable.timeliness}")
	boolean isTimelinessMailEnable;
	
	@Autowired
	@Qualifier("timelinessReportGenerationRequest")
	private TimelinessReportGenerationRequest timelinessRepService;	
	
	private int  foTotalReportableTrades=0;
	private int  irsTotalFoIRSReportableTrades=0;
	private int  irsTotalOnlyInIRSReportableTrades=0;
	private int  dtccTotalReportableTrades=0;
	private int  totalTradesFoIrsNotReportedOntimeFromIrs=0;
	private int  totalTradesOnlyIrsNotReportedOntimeFromIrs=0;
	private int  totalTradesFoGtrNotInGtrOntime=0;
	private int  totalTradesOnlyGtrNotInGtrOntime=0;
	private long elapsedTimeFOandSDRUpload=0L;
	private long elapsedTimeFoResponseRt=0L;

	/* Fields for IR summary */
	private HashSet<String> irFoTradeCount;
	private HashSet<String> irTradeBreakForFO;
	private HashSet<String> irTradeBreakForIRS;
	private HashSet<String> irTradeBreakForGTR;
	private List<TradesCausingBreakDetails> irTradeBreaksListForFO;
	private List<TradesCausingBreakDetails> irTradeBreaksListForIRS;
	private HashSet<String> irFoIrsSetForRT;
	private HashSet<String> irFoIrsSetForPET;
	private HashSet<String> irGtrTradeCountForRT;
	private HashSet<String> irGtrTradeCountForPET;
	
	/* Fields for CR summary */
	private HashSet<String> crFoTradeCount;
	private HashSet<String> crTradeBreakForFO;
	private HashSet<String> crTradeBreakForIRS;
	private HashSet<String> crTradeBreakForGTR;
	private List<TradesCausingBreakDetails> crTradeBreaksListForFO;
	private List<TradesCausingBreakDetails> crTradeBreaksListForIRS;
	private HashSet<String> crFoIrsSetForRT;
	private HashSet<String> crFoIrsSetForPET;
	private HashSet<String> crGtrTradeCountForRT;
	private HashSet<String> crGtrTradeCountForPET;
	
	/* Fields for EQ summary */
	private HashSet<String> eqFoTradeCount;
	private HashSet<String> eqTradeBreakForFO;
	private HashSet<String> eqTradeBreakForIRS;
	private HashSet<String> eqTradeBreakForGTR;
	private List<TradesCausingBreakDetails> eqTradeBreaksListForFO;
	private List<TradesCausingBreakDetails> eqTradeBreaksListForIRS;
	private HashSet<String> eqFoIrsSetForRT;
	private HashSet<String> eqFoIrsSetForPET;
	private HashSet<String> eqGtrTradeCountForRT;
	private HashSet<String> eqGtrTradeCountForPET;
	
	/* Fields for COMM summary */
	private HashSet<String> commFoTradeCount;
	private HashSet<String> commTradeBreakForFO;
	private HashSet<String> commTradeBreakForIRS;
	private HashSet<String> commTradeBreakForGTR;	//Not needed now
	private List<TradesCausingBreakDetails> commTradeBreaksListForFO;
	private List<TradesCausingBreakDetails> commTradeBreaksListForIRS;
	private HashSet<String> commFoIrsSet;
	private int commGtrTradeCount;
	
	@PostConstruct
	public void initialize() {
		outputFolderTimeliness = new File(outputFolderNameTimeliness);
		if (!outputFolderTimeliness.exists()) {
			if (!outputFolderTimeliness.mkdirs()) {
				throw new FileGeneratorException(
						"Couldn't create output folder - "
								+ outputFolderNameTimeliness);
			}
		}
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = java.lang.Throwable.class)
	public void csvGenerate(String reconId) {
		logger.info("Reached csvGenerate");
		BufferedWriter out = null;
		generateReport(out,reconId);
		logger.info("Report generation completed");

	}

	private void generateReport(BufferedWriter out,String reconId) {
		List<ReconTimelinessDomain> dataList = reconTimelinessIrsGtrExtnDao.findForReconId(reconId);
		logger.info("Size of Data List for Report : "+dataList.size());
		//String reconId=dataList.get(0).getReconId();
		//File resultingFile = null;
		File fileName =new File(outputFolderTimeliness,getFileName(reconId));
		Map<String, AssetClassWiseDetails> summaryReport = new HashMap<String, AssetClassWiseDetails>();
		//File tempFile = null;
		if(dataList.size()>0){
			try {
				//tempFile = File.createTempFile("sdr-", null);
				foTotalReportableTrades=0;
				irsTotalFoIRSReportableTrades=0;
				irsTotalOnlyInIRSReportableTrades=0;
				dtccTotalReportableTrades=0;
				totalTradesFoIrsNotReportedOntimeFromIrs=0;
				totalTradesOnlyIrsNotReportedOntimeFromIrs=0;
				totalTradesFoGtrNotInGtrOntime=0;
				totalTradesOnlyGtrNotInGtrOntime=0;
				elapsedTimeFOandSDRUpload=0L;
				elapsedTimeFoResponseRt=0L;
				
				/* Intialize fields for IR */
				irFoTradeCount = new HashSet<String>();
				irTradeBreakForFO = new HashSet<String>();
				irTradeBreakForIRS = new HashSet<String>();
				irTradeBreakForGTR = new HashSet<String>();
				irTradeBreaksListForFO = new ArrayList<TradesCausingBreakDetails>();
				irTradeBreaksListForIRS = new ArrayList<TradesCausingBreakDetails>();
				irFoIrsSetForRT = new HashSet<String>();
				irFoIrsSetForPET = new HashSet<String>();
				irGtrTradeCountForRT = new HashSet<String>();
				irGtrTradeCountForPET = new HashSet<String>();
				
				/* Intialize fields for CR */
				crFoTradeCount = new HashSet<String>();
				crTradeBreakForFO = new HashSet<String>();
				crTradeBreakForIRS = new HashSet<String>();
				crTradeBreakForGTR = new HashSet<String>();
				crTradeBreaksListForFO = new ArrayList<TradesCausingBreakDetails>();
				crTradeBreaksListForIRS = new ArrayList<TradesCausingBreakDetails>();
				crFoIrsSetForRT = new HashSet<String>();
				crFoIrsSetForPET = new HashSet<String>();
				crGtrTradeCountForRT = new HashSet<String>();
				crGtrTradeCountForPET = new HashSet<String>();
				
				/* Intialize fields for EQ */
				eqFoTradeCount = new HashSet<String>();
				eqTradeBreakForFO = new HashSet<String>();
				eqTradeBreakForIRS = new HashSet<String>();
				eqTradeBreakForGTR = new HashSet<String>();
				eqTradeBreaksListForFO = new ArrayList<TradesCausingBreakDetails>();
				eqTradeBreaksListForIRS = new ArrayList<TradesCausingBreakDetails>();
				eqFoIrsSetForRT = new HashSet<String>();
				eqFoIrsSetForPET = new HashSet<String>();
				eqGtrTradeCountForRT = new HashSet<String>();
				eqGtrTradeCountForPET = new HashSet<String>();
				
				/* Intialize fields for COMM */
				commFoTradeCount = new HashSet<String>();
				commTradeBreakForFO = new HashSet<String>();
				commTradeBreakForIRS = new HashSet<String>();
				commTradeBreakForGTR = new HashSet<String>();
				commTradeBreaksListForFO = new ArrayList<TradesCausingBreakDetails>();
				commTradeBreaksListForIRS = new ArrayList<TradesCausingBreakDetails>();
				commFoIrsSet = new HashSet<String>();
				commGtrTradeCount = 0;
				
				
				out = new BufferedWriter(new FileWriter(fileName));
		
				writeFileHeader(out);
		
				/* write the csv file Content */
				for(ReconTimelinessDomain dm : dataList){
					elapsedTimeFOandSDRUpload=findElapsedTime(!TimelinessUtils.IsNullOrBlank(dm.getExecutionDate())?dm.getExecutionDate():0L,dm.getIrsReportUploadTime());
					elapsedTimeFoResponseRt=findElapsedTime(!TimelinessUtils.IsNullOrBlank(dm.getExecutionDate())?dm.getExecutionDate():0L,dm.getSdrSubmissionTime());
					
					/*------------- Start section for total counting -------------*/
					
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && Constants.Y.equals(dm.getFoRepFlag()) && !Constants.NOT_TO_SEND.equals(dm.getIrsMsgStatus()) && !Constants.DUPLICATE.equals(dm.getIrsMsgStatus())) 
					{
						foTotalReportableTrades++;
						
					}
					
					/*
					 * Trades having 2 way recon : FO + IRS
					 * */
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
					{
						irsTotalFoIRSReportableTrades++;
					}
					
					/*
					 * Trades only in IRS
					 * */
					if(TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
					{
						irsTotalOnlyInIRSReportableTrades++;
					}
					
					if(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi()))
					{
						dtccTotalReportableTrades++;
					}
					
					/*
					 * Trades having 2 way recon : IRS + FO
					 * */
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && (elapsedTimeFOandSDRUpload==0L || elapsedTimeFOandSDRUpload>900000L ) && Constants.SENT.equals(dm.getIrsMsgStatus()))
					{
						totalTradesFoIrsNotReportedOntimeFromIrs++;
					}
					
					/*
					 * Trades having only IRS info
					 * */
					if(TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && (elapsedTimeFOandSDRUpload==0L || elapsedTimeFOandSDRUpload>900000L ) && Constants.SENT.equals(dm.getIrsMsgStatus()))
					{
						totalTradesOnlyIrsNotReportedOntimeFromIrs++;
					}
					
					/*
					 * Trades having 2 way recon : FO + GTR 
					 * */
					if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getGtrUsi()) && (elapsedTimeFoResponseRt==0L || elapsedTimeFoResponseRt>900000L) )
					{
						totalTradesFoGtrNotInGtrOntime++;
					}
					
					/*
					 * Trades having only GTR info
					 * */
					if(TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getGtrUsi()) && (elapsedTimeFoResponseRt==0L || elapsedTimeFoResponseRt>900000L) )
					{
						totalTradesOnlyGtrNotInGtrOntime++;
					}
					
					/*------------- End section for total counting -------------*/
					
					/*------------- Start section for asset class wise counting -------------*/
					
					if(Constants.ASSET_CLASS_INTEREST_RATE.equals(dm.getAssetClass()))
					{
						/* Section for IR counting */
						if(Constants.Y.equals(dm.getFoRepFlag()) && (!Constants.NOT_TO_SEND.equals(dm.getIrsMsgStatus()) || !Constants.DUPLICATE.equals(dm.getIrsMsgStatus())))
						{
							 irFoTradeCount.add(dm.getFoTradeId()+Constants.SEPERATOR+dm.getFoTradeVersion()+Constants.SEPERATOR+dm.getFoTradeStatus()); 
							
							 /*FO trades break list*/
							if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()))
							{
								irTradeBreakForFO.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+dm.getFoTradeStatus());
								TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
								tb.setSystem(dm.getSystem());
								tb.setAction(Constants.EMPTY_STRING);
								tb.setProduct(dm.getProduct());
								tb.setSubProduct(dm.getSubProduct());
								tb.setMarketType(dm.getFoMarketType());
								tb.setMsgType(Constants.EMPTY_STRING);
								tb.setTradeId(dm.getFoTradeId());
								tb.setTradeVersion(dm.getFoTradeVersion());
								tb.setFoUsi(dm.getFoUsi());
								tb.setIrsUsi(Constants.EMPTY_STRING);
								tb.setGtrUsi(Constants.EMPTY_STRING);
								tb.setStatus(dm.getFoTradeStatus());
								irTradeBreaksListForFO.add(tb);
							}
						}
						if(!TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							String usi = !TimelinessUtils.IsNullOrBlank(dm.getIrsDtccUsi()) ? dm.getIrsDtccUsi() : dm.getIrsUsi();
							if(!TimelinessUtils.IsNullOrBlank(dm.getIrsMsgType())){
								if(Constants.RT.equals(dm.getIrsMsgType())){
									irFoIrsSetForRT.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+usi+Constants.COLON+dm.getIrsReportUploadTime());
								} else if(Constants.PET.equals(dm.getIrsMsgType())){
									irFoIrsSetForPET.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+usi+Constants.COLON+dm.getIrsReportUploadTime());
								}
							}
						}
						
						/*IRS trades break list*/
						if((TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) || TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							irTradeBreakForIRS.add(dm.getIrsTradeId()+Constants.COLON+dm.getIrsTradeVersion()+Constants.COLON+dm.getIrsTradeStatus()+Constants.COLON+dm.getIrsReportUploadTime());
							TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
							tb.setSystem(dm.getSystem());
							tb.setAction(!TimelinessUtils.IsNullOrBlank(dm.getGtrAction())?dm.getGtrAction():Constants.EMPTY_STRING);
							tb.setProduct(dm.getProduct());
							tb.setSubProduct(dm.getSubProduct());
							tb.setMarketType(dm.getIrsTransactionType());
							tb.setMsgType(dm.getIrsMsgType());
							tb.setTradeId(dm.getIrsTradeId());
							tb.setTradeVersion(dm.getIrsTradeVersion());
							tb.setFoUsi(Constants.EMPTY_STRING);
							tb.setIrsUsi(dm.getIrsUsi());
							tb.setGtrUsi(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())?dm.getGtrUsi():Constants.EMPTY_STRING);
							tb.setStatus(dm.getIrsTradeStatus());
							irTradeBreaksListForIRS.add(tb);
						}
						if(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())){
							if(Constants.RT.equals(dm.getIrsMsgType()) || Constants.RT.equals(dm.getGtrMessageType())){
								irGtrTradeCountForRT.add(dm.getGtrAction()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							} else if(Constants.PET.equals(dm.getIrsMsgType()) || Constants.PET.equals(dm.getGtrMessageType())){
								irGtrTradeCountForPET.add(dm.getGtrAction()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							}
							
							/*Count GTR breaks and add to Trade break list*/
							if(Constants.GTR.equals(dm.getSystem())){
								irTradeBreakForGTR.add(dm.getGtrMessageType()+Constants.COLON+dm.getGtrTradeParty1ReferenceNumber()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
								TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
								tb.setSystem(dm.getSystem());
								tb.setAction(dm.getGtrAction());
								tb.setProduct(!TimelinessUtils.IsNullOrBlank(dm.getProduct())?dm.getProduct():Constants.EMPTY_STRING);
								tb.setSubProduct(Constants.EMPTY_STRING);
								tb.setMarketType(dm.getGtrTransType());
								tb.setMsgType(dm.getGtrMessageType());
								tb.setTradeId(dm.getGtrTradeParty1ReferenceNumber());
								tb.setTradeVersion(Constants.EMPTY_STRING);
								tb.setFoUsi(Constants.EMPTY_STRING);
								tb.setIrsUsi(Constants.EMPTY_STRING);
								tb.setGtrUsi(dm.getGtrUsi());
								//tb.setStatus(dm.getDtccRespAcceptance());
								tb.setStatus(Constants.EMPTY_STRING);
								irTradeBreaksListForIRS.add(tb);
							}
						}
						
					} else if(Constants.ASSET_CLASS_CREDIT.equals(dm.getAssetClass()))
					{
						/* Section for CR counting */
						if(Constants.Y.equals(dm.getFoRepFlag()) && (!Constants.NOT_TO_SEND.equals(dm.getIrsMsgStatus()) || !Constants.DUPLICATE.equals(dm.getIrsMsgStatus())))
						{
							 crFoTradeCount.add(dm.getFoTradeId()+Constants.SEPERATOR+dm.getFoTradeVersion()+Constants.SEPERATOR+dm.getFoTradeStatus()); 
							
							 /*FO trades break list*/
							if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()))
							{
								crTradeBreakForFO.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+dm.getFoTradeStatus());
								TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
								tb.setSystem(dm.getSystem());
								tb.setAction(Constants.EMPTY_STRING);
								tb.setProduct(dm.getProduct());
								tb.setSubProduct(dm.getSubProduct());
								tb.setMarketType(dm.getFoMarketType());
								tb.setMsgType(Constants.EMPTY_STRING);
								tb.setTradeId(dm.getFoTradeId());
								tb.setTradeVersion(dm.getFoTradeVersion());
								tb.setFoUsi(dm.getFoUsi());
								tb.setIrsUsi(Constants.EMPTY_STRING);
								tb.setGtrUsi(Constants.EMPTY_STRING);
								tb.setStatus(dm.getFoTradeStatus());
								crTradeBreaksListForFO.add(tb);
							}
						}
						if(!TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							String usi = !TimelinessUtils.IsNullOrBlank(dm.getIrsDtccUsi()) ? dm.getIrsDtccUsi() : dm.getIrsUsi();
							if(!TimelinessUtils.IsNullOrBlank(dm.getIrsMsgType())){
								if(Constants.RT.equals(dm.getIrsMsgType())){
									crFoIrsSetForRT.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+usi+Constants.COLON+dm.getIrsReportUploadTime());
								} else if(Constants.PET.equals(dm.getIrsMsgType())){
									crFoIrsSetForPET.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+usi+Constants.COLON+dm.getIrsReportUploadTime());
								}
							}
						}
						/*IRS trades break list*/
						if((TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) || TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							crTradeBreakForIRS.add(dm.getIrsTradeId()+Constants.COLON+dm.getIrsTradeVersion()+Constants.COLON+dm.getIrsTradeStatus()+Constants.COLON+dm.getIrsReportUploadTime());
							TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
							tb.setSystem(dm.getSystem());
							tb.setAction(!TimelinessUtils.IsNullOrBlank(dm.getGtrAction())?dm.getGtrAction():Constants.EMPTY_STRING);
							tb.setProduct(dm.getProduct());
							tb.setSubProduct(dm.getSubProduct());
							tb.setMarketType(dm.getIrsTransactionType());
							tb.setMsgType(dm.getIrsMsgType());
							tb.setTradeId(dm.getIrsTradeId());
							tb.setTradeVersion(dm.getIrsTradeVersion());
							tb.setFoUsi(Constants.EMPTY_STRING);
							tb.setIrsUsi(dm.getIrsUsi());
							tb.setGtrUsi(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())?dm.getGtrUsi():Constants.EMPTY_STRING);
							tb.setStatus(dm.getIrsTradeStatus());
							crTradeBreaksListForIRS.add(tb);
						}
						if(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())){
							if(Constants.RT.equals(dm.getIrsMsgType()) || Constants.RT.equals(dm.getGtrMessageType())){
								crGtrTradeCountForRT.add(dm.getGtrAction()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							} else if(Constants.PET.equals(dm.getIrsMsgType()) || Constants.PET.equals(dm.getGtrMessageType())){
								crGtrTradeCountForPET.add(dm.getGtrAction()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							}
						}
						
						/*Count GTR breaks and add to Trade break list*/
						if(Constants.GTR.equals(dm.getSystem())){
							crTradeBreakForGTR.add(dm.getGtrMessageType()+Constants.COLON+dm.getGtrTradeParty1ReferenceNumber()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
							tb.setSystem(dm.getSystem());
							tb.setAction(dm.getGtrAction());
							tb.setProduct(!TimelinessUtils.IsNullOrBlank(dm.getProduct())?dm.getProduct():Constants.EMPTY_STRING);
							tb.setSubProduct(Constants.EMPTY_STRING);
							tb.setMarketType(dm.getGtrTransType());
							tb.setMsgType(dm.getGtrMessageType());
							tb.setTradeId(dm.getGtrTradeParty1ReferenceNumber());
							tb.setTradeVersion(Constants.EMPTY_STRING);
							tb.setFoUsi(Constants.EMPTY_STRING);
							tb.setIrsUsi(Constants.EMPTY_STRING);
							tb.setGtrUsi(dm.getGtrUsi());
							//tb.setStatus(dm.getDtccRespAcceptance());
							tb.setStatus(Constants.EMPTY_STRING);
							crTradeBreaksListForIRS.add(tb);
						}
						
					}  else if(Constants.ASSET_CLASS_EQUITY.equals(dm.getAssetClass()))
					{
						/* Section for EQ counting */
						if(Constants.Y.equals(dm.getFoRepFlag()) && (!Constants.NOT_TO_SEND.equals(dm.getIrsMsgStatus()) || !Constants.DUPLICATE.equals(dm.getIrsMsgStatus())))
						{
							 eqFoTradeCount.add(dm.getFoTradeId()+Constants.SEPERATOR+dm.getFoTradeVersion()+Constants.SEPERATOR+dm.getFoTradeStatus());
							
							 /*FO trades break list*/
							if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()))
							{
								eqTradeBreakForFO.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+dm.getFoTradeStatus());
								TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
								tb.setSystem(dm.getSystem());
								tb.setAction(Constants.EMPTY_STRING);
								tb.setProduct(dm.getProduct());
								tb.setSubProduct(dm.getSubProduct());
								tb.setMarketType(dm.getFoMarketType());
								tb.setMsgType(Constants.EMPTY_STRING);
								tb.setTradeId(dm.getFoTradeId());
								tb.setTradeVersion(dm.getFoTradeVersion());
								tb.setFoUsi(dm.getFoUsi());
								tb.setIrsUsi(Constants.EMPTY_STRING);
								tb.setGtrUsi(Constants.EMPTY_STRING);
								tb.setStatus(dm.getFoTradeStatus());
								eqTradeBreaksListForFO.add(tb);
							}
						}
						if(!TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							String usi = !TimelinessUtils.IsNullOrBlank(dm.getIrsDtccUsi()) ? dm.getIrsDtccUsi() : dm.getIrsUsi();
							if(!TimelinessUtils.IsNullOrBlank(dm.getIrsMsgType())){
								if(Constants.RT.equals(dm.getIrsMsgType())){
									eqFoIrsSetForRT.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+usi+Constants.COLON+dm.getIrsReportUploadTime());
								} else if(Constants.PET.equals(dm.getIrsMsgType())){
									eqFoIrsSetForPET.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+usi+Constants.COLON+dm.getIrsReportUploadTime());
								}
							}
						}
						/*IRS trades break list*/
						if((TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) || TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							eqTradeBreakForIRS.add(dm.getIrsTradeId()+Constants.COLON+dm.getIrsTradeVersion()+Constants.COLON+dm.getIrsTradeStatus()+Constants.COLON+dm.getIrsReportUploadTime());
							TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
							tb.setSystem(dm.getSystem());
							tb.setAction(!TimelinessUtils.IsNullOrBlank(dm.getGtrAction())?dm.getGtrAction():Constants.EMPTY_STRING);
							tb.setProduct(dm.getProduct());
							tb.setSubProduct(dm.getSubProduct());
							tb.setMarketType(dm.getIrsTransactionType());
							tb.setMsgType(dm.getIrsMsgType());
							tb.setTradeId(dm.getIrsTradeId());
							tb.setTradeVersion(dm.getIrsTradeVersion());
							tb.setFoUsi(Constants.EMPTY_STRING);
							tb.setIrsUsi(dm.getIrsUsi());
							tb.setGtrUsi(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())?dm.getGtrUsi():Constants.EMPTY_STRING);
							tb.setStatus(dm.getIrsTradeStatus());
							eqTradeBreaksListForIRS.add(tb);
						}
						if(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())){
							if(Constants.RT.equals(dm.getIrsMsgType()) || Constants.RT.equals(dm.getGtrMessageType())){
								eqGtrTradeCountForRT.add(dm.getGtrAction()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							} else if(Constants.PET.equals(dm.getIrsMsgType()) || Constants.PET.equals(dm.getGtrMessageType())){
								eqGtrTradeCountForPET.add(dm.getGtrAction()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							}
						}
						
						/*Count GTR breaks and add to Trade break list*/
						if(Constants.GTR.equals(dm.getSystem())){
							eqTradeBreakForGTR.add(dm.getGtrMessageType()+Constants.COLON+dm.getGtrTradeParty1ReferenceNumber()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
							tb.setSystem(dm.getSystem());
							tb.setAction(dm.getGtrAction());
							tb.setProduct(!TimelinessUtils.IsNullOrBlank(dm.getProduct())?dm.getProduct():Constants.EMPTY_STRING);
							tb.setSubProduct(Constants.EMPTY_STRING);
							tb.setMarketType(dm.getGtrTransType());
							tb.setMsgType(dm.getGtrMessageType());
							tb.setTradeId(dm.getGtrTradeParty1ReferenceNumber());
							tb.setTradeVersion(Constants.EMPTY_STRING);
							tb.setFoUsi(Constants.EMPTY_STRING);
							tb.setIrsUsi(Constants.EMPTY_STRING);
							tb.setGtrUsi(dm.getGtrUsi());
							//tb.setStatus(dm.getDtccRespAcceptance());
							tb.setStatus(Constants.EMPTY_STRING);
							eqTradeBreaksListForIRS.add(tb);
						}
					}  else if(Constants.ASSET_CLASS_COMMODITY.equals(dm.getAssetClass()))
					{
						/* Section for COMM counting */
						if(Constants.Y.equals(dm.getFoRepFlag()) && (!Constants.NOT_TO_SEND.equals(dm.getIrsMsgStatus()) || !Constants.DUPLICATE.equals(dm.getIrsMsgStatus())))
						{
							 commFoTradeCount.add(dm.getFoTradeId()+Constants.SEPERATOR+dm.getFoTradeVersion()+Constants.SEPERATOR+dm.getFoTradeStatus()); 
							
							 /*FO trades break list*/
							if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()))
							{
								commTradeBreakForFO.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion()+Constants.COLON+dm.getFoTradeStatus());
								TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
								tb.setSystem(dm.getSystem());
								tb.setAction(Constants.EMPTY_STRING);
								tb.setProduct(dm.getProduct());
								tb.setSubProduct(dm.getSubProduct());
								tb.setMarketType(dm.getFoMarketType());
								tb.setMsgType(Constants.EMPTY_STRING);
								tb.setTradeId(dm.getFoTradeId());
								tb.setTradeVersion(dm.getFoTradeVersion());
								tb.setFoUsi(dm.getFoUsi());
								tb.setIrsUsi(Constants.EMPTY_STRING);
								tb.setGtrUsi(Constants.EMPTY_STRING);
								tb.setStatus(dm.getFoTradeStatus());
								commTradeBreaksListForFO.add(tb);
							}
						}
						if(!TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId()) && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							commFoIrsSet.add(dm.getFoTradeId()+Constants.COLON+dm.getFoTradeVersion());
						}
						/*IRS trades break list*/
						if((TimelinessUtils.IsNullOrBlank(dm.getFoTradeId()) || TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())) && !TimelinessUtils.IsNullOrBlank(dm.getIrsTradeId())  && Constants.SENT.equals(dm.getIrsMsgStatus()))
						{
							commTradeBreakForIRS.add(dm.getIrsTradeId()+Constants.COLON+dm.getIrsTradeVersion()+Constants.COLON+dm.getIrsTradeStatus()+Constants.COLON+dm.getIrsReportUploadTime());
							TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
							tb.setSystem(dm.getSystem());
							tb.setAction(!TimelinessUtils.IsNullOrBlank(dm.getGtrAction())?dm.getGtrAction():Constants.EMPTY_STRING);
							tb.setProduct(dm.getProduct());
							tb.setSubProduct(dm.getSubProduct());
							tb.setMarketType(dm.getIrsTransactionType());
							tb.setMsgType(dm.getIrsMsgType());
							tb.setTradeId(dm.getIrsTradeId());
							tb.setTradeVersion(dm.getIrsTradeVersion());
							tb.setFoUsi(Constants.EMPTY_STRING);
							tb.setIrsUsi(dm.getIrsUsi());
							tb.setGtrUsi(!TimelinessUtils.IsNullOrBlank(dm.getGtrUsi())?dm.getGtrUsi():Constants.EMPTY_STRING);
							tb.setStatus(dm.getIrsTradeStatus());
							commTradeBreaksListForIRS.add(tb);
						}
						if(Constants.Y.equals(dm.getDtccRespRecv())){
							commGtrTradeCount++;
						}
						
						/*Count GTR breaks and add to Trade break list*/
						if(Constants.GTR.equals(dm.getSystem())){
							commTradeBreakForGTR.add(dm.getGtrMessageType()+Constants.COLON+dm.getGtrTradeParty1ReferenceNumber()+Constants.COLON+dm.getGtrUsi()+Constants.COLON+dm.getSdrSubmissionTime());
							TradesCausingBreakDetails tb = new TradesCausingBreakDetails();
							tb.setSystem(dm.getSystem());
							tb.setAction(dm.getGtrAction());
							tb.setProduct(!TimelinessUtils.IsNullOrBlank(dm.getProduct())?dm.getProduct():Constants.EMPTY_STRING);
							tb.setSubProduct(Constants.EMPTY_STRING);
							tb.setMarketType(dm.getGtrTransType());
							tb.setMsgType(dm.getGtrMessageType());
							tb.setTradeId(dm.getGtrTradeParty1ReferenceNumber());
							tb.setTradeVersion(Constants.EMPTY_STRING);
							tb.setFoUsi(Constants.EMPTY_STRING);
							tb.setIrsUsi(Constants.EMPTY_STRING);
							tb.setGtrUsi(dm.getGtrUsi());
							//tb.setStatus(dm.getDtccRespAcceptance());
							tb.setStatus(Constants.EMPTY_STRING);
							commTradeBreaksListForIRS.add(tb);
						}
					}
					
					
					/*------------- End section for asset class wise counting -------------*/
					
					out.write(checkNull(dm.getSystem()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getAssetClass()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getProduct()));
					out.write(Constants.SEPERATOR);
					if(!TimelinessUtils.IsNullOrBlank(dm.getExecutionDate()))
						out.write(dm.getExecutionDate() !=0L ?DateUtil.formatTimeStampForReport(dm.getExecutionDate()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoTradeId()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoUsi()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoSdrEligibleTrade()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getFoJurisdiction()));
					out.write(Constants.SEPERATOR);
					out.write(dm.getIrsRecvTimestamp()!=0L?DateUtil.formatTimeStampForReport(dm.getIrsRecvTimestamp()):Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getIrsTradeId()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(TimelinessUtils.IsNullOrBlank(dm.getIrsDtccUsi())?dm.getIrsUsi():dm.getIrsDtccUsi()));
					out.write(Constants.SEPERATOR);
					if(!TimelinessUtils.IsNullOrBlank(dm.getIrsReportUploadTime()))
						out.write(dm.getIrsReportUploadTime()!=0L?DateUtil.formatTimeStampForReport(dm.getIrsReportUploadTime()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getIrsMsgType()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getIrsMsgStatus()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getIrsDescription()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(DateUtil.reportFormattedTimeDifference(elapsedTimeFOandSDRUpload)));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getGtrAction()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getGtrUsi()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getDtccRespRecv()));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getDtccRespAcceptance()));
					out.write(Constants.SEPERATOR);
					if(!TimelinessUtils.IsNullOrBlank(dm.getSdrSubmissionTime()))
						out.write(dm.getSdrSubmissionTime()!=0L?DateUtil.formatTimeStampForReport(dm.getSdrSubmissionTime()):Constants.EMPTY_STRING);
					else 
						out.write(Constants.EMPTY_STRING);
					out.write(Constants.SEPERATOR);
					out.write(checkNull(Constants.Y.equals(dm.getDtccRespRecv()) ? DateUtil.reportFormattedTimeDifference(elapsedTimeFoResponseRt):Constants.EMPTY_STRING));
					out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getReportingParty()));
					/*out.write(Constants.SEPERATOR);
					out.write(checkNull(dm.getSdrEligibility()));*/
					out.newLine();
				}
				
				
				/*--------- Create data for the mail body ---------*/
				
				/* Summarize for IR */
				AssetClassWiseDetails irSummary = new AssetClassWiseDetails();
				irSummary.setFoCount(irFoTradeCount.size());
				irSummary.setFoIrsCountForRT(irFoIrsSetForRT.size());
				irSummary.setFoIrsCountForPET(irFoIrsSetForPET.size());
				irSummary.setTradeBreaksForFO(irTradeBreakForFO.size());
				irSummary.setTradeBreaksForIRS(irTradeBreakForIRS.size());
				irSummary.setTradeBreaksForGTR(irTradeBreakForGTR.size());
				irSummary.setListOfBrokenTradesForFO(irTradeBreaksListForFO);
				irSummary.setListOfBrokenTradesForIRS(irTradeBreaksListForIRS);
				irSummary.setGtrCountForRT(irGtrTradeCountForRT.size());
				irSummary.setGtrCountForPET(irGtrTradeCountForPET.size());
				
				/* Summarize for CR */
				AssetClassWiseDetails crSummary = new AssetClassWiseDetails();
				crSummary.setFoCount(crFoTradeCount.size());
				crSummary.setFoIrsCountForRT(crFoIrsSetForRT.size());
				crSummary.setFoIrsCountForPET(crFoIrsSetForPET.size());
				crSummary.setTradeBreaksForFO(crTradeBreakForFO.size());
				crSummary.setTradeBreaksForIRS(crTradeBreakForIRS.size());
				crSummary.setTradeBreaksForGTR(crTradeBreakForGTR.size());
				crSummary.setListOfBrokenTradesForFO(crTradeBreaksListForFO);
				crSummary.setListOfBrokenTradesForIRS(crTradeBreaksListForIRS);
				crSummary.setGtrCountForRT(crGtrTradeCountForRT.size());
				crSummary.setGtrCountForPET(crGtrTradeCountForPET.size());
				
				/* Summarize for EQ */
				AssetClassWiseDetails eqSummary = new AssetClassWiseDetails();
				eqSummary.setFoCount(eqFoTradeCount.size());
				eqSummary.setFoIrsCountForRT(eqFoIrsSetForRT.size());
				eqSummary.setFoIrsCountForPET(eqFoIrsSetForPET.size());
				eqSummary.setTradeBreaksForFO(eqTradeBreakForFO.size());
				eqSummary.setTradeBreaksForIRS(eqTradeBreakForIRS.size());
				eqSummary.setTradeBreaksForGTR(eqTradeBreakForGTR.size());
				eqSummary.setListOfBrokenTradesForFO(eqTradeBreaksListForFO);
				eqSummary.setListOfBrokenTradesForIRS(eqTradeBreaksListForIRS);
				eqSummary.setGtrCountForRT(eqGtrTradeCountForRT.size());
				eqSummary.setGtrCountForPET(eqGtrTradeCountForPET.size());				
				
				/* Summarize for COMM */
				AssetClassWiseDetails commSummary = new AssetClassWiseDetails();
				commSummary.setFoCount(commFoTradeCount.size());
				commSummary.setFoIrsCountForRT(commFoIrsSet.size());
				commSummary.setTradeBreaksForFO(commTradeBreakForFO.size());
				commSummary.setTradeBreaksForIRS(commTradeBreakForIRS.size());
				commSummary.setTradeBreaksForGTR(commTradeBreakForGTR.size());
				commSummary.setListOfBrokenTradesForFO(commTradeBreaksListForFO);
				commSummary.setListOfBrokenTradesForIRS(commTradeBreaksListForIRS);
				commSummary.setGtrCountForRT(commGtrTradeCount);
				
				/* Collect all summaries into a single map */
				//Map<String, AssetClassWiseDetails> summaryReport = new HashMap<String, AssetClassWiseDetails>();
				summaryReport.put(Constants.ASSET_CLASS_INTEREST_RATE,irSummary);
				summaryReport.put(Constants.ASSET_CLASS_CREDIT,	crSummary);
				summaryReport.put(Constants.ASSET_CLASS_EQUITY,	eqSummary);
				summaryReport.put(Constants.ASSET_CLASS_COMMODITY, commSummary);
				/*-----------------------------*/
		
				writeFileFooter(out,reconId);
		
				logger.debug("Generated file..." + fileName.getAbsolutePath() + " for "
						+ dataList.size() + " records");
		
				/*File targetFolder = null;
				targetFolder = outputFolderTimeliness;
				resultingFile = new File(targetFolder, fileName);
				FileUtils.moveFile(tempFile, resultingFile);
				*/
				logger.info("Timeliness Debug Report generated at : " + fileName.getAbsolutePath());
				logger.info("Timeliness Debug Report generated: records = " + dataList.size());
				
				/* Update the report_generated column to Y which is by default set to N*/
				//timelinessDao.updateReportGenerated(uniqueFileId);
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}catch (Exception e){
			 e.printStackTrace();
			}
			finally {
				try {
					out.close();
					if(isTimelinessMailEnable)
						timelinessMailGeneration(fileName, reconId, summaryReport);
				} catch (IOException e) {
					logger.error("Could not close temporary file : "+fileName.getAbsolutePath());
				}
			}
		}else
			logger.info("No data to be reported");
	}
	

	private void timelinessMailGeneration(File fileName, String reconId, Map<String, AssetClassWiseDetails> summaryReport){
		timelinessRepService.submit(new TimelinessReportRequest(fileName,reconId,summaryReport));
	}
	
	private long findElapsedTime(Long executionDate, Long elapsedTime) {
		long diff=0L;
		if(!TimelinessUtils.IsNullOrBlank(executionDate) && !TimelinessUtils.IsNullOrBlank(elapsedTime)&&executionDate!=0L&&elapsedTime!=0L)
			diff=elapsedTime-executionDate;
		return diff;
	}

	private String checkNull(String value) {
		String val = Constants.EMPTY_STRING;
		if(StringUtils.isNotBlank(value)){
			val=value;
		}
		return Constants.QUOTES+val+Constants.QUOTES;
	}
	

	private void writeFileFooter(BufferedWriter out,String uniqueFileId) {
		try {
			out.write(
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					//foTotalReportableTrades+"(Total Trades to be reported FO)"+Constants.SEPERATOR+
					(irFoTradeCount.size()+crFoTradeCount.size()+eqFoTradeCount.size()+commFoTradeCount.size())+"(Total Trades to be reported FO)"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					irsTotalFoIRSReportableTrades+"(Total in Internal Reporting Solution(both in FO and IRS))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesFoIrsNotReportedOntimeFromIrs+"(Trades not reported on Time from IRS(both in FO and IRS))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					dtccTotalReportableTrades+"(Total Trades Reported in DTCC(both in FO and GTR))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesFoGtrNotInGtrOntime+"(Trades not in GTR on time(both in FO and GTR))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					""
				);
			out.newLine();
			
			out.write(
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					irsTotalOnlyInIRSReportableTrades+"(Total in Internal Reporting Solution(Only in IRS))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesOnlyIrsNotReportedOntimeFromIrs+"(Trades not reported on Time from IRS(Only in IRS))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesOnlyGtrNotInGtrOntime+"(Trades not in GTR on time(Only in GTR))"+Constants.SEPERATOR+
					Constants.SEPERATOR+
					""
				);
			out.newLine();
			
			out.write(Constants.SEPERATOR+Constants.UNIQUEID+
					Constants.SEPERATOR+uniqueFileId);
			out.newLine();
			
			/*out.write(
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					foTotalReportableTrades+Constants.SEPERATOR+
					irsTotalReportableTrades+Constants.SEPERATOR+
					dtccTotalReportableTrades+Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesNotReportedOntimeFromIrs+Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					Constants.SEPERATOR+
					totalTradesNotInGtrOntime+Constants.SEPERATOR+
					Constants.SEPERATOR+
					""
				);
			out.newLine();*/
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void writeFileHeader(BufferedWriter out) {
		try {
			out.write(
					"System"+Constants.SEPERATOR+
					"Asset Class"+Constants.SEPERATOR+
					"Product"+Constants.SEPERATOR+
					"Execution Time  "+Constants.SEPERATOR+
					"FO Trade ID "+Constants.SEPERATOR+
					"FO USI"+Constants.SEPERATOR+
					"FO SDR Eligible Trade"+Constants.SEPERATOR+
					"FO Jurisdiction"+Constants.SEPERATOR+
					"IRS Receive time"+Constants.SEPERATOR+
					"IRS Trade ID "+Constants.SEPERATOR+
					"Internal Reporting Solution USI"+Constants.SEPERATOR+
					
					"IRS RT upload time "+Constants.SEPERATOR+
					"IRS Message Type"+Constants.SEPERATOR+
					"IRS Message Status"+Constants.SEPERATOR+
					"IRS Description"+Constants.SEPERATOR+
					"FO vs DTCC upload"+Constants.SEPERATOR+
					"GTR Action"+Constants.SEPERATOR+
					"GTR USI From DTCC"+Constants.SEPERATOR+
					"DTCC response received?(Y/N)"+Constants.SEPERATOR+
					"DTCC response(Accepted/Rejected)"+Constants.SEPERATOR+
					"DTCC Submission Time"+Constants.SEPERATOR+
					"FO vs DTCC submission"+Constants.SEPERATOR+
					"Reporting Party"
					/*+Constants.SEPERATOR+
					"SDR Eligibility"*/
				);
			out.newLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String getFileName(String uniqueFileId) {
		//logger.info(new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date()));
		return Constants.TimelinessDebugFileName+new SimpleDateFormat("yyyyMMdd").format(new Date())+"_"+uniqueFileId+fileExtn;
	}
}
