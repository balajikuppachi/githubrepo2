package com.wf.df.sdr.dto;

public class TradesCausingBreakDetails {

	String system;
	String action;
	String product;
	String subProduct;
	String marketType;
	String msgType;
	String tradeId;
	String tradeVersion;
	String foUsi;
	String irsUsi;
	String gtrUsi;
	String status;
	String irsDescription;
	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getSubProduct() {
		return subProduct;
	}
	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}
	public String getMarketType() {
		return marketType;
	}
	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getTradeVersion() {
		return tradeVersion;
	}
	public void setTradeVersion(String tradeVersion) {
		this.tradeVersion = tradeVersion;
	}
	public String getFoUsi() {
		return foUsi;
	}
	public void setFoUsi(String foUsi) {
		this.foUsi = foUsi;
	}
	public String getIrsUsi() {
		return irsUsi;
	}
	public void setIrsUsi(String irsUsi) {
		this.irsUsi = irsUsi;
	}
	public String getGtrUsi() {
		return gtrUsi;
	}
	public void setGtrUsi(String gtrUsi) {
		this.gtrUsi = gtrUsi;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIrsDescription() {
		return irsDescription;
	}
	public void setIrsDescription(String irsDescription) {
		this.irsDescription = irsDescription;
	}
	
}
