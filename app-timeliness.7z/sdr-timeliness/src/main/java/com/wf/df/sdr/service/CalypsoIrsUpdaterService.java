package com.wf.df.sdr.service;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.common.Constants;

@Component
@ManagedResource(description="Update Calypso IRS details")
public class CalypsoIrsUpdaterService extends BaseIrsUpdaterService{

	@ManagedOperation(description="Trigger Calypso IRS Upload")
	public void updateForIrsDetailsForCalypsoSystem(String reconId){
		updateForIrsDetails(reconId,Constants.ASSET_CLASS_INTEREST_RATE);
		updateForIrsDetails(reconId,Constants.ASSET_CLASS_CREDIT);
	}
}
