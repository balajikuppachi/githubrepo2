package com.wf.df.sdr.commons;

import org.apache.log4j.Logger;

public final class TimelinessUtils {
	static Logger logger = Logger.getLogger(TimelinessUtils.class);
	
	/**
	 * 
	 * @param obj
	 * @return
	 */
	public static final boolean IsNullOrBlank(Object obj) {

		if (obj instanceof String) {
			return ((String)obj).trim().length() == 0;
		} else if (obj == null) {
			return true;
		} else
			return false;
	}
	
	public static final boolean IsNull(Object obj) {

		 if (obj == null) {
			return true;
		} else
			return false;
	}
	
	/*public static String convertListToDelimitedString(List<String> coll, String delim) {
		if (CollectionUtils.isEmpty(coll)) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		Iterator<String> it = coll.iterator();
		String value = null;
		while (it.hasNext()) {
			
			value = it.next();
			if(value == null || "null".equalsIgnoreCase(value))
				continue;
			
			sb.append(value);
			if (it.hasNext()) {
				sb.append(delim);
			}
		}
		return sb.toString();
	}*/

	/*public static final boolean IsNullOrNone(Object obj) {
		String s = null;
		if (obj instanceof String) {
			s = (String)obj;
			if(Constants.NONE.equalsIgnoreCase(s.trim())){
				return true;
			} else if (Constants.NOT_FOUND.equalsIgnoreCase(s.trim())) {
				return true;
			}
			return s.trim().length() == 0;
		} else if (obj == null) {
			return true;
		} else
			return false;
	}*/

}
