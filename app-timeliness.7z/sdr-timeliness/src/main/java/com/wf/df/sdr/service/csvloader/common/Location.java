package com.wf.df.sdr.service.csvloader.common;

public interface Location {
	String asString();
}
