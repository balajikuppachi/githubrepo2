package com.wf.df.sdr.service.csvloader.beans;

import java.util.Date;

public class DtccEqBean implements BaseBean{

	private String gtrAction;
	private String transactionType;
	private String messageType;
	private String usiPrefix;
	private String usiValue;
	private String assetClass;
	private String productIdValue;
	private String status;
	private Date submissionDateTime;
	//private String dataSubmitterMessageId;
	private String party1TransactionId;
	
	public String getGtrAction() {
		return gtrAction;
	}
	public void setGtrAction(String gtrAction) {
		this.gtrAction = gtrAction;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getUsiPrefix() {
		return usiPrefix;
	}
	public void setUsiPrefix(String usiPrefix) {
		this.usiPrefix = usiPrefix;
	}
	public String getUsiValue() {
		return usiValue;
	}
	public void setUsiValue(String usiValue) {
		this.usiValue = usiValue;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getProductIdValue() {
		return productIdValue;
	}
	public void setProductIdValue(String productIdValue) {
		this.productIdValue = productIdValue;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getSubmissionDateTime() {
		return submissionDateTime;
	}
	public void setSubmissionDateTime(Date submissionDateTime) {
		this.submissionDateTime = submissionDateTime;
	}

	/*public String getDataSubmitterMessageId() {
		return dataSubmitterMessageId;
	}
	public void setDataSubmitterMessageId(String dataSubmitterMessageId) {
		this.dataSubmitterMessageId = dataSubmitterMessageId;
	}*/
	public String getParty1TransactionId() {
		return party1TransactionId;
	}
	public void setParty1TransactionId(String party1TransactionId) {
		this.party1TransactionId = party1TransactionId;
	}
	
	@Override
	public String toString() {
		return "DtccEqBean [gtrAction=" + gtrAction + ", transactionType="
				+ transactionType + ", messageType=" + messageType
				+ ", usiPrefix=" + usiPrefix + ", usiValue=" + usiValue
				+ ", assetClass=" + assetClass + ", productIdValue="
				+ productIdValue + ", status=" + status
				+ ", submissionDateTime=" + submissionDateTime
				+ ", party1TransactionId=" + party1TransactionId + "]";
	}
	
}
