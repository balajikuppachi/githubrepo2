package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.ReconTimelinessIrsGtrDao;
import com.wf.df.sdr.dto.ReconTimelinessIrsGtrDomain;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public class ReconTimelinessIrsGtrDaoImpl extends AbstractDAO implements ParameterizedRowMapper<ReconTimelinessIrsGtrDomain>,ReconTimelinessIrsGtrDao {

	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recon_timeliness_irs_gtr";
	}
	
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(ReconTimelinessIrsGtrDomain dto) {
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( irs_system, irs_asset_class, irs_product, irs_sub_product, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trans_type, irs_exec_time, irs_trade_status, irs_report_upload_time, irs_message_type, irs_msg_status, irs_description, irs_rep_flag, gtr_action, gtr_asset_class, gtr_trade_party_1_reference_number, gtr_usi, gtr_resp_recv, gtr_resp_acceptance, gtr_submission_time, gtr_message_type, gtr_trans_type, gtr_rep_flag, recon_id,gtr_exec_time ) VALUES ( ? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,?,?)", dto.getIrsSystem(), dto.getIrsAssetClass(), dto.getIrsProduct(), dto.getIrsSubProduct(), dto.getIrsRecvTimestamp().longValue()+"", dto.getIrsSendId(), dto.getIrsTradeId(), dto.getIrsTradeVersion(), dto.getIrsUsi(), dto.getIrsDtccUsi(), dto.getIrsTransType(), dto.getIrsExecTime().longValue()+"", dto.getIrsTradeStatus(), dto.getIrsReportUploadTime().longValue()+"", dto.getIrsMessageType(), dto.getIrsMsgStatus(), dto.getIrsDescription(), dto.getIrsRepFlag(), dto.getGtrAction(), dto.getGtrAssetClass(), dto.getGtrTradeParty1ReferenceNumber(), dto.getGtrUsi(), dto.getGtrRespRecv(), dto.getGtrRespAcceptance(), dto.getGtrSubmissionTime().longValue()+"", dto.getGtrMessageType(), dto.getGtrTransType(), dto.getGtrRepFlag(), dto.getReconId(),dto.getGtrExecTime().longValue()+"");
	}

	/** 
	 * Returns all rows from the recon_timeliness_irs_gtr table that match the criteria for recon_id.
	 */
	@Transactional
	public List<ReconTimelinessIrsGtrDomain> findAll(String reconId) throws TimelinessDomainException {
		try {
			return jdbcTemplate.query("SELECT irs_system, irs_asset_class, irs_product, irs_sub_product, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trans_type, irs_exec_time, irs_trade_status, irs_report_upload_time, irs_message_type, irs_msg_status, irs_description, irs_rep_flag, gtr_action, gtr_asset_class, gtr_trade_party_1_reference_number, gtr_usi, gtr_resp_recv, gtr_resp_acceptance, gtr_submission_time, gtr_message_type, gtr_trans_type, gtr_rep_flag, recon_id,gtr_exec_time  FROM " + getTableName()+ " WHERE recon_id = ? ", this,reconId);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	
	/** 
	 * Returns all rows from the recon_timeliness_irs_gtr table that match the criteria for recon_id and irs_asset_class.
	 */
	@Transactional
	public List<ReconTimelinessIrsGtrDomain> findAllByAssetClass(String reconId, String assetClass) throws TimelinessDomainException {
		try {
			return jdbcTemplate.query("SELECT irs_system, irs_asset_class, irs_product, irs_sub_product, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trans_type, irs_exec_time, irs_trade_status, irs_report_upload_time, irs_message_type, irs_msg_status, irs_description, irs_rep_flag, gtr_action, gtr_asset_class, gtr_trade_party_1_reference_number, gtr_usi, gtr_resp_recv, gtr_resp_acceptance, gtr_submission_time, gtr_message_type, gtr_trans_type, gtr_rep_flag, recon_id,gtr_exec_time  FROM " + getTableName()+ " WHERE recon_id = ? and irs_asset_class in (?)", this,reconId,assetClass);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new TimelinessDomainException("Query failed", e);
		}
	}

	@Override
	public ReconTimelinessIrsGtrDomain mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		
		ReconTimelinessIrsGtrDomain dto= new ReconTimelinessIrsGtrDomain();
		
		dto.setIrsSystem(rs.getString(1));
		dto.setIrsAssetClass(rs.getString(2));
		dto.setIrsProduct(rs.getString(3));
		dto.setIrsSubProduct(rs.getString(4));
		dto.setIrsRecvTimestamp(rs.getLong(5));
		dto.setIrsSendId(rs.getString(6));
		dto.setIrsTradeId(rs.getString(7));
		dto.setIrsTradeVersion(rs.getString(8));
		dto.setIrsUsi(rs.getString(9));
		dto.setIrsDtccUsi(rs.getString(10));
		dto.setIrsTransType(rs.getString(11));
		dto.setIrsExecTime(Long.parseLong(null!=rs.getString(12)?rs.getString(12):"0"));
		dto.setIrsTradeStatus(rs.getString(13));
		dto.setIrsReportUploadTime(Long.parseLong(null!=rs.getString(14)?rs.getString(14):"0"));
		dto.setIrsMessageType(rs.getString(15));
		dto.setIrsMsgStatus(rs.getString(16));
		dto.setIrsDescription(rs.getString(17));
		dto.setIrsRepFlag(rs.getString(18));
		dto.setGtrAction(rs.getString(19));
		dto.setGtrAssetClass(rs.getString(20));
		dto.setGtrTradeParty1ReferenceNumber(rs.getString(21));
		dto.setGtrUsi(rs.getString(22));
		dto.setGtrRespRecv(rs.getString(23));
		dto.setGtrRespAcceptance(rs.getString(24));
		dto.setGtrSubmissionTime(Long.parseLong(null!=rs.getString(25)?rs.getString(25):"0"));
		dto.setGtrMessageType(rs.getString(26));
		dto.setGtrTransType(rs.getString(27));
		dto.setGtrRepFlag(rs.getString(28));
		dto.setReconId(rs.getString(29));
		dto.setGtrExecTime(Long.parseLong(null!=rs.getString(30)?rs.getString(30):"0"));
		return dto;
	}

	
	@Transactional
	public int updateDtccDetailsUsingIrsKey(ReconTimelinessIrsGtrDomain dto) throws TimelinessDomainException {
		try {
			return jdbcTemplate.update("UPDATE " + getTableName() + " set gtr_action=?, gtr_asset_class=?, gtr_trade_party_1_reference_number=?, gtr_usi=?, gtr_submission_time=?, gtr_resp_recv='Y', gtr_resp_acceptance=?, gtr_message_type=?, gtr_trans_type=? ,gtr_exec_time=? where irs_send_id = "+
				"(select min(irs_send_id) from " + getTableName() + " where irs_trade_id=? and irs_asset_class=? and gtr_usi is null and (irs_usi=? or irs_dtcc_usi=?) and irs_msg_status='SENT' and recon_id=? and irs_message_type=?) and irs_message_type=? and recon_id=?",
				dto.getGtrAction(),dto.getGtrAssetClass(),dto.getGtrTradeParty1ReferenceNumber(),dto.getGtrUsi(),dto.getGtrSubmissionTime().longValue()+"",dto.getGtrRespAcceptance(),dto.getGtrMessageType(),dto.getGtrTransType(),dto.getGtrExecTime().longValue()+"" ,dto.getIrsTradeId(),dto.getGtrAssetClass(), dto.getIrsUsi(),dto.getIrsUsi(),dto.getReconId(),dto.getGtrMessageType(),dto.getGtrMessageType(),dto.getReconId());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	
	/**
	 * Update DTCC USI and Response time for the trade_id
	 */
	@Transactional
	public int updateEqDtccDetails(ReconTimelinessIrsGtrDomain dto) throws TimelinessDomainException {
		try {
			return jdbcTemplate.update("UPDATE " + getTableName() + " set gtr_action=?, gtr_asset_class=?, gtr_trade_party_1_reference_number=?, gtr_usi=?, gtr_submission_time=?, gtr_resp_recv='Y', gtr_resp_acceptance=?, gtr_message_type=?, gtr_trans_type=? ,gtr_exec_time=? where irs_trade_id=? " +
					"and irs_trade_version=? and irs_msg_status='SENT' and irs_message_type=? and recon_id=? ",
					dto.getGtrAction(),dto.getGtrAssetClass(),dto.getGtrTradeParty1ReferenceNumber(),dto.getGtrUsi(), dto.getGtrSubmissionTime().longValue()+"", dto.getGtrRespAcceptance(),dto.getGtrMessageType(),dto.getGtrTransType(),dto.getGtrExecTime().longValue()+"" ,dto.getIrsTradeId(), dto.getIrsTradeVersion(),dto.getGtrMessageType(),dto.getReconId());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	
	@Transactional
	public void updateCommGtrDetails(ReconTimelinessIrsGtrDomain dto) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set gtr_action=?, gtr_asset_class=?, gtr_trade_party_1_reference_number=?, gtr_usi=?, gtr_submission_time=?, gtr_resp_recv=?, gtr_resp_acceptance=?, gtr_message_type=?, gtr_trans_type=? ,gtr_exec_time=? where irs_trade_id=? and irs_trade_version=? and irs_msg_status='SENT'  and irs_send_id=? ",
					dto.getGtrAction(),dto.getGtrAssetClass(),dto.getGtrTradeParty1ReferenceNumber(),dto.getGtrUsi(), dto.getGtrSubmissionTime().longValue()+"", dto.getGtrRespRecv(), dto.getGtrRespAcceptance(),dto.getGtrMessageType(),dto.getGtrTransType(), dto.getGtrExecTime().longValue()+"" ,dto.getIrsTradeId(), dto.getIrsTradeVersion(),dto.getIrsSendId());
		} catch (Exception e) {
			throw new TimelinessDomainException("Query failed", e);
		}
	}
}
