package com.wf.df.sdr.exception.dao;

public class TimelinessDomainException extends DaoException
{
	/**
	 * Method 'DomainValuesDaoException'
	 * 
	 * @param message
	 */
	public TimelinessDomainException(String message)
	{
		super(message);
	}

	/**
	 * Method 'DomainValuesDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public TimelinessDomainException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
