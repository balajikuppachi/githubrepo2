package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.ReconTimelinessDomain;
import com.wf.df.sdr.service.csvloader.beans.ReconTimelinessIrsResultBean;

@Repository
public class ReconTimelinessIrsGtrExtnDao{

Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private ParameterizedRowMapper<ReconTimelinessDomain> reconTimelinessIrsGtrRowMapper = new ReconTimelinessDaoImpl();
	
	/*private static String irsRtPetSentDetails="select i.src_asset_class, i.src_prod_type, i.src_sub_prod_type, i.create_datetime, i.send_id, i.src_trade_id, i.src_trade_version, i.usi, mud.dtccusi, i.src_tlc_event, i.src_exec_datetime, i.src_trade_status, b.create_datetime, b.msg_type from  input_msg_store i join batch_details b on i.send_id=b.send_id  left join mapping_usi_dtccusi mud on i.send_id=mud.send_id " +
   												"where b.msg_type in ('RT','PET') and i.src_prod_type not like 'FX%' and convert(DATE, b.create_datetime, 101)=? and i.src_asset_class=? and i.sdr_repository='DTCC' order by b.send_id";
	 */
	
	private static String irsRtPetSentDetails="select i.src_asset_class, i.src_prod_type, i.src_sub_prod_type, i.create_datetime, i.send_id, i.src_trade_id, i.src_trade_version, i.usi, mud.dtccusi, i.src_tlc_event, " +
											 "i.src_exec_datetime, i.src_trade_status, srms.create_datetime, srms.report_type from  input_msg_store i join  sts_response_msg_store srms on i.send_id = srms.send_id " +
											 "left join mapping_usi_dtccusi mud on i.send_id=mud.send_id where srms.report_type in ('RT','PET') and i.src_prod_type not like 'FX%' and " +
											 "convert(DATE, srms.create_datetime, 101)=? and i.src_asset_class=? and i.sdr_repository='DTCC' order by i.send_id";
	
	/*private static String irsRtPetNtsDupDetails="SELECT DISTINCT i.src_asset_class, i.src_prod_type, i.src_sub_prod_type, i.create_datetime, i.send_id, i.src_trade_id, i.src_trade_version, i.usi, i.src_tlc_event, i.src_exec_datetime, i.src_trade_status, m.create_datetime, m.msg_type, m.status FROM input_msg_store i, msg_status m " +
												"WHERE  convert(DATE, m.create_datetime, 101)=? AND m.asset_class=? AND i.send_id = m.send_id AND m.status IN ('NOT_TO_SEND' ,'DUPLICATE') AND m.msg_type IN ( 'PET', 'RT')  and m.sdr_repository='DTCC' order by i.send_id";*/

	
	private static String irsRtPetNtsDupDetails="SELECT DISTINCT i.src_asset_class, i.src_prod_type, i.src_sub_prod_type, i.create_datetime, i.send_id, i.src_trade_id, i.src_trade_version, i.usi, i.src_tlc_event, " +
			"i.src_exec_datetime, i.src_trade_status, m.create_datetime, m.msg_type, m.status FROM input_msg_store i, msg_status m where convert(DATE, m.create_datetime, 101)=? AND m.asset_class=? " +
			"AND i.send_id = m.send_id AND m.status IN ('NOT_TO_SEND', 'DUPLICATE') and i.send_id not in (Select sms.send_id from sts_response_msg_store sms where convert(DATE, sms.create_datetime, 101)=? " +
			"AND sms.report_type IN ( 'PET', 'RT')) AND m.msg_type IN ( 'PET', 'RT') AND m.sdr_repository='DTCC' order by i.send_id";

	
	private static String irsLeftOverFoTradeDetails="select DISTINCT ims.src_asset_class, ims.src_prod_type, ims.src_sub_prod_type, ims.create_datetime, ims.send_id, ims.src_trade_id, ims.src_trade_version, ims.usi, ims.src_tlc_event, ims.src_exec_datetime, ims.src_trade_status from recon_timeliness_view rtv, input_msg_store ims where rtv.fo_rep_flag='Y' and " +
														"rtv.fo_trade_id is not null and rtv.irs_trade_id is null and rtv.fo_trade_id = ims.src_trade_id and rtv.fo_trade_version = ims.src_trade_version and convert(date,ims.create_datetime,101)=? and ims.src_asset_class=?  and ims.sdr_repository='DTCC'";

	private static String imsDataComm=" select i.src_asset_class, i.src_prod_type, i.src_sub_prod_type, i.create_datetime, i.send_id,i.src_trade_id, i.src_trade_version, i.usi, i.src_tlc_event, i.src_exec_datetime, i.src_trade_status, m.create_datetime from msg_to_report m , input_msg_store i where "+ 
									  "	i.send_id=m.send_id and m.create_datetime=convert(date,?,101) and i.create_datetime=convert(date,?,101) and m.msg_type in('2','5','37') and  i.rep_party=i.party1_lei "+
									  "	and m.asset_class='Commodity' and m.asset_class=i.src_asset_class and m.send_id not IN (select distinct send_id from msg_not_eligible where create_datetime = convert(date,?,101) )order by i.send_id desc";
	
	private static String reconDetails="select isnull(fo_system,irs_system) as system,isnull(fo_asset_class,irs_asset_class) as asset_class,isnull(fo_product,irs_product) as product,isnull(fo_sub_product,irs_sub_product) as sub_product,fo_exec_date, Case WHEN fo_system is null THEN irs_exec_time ELSE execution_date End as execution_date, fo_tlc_exec_date, fo_market_type, fo_trade_status, fo_trade_id, fo_trade_version, fo_usi, fo_sdr_eligible_trade, reporting_party, sdr_eligibility, fo_rep_flag, fo_sdr_reportable, fo_jurisdiction, irs_recv_timestamp, irs_send_id, irs_trade_id, irs_trade_version, irs_usi, irs_dtcc_usi, irs_trade_status, irs_trans_type, irs_rep_flag, irs_report_upload_time, irs_message_type, irs_msg_status, irs_description, gtr_action, gtr_usi, gtr_resp_recv, gtr_resp_acceptance, gtr_submission_time, gtr_trans_type, gtr_rep_flag,gtr_asset_class,gtr_trade_party_1_reference_number,gtr_message_type, f_recon_id from "+
										"(select f.fo_system,i.irs_system,f.fo_asset_class,i.irs_asset_class,f.fo_trade_id,f.execution_date, f.fo_trade_version, i.irs_trade_id, i.irs_trade_version, f.fo_market_type, i.irs_msg_status, i.irs_message_type,f.fo_product,i.irs_product,f.fo_sub_product,irs_sub_product,f.fo_exec_date,f.fo_tlc_exec_date,f.fo_trade_status,f.fo_usi,f.fo_sdr_eligible_trade,f.reporting_party,f.sdr_eligibility,f.fo_rep_flag,f.fo_sdr_reportable,f.fo_jurisdiction,i.irs_recv_timestamp,i.irs_send_id,i.irs_usi,i.irs_dtcc_usi,i.irs_trade_status,i.irs_trans_type,i.irs_exec_time,i.irs_rep_flag,i.irs_report_upload_time,i.irs_description,i.gtr_action,i.gtr_usi,i.gtr_resp_recv,i.gtr_resp_acceptance,i.gtr_submission_time,i.gtr_trans_type,i.gtr_rep_flag,i.gtr_asset_class,i.gtr_trade_party_1_reference_number,i.gtr_message_type,f.recon_id as f_recon_id from recon_timeliness_fo f LEFT OUTER JOIN recon_timeliness_irs_gtr i on f.recon_id = i.recon_id and f.fo_trade_id=i.irs_trade_id and f.fo_trade_version=i.irs_trade_version "+
										"and f.fo_trade_status=i.irs_trade_status "+
										"where f.recon_id = ? "+ 
										"UNION "+
										"select f.fo_system,i.irs_system,f.fo_asset_class,i.irs_asset_class,f.fo_trade_id,f.execution_date, f.fo_trade_version, i.irs_trade_id, i.irs_trade_version, f.fo_market_type, i.irs_msg_status, i.irs_message_type,f.fo_product,i.irs_product,f.fo_sub_product,irs_sub_product,f.fo_exec_date,f.fo_tlc_exec_date,f.fo_trade_status,f.fo_usi,f.fo_sdr_eligible_trade,f.reporting_party,f.sdr_eligibility,f.fo_rep_flag,f.fo_sdr_reportable,f.fo_jurisdiction,i.irs_recv_timestamp,i.irs_send_id,i.irs_usi,i.irs_dtcc_usi,i.irs_trade_status,i.irs_trans_type,i.irs_exec_time,i.irs_rep_flag,i.irs_report_upload_time,i.irs_description,i.gtr_action,i.gtr_usi,i.gtr_resp_recv,i.gtr_resp_acceptance,i.gtr_submission_time,i.gtr_trans_type,i.gtr_rep_flag,i.gtr_asset_class,i.gtr_trade_party_1_reference_number,i.gtr_message_type,i.recon_id as i_recon_id from recon_timeliness_fo f RIGHT OUTER JOIN recon_timeliness_irs_gtr i on f.recon_id = i.recon_id and f.fo_trade_id=i.irs_trade_id and f.fo_trade_version=i.irs_trade_version "+ 
										"and f.fo_trade_status=i.irs_trade_status "+
										"where i.recon_id = ? ) recon_timeliness ";
	
	private static String fetchResponseForComm=" select TOP 1 trace_id,status,create_datetime from mapping_sdr_enconnect where msg_type is null and create_datetime=convert(date,?,101) and send_id=? "+
											   " order by create_datetime asc ";
	
	private static String fetchEndurResult=" select TOP 1 confirm_status, usi from endur_msg_store where trace_id=? and create_datetime =convert(date,?,101) order by create_datetime asc";
	
	private static String irsLeftOverFoTradeDetailsForComm="select DISTINCT ims.src_asset_class, ims.src_prod_type, ims.src_sub_prod_type, ims.create_datetime, ims.send_id, ims.src_trade_id, ims.src_trade_version, ims.usi, ims.src_tlc_event, ims.src_exec_datetime, ims.src_trade_status from recon_timeliness_view rtv, input_msg_store ims where rtv.fo_rep_flag='Y' and " +
	"rtv.fo_trade_id is not null and rtv.irs_trade_id is null and rtv.fo_trade_id = ims.src_trade_id and rtv.fo_trade_version = ims.src_trade_version and rtv.fo_trade_status= ims.src_trade_status and convert(date,ims.create_datetime,101)=? and ims.src_asset_class=?";

	
	@Transactional
	public List<ReconTimelinessIrsResultBean> getIrsSentRtPetDetails(String executionDate, String assetClass) {

		return jdbcTemplate.query(irsRtPetSentDetails,new Object[]{executionDate,assetClass},new RowMapper() {
			@Override
			public ReconTimelinessIrsResultBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReconTimelinessIrsResultBean rb=new ReconTimelinessIrsResultBean();
				rb.setIrsAssetClass(rs.getString(1));
				rb.setIrsProductType(rs.getString(2));
				rb.setIrsSubProductType(rs.getString(3));
				rb.setIrsReceiveTime(rs.getString(4));
				rb.setIrsSendId(rs.getString(5));
				rb.setIrsSrcTradeId(rs.getString(6));
				rb.setIrsSrcTradeVersion(rs.getString(7));
				rb.setIrsUsi(rs.getString(8));
				rb.setMapIrsDtccUsi(rs.getString(9));
				rb.setIrsSrcTlcEvent(rs.getString(10));
				rb.setIrsExecDatetime(rs.getString(11));
				rb.setIrsTradeStatus(rs.getString(12));
				rb.setIrsReportUploadTime(rs.getString(13));
				rb.setIrsMsgType(rs.getString(14));
				return rb;
			}
			});
	}

	public List<ReconTimelinessIrsResultBean> getIrsRtPetNtsAndDupDetails(String executionDate, String assetClass) {
		return jdbcTemplate.query(irsRtPetNtsDupDetails,new Object[]{executionDate,assetClass, executionDate},new RowMapper() {
			@Override
			public ReconTimelinessIrsResultBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReconTimelinessIrsResultBean rb=new ReconTimelinessIrsResultBean();
				rb.setIrsAssetClass(rs.getString(1));
				rb.setIrsProductType(rs.getString(2));
				rb.setIrsSubProductType(rs.getString(3));
				rb.setIrsReceiveTime(rs.getString(4));
				rb.setIrsSendId(rs.getString(5));
				rb.setIrsSrcTradeId(rs.getString(6));
				rb.setIrsSrcTradeVersion(rs.getString(7));
				rb.setIrsUsi(rs.getString(8));
				rb.setIrsSrcTlcEvent(rs.getString(9));
				rb.setIrsExecDatetime(rs.getString(10));
				rb.setIrsTradeStatus(rs.getString(11));
				rb.setIrsReportUploadTime(rs.getString(12));
				rb.setIrsMsgType(rs.getString(13));
				rb.setIrsMsgStatus(rs.getString(14));
				return rb;
			}
			});
	}
	
	
	public List<ReconTimelinessIrsResultBean> getIrsLeftOverFoTradeDetails(String executionDate, String assetClass) {
		return jdbcTemplate.query(irsLeftOverFoTradeDetails,new Object[]{executionDate,assetClass},new RowMapper() {
			@Override
			public ReconTimelinessIrsResultBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReconTimelinessIrsResultBean rb=new ReconTimelinessIrsResultBean();
				rb.setIrsAssetClass(rs.getString(1));
				rb.setIrsProductType(rs.getString(2));
				rb.setIrsSubProductType(rs.getString(3));
				rb.setIrsReceiveTime(rs.getString(4));
				rb.setIrsSendId(rs.getString(5));
				rb.setIrsSrcTradeId(rs.getString(6));
				rb.setIrsSrcTradeVersion(rs.getString(7));
				rb.setIrsUsi(rs.getString(8));
				rb.setIrsSrcTlcEvent(rs.getString(9));
				rb.setIrsExecDatetime(rs.getString(10));
				rb.setIrsTradeStatus(rs.getString(11));
				return rb;
			}
			});
	}
	@Transactional
	public  List<ReconTimelinessIrsResultBean> fetchImsDataForComm(String executionDate) {
		return jdbcTemplate.query(imsDataComm,new Object[]{executionDate,executionDate,executionDate},new RowMapper() {
			@Override
			public ReconTimelinessIrsResultBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReconTimelinessIrsResultBean rb=new ReconTimelinessIrsResultBean();
				rb.setIrsAssetClass(rs.getString(1));
				rb.setIrsProductType(rs.getString(2));
				rb.setIrsSubProductType(rs.getString(3));
				rb.setIrsReceiveTime(rs.getString(4));
				rb.setIrsSendId(rs.getString(5));
				rb.setIrsSrcTradeId(rs.getString(6));
				rb.setIrsSrcTradeVersion(rs.getString(7));
				rb.setIrsUsi(rs.getString(8));
				rb.setIrsSrcTlcEvent(rs.getString(9));
				rb.setIrsExecDatetime(rs.getString(10));
				rb.setIrsTradeStatus(rs.getString(11).toUpperCase());
				rb.setIrsReportUploadTime(rs.getString(12));
				return rb;
			}
		});
	}
	
	
	@Transactional
	public List<ReconTimelinessIrsResultBean> getIrsLeftOverFoTradeDetailsForComm(String executionDate, String assetClass) {
		return jdbcTemplate.query(irsLeftOverFoTradeDetailsForComm,new Object[]{executionDate,assetClass},new RowMapper() {
			@Override
			public ReconTimelinessIrsResultBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReconTimelinessIrsResultBean rb=new ReconTimelinessIrsResultBean();
				rb.setIrsAssetClass(rs.getString(1));
				rb.setIrsProductType(rs.getString(2));
				rb.setIrsSubProductType(rs.getString(3));
				rb.setIrsReceiveTime(rs.getString(4));
				rb.setIrsSendId(rs.getString(5));
				rb.setIrsSrcTradeId(rs.getString(6));
				rb.setIrsSrcTradeVersion(rs.getString(7));
				rb.setIrsUsi(rs.getString(8));
				rb.setIrsSrcTlcEvent(rs.getString(9));
				rb.setIrsExecDatetime(rs.getString(10));
				rb.setIrsTradeStatus(rs.getString(11));
				return rb;
			}
			});
	}
	@Transactional
	public List<String> fetchResponseFromComm(BigDecimal sendId,String executionDate) {
		
	final List<String> resultList =new ArrayList<String>();
		jdbcTemplate.query(fetchResponseForComm,new Object[] { executionDate,sendId },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
				
				resultList.add(rs.getString(1));
				resultList.add(rs.getString(2));
				resultList.add(rs.getString(3));
				return null;
			}			
		});		
		return resultList;
	}

	@Transactional
	public List<String> fetchEndurResult(String traceId,String executionDate ) {
	final List<String> resultList =new ArrayList<String>();
		jdbcTemplate.query(fetchEndurResult,new Object[] { traceId,executionDate },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
	
				resultList.add(rs.getString(1));
				resultList.add(rs.getString(2));
				return null;
			}			
		});		
		return resultList;
	}
	
	public List<ReconTimelinessDomain> findForReconId(String reconId){
			return  jdbcTemplate.query(reconDetails, new Object[]{reconId,reconId}, reconTimelinessIrsGtrRowMapper);
		
	}
}
