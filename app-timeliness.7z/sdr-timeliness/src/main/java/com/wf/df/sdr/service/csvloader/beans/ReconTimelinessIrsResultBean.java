package com.wf.df.sdr.service.csvloader.beans;

public class ReconTimelinessIrsResultBean {
	
	private String irsAssetClass;
	private String irsProductType;
	private String irsSubProductType;
	private String irsReceiveTime;
	private String irsExecDatetime;
	private String irsSendId;
	private String irsSrcTradeId;
	private String irsSrcTradeVersion;
	private String irsUsi;
	private String mapIrsDtccUsi;
	private String irsSrcTlcEvent;
	private String irsTradeStatus;
	private String irsReportUploadTime;
	private String irsMsgType;
	private String irsMsgStatus;
	private String irsMsgDescription;
	
	public String getIrsAssetClass() {
		return irsAssetClass;
	}
	public void setIrsAssetClass(String irsAssetClass) {
		this.irsAssetClass = irsAssetClass;
	}
	public String getIrsProductType() {
		return irsProductType;
	}
	public void setIrsProductType(String irsProductType) {
		this.irsProductType = irsProductType;
	}
	public String getIrsSubProductType() {
		return irsSubProductType;
	}
	public void setIrsSubProductType(String irsSubProductType) {
		this.irsSubProductType = irsSubProductType;
	}
	public String getIrsReceiveTime() {
		return irsReceiveTime;
	}
	public void setIrsReceiveTime(String irsReceiveTime) {
		this.irsReceiveTime = irsReceiveTime;
	}
	public String getIrsExecDatetime() {
		return irsExecDatetime;
	}
	public void setIrsExecDatetime(String irsExecDatetime) {
		this.irsExecDatetime = irsExecDatetime;
	}
	public String getIrsSendId() {
		return irsSendId;
	}
	public void setIrsSendId(String irsSendId) {
		this.irsSendId = irsSendId;
	}
	public String getIrsSrcTradeId() {
		return irsSrcTradeId;
	}
	public void setIrsSrcTradeId(String irsSrcTradeId) {
		this.irsSrcTradeId = irsSrcTradeId;
	}
	public String getIrsSrcTradeVersion() {
		return irsSrcTradeVersion;
	}
	public void setIrsSrcTradeVersion(String irsSrcTradeVersion) {
		this.irsSrcTradeVersion = irsSrcTradeVersion;
	}
	public String getIrsUsi() {
		return irsUsi;
	}
	public void setIrsUsi(String irsUsi) {
		this.irsUsi = irsUsi;
	}
	public String getMapIrsDtccUsi() {
		return mapIrsDtccUsi;
	}
	public void setMapIrsDtccUsi(String mapIrsDtccUsi) {
		this.mapIrsDtccUsi = mapIrsDtccUsi;
	}
	public String getIrsSrcTlcEvent() {
		return irsSrcTlcEvent;
	}
	public void setIrsSrcTlcEvent(String irsSrcTlcEvent) {
		this.irsSrcTlcEvent = irsSrcTlcEvent;
	}
	public String getIrsTradeStatus() {
		return irsTradeStatus;
	}
	public void setIrsTradeStatus(String irsTradeStatus) {
		this.irsTradeStatus = irsTradeStatus;
	}
	public String getIrsReportUploadTime() {
		return irsReportUploadTime;
	}
	public void setIrsReportUploadTime(String irsReportUploadTime) {
		this.irsReportUploadTime = irsReportUploadTime;
	}
	public String getIrsMsgType() {
		return irsMsgType;
	}
	public void setIrsMsgType(String irsMsgType) {
		this.irsMsgType = irsMsgType;
	}
	public String getIrsMsgStatus() {
		return irsMsgStatus;
	}
	public void setIrsMsgStatus(String irsMsgStatus) {
		this.irsMsgStatus = irsMsgStatus;
	}
	public String getIrsMsgDescription() {
		return irsMsgDescription;
	}
	public void setIrsMsgDescription(String irsMsgDescription) {
		this.irsMsgDescription = irsMsgDescription;
	}
	
	@Override
	public String toString() {
		return "ReconTimelinessIrsBean [irsAssetClass=" + irsAssetClass
				+ ", irsProductType=" + irsProductType + ", irsSubProductType="
				+ irsSubProductType + ", irsReceiveTime=" + irsReceiveTime
				+ ", irsExecDatetime=" + irsExecDatetime + ", irsSendId="
				+ irsSendId + ", irsSrcTradeId=" + irsSrcTradeId
				+ ", irsSrcTradeVersion=" + irsSrcTradeVersion + ", irsUsi="
				+ irsUsi + ", mapIrsDtccUsi=" + mapIrsDtccUsi
				+ ", irsSrcTlcEvent=" + irsSrcTlcEvent + ", irsTradeStatus="
				+ irsTradeStatus + ", irsReportUploadTime="
				+ irsReportUploadTime + ", irsMsgType=" + irsMsgType
				+ ", irsMsgStatus=" + irsMsgStatus + ", irsMsgDescription="
				+ irsMsgDescription + "]";
	}
}
