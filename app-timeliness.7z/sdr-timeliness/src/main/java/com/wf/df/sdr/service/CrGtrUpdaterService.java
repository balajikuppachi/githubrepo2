package com.wf.df.sdr.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.beans.DtccCrBean;
import com.wf.df.sdr.service.csvloader.beans.ReconGtrBaseBean;
import com.wf.df.sdr.service.csvloader.common.Constants;

@Component
public class CrGtrUpdaterService extends BaseGtrUpdaterService{

	public void updateGtrCalypsoCrDetails(List<DtccCrBean> beanList){
		List<ReconGtrBaseBean> reconGtrbean=new ArrayList<ReconGtrBaseBean>();
		for(int i=0;i<beanList.size();i++){
			ReconGtrBaseBean bean=new ReconGtrBaseBean();
			BeanUtils.copyProperties(beanList.get(i), bean);
			reconGtrbean.add(bean);
		}
		
		updateForGtrInfo(reconGtrbean,Constants.ASSET_CLASS_CREDIT);
	}
}
