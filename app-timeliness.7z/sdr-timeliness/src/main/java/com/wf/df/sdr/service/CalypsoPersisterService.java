package com.wf.df.sdr.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessFODao;
import com.wf.df.sdr.dao.TimelinessDao;
import com.wf.df.sdr.dto.ReconTimelinessFO;
import com.wf.df.sdr.service.csvloader.beans.CalypsoBean;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

@Component
public class CalypsoPersisterService extends BasePersisterService  {

	@Autowired
	TimelinessDao timelinessDao;
	@Autowired
	ReconTimelinessFODao reconTimelinessFODao;
	
	/*@Value("${timeliness.date.flag}")
	boolean isDateProvided;
	
	@Value("${timeliness.date.value}")
	String dateProvided;
	*/
	/*public void persist(List<CalypsoBean> list){
		for(CalypsoBean bean : list){
			
			Check life cycle event and populate required time
			long execTime = 0L;
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrMarketType()))
			{
				if(StringUtils.equals(bean.getSdrMarketType().trim(),Constants.NEW_DEAL) && !TimelinessUtils.IsNullOrBlank(bean.getExecutionDatetime()))
				{	
					execTime=DateUtil.convertCalypsoUTCtoLocalTime(bean.getExecutionDatetime()).getTime();
				}	
				if(!StringUtils.equals(bean.getSdrMarketType().trim(),Constants.NEW_DEAL) && !TimelinessUtils.IsNullOrBlank(bean.getTlcExecutionDatetime()))
				{
					execTime=DateUtil.convertCalypsoUTCtoLocalTime(bean.getTlcExecutionDatetime()).getTime();
				}
			}


			
			TimelinessDomain dto = new TimelinessDomain();
			dto.setSystem(Constants.CALYPSO);
			if(bean.getAssetClass().toLowerCase().contains(Constants.RATES))
			{
				dto.setAssetClass(Constants.ASSET_CLASS_INTEREST_RATE);
			}else if (bean.getAssetClass().toLowerCase().contains(Constants.ASSET_CLASS_CREDIT.toLowerCase())) {
				dto.setAssetClass(Constants.ASSET_CLASS_CREDIT);
			}else if (bean.getAssetClass().toLowerCase().contains(Constants.FX.toLowerCase())) {
				dto.setAssetClass(Constants.ASSET_CLASS_FOREX);
			}
			dto.setProduct(bean.getProductType());
			if(!TimelinessUtils.IsNullOrBlank(bean.getExecutionDatetime())){
				Date execDate=DateUtil.convertCalypsoUTCtoLocalTime(bean.getExecutionDatetime());
				dto.setFoExecDate(!TimelinessUtils.IsNullOrBlank(execDate)?execDate.getTime():0L);
			} else {
				dto.setFoExecDate(0L);
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getTlcExecutionDatetime())){
				dto.setFoTlcExecDate(DateUtil.convertCalypsoUTCtoLocalTime(bean.getTlcExecutionDatetime()).getTime());
			} else {
				dto.setFoTlcExecDate(0L);
			}
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrMarketType()))
			{
				dto.setFoMarketType(bean.getSdrMarketType());
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getTradeStatus()))
			{
				dto.setFoTradeStatus(bean.getTradeStatus());
			}
			dto.setExecutionDate(execTime);
			dto.setIrsRecvTimestamp(Constants.EMPTY_STRING);
			dto.setFoTradeId(bean.getTradeId());
			dto.setFoTradeVersion(bean.getTradeVersion());
			dto.setFoUsi(bean.getUsiCurrent());
			dto.setFoSdrEligibleTrade(bean.getSdrReportable());
			dto.setFoRepFlag(Constants.N);
			dto.setIrsRepFlag(Constants.N);
			dto.setGtrRepFlag(Constants.N);
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrReportable()) && !TimelinessUtils.IsNullOrBlank(bean.getReportingParty()) && !TimelinessUtils.IsNullOrBlank(bean.getSdrEligible())){
				if(!Constants.FALSE.equalsIgnoreCase(bean.getSdrEligible())){
					if(!TimelinessUtils.IsNullOrBlank(bean.getSdrMarketType())){
						if(!Constants.Compressed_Term.equalsIgnoreCase(bean.getSdrMarketType()) || !Constants.Compressed_PartialTerm.equalsIgnoreCase(bean.getSdrMarketType())){
							if(!Constants.FALSE.equalsIgnoreCase(bean.getSdrReportable())){
								if(!TimelinessUtils.IsNullOrBlank(bean.getUsiCurrent())){
									dto.setFoRepFlag(Constants.Y);
								}
							}
						}
					}
				}
			}
			dto.setIrsUsi(Constants.EMPTY_STRING);
			//dto.setGtrUsi(null);
			dto.setIrsReportUploadTime(0L);
			dto.setDtccRespAcceptance(Constants.EMPTY_STRING);
			dto.setSdrSubmissionTime(0L);
			dto.setReportingParty(bean.getReportingParty());
			dto.setSdrEligibility(bean.getSdrEligible());

			Store in DB
			if(execTime!=0L && !TimelinessUtils.IsNullOrBlank(bean.getTradeId())&&!TimelinessUtils.IsNullOrBlank(bean.getTradeVersion()) && DateUtil.dateComparision(DateUtil.formatTimeStampForReport(dto.getExecutionDate())))
				timelinessDao.insert(dto);
		}
		
	}*/
	public String persist(List<CalypsoBean> list){
		String reconId=getCurrentReconId(Constants.ASSET_CLASS_INTEREST_RATE);
		String dateProvided = alterReconID(reconId);
		for(CalypsoBean bean : list){
			
			/*Check life cycle event and populate required time*/
			long execTime = 0L;
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrMarketType()))
			{
				if(StringUtils.equals(bean.getSdrMarketType().trim(),Constants.NEW_DEAL) && !TimelinessUtils.IsNullOrBlank(bean.getExecutionDatetime()))
				{	
					execTime=DateUtil.convertCalypsoUTCtoLocalTime(bean.getExecutionDatetime()).getTime();
				}	
				if(!StringUtils.equals(bean.getSdrMarketType().trim(),Constants.NEW_DEAL) && !TimelinessUtils.IsNullOrBlank(bean.getTlcExecutionDatetime()))
				{
					execTime=DateUtil.convertCalypsoUTCtoLocalTime(bean.getTlcExecutionDatetime()).getTime();
				}
			}
			
			ReconTimelinessFO dto = new ReconTimelinessFO();
			dto.setFoSystem(Constants.CALYPSO);
			if(bean.getAssetClass().toLowerCase().contains(Constants.RATES))
			{
				dto.setFoAssetClass(Constants.ASSET_CLASS_INTEREST_RATE);
			}else if (bean.getAssetClass().toLowerCase().contains(Constants.ASSET_CLASS_CREDIT.toLowerCase())) {
				dto.setFoAssetClass(Constants.ASSET_CLASS_CREDIT);
			}else if (bean.getAssetClass().toLowerCase().contains(Constants.FX.toLowerCase())) {
				dto.setFoAssetClass(Constants.ASSET_CLASS_FOREX);
			}
			dto.setFoProduct(bean.getProductType());
			dto.setFoSubProduct(bean.getSubProductType());
			if(!TimelinessUtils.IsNullOrBlank(bean.getExecutionDatetime())){
				Date execDate=DateUtil.convertCalypsoUTCtoLocalTime(bean.getExecutionDatetime());
				dto.setFoExecDate(!TimelinessUtils.IsNullOrBlank(execDate)?execDate.getTime():0L);
			} else {
				dto.setFoExecDate(0L);
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getTlcExecutionDatetime())){
				dto.setFoTlcExecDate(DateUtil.convertCalypsoUTCtoLocalTime(bean.getTlcExecutionDatetime()).getTime());
			} else {
				dto.setFoTlcExecDate(0L);
			}
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrMarketType()))
			{
				dto.setFoMarketType(bean.getSdrMarketType());
			}
			if(!TimelinessUtils.IsNullOrBlank(bean.getTradeStatus()))
			{
				dto.setFoTradeStatus(bean.getTradeStatus());
			}
			dto.setExecutionDate(execTime);
			dto.setFoTradeId(bean.getTradeId());
			dto.setFoTradeVersion(bean.getTradeVersion());
			dto.setFoUsi(bean.getUsiCurrent());
			dto.setFoSdrEligibleTrade(bean.getSdrEligible());
			dto.setFoSdrReportable(bean.getSdrReportable());
			if(Constants.TRUE.equalsIgnoreCase(bean.getSdrReportable().trim()))
				dto.setFoJurisdiction(Constants.CFTC);
			else 
				dto.setFoJurisdiction(Constants.EMPTY_STRING);
			dto.setFoRepFlag(Constants.N);
			
			if(!TimelinessUtils.IsNullOrBlank(bean.getReportingParty())  && Constants.US.equalsIgnoreCase(bean.getReportingParty()))
			{
			if(!TimelinessUtils.IsNullOrBlank(bean.getSdrReportable()) && !TimelinessUtils.IsNullOrBlank(bean.getSdrEligible())){
				if(!Constants.FALSE.equalsIgnoreCase(bean.getSdrEligible())){
					if(!TimelinessUtils.IsNullOrBlank(bean.getSdrMarketType())){
						if(!Constants.Compressed_Term.equalsIgnoreCase(bean.getSdrMarketType()) || !Constants.Compressed_PartialTerm.equalsIgnoreCase(bean.getSdrMarketType())){
							if(!Constants.FALSE.equalsIgnoreCase(bean.getSdrReportable())){
								if(!TimelinessUtils.IsNullOrBlank(bean.getUsiCurrent())){
									dto.setFoRepFlag(Constants.Y);
								}
							}
						}
					}
				}
			}
			}else if (!TimelinessUtils.IsNullOrBlank(bean.getReportingParty())  && StringUtils.containsIgnoreCase(bean.getReportingParty(), Constants.CFTCUS))
			{
				if(!TimelinessUtils.IsNullOrBlank(bean.getCptyClassification()) && !TimelinessUtils.IsNullOrBlank(bean.getReportingJurisdiction())){
					if(!Constants.INTERNAL.equals(bean.getCptyClassification()) && StringUtils.containsIgnoreCase(bean.getReportingJurisdiction(), Constants.CFTC)){
						if(!TimelinessUtils.IsNullOrBlank(bean.getSdrMarketType())){
							if(!Constants.Compressed_Term.equalsIgnoreCase(bean.getSdrMarketType()) || !Constants.Compressed_PartialTerm.equalsIgnoreCase(bean.getSdrMarketType())){
									if(!TimelinessUtils.IsNullOrBlank(bean.getUsiCurrent())){
										dto.setFoRepFlag(Constants.Y);
								}
							}
						}
					}
				}
			}
			dto.setReportingParty(bean.getReportingParty());
			dto.setSdrEligibility(bean.getSdrEligible());
			dto.setReconId(reconId);
			dto.setCptyClassification(bean.getCptyClassification());
			dto.setReportingJurisdiction(bean.getReportingJurisdiction());
			
			/*Store in DB*/
			if(execTime!=0L && (DateUtil.compareDate(dateProvided,DateUtil.formatTimeStampForReport(dto.getExecutionDate())) || DateUtil.dateComparision(DateUtil.formatTimeStampForReport(dto.getExecutionDate())))
					&& !TimelinessUtils.IsNullOrBlank(bean.getTradeId())&&!TimelinessUtils.IsNullOrBlank(bean.getTradeVersion()) && !Constants.ASSET_CLASS_FOREX.equals(dto.getFoAssetClass()))
					{
						reconTimelinessFODao.insert(dto);
					}
			}
			
		return reconId;
	}

	private String alterReconID(String reconID) {
		
		StringBuffer sb = new StringBuffer(reconID);
		if(reconID.length()==8){
			sb.insert(4, '-');
			sb.insert(7, '-');
		}
		return 	sb.toString();		
	}
	
	
}
