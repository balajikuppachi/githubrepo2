package com.wf.df.sdr.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconTimelinessIrsGtrDao;
import com.wf.df.sdr.dao.spring.ReconTimelinessIrsGtrExtnDao;
import com.wf.df.sdr.dao.spring.TimelinessExtnDao;
import com.wf.df.sdr.dto.ReconTimelinessIrsGtrDomain;
import com.wf.df.sdr.service.csvloader.beans.ReconTimelinessIrsResultBean;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DateUtil;

/**
 * Class to update IRS details for all FO trades based on presence of 
 * 	1> SENT - RT and PET  
 *	2> NOT_TO_SEND and DUPLICATE
 *	3> Presence in input_msg_store table
 */
@Component
public class BaseIrsUpdaterService {
	
	@Autowired
	ReconTimelinessIrsGtrExtnDao reconTimelinessExtnDao;
	
	@Autowired
	ReconTimelinessIrsGtrDao irsRtPetDetails;
	
	@Autowired
	TimelinessExtnDao timelinessExtnDao;
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
/*	@Value("${timeliness.date.flag}")
	boolean isDateProvided;
	
	@Value("${timeliness.date.value}")
	String dateProvided;
	*/
	
	
	public void updateForIrsDetails(String reconId, String assetClass){
		
		//String reconDate = isDateProvided ? dateProvided : DateUtil.yesterdayDate;
		
		logger.info("Triggered IRS updater service for "+assetClass);
		logger.debug("Updating for RT PET SENT messages for all "+assetClass+" trades");
		
		/*
		 * For all RT and PET SENT records
		 * */
		
		List<ReconTimelinessIrsResultBean> irsRtPetSentTrades=reconTimelinessExtnDao.getIrsSentRtPetDetails(reconId, assetClass);
		
		if(!TimelinessUtils.IsNullOrBlank(irsRtPetSentTrades) && irsRtPetSentTrades.size()>0){
			for(ReconTimelinessIrsResultBean result : irsRtPetSentTrades){
				ReconTimelinessIrsGtrDomain domain = new ReconTimelinessIrsGtrDomain();
				if(!TimelinessUtils.IsNullOrBlank(result)){
					domain.setIrsSystem(Constants.IRS);				
					domain.setIrsAssetClass(result.getIrsAssetClass());			
					domain.setIrsProduct(result.getIrsProductType());				
					domain.setIrsSubProduct(result.getIrsSubProductType());	
					
					String irsRcvTime = result.getIrsReceiveTime();
					if(!TimelinessUtils.IsNullOrBlank(irsRcvTime)){
						domain.setIrsRecvTimestamp(DateUtil.getTimestampFromStringForDiff(irsRcvTime).getTime());		
					} else {
						domain.setIrsRecvTimestamp(0L);	
					}
					
					domain.setIrsSendId(result.getIrsSendId()); 			
					domain.setIrsTradeId(result.getIrsSrcTradeId());			
					domain.setIrsTradeVersion(result.getIrsSrcTradeVersion());		
					domain.setIrsUsi(result.getIrsUsi());					
					domain.setIrsDtccUsi(result.getMapIrsDtccUsi());			
					domain.setIrsTransType(result.getIrsSrcTlcEvent());			
					
					String irsExecTime = result.getIrsExecDatetime();
					if(!TimelinessUtils.IsNullOrBlank(irsExecTime)){
						domain.setIrsExecTime(DateUtil.getTimestampFromStringForDiff(irsExecTime).getTime());			
					} else {
						domain.setIrsExecTime(0L);	
					}
					
					domain.setIrsTradeStatus(result.getIrsTradeStatus());		

					String irsReportUploadTime = result.getIrsReportUploadTime();
					if(!TimelinessUtils.IsNullOrBlank(irsReportUploadTime)){
						domain.setIrsReportUploadTime(DateUtil.getTimestampFromStringForDiff(irsReportUploadTime).getTime());	
					} else {
						domain.setIrsReportUploadTime(0L);	
					}
					
					domain.setIrsMessageType(result.getIrsMsgType());		
					domain.setIrsMsgStatus(Constants.SENT);			
					domain.setIrsDescription(Constants.EMPTY_STRING);	
					domain.setIrsRepFlag(Constants.Y);
					domain.setGtrSubmissionTime(0L);
					domain.setGtrRespRecv(Constants.N);
					domain.setGtrRepFlag(Constants.Y);
					domain.setReconId(reconId);
					domain.setGtrExecTime(0L);
				}
				
				irsRtPetDetails.insert(domain);
			}
		}
		logger.debug("Completed IRS RT PET SENT update for "+ assetClass);
		logger.debug("Updating for RT PET NOT_TO_SEND and DUPLICATE messages for all "+assetClass+" trades");
		
		/*
		 * For all NOT_TO_SEND and DUPLICATE records
		 * */
		List<ReconTimelinessIrsResultBean> irsRtPetNtsAndDupTrades=reconTimelinessExtnDao.getIrsRtPetNtsAndDupDetails(reconId, assetClass);
		
		if(!TimelinessUtils.IsNullOrBlank(irsRtPetNtsAndDupTrades) && irsRtPetNtsAndDupTrades.size()>0){
			for(ReconTimelinessIrsResultBean result : irsRtPetNtsAndDupTrades){
				ReconTimelinessIrsGtrDomain domain = new ReconTimelinessIrsGtrDomain();
				if(!TimelinessUtils.IsNullOrBlank(result)){
					domain.setIrsSystem(Constants.IRS);				
					domain.setIrsAssetClass(result.getIrsAssetClass());			
					domain.setIrsProduct(result.getIrsProductType());				
					domain.setIrsSubProduct(result.getIrsSubProductType());	
					
					String irsRcvTime = result.getIrsReceiveTime();
					if(!TimelinessUtils.IsNullOrBlank(irsRcvTime)){
						domain.setIrsRecvTimestamp(DateUtil.getTimestampFromStringForDiff(irsRcvTime).getTime());		
					} else {
						domain.setIrsRecvTimestamp(0L);	
					}
					
					domain.setIrsSendId(result.getIrsSendId()); 			
					domain.setIrsTradeId(result.getIrsSrcTradeId());			
					domain.setIrsTradeVersion(result.getIrsSrcTradeVersion());		
					domain.setIrsUsi(result.getIrsUsi());					
					domain.setIrsDtccUsi(Constants.EMPTY_STRING);			
					domain.setIrsTransType(result.getIrsSrcTlcEvent());			
					
					String irsExecTime = result.getIrsExecDatetime();
					if(!TimelinessUtils.IsNullOrBlank(irsExecTime)){
						domain.setIrsExecTime(DateUtil.getTimestampFromStringForDiff(irsExecTime).getTime());			
					} else {
						domain.setIrsExecTime(0L);	
					}
					
					domain.setIrsTradeStatus(result.getIrsTradeStatus());		

					/*For NOT_TO_SEND and DUPLICATE we are not uploading the report*/
					domain.setIrsReportUploadTime(0L);	
					
					domain.setIrsMessageType(result.getIrsMsgType());		
					domain.setIrsMsgStatus(result.getIrsMsgStatus());			
					domain.setIrsDescription(Constants.NOT_ELIGIBLE_FOR+domain.getIrsMessageType());	
					domain.setIrsRepFlag(Constants.Y);
					domain.setGtrSubmissionTime(0L);
					domain.setGtrRespRecv(Constants.N);
					domain.setGtrRepFlag(Constants.Y);
					domain.setReconId(reconId);
					domain.setGtrExecTime(0L);
				}
				irsRtPetDetails.insert(domain);
			}
		}
		logger.debug("Completed update for RT PET NOT_TO_SEND and DUPLICATE messages for all "+assetClass+" trades");
		logger.debug("Update for left over FO trades that are present in input_msg_store for "+assetClass+" trades");
		
		/*
		 * For left over FO trades present in input_msg_store
		 * */
		List<ReconTimelinessIrsResultBean> irsLeftOverFoTrades=reconTimelinessExtnDao.getIrsLeftOverFoTradeDetails(reconId, assetClass);
		logger.debug("Matching IRS for FO leftover trades count : "+irsLeftOverFoTrades.size());
		if(!TimelinessUtils.IsNullOrBlank(irsLeftOverFoTrades) && irsLeftOverFoTrades.size()>0){
			for(ReconTimelinessIrsResultBean result : irsLeftOverFoTrades){
				ReconTimelinessIrsGtrDomain domain = new ReconTimelinessIrsGtrDomain();
				if(!TimelinessUtils.IsNullOrBlank(result)){
					domain.setIrsSystem(Constants.IRS);				
					domain.setIrsAssetClass(result.getIrsAssetClass());			
					domain.setIrsProduct(result.getIrsProductType());				
					domain.setIrsSubProduct(result.getIrsSubProductType());	
					
					String irsRcvTime = result.getIrsReceiveTime();
					if(!TimelinessUtils.IsNullOrBlank(irsRcvTime)){
						domain.setIrsRecvTimestamp(DateUtil.getTimestampFromStringForDiff(irsRcvTime).getTime());		
					} else {
						domain.setIrsRecvTimestamp(0L);	
					}
					
					domain.setIrsSendId(result.getIrsSendId()); 			
					domain.setIrsTradeId(result.getIrsSrcTradeId());			
					domain.setIrsTradeVersion(result.getIrsSrcTradeVersion());		
					domain.setIrsUsi(result.getIrsUsi());					
					domain.setIrsDtccUsi(Constants.EMPTY_STRING);			
					domain.setIrsTransType(result.getIrsSrcTlcEvent());			
					
					String irsExecTime = result.getIrsExecDatetime();
					if(!TimelinessUtils.IsNullOrBlank(irsExecTime)){
						domain.setIrsExecTime(DateUtil.getTimestampFromStringForDiff(irsExecTime).getTime());			
					} else {
						domain.setIrsExecTime(0L);	
					}
					
					domain.setIrsTradeStatus(result.getIrsTradeStatus());		

					/*For trades which are not eligible for reporting no upload hence update 0*/
					domain.setIrsReportUploadTime(0L);	
					
					domain.setIrsMessageType(Constants.EMPTY_STRING);		
					domain.setIrsMsgStatus(Constants.EMPTY_STRING);			
					domain.setIrsDescription(Constants.EMPTY_STRING);	
					domain.setIrsRepFlag(Constants.Y);
					domain.setGtrSubmissionTime(0L);
					domain.setGtrRespRecv(Constants.N);
					domain.setGtrRepFlag(Constants.Y);
					domain.setReconId(reconId);
					domain.setGtrExecTime(0L);
				}
				irsRtPetDetails.insert(domain);
			}
		}
		logger.debug("Completed update for left over FO trades for all "+assetClass+" trades");
		logger.info("Completed IRS updater service for "+assetClass);
	}
}
