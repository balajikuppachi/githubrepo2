package com.wf.df.sdr.service.csvloader.beans;

import java.util.Date;

public class ReconGtrBaseBean {

	private String gtrAction;
	private String transactionType;
	private String messageType;
	private String usiNamespace;
	private String usi;
	private String assetClass;
	private String productType;
	private String status;
	private String errorReason;
	private Date submissionDateTime;
	private String tradeParty1ReferenceNumber;
	private Date executionTimeStamp;
	/**
	 * @return the gtrAction
	 */
	public String getGtrAction() {
		return gtrAction;
	}
	/**
	 * @param gtrAction the gtrAction to set
	 */
	public void setGtrAction(String gtrAction) {
		this.gtrAction = gtrAction;
	}
	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}
	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}
	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	/**
	 * @return the usiNamespace
	 */
	public String getUsiNamespace() {
		return usiNamespace;
	}
	/**
	 * @param usiNamespace the usiNamespace to set
	 */
	public void setUsiNamespace(String usiNamespace) {
		this.usiNamespace = usiNamespace;
	}
	/**
	 * @return the usi
	 */
	public String getUsi() {
		return usi;
	}
	/**
	 * @param usi the usi to set
	 */
	public void setUsi(String usi) {
		this.usi = usi;
	}
	/**
	 * @return the assetClass
	 */
	public String getAssetClass() {
		return assetClass;
	}
	/**
	 * @param assetClass the assetClass to set
	 */
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}
	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the errorReason
	 */
	public String getErrorReason() {
		return errorReason;
	}
	/**
	 * @param errorReason the errorReason to set
	 */
	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}
	/**
	 * @return the submissionDateTime
	 */
	public Date getSubmissionDateTime() {
		return submissionDateTime;
	}
	/**
	 * @param submissionDateTime the submissionDateTime to set
	 */
	public void setSubmissionDateTime(Date submissionDateTime) {
		this.submissionDateTime = submissionDateTime;
	}
	/**
	 * @return the tradeParty1ReferenceNumber
	 */
	public String getTradeParty1ReferenceNumber() {
		return tradeParty1ReferenceNumber;
	}
	/**
	 * @param tradeParty1ReferenceNumber the tradeParty1ReferenceNumber to set
	 */
	public void setTradeParty1ReferenceNumber(String tradeParty1ReferenceNumber) {
		this.tradeParty1ReferenceNumber = tradeParty1ReferenceNumber;
	}
	public Date getExecutionTimeStamp() {
		return executionTimeStamp;
	}
	public void setExecutionTimeStamp(Date executionTimeStamp) {
		this.executionTimeStamp = executionTimeStamp;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ReconGtrBaseBean [transactionType=" + transactionType
				+ ", messageType=" + messageType + ", usiNamespace="
				+ usiNamespace + ", usi=" + usi + ", assetClass=" + assetClass
				+ ", productType=" + productType + ", status=" + status
				+ ", errorReason=" + errorReason + ", submissionDateTime="
				+ submissionDateTime + ", tradeParty1ReferenceNumber="
				+ tradeParty1ReferenceNumber + "]";
	}
	
	
}
