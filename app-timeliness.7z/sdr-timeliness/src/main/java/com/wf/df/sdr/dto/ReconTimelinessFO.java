package com.wf.df.sdr.dto;

public class ReconTimelinessFO {

	private String	foSystem;
	private String	foAssetClass;
	private String	foProduct;
	private String	foSubProduct;
	private Long	foExecDate;
	private Long	executionDate;
	private Long	foTlcExecDate;
	private String	foMarketType;
	private String	foTradeStatus;
	private String	foTradeId;
	private String	foTradeVersion;
	private String	foUsi;
	private String	foSdrEligibleTrade;
	private String	reportingParty;
	private String	sdrEligibility;
	private String	foSdrReportable;
	private String	foJurisdiction;
	private String	foRepFlag;
	private String	reconId;
	private String cptyClassification;
	private String reportingJurisdiction;

	/**
	 * @return the system
	 */
	public String getFoSystem() {
		return foSystem;
	}
	/**
	 * @param system the system to set
	 */
	public void setFoSystem(String foSystem) {
		this.foSystem = foSystem;
	}
	/**
	 * @return the assetClass
	 */
	public String getFoAssetClass() {
		return foAssetClass;
	}
	/**
	 * @param assetClass the assetClass to set
	 */
	public void setFoAssetClass(String foAssetClass) {
		this.foAssetClass = foAssetClass;
	}
	/**
	 * @return the product
	 */
	public String getFoProduct() {
		return foProduct;
	}
	/**
	 * @param product the product to set
	 */
	public void setFoProduct(String foProduct) {
		this.foProduct = foProduct;
	}
	/**
	 * @return the subProduct
	 */
	public String getFoSubProduct() {
		return foSubProduct;
	}
	/**
	 * @param subProduct the subProduct to set
	 */
	public void setFoSubProduct(String foSubProduct) {
		this.foSubProduct = foSubProduct;
	}
	/**
	 * @return the foExecDate
	 */
	public Long getFoExecDate() {
		return foExecDate;
	}
	/**
	 * @param foExecDate the foExecDate to set
	 */
	public void setFoExecDate(Long foExecDate) {
		this.foExecDate = foExecDate;
	}
	/**
	 * @return the executionDate
	 */
	public Long getExecutionDate() {
		return executionDate;
	}
	/**
	 * @param executionDate the executionDate to set
	 */
	public void setExecutionDate(Long executionDate) {
		this.executionDate = executionDate;
	}
	/**
	 * @return the foTlcExecDate
	 */
	public Long getFoTlcExecDate() {
		return foTlcExecDate;
	}
	/**
	 * @param foTlcExecDate the foTlcExecDate to set
	 */
	public void setFoTlcExecDate(Long foTlcExecDate) {
		this.foTlcExecDate = foTlcExecDate;
	}
	/**
	 * @return the foMarketType
	 */
	public String getFoMarketType() {
		return foMarketType;
	}
	/**
	 * @param foMarketType the foMarketType to set
	 */
	public void setFoMarketType(String foMarketType) {
		this.foMarketType = foMarketType;
	}
	/**
	 * @return the foTradeStatus
	 */
	public String getFoTradeStatus() {
		return foTradeStatus;
	}
	/**
	 * @param foTradeStatus the foTradeStatus to set
	 */
	public void setFoTradeStatus(String foTradeStatus) {
		this.foTradeStatus = foTradeStatus;
	}
	/**
	 * @return the foTradeId
	 */
	public String getFoTradeId() {
		return foTradeId;
	}
	/**
	 * @param foTradeId the foTradeId to set
	 */
	public void setFoTradeId(String foTradeId) {
		this.foTradeId = foTradeId;
	}
	/**
	 * @return the foTradeVersion
	 */
	public String getFoTradeVersion() {
		return foTradeVersion;
	}
	/**
	 * @param foTradeVersion the foTradeVersion to set
	 */
	public void setFoTradeVersion(String foTradeVersion) {
		this.foTradeVersion = foTradeVersion;
	}
	/**
	 * @return the foUsi
	 */
	public String getFoUsi() {
		return foUsi;
	}
	/**
	 * @param foUsi the foUsi to set
	 */
	public void setFoUsi(String foUsi) {
		this.foUsi = foUsi;
	}
	/**
	 * @return the foSdrEligibleTrade
	 */
	public String getFoSdrEligibleTrade() {
		return foSdrEligibleTrade;
	}
	/**
	 * @param foSdrEligibleTrade the foSdrEligibleTrade to set
	 */
	public void setFoSdrEligibleTrade(String foSdrEligibleTrade) {
		this.foSdrEligibleTrade = foSdrEligibleTrade;
	}
	/**
	 * @return the foSdrReportable
	 */
	public String getFoSdrReportable() {
		return foSdrReportable;
	}
	/**
	 * @param foSdrReportable the foSdrReportable to set
	 */
	public void setFoSdrReportable(String foSdrReportable) {
		this.foSdrReportable = foSdrReportable;
	}
	/**
	 * @return the foJurisdiction
	 */
	public String getFoJurisdiction() {
		return foJurisdiction;
	}
	/**
	 * @param foJurisdiction the foJurisdiction to set
	 */
	public void setFoJurisdiction(String foJurisdiction) {
		this.foJurisdiction = foJurisdiction;
	}
	/**
	 * @return the reportingParty
	 */
	public String getReportingParty() {
		return reportingParty;
	}
	/**
	 * @param reportingParty the reportingParty to set
	 */
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}
	/**
	 * @return the sdrEligibility
	 */
	public String getSdrEligibility() {
		return sdrEligibility;
	}
	/**
	 * @param sdrEligibility the sdrEligibility to set
	 */
	public void setSdrEligibility(String sdrEligibility) {
		this.sdrEligibility = sdrEligibility;
	}
	/**
	 * @return the foRepFlag
	 */
	public String getFoRepFlag() {
		return foRepFlag;
	}
	/**
	 * @param foRepFlag the foRepFlag to set
	 */
	public void setFoRepFlag(String foRepFlag) {
		this.foRepFlag = foRepFlag;
	}
	/**
	 * @return the reconId
	 */
	public String getReconId() {
		return reconId;
	}
	/**
	 * @param reconId the reconId to set
	 */
	public void setReconId(String reconId) {
		this.reconId = reconId;
	}
	public String getCptyClassification() {
		return cptyClassification;
	}
	public void setCptyClassification(String cptyClassification) {
		this.cptyClassification = cptyClassification;
	}
	public String getReportingJurisdiction() {
		return reportingJurisdiction;
	}
	public void setReportingJurisdiction(String reportingJurisdiction) {
		this.reportingJurisdiction = reportingJurisdiction;
	}
	
}
