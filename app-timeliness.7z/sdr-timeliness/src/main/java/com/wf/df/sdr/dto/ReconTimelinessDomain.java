package com.wf.df.sdr.dto;

import java.util.Date;

public class ReconTimelinessDomain {
	
	private String	system;
	private String	assetClass;
	private String	product;
	private String	subProduct;
	private Long	foExecDate;
	private Long	executionDate;
	private Long	foTlcExecDate;
	private String	foMarketType;
	private String	foTradeStatus;
	private String	foTradeId;
	private String	foTradeVersion;
	private String	foUsi;
	private String	foSdrEligibleTrade;
	private String	reportingParty;
	private String	sdrEligibility;
	private String	foRepFlag;
	private String	foSdrReportable;
	private String	foJurisdiction;
	private Long	irsRecvTimestamp;
	private String	irsSendId;
	private String	irsTradeId;
	private String	irsTradeVersion;
	private String	irsUsi;
	private String	irsDtccUsi;
	private String	irsTradeStatus;
	private String	irsTransactionType;
	private String	irsRepFlag;
	private Long	irsReportUploadTime;
	private String	irsMsgType;
	private String	irsMsgStatus;
	private String	irsDescription;
	private String	gtrAction;
	private String	gtrUsi;
	private String	dtccRespRecv;
	private String	dtccRespAcceptance;
	private Long	sdrSubmissionTime;
	private String	gtrTransType;
	private String	gtrRepFlag;
	private String	gtrAssetClass;
	private String	gtrTradeParty1ReferenceNumber;
	private String	gtrMessageType;
	private Long gtrExecutionTime;
	private String 	reconId;
	private String cptyClassification;
	private String reportingJurisdiction;

	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getSubProduct() {
		return subProduct;
	}
	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}
	public Long getFoExecDate() {
		return foExecDate;
	}
	public void setFoExecDate(Long foExecDate) {
		this.foExecDate = foExecDate;
	}
	public Long getExecutionDate() {
		return executionDate;
	}
	public void setExecutionDate(Long executionDate) {
		this.executionDate = executionDate;
	}
	public Long getFoTlcExecDate() {
		return foTlcExecDate;
	}
	public void setFoTlcExecDate(Long foTlcExecDate) {
		this.foTlcExecDate = foTlcExecDate;
	}
	public String getFoMarketType() {
		return foMarketType;
	}
	public void setFoMarketType(String foMarketType) {
		this.foMarketType = foMarketType;
	}
	public String getFoTradeStatus() {
		return foTradeStatus;
	}
	public void setFoTradeStatus(String foTradeStatus) {
		this.foTradeStatus = foTradeStatus;
	}
	public String getFoTradeId() {
		return foTradeId;
	}
	public void setFoTradeId(String foTradeId) {
		this.foTradeId = foTradeId;
	}
	public String getFoTradeVersion() {
		return foTradeVersion;
	}
	public void setFoTradeVersion(String foTradeVersion) {
		this.foTradeVersion = foTradeVersion;
	}
	public String getFoUsi() {
		return foUsi;
	}
	public void setFoUsi(String foUsi) {
		this.foUsi = foUsi;
	}
	public String getFoSdrEligibleTrade() {
		return foSdrEligibleTrade;
	}
	public void setFoSdrEligibleTrade(String foSdrEligibleTrade) {
		this.foSdrEligibleTrade = foSdrEligibleTrade;
	}
	public String getReportingParty() {
		return reportingParty;
	}
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}
	public String getSdrEligibility() {
		return sdrEligibility;
	}
	public void setSdrEligibility(String sdrEligibility) {
		this.sdrEligibility = sdrEligibility;
	}
	public String getFoRepFlag() {
		return foRepFlag;
	}
	public void setFoRepFlag(String foRepFlag) {
		this.foRepFlag = foRepFlag;
	}
	public String getFoSdrReportable() {
		return foSdrReportable;
	}
	public void setFoSdrReportable(String foSdrReportable) {
		this.foSdrReportable = foSdrReportable;
	}
	public String getFoJurisdiction() {
		return foJurisdiction;
	}
	public void setFoJurisdiction(String foJurisdiction) {
		this.foJurisdiction = foJurisdiction;
	}
	public Long getIrsRecvTimestamp() {
		return irsRecvTimestamp;
	}
	public void setIrsRecvTimestamp(Long irsRecvTimestamp) {
		this.irsRecvTimestamp = irsRecvTimestamp;
	}
	public String getIrsSendId() {
		return irsSendId;
	}
	public void setIrsSendId(String irsSendId) {
		this.irsSendId = irsSendId;
	}
	public String getIrsTradeId() {
		return irsTradeId;
	}
	public void setIrsTradeId(String irsTradeId) {
		this.irsTradeId = irsTradeId;
	}
	public String getIrsTradeVersion() {
		return irsTradeVersion;
	}
	public void setIrsTradeVersion(String irsTradeVersion) {
		this.irsTradeVersion = irsTradeVersion;
	}
	public String getIrsUsi() {
		return irsUsi;
	}
	public void setIrsUsi(String irsUsi) {
		this.irsUsi = irsUsi;
	}
	public String getIrsDtccUsi() {
		return irsDtccUsi;
	}
	public void setIrsDtccUsi(String irsDtccUsi) {
		this.irsDtccUsi = irsDtccUsi;
	}
	public String getIrsTradeStatus() {
		return irsTradeStatus;
	}
	public void setIrsTradeStatus(String irsTradeStatus) {
		this.irsTradeStatus = irsTradeStatus;
	}
	public String getIrsTransactionType() {
		return irsTransactionType;
	}
	public void setIrsTransactionType(String irsTransactionType) {
		this.irsTransactionType = irsTransactionType;
	}
	public String getIrsRepFlag() {
		return irsRepFlag;
	}
	public void setIrsRepFlag(String irsRepFlag) {
		this.irsRepFlag = irsRepFlag;
	}
	public Long getIrsReportUploadTime() {
		return irsReportUploadTime;
	}
	public void setIrsReportUploadTime(Long irsReportUploadTime) {
		this.irsReportUploadTime = irsReportUploadTime;
	}
	public String getIrsMsgType() {
		return irsMsgType;
	}
	public void setIrsMsgType(String irsMsgType) {
		this.irsMsgType = irsMsgType;
	}
	public String getIrsMsgStatus() {
		return irsMsgStatus;
	}
	public void setIrsMsgStatus(String irsMsgStatus) {
		this.irsMsgStatus = irsMsgStatus;
	}
	public String getIrsDescription() {
		return irsDescription;
	}
	public void setIrsDescription(String irsDescription) {
		this.irsDescription = irsDescription;
	}
	public String getGtrAction() {
		return gtrAction;
	}
	public void setGtrAction(String gtrAction) {
		this.gtrAction = gtrAction;
	}
	public String getGtrUsi() {
		return gtrUsi;
	}
	public void setGtrUsi(String gtrUsi) {
		this.gtrUsi = gtrUsi;
	}
	public String getDtccRespRecv() {
		return dtccRespRecv;
	}
	public void setDtccRespRecv(String dtccRespRecv) {
		this.dtccRespRecv = dtccRespRecv;
	}
	public String getDtccRespAcceptance() {
		return dtccRespAcceptance;
	}
	public void setDtccRespAcceptance(String dtccRespAcceptance) {
		this.dtccRespAcceptance = dtccRespAcceptance;
	}
	public Long getSdrSubmissionTime() {
		return sdrSubmissionTime;
	}
	public void setSdrSubmissionTime(Long sdrSubmissionTime) {
		this.sdrSubmissionTime = sdrSubmissionTime;
	}
	public String getGtrTransType() {
		return gtrTransType;
	}
	public void setGtrTransType(String gtrTransType) {
		this.gtrTransType = gtrTransType;
	}
	public String getGtrRepFlag() {
		return gtrRepFlag;
	}
	public void setGtrRepFlag(String gtrRepFlag) {
		this.gtrRepFlag = gtrRepFlag;
	}
	public String getGtrAssetClass() {
		return gtrAssetClass;
	}
	public void setGtrAssetClass(String gtrAssetClass) {
		this.gtrAssetClass = gtrAssetClass;
	}
	public String getGtrTradeParty1ReferenceNumber() {
		return gtrTradeParty1ReferenceNumber;
	}
	public void setGtrTradeParty1ReferenceNumber(
			String gtrTradeParty1ReferenceNumber) {
		this.gtrTradeParty1ReferenceNumber = gtrTradeParty1ReferenceNumber;
	}
	public String getGtrMessageType() {
		return gtrMessageType;
	}
	public void setGtrMessageType(String gtrMessageType) {
		this.gtrMessageType = gtrMessageType;
	}
	public Long getGtrExecutionTime() {
		return gtrExecutionTime;
	}
	public void setGtrExecutionTime(Long gtrExecutionTime) {
		this.gtrExecutionTime = gtrExecutionTime;
	}
	public String getReconId() {
		return reconId;
	}
	public void setReconId(String reconId) {
		this.reconId = reconId;
	}
	
	public String getCptyClassification() {
		return cptyClassification;
	}
	public void setCptyClassification(String cptyClassification) {
		this.cptyClassification = cptyClassification;
	}
	public String getReportingJurisdiction() {
		return reportingJurisdiction;
	}
	public void setReportingJurisdiction(String reportingJurisdiction) {
		this.reportingJurisdiction = reportingJurisdiction;
	}
	@Override
	public String toString() {
		return "ReconTimelinessDomain [system=" + system + ", assetClass="
				+ assetClass + ", product=" + product + ", subProduct="
				+ subProduct + ", foExecDate=" + foExecDate
				+ ", executionDate=" + executionDate + ", foTlcExecDate="
				+ foTlcExecDate + ", foMarketType=" + foMarketType
				+ ", foTradeStatus=" + foTradeStatus + ", foTradeId="
				+ foTradeId + ", foTradeVersion=" + foTradeVersion + ", foUsi="
				+ foUsi + ", foSdrEligibleTrade=" + foSdrEligibleTrade
				+ ", reportingParty=" + reportingParty + ", sdrEligibility="
				+ sdrEligibility + ", foRepFlag=" + foRepFlag
				+ ", foSdrReportable=" + foSdrReportable + ", foJurisdiction="
				+ foJurisdiction + ", irsRecvTimestamp=" + irsRecvTimestamp
				+ ", irsSendId=" + irsSendId + ", irsTradeId=" + irsTradeId
				+ ", irsTradeVersion=" + irsTradeVersion + ", irsUsi=" + irsUsi
				+ ", irsDtccUsi=" + irsDtccUsi + ", irsTradeStatus="
				+ irsTradeStatus + ", irsTransactionType=" + irsTransactionType
				+ ", irsRepFlag=" + irsRepFlag + ", irsReportUploadTime="
				+ irsReportUploadTime + ", irsMsgType=" + irsMsgType
				+ ", irsMsgStatus=" + irsMsgStatus + ", irsDescription="
				+ irsDescription + ", gtrAction=" + gtrAction + ", gtrUsi="
				+ gtrUsi + ", dtccRespRecv=" + dtccRespRecv
				+ ", dtccRespAcceptance=" + dtccRespAcceptance
				+ ", sdrSubmissionTime=" + sdrSubmissionTime
				+ ", gtrTransType=" + gtrTransType + ", gtrRepFlag="
				+ gtrRepFlag + ", gtrAssetClass=" + gtrAssetClass
				+ ", gtrTradeParty1ReferenceNumber="
				+ gtrTradeParty1ReferenceNumber +", gtrExecutionTime=" + gtrExecutionTime +", gtrMessageType="
				+ gtrMessageType + ", reconId=" + reconId + "]";
	}
	
}

