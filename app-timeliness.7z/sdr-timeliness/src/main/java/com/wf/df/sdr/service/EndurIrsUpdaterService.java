package com.wf.df.sdr.service;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

@Component
@ManagedResource(description="Update Endur IRS details")
public class EndurIrsUpdaterService extends BaseIrsUpdaterService{

	@ManagedOperation(description="Trigger Endur IRS Upload")
	public void updateForIrsDetailsForEndurSystem(String reconId){
		
		/*
		 * Need to handle seperately for Commodity
		 * */
		
		//updateForIrsDetails(reconId,Constants.ASSET_CLASS_COMMODITY);

		logger.info("Completed Endur IRS updating");
		}
}
