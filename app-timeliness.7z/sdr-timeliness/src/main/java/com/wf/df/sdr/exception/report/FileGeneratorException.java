package com.wf.df.sdr.exception.report;


public class FileGeneratorException extends RuntimeException {
	
	private static final long serialVersionUID = -4673009613676459325L;

	public FileGeneratorException() {
		super();
	}
	
	public FileGeneratorException(String message) {
		super(message);
	}
	
	public FileGeneratorException(Throwable cause) {
		super(cause);
	}
	
	public FileGeneratorException(String message, Throwable cause) {
		super(message, cause);
	}
}
