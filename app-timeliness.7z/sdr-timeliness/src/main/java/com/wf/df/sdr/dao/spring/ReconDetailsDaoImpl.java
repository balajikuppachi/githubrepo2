package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.ReconDetailsDao;
import com.wf.df.sdr.dto.ReconDetails;
import com.wf.df.sdr.exception.dao.TimelinessDomainException;

public class ReconDetailsDaoImpl  extends AbstractDAO implements ParameterizedRowMapper<ReconDetails>,ReconDetailsDao{

	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return ReconDetails
	 */
	@Override
	public ReconDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		ReconDetails dto=new ReconDetails();
		dto.setId(rs.getBigDecimal(1));
		dto.setReconId(rs.getString(2));
		dto.setReportFileName(rs.getString(3));
		dto.setMailStatus(rs.getString(4));
		dto.setRunDate(rs.getDate(5));
		dto.setReconFlag(rs.getString(6));
		
		return dto;
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(ReconDetails dto) {
		
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( id, recon_id, report_file_name, mail_status,run_date, recon_date_flag ) VALUES ( ?, ?, ?, ?, ?, ?)", dto.getId(),dto.getReconId(),dto.getReportFileName(),dto.getMailStatus(),new Date(), dto.getReconFlag());
		
	}

	/** 
	 * Returns all rows from the recon_details table that match the criteria ''.
	 */
	@Transactional
	public List<ReconDetails> findAll() throws TimelinessDomainException {
		try {
			return jdbcTemplate.query("SELECT id, recon_id, report_file_name, mail_status,run_date, recon_date_flag  FROM " + getTableName()+ "", this);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new TimelinessDomainException("Query failed", e);
		}
	}
	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recon_details";
	}

	@Transactional
	public void UpdateReconDetails(ReconDetails dto) throws TimelinessDomainException {
		try {
			jdbcTemplate.update("Update " + getTableName()+ " set report_file_name = ?, mail_status = ?, recon_date_flag = ? where recon_id = ?", dto.getReportFileName(), dto.getMailStatus(), dto.getReconFlag(), dto.getReconId());
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
