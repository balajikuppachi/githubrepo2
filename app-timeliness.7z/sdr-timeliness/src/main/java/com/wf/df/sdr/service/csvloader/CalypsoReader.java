package com.wf.df.sdr.service.csvloader;

import java.io.InputStream;
import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.beans.CalypsoBean;
import com.wf.df.sdr.service.csvloader.common.CommonLoader;
import com.wf.df.sdr.service.csvloader.common.DataReader;
import com.wf.df.sdr.service.csvloader.common.SdrSnapshotReader;

@Component
public class CalypsoReader extends CommonLoader<CalypsoBean>{
	
	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new SdrSnapshotReader(inputStream,1);
	}
	
	@Override
	public boolean validate(CalypsoBean bean) {
		/*if(bean.getAssetClass().toLowerCase().contains(Constants.FX.toLowerCase())){
			return false;
		}*/
		return true;
	}
	
	@Override
	public CalypsoBean parseRecord(String[] fields) throws ParseException {
		CalypsoBean bean = new CalypsoBean();
		bean.setSystem(fields[0]);
		bean.setTradeId(fields[1]);
		bean.setTradeVersion(fields[2]);
		bean.setTradeStatus(fields[3]);
		bean.setAssetClass(fields[4]);
		bean.setProductType(fields[5]);
		bean.setSubProductType(fields[6]);
		bean.setTlcExecutionDatetime(fields[7]);
		bean.setCptyClassification(fields[8]);
		bean.setEmirDelegatedReportingElection(fields[9]);
		bean.setEmirReportable(fields[10]);
		bean.setEmirReportingParty(fields[11]);
		bean.setExecutionDatetime(fields[12]);
		bean.setReportingJurisdiction(fields[13]);
		bean.setReportingParty(fields[14]);
		bean.setSdrBackload(fields[15]);
		bean.setSdrEligible(fields[16]);
		bean.setSdrMarketType(fields[17]);
		bean.setSdrReportable(fields[18]);
		bean.setUsiCurrent(fields[19]);
		bean.setUtiCurrent(fields[20]);
		return bean;
	}
}
