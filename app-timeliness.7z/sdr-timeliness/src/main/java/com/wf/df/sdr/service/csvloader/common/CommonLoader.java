package com.wf.df.sdr.service.csvloader.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wf.df.sdr.service.csvloader.beans.BaseBean;

public abstract class CommonLoader<T extends BaseBean> {
	private Logger logger = LoggerFactory.getLogger(CommonLoader.class);
	public abstract T parseRecord(String[] fields) throws ParseException ;
	public abstract DataReader<String[]> getDataReader(InputStream inputStream);
	public abstract boolean validate(T bean);
	public String filename = null;
	
	public List<T> read(String file) throws FileNotFoundException, IOException, ParseException {
		List<T> beanList = new ArrayList<T>();
		filename=file;
		logger.info("Loading data from file: " + file);
		InputStream is = null;
		try {
			is = getClass().getResourceAsStream("/"+file);
			if(null != is)
				beanList=this.read(is);
			else
				throw new FileNotFoundException(file+" is not found");
		} finally {
			if (is != null) {
				is.close();
			}
		}
		return beanList;
	}
	
	public List<T> read(File file) throws FileNotFoundException, IOException, ParseException {
		List<T> beanList = new ArrayList<T>();
		filename=file.getName();
		logger.info("Loading data from file: " + filename);
		InputStream is = null;
		try {
			is = new FileInputStream(file);
			if(null != is)
				beanList=this.read(is);
		} catch(FileNotFoundException fne){
			logger.error(fne.getMessage());
		}
		finally {
			if (is != null) {
				is.close();
				file.delete();
			}
		}
		logger.info(filename + " - file loading complete for : "+ beanList.size() +" records");
		return beanList;
	}
	
	public List<T> read(InputStream inputStream) throws IOException, ParseException{
		DataReader<String[]> dataReader = getDataReader(inputStream);
		return loadFile(dataReader);
	}
	
	
	
	public List<T> loadFile(DataReader<String[]> reader) throws IOException, ParseException {
		String[] nextLine = null;
		List<T> beanList = new ArrayList<T>();
		try {
			while ((nextLine = reader.readNext()) != null) {
				try {					
					T entry = parseRecord(nextLine);
					if(validate(entry)){
						beanList.add(entry);
					}
					else{
						//Invalid records
					}
				} catch (Exception e) {
					logger.error("Couldn't parse record: file #" + reader.currentLocation().asString(), e);
				} 
			}
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
		return beanList;
	}
	
}
