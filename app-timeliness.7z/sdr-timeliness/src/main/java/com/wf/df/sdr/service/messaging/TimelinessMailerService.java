package com.wf.df.sdr.service.messaging;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.dao.ReconDetailsDao;
import com.wf.df.sdr.dto.AssetClassWiseDetails;
import com.wf.df.sdr.dto.ReconDetails;
import com.wf.df.sdr.service.csvloader.common.Constants;

@Component
public class TimelinessMailerService {

	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private TimelinessMailSender mailSender;
	
	 @Autowired
	    private VelocityEngine velocityEngine;
	 
	 @Autowired
	 public ReconDetailsDao reconDetailsDao;
	
	@Value("${mail.from.timeliness}") String mailFromTimeliness;
	@Value("${mail.to.timeliness}") String mailToTimeliness;
	@Value("${mail.cc.timeliness}") String mailCCTimeliness;
	@Value("${mail.bcc.timeliness}") String mailBCCTimeliness;
	@Value("${file.outputFolder.Timeliness}") String timelinessOutput;
	
	@Value("${timeliness.report.template}") String timelinessEmailTemplate;
	
	String subject=Constants.TimelinessFileName;
	
	public static HashMap<String, String> templateMap = new HashMap <String, String>();
	
	@PostConstruct
	public void initialize() {
			// Add templates here
			templateMap.put(Constants.TIMELINESSEMAIL , timelinessEmailTemplate);
	}
	
	public void setTimelinessMailSender(TimelinessMailSender mailSender) {
		this.mailSender = mailSender;
	}
	
	public void sendTimelinessMail(TimelinessReportRequest reportReq) {
		
		sendMail(subject,  mailFromTimeliness, mailToTimeliness, mailCCTimeliness, mailBCCTimeliness,  reportReq.getFileName(),reportReq.getReconId(),reportReq.getMsgContent());
		
	}
	
	private String alterReconID(String reconID) {
		
		StringBuffer sb = new StringBuffer(reconID);
		if(reconID.length()==8){
			sb.insert(4, '-');
			sb.insert(7, '-');
		}
		return 	sb.toString();		
	}
	public void sendMail(String subject, String from, String to, String cc, String bcc, File attachment,String reconId, Map<String, AssetClassWiseDetails> dataMap) {
		logger.info("Sending mail for Recon Id : "+reconId);
		String filePath=timelinessOutput+Constants.BACKSLASH+attachment.getName();
		String templateStr=templateMap.get(Constants.TIMELINESSEMAIL);
		subject=subject+" as of "+alterReconID(reconId);
		File generatedFile= new File(filePath);
		String[] toArr = null;
		String[] toCCArr = null;
		String[] toBCCArr = null;

		if (!TimelinessUtils.IsNullOrBlank(to))
			toArr = to.split(",");
		if (!TimelinessUtils.IsNullOrBlank(cc))
			toCCArr = cc.split(",");
		if (!TimelinessUtils.IsNullOrBlank(bcc))
			toBCCArr = bcc.split(",");
		
		
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message,true);
			String body = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, templateStr, "UTF-8", dataMap);
			helper.setSubject(subject);
			helper.setText(body,true);
			helper.setFrom(from);
			if (toArr != null)
				helper.setTo(toArr);
			if (toCCArr != null)
				helper.setCc(toCCArr);
			if (toBCCArr != null)
				helper.setBcc(toBCCArr);
			/*if (StringUtils.isNotBlank(replyTo))
				helper.setReplyTo(replyTo);*/
			if(attachment!=null)
				helper.addAttachment(attachment.getName(), generatedFile);
			mailSender.send(message);
			logger.info("Mail Sent :"+subject);
			
			/*
			 * Update recon details
			 * */
			ReconDetails reconDetails = new ReconDetails();
			reconDetails.setReconId(reconId);
			reconDetails.setReportFileName(attachment.getName());
			reconDetails.setMailStatus(Constants.SENT);
			reconDetails.setReconFlag(Constants.FALSE);
			reconDetailsDao.UpdateReconDetails(reconDetails);
			logger.info("updated recon details table");
			
		} catch (Exception me) {
			logger.info("Error in Sending Mail"	+ me);
		}

	}
}
