package com.wf.df.sdr.dto;

import java.util.Date;

public class TimelinessDomain {
	
	private String	system;
	private String	assetClass;
	private String	product;
	private Long	foExecDate;
	private Long	executionDate;
	private Long	foTlcExecDate;
	private String	foMarketType;
	private String	foTradeStatus;
	private String	foTradeId;
	private String	foTradeVersion;
	private String	foUsi;
	private String	foSdrEligibleTrade;
	private String	reportingParty;
	private String	sdrEligibility;
	private String	foRepFlag;
	private String	irsRecvTimestamp;
	private String	irsSendId;
	private String	irsTradeId;
	private String	irsTradeVersion;
	private String	irsUsi;
	private String	irsDtccUsi;
	private String	irsTransactionType;
	private String	irsRepFlag;
	private Long	irsReportUploadTime;
	private String	gtrUsi;
	private String	dtccRespRecv;
	private String	dtccRespAcceptance;
	private Long	sdrSubmissionTime;
	private String	gtrRepFlag;
	private Date 	runDate;
	private String	reported;
	private String uniqueFileId;
	
	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public Long getFoExecDate() {
		return foExecDate;
	}
	public void setFoExecDate(Long foExecDate) {
		this.foExecDate = foExecDate;
	}
	public Long getExecutionDate() {
		return executionDate;
	}
	public void setExecutionDate(Long executionDate) {
		this.executionDate = executionDate;
	}
	public Long getFoTlcExecDate() {
		return foTlcExecDate;
	}
	public void setFoTlcExecDate(Long foTlcExecDate) {
		this.foTlcExecDate = foTlcExecDate;
	}
	public String getFoMarketType() {
		return foMarketType;
	}
	public void setFoMarketType(String foMarketType) {
		this.foMarketType = foMarketType;
	}
	public String getFoTradeStatus() {
		return foTradeStatus;
	}
	public void setFoTradeStatus(String foTradeStatus) {
		this.foTradeStatus = foTradeStatus;
	}
	public String getFoTradeId() {
		return foTradeId;
	}
	public void setFoTradeId(String foTradeId) {
		this.foTradeId = foTradeId;
	}
	public String getFoTradeVersion() {
		return foTradeVersion;
	}
	public void setFoTradeVersion(String foTradeVersion) {
		this.foTradeVersion = foTradeVersion;
	}
	public String getFoUsi() {
		return foUsi;
	}
	public void setFoUsi(String foUsi) {
		this.foUsi = foUsi;
	}
	public String getFoSdrEligibleTrade() {
		return foSdrEligibleTrade;
	}
	public void setFoSdrEligibleTrade(String foSdrEligibleTrade) {
		this.foSdrEligibleTrade = foSdrEligibleTrade;
	}
	public String getReportingParty() {
		return reportingParty;
	}
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}
	public String getSdrEligibility() {
		return sdrEligibility;
	}
	public void setSdrEligibility(String sdrEligibility) {
		this.sdrEligibility = sdrEligibility;
	}
	public String getFoRepFlag() {
		return foRepFlag;
	}
	public void setFoRepFlag(String foRepFlag) {
		this.foRepFlag = foRepFlag;
	}
	public String getIrsRecvTimestamp() {
		return irsRecvTimestamp;
	}
	public void setIrsRecvTimestamp(String irsRecvTimestamp) {
		this.irsRecvTimestamp = irsRecvTimestamp;
	}
	public String getIrsSendId() {
		return irsSendId;
	}
	public void setIrsSendId(String irsSendId) {
		this.irsSendId = irsSendId;
	}
	public String getIrsTradeId() {
		return irsTradeId;
	}
	public void setIrsTradeId(String irsTradeId) {
		this.irsTradeId = irsTradeId;
	}
	public String getIrsTradeVersion() {
		return irsTradeVersion;
	}
	public void setIrsTradeVersion(String irsTradeVersion) {
		this.irsTradeVersion = irsTradeVersion;
	}
	public String getIrsUsi() {
		return irsUsi;
	}
	public void setIrsUsi(String irsUsi) {
		this.irsUsi = irsUsi;
	}
	public String getIrsDtccUsi() {
		return irsDtccUsi;
	}
	public void setIrsDtccUsi(String irsDtccUsi) {
		this.irsDtccUsi = irsDtccUsi;
	}
	public String getIrsTransactionType() {
		return irsTransactionType;
	}
	public void setIrsTransactionType(String irsTransactionType) {
		this.irsTransactionType = irsTransactionType;
	}
	public String getIrsRepFlag() {
		return irsRepFlag;
	}
	public void setIrsRepFlag(String irsRepFlag) {
		this.irsRepFlag = irsRepFlag;
	}
	public Long getIrsReportUploadTime() {
		return irsReportUploadTime;
	}
	public void setIrsReportUploadTime(Long irsReportUploadTime) {
		this.irsReportUploadTime = irsReportUploadTime;
	}
	public String getGtrUsi() {
		return gtrUsi;
	}
	public void setGtrUsi(String gtrUsi) {
		this.gtrUsi = gtrUsi;
	}
	public String getDtccRespRecv() {
		return dtccRespRecv;
	}
	public void setDtccRespRecv(String dtccRespRecv) {
		this.dtccRespRecv = dtccRespRecv;
	}
	public String getDtccRespAcceptance() {
		return dtccRespAcceptance;
	}
	public void setDtccRespAcceptance(String dtccRespAcceptance) {
		this.dtccRespAcceptance = dtccRespAcceptance;
	}
	public Long getSdrSubmissionTime() {
		return sdrSubmissionTime;
	}
	public void setSdrSubmissionTime(Long sdrSubmissionTime) {
		this.sdrSubmissionTime = sdrSubmissionTime;
	}
	public String getGtrRepFlag() {
		return gtrRepFlag;
	}
	public void setGtrRepFlag(String gtrRepFlag) {
		this.gtrRepFlag = gtrRepFlag;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public String getReported() {
		return reported;
	}
	public void setReported(String reported) {
		this.reported = reported;
	}
	public String getUniqueFileId() {
		return uniqueFileId;
	}
	public void setUniqueFileId(String uniqueFileId) {
		this.uniqueFileId = uniqueFileId;
	}
	
	
	@Override
	public String toString() {
		return "TimelinessDomain [system=" + system + ", assetClass="
				+ assetClass + ", product=" + product + ", foExecDate="
				+ foExecDate + ", executionDate=" + executionDate
				+ ", foTlcExecDate=" + foTlcExecDate + ", foMarketType="
				+ foMarketType + ", foTradeStatus=" + foTradeStatus
				+ ", foTradeId=" + foTradeId + ", foTradeVersion="
				+ foTradeVersion + ", foUsi=" + foUsi + ", foSdrEligibleTrade="
				+ foSdrEligibleTrade + ", reportingParty=" + reportingParty
				+ ", sdrEligibility=" + sdrEligibility + ", foRepFlag="
				+ foRepFlag + ", irsRecvTimestamp=" + irsRecvTimestamp
				+ ", irsSendId=" + irsSendId + ", irsTradeId=" + irsTradeId
				+ ", irsTradeVersion=" + irsTradeVersion + ", irsUsi=" + irsUsi
				+ ", irsDtccUsi=" + irsDtccUsi + ", irsTransactionType="
				+ irsTransactionType + ", irsRepFlag=" + irsRepFlag
				+ ", irsReportUploadTime=" + irsReportUploadTime + ", gtrUsi="
				+ gtrUsi + ", dtccRespRecv=" + dtccRespRecv
				+ ", dtccRespAcceptance=" + dtccRespAcceptance
				+ ", sdrSubmissionTime=" + sdrSubmissionTime + ", gtrRepFlag="
				+ gtrRepFlag + ", runDate=" + runDate + ", reported="
				+ reported + ", uniqueFileId=" + uniqueFileId + "]";
	}
	

}
