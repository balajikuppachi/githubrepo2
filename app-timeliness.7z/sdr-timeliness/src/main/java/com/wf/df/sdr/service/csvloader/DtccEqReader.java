package com.wf.df.sdr.service.csvloader;

import java.io.InputStream;
import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.commons.TimelinessUtils;
import com.wf.df.sdr.service.csvloader.beans.DtccEqBean;
import com.wf.df.sdr.service.csvloader.common.CommonLoader;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DataReader;
import com.wf.df.sdr.service.csvloader.common.DateUtil;
import com.wf.df.sdr.service.csvloader.common.SdrSnapshotReader;

@Component
public class DtccEqReader extends CommonLoader<DtccEqBean>{

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new SdrSnapshotReader(inputStream,3);
	}
	
	@Override
	public boolean validate(DtccEqBean bean) {
		if(bean.getMessageType().equals(Constants.RT)||bean.getMessageType().equals(Constants.PET))
			return true;
		else
			return false;
	}

	@Override
	public DtccEqBean parseRecord(String[] fields) throws ParseException {
		DtccEqBean bean = new DtccEqBean();
		
		bean.setMessageType(fields[0]);
		bean.setTransactionType(fields[1]);
		bean.setGtrAction(fields[2]);
		bean.setAssetClass(fields[3]);
		bean.setUsiPrefix(fields[5]);
		bean.setUsiValue(fields[6]);
		bean.setProductIdValue(fields[8]);
		//bean.setDataSubmitterMessageId(fields[34]);
		bean.setParty1TransactionId(fields[23]);
		bean.setStatus(!TimelinessUtils.IsNullOrBlank(fields[28])?fields[28]:"");
		bean.setSubmissionDateTime(bean.getStatus().equals(Constants.EQ_ACCEPTED)?DateUtil.getTimestampFromStringAcceptedEq(fields[27]):DateUtil.getTimestampFromStringRejectedEq(fields[27]));
		return bean;
	}
	
}
