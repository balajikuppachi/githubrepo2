package com.wf.df.sdr.service.csvloader;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wf.df.sdr.service.csvloader.beans.BaseBean;

public class LoadTester<T>{

	private Logger logger = LoggerFactory.getLogger(LoadTester.class);

	public static void main(String[] args) {
		
		/*Run for Galaxy*/
		List<? extends BaseBean> beanGalaxyList = new LoadTester<GalaxyReader>().callGenericReader(new GalaxyReader(),"galaxy_SdrRecon20140307.csv");
		for(BaseBean bean : beanGalaxyList){
			System.out.println(bean);
		}
		
		/*Run for Endur*/
		List<? extends BaseBean> beanEndurList = new LoadTester<EndurReader>().callGenericReader(new EndurReader(),"endur_fo feed report.csv");
		for(BaseBean bean : beanEndurList){
			System.out.println(bean);
		}
		
		/*Run for Calypso*/
		List<? extends BaseBean> beanCalypsoList = new LoadTester<CalypsoReader>().callGenericReader(new CalypsoReader(),"calypso_SDRDailyReconReport.CIRCqafunrel.csv");
		for(BaseBean bean : beanCalypsoList){
			System.out.println(bean);
		}
		
		/*Run for DTCC IR*/
		List<? extends BaseBean> beanDtccIrList = new LoadTester<DtccIrReader>().callGenericReader(new DtccIrReader(),"IR_SUB_040314_094754.CSV");
		for(BaseBean bean : beanDtccIrList){
			System.out.println(bean);
		}
	}
	
	public List<? extends BaseBean> callGenericReader(T loader,String filename){
		logger.info("Calling Reader");
		List<? extends BaseBean> returnList = null;
		
		/*Change type of loader to read only the one required*/
		if(!(loader instanceof CalypsoReader))
			return new ArrayList<BaseBean>();
		
		try {
			returnList = (	loader instanceof GalaxyReader? (GalaxyReader) loader: 
							loader instanceof EndurReader ? (EndurReader) loader : 
							loader instanceof CalypsoReader ? (CalypsoReader) loader :
								(DtccIrReader) loader).read(filename);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		logger.info("List size : " + returnList.size());
		return returnList;
	}
}
