package com.wf.df.sdr.service.csvloader;

import java.io.InputStream;
import java.text.ParseException;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.service.csvloader.beans.DtccFxBean;
import com.wf.df.sdr.service.csvloader.common.CommonLoader;
import com.wf.df.sdr.service.csvloader.common.Constants;
import com.wf.df.sdr.service.csvloader.common.DataReader;
import com.wf.df.sdr.service.csvloader.common.DateUtil;
import com.wf.df.sdr.service.csvloader.common.SdrSnapshotReader;


@Component
public class DtccFxReader extends CommonLoader<DtccFxBean>{

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new SdrSnapshotReader(inputStream,4);
	}

	@Override
	public boolean validate(DtccFxBean bean) {
		if(bean.getMessageType().equals(Constants.RT))
			return true;
		else
			return false;
	}

	@Override
	public DtccFxBean parseRecord(String[] fields) throws ParseException {
		DtccFxBean bean = new DtccFxBean();
		bean.setTransactionType(fields[10]);
		bean.setMessageType(fields[8]);
		bean.setUsiPrefix(fields[11]);
		bean.setUsiValue(fields[12]);
		bean.setAssetClass(fields[13]);
		bean.setProductType(fields[26]+fields[27]);
		bean.setStatus("NOT THERE");				//DTCC submission report does not have this field	
		bean.setSubmissionDateTime(DateUtil.getTimestampFromStringFx(fields[1]));
		bean.setTradeParty1TransactionId(fields[50]);
		//this field need to add in report(Data submitter ID)
		bean.setDataSubmitter(fields[179]);
		
		return bean;
	}
}
