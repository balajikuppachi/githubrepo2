/*package com.wellsfargo.regulatory.core.rules.services;

import org.apache.log4j.Logger;
import org.drools.runtime.StatefulKnowledgeSession;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;

public class TradeEnrichRuleTest
{
	private static final Logger logger = Logger.getLogger(TradeEnrichRuleTest.class);

	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static <StatefulKnowledgeSession> void main(String[] args)
	{
		ReportingContext currReportingContext = ReportingContext.getInstance();

		Keyword currKeyword = new Keyword();
		SdrRequest sdrRequest = new SdrRequest();
		TradeType tradeType = new TradeType();
		TradeHeaderType tradeHeaderType = new TradeHeaderType();
		LifeCycleType lifeCycleType = new LifeCycleType();
		// lifeCycleType.setAllocatedFrom("true");
		lifeCycleType.setEventType("New Deal");
		tradeHeaderType.setLifeCycle(lifeCycleType);
		// currReportingContext.setAssetClass("Transaction");

		RegulatoryType currRegulatoryType = new RegulatoryType();
		KeywordsType currKeywordsType = new KeywordsType();

		tradeType.setTradeHeader(tradeHeaderType);
		tradeType.setRegulatory(currRegulatoryType);
		currRegulatoryType.setKeywords(currKeywordsType);
		sdrRequest.setTrade(tradeType);
		currReportingContext.setSdrRequest(sdrRequest);

		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);

		System.out.println("Before calling rules engine");

		// StatelessKnowledgeSession statelessKnowledgeSession =
		// (StatelessKnowledgeSession)applicationContext.getBean("populateKSession");
		StatefulKnowledgeSession statefulKnowledgeSession = (StatefulKnowledgeSession) applicationContext.getBean("populateKSession");

		// statefulKnowledgeSession.setGlobal("logger", logger);
		// statelessKnowledgeSession.execute(currReportingContext);

		statefulKnowledgeSession.insert(currReportingContext);
		statefulKnowledgeSession.fireAllRules();
		statefulKnowledgeSession.dispose();

		System.out.println("After calling rules engine");

	}

}
*/