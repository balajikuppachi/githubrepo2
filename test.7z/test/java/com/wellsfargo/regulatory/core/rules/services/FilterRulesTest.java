package com.wellsfargo.regulatory.core.rules.services;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.GtrEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.keywords.Constants;

public class FilterRulesTest {

	private static final Logger logger = Logger.getLogger(FilterRulesTest.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args) {

        ReportingContext currReportingContext =ReportingContext.getInstance();

		SdrRequest sdrRequest = new SdrRequest();
		TradeType  tradeType = new TradeType();
		TradeHeaderType  tradeHeaderType = new TradeHeaderType();
		LifeCycleType  lifeCycleType = new LifeCycleType();
		lifeCycleType.setAllocatedFrom("true");
		lifeCycleType.setEventType("Compressed - Term");

		// data to test reportingParty rule
		ClearingType clearingType = new ClearingType();
		clearingType.setClearedTrade(false);
		lifeCycleType.setClearing(clearingType);

		currReportingContext.getRegulatories().put("CFTC_DTCC",UsThemEnum.US+"");

		tradeHeaderType.setLifeCycle(lifeCycleType);
		//currReportingContext.setAssetClass("Credit");
		sdrRequest.setAssetClass("Credit");

	// data to test internal trade
		tradeHeaderType.setProcessingOrgLEI("lei:abc123");
		tradeHeaderType.setCounterpartyLEI("CICI:PBLD0EJDB5FWOLXP3B761");


		RegulatoryType currRegulatoryType = new RegulatoryType();

		//data to dfVariableFilter
		ReportingEligibilityType reportingEligibilityType = new ReportingEligibilityType();
		reportingEligibilityType.setDelegatedReporting("true");
		reportingEligibilityType.setReportingJurisdiction(JurisdictionEnum.CFTC);
		reportingEligibilityType.setRepository(GtrEnum.DTCC);
		reportingEligibilityType.setReportingParty(UsThemEnum.THEM);

		ReportingEligibilityType reportingEligibilityTypeESMA = new ReportingEligibilityType();
		reportingEligibilityTypeESMA.setDelegatedReporting("true");
		reportingEligibilityTypeESMA.setReportingJurisdiction(JurisdictionEnum.ESMA);
		reportingEligibilityTypeESMA.setRepository(GtrEnum.DTCC);
		reportingEligibilityTypeESMA.setReportingParty(UsThemEnum.THEM);

     	currRegulatoryType.getReportingEligibility().add(reportingEligibilityType);
     	currRegulatoryType.getReportingEligibility().add(reportingEligibilityTypeESMA);

		// end data for dfVariableFilter
		KeywordsType currKeywordsType = new KeywordsType();

		LegType leg = new LegType();
		BigDecimal notional = new BigDecimal(90);
		leg.setNotional(notional);

		ProductType product = new ProductType();
		product.getLeg().add(leg);
	//	product.setProductType("CreditDefaultSwap");
		//product.setProductType("FXCash");

		//data to test rpsTradeFilterRule
		product.setProductType("RiskParticipationSwap");

		product.setProductSubType("Forward");

		//data to test usi filter
		Keyword	keyword = new Keyword();
		keyword.setName(Constants.USI_VALUE);
		keyword.setValue("A123");



		currKeywordsType.getKeyword().add(keyword);
		currRegulatoryType.setKeywords(currKeywordsType);


		TradeDetailType tradeDetail = new TradeDetailType();
		tradeDetail.setProduct(product);

		tradeType.setTradeDetail(tradeDetail);


		tradeType.setTradeHeader(tradeHeaderType);
		tradeType.setRegulatory(currRegulatoryType);
		sdrRequest.setTrade(tradeType);
		currReportingContext.setSdrRequest(sdrRequest);

	//	ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);

		System.out.println("before calling rules engine");


		KieServices ks = KieServices.Factory.get();
		KieContainer kc = ks.getKieClasspathContainer();
		KieSession ksession = kc.newKieSession("filterKSession");
		ksession.insert(currReportingContext);
		ksession.setGlobal("logger", logger);
	//	ksession.addEventListener( new DebugAgendaEventListener() );
	//	ksession.addEventListener( new DebugRuleRuntimeEventListener() );
		Agenda agenda = ksession.getAgenda();
		//agenda.getAgendaGroup( "assetClassAgenda" ).setFocus();

		//agenda.getAgendaGroup( "dfRulesAgenda" ).setFocus();

		agenda.getAgendaGroup( "filterAgenda" ).setFocus();
	//	agenda.getActivationGroup("dfRulesActivation").getName();






		ksession.fireAllRules();
	/*	if(currReportingContext.getRulesResultsContext() != null)
		{
			List<ValidationResult> validationResultList = currReportingContext.getRulesResultsContext().getFilterValidationResultList();

			for(ValidationResult currValidationResult: validationResultList)
			{
				System.out.println("Filter validation results are: " +currValidationResult.toString());
			}

		}
	*/


		System.out.println("after calling rules engine");

	}

}
