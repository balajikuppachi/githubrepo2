package com.wellsfargo.regulatory.core.rules.services;

import java.util.List;

import org.apache.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;

public class BuySellTypeValidationTest
{
	
	private static final Logger logger = Logger.getLogger(BuySellTypeValidationTest.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args) {
		
        ReportingContext currReportingContext =ReportingContext.getInstance();
	
		SdrRequest sdrRequest = new SdrRequest();
		TradeType  tradeType = new TradeType();
		TradeHeaderType  tradeHeaderType = new TradeHeaderType();
		LifeCycleType  lifeCycleType = new LifeCycleType();
		lifeCycleType.setAllocatedFrom("true");
		lifeCycleType.setEventType("New Deal");
		tradeHeaderType.setLifeCycle(lifeCycleType);
		currReportingContext.setAssetClass("InterestRate");
		
		TradeDetailType  tradeDetailType = new TradeDetailType();
		ProductType    productType       = new ProductType();
		productType.setBuySell(BuySellEnum.BUY);
		tradeDetailType.setProduct(productType);
		tradeType.setTradeDetail(tradeDetailType);
		
		
	
		
		RegulatoryType currRegulatoryType = new RegulatoryType();
		
		KeywordsType currKeywordsType = new KeywordsType();
		  
		tradeType.setTradeHeader(tradeHeaderType);
		tradeType.setRegulatory(currRegulatoryType);
		currRegulatoryType.setKeywords(currKeywordsType);
		sdrRequest.setTrade(tradeType);
		currReportingContext.setSdrRequest(sdrRequest);
		
	//	ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		
		System.out.println("before calling rules engine");
		
		
		KieServices ks = KieServices.Factory.get();
		KieContainer kc = ks.getKieClasspathContainer();
		KieSession ksession = kc.newKieSession("reqValidationKsession");
		ksession.insert(currReportingContext);
		ksession.setGlobal("logger", logger);
	
		Agenda agenda = ksession.getAgenda();
		agenda.getAgendaGroup( "assetClassAgenda" ).setFocus();
		agenda.getAgendaGroup( "commonAgenda" ).setFocus();
		ksession.fireAllRules();
		
		if(currReportingContext.getRulesResultsContext() != null)
		{
			List<ValidationResult> validationResultList = currReportingContext.getRulesResultsContext().getAlertValidationResultList();
			
			for(ValidationResult currValidationResult: validationResultList)
			{
				System.out.println("validation results are: " +currValidationResult.toString());
			}
			
		}
		
		System.out.println("after calling rules engine");    

	}

}
