package com.wellsfargo.regulatory.core.rules.services;

import org.apache.log4j.Logger;
import org.kie.api.runtime.KieSession;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;


public class TradeEnrichRuleTest_Spring {
	
	private static final Logger logger = Logger.getLogger(TradeEnrichRuleTest_Spring.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";


	public static void main(String[] args) {
		
        ReportingContext currReportingContext =ReportingContext.getInstance();
		
		Keyword currKeyword = new Keyword();
		SdrRequest sdrRequest = new SdrRequest();
		TradeType  tradeType = new TradeType();
		TradeHeaderType  tradeHeaderType = new TradeHeaderType();
		LifeCycleType  lifeCycleType = new LifeCycleType();
		lifeCycleType.setAllocatedFrom("true");
		lifeCycleType.setEventType("New Deal");
		tradeHeaderType.setLifeCycle(lifeCycleType);
		currReportingContext.setAssetClass("Transaction");
		
	
		
		RegulatoryType currRegulatoryType = new RegulatoryType();
		
		KeywordsType currKeywordsType = new KeywordsType();
		  
		tradeType.setTradeHeader(tradeHeaderType);
		tradeType.setRegulatory(currRegulatoryType);
		currRegulatoryType.setKeywords(currKeywordsType);
		sdrRequest.setTrade(tradeType);
		currReportingContext.setSdrRequest(sdrRequest);
		
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		
		System.out.println("before calling rules engine");
		
		
		//KieServices ks = KieServices.Factory.get();
		//KieContainer kc = ks.getKieClasspathContainer();
		//KieSession ksession = kc.newKieSession("enrichKS");
		
				                    
	//	KieBase kbase = (KieBase) applicationContext.getBean("enrichKBase");
		KieSession ksession =(KieSession) applicationContext.getBean("enrichKSession");
		
		ksession.insert(currReportingContext);
	//	ksession.setGlobal("logger", logger);
		ksession.fireAllRules();
		ksession.dispose();
		
		System.out.println("after calling rules engine");    

	}

}
