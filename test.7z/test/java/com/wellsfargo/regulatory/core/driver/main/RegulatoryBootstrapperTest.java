package com.wellsfargo.regulatory.core.driver.main;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Filename 	: RegulatoryAppBootstrapper.java 
 * Author 		: Rama K Nuti 
 * DateCreated 	: Aug 11 2014 
 * Contents 	: Bootstraps application components
 *
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. No part of this
 * program may be photocopied reproduced or translated to another program
 * language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class RegulatoryBootstrapperTest extends AbstractRegulatorySpringTestCase 
{
	private static final Log LOGGER = LogFactory.getLog(RegulatoryBootstrapperTest.class);

	public void testBootstrap() 
	{
		try 
		{
			LOGGER.debug("--> Started testBootstrap :: bootstrapApplication(META-INF)");
			RegulatoryBootstrapper.bootstrapApplication("META-INF");
			LOGGER.debug("--> Ended testBootstrap :: bootstrapApplication(META-INF)");
			
		} 
		catch (Throwable t) 
		{
			System.out.println("Exception encountered: "+ t.getClass().getName());
			t.printStackTrace();
			LOGGER.error("Exception encountered: " + t.getMessage(), t);
			//fail(t.getMessage());
		}
	}
	
//
//	public void testBootstrapMissing() 
//	{
//		try 
//		{
//			RegulatoryBootstrapper.bootstrapApplication("foo");
//		} 
//		catch (Throwable t) 
//		{
//			System.out.println("Exception encountered: "+ t.getClass().getName());
//			t.printStackTrace();
//			LOGGER.error("Exception encountered: " + t.getMessage(), t);
//			fail(t.getMessage());
//		}
//	}
//
//	public void testBootstrapNull() 
//	{
//		try 
//		{
//			RegulatoryBootstrapper.bootstrapApplication(null);
//		} 
//		catch (Throwable t) 
//		{
//			System.out.println("Exception encountered: " + t.getClass().getName());
//			t.printStackTrace();
//			LOGGER.error("Exception encountered: " + t.getMessage(), t);
//			fail(t.getMessage());
//		}
//	}
//
//	public void testShutdown() 
//	{
//		try 
//		{
//			RegulatoryBootstrapper.shutdown();
//		} 
//		catch (Throwable t) 
//		{
//			System.out.println("Exception encountered: " + t.getClass().getName());
//			t.printStackTrace();
//			LOGGER.error("Exception encountered: " + t.getMessage(), t);
//			fail(t.getMessage());
//		}
//	}
//	
//	
	
}
