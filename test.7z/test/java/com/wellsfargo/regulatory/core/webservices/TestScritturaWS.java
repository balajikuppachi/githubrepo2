package com.wellsfargo.regulatory.core.webservices;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.codec.binary.Base64;

/*
 * @version 1.0
 * @author  Rama K Nuti
 */
 
/* 
 * ====================
 * Credentials
 * ====================
 * UAT	: Account Password: S&druat#21
 * QA 	: Account Password: S&drqa#21
 * PROD	: Account Password: B8#b4wLk
 * 
 * sdrprod - AD-ENT
 * sdruat - QA-ENT 
 * sdrqa - QA-ENT

 */

public class TestScritturaWS 
{
	// UAT
	private static final String REQUEST_ScritturaWS = 
	"<soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:scr=\"http://com.webservice/Scrittura\">"
			+ "<soapenv:Header>"
			//+ "<id>app1cwf</id>" 
			//+ "<password>QzBtcG9zaXRl</password>"
			
			//+ "<id>"+ Base64.encodeBase64("app1cwf".getBytes()) +"</id>" 
			//+ "<password>"+ Base64.encodeBase64("QzBtcG9zaXRl".getBytes()) +"</password>"
			
			//+ "<id>"+ Base64.encodeBase64("sdruat".getBytes()) +"</id>" 
			//+ "<password>"+ Base64.encodeBase64("S&druat#21".getBytes()) +"</password>"

			+ "<id>"+ Base64.encodeBase64("sdrprod".getBytes()) +"</id>" 
			+ "<password>"+ Base64.encodeBase64("B8#b4wLk".getBytes()) +"</password>"

			+ "</soapenv:Header>"
			+ "<soapenv:Body>"
			//+ "<scr:getFileAsAttachment soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
			//+ "<string xsi:type=\"xsd:string\">234557</string>"
			+ "<scr:getFileAsAttachment>"
			+ "<string>234557</string>"
			+ "</scr:getFileAsAttachment>"
			+ " </soapenv:Body>"
	+ " </soapenv:Envelope>";

	// 14647703

	public static void main(String[] args) 
	{
		System.out.println("$$$$$$$$$$ Starting ScritturaWS ..........");
		getScritturaWSProfile();
		System.out.println("$$$$$$$$$$ Ending ScritturaWS ..........");
	}
	
	
	public static LoggerOutput log1 = null;
	
	
	public static void getScritturaWSProfile()
	{
		log1 = new LoggerOutput(Long.toString(System.currentTimeMillis())+"-ScritturaWS-IST.log");
		
		URL serviceURL = null;
		HttpURLConnection serviceConnection = null;
		
		//System.setProperty("javax.net.ssl.keyStore", "");
		//System.setProperty("javax.net.ssl.keyStorePassword", "");
		//System.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
		//System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
		//System.setProperty("javax.net.debug","all");
		//System.setProperty("java.security.debug","all");
		
		java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        
		System.out.println("$$$$$$$$$$$$$ Making Call to ScritturaWS Environment.");

		log1.start();
	    double stTime = System.currentTimeMillis();
        System.out.println("$$$$$$$$$$$$$ Time taken for ScritturaWS call (ScritturaWS Inquire) Start-Time : "+ stTime + " Milliseconds");
		
        
		try 
		{
			
			/*** Encode data on your side using BASE64 ***/
			//byte[] bytesEncoded = Base64.encodeBase64(str.getBytes());
			//System.out.println("ecncoded value is " + new String(bytesEncoded ));

			/*** Decode data on other side, by processing encoded data ***/
			//byte[] valueDecoded= Base64.decodeBase64(bytesEncoded );
			//System.out.println("Decoded value is " + new String(valueDecoded));
			
			
			//DEV/UAT
			//serviceURL = new URL("https://scrittura.test.wachovia.net/webservices/ScritturaWS?WSDL");

			//PROD
			serviceURL = new URL("https://scrittura.wachovia.net/webservices/ScritturaWS?WSDL");

			//serviceURL = new URL("https://scrittura.wachovia.net:443/webservices/ScritturaWS?WSDL");
				
			System.out.println("$$$$$$$$$$$$$ WebService Connecting URL is : "+ serviceURL);

			System.out.println("$$$$$$$$$$$$$ REQUEST_ScritturaWS : "+ REQUEST_ScritturaWS);

			URLConnection con;
			con = serviceURL.openConnection();
			
			serviceConnection = (HttpURLConnection) con;
			serviceConnection.setDoInput(true);
			serviceConnection.setDoOutput(true);
			serviceConnection.setRequestMethod("POST");
			serviceConnection.setRequestProperty("Content-Type", "text/xml");
			serviceConnection.setRequestProperty("Content-Length", String.valueOf(REQUEST_ScritturaWS.getBytes().length));
	
			serviceConnection.getOutputStream().write(REQUEST_ScritturaWS.getBytes());
			serviceConnection.getResponseCode();
	
			// Get response data
			InputStreamReader isr = null;
			if (serviceConnection.getErrorStream() != null) 
			{
				// Error occurred, get data from error stream if avail
				isr = new InputStreamReader(serviceConnection.getErrorStream());
			} 
			else 
			{
				// Good response from server, get data
				isr = new InputStreamReader(serviceConnection.getInputStream());
			}
	
			String result = readData(isr);
			
			log1.writeln(result);
			System.out.println(result);
			
		    double endTime = System.currentTimeMillis();
	        System.out.println("$$$$$$$$$$$$$ Time taken for ScritturaWS call (ScritturaWS Inquire) End-Time : "+ endTime + " Milliseconds");

	        System.out.println("$$$$$$$$$$$$$ Time taken for ScritturaWS call (ScritturaWS Inquire) : "+(endTime - stTime)+ " Milliseconds");
	        
			long totalMemory = Runtime.getRuntime().totalMemory();
			long freeMemory  = Runtime.getRuntime().freeMemory();

			System.out.println("########## Java Memory Total  : " + totalMemory);
			System.out.println("########## Java Memory Free   : " + freeMemory);
			System.out.println("########## Java Memory in use : " + (totalMemory - freeMemory));
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
			log1.writeln(ex.getMessage());
		}
		
		log1.stop();
	}


	/**
	 * Read contents of file or stream and return as string.
	 * 
	 * @param in
	 *            The Reader used to wrap the file or stream.
	 * @return String The contents of the file or stream as a string.
	 * @throws IOException
	 *             Thrown if I/O error occurs.
	 */
	private static String readData(Reader in) throws IOException, Exception 
	{
		int num = 0;
		char[] readBuf 		= new char[2048];
		StringBuffer buf 	= new StringBuffer();

		while ((num = in.read(readBuf, 0, readBuf.length)) != -1) 
		{
			buf.append(readBuf, 0, num);
		}

		return buf.toString();
	}
	
	
}
