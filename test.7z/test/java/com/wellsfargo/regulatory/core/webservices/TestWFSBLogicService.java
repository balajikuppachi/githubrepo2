package com.wellsfargo.regulatory.core.webservices;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/*
 * @version 1.0
 * @author  Rama K Nuti
 */

public class TestWFSBLogicService 
{
	private static final String REQUEST_WFSService = 
	"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:blog=\"http://www.wellsfargo.com/blogic\"> "
			+ "<soapenv:Header/>"
			+ "<soapenv:Body>"
			+ "<blog:isEConfirmEligible>"
			+ "<marketType>ABC</marketType>"
			+ "<processingOrg>WellsFargo</processingOrg>"
			+ "<counterparty>WellsFargo</counterparty>"
			+ "</blog:isEConfirmEligible>"
			+ "</soapenv:Body>"
   + "</soapenv:Envelope>";


	public static void main(String[] args) 
	{
		System.out.println("$$$$$$$$$$ Starting WFSService ..........");
		getWFSServiceProfile();
		System.out.println("$$$$$$$$$$ Ending WFSService ..........");
	}
	
	
	public static LoggerOutput log1 = null;
	
	
	public static void getWFSServiceProfile()
	{
		log1 = new LoggerOutput(Long.toString(System.currentTimeMillis())+"-WFSBLogicService-IST.log");
		
		URL serviceURL = null;
		HttpURLConnection serviceConnection = null;
		
		//System.setProperty("javax.net.ssl.keyStore", "");
		//System.setProperty("javax.net.ssl.keyStorePassword", "");
		//System.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
		//System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
		//System.setProperty("javax.net.debug","all");
		//System.setProperty("java.security.debug","all");
		
		java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        
		System.out.println("$$$$$$$$$$$$$ Making Call to WFSService Environment.");

		log1.start();
	    double stTime = System.currentTimeMillis();
        System.out.println("$$$$$$$$$$$$$ Time taken for WFSService call (WFSBLogicService Inquire) Start-Time : "+ stTime + " Milliseconds");
		
        
		try 
		{
			serviceURL = new URL("http://wspsa99a0015.wellsfargo.com:8080/wfs-blogic/WFSBLogicService?wsdl");

			System.out.println("$$$$$$$$$$$$$ WebService Connecting URL is : "+ serviceURL);
			
			URLConnection con;
			con = serviceURL.openConnection();
			
			serviceConnection = (HttpURLConnection) con;
			serviceConnection.setDoInput(true);
			serviceConnection.setDoOutput(true);
			serviceConnection.setRequestMethod("POST");
			serviceConnection.setRequestProperty("Content-Type", "text/xml");
			serviceConnection.setRequestProperty("Content-Length", String.valueOf(REQUEST_WFSService.getBytes().length));
	
			serviceConnection.getOutputStream().write(REQUEST_WFSService.getBytes());
			serviceConnection.getResponseCode();
	
			// Get response data
			InputStreamReader isr = null;
			if (serviceConnection.getErrorStream() != null) 
			{
				// Error occurred, get data from error stream if avail
				isr = new InputStreamReader(serviceConnection.getErrorStream());
			} 
			else 
			{
				// Good response from server, get data
				isr = new InputStreamReader(serviceConnection.getInputStream());
			}
	
			String result = readData(isr);
			
			log1.writeln(result);
			System.out.println(result);
			
		    double endTime = System.currentTimeMillis();
	        System.out.println("$$$$$$$$$$$$$ Time taken for WFSService call (WFSService Inquire) End-Time : "+ endTime + " Milliseconds");

	        System.out.println("$$$$$$$$$$$$$ Time taken for WFSService call (WFSService Inquire) : "+(endTime - stTime)+ " Milliseconds");
	        
			long totalMemory = Runtime.getRuntime().totalMemory();
			long freeMemory  = Runtime.getRuntime().freeMemory();

			System.out.println("########## Java Memory Total  : " + totalMemory);
			System.out.println("########## Java Memory Free   : " + freeMemory);
			System.out.println("########## Java Memory in use : " + (totalMemory - freeMemory));
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
			log1.writeln(ex.getMessage());
		}
		
		log1.stop();
	}


	/**
	 * Read contents of file or stream and return as string.
	 * 
	 * @param in
	 *            The Reader used to wrap the file or stream.
	 * @return String The contents of the file or stream as a string.
	 * @throws IOException
	 *             Thrown if I/O error occurs.
	 */
	private static String readData(Reader in) throws IOException, Exception 
	{
		int num = 0;
		char[] readBuf 		= new char[2048];
		StringBuffer buf 	= new StringBuffer();

		while ((num = in.read(readBuf, 0, readBuf.length)) != -1) 
		{
			buf.append(readBuf, 0, num);
		}

		return buf.toString();
	}
	
	
}
