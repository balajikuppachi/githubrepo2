package com.wellsfargo.regulatory.core.webservices;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;

/**
 * -----------------------------------------------------------------------------
 * Used to test the Java I/O package to format output to a file using the 
 * PrintWriter wrapper class.
 * Example usage:
 *
 *   LoggerOutput log = new LoggerOutput("TestLogger.log");
 *   log.start();
 *   log.writeln("main : < Setting counter to 1");
 *   log.writeln("main : > Out of main with counter at 1024");
 *   log.stop();
 * 
 * @version 1.0
 * @author  Rama K Nuti
 * -----------------------------------------------------------------------------
 */

public class LoggerOutput 
{
    private String      logFileName  = null;
    private PrintWriter pw           = null;
    private Date        startTime    = null;
    private Date        stopTime     = null;


    /**
     * Used to write a given String object (without a newline) to the log file.
     * @param s String that will be written to the log file.
     */
    public void write (String s) 
    {
        pw.print(s);
    }


    /**
     * Used to write a given String object (with a newline) to the log file.
     * @param s String that will be written to the log file.
     */
    public void writeln (String s) 
    {
        pw.println(s);
    }


    /**
     * Used to write a newline character to the log file.
     */
    public void writeln () 
    {
        pw.println();
    }


    /**
     * Used to open the log file for writting.  This method MUST be called
     * before writting to the log file.
     */
    public void start() 
    {
        startTime = Calendar.getInstance().getTime();

        try 
        {
            pw = new PrintWriter(new FileWriter(logFileName));
        } 
        catch (IOException ioe) 
        {
            ioe.printStackTrace();
        }
        
        pw.println("# --------------------------------------------");
        pw.println("# LOG FILE     : " + logFileName);
        pw.println("# START TIME   : " + startTime);
        pw.println("# --------------------------------------------");
        pw.println();
    }


    /**
     * Used to flush and close the log file.  This method MUST be called in 
     * order for all data to be flushed and saved to the log file.
     */
    public void stop() 
    {
        stopTime 	= Calendar.getInstance().getTime();
        long diff 	= stopTime.getTime() - startTime.getTime();

        pw.println();
        pw.println("# --------------------------------------------");
        pw.println("#           << END OF LOGFILE >>              ");
        pw.println("# --------------------------------------------");
        pw.println("# STOP TIME    : " + stopTime);
        pw.println("# ELAPSED TIME : " + (diff / (1000L)) + " seconds.");
        pw.println("# --------------------------------------------");
        pw.close();
    }


    /**
     * Used to write a given String object (without a newline) to the log file.
     * @param logFileName Name of the path/logfile to create.
     */
    public LoggerOutput (String logFileName) 
    {
        this.logFileName = logFileName;
    }

}

