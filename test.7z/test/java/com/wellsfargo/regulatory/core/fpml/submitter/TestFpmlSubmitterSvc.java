package com.wellsfargo.regulatory.core.fpml.submitter;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.utils.FileUtils;
import com.wellsfargo.regulatory.core.services.reader.RegulatoryMessageReader;


public class TestFpmlSubmitterSvc
{
	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());

	@Value("${test.regRep.fpml.assetClass}")
	private String assetClass;
	@Value("${test.regRep.fpml.reportType}")
	private String reportType;
	@Value("${test.regRep.fpml.jurisdiction}")
	private String regulatory;

	public Message<?> submit(Message<?> message) throws MessagingException
	{
		logger.info("inside TestFpmlSubmitterSvc");

		Object ipMessage = null;
		File srcFile = null;
		String errorString = null;	
		String origPayload = null;
		ReportingContext repContext = null;
		Message<?> messageOut = null;	

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);

			return message;
			// throw new MessagingException("Reader-1", ExceptionSeverityEnum.ERROR,
			// ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId);
		}

		// sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
		ipMessage = message.getPayload();

		if (null == ipMessage)
		{
			errorString = "Null incoming request ";
			logger.error("########## " + errorString);

		}

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
		}
		else if (ipMessage instanceof File)
		{
			srcFile = ((File) ipMessage);

			try
			{
				origPayload = org.apache.commons.io.FileUtils.readFileToString(srcFile);

				// - Remove the src file
				FileUtils.deleteAFile(srcFile);
			}
			catch (IOException e)
			{
				errorString = "Failed to read the payload ";
				logger.error("########## " + errorString);
			}
		}
		else
		{
			errorString = "Failed to read invalid incoming message type";
			logger.error("########## " + errorString);
		}

		logger.debug("@@@@ Message-OrigPayload : \n" + StringUtils.trimToEmpty(origPayload));

		repContext = ReportingContext.getInstance();
		repContext.setPayload(origPayload);
		repContext.setMessageId("testFmpl");

		repContext.getRegulatories().put(regulatory,UsThemEnum.US+"");
		repContext.setAssetClass(assetClass);
		repContext.getReportTypes().add(reportType);

		// MessageBuilder.withPayload(origPayload).copyHeadersIfAbsent(message.getHeaders()).build();
		messageOut = MessageBuilder.withPayload(repContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.info("@@@@ Message has been sucessfully read !");

		return messageOut;
	}

}
