package com.wellsfargo.regulatory.core.integration.gateways;


import java.util.HashMap;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class GatewayServiceTest 
{
    public static void main(String[] args) throws Exception 
    {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext( "classpath:/com/wellsfargo/regulatory/core/spring/beans/gateway-app.xml");
        
        @SuppressWarnings("unchecked")
		java.util.HashMap routingRulesMap 	= (HashMap<String, String>) ctx.getBean("routingRulesMap");
		java.util.HashMap mqSenderMap 		= (HashMap<String, String>) ctx.getBean("mqSenderMap");
		java.util.HashMap mqListenerMap 	= (HashMap<String, String>) ctx.getBean("mqListenerMap");
		java.util.HashMap fpmlDeliveryMap 	= (HashMap<String, String>) ctx.getBean("fpmlDeliveryMap");

        System.out.println("RoutingRulesMap : "+routingRulesMap.size());
        System.out.println("MQSenderMap : "+mqSenderMap.size());
        System.out.println("MQListenerMap : "+mqSenderMap.size());
        System.out.println("FpmlDeliveryMap : "+fpmlDeliveryMap.size());
        
        String routingRule_CREDIT_DEFAULT_P 				= "FO,CFTC_DTCC,CREDIT,DEFAULT,DTCC";
        String routingRule_CREDIT_RT_P 						= "FO,CFTC_DTCC,CREDIT,RT,DTCC";
        String routingRule_CREDIT_PET_P 					= "FO,CFTC_DTCC,CREDIT,PET,DTCC";
        String routingRule_CREDIT_CONFIRM_P 				= "FO,CFTC_DTCC,CREDIT,CONFIRM,DTCC";
        String routingRule_CREDIT_DOCUMENT_P 				= "FO,CFTC_DTCC,CREDIT,DOCUMENT,DTCC";
        String routingRule_CREDIT_VALUATION_P 				= "FO,CFTC_DTCC,CREDIT,VALUATION,DTCC";
        String routingRule_CREDIT_SNAPSHOT_NP 				= "FO,CFTC_DTCC,CREDIT,SNAPSHOT,DTCC";
        String routingRule_CREDIT_SNAPSHOTBACKLOAD_NP		= "FO,CFTC_DTCC,CREDIT,SNAPSHOTBACKLOAD,DTCC";
        String routingRule_CREDIT_SNAPSHOT_NR_NP 			= "FO,CFTC_DTCC,CREDIT,SNAPSHOT_NR,DTCC";
        String routingRule_CREDIT_VALUATION_NR_NP 			= "FO,CFTC_DTCC,CREDIT,VALUATION_NR,DTCC";        
        
        String routingRule_INTERESTRATE_DEFAULT_P 			= "FO,CFTC_DTCC,INTERESTRATE,DEFAULT,DTCC";
        String routingRule_INTERESTRATE_RT_P 				= "FO,CFTC_DTCC,INTERESTRATE,RT,DTCC";
        String routingRule_INTERESTRATE_PET_P 				= "FO,CFTC_DTCC,INTERESTRATE,PET,DTCC";
        String routingRule_INTERESTRATE_CONFIRM_P 			= "FO,CFTC_DTCC,INTERESTRATE,CONFIRM,DTCC";
        String routingRule_INTERESTRATE_DOCUMENT_P 			= "FO,CFTC_DTCC,INTERESTRATE,DOCUMENT,DTCC";
        String routingRule_INTERESTRATE_VALUATION_P 		= "FO,CFTC_DTCC,INTERESTRATE,VALUATION,DTCC";
        String routingRule_INTERESTRATE_SNAPSHOT_NP 		= "FO,CFTC_DTCC,INTERESTRATE,SNAPSHOT,DTCC";
        String routingRule_INTERESTRATE_SNAPSHOTBACKLOAD_NP = "FO,CFTC_DTCC,INTERESTRATE,SNAPSHOTBACKLOAD,DTCC";
        String routingRule_INTERESTRATE_SNAPSHOT_NR_NP 		= "FO,CFTC_DTCC,INTERESTRATE,SNAPSHOT_NR,DTCC";
        String routingRule_INTERESTRATE_VALUATION_NR_NP 	= "FO,CFTC_DTCC,INTERESTRATE,VALUATION_NR,DTCC";
        
        String routingRule_EQUITY_DEFAULT_P 				= "FO,CFTC_DTCC,EQUITY,DEFAULT,DTCC";
        String routingRule_EQUITY_RT_P 					= "FO,CFTC_DTCC,EQUITY,RT,DTCC";
        String routingRule_EQUITY_PET_P 					= "FO,CFTC_DTCC,EQUITY,PET,DTCC";
        String routingRule_EQUITY_CONFIRM_P 				= "FO,CFTC_DTCC,EQUITY,CONFIRM,DTCC";
        String routingRule_EQUITY_DOCUMENT_P 				= "FO,CFTC_DTCC,EQUITY,DOCUMENT,DTCC";
        String routingRule_EQUITY_VALUATION_P 			= "FO,CFTC_DTCC,EQUITY,VALUATION,DTCC";
        String routingRule_EQUITY_SNAPSHOT_NP 			= "FO,CFTC_DTCC,EQUITY,SNAPSHOT,DTCC";
        String routingRule_EQUITY_SNAPSHOTBACKLOAD_NP		= "FO,CFTC_DTCC,EQUITY,SNAPSHOTBACKLOAD,DTCC";
        String routingRule_EQUITY_SNAPSHOT_NR_NP 			= "FO,CFTC_DTCC,EQUITY,SNAPSHOT_NR,DTCC";
        String routingRule_EQUITY_VALUATION_NR_NP 		= "FO,CFTC_DTCC,EQUITY,VALUATION_NR,DTCC";
        
        String routingRule_COMM_DEFAULT_P 					= "FO,CFTC_DTCC,COMMODITY,DEFAULT,DTCC";
        String routingRule_COMM_RT_P 						= "FO,CFTC_DTCC,COMMODITY,RT,DTCC";
        String routingRule_COMM_PET_P 						= "FO,CFTC_DTCC,COMMODITY,PET,DTCC";
        String routingRule_COMM_CONFIRM_P 					= "FO,CFTC_DTCC,COMMODITY,CONFIRM,DTCC";
        String routingRule_COMM_DOCUMENT_P 					= "FO,CFTC_DTCC,COMMODITY,DOCUMENT,DTCC";
        String routingRule_COMM_VALUATION_P 				= "FO,CFTC_DTCC,COMMODITY,VALUATION,DTCC";
        String routingRule_COMM_SNAPSHOT_NP 				= "FO,CFTC_DTCC,COMMODITY,SNAPSHOT,DTCC";
        String routingRule_COMM_SNAPSHOTBACKLOAD_NP 		= "FO,CFTC_DTCC,COMMODITY,SNAPSHOTBACKLOAD,DTCC";
        String routingRule_COMM_SNAPSHOT_NR_NP 				= "FO,CFTC_DTCC,COMMODITY,SNAPSHOT_NR,DTCC";
        String routingRule_COMM_VALUATION_NR_NP 			= "FO,CFTC_DTCC,COMMODITY,VALUATION_NR,DTCC";
        
        String routingRule_FX_DEFAULT_P 					= "FO,CFTC_DTCC,FOREIGNEXCHANGE,DEFAULT,DTCC";
        String routingRule_FX_RT_P 							= "FO,CFTC_DTCC,FOREIGNEXCHANGE,RT,DTCC";
        String routingRule_FX_PET_P 						= "FO,CFTC_DTCC,FOREIGNEXCHANGE,PET,DTCC";
        String routingRule_FX_CONFIRM_P 					= "FO,CFTC_DTCC,FOREIGNEXCHANGE,CONFIRM,DTCC";
        String routingRule_FX_DOCUMENT_P 					= "FO,CFTC_DTCC,FOREIGNEXCHANGE,DOCUMENT,DTCC";
        String routingRule_FX_VALUATION_P 					= "FO,CFTC_DTCC,FOREIGNEXCHANGE,VALUATION,DTCC";
        String routingRule_FX_SNAPSHOT_NP 					= "FO,CFTC_DTCC,FOREIGNEXCHANGE,SNAPSHOT,DTCC";
        String routingRule_FX_SNAPSHOTBACKLOAD_NP 			= "FO,CFTC_DTCC,FOREIGNEXCHANGE,SNAPSHOTBACKLOAD,DTCC";
        String routingRule_FX_SNAPSHOT_NR_NP 				= "FO,CFTC_DTCC,FOREIGNEXCHANGE,SNAPSHOT_NR,DTCC";
        String routingRule_FX_VALUATION_NR_NP 				= "FO,CFTC_DTCC,FOREIGNEXCHANGE,VALUATION_NR,DTCC";
        
        
        /*** DTCC_INTERESTRATE_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_INTERESTRATE_PRIORITY_P 			= (String) routingRulesMap.get(routingRule_INTERESTRATE_RT_P);
        String dtccINTERESTRATEPriorityEndPoint 		= (String) mqSenderMap.get(DTCC_INTERESTRATE_PRIORITY_P);
        String dtccINTERESTRATEPriorityDelivery 		= (String) fpmlDeliveryMap.get(DTCC_INTERESTRATE_PRIORITY_P);
        String dtccINTERESTRATEPriorityEndPointURI 	= (String) mqListenerMap.get(dtccINTERESTRATEPriorityEndPoint);

        System.out.println("DTCC_INTERESTRATE_PRIORITY 		: "+DTCC_INTERESTRATE_PRIORITY_P);
        System.out.println("dtccINTERESTRATEPriorityEndPoint	: "+dtccINTERESTRATEPriorityEndPoint);
        System.out.println("dtccINTERESTRATEPriorityDelivery 	: "+dtccINTERESTRATEPriorityDelivery);
        System.out.println("dtccINTERESTRATEPriorityEndPointURI	: "+dtccINTERESTRATEPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");
        
        /*** DTCC_INTERESTRATE_NON_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_INTERESTRATE_NON_PRIORITY			= (String) routingRulesMap.get(routingRule_INTERESTRATE_SNAPSHOT_NP);
        String dtccINTERESTRATENonPriorityEndPoint 		= (String) mqSenderMap.get(DTCC_INTERESTRATE_NON_PRIORITY);
        String dtccINTERESTRATENonPriorityDelivery 		= (String) fpmlDeliveryMap.get(DTCC_INTERESTRATE_NON_PRIORITY);
        String dtccINTERESTRATENonPriorityEndPointURI 	= (String) mqListenerMap.get(dtccINTERESTRATENonPriorityEndPoint);

        System.out.println("DTCC_INTERESTRATE_NON_PRIORITY 		: "+DTCC_INTERESTRATE_NON_PRIORITY);
        System.out.println("dtccINTERESTRATENonPriorityEndPoint	: "+dtccINTERESTRATENonPriorityEndPoint);
        System.out.println("dtccINTERESTRATENonPriorityDelivery	: "+dtccINTERESTRATENonPriorityDelivery);
        System.out.println("dtccINTERESTRATENonPriorityEndPointURI	: "+dtccINTERESTRATENonPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");
        

        
        /*** DTCC_CREDIT_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_CREDIT_PRIORITY_P 			= (String) routingRulesMap.get(routingRule_CREDIT_RT_P);
        String dtccCREDITPriorityEndPoint 		= (String) mqSenderMap.get(DTCC_CREDIT_PRIORITY_P);
        String dtccCREDITPriorityDelivery 		= (String) fpmlDeliveryMap.get(DTCC_CREDIT_PRIORITY_P);
        String dtccCREDITPriorityEndPointURI 	= (String) mqListenerMap.get(dtccCREDITPriorityEndPoint);

        System.out.println("DTCC_CREDIT_PRIORITY 			: "+DTCC_CREDIT_PRIORITY_P);
        System.out.println("dtccCREDITPriorityEndPoint 		: "+dtccCREDITPriorityEndPoint);
        System.out.println("dtccCREDITPriorityDelivery 		: "+dtccCREDITPriorityDelivery);
        System.out.println("dtccCREDITPriorityEndPointURI		: "+dtccCREDITPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");
        
        /*** DTCC_CREDIT_NON_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_CREDIT_NON_PRIORITY			= (String) routingRulesMap.get(routingRule_CREDIT_SNAPSHOT_NP);
        String dtccCREDITNonPriorityEndPoint 	= (String) mqSenderMap.get(DTCC_CREDIT_NON_PRIORITY);
        String dtccCREDITNonPriorityDelivery 	= (String) fpmlDeliveryMap.get(DTCC_CREDIT_NON_PRIORITY);
        String dtccCREDITNonPriorityEndPointURI = (String) mqListenerMap.get(dtccCREDITNonPriorityEndPoint);

        System.out.println("DTCC_CREDIT_PRIORITY 			: "+DTCC_CREDIT_NON_PRIORITY);
        System.out.println("dtccCREDITNonPriorityEndPoint		: "+dtccCREDITNonPriorityEndPoint);
        System.out.println("dtccCREDITNonPriorityDelivery		: "+dtccCREDITNonPriorityDelivery);
        System.out.println("dtccCREDITNonPriorityEndPointURI	: "+dtccCREDITNonPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");


        /*** DTCC_COMMODITY_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_COMMODITY_PRIORITY_P 			= (String) routingRulesMap.get(routingRule_COMM_RT_P);
        String dtccCOMMODITYPriorityEndPoint 		= (String) mqSenderMap.get(DTCC_COMMODITY_PRIORITY_P);
        String dtccCOMMODITYPriorityDelivery 		= (String) fpmlDeliveryMap.get(DTCC_COMMODITY_PRIORITY_P);
        String dtccCOMMODITYPriorityEndPointURI 	= (String) mqListenerMap.get(dtccCOMMODITYPriorityEndPoint);

        System.out.println("DTCC_COMMODITY_PRIORITY 		: "+DTCC_COMMODITY_PRIORITY_P);
        System.out.println("dtccCOMMODITYPriorityEndPoint 		: "+dtccCOMMODITYPriorityEndPoint);
        System.out.println("dtccCOMMODITYPriorityDelivery 		: "+dtccCOMMODITYPriorityDelivery);
        System.out.println("dtccCOMMODITYPriorityEndPointURI	: "+dtccCOMMODITYPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");
        
        /*** DTCC_COMMODITY_NON_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_COMMODITY_NON_PRIORITY			= (String) routingRulesMap.get(routingRule_COMM_SNAPSHOT_NP);
        String dtccCOMMODITYNonPriorityEndPoint 		= (String) mqSenderMap.get(DTCC_COMMODITY_NON_PRIORITY);
        String dtccCOMMODITYNonPriorityDelivery 		= (String) fpmlDeliveryMap.get(DTCC_COMMODITY_NON_PRIORITY);
        String dtccCOMMODITYNonPriorityEndPointURI 	= (String) mqListenerMap.get(dtccCOMMODITYNonPriorityEndPoint);

        System.out.println("DTCC_COMMODITY_PRIORITY 		: "+DTCC_COMMODITY_NON_PRIORITY);
        System.out.println("dtccCOMMODITYNonPriorityEndPoint	: "+dtccCOMMODITYNonPriorityEndPoint);
        System.out.println("dtccCOMMODITYNonPriorityDelivery	: "+dtccCOMMODITYNonPriorityDelivery);
        System.out.println("dtccCOMMODITYNonPriorityEndPointURI	: "+dtccCOMMODITYNonPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");

        
        /*** DTCC_EQUITY_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_EQUITY_PRIORITY_P 			= (String) routingRulesMap.get(routingRule_EQUITY_RT_P);
        String dtccEQUITYPriorityEndPoint 		= (String) mqSenderMap.get(DTCC_EQUITY_PRIORITY_P);
        String dtccEQUITYPriorityDelivery 		= (String) fpmlDeliveryMap.get(DTCC_EQUITY_PRIORITY_P);
        String dtccEQUITYPriorityEndPointURI 	= (String) mqListenerMap.get(dtccEQUITYPriorityEndPoint);

        System.out.println("DTCC_EQUITY_PRIORITY 			: "+DTCC_EQUITY_PRIORITY_P);
        System.out.println("dtccEQUITYPriorityEndPoint 		: "+dtccEQUITYPriorityEndPoint);
        System.out.println("dtccEQUITYPriorityDelivery 		: "+dtccEQUITYPriorityDelivery);
        System.out.println("dtccEQUITYPriorityEndPointURI		: "+dtccEQUITYPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");
        
        /*** DTCC_EQUITY_NON_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_EQUITY_NON_PRIORITY			= (String) routingRulesMap.get(routingRule_EQUITY_SNAPSHOT_NP);
        String dtccEQUITYNonPriorityEndPoint 	= (String) mqSenderMap.get(DTCC_EQUITY_NON_PRIORITY);
        String dtccEQUITYNonPriorityDelivery 	= (String) fpmlDeliveryMap.get(DTCC_EQUITY_NON_PRIORITY);
        String dtccEQUITYNonPriorityEndPointURI = (String) mqListenerMap.get(dtccEQUITYNonPriorityEndPoint);

        System.out.println("DTCC_EQUITY_PRIORITY 			: "+DTCC_EQUITY_NON_PRIORITY);
        System.out.println("dtccEQUITYNonPriorityEndPoint		: "+dtccEQUITYNonPriorityEndPoint);
        System.out.println("dtccEQUITYNonPriorityDelivery		: "+dtccEQUITYNonPriorityDelivery);
        System.out.println("dtccEQUITYNonPriorityEndPointURI	: "+dtccEQUITYNonPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");

        
        /*** DTCC_FX_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_FX_PRIORITY_P 			= (String) routingRulesMap.get(routingRule_FX_RT_P);
        String dtccFXPriorityEndPoint 		= (String) mqSenderMap.get(DTCC_FX_PRIORITY_P);
        String dtccFXPriorityDelivery 		= (String) fpmlDeliveryMap.get(DTCC_FX_PRIORITY_P);
        String dtccFXPriorityEndPointURI 	= (String) mqListenerMap.get(dtccFXPriorityEndPoint);

        System.out.println("DTCC_FX_PRIORITY 			: "+DTCC_FX_PRIORITY_P);
        System.out.println("dtccFXPriorityEndPoint 			: "+dtccFXPriorityEndPoint);
        System.out.println("dtccFXPriorityDelivery 			: "+dtccFXPriorityDelivery);
        System.out.println("dtccFXPriorityEndPointURI		: "+dtccFXPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");
        
        /*** DTCC_FX_NON_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_FX_NON_PRIORITY			= (String) routingRulesMap.get(routingRule_FX_SNAPSHOT_NP);
        String dtccFXNonPriorityEndPoint 	= (String) mqSenderMap.get(DTCC_FX_NON_PRIORITY);
        String dtccFXNonPriorityDelivery 	= (String) fpmlDeliveryMap.get(DTCC_FX_NON_PRIORITY);
        String dtccFXNonPriorityEndPointURI = (String) mqListenerMap.get(dtccFXNonPriorityEndPoint);

        System.out.println("DTCC_FX_PRIORITY 			: "+DTCC_FX_NON_PRIORITY);
        System.out.println("dtccFXNonPriorityEndPoint		: "+dtccFXNonPriorityEndPoint);
        System.out.println("dtccFXNonPriorityDelivery		: "+dtccFXNonPriorityDelivery);
        System.out.println("dtccFXNonPriorityEndPointURI		: "+dtccFXNonPriorityEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");

        /*** DTCC_FX_NON_PRIORITY ***/
        System.out.println("---------------------------------------------------------------------------------------------");
        String DTCC_FX_DOCUMENT			= (String) routingRulesMap.get(routingRule_FX_DOCUMENT_P);
        String dtccFXDocumentEndPoint 	= (String) mqSenderMap.get(DTCC_FX_DOCUMENT);
        String dtccFXDocumentDelivery 	= (String) fpmlDeliveryMap.get(DTCC_FX_DOCUMENT);
        String dtccFXDocumentEndPointURI = (String) mqListenerMap.get(dtccFXDocumentEndPoint);

        System.out.println("DTCC_FX_PRIORITY 			: "+DTCC_FX_DOCUMENT);
        System.out.println("dtccFXDocumentEndPoint			: "+dtccFXDocumentEndPoint);
        System.out.println("dtccFXDocumentDelivery			: "+dtccFXDocumentDelivery);
        System.out.println("dtccFXDocumentEndPointURI		: "+dtccFXDocumentEndPointURI);
        System.out.println("---------------------------------------------------------------------------------------------\n");

        
    }
}
