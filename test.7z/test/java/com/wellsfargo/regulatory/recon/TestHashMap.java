package com.wellsfargo.regulatory.recon;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class TestHashMap
{

	public static void main(String[] args)
	{
		
		Map mymap = new LinkedHashMap<>();
		mymap.put("1","one");
		mymap.put("1","not one");
		mymap.put("1","surely not one");
		//the following line is case 2 for duplicate
		//mymap.put("1","one");  
		System.out.println(mymap.get("1"));
	}

}
