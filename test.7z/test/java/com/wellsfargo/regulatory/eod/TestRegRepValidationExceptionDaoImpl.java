package com.wellsfargo.regulatory.eod;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.eod.dto.RegRepValidationException;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepValidationExceptionDaoImpl;

public class TestRegRepValidationExceptionDaoImpl
{

	private static final Logger logger = Logger.getLogger(TestRegRepEodJobDetailsDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling RegRepValidationExceptionDaoImpl");

		RegRepValidationExceptionDaoImpl regRepValidationExceptionDaoImpl = applicationContext.getBean("regRepValidationExceptionDaoImpl", RegRepValidationExceptionDaoImpl.class);
		try
		{
			RegRepValidationException currRegRepValidationException = new RegRepValidationException();
			currRegRepValidationException.setMessageId("messageId234");
			currRegRepValidationException.setTradeid("trade234");
			currRegRepValidationException.setExceptionCode("excepcode234");
			currRegRepValidationException.setExceptionType("excepType234");
			currRegRepValidationException.setComments("comments234");
			regRepValidationExceptionDaoImpl.insert(currRegRepValidationException);
			
			logger.info("inserted record into Validation Exception table");
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
