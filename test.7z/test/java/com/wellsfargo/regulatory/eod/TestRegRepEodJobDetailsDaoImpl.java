package com.wellsfargo.regulatory.eod;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;

public class TestRegRepEodJobDetailsDaoImpl
{

	private static final Logger logger = Logger.getLogger(TestRegRepEodJobDetailsDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling RegRepEodJobDetailsDaoImpl");

		RegRepEodJobDetailsDaoImpl eodJobDetails = applicationContext.getBean("regRepEodJobDetailsDaoImpl", RegRepEodJobDetailsDaoImpl.class);
		try
		{
			RegRepEodJobDetails currRegRepEodJobDetails = eodJobDetails.findByJobName("externalValuationDataLoaderSvc", null, null, null);
			logger.info("Eod job details object from DB " + currRegRepEodJobDetails.toString());
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
