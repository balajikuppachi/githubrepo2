package com.wellsfargo.regulatory.eod;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.eod.services.EodSnapShotJobResposeHandlerSvc;

public class TestEodSnapShotJobResponseSvc
{

	private static final Logger logger = Logger.getLogger(TestEodSnapShotJobResponseSvc.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling EodSnapShotJobResponseSvc");

		//EodSnapShotJobResponseSvc eodSnapShotJobResponseSvc = applicationContext.getBean("eodSnapShotJobResponseSvc", EodSnapShotJobResponseSvc.class);
		EodSnapShotJobResposeHandlerSvc snapShotJobResposeHandlerSvc =  applicationContext.getBean("eodSnapShotJobResposeHandlerSvc", EodSnapShotJobResposeHandlerSvc.class);
		try
		{
			//snapShotJobResposeHandlerSvc.handleResponse();
			logger.info("Eod job details object from DB ");
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
