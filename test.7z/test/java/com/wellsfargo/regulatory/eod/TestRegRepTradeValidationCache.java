package com.wellsfargo.regulatory.eod;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.core.data.cache.RegRepTradeValidationCache;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;

public class TestRegRepTradeValidationCache
{

	private static final Logger logger = Logger.getLogger(TestRegRepTradeValidationCache.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling RegRepTradeValidationCache");

		RegRepTradeValidationCache regRepTradeValidationCache = applicationContext.getBean("regRepTradeValidationCache", RegRepTradeValidationCache.class);
		
		
		if(null != regRepTradeValidationCache)
		{
			regRepTradeValidationCache.loadTradeValidationToCache();
			String tradeId = "trade123";
			
			RegRepTradeValidation currRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);
			logger.info("Value from cache  " + currRegRepTradeValidation.toString());
			
			currRegRepTradeValidation.setTradeid("trade123");
			currRegRepTradeValidation.setLifecycleEventType("Amend");
			
			regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);
			RegRepTradeValidation updatedRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);	
			
			
		
		}
		try
		{
			// snapShotJobResposeHandlerSvc.handleResponse();
			logger.info("Eod job details object from DB ");
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
