package com.wellsfargo.regulatory.eod;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobExecutionDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobExecutionDetails;

public class TestRegRepEodJobExecutionDetailsDaoImpl
{

	private static final Logger logger = Logger.getLogger(TestRegRepEodJobExecutionDetailsDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling RegRepEodJobDetailsDaoImpl");

		RegRepEodJobExecutionDetailsDaoImpl eodJobExecDetails = applicationContext.getBean("regRepEodJobExecutionDetailsDaoImpl", RegRepEodJobExecutionDetailsDaoImpl.class);
		RegRepEodJobExecutionDetails currJobExecDtls = new RegRepEodJobExecutionDetails();
		currJobExecDtls.setJobDetailsId(1);
		Date asOfDate = new Date();
		java.sql.Date date = new java.sql.Date(asOfDate.getTime());
		//Date createDate = new Date();
		currJobExecDtls.setAsOfDate(date);
		currJobExecDtls.setJobStatus("success");
		currJobExecDtls.setRecordsTotal(1000);
		currJobExecDtls.setRecordsLoaded(1000);		

		try
		{
			//eodJobExecDetails.insert(currJobExecDtls);
		 long jobExecId = 	eodJobExecDetails.insertandGetId(currJobExecDtls);
			logger.info("inserted data into JobDetails table with Id  " + jobExecId);
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
