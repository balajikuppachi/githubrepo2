package com.wellsfargo.regulatory.etd.parser;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.etd.bo.dtcc.ETDDtccTemplate;
import com.wellsfargo.regulatory.etd.services.parsers.ETDDtccTemplateParser;

public class TestEtdDtccTemplateParser
{
	private static final Logger logger = Logger.getLogger(TestEtdDtccTemplateParser.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";
	
	public static void main(String args[])
	{
		System.out.println("before calling parser");
		
	
		ETDDtccTemplate currObj = new ETDDtccTemplate();
		currObj.setAction("New");
		currObj.setClearingBrokerParty1Value("123");
		currObj.setClearingDCOPrefix("lei");
		currObj.setFixedrateofleg2("fixedLeg");
		currObj.setPrimaryAssetClass("Rates");
		currObj.setUTIValue("uti");
		currObj.setVersion("12");
		currObj.setTBD10("10");
		currObj.setTBD20("20");
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		
		ETDDtccTemplateParser currParser = (ETDDtccTemplateParser) applicationContext.getBean("eTDDtccTemplateParser");
		
		String response = null;
		try
        {
			response =   currParser.marshallToDtccTemplateString(currObj);
			System.out.println("response " + response);
        }
        catch (Exception e)
        {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
        }
		
		
	}


}
