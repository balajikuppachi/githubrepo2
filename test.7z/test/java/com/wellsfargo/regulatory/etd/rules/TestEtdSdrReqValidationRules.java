package com.wellsfargo.regulatory.etd.rules;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CommodityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DocumentationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.InstrumentIdEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PriceTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType.UnderlyingAsset;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartiesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;



public class TestEtdSdrReqValidationRules {
	private static final Logger logger = Logger.getLogger(TestEtdSdrReqValidationRules.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args) {

		
	     ReportingContext currReportingContext =ReportingContext.getInstance();
			
			SdrRequest sdrRequest = new SdrRequest();
			TradeType  tradeType = new TradeType();
			TradeHeaderType  tradeHeaderType = new TradeHeaderType();
			
			tradeHeaderType.setStatus("CH_TOBE_VER");
			tradeHeaderType.setProcessingOrgLEI("LEI:12345");
			tradeHeaderType.setExecutionVenue("ExecutionVenue");
			tradeHeaderType.setAction("C");
			tradeHeaderType.setCounterpartyLEI("LEI:2138001YYBULX5SZ2H24");
			tradeHeaderType.setTradeId("5E11    C0");
			tradeHeaderType.setIsPosition(false);
			
			LifeCycleType cycleType = new LifeCycleType();
			
			cycleType.setEventType("Cancel");
			
			String eventDateString = "2014-01-17T23:59:59.000-05:00";
            try
            {
	            XMLGregorianCalendar eventDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(eventDateString);
	            //cycleType.setEventExecutionDateTime(eventDate);
            }
            catch (DatatypeConfigurationException e)
            {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }
            
            ClearingType clearingType = new ClearingType();
            clearingType.setClearedTrade(true);
            
            String clearingDateString = "2014-01-20T23:59:59.000-05:00";
            try
            {
	            XMLGregorianCalendar clearedDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(clearingDateString);
	            //clearingType.setClearedDateTime(clearedDate);
            }
            catch (DatatypeConfigurationException e)
            {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }
            
            cycleType.setClearing(clearingType);
			
			tradeHeaderType.setLifeCycle(cycleType);
			
			TradeDetailType tradeDetail = new TradeDetailType();
             ProductType product = new ProductType();
             product.setProductType("Futures");
             
             ProductKeysType productKey = new ProductKeysType();
             productKey.setUTI("103039933701W00000000000000000000009718417");
             product.setProductKeys(productKey);
             
             KeywordsType keywordsType = new KeywordsType();
             
             Keyword keyword1 = new Keyword();
             keyword1.setName("ProductID1");
             keyword1.setValue("E:CO");
             
             Keyword keyword2 = new Keyword();
             keyword2.setName("ProductID2");
             keyword2.setValue("E:FU");
             
             keywordsType.getKeyword().add(keyword1);
             keywordsType.getKeyword().add(keyword2);
             
             product.setKeywords(keywordsType);
             
             CommodityTermsType commodityTermsType= new CommodityTermsType();
             commodityTermsType.setCommodityType("EN");
             commodityTermsType.setCommodityTypeDetail("EL");
             commodityTermsType.setDeliveryPoint("1234567891234567");
             commodityTermsType.setInterconnectionPoint("12345678912345678912345678912345678912345678912345");
             commodityTermsType.setContractCapacity("1234567891234567891234567891234567891234567891234");
             
             String deliveryEndDateTimeString = "2014-01-17T23:59:59.000-05:00";
             try
             {
 	            XMLGregorianCalendar deliveryEndDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(deliveryEndDateTimeString);
 	            commodityTermsType.setDeliveryEndDateTime(deliveryEndDate);
             }
             catch (DatatypeConfigurationException e)
             {
 	            // TODO Auto-generated catch block
 	            e.printStackTrace();
             }
             
             String deliveryStartDateTimeString = "2014-01-16T23:59:59.000-05:00";
             try
             {
 	            XMLGregorianCalendar deliveryStartDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(deliveryStartDateTimeString);
 	            commodityTermsType.setDeliveryStartDateTime(deliveryStartDate);
             }
             catch (DatatypeConfigurationException e)
             {
 	            // TODO Auto-generated catch block
 	            e.printStackTrace();
             }
             
             product.setCommodityTerms(commodityTermsType);
             
             UnderlyingAsset underlyingAsset = new UnderlyingAsset();
             underlyingAsset.setAssetType(InstrumentIdEnum.BASKET);
             underlyingAsset.setAssetValue("Asset");
             
             product.setUnderlyingAsset(underlyingAsset);
             
         	//test data for notionalCurrencyValidationRule , legTypePriceValidationRule
            LegType leg = new LegType();
            leg.setNotionalCurrency("USD");
            leg.setSettlementCurrency("USD");
            leg.setPrice(new BigDecimal(10.00));
            leg.setNotional(new BigDecimal(10.00));
            leg.setQuantityUnit("10");
            leg.setSettlementType(SettlementTypeEnum.CASH);
            leg.setTotalQuantity(new BigDecimal("19009001.00"));
            leg.setPriceType(PriceTypeEnum.BASIS_POINTS);
            leg.setFixedRate(new BigDecimal("2.0"));
            leg.setDayCountFraction("Actual/365");
            leg.setPaymentFrequency("3M");
            leg.setFixedFloat(FixedFloatEnum.FIXED);
            leg.setResetFrequency("3M");
            leg.setCurrency("INR");
            
            String val = leg.getFixedFloat().value();
            System.out.println("Fixed or float ? "+ val);
            
            String settlementDateString = "2014-01-17T23:59:59.000-05:00";
            try
            {
	            XMLGregorianCalendar settlementDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(settlementDateString);
	            leg.setSettlementDate(settlementDate);
            }
            catch (DatatypeConfigurationException e)
            {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }
            
            String dateString = "2014-01-18T23:59:59.000-05:00";
            try
            {
	            XMLGregorianCalendar startDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(dateString);
	            XMLGregorianCalendar executionDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(dateString);
	            leg.setStartDate(startDate);
	            tradeHeaderType.setExecutionDateTime(executionDate);
            }
            catch (DatatypeConfigurationException e)
            {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }
            
            String endDateString = "2014-01-18T23:59:59.000-05:00";
            try
            {
	            XMLGregorianCalendar endDate =  DatatypeFactory.newInstance().newXMLGregorianCalendar(endDateString);
	            leg.setEndDate(endDate);
            }
            catch (DatatypeConfigurationException e)
            {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
            }
           
             product.getLeg().add(leg);
             tradeDetail.setProduct(product);
		
            DocumentationType documentationType = new DocumentationType();
             
            documentationType.setMasterAgreementType("asdf");
            documentationType.setMasterAgreementVersion("2090");
            
            tradeDetail.setDocumentation(documentationType);
             
			RegulatoryType currRegulatoryType = new RegulatoryType();
			
			KeywordsType currKeywordsType = new KeywordsType();
			  
			tradeType.setTradeHeader(tradeHeaderType);
			
			currRegulatoryType.setKeywords(currKeywordsType);
			tradeType.setRegulatory(currRegulatoryType);
			
			tradeType.setTradeDetail(tradeDetail);
			
			sdrRequest.setTrade(tradeType);
			sdrRequest.setAssetClass("InterestRate");
			currReportingContext.setSdrRequest(sdrRequest);
			
			// test data for part1TaxonomyValidationRule
			
			TradePartiesType tradeParties = new TradePartiesType();
			TradePartyType tradeParty   = new TradePartyType();
			tradeParty.setLEI("LEI:12345");	
			tradeParty.setEmirTaxonomy("T:1111");
			tradeParties.getParty().add(tradeParty);			
			tradeDetail.setTradeParties(tradeParties);
			
			//ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
			
			System.out.println("before calling rules engine");
			
			
			Date settlementDate = sdrRequest.getTrade().getTradeDetail().getProduct().getLeg().get(0).getSettlementDate().toGregorianCalendar().getTime();
			Date executionDate = sdrRequest.getTrade().getTradeHeader().getExecutionDateTime().toGregorianCalendar().getTime();
			
			if(settlementDate.compareTo(executionDate) >= 0)
			{
				System.out.println("settlementDate equal to or greater than executionDate");
			}else{
				System.out.println("settlementDate less than executionDate");
			}
			
			
			KieServices ks = KieServices.Factory.get();
			KieContainer kc = ks.getKieClasspathContainer();
			KieSession ksession = kc.newKieSession("etdReqValKsession");
			ksession.setGlobal("logger", logger);
			Agenda agenda = ksession.getAgenda();
			agenda.getAgendaGroup("etdTransactionAndPositionAgenda").setFocus();
			agenda.getAgendaGroup("etdcommonAgenda").setFocus();
			
			ksession.insert(currReportingContext);
			ksession.fireAllRules();
			ksession.dispose();
				System.out.println("after calling rules engine");     

				if (currReportingContext.getRulesResultsContext() != null)
				{
					List<ValidationResult> validationResultList = currReportingContext.getRulesResultsContext().getAlertValidationResultList();

					if (validationResultList != null)
					{
						for (ValidationResult currValidationResult : validationResultList)
						{
							System.out.println("Validation results are: " + currValidationResult.toString());
						}
					}
				}

	}
	
	public boolean isFixedFloatValueExists(List legTypeList)
	{
		boolean rateExists = false;
		LegType legType = null;
		for( Object currLegType : legTypeList)
		{
			if(null != currLegType && currLegType instanceof    LegType)
			{
				legType = (LegType) currLegType ;
				if(null != legType.getFixedRate())
				{
					rateExists = true;
					return rateExists;
					
				}
			
				
			}
			
		}
		
		return rateExists;
	}
	
}
