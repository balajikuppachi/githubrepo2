package com.wellsfargo.regulatory.etd.persister;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.etd.dao.EtdPayloadDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;

public class TestEtdPayLoadDao
{


	private static final Logger logger = Logger.getLogger(TestEtdPayLoadDao.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
        {
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
        }
        catch (IOException e1)
        {
	        // TODO Auto-generated catch block
	        e1.printStackTrace();
        }
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling etdPayloadDao");
		
		EtdPayloadDao curretdPayloadDao = applicationContext.getBean("etdPayloadDao", EtdPayloadDao.class);
		

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String datefromString = "2015-03-10";
		String dateToString = "2015-03-20";

		Date reportFromDate = null;
		Date reportToDate = null;
		try
		{
			reportFromDate = dateFormat.parse(datefromString);
			reportToDate =  dateFormat.parse(dateToString);
		}
		catch (ParseException e)
		{
			logger.error("Exception occurred while parsing reportDate " + e.getMessage());
		}
		
		List<EtdPayload>  etdPayloadList = curretdPayloadDao.getEtdPayLoadByCreateDate(reportFromDate, reportToDate);
		
		System.out.println("number of payload records received " + etdPayloadList.size());
		
	
	

	}



}
