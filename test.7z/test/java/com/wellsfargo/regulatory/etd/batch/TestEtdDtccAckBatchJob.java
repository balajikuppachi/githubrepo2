package com.wellsfargo.regulatory.etd.batch;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;

public class TestEtdDtccAckBatchJob
{
	private static final Logger logger = Logger.getLogger(TestEtdDtccAckBatchJob.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
        {
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
        }
        catch (IOException e1)
        {
	        // TODO Auto-generated catch block
	        e1.printStackTrace();
        }
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling batch job");
		

	    Job job = applicationContext.getBean("etdDtccAckBatchjob", Job.class);
	//	Job job = applicationContext.getBean("etdDtccAckBatchjob", Job.class);				

		JobLauncher jobLauncher = applicationContext.getBean("jobLauncher", JobLauncher.class);

		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();

		jobParametersBuilder.addString(EtdConstants.MESSAGETYPE, "Transaction");

		try
		{
			jobLauncher.run(job, jobParametersBuilder.toJobParameters());
		}
		catch (JobExecutionAlreadyRunningException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JobRestartException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JobInstanceAlreadyCompleteException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JobParametersInvalidException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
