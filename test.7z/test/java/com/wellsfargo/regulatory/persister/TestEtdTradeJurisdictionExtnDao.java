package com.wellsfargo.regulatory.persister;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionExtnDao;

public class TestEtdTradeJurisdictionExtnDao
{

	private static final Logger logger = Logger.getLogger(TestReconTimelinessDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		logger.info("before calling EtdTradeJurisdictionExtnDao");

		EtdTradeJurisdictionExtnDao etdTradeJurisdictionExtnDao = applicationContext.getBean("etdTradeJurisdictionExtnDao", EtdTradeJurisdictionExtnDao.class);

		int cntOfrec = 0;
		//String asOfDate = "2015-01-27";
		String asOfDate = "2015-05-19";
		String msgType = "Transaction";
		if (null != etdTradeJurisdictionExtnDao)
		{
			try
			{
				//cntOfrec = etdTradeJurisdictionExtnDao.getCntOfTransactionRecords(msgType, asOfDate);
				//cntOfrec = etdTradeJurisdictionExtnDao.getCntOfValuationRecords( asOfDate);
				cntOfrec = etdTradeJurisdictionExtnDao.getCntOfCollateralRecords( asOfDate);
			}
			catch (Exception ex)
			{
				logger.info("exception occurred while getting data for reconTimeliness: " + ExceptionUtils.getFullStackTrace(ex));

			}
		}

		logger.info("regrep Message list size " + cntOfrec);

	}

}
