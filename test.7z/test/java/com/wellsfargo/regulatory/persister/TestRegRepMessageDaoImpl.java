package com.wellsfargo.regulatory.persister;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;

public class TestRegRepMessageDaoImpl {

	private static final Logger logger = Logger
			.getLogger(TestRegRepMessageDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args) {
		try {
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling regRepMessageDao");

		RegRepMessageDao regRepMessageDao = applicationContext.getBean("regRepMessageDao", RegRepMessageDao.class);

		Date start = null;
		Date end = null;

		String startDateStr = "2015-04-01";
		String endDateStr = "2015-04-03";
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		try {
			start = dateFormat.parse(startDateStr);
			end = dateFormat.parse(endDateStr);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		List<String> assetClasses = new ArrayList<String>();
		List<String> jurisdictions = new ArrayList<String>();
		//assetClasses.add("ForeignExchange");
		jurisdictions.add("CFTC");

		List<RegRepMessage> regMessages = regRepMessageDao
				.find(regRepMessageDao.filter(start, end, assetClasses,	jurisdictions, true));
		
		for (RegRepMessage message : regMessages)
		{
			if(message.getRegRepResponse() != null)
			{
				RegRepResponse response = message.getRegRepResponse();
				System.out.println(response.getAcknowledgementTimestamp());
				if(response.getRegRepReport() != null)
				{
					message = response.getRegRepReport().getRegRepMessage();
					System.out.println(message.toString());
				}
				else
				{
					System.out.println("Regrep report is null ");
				}
			}
			else
			{
				System.out.println("Regrep response is null ");
			}
		}
		System.out.println("regrep Message list size " + regMessages.size());

	}

}
