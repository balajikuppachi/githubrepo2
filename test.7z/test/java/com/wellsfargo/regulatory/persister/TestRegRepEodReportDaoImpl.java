package com.wellsfargo.regulatory.persister;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodReportDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodReport;

public class TestRegRepEodReportDaoImpl
{

	private static final Logger logger = Logger.getLogger(TestRegRepEodReportDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling regRepMessageDao");

		RegRepMessageDao regRepMessageDao = applicationContext.getBean("regRepMessageDao", RegRepMessageDao.class);
		RegRepEodReportDaoImpl regRepEodReportDaoImpl = applicationContext.getBean("regRepEodReportDaoImpl", RegRepEodReportDaoImpl.class);

		RegRepEodReport regRepEodReport = new RegRepEodReport();
		regRepEodReportDaoImpl.insertRegRepEodReport(regRepEodReport);

	}

}
