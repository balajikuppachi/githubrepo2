/**
 * 
 */
package com.wellsfargo.regulatory.persister;

import java.io.IOException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;
import com.wellsfargo.regulatory.persister.helper.RegRepPayLoadSequence;

/**
 * @author u363026
 *
 */
public class TestRegRepPayLoadSequence 
{
    protected static ApplicationContext applicationContext 			= null;    
    public static final String INIT_CONFIGURATION_FILE 				= "classpath:META-INF/spring/applicationContext.xml";
    
	public static void main(String[] args) throws IOException 
	{
    	try
    	{
	        applicationContext = new ClassPathXmlApplicationContext(INIT_CONFIGURATION_FILE);
	        RegulatoryBeanFactory.setContext(applicationContext);
	        
	        RegRepPayLoadSequence regRepPayLoadSequence =  (RegRepPayLoadSequence)RegulatoryBeanFactory.getBean("regRepPayLoadSequence");
	        for(int i=0; i < 10; i++)
	        {
	        	System.out.println("@@@@@@ RegRepPayLoadSequence.getNextId() - "+i+" : "+regRepPayLoadSequence.getNextId());
	        }
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		throw new IOException("##### Exception encountered bootstrapping : "+e);
    	}
    	finally
    	{
    		System.exit(0);
    	}
	}

}
