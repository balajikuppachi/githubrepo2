package com.wellsfargo.regulatory.persister;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.persister.dao.RegRepPayloadDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPayload;

public class TestRegRepPayload
{

	private static final Logger logger = Logger.getLogger(TestRegRepPayload.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
        {
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
        }
        catch (IOException e1)
        {
	        // TODO Auto-generated catch block
	        e1.printStackTrace();
        }
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		System.out.println("before calling regRepPayloadDao");
		
		RegRepPayloadDao regRepPayloadDao = applicationContext.getBean("regRepPayloadDao", RegRepPayloadDao.class);
		RegRepPayload currRegRepPayload = regRepPayloadDao.findPayloadByRegRepMessageId("C4C8B715-1840-E683-79CD-652EB05BCAF8");
		System.out.println("payload " + currRegRepPayload.getPayload());
		
	
	

	}

}
