package com.wellsfargo.regulatory.persister;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.exceptions.ReconException;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;
import com.wellsfargo.regulatory.persister.recon.dao.ReconTimelinessDao;
import com.wellsfargo.regulatory.persister.recon.dto.ReconTimelinessDomain;

public class TestReconTimelinessDaoImpl
{

	private static final Logger logger = Logger.getLogger(TestReconTimelinessDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		catch (IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		logger.info("before calling reconTimelinessDao");

		ReconTimelinessDao reconTimelinessDao = applicationContext.getBean("reconTimelinessDao", ReconTimelinessDao.class);

		List<ReconTimelinessDomain> reconTimelinessDomainList = null;
		if (null != reconTimelinessDao)
		{
			try
			{
				reconTimelinessDomainList = reconTimelinessDao.findAll();
			}
			catch (ReconException ex)
			{
				logger.info("exception occurred while getting data for reconTimeliness: " + ExceptionUtils.getFullStackTrace(ex));

			}
		}

		for (ReconTimelinessDomain currReconTimelinessDomain : reconTimelinessDomainList)
		{
			logger.info("current record is : " + currReconTimelinessDomain.toString());
		}
		logger.info("regrep Message list size " + reconTimelinessDomainList.size());

	}

}
