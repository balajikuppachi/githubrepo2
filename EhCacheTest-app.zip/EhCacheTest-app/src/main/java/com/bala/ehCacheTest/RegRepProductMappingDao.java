package com.bala.ehCacheTest;


import java.util.List;

import com.bala.ehCacheTest.RegRepProductMapping;

public interface RegRepProductMappingDao {
	
	public List<RegRepProductMapping> findAll();

}
