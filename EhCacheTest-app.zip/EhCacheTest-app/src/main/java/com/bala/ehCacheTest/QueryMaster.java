package com.bala.ehCacheTest;



/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class QueryMaster
{

	// public static @Value("${regRep.query.REG_REP_MESSAGE_PAYLOAD.get}") String RAW_MESSAGE;
	// public static @Value("${regRep.query.REG_REP_MESSAGE.get}") String PARSED_MESSAGE;
	// public static @Value("${regRep.query.DRL_CONFIG.insert}") String INSERT_CONFIG;
	// public static @Value("${regRep.query.DRL_CONFIG.get}") String GET_ALL_CONFIG;
	// public static @Value("${regRep.query.MESSAGE_STATUS_LOG.insert}") String
	// INSERT_MESSAGE_STATUS;
	// public static @Value("${regRep.query.REG_REP_EXCEPTIONS.insert}") String
	// INSERT_REG_REP_EXCEPTION;

	public static final String RAW_MESSAGE = "select * from message_payload where sdr_message_id = ?";

	public static final String PARSED_MESSAGE = "select * from message where sdr_message_id = ?";

	public static final String INSERT_CONFIG = "INSERT INTO DRL_CONFIG (ID, DRL_KEY, REPORTING_JURISDICTION, REPOSITORY, DRL_TYPE, FILE_LOCATION) values(?,?,?,?,?,?)";

	public static final String GET_ALL_CONFIG = "SELECT * FROM REG_REP_RULES_CONFIG";

	public static final String INSERT_MESSAGE_STATUS = "INSERT INTO MESSAGE_STATUS_LOG (SDR_MESSAGE_ID, CHANNEL_TIMESTAMP, CHANNEL_NAME, REFERENCE_QUERY) values(?,?,?,?)";

	public static final String INSERT_REG_REP_EXCEPTION = "INSERT INTO REG_REP_EXCEPTION ( REG_REP_EXCEPTION_ID, SDR_MESSAGE_ID, EXCEPTION_CODE, EXCEPTION_DESCRIPTION, EXCEPTION_STATUS, EXCEPTION_TIMESTAMP, "
	        + "EXCEPTION_TYPE, EXCEPTION_SEVERITY) values(?,?,?,?,?,?,?)";

	public static final String GET_ALL_COMPLIANCE_MATRIX = "SELECT * FROM REG_REP_COMPLIANCE_MATRIX";

	public static final String GET_ALL_DOMAIN_MAPPING = "SELECT * FROM REG_REP_DOMAIN_MAPPING";

	public static final String GET_ALL_PRODUCT_MAPPING = "SELECT * FROM REG_REP_PRODUCT_MAPPING";

	public static final String GET_ALL_DUP_CHECK_MAPPING = "SELECT * FROM REG_REP_DUP_CHECK_MAPPING";

	public static final String GET_ALL_REG_REP_EVENT_HIERARCHY = "SELECT * FROM REG_REP_EVENT_HIERARCHY";

}
