package com.bala.ehCacheTest;

import org.apache.log4j.Logger;


import com.bala.ehCacheTest.ProductMappingCache;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class InstantiationHelper
{
	private static Logger logger = Logger.getLogger(InstantiationHelper.class.getName());

	public static void loadCache()
	{
		/*// This should instantiate the rules cache
		DRLCache.getInstance();
		logger.info("***** Successfully instantiated Rules cache");

		// This should instantiate the compliance cache
		ComplianceCache.getInstance();
		logger.info("***** Successfully instantiated Compliance cache");

		// This should instantiate the Domain Mapping cache
		DomainMappingCache.getInstance();
		logger.info("***** Successfully instantiated Domain Mapping cache");*/

		// This should instantiate the Product Mapping cache
		ProductMappingCache.getInstance();
		logger.info("***** Successfully instantiated Product Mapping cache");
		
		/*// This should instantiate the Product Mapping cache
		IgnoreXpathCache.getInstance();
		logger.info("***** Successfully instantiated Duplicate Check Xpath cache");
*/
		logger.info("***** Successfully instantiated all cache objects");
	}
}
