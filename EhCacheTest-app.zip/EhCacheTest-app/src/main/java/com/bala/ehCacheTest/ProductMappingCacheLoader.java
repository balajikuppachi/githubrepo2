package com.bala.ehCacheTest;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bala.ehCacheTest.ProductMappingCache;
import com.bala.ehCacheTest.RegRepProductMapping;
import com.bala.ehCacheTest.RegRepProductMappingDao;
import com.bala.ehCacheTest.Constants;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */
@Component
public class ProductMappingCacheLoader
{
	@Autowired
	private static RegRepProductMappingDao productMapDao;
	
	private static Logger logger = Logger.getLogger(ProductMappingCacheLoader.class.getName());

	public void setdRLConfigDao(RegRepProductMappingDao productMapDao)
	{
		ProductMappingCacheLoader.productMapDao = productMapDao;
	}

	public static void loadProductMappingCache(ProductMappingCache prdCache)
	{
		logger.debug("Entering loadProductMappingCache() method");

		String key 					= null;
		List<String> values 		= null;
		StringBuilder keyBuilder 	= null;

		List<RegRepProductMapping> configList = productMapDao.findAll();

		for (RegRepProductMapping config : configList)
		{
			keyBuilder = new StringBuilder();

			keyBuilder.append(StringUtils.strip(config.getSrcAssetClass()));
			keyBuilder.append(Constants.UNDERSCORE);
			keyBuilder.append(StringUtils.strip(config.getSrcPrdType()));
			keyBuilder.append(Constants.UNDERSCORE);
			keyBuilder.append(StringUtils.strip(config.getSrcSubPrdType()));
			keyBuilder.append(Constants.UNDERSCORE);
			keyBuilder.append(StringUtils.strip(config.getMappingType()));
			
			
			
			values = new ArrayList<String>(5);

			values.add(config.getDtccAssetClass());
			values.add(config.getDtccPrdType());
			values.add(config.getDtccSubPrdType());
			values.add(config.getJurisdiction());
			values.add(config.getFpmlProductType());

			key = keyBuilder.toString();

			logger.info("key : " + key);
			prdCache.setValue(key, values);
		}

		logger.debug("Successfully instantiated Product Mapping cache.");
	}

}
