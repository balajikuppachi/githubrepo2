package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * @author Raji Komatreddy
 * The persistent class for the REG_REP_PR_CID database table.
 * 
 */
@Entity
@Table(name="REG_REP_PR_CID")
public class RegRepPrCid extends RegRepPrJob {	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="cid_id")
	private Long cidId;

	private String addressLine1;

	private String addressLine2;

	@Temporal(TemporalType.DATE)
	@Column(name="as_of_date")
	private Date asOfDate;

	@Column(name="bus_a_extl_key_c")
	private String busAExtlKeyC;

	@Column(name="bus_a_extl_n")
	private String busAExtlN;

	@Column(name="bus_a_id_c")
	private int busAIdC;

	@Column(name="bus_a_n")
	private String busAN;

	private String city;

	private String country;

	@Column(name="create_datetime")
	private Date createDatetime;

	private String deliveryPortfolioDataEmail;
	
	@Column(name="emailaddress")
	private String emailaddress;
	
	private String df_ETEU_EndUserType;

	private String etMSP_commodities;

	private String etMSP_creditderivatives;

	private String etMSP_equityderivatives;

	private String etMSP_FX;

	private String etMSP_rates;

	private String etSBMSP_commodities;

	private String etSBMSP_creditderivatives;

	private String etSBMSP_equityderivatives;

	private String etSBMSP_FX;

	private String etSBMSP_rates;

	private String etSBSD_commodities;

	private String etSBSD_creditderivatives;

	private String etSBSD_equityderivatives;

	private String etSBSD_FX;

	private String etSBSD_rates;

	private String etSD_commodities;

	private String etSD_creditderivatives;

	private String etSD_equityderivatives;

	private String etSD_FX;

	private String etSD_rates;

	private String isdaPortfolioRecon;

	private String isdaRiskValuation;	

	@Column(name="lei")
	private String lei;

	@Column(name="lgle_full_n")
	private String lgleFullN;

	@Column(name="lgle_id_c")
	private int lgleIdC;

	@Column(name="lgle_type_c")
	private String lgleTypeC;

	private String portfolioDataMethod;

	private String qualifier;

	private String reconSDRData;

	private String regEntityEndUser;

	private String regEntityMajorSwap;

	private String regEntitySecBasedMajorSwap;

	private String regEntitySecBasedSwapDealer;

	private String regEntitySwapDealer;

	private String relationshipType;

	private String state;

	@Column(name="system_c")
	private String systemC;

	private String zipCode;
	
	/*@Column(name="dom_intl")
	private String domIntl;*/
	
	@Column(name="isAccountJointAndSeveral")
	private String jsFlag;
	
	private String contactName;
	
	public RegRepPrCid() {
	}

	public long getCidId() {
		return this.cidId;
	}

	public void setCidId(long cidId) {
		this.cidId = cidId;
	}

	public String getAddressLine1() {
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public Date getAsOfDate() {
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}

	public String getBusAExtlKeyC() {
		return this.busAExtlKeyC;
	}

	public void setBusAExtlKeyC(String busAExtlKeyC) {
		this.busAExtlKeyC = busAExtlKeyC;
	}

	public String getBusAExtlN() {
		return this.busAExtlN;
	}

	public void setBusAExtlN(String busAExtlN) {
		this.busAExtlN = busAExtlN;
	}

	public int getBusAIdC() {
		return this.busAIdC;
	}

	public void setBusAIdC(int busAIdC) {
		this.busAIdC = busAIdC;
	}

	public String getBusAN() {
		return this.busAN;
	}

	public void setBusAN(String busAN) {
		this.busAN = busAN;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Date getCreateDatetime() {
		return this.createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getDeliveryPortfolioDataEmail() {
		return this.deliveryPortfolioDataEmail;
	}

	public void setDeliveryPortfolioDataEmail(String deliveryPortfolioDataEmail) {
		this.deliveryPortfolioDataEmail = deliveryPortfolioDataEmail;
	}
	
	public String getEmailAddress() {
		return this.emailaddress;
	}

	public void setEmailAddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}
	
	public String getDf_ETEU_EndUserType() {
		return this.df_ETEU_EndUserType;
	}

	public void setDf_ETEU_EndUserType(String df_ETEU_EndUserType) {
		this.df_ETEU_EndUserType = df_ETEU_EndUserType;
	}

	public String getEtMSP_commodities() {
		return this.etMSP_commodities;
	}

	public void setEtMSP_commodities(String etMSP_commodities) {
		this.etMSP_commodities = etMSP_commodities;
	}

	public String getEtMSP_creditderivatives() {
		return this.etMSP_creditderivatives;
	}

	public void setEtMSP_creditderivatives(String etMSP_creditderivatives) {
		this.etMSP_creditderivatives = etMSP_creditderivatives;
	}

	public String getEtMSP_equityderivatives() {
		return this.etMSP_equityderivatives;
	}

	public void setEtMSP_equityderivatives(String etMSP_equityderivatives) {
		this.etMSP_equityderivatives = etMSP_equityderivatives;
	}

	public String getEtMSP_FX() {
		return this.etMSP_FX;
	}

	public void setEtMSP_FX(String etMSP_FX) {
		this.etMSP_FX = etMSP_FX;
	}

	public String getEtMSP_rates() {
		return this.etMSP_rates;
	}

	public void setEtMSP_rates(String etMSP_rates) {
		this.etMSP_rates = etMSP_rates;
	}

	public String getEtSBMSP_commodities() {
		return this.etSBMSP_commodities;
	}

	public void setEtSBMSP_commodities(String etSBMSP_commodities) {
		this.etSBMSP_commodities = etSBMSP_commodities;
	}

	public String getEtSBMSP_creditderivatives() {
		return this.etSBMSP_creditderivatives;
	}

	public void setEtSBMSP_creditderivatives(String etSBMSP_creditderivatives) {
		this.etSBMSP_creditderivatives = etSBMSP_creditderivatives;
	}

	public String getEtSBMSP_equityderivatives() {
		return this.etSBMSP_equityderivatives;
	}

	public void setEtSBMSP_equityderivatives(String etSBMSP_equityderivatives) {
		this.etSBMSP_equityderivatives = etSBMSP_equityderivatives;
	}

	public String getEtSBMSP_FX() {
		return this.etSBMSP_FX;
	}

	public void setEtSBMSP_FX(String etSBMSP_FX) {
		this.etSBMSP_FX = etSBMSP_FX;
	}

	public String getEtSBMSP_rates() {
		return this.etSBMSP_rates;
	}

	public void setEtSBMSP_rates(String etSBMSP_rates) {
		this.etSBMSP_rates = etSBMSP_rates;
	}

	public String getEtSBSD_commodities() {
		return this.etSBSD_commodities;
	}

	public void setEtSBSD_commodities(String etSBSD_commodities) {
		this.etSBSD_commodities = etSBSD_commodities;
	}

	public String getEtSBSD_creditderivatives() {
		return this.etSBSD_creditderivatives;
	}

	public void setEtSBSD_creditderivatives(String etSBSD_creditderivatives) {
		this.etSBSD_creditderivatives = etSBSD_creditderivatives;
	}

	public String getEtSBSD_equityderivatives() {
		return this.etSBSD_equityderivatives;
	}

	public void setEtSBSD_equityderivatives(String etSBSD_equityderivatives) {
		this.etSBSD_equityderivatives = etSBSD_equityderivatives;
	}

	public String getEtSBSD_FX() {
		return this.etSBSD_FX;
	}

	public void setEtSBSD_FX(String etSBSD_FX) {
		this.etSBSD_FX = etSBSD_FX;
	}

	public String getEtSBSD_rates() {
		return this.etSBSD_rates;
	}

	public void setEtSBSD_rates(String etSBSD_rates) {
		this.etSBSD_rates = etSBSD_rates;
	}

	public String getEtSD_commodities() {
		return this.etSD_commodities;
	}

	public void setEtSD_commodities(String etSD_commodities) {
		this.etSD_commodities = etSD_commodities;
	}

	public String getEtSD_creditderivatives() {
		return this.etSD_creditderivatives;
	}

	public void setEtSD_creditderivatives(String etSD_creditderivatives) {
		this.etSD_creditderivatives = etSD_creditderivatives;
	}

	public String getEtSD_equityderivatives() {
		return this.etSD_equityderivatives;
	}

	public void setEtSD_equityderivatives(String etSD_equityderivatives) {
		this.etSD_equityderivatives = etSD_equityderivatives;
	}

	public String getEtSD_FX() {
		return this.etSD_FX;
	}

	public void setEtSD_FX(String etSD_FX) {
		this.etSD_FX = etSD_FX;
	}

	public String getEtSD_rates() {
		return this.etSD_rates;
	}

	public void setEtSD_rates(String etSD_rates) {
		this.etSD_rates = etSD_rates;
	}

	public String getIsdaPortfolioRecon() {
		return this.isdaPortfolioRecon;
	}

	public void setIsdaPortfolioRecon(String isdaPortfolioRecon) {
		this.isdaPortfolioRecon = isdaPortfolioRecon;
	}

	public String getIsdaRiskValuation() {
		return this.isdaRiskValuation;
	}

	public void setIsdaRiskValuation(String isdaRiskValuation) {
		this.isdaRiskValuation = isdaRiskValuation;
	}


	public String getLei() {
		return this.lei;
	}

	public void setLei(String lei) {
		this.lei = lei;
	}

	public String getLgleFullN() {
		return this.lgleFullN;
	}

	public void setLgleFullN(String lgleFullN) {
		this.lgleFullN = lgleFullN;
	}

	public int getLgleIdC() {
		return this.lgleIdC;
	}

	public void setLgleIdC(int lgleIdC) {
		this.lgleIdC = lgleIdC;
	}

	public String getLgleTypeC() {
		return this.lgleTypeC;
	}

	public void setLgleTypeC(String lgleTypeC) {
		this.lgleTypeC = lgleTypeC;
	}

	public String getPortfolioDataMethod() {
		return this.portfolioDataMethod;
	}

	public void setPortfolioDataMethod(String portfolioDataMethod) {
		this.portfolioDataMethod = portfolioDataMethod;
	}

	public String getQualifier() {
		return this.qualifier;
	}

	public void setQualifier(String qualifier) {
		this.qualifier = qualifier;
	}

	public String getReconSDRData() {
		return this.reconSDRData;
	}

	public void setReconSDRData(String reconSDRData) {
		this.reconSDRData = reconSDRData;
	}

	public String getRegEntityEndUser() {
		return this.regEntityEndUser;
	}

	public void setRegEntityEndUser(String regEntityEndUser) {
		this.regEntityEndUser = regEntityEndUser;
	}

	public String getRegEntityMajorSwap() {
		return this.regEntityMajorSwap;
	}

	public void setRegEntityMajorSwap(String regEntityMajorSwap) {
		this.regEntityMajorSwap = regEntityMajorSwap;
	}

	public String getRegEntitySecBasedMajorSwap() {
		return this.regEntitySecBasedMajorSwap;
	}

	public void setRegEntitySecBasedMajorSwap(String regEntitySecBasedMajorSwap) {
		this.regEntitySecBasedMajorSwap = regEntitySecBasedMajorSwap;
	}

	public String getRegEntitySecBasedSwapDealer() {
		return this.regEntitySecBasedSwapDealer;
	}

	public void setRegEntitySecBasedSwapDealer(String regEntitySecBasedSwapDealer) {
		this.regEntitySecBasedSwapDealer = regEntitySecBasedSwapDealer;
	}

	public String getRegEntitySwapDealer() {
		return this.regEntitySwapDealer;
	}

	public void setRegEntitySwapDealer(String regEntitySwapDealer) {
		this.regEntitySwapDealer = regEntitySwapDealer;
	}

	public String getRelationshipType() {
		return this.relationshipType;
	}

	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getSystemC() {
		return this.systemC;
	}

	public void setSystemC(String systemC) {
		this.systemC = systemC;
	}

	public String getZipCode() {
		return this.zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/*public String getDomIntl()
	{
		return domIntl;
	}

	public void setDomIntl(String domIntl)
	{
		this.domIntl = domIntl;
	}*/

	public String getJsFlag()
	{
		return jsFlag;
	}

	public void setJsFlag(String jsFlag)
	{
		this.jsFlag = jsFlag;
	}
	

	public String getContactName()
	{
		return contactName;
	}

	public void setContactName(String contactName)
	{
		this.contactName = contactName;
	}

}