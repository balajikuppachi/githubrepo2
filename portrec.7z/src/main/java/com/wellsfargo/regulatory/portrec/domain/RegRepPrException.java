package com.wellsfargo.regulatory.portrec.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Raji Komatreddy 
 * The persistent class for the REG_REP_PR_EXCEPTION database table.
 */
@Entity
@Table(name = "REG_REP_PR_EXCEPTION")
public class RegRepPrException
{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="exception_id")
	private long exceptionId;

	@Column(name="create_datetime")
	private Date createDatetime;

	@Column(name="exception_desc")
	private String exceptionDesc;

	@Column(name="exception_source")
	private String exceptionSource;

	@Column(name="exception_trace")
	private String exceptionTrace;

	@Column(name="exception_type")
	private String exceptionType;

	@Column(name="job_execution_id")
	private long jobExecutionId;
	
	@Column(name = "cid_cpty_id")
	private Long cidCptyId;

	public RegRepPrException() {
	}

	public long getExceptionId() {
		return this.exceptionId;
	}

	public void setExceptionId(long exceptionId) {
		this.exceptionId = exceptionId;
	}

	public Date getCreateDatetime() {
		return this.createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getExceptionDesc() {
		return this.exceptionDesc;
	}

	public void setExceptionDesc(String exceptionDesc) {
		this.exceptionDesc = exceptionDesc;
	}

	public String getExceptionSource() {
		return this.exceptionSource;
	}

	public void setExceptionSource(String exceptionSource) {
		this.exceptionSource = exceptionSource;
	}

	public String getExceptionTrace() {
		return this.exceptionTrace;
	}

	public void setExceptionTrace(String exceptionTrace) {
		this.exceptionTrace = exceptionTrace;
	}

	public String getExceptionType() {
		return this.exceptionType;
	}

	public void setExceptionType(String exceptionType) {
		this.exceptionType = exceptionType;
	}

	public long getJobExecutionId() {
		return this.jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}

	public Long getCidCptyId() {
		return cidCptyId;
	}

	public void setCidCptyId(Long cidCptyId) {
		this.cidCptyId = cidCptyId;
	}
}