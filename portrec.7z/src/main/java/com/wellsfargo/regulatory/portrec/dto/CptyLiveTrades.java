package com.wellsfargo.regulatory.portrec.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Raji Komatreddy
 */
public class CptyLiveTrades
{
	private BigDecimal liveTradesId;
	private int cidCptyId;
	private String cptyType;
	private int portfolioSize;
	private int commSize;
	private int crSize;
	private int irSize;
	private int eqSize;
	private int fxSize;
	private int fxIntlSize;
	private String reconEligible;
	private String reportyingParty;
	private String reconCpty;
	private String reconComment;

	private long jobExecutionId;
	private Date asOfDate;
	private String assetClass;
	private int baId;
	private int legalId;
	private String party1Lei;
	private String party2Lei;
	private String tradeId;
	private int ultimateCptyId;
	private String usi;
	private String uti;	

	public BigDecimal getLiveTradesId()
	{
		return liveTradesId;
	}

	public void setLiveTradesId(BigDecimal liveTradesId)
	{
		this.liveTradesId = liveTradesId;
	}
	
	public int getCidCptyId()
	{
		return cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public String getCptyType()
	{
		return cptyType;
	}

	public void setCptyType(String cptyType)
	{
		this.cptyType = cptyType;
	}

	public int getPortfolioSize()
	{
		return portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public Date getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getAssetClass()
	{
		return assetClass;
	}

	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}

	public int getBaId()
	{
		return baId;
	}

	public void setBaId(int baId)
	{
		this.baId = baId;
	}

	public int getLegalId()
	{
		return legalId;
	}

	public void setLegalId(int legalId)
	{
		this.legalId = legalId;
	}

	public String getParty1Lei()
	{
		return party1Lei;
	}

	public void setParty1Lei(String party1Lei)
	{
		this.party1Lei = party1Lei;
	}

	public String getParty2Lei()
	{
		return party2Lei;
	}

	public void setParty2Lei(String party2Lei)
	{
		this.party2Lei = party2Lei;
	}

	public String getTradeId()
	{
		return tradeId;
	}

	public void setTradeId(String tradeId)
	{
		this.tradeId = tradeId;
	}

	public int getUltimateCptyId()
	{
		return ultimateCptyId;
	}

	public void setUltimateCptyId(int ultimateCptyId)
	{
		this.ultimateCptyId = ultimateCptyId;
	}

	public String getUsi()
	{
		return usi;
	}

	public void setUsi(String usi)
	{
		this.usi = usi;
	}

	public String getUti()
	{
		return uti;
	}

	public void setUti(String uti)
	{
		this.uti = uti;
	}

	public int getCommSize()
	{
		return commSize;
	}

	public void setCommSize(int commSize)
	{
		this.commSize = commSize;
	}

	public int getCrSize()
	{
		return crSize;
	}

	public void setCrSize(int crSize)
	{
		this.crSize = crSize;
	}

	public int getIrSize()
	{
		return irSize;
	}

	public void setIrSize(int irSize)
	{
		this.irSize = irSize;
	}

	public int getEqSize()
	{
		return eqSize;
	}

	public void setEqSize(int eqSize)
	{
		this.eqSize = eqSize;
	}

	public int getFxSize()
	{
		return fxSize;
	}

	public void setFxSize(int fxSize)
	{
		this.fxSize = fxSize;
	}

	public int getFxIntlSize()
	{
		return fxIntlSize;
	}

	public void setFxIntlSize(int fxIntlSize)
	{
		this.fxIntlSize = fxIntlSize;
	}

	public String getReconEligible()
	{
		return reconEligible;
	}

	public void setReconEligible(String reconEligible)
	{
		this.reconEligible = reconEligible;
	}

	public String getReportyingParty()
	{
		return reportyingParty;
	}

	public void setReportyingParty(String reportyingParty)
	{
		this.reportyingParty = reportyingParty;
	}

	public String getReconCpty()
	{
		return reconCpty;
	}

	public void setReconCpty(String reconCpty)
	{
		this.reconCpty = reconCpty;
	}

	public String getReconComment()
	{
		return reconComment;
	}

	public void setReconComment(String reconComment)
	{
		this.reconComment = reconComment;
	}

}
