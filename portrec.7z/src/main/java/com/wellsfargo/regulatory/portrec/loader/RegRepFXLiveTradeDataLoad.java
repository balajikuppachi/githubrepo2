package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.common.FxInternationalReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepFXLiveTradeDataLoad extends LoaderHelper<RegRepPrLiveTrade> {
	public static String PORTFOLIO_SEGMENT_NAME = "Live Trades, FX_INTL";
	@Value("${file.cid.inputFolder}") String cidDirectory;
	@Value("${portrec.create.file.cid}") String createFile;
		
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.FX_LIVE_TRADE;
	}

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new FxInternationalReader(inputStream);
	}

	@Override
	public RegRepPrLiveTrade parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrLiveTrade trades = new RegRepPrLiveTrade();
		
		trades.setTradeId(fields[0]);
		trades.setAssetClass("FX_INTL");
		trades.setParty1Lei(fields[1]);
		trades.setParty2Lei(fields[10]);
		
		trades.setBaId(convertStrtoInt(fields[51]));
				
		trades.setUsi(fields[0]);
		trades.setAsOfDate(asofDate);
	return trades;
	}

	@Override
	public boolean validate(RegRepPrLiveTrade trade) {
		boolean canLoad = true;
		return canLoad;
	}
	
	private int convertStrtoInt(String baid){
		baid.trim();
		int baID = 0;
			try {
				baID = Integer.parseInt(baid);
			}catch (Exception ex){
				ex.getMessage();}
		return baID;
	}

	@Override
	public RegRepPrLiveTrade getTableName() {
		return new RegRepPrLiveTrade();
	}

	@Override
	public boolean deletePrevDayRecords() {
		return true;
	}

	@Override
	public String loadNextJob() {
		String fileName = null;
		if(createFile.equalsIgnoreCase(PortrecConstants.TRUE)){
			Date date = new Date();
			DateFormat formatter ; 
			formatter = new SimpleDateFormat("yyyyMMdd");
			fileName = cidDirectory + "/cid-data." + formatter.format(date) + ".txt";
		}
		return fileName;	
	}

}
