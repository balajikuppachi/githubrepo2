package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.mailer.CptyMisMailerSmtpService;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrDaReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Service
public class PrPostRunReportWriter {

	private final Logger logger = Logger.getLogger(PrPreRunReportWriter.class);
	@Value("${file.mis.outputFolder}")
	String outputFolderName;
	protected String legalNameValue = null;
	protected String legalIdValue = null;
	protected String fileType = null;
	protected String fileName = null;
	protected String reconType = null;
	protected String reconDate = null;
	protected String assetClass=null;
	protected String affirmedFlag = null;
	protected String affirmedTime = null;
	protected String usercomment = null;
	protected String reconFreq = null;
	protected String jsFlag;
	protected Date todayDate = null;
	protected Date cobDate =null;
	protected String reconFreqHeading = null;
	long currJobExecutionId = 0;
	@Autowired
	RegRepPrDaReportRepository regRepPrDaReportRepository;

	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;
	@Autowired
	CalendarService calendarService;
	@Autowired
	CptyMisMailerSmtpService cptyMisMailerSmtpService;
 	
	public void misPostFileGeneration(Message<?> message) throws PortrecException {

		long timeStart = System.currentTimeMillis();
		logger.info("Start misPostReportGeneration - ");

		Object ipMessage = null;
		String errorString = null;
		Date reconDate = null;
		
		String jobAsOfDate = null;
		Date asOfDate = null;

		RegRepPrJobDetail currRegRepPrJobDetail = null;
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);

		if (null == message) {
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("misPostReportGeneration-1",
					ExceptionSeverityEnum.ERROR,
					ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		ipMessage = message.getPayload();
		if (null != message.getHeaders().get(
				PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE))
			jobAsOfDate = message.getHeaders()
					.get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)
					.toString();

		if (null != jobAsOfDate) {
			logger.info(" recon process running for asOfDate received from fileName "
					+ jobAsOfDate);
			try {
				asOfDate = reconDateFormat.parse(jobAsOfDate);
				if (null != asOfDate) {
					reconDate = asOfDate;
				} else {
					reconDate = new Date();
				}
			} catch (ParseException e) {
				logger.error("########## " + e.getMessage());
				// e.printStackTrace();
			}
		} else {
			reconDate = new Date();
		}

		if (ipMessage instanceof RegRepPrJobDetail) {
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail) {
			errorString = "Null incoming PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("misPostReportGeneration-2",
					ExceptionSeverityEnum.ERROR,
					ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		// tradeFile.setId(new BigDecimal(10000001));
		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(reconDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail
				.getJobName());
		regRepPrJobExecutionDetail
				.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository
				.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail) {
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("misPostReportGeneration-3",
					ExceptionSeverityEnum.ERROR,
					ExceptionTypeEnum.PORTREC_ERROR, errorString);

		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		logger.info("jobExecution id for current run of misPostReportGeneration "
				+ currJobExecutionId);

		
		
		String fileName = "CptyReconMailerProcess";
		String status = "success";
		RegRepPrJobExecutionDetail prevRegRepPrJobExecutionDetail= regRepPrJobExecutionDetailRepository.findPreviousJobExecutionDetail(fileName, status);
		long prevJobExecutionId  = prevRegRepPrJobExecutionDetail.getJobExecutionId();
		
		logger.info("jobExecution id for previous run Mailing Process " + prevJobExecutionId);
		
		try {
			todayDate = new SimpleDateFormat("yyyy-MM-dd").parse(PortRecUtil
					.convertDateToString_yyyy_MM_dd(new Date()));

			List<RegRepPrReconCalendar> reconCalList = regRepPrReconCalendarRepository
					.findByDate(todayDate);
			logger.info("Building post summary reports....");
			if(!reconCalList.isEmpty()){
			for (RegRepPrReconCalendar reconCalItem : reconCalList) {
				reconFreq = reconCalItem.getReconFreq();
				cobDate = reconCalItem.getAsOfDate();
			File prPostRunFolder = new File(outputFolderName);
			File prPostRunFile;
			if (prPostRunFolder.exists() && prPostRunFolder.isDirectory()) {
				// create preRun file here
				prPostRunFile = new File(prPostRunFolder + File.separator
						+ PortrecConstants.PR_POST_FILE_NAME
						+ PortrecConstants.UNDERSCORE+reconFreq.toLowerCase() + PortrecConstants.UNDERSCORE
						+ PortRecUtil.convertDateToString_Mmddyyyy(cobDate)+".xls");
			} else {
				prPostRunFolder.mkdirs();
				prPostRunFile = new File(prPostRunFolder + File.separator
						+ PortrecConstants.PR_POST_FILE_NAME+PortrecConstants.UNDERSCORE
						+ reconFreq.toLowerCase() + PortrecConstants.UNDERSCORE
						+ PortRecUtil.convertDateToString_Mmddyyyy(cobDate)+".xls");
			}
			generateCsvFile(prPostRunFile,prevRegRepPrJobExecutionDetail);
			String mailCobDate=cobDate.toString();
			cptyMisMailerSmtpService.sendEmail(mailCobDate,reconFreq,"Post Run");
			}
			logger.info("Folder where file created is " + outputFolderName);
		}
			else
			{
				logger.info("Post Report recon date doesn't match with Run date ");
			}
		}catch (Exception ex) {

			logger.error("Error in misPostReportGeneration Process : " + ex.getMessage());
			try {
				regRepPrJobExecutionDetail
						.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository
						.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				RegRepPrException regRepPrException = new RegRepPrException();
				regRepPrException.setExceptionSource("PrPostRunReportWriter");
				regRepPrException.setJobExecutionId(currJobExecutionId);
				regRepPrException.setExceptionDesc(errorString);
				regRepPrException
						.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR
								.toString());
				regRepPrException.setExceptionTrace(ExceptionUtils
						.getStackTrace(ex));
				regRepPrException.setCreateDatetime(new Date());
				portrecExceptionLogger.logExceptionToDB(regRepPrException);
				logger.error("Exception occurred inside misPostReportGeneration for jobId #"
						+ currJobExecutionId
						+ "exception message "
						+ errorString);
			} catch (Exception e) {
				logger.error("exception while logging exception to DB "
						+ ExceptionUtils.getStackTrace(e));
			}
		}

		regRepPrJobExecutionDetail
				.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository
				.save(regRepPrJobExecutionDetail);

		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in misPostReportGeneration Process : "
				+ PortRecUtil.printTimeTaken(timeEnd - timeStart));
	}
	private void prepareSummaryHeader(Workbook wb, Row row, short column,
			String displayText) {
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = wb.createCellStyle();

		Font xSSFFont = wb.createFont();
		xSSFFont.setFontName(HSSFFont.FONT_ARIAL);
		xSSFFont.setFontHeightInPoints((short) 12);
		xSSFFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		xSSFFont.setColor(HSSFColor.BLACK.index);
		cellStyle.setFont(xSSFFont);

		cell.setCellStyle(cellStyle);

	}

	private void generateCsvFile(File prPostRunFile,RegRepPrJobExecutionDetail prevRegRepPrJobExecutionDetail) throws ParseException {
		try {
			
			reconFreqHeading=calendarService.reconFrequency(cobDate, reconFreq);
			FileOutputStream fileOut = new FileOutputStream(prPostRunFile);
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet worksheet1 = workbook.createSheet("Summary");
			Sheet worksheet2 = workbook.createSheet("Details");
			currJobExecutionId = prevRegRepPrJobExecutionDetail.getJobExecutionId();
			Row row1 = worksheet1.createRow((short) 1);
			prepareSummaryHeader(workbook, row1, (short) 0,
					PortrecConstants.POST_REPORT_HEADING);
			if(null!=reconFreqHeading)
			prepareSummaryHeader(workbook, row1, (short) 1,
					reconFreqHeading);
			
			Row row2 = worksheet1.createRow((short) 2);
			prepareSummaryHeader(workbook, row2, (short) 1,
					PortrecConstants.DATA_COB
					+ PortrecConstants.SPACE
					+ PortRecUtil.convertDateToString_Mmddyy(cobDate));
			
			Row row3 = worksheet1.createRow((short) 4);
			prepareSummaryHeader(workbook, row3, (short) 0,
					PortrecConstants.CATEGORY);
			prepareSummaryHeader(workbook, row3, (short) 1,
					PortrecConstants.COUNT);

			Row row4 = worksheet1.createRow((short) 5);
			prepareSummaryHeader(workbook, row4, (short) 0,
					PortrecConstants.MATERIAL_TERMS);
			

			Row row5 = worksheet1.createRow((short) 6);
			Cell cellA7 = row5.createCell((short) 0);
			cellA7.setCellValue(PortrecConstants.FILES_ISSUED_TO_CP);
			Cell cellA8 = row5.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA8.setCellValue(regRepPrDaReportRepository
					.totalMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row6 = worksheet1.createRow((short) 7);
			Cell cellA9 = row6.createCell((short) 0);
			cellA9.setCellValue(PortrecConstants.AFFIRMED);
			Cell cellA10 = row6.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalAffirmMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA10.setCellValue(regRepPrDaReportRepository
					.totalAffirmMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row7 = worksheet1.createRow((short) 8);
			Cell cellA11 = row7.createCell((short) 0);
			cellA11.setCellValue(PortrecConstants.DISAFFIRMED);
			Cell cellA12 = row7.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalDisAffirmMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA12.setCellValue(regRepPrDaReportRepository
					.totalDisAffirmMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row8 = worksheet1.createRow((short) 9);
			Cell cellA13 = row8.createCell((short) 0);
			cellA13.setCellValue(PortrecConstants.NO_RESPONSE);
			Cell cellA14 = row8.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalNoResponseMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA14.setCellValue(regRepPrDaReportRepository
					.totalNoResponseMaterialTermFile(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row9 = worksheet1.createRow((short) 11);
			prepareSummaryHeader(workbook, row9, (short) 0,
					PortrecConstants.VALUATION);
			

			Row row10 = worksheet1.createRow((short) 12);
			Cell cellA17 = row10.createCell((short) 0);
			cellA17.setCellValue(PortrecConstants.FILES_ISSUED_TO_CP);
			Cell cellA18 = row10.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalValuationFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA18.setCellValue(regRepPrDaReportRepository
					.totalValuationFile(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row11 = worksheet1.createRow((short) 13);
			Cell cellA19 = row11.createCell((short) 0);
			cellA19.setCellValue(PortrecConstants.AFFIRMED);
			Cell cellA20 = row11.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalAffirmValuationFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA20.setCellValue(regRepPrDaReportRepository
					.totalAffirmValuationFile(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row12 = worksheet1.createRow((short) 14);
			Cell cellA21 = row12.createCell((short) 0);
			cellA21.setCellValue(PortrecConstants.DISAFFIRMED);
			Cell cellA22 = row12.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalDisAffirmValuationFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA22.setCellValue(regRepPrDaReportRepository
					.totalDisAffirmValuationFile(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row13 = worksheet1.createRow((short) 15);
			Cell cellA23 = row13.createCell((short) 0);
			cellA23.setCellValue(PortrecConstants.NO_RESPONSE);
			Cell cellA24 = row13.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalNoResponseValuationFile(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA24.setCellValue(regRepPrDaReportRepository
					.totalNoResponseValuationFile(reconFreq,prevRegRepPrJobExecutionDetail));

			

			Row row14 = worksheet2.createRow((short) 0);
			prepareSummaryHeader(workbook, row14, (short) 0,
					PortrecConstants.lEGAL_NAME);
			prepareSummaryHeader(workbook, row14, (short) 1,
					PortrecConstants.lEGAL_ID);
			prepareSummaryHeader(workbook, row14, (short) 2,
					PortrecConstants.ASSET_CLASS);
			prepareSummaryHeader(workbook, row14, (short) 3,
					PortrecConstants.FILE_NAME);
			prepareSummaryHeader(workbook, row14, (short) 4,
					PortrecConstants.RECON_TYPE);
			prepareSummaryHeader(workbook, row14, (short) 5,
					PortrecConstants.RECON_DATE);
			prepareSummaryHeader(workbook, row14, (short) 6,
					PortrecConstants.FILE_TYPE);
			prepareSummaryHeader(workbook, row14, (short) 7,
					PortrecConstants.JS_INDICATOR);
			prepareSummaryHeader(workbook, row14, (short) 8,
					PortrecConstants.AFFIRM);
			prepareSummaryHeader(workbook, row14, (short) 9,
					PortrecConstants.AFFIRM_WITH_TIMESTAMP);
			prepareSummaryHeader(workbook, row14, (short) 10,
					PortrecConstants.COMMENTS);
			
			

			List<Object[]> list = regRepPrDaReportRepository
					.postReportdetails(reconFreq,prevRegRepPrJobExecutionDetail);
			List <CptyMisPostDetails> postdetailslist=new ArrayList<CptyMisPostDetails>();
			
			for(Object[] Object: list)
			{
				CptyMisPostDetails cptyMisPostDetails = new CptyMisPostDetails();
				cptyMisPostDetails.setCidCptyId(null!=Object[0]?(Integer)Object[0]:null);
				cptyMisPostDetails.setFullLegalName(null!=Object[1]?String.valueOf(Object[1]):null);
				cptyMisPostDetails.setAssetClass(null!=Object[2]?String.valueOf(Object[2]):null);
				cptyMisPostDetails.setFileName(null!=Object[3]?String.valueOf(Object[3]):null);
				cptyMisPostDetails.setReconFreq(null!=Object[4]?String.valueOf(Object[4]):null);
				cptyMisPostDetails.setAsOfDate(null!=Object[5]?(Date)Object[5]:null);
				cptyMisPostDetails.setMtValType(null!=Object[6]?String.valueOf(Object[6]):null);
				cptyMisPostDetails.setJsFlag(null!=Object[7]?(Integer)Object[7]:null);
				cptyMisPostDetails.setAffirmedFlag(null!=Object[8]?String.valueOf(Object[8]):null);
				cptyMisPostDetails.setAffirmDatetime(null!=Object[9]?(Date)Object[9]:null);
				cptyMisPostDetails.setAffirmComments(null!=Object[10]?String.valueOf(Object[10]):null);
				postdetailslist.add(cptyMisPostDetails);
			}

			//int size = list.size();
			int noOfrows = 1;
			
			for(CptyMisPostDetails cptyMisPostDetails:postdetailslist){
				Row row = worksheet2.createRow((short) noOfrows);
				Cell cellA25 = row.createCell((short) 0);
				if (cptyMisPostDetails.getFullLegalName() != null) {
					legalNameValue = cptyMisPostDetails.getFullLegalName().toString();
				} else
					legalNameValue =PortrecConstants.EMPTY;
				cellA25.setCellValue(legalNameValue);

				Cell cellA26 = row.createCell((short) 1);
				if (cptyMisPostDetails.getCidCptyId() != null) {
					legalIdValue = cptyMisPostDetails.getCidCptyId().toString();
				} else
					legalIdValue = PortrecConstants.EMPTY;
				cellA26.setCellValue(legalIdValue);
				
				Cell cellA27 = row.createCell((short) 2);
				if (cptyMisPostDetails.getAssetClass() != null) {
					assetClass = cptyMisPostDetails.getAssetClass().toString();
				} else
					assetClass = PortrecConstants.EMPTY;
				cellA27.setCellValue(assetClass);

				Cell cellA28 = row.createCell((short) 3);
				if (cptyMisPostDetails.getFileName() != null) {
					fileName = cptyMisPostDetails.getFileName().toString();
				} else
					fileName =PortrecConstants.EMPTY;
				cellA28.setCellValue(fileName);
				Cell cellA29 = row.createCell((short) 4);
				if (cptyMisPostDetails.getReconFreq() != null) {
					reconType = cptyMisPostDetails.getReconFreq().toString();
				} else
					reconType = PortrecConstants.EMPTY;
				cellA29.setCellValue(reconType);
				Cell cellA30 = row.createCell((short) 5);
				if (cptyMisPostDetails.getAsOfDate()!= null) {
					reconDate = cptyMisPostDetails.getAsOfDate().toString();
				} else
					reconDate = PortrecConstants.EMPTY;
				cellA30.setCellValue(reconDate);
				
				Cell cellA31 = row.createCell((short) 6);
				if (cptyMisPostDetails.getMtValType() != null) {
					fileType = cptyMisPostDetails.getMtValType().toString();
				} else
					fileType = PortrecConstants.EMPTY;
				cellA31.setCellValue(fileType);
				
				Cell cellA32 = row.createCell((short) 7);
				if (cptyMisPostDetails.getJsFlag() != null
						&& cptyMisPostDetails.getJsFlag().toString()
								.equals("1")) {

					jsFlag = "Y";
				}

				else
					jsFlag = "N";
				cellA32.setCellValue(jsFlag);

				if (cptyMisPostDetails.getAffirmedFlag() != null) {
					affirmedFlag = cptyMisPostDetails.getAffirmedFlag().toString();
				} else
					affirmedFlag = PortrecConstants.EMPTY;
				Cell cellA33 = row.createCell((short) 8);
				cellA33.setCellValue(affirmedFlag);

				if (cptyMisPostDetails.getAffirmDatetime() != null) {
					affirmedTime = cptyMisPostDetails.getAffirmDatetime().toString();
				} else
					affirmedTime =PortrecConstants.EMPTY;
				Cell cellA34 = row.createCell((short) 9);
				cellA34.setCellValue(affirmedTime);

				if (cptyMisPostDetails.getAffirmComments() != null) {
					usercomment = cptyMisPostDetails.getAffirmComments().toString();
				} else
					usercomment = PortrecConstants.EMPTY;
				Cell cellA35 = row.createCell((short) 10);
				cellA35.setCellValue(usercomment);
				noOfrows++;
			}
			workbook.write(fileOut);
			workbook.dispose();
			fileOut.flush();
			fileOut.close();

		} catch (Exception e) {
			String errorMsg = "exception while generating post run mis file ";
			portrecExceptionLogger.logExceptionScenario("PrPostRunReportWriter",errorMsg, e, currJobExecutionId, null);
		}
	}

}
