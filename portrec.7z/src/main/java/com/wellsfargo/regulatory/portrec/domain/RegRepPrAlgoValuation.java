package com.wellsfargo.regulatory.portrec.domain;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy 
 * The persistent class for the REG_REP_PR_ALGO_VALUATION database table.
 */
@Entity
@Table(name = "REG_REP_PR_ALGO_VALUATION")
public class RegRepPrAlgoValuation extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "algo_valuation_id")
	private long algoValuationId;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "base_ccy")
	private String baseCcy;

	private String book;

	@Column(name = "buy_or_sell")
	private String buyOrSell;

	@Column(name = "collat_agreement_id")
	private String collatAgreementId;

	private String collateralized;

	@Column(name = "cpty_branch")
	private String cptyBranch;

	@Column(name = "cpty_trade_id")
	private String cptyTradeId;

	@Temporal(TemporalType.DATE)
	@Column(name = "effective_date")
	private Date effectiveDate;

	@Column(name = "ext_principal")
	private String extPrincipal;

	@Column(name = "full_name")
	private String fullName;

	private String imargin;

	@Column(name = "last_update_date_ts")
	private Date lastUpdateDateTs;

	@Column(name = "legal_id")
	private BigInteger legalId;

	@Temporal(TemporalType.DATE)
	@Column(name = "maturity_date")
	private Date maturityDate;

	private BigDecimal notional1;

	@Column(name = "notional1_ccy")
	private String notional1Ccy;

	private BigDecimal notional2;

	@Column(name = "notional2_ccy")
	private String notional2Ccy;

	@Column(name = "parent_legal_id")
	private String parentLegalId;

	@Column(name = "parent_legal_name")
	private String parentLegalName;

	@Column(name = "prod_type")
	private String prodType;

	@Column(name = "product_id")
	private String productId;

	@Column(name = "put_call")
	private String putCall;

	private String pv;

	@Column(name = "pv_base_ccy")
	private String pvBaseCcy;

	@Column(name = "pv_ccy")
	private String pvCcy;

	@Temporal(TemporalType.DATE)
	@Column(name = "pv_cob_date")
	private Date pvCobDate;

	@Column(name = "source_system")
	private String sourceSystem;

	@Column(name = "strike_price")
	private String strikePrice;

	@Temporal(TemporalType.DATE)
	@Column(name = "trade_date")
	private Date tradeDate;

	@Column(name = "trade_id")
	private String tradeId;

	private String trader;

	@Column(name = "underlying_name")
	private String underlyingName;

	public RegRepPrAlgoValuation()
	{
	}

	public long getAlgoValuationId()
	{
		return this.algoValuationId;
	}

	public void setAlgoValuationId(long algoValuationId)
	{
		this.algoValuationId = algoValuationId;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getBaseCcy()
	{
		return this.baseCcy;
	}

	public void setBaseCcy(String baseCcy)
	{
		this.baseCcy = baseCcy;
	}

	public String getBook()
	{
		return this.book;
	}

	public void setBook(String book)
	{
		this.book = book;
	}

	public String getBuyOrSell()
	{
		return this.buyOrSell;
	}

	public void setBuyOrSell(String buyOrSell)
	{
		this.buyOrSell = buyOrSell;
	}

	public String getCollatAgreementId()
	{
		return this.collatAgreementId;
	}

	public void setCollatAgreementId(String collatAgreementId)
	{
		this.collatAgreementId = collatAgreementId;
	}

	public String getCollateralized()
	{
		return this.collateralized;
	}

	public void setCollateralized(String collateralized)
	{
		this.collateralized = collateralized;
	}

	public String getCptyBranch()
	{
		return this.cptyBranch;
	}

	public void setCptyBranch(String cptyBranch)
	{
		this.cptyBranch = cptyBranch;
	}

	public String getCptyTradeId()
	{
		return this.cptyTradeId;
	}

	public void setCptyTradeId(String cptyTradeId)
	{
		this.cptyTradeId = cptyTradeId;
	}

	public Date getEffectiveDate()
	{
		return this.effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate)
	{
		this.effectiveDate = effectiveDate;
	}

	public String getExtPrincipal()
	{
		return this.extPrincipal;
	}

	public void setExtPrincipal(String extPrincipal)
	{
		this.extPrincipal = extPrincipal;
	}

	public String getFullName()
	{
		return this.fullName;
	}

	public void setFullName(String fullName)
	{
		this.fullName = fullName;
	}

	public String getImargin()
	{
		return this.imargin;
	}

	public void setImargin(String imargin)
	{
		this.imargin = imargin;
	}

	public Date getLastUpdateDateTs()
	{
		return this.lastUpdateDateTs;
	}

	public void setLastUpdateDateTs(Date lastUpdateDateTs)
	{
		this.lastUpdateDateTs = lastUpdateDateTs;
	}

	public BigInteger getLegalId()
	{
		return this.legalId;
	}

	public void setLegalId(BigInteger legalId)
	{
		this.legalId = legalId;
	}

	public Date getMaturityDate()
	{
		return this.maturityDate;
	}

	public void setMaturityDate(Date maturityDate)
	{
		this.maturityDate = maturityDate;
	}

	public BigDecimal getNotional1()
	{
		return this.notional1;
	}

	public void setNotional1(BigDecimal notional1)
	{
		this.notional1 = notional1;
	}

	public String getNotional1Ccy()
	{
		return this.notional1Ccy;
	}

	public void setNotional1Ccy(String notional1Ccy)
	{
		this.notional1Ccy = notional1Ccy;
	}

	public BigDecimal getNotional2()
	{
		return this.notional2;
	}

	public void setNotional2(BigDecimal notional2)
	{
		this.notional2 = notional2;
	}

	public String getNotional2Ccy()
	{
		return this.notional2Ccy;
	}

	public void setNotional2Ccy(String notional2Ccy)
	{
		this.notional2Ccy = notional2Ccy;
	}

	public String getParentLegalId()
	{
		return this.parentLegalId;
	}

	public void setParentLegalId(String parentLegalId)
	{
		this.parentLegalId = parentLegalId;
	}

	public String getParentLegalName()
	{
		return this.parentLegalName;
	}

	public void setParentLegalName(String parentLegalName)
	{
		this.parentLegalName = parentLegalName;
	}

	public String getProdType()
	{
		return this.prodType;
	}

	public void setProdType(String prodType)
	{
		this.prodType = prodType;
	}

	public String getProductId()
	{
		return this.productId;
	}

	public void setProductId(String productId)
	{
		this.productId = productId;
	}

	public String getPutCall()
	{
		return this.putCall;
	}

	public void setPutCall(String putCall)
	{
		this.putCall = putCall;
	}

	public String getPv()
	{
		return this.pv;
	}

	public void setPv(String pv)
	{
		this.pv = pv;
	}

	public String getPvBaseCcy()
	{
		return this.pvBaseCcy;
	}

	public void setPvBaseCcy(String pvBaseCcy)
	{
		this.pvBaseCcy = pvBaseCcy;
	}

	public String getPvCcy()
	{
		return this.pvCcy;
	}

	public void setPvCcy(String pvCcy)
	{
		this.pvCcy = pvCcy;
	}

	public Date getPvCobDate()
	{
		return this.pvCobDate;
	}

	public void setPvCobDate(Date pvCobDate)
	{
		this.pvCobDate = pvCobDate;
	}

	public String getSourceSystem()
	{
		return this.sourceSystem;
	}

	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	public String getStrikePrice()
	{
		return this.strikePrice;
	}

	public void setStrikePrice(String strikePrice)
	{
		this.strikePrice = strikePrice;
	}

	public Date getTradeDate()
	{
		return this.tradeDate;
	}

	public void setTradeDate(Date tradeDate)
	{
		this.tradeDate = tradeDate;
	}

	public String getTradeId()
	{
		return this.tradeId;
	}

	public void setTradeId(String tradeId)
	{
		this.tradeId = tradeId;
	}

	public String getTrader()
	{
		return this.trader;
	}

	public void setTrader(String trader)
	{
		this.trader = trader;
	}

	public String getUnderlyingName()
	{
		return this.underlyingName;
	}

	public void setUnderlyingName(String underlyingName)
	{
		this.underlyingName = underlyingName;
	}

}