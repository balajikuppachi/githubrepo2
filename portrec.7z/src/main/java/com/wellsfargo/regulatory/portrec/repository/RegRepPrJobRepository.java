/*package com.wellsfargo.regulatory.portrec.repository;

import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJob;

*//**
 * 
 * @author Raji Komatreddy
 * 
 *//*
public interface RegRepPrJobRepository extends CrudRepository<RegRepPrJob, Long>
{

}
*/