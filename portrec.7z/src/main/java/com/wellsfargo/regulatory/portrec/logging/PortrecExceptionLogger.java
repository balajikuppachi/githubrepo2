package com.wellsfargo.regulatory.portrec.logging;

import java.util.Date;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.exceptions.ReportingException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrExceptionRepository;

/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class PortrecExceptionLogger
{
	@Autowired
	RegRepPrExceptionRepository regRepPrExceptionRepository;
	private static Logger logger = Logger.getLogger(PortrecExceptionLogger.class.getName());

	public void logExceptions(Message<MessageHandlingException> message) throws MessagingException
	{
		RegRepPrException regRepPrException = new RegRepPrException();
		Date currDate = new Date();

		String exceptionCode = null;		
		ExceptionTypeEnum exceptionType = null;
		long jobExecutionId = 0;
		ReportingException exception = null;
		try
		{

			Throwable exceptionParent = message.getPayload();
			String exceptionString = exceptionParent.getMessage();
			String stackTrace = org.apache.commons.lang.exception.ExceptionUtils.getFullStackTrace(exceptionParent);
			while ((null != exceptionParent) && !(exceptionParent instanceof ReportingException))
			{
				exceptionParent = exceptionParent.getCause();
			}
			if ((null != exceptionParent) && (exceptionParent instanceof ReportingException))
			{
				exception = (ReportingException) exceptionParent;
				exceptionCode = exception.getExceptionCode();				
				exceptionType = exception.getExceptionType();
				if (null != exception.getSdrMessageId()) jobExecutionId = Long.parseLong(exception.getSdrMessageId());

				regRepPrException.setJobExecutionId(jobExecutionId);
				regRepPrException.setExceptionSource(exceptionCode);				
				regRepPrException.setExceptionType(exceptionType.toString());
				regRepPrException.setExceptionDesc(exceptionString);
				regRepPrException.setExceptionTrace(stackTrace);
				regRepPrException.setCreateDatetime(currDate);

			}
			else
			{

				regRepPrException.setExceptionSource("UNCGHT:1");
				regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
				regRepPrException.setExceptionDesc(exceptionString);
				regRepPrException.setExceptionTrace(stackTrace);
				regRepPrException.setCreateDatetime(currDate);

			}
			logExceptionToDB(regRepPrException);
			
		}
		catch (Exception excep)
		{
			logger.error("Exception occurred inside PortrecExceptionLogger" + ExceptionUtils.getStackTrace(excep));
		}

	}

	public boolean logExceptionToDB(RegRepPrException regRepPrException) throws Exception
	{
		boolean success = true;
		/*regRepPrException.setExceptionId(123);*/
		regRepPrExceptionRepository.save(regRepPrException);

		return success;
	}
	
	
	
	public boolean logException(String exceptionProcess, String errorString, String excTrace, Long currJobExecutionId, Long legalId) throws Exception
	{
		boolean success = true;
		RegRepPrException regRepPrException = new RegRepPrException();
		regRepPrException.setExceptionSource(exceptionProcess);
		regRepPrException.setJobExecutionId(currJobExecutionId);
		regRepPrException.setCidCptyId(legalId);
		regRepPrException.setExceptionDesc(errorString);
		regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
		regRepPrException.setExceptionTrace(excTrace);
		regRepPrException.setCreateDatetime(new Date());
		logExceptionToDB(regRepPrException);
		
		return success;
	}
	
	public void logExceptionScenario(String exceptionSource, String errorMsg, Exception ce, Long jobExecutionId, Long legalId){

		logger.error("#### " + errorMsg + ". Legal id : " + legalId);
		String stackTrace = (null != ce ? ExceptionUtils.getStackTrace(ce) : null); 
		try {
			logException(exceptionSource, errorMsg, stackTrace, jobExecutionId, legalId);
		} catch (Exception e) {
			logger.error("Exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
		}
	}

}
