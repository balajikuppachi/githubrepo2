package com.wellsfargo.regulatory.portrec.mailer;

/**
 * @author u235720
 *
 */
public class PrExtractsTo {
	
	private String assetClass;
	
	private boolean flag;
	
	private int valCount;
	
	private int irCount;
	
	private int crCount;
	
	private int eqCount;
	
	private int fxCount;
	
	private int comCount;
	
	private int totalMtCount;
	
	private String valFileName;
	
	private String irMtFileName;
	
	private String crMtFileName;
	
	private String eqMtFileName;
	
	private String fxMtFileName;
	
	private String comMtFileName;

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public int getValCount() {
		return valCount;
	}

	public void setValCount(int valCount) {
		this.valCount = valCount;
	}

	public int getIrCount() {
		return irCount;
	}

	public void setIrCount(int irCount) {
		this.irCount = irCount;
	}

	public int getCrCount() {
		return crCount;
	}

	public void setCrCount(int crCount) {
		this.crCount = crCount;
	}

	public int getEqCount() {
		return eqCount;
	}

	public void setEqCount(int eqCount) {
		this.eqCount = eqCount;
	}

	public int getFxCount() {
		return fxCount;
	}

	public void setFxCount(int fxCount) {
		this.fxCount = fxCount;
	}

	public int getComCount() {
		return comCount;
	}

	public void setComCount(int comCount) {
		this.comCount = comCount;
	}

	public int getTotalMtCount() {
		return totalMtCount;
	}

	public void setTotalMtCount(int totalMtCount) {
		this.totalMtCount = totalMtCount;
	}

	public String getValFileName() {
		return valFileName;
	}

	public void setValFileName(String valFileName) {
		this.valFileName = valFileName;
	}

	public String getIrMtFileName() {
		return irMtFileName;
	}

	public void setIrMtFileName(String irMtFileName) {
		this.irMtFileName = irMtFileName;
	}

	public String getCrMtFileName() {
		return crMtFileName;
	}

	public void setCrMtFileName(String crMtFileName) {
		this.crMtFileName = crMtFileName;
	}

	public String getEqMtFileName() {
		return eqMtFileName;
	}

	public void setEqMtFileName(String eqMtFileName) {
		this.eqMtFileName = eqMtFileName;
	}

	public String getFxMtFileName() {
		return fxMtFileName;
	}

	public void setFxMtFileName(String fxMtFileName) {
		this.fxMtFileName = fxMtFileName;
	}

	public String getComMtFileName() {
		return comMtFileName;
	}

	public void setComMtFileName(String comMtFileName) {
		this.comMtFileName = comMtFileName;
	}
	
}
