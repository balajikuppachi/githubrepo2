package com.wellsfargo.regulatory.portrec.dto;

import java.util.Date;

public class CptyReconFreq
{
	private int cidCptyId;
	private String legalType;
	private String reconFreq;
	private int portfolioSize;
	private int commSize;
	private int crSize;
	private int irSize;
	private int eqSize;
	private int fxSize;
	private int fxIntlSize;
	private Date updateDatetime;

	public int getCidCptyId()
	{
		return cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public String getLegalType()
	{
		return legalType;
	}

	public void setLegalType(String legalType)
	{
		this.legalType = legalType;
	}

	public String getReconFreq()
	{
		return reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public int getPortfolioSize()
	{
		return portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public int getCommSize()
	{
		return commSize;
	}

	public void setCommSize(int commSize)
	{
		this.commSize = commSize;
	}

	public int getCrSize()
	{
		return crSize;
	}

	public void setCrSize(int crSize)
	{
		this.crSize = crSize;
	}

	public int getIrSize()
	{
		return irSize;
	}

	public void setIrSize(int irSize)
	{
		this.irSize = irSize;
	}

	public int getEqSize()
	{
		return eqSize;
	}

	public void setEqSize(int eqSize)
	{
		this.eqSize = eqSize;
	}

	public int getFxSize()
	{
		return fxSize;
	}

	public void setFxSize(int fxSize)
	{
		this.fxSize = fxSize;
	}

	public int getFxIntlSize()
	{
		return fxIntlSize;
	}

	public void setFxIntlSize(int fxIntlSize)
	{
		this.fxIntlSize = fxIntlSize;
	}

	public Date getUpdateDatetime()
	{
		return updateDatetime;
	}

	public void setUpdateDatetime(Date updateDatetime)
	{
		this.updateDatetime = updateDatetime;
	}

}
