package com.wellsfargo.regulatory.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy 
 * The persistent class for the REG_REP_PR_CR_POSITION_REPORT database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_CR_POSITION_REPORT")
public class RegRepPrCrPositionReport extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cr_position_report_id")
	private Long crPositionReportId;

	@Column(name = "additional_repository_1_lei")
	private String additionalRepository1Lei;

	@Column(name = "allocation_indicator")
	private String allocationIndicator;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	private String buyer;

	@Column(name = "buyer_lei_prefix")
	private String buyerLeiPrefix;

	@Column(name = "buyer_lei_value")
	private String buyerLeiValue;

	private String collateralized;

	@Column(name = "disputed_notional_amount_1")
	private BigDecimal disputedNotionalAmount1;

	@Column(name = "disputed_notional_currency_1")
	private String disputedNotionalCurrency1;

	@Temporal(TemporalType.DATE)
	@Column(name = "effective_date")
	private Date effectiveDate;

	@Column(name = "execution_date")
	private Date executionDate;

	@Column(name = "execution_venue")
	private String executionVenue;

	@Column(name = "execution_venue_prefix")
	private String executionVenuePrefix;

	@Column(name = "fixed_rate_per_annum")
	private BigDecimal fixedRatePerAnnum;

	@Column(name = "initial_payment_amount")
	private BigDecimal initialPaymentAmount;

	@Column(name = "initial_payment_currency")
	private String initialPaymentCurrency;

	@Column(name = "mandatory_clearing_indicator")
	private String mandatoryClearingIndicator;

	@Column(name = "notional_amount_1")
	private BigDecimal notionalAmount1;

	@Column(name = "notional_currency_1")
	private String notionalCurrency1;

	@Column(name = "option_strike_price")
	private String optionStrikePrice;

	@Column(name = "orig_trade_id")
	private String origTradeId;

	@Column(name = "payment_frequency_period_1")
	private String paymentFrequencyPeriod1;

	@Column(name = "payment_frequency_period_multiplier_1")
	private String paymentFrequencyPeriodMultiplier1;

	@Column(name = "primary_asset_class")
	private String primaryAssetClass;

	@Column(name = "product_type")
	private String productType;

	@Column(name = "product_type_prefix")
	private String productTypePrefix;

	@Column(name = "reference_entity")
	private String referenceEntity;

	@Column(name = "reporting_jurisdiction")
	private String reportingJurisdiction;

	@Column(name = "reporting_party")
	private String reportingParty;

	@Column(name = "revision_id")
	private int revisionId;

	@Temporal(TemporalType.DATE)
	@Column(name = "scheduled_termination_date")
	private Date scheduledTerminationDate;

	@Column(name = "secondary_asset_class")
	private String secondaryAssetClass;

	private String seller;

	@Column(name = "single_payment_amount")
	private BigDecimal singlePaymentAmount;

	@Column(name = "single_payment_currency")
	private String singlePaymentCurrency;

	@Column(name = "submitted_for")
	private String submittedFor;

	@Temporal(TemporalType.DATE)
	@Column(name = "trade_date")
	private Date tradeDate;

	@Column(name = "trade_party_1_financial_entity")
	private String tradeParty1FinancialEntity;

	@Column(name = "trade_party_1_usperson_indicator")
	private String tradeParty1UspersonIndicator;

	@Column(name = "trade_party_2_financial_entity")
	private String tradeParty2FinancialEntity;

	@Column(name = "trade_party_2_usperson_indicator")
	private String tradeParty2UspersonIndicator;

	@Column(name = "trade_party1")
	private String tradeParty1;

	@Column(name = "trade_party1_lei")
	private String tradeParty1Lei;

	@Column(name = "trade_party1_role")
	private String tradeParty1Role;

	@Column(name = "trade_party1_tr_id")
	private String tradeParty1TrId;

	@Column(name = "trade_party2")
	private String tradeParty2;

	@Column(name = "trade_party2_lei")
	private String tradeParty2Lei;

	@Column(name = "trade_party2_role")
	private String tradeParty2Role;

	@Column(name = "trader_location_party1")
	private String traderLocationParty1;

	@Column(name = "trader_location_party2")
	private String traderLocationParty2;

	@Column(name = "underlying_asset")
	private String underlyingAsset;

	private String usi;

	@Column(name = "usi_prefix")
	private String usiPrefix;

	@Column(name = "verified_notional_amount_1")
	private BigDecimal verifiedNotionalAmount1;

	@Column(name = "verified_notional_currency_1")
	private String verifiedNotionalCurrency1;

	public RegRepPrCrPositionReport()
	{
	}

	public long getCrPositionReportId()
	{
		return this.crPositionReportId;
	}

	public void setCrPositionReportId(long crPositionReportId)
	{
		this.crPositionReportId = crPositionReportId;
	}

	public String getAdditionalRepository1Lei()
	{
		return this.additionalRepository1Lei;
	}

	public void setAdditionalRepository1Lei(String additionalRepository1Lei)
	{
		this.additionalRepository1Lei = additionalRepository1Lei;
	}

	public String getAllocationIndicator()
	{
		return this.allocationIndicator;
	}

	public void setAllocationIndicator(String allocationIndicator)
	{
		this.allocationIndicator = allocationIndicator;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getBuyer()
	{
		return this.buyer;
	}

	public void setBuyer(String buyer)
	{
		this.buyer = buyer;
	}

	public String getBuyerLeiPrefix()
	{
		return this.buyerLeiPrefix;
	}

	public void setBuyerLeiPrefix(String buyerLeiPrefix)
	{
		this.buyerLeiPrefix = buyerLeiPrefix;
	}

	public String getBuyerLeiValue()
	{
		return this.buyerLeiValue;
	}

	public void setBuyerLeiValue(String buyerLeiValue)
	{
		this.buyerLeiValue = buyerLeiValue;
	}

	public String getCollateralized()
	{
		return this.collateralized;
	}

	public void setCollateralized(String collateralized)
	{
		this.collateralized = collateralized;
	}

	public BigDecimal getDisputedNotionalAmount1()
	{
		return this.disputedNotionalAmount1;
	}

	public void setDisputedNotionalAmount1(BigDecimal disputedNotionalAmount1)
	{
		this.disputedNotionalAmount1 = disputedNotionalAmount1;
	}

	public String getDisputedNotionalCurrency1()
	{
		return this.disputedNotionalCurrency1;
	}

	public void setDisputedNotionalCurrency1(String disputedNotionalCurrency1)
	{
		this.disputedNotionalCurrency1 = disputedNotionalCurrency1;
	}

	public Date getEffectiveDate()
	{
		return this.effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate)
	{
		this.effectiveDate = effectiveDate;
	}

	public Date getExecutionDate()
	{
		return this.executionDate;
	}

	public void setExecutionDate(Date executionDate)
	{
		this.executionDate = executionDate;
	}

	public String getExecutionVenue()
	{
		return this.executionVenue;
	}

	public void setExecutionVenue(String executionVenue)
	{
		this.executionVenue = executionVenue;
	}

	public String getExecutionVenuePrefix()
	{
		return this.executionVenuePrefix;
	}

	public void setExecutionVenuePrefix(String executionVenuePrefix)
	{
		this.executionVenuePrefix = executionVenuePrefix;
	}

	public BigDecimal getFixedRatePerAnnum()
	{
		return this.fixedRatePerAnnum;
	}

	public void setFixedRatePerAnnum(BigDecimal fixedRatePerAnnum)
	{
		this.fixedRatePerAnnum = fixedRatePerAnnum;
	}

	public BigDecimal getInitialPaymentAmount()
	{
		return this.initialPaymentAmount;
	}

	public void setInitialPaymentAmount(BigDecimal initialPaymentAmount)
	{
		this.initialPaymentAmount = initialPaymentAmount;
	}

	public String getInitialPaymentCurrency()
	{
		return this.initialPaymentCurrency;
	}

	public void setInitialPaymentCurrency(String initialPaymentCurrency)
	{
		this.initialPaymentCurrency = initialPaymentCurrency;
	}

	public String getMandatoryClearingIndicator()
	{
		return this.mandatoryClearingIndicator;
	}

	public void setMandatoryClearingIndicator(String mandatoryClearingIndicator)
	{
		this.mandatoryClearingIndicator = mandatoryClearingIndicator;
	}

	public BigDecimal getNotionalAmount1()
	{
		return this.notionalAmount1;
	}

	public void setNotionalAmount1(BigDecimal notionalAmount1)
	{
		this.notionalAmount1 = notionalAmount1;
	}

	public String getNotionalCurrency1()
	{
		return this.notionalCurrency1;
	}

	public void setNotionalCurrency1(String notionalCurrency1)
	{
		this.notionalCurrency1 = notionalCurrency1;
	}

	public String getOptionStrikePrice()
	{
		return this.optionStrikePrice;
	}

	public void setOptionStrikePrice(String optionStrikePrice)
	{
		this.optionStrikePrice = optionStrikePrice;
	}

	public String getOrigTradeId()
	{
		return this.origTradeId;
	}

	public void setOrigTradeId(String origTradeId)
	{
		this.origTradeId = origTradeId;
	}

	public String getPaymentFrequencyPeriod1()
	{
		return this.paymentFrequencyPeriod1;
	}

	public void setPaymentFrequencyPeriod1(String paymentFrequencyPeriod1)
	{
		this.paymentFrequencyPeriod1 = paymentFrequencyPeriod1;
	}

	public String getPaymentFrequencyPeriodMultiplier1()
	{
		return this.paymentFrequencyPeriodMultiplier1;
	}

	public void setPaymentFrequencyPeriodMultiplier1(String paymentFrequencyPeriodMultiplier1)
	{
		this.paymentFrequencyPeriodMultiplier1 = paymentFrequencyPeriodMultiplier1;
	}

	public String getPrimaryAssetClass()
	{
		return this.primaryAssetClass;
	}

	public void setPrimaryAssetClass(String primaryAssetClass)
	{
		this.primaryAssetClass = primaryAssetClass;
	}

	public String getProductType()
	{
		return this.productType;
	}

	public void setProductType(String productType)
	{
		this.productType = productType;
	}

	public String getProductTypePrefix()
	{
		return this.productTypePrefix;
	}

	public void setProductTypePrefix(String productTypePrefix)
	{
		this.productTypePrefix = productTypePrefix;
	}

	public String getReferenceEntity()
	{
		return this.referenceEntity;
	}

	public void setReferenceEntity(String referenceEntity)
	{
		this.referenceEntity = referenceEntity;
	}

	public String getReportingJurisdiction()
	{
		return this.reportingJurisdiction;
	}

	public void setReportingJurisdiction(String reportingJurisdiction)
	{
		this.reportingJurisdiction = reportingJurisdiction;
	}

	public String getReportingParty()
	{
		return this.reportingParty;
	}

	public void setReportingParty(String reportingParty)
	{
		this.reportingParty = reportingParty;
	}

	public int getRevisionId()
	{
		return this.revisionId;
	}

	public void setRevisionId(int revisionId)
	{
		this.revisionId = revisionId;
	}

	public Date getScheduledTerminationDate()
	{
		return this.scheduledTerminationDate;
	}

	public void setScheduledTerminationDate(Date scheduledTerminationDate)
	{
		this.scheduledTerminationDate = scheduledTerminationDate;
	}

	public String getSecondaryAssetClass()
	{
		return this.secondaryAssetClass;
	}

	public void setSecondaryAssetClass(String secondaryAssetClass)
	{
		this.secondaryAssetClass = secondaryAssetClass;
	}

	public String getSeller()
	{
		return this.seller;
	}

	public void setSeller(String seller)
	{
		this.seller = seller;
	}

	public BigDecimal getSinglePaymentAmount()
	{
		return this.singlePaymentAmount;
	}

	public void setSinglePaymentAmount(BigDecimal singlePaymentAmount)
	{
		this.singlePaymentAmount = singlePaymentAmount;
	}

	public String getSinglePaymentCurrency()
	{
		return this.singlePaymentCurrency;
	}

	public void setSinglePaymentCurrency(String singlePaymentCurrency)
	{
		this.singlePaymentCurrency = singlePaymentCurrency;
	}

	public String getSubmittedFor()
	{
		return this.submittedFor;
	}

	public void setSubmittedFor(String submittedFor)
	{
		this.submittedFor = submittedFor;
	}

	public Date getTradeDate()
	{
		return this.tradeDate;
	}

	public void setTradeDate(Date tradeDate)
	{
		this.tradeDate = tradeDate;
	}

	public String getTradeParty1FinancialEntity()
	{
		return this.tradeParty1FinancialEntity;
	}

	public void setTradeParty1FinancialEntity(String tradeParty1FinancialEntity)
	{
		this.tradeParty1FinancialEntity = tradeParty1FinancialEntity;
	}

	public String getTradeParty1UspersonIndicator()
	{
		return this.tradeParty1UspersonIndicator;
	}

	public void setTradeParty1UspersonIndicator(String tradeParty1UspersonIndicator)
	{
		this.tradeParty1UspersonIndicator = tradeParty1UspersonIndicator;
	}

	public String getTradeParty2FinancialEntity()
	{
		return this.tradeParty2FinancialEntity;
	}

	public void setTradeParty2FinancialEntity(String tradeParty2FinancialEntity)
	{
		this.tradeParty2FinancialEntity = tradeParty2FinancialEntity;
	}

	public String getTradeParty2UspersonIndicator()
	{
		return this.tradeParty2UspersonIndicator;
	}

	public void setTradeParty2UspersonIndicator(String tradeParty2UspersonIndicator)
	{
		this.tradeParty2UspersonIndicator = tradeParty2UspersonIndicator;
	}

	public String getTradeParty1()
	{
		return this.tradeParty1;
	}

	public void setTradeParty1(String tradeParty1)
	{
		this.tradeParty1 = tradeParty1;
	}

	public String getTradeParty1Lei()
	{
		return this.tradeParty1Lei;
	}

	public void setTradeParty1Lei(String tradeParty1Lei)
	{
		this.tradeParty1Lei = tradeParty1Lei;
	}

	public String getTradeParty1Role()
	{
		return this.tradeParty1Role;
	}

	public void setTradeParty1Role(String tradeParty1Role)
	{
		this.tradeParty1Role = tradeParty1Role;
	}

	public String getTradeParty1TrId()
	{
		return this.tradeParty1TrId;
	}

	public void setTradeParty1TrId(String tradeParty1TrId)
	{
		this.tradeParty1TrId = tradeParty1TrId;
	}

	public String getTradeParty2()
	{
		return this.tradeParty2;
	}

	public void setTradeParty2(String tradeParty2)
	{
		this.tradeParty2 = tradeParty2;
	}

	public String getTradeParty2Lei()
	{
		return this.tradeParty2Lei;
	}

	public void setTradeParty2Lei(String tradeParty2Lei)
	{
		this.tradeParty2Lei = tradeParty2Lei;
	}

	public String getTradeParty2Role()
	{
		return this.tradeParty2Role;
	}

	public void setTradeParty2Role(String tradeParty2Role)
	{
		this.tradeParty2Role = tradeParty2Role;
	}

	public String getTraderLocationParty1()
	{
		return this.traderLocationParty1;
	}

	public void setTraderLocationParty1(String traderLocationParty1)
	{
		this.traderLocationParty1 = traderLocationParty1;
	}

	public String getTraderLocationParty2()
	{
		return this.traderLocationParty2;
	}

	public void setTraderLocationParty2(String traderLocationParty2)
	{
		this.traderLocationParty2 = traderLocationParty2;
	}

	public String getUnderlyingAsset()
	{
		return this.underlyingAsset;
	}

	public void setUnderlyingAsset(String underlyingAsset)
	{
		this.underlyingAsset = underlyingAsset;
	}

	public String getUsi()
	{
		return this.usi;
	}

	public void setUsi(String usi)
	{
		this.usi = usi;
	}

	public String getUsiPrefix()
	{
		return this.usiPrefix;
	}

	public void setUsiPrefix(String usiPrefix)
	{
		this.usiPrefix = usiPrefix;
	}

	public BigDecimal getVerifiedNotionalAmount1()
	{
		return this.verifiedNotionalAmount1;
	}

	public void setVerifiedNotionalAmount1(BigDecimal verifiedNotionalAmount1)
	{
		this.verifiedNotionalAmount1 = verifiedNotionalAmount1;
	}

	public String getVerifiedNotionalCurrency1()
	{
		return this.verifiedNotionalCurrency1;
	}

	public void setVerifiedNotionalCurrency1(String verifiedNotionalCurrency1)
	{
		this.verifiedNotionalCurrency1 = verifiedNotionalCurrency1;
	}

}