package com.wellsfargo.regulatory.portrec.dto;

import java.util.Date;

/**
 * @author Raji Komatreddy
 */

public class PositionRecon
{
	private Long positionReconId;
	private long jobExecutionId;
	private int cidCptyId;
	private Date asOfDate;
	private String reconFreq;
	private int portfolioSize;
	private int irPositionSize;
	private int crPositionSize;
	private int eqPositionSize;
	private int fxPositionSize;
	private int commPositionSize;
	private int valuationSize;
	private Date createDatetime;

	public Long getPositionReconId()
	{
		return positionReconId;
	}

	public void setPositionReconId(Long positionReconId)
	{
		this.positionReconId = positionReconId;
	}

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public int getCidCptyId()
	{
		return cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public Date getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getReconFreq()
	{
		return reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public int getPortfolioSize()
	{
		return portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public int getIrPositionSize()
	{
		return irPositionSize;
	}

	public void setIrPositionSize(int irPositionSize)
	{
		this.irPositionSize = irPositionSize;
	}

	public int getCrPositionSize()
	{
		return crPositionSize;
	}

	public void setCrPositionSize(int crPositionSize)
	{
		this.crPositionSize = crPositionSize;
	}

	public int getEqPositionSize()
	{
		return eqPositionSize;
	}

	public void setEqPositionSize(int eqPositionSize)
	{
		this.eqPositionSize = eqPositionSize;
	}

	public int getFxPositionSize()
	{
		return fxPositionSize;
	}

	public void setFxPositionSize(int fxPositionSize)
	{
		this.fxPositionSize = fxPositionSize;
	}

	public int getCommPositionSize()
	{
		return commPositionSize;
	}

	public void setCommPositionSize(int commPositionSize)
	{
		this.commPositionSize = commPositionSize;
	}

	public int getValuationSize()
	{
		return valuationSize;
	}

	public void setValuationSize(int valuationSize)
	{
		this.valuationSize = valuationSize;
	}

	public Date getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

}
