package com.wellsfargo.regulatory.portrec.mailer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconReport;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 */
@Component
@ManagedResource(description = "Counter Party Mailing Process")
public class CptyMailerProcess
{

	private final Logger logger = Logger.getLogger(CptyMailerProcess.class);

	@Autowired
	PrEmailTemplateService prMailingService;

	@Autowired
	CptyReconReportService cptyReconReportService;

	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;

	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;
	
	@Autowired
	CalendarService calendarService;
	
	@Value("${mail.process.flag}")
	String emailSendFlag;
	
	@Value("${days.email.data.delivery.date}")
	int noOfDaysToDataDeliveryDate;
	
	@Value("${days.email.affirm.date}")
	int noOfDaysToAffirmDate;
	
	@Autowired
	PrEmailAddressValidation prEmailAddressValidation;

	@ManagedOperation(description = "Starting Mailer Process")
	public void startMailerProcess(Message<?> message) throws PortrecException
	{
		
		long timeStart = System.currentTimeMillis();
		logger.info("Start Cpty Mailer Process - ");

		Object ipMessage = null;
		String errorString = null;
		String jobReconDateInString = null;
		Date reconDate = new Date();
		long currJobExecutionId = 0;

		RegRepPrJobDetail currRegRepPrJobDetail = null;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(PortrecConstants.PORTREC_AS_OF_DATE_FORMAT);

		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyMailerProcess-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		
		ipMessage = message.getPayload();
		
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)) 
		{
			jobReconDateInString = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();
		}
		
		if (null != jobReconDateInString)
		{
			logger.info("Mailing process running for run date received from fileName " + jobReconDateInString);
			try
			{
				reconDate = reconDateFormat.parse(jobReconDateInString);
			}
			catch (ParseException e)
			{
				logger.error("########## " + e.getMessage());
			}
			
		}else{
			reconDate = new Date();
		}
		

		if (ipMessage instanceof RegRepPrJobDetail)
		{
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail)
		{
			errorString = "Null incoming PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyMailerProcess-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(reconDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail.getJobName());
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyMailerProcess-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		logger.info("JobExecution id for current run of CptyMailerProcess :  " + currJobExecutionId);
		
		String fileName = "CptyReconMailerProcess";
		String status = "success";
		RegRepPrJobExecutionDetail prevRegRepPrJobExecutionDetail= regRepPrJobExecutionDetailRepository.findPreviousJobExecutionDetail(fileName, status);
		long prevJobExecutionId  = prevRegRepPrJobExecutionDetail.getJobExecutionId();
		
		logger.info("JobExecution id for previous run of CptyReconMailerProcess : " + prevJobExecutionId);
		
		Date asOfDate = null;
		
		try
		{
			List<RegRepPrReconReport> lastReconReport = cptyReconReportService.getAllReconReport(prevRegRepPrJobExecutionDetail);
			
			Date deliveryDate = calendarService.dateIncrement(reconDate, noOfDaysToDataDeliveryDate);
			Date affirmDate = calendarService.dateIncrement(reconDate, noOfDaysToAffirmDate);
			
			String reconFrequency = null;
			int legalId = 0;
			
			for(RegRepPrReconReport reconReport : lastReconReport)
			{
				try 
				{
					CptyReconInformation prCptyInformation = new CptyReconInformation();
					
					logger.info("Legal Id : " + reconReport.getCidCptyId());
						
					prCptyInformation.setCustomerName1(StringUtils.trim(reconReport.getCustomerName1()));
					prCptyInformation.setCustomerName2(StringUtils.trim(reconReport.getCustomerName2()));
					prCptyInformation.setAddressLine1(StringUtils.trim(reconReport.getAddressLine1()));
					prCptyInformation.setAddressLine2(StringUtils.trim(reconReport.getAddressLine2()));
					prCptyInformation.setCity(StringUtils.trim(reconReport.getCity()));
					prCptyInformation.setState(StringUtils.trim(reconReport.getState()));
					prCptyInformation.setCountry(StringUtils.trim(reconReport.getCountry()));
					prCptyInformation.setZipCode(StringUtils.trim(reconReport.getZipCode()));
					
					prCptyInformation.setDispatchDate(reconDate);
					prCptyInformation.setDataDeliveryDate(deliveryDate);
					
					asOfDate = reconReport.getAsOfDate();
					prCptyInformation.setAsOfDate(asOfDate);
					
					prCptyInformation.setRecordDate(asOfDate);
					prCptyInformation.setAffirmDate(affirmDate);
					
					prCptyInformation.setCidCptyId(reconReport.getCidCptyId());
					prCptyInformation.setFullLegalName(StringUtils.trim(reconReport.getLgleFullN()));
					prCptyInformation.setRegRepPrJobExecutionDetail(regRepPrJobExecutionDetail);
					
					prCptyInformation.setEmailAddress(StringUtils.trim(reconReport.getEmailAddress()));
					prCptyInformation.setCptyType(StringUtils.trim(reconReport.getCptyType()));
					prCptyInformation.setPortfolioSize(reconReport.getPortfolioSize());
					
					reconFrequency = StringUtils.trim(reconReport.getReconFreq());
					prCptyInformation.setReconFreq(reconFrequency);

					prCptyInformation.setDomIntl(StringUtils.trim(reconReport.getDomInt1()));
					
					if (reconFrequency.equalsIgnoreCase(PortrecConstants.QUARTERLY))
					{
						if(!StringUtils.isBlank(emailSendFlag) && new Boolean(emailSendFlag))
						{
							prMailingService.sendReconEmailQuarterly(prCptyInformation);	
						}
					}
					else if (reconFrequency.equalsIgnoreCase(PortrecConstants.ANNUAL))
					{
						if(!StringUtils.isBlank(emailSendFlag) && new Boolean(emailSendFlag))
						{
							prMailingService.sendReconEmailAnnual(prCptyInformation);
						}
					}
					
					// TODO
					// Update Recon table for which Email has been sent
									
					
				} // ends try block - looping over counter parties
				catch(Exception ex)
				{
					logger.error("Error-4 in Cpty Mailer Process. Legal Id: " + legalId + " ## "+ ex.getMessage());
					try
					{
						regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
						regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
						regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
						regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

						errorString = ex.getMessage();
						logger.error("Exception-4 inside CptyMailerProcess for jobId #" + currJobExecutionId + " exception message " + errorString);
						portrecExceptionLogger.logException("CptyMailerProcess-4", errorString, ExceptionUtils.getStackTrace(ex), currJobExecutionId, Long.valueOf(legalId));
					}
					catch (Exception e)
					{
						logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
					}
				} // ends catch block - looping over counter parties
			} // end for loop over eligible counter parties 
		}
		catch (Exception ex)
		{
			logger.error("Error-5 in Cpty Mailer Process : " + ex.getMessage());
			
			try
			{
				regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				logger.error("Exception-5 inside Cpty Mailer Process for jobId #" + currJobExecutionId + " exception message " + errorString);
				portrecExceptionLogger.logException("CptyMailerProcess-5", errorString, ExceptionUtils.getStackTrace(ex), currJobExecutionId, null);
			}
			catch (Exception e)
			{
				logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}

		}

		regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in Cpty Mailer Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));
		
	}
	
}