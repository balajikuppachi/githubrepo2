package com.wellsfargo.regulatory.portrec.reports;

import java.util.Date;

public class CptyMisPostDetails {

	
	private Integer cidCptyId;
	private String fullLegalName;
	private String assetClass;
	private String fileName;
	private String reconFreq;
	private Date asOfDate;
	private String mtValType;
	private String affirmedFlag;
	private Date affirmDatetime;
	private String affirmComments;
	private Integer jsFlag;
	
	public String getFullLegalName() {
		return fullLegalName;
	}
	public void setFullLegalName(String fullLegalName) {
		this.fullLegalName = fullLegalName;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getReconFreq() {
		return reconFreq;
	}
	public void setReconFreq(String reconFreq) {
		this.reconFreq = reconFreq;
	}
	public Date getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}
	public String getMtValType() {
		return mtValType;
	}
	public void setMtValType(String mtValType) {
		this.mtValType = mtValType;
	}
	public String getAffirmedFlag() {
		return affirmedFlag;
	}
	public void setAffirmedFlag(String affirmedFlag) {
		this.affirmedFlag = affirmedFlag;
	}
	public Date getAffirmDatetime() {
		return affirmDatetime;
	}
	public void setAffirmDatetime(Date affirmDatetime) {
		this.affirmDatetime = affirmDatetime;
	}
	public String getAffirmComments() {
		return affirmComments;
	}
	public void setAffirmComments(String affirmComments) {
		this.affirmComments = affirmComments;
	}
	public Integer getCidCptyId() {
		return cidCptyId;
	}
	public void setCidCptyId(Integer cidCptyId) {
		this.cidCptyId = cidCptyId;
	}
	public Integer getJsFlag() {
		return jsFlag;
	}
	public void setJsFlag(Integer jsFlag) {
		this.jsFlag = jsFlag;
	}
}
