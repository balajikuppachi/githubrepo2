package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.mailer.CptyReconInformation;
import com.wellsfargo.regulatory.portrec.mailer.PrEmailAddressValidation;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCidRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCptyReconFreqRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrDaReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Service
public class PrPreRunReportWriter {
	
	private final Logger logger = Logger.getLogger(PrPreRunReportWriter.class);
	
	@Value("${file.mis.outputFolder}")
	String outputFolderName;

	protected String legalNameValue = null;
	protected String legalIdValue = null;
	protected String emailAddressValue = null;
	protected String reconTypeValue = null;
	protected String portfolioSizeValue = null;
	protected String cptyTypeValue = null;
	protected Date todayDate = null;
	protected String irCount=null;
	protected String crCount=null;
	protected String eqCount=null;
	protected String fxCount=null;
	protected String fxIntlCount=null;
	protected String commCount=null;
	protected String  jsFLag=null;
	
	@Autowired
	RegRepPrCptyReconFreqRepository regRepPrCptyReconFreqRepository;
	
	@Autowired
	RegRepPrDaReportRepository regRepPrDaReportRepository;
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	@Autowired
	RegRepPrCidRepository regRepPrCidRepository;

	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;

	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;
	
	@Autowired
	CalendarService calendarService;
	
	@Autowired
	PrEmailAddressValidation prEmailAddressValidation;

	public boolean misPreFileGeneration(long currJobExecutionId, Map<String, Map<Integer, CptyReconInformation>>  map) throws PortrecException {

		long timeStart = System.currentTimeMillis();
		
		logger.info("Start misPreReportGeneration - ");
		
		logger.info("jobExecution id for current run of misPreReportGeneration " + currJobExecutionId);

		logger.info("Folder where file created is " + outputFolderName);
		
		boolean flag = false;
		
		Set<String> freqs = map.keySet();
		
		logger.info("Number of recon frequency : " + freqs.size());
		
		for(String freqKey :freqs)
		{
			Map<Integer, CptyReconInformation>  mapOfLegalIds = map.get(freqKey);
			
			try 
			{
			
				String[] keyArray = freqKey.split(":");
				
				String reconFrequency = null;
				Date asOfDate = null;
				
				if(null != keyArray && keyArray.length > 1)
				{
					if(null != keyArray[0]){
						reconFrequency = keyArray[0];
					}else{
						String errorMsg = "Error as Frequency is null";
						portrecExceptionLogger.logExceptionScenario("PrPreRunReportWriter-1", errorMsg, null, currJobExecutionId, null);
						throw new PortrecException("PrPreRunReportWriter-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorMsg);
					}
					
					if(null != keyArray[1]){
						String asOfDateString = keyArray[1];
						asOfDate = new SimpleDateFormat("yyyy-MM-dd").parse(asOfDateString);
					}else{
						String errorMsg = "Error as As Of Date is null";
						portrecExceptionLogger.logExceptionScenario("PrPreRunReportWriter-2", errorMsg, null, currJobExecutionId, null);
						throw new PortrecException("PrPreRunReportWriter-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorMsg);
					}
				}
			
				File prPreRunFolder = new File(outputFolderName);
				
				if (!prPreRunFolder.exists() && !prPreRunFolder.isDirectory()) 
				{
					prPreRunFolder.mkdirs();
				}
				
				File prPreRunFile = new File(prPreRunFolder + File.separator
						+ PortrecConstants.PR_PRE_FILE_NAME + PortrecConstants.UNDERSCORE
						+ reconFrequency.toLowerCase() + PortrecConstants.UNDERSCORE
						+ PortRecUtil.convertDateToString_Mmddyyyy(asOfDate)
						+ ".xls");
				
				
				if(null != mapOfLegalIds && !mapOfLegalIds.isEmpty())
				{
					generateCsvFile(prPreRunFile,currJobExecutionId, mapOfLegalIds, reconFrequency, asOfDate);
					
				} else {
					logger.info("No eligible Cp to generate Pre Run Report : " + reconFrequency);
				}
			}
			catch(Exception ex)
			{
				String errorMsg = "Error while generating MIS PreRun Report :" + ex.getMessage();
				portrecExceptionLogger.logExceptionScenario("PrPreRunReportWriter-3", errorMsg, ex, currJobExecutionId, null);
				throw new PortrecException("PrPreRunReportWriter-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorMsg, ex);
			}
			
			flag= true;
		}

		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in Mis PreRun Report generation : "	+ PortRecUtil.printTimeTaken(timeEnd - timeStart));
		
		return flag;
	}

	private void prepareSummaryHeader(Workbook wb, Row row, short column, String displayText) {
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = wb.createCellStyle();

		Font xSSFFont = wb.createFont();
		xSSFFont.setFontName(HSSFFont.FONT_ARIAL);
		xSSFFont.setFontHeightInPoints((short) 12);
		xSSFFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		xSSFFont.setColor(HSSFColor.BLACK.index);
		cellStyle.setFont(xSSFFont);

		cell.setCellStyle(cellStyle);
	}

	private void generateCsvFile(File prPreRunFile, long currJobExecutionId, Map<Integer,CptyReconInformation> legalIdMap, String reconFrequency, Date asOfDate) throws Exception 
	{
		try 
		{
			String reconFreqHeading = null;
			
			FileOutputStream fileOut = new FileOutputStream(prPreRunFile);
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet worksheet1 = workbook.createSheet("Summary");
			Sheet worksheet2 = workbook.createSheet("Detail");
			
			Row row1 = worksheet1.createRow((short) 2);
			
			prepareSummaryHeader(workbook, row1, (short) 0,	PortrecConstants.PRE_REPORT_HEADING);
			
			reconFreqHeading = calendarService.reconFrequency(asOfDate, reconFrequency);
			if (null != reconFreqHeading)
			{
				prepareSummaryHeader(workbook, row1, (short) 1, reconFreqHeading);
			}
			
			Row row2 = worksheet1.createRow((short) 3);
			
			prepareSummaryHeader(workbook, row2, (short) 1,	PortrecConstants.DATA_COB + PortrecConstants.SPACE
					+ PortRecUtil.convertDateToString_Mmddyy(asOfDate));
			

			Row row3 = worksheet1.createRow((short) 6);
			prepareSummaryHeader(workbook, row3, (short) 0, PortrecConstants.CATEGORY);
			prepareSummaryHeader(workbook, row3, (short) 1, PortrecConstants.COUNT);
			

			Row row4 = worksheet1.createRow((short) 7);
			Cell cellA6 = row4.createCell((short) 0);
			if (reconFrequency != null && reconFrequency.length()>1) {
				cellA6.setCellValue(reconFrequency.substring(0, 1)
						+ reconFrequency.substring(1).toLowerCase()
						+ PortrecConstants.SPACE + PortrecConstants.RECON);
			}

			Row row5 = worksheet1.createRow((short) 8);
			Cell cellA7 = row5.createCell((short) 0);
			cellA7.setCellValue(PortrecConstants.TOTAL_CP_ELIGIBLE_FOR_NOTICE);
			Cell cellA8 = row5.createCell((short) 1);
			
			Long numOfNoticeEligibleCp = null;
			numOfNoticeEligibleCp = regRepPrCptyReconFreqRepository.findTotalCpEligibleForNotice(reconFrequency);
			
			if (null != numOfNoticeEligibleCp){
				cellA8.setCellValue(numOfNoticeEligibleCp);
			}
			
			Row row6 = worksheet1.createRow((short) 9);
			Cell cellA9 = row6.createCell((short) 0);
			cellA9.setCellValue(PortrecConstants.SWAP_DEALER_MSP);
			Cell cellA10 = row6.createCell((short) 1);
			
			Long numOfSdMsp = null;
			numOfSdMsp = regRepPrCptyReconFreqRepository.findSwapDealerAndMsp(reconFrequency);
			
			if (null != numOfSdMsp){
				cellA10.setCellValue(numOfSdMsp);
			}
			
			Row row7 = worksheet1.createRow((short) 10);
			Cell cellA11 = row7.createCell((short) 0);
			cellA11.setCellValue(PortrecConstants.NON_SWAP_DEALER_MSP);
			Cell cellA12 = row7.createCell((short) 1);
			
			Long numOfNonSdMsp = null;
			numOfNonSdMsp = regRepPrCptyReconFreqRepository.findNonSwapDealerAndMsp(reconFrequency);
			
			if (null != numOfNonSdMsp){
				cellA12.setCellValue(numOfNonSdMsp);
			}
			
			Row row8 = worksheet1.createRow((short) 11);
			Cell cellA13 = row8.createCell((short) 0);
			cellA13.setCellValue(PortrecConstants.TOTAL_MATERIAL_TERM_FILE);
			Cell cellA14 = row8.createCell((short) 1);
			cellA14.setCellValue(PortrecConstants.EMPTY);

			Row row9 = worksheet1.createRow((short) 12);
			Cell cellA15 = row9.createCell((short) 0);
			cellA15.setCellValue(PortrecConstants.TOTAL_VALUATION_FILE);
			Cell cellA16 = row9.createCell((short) 1);
			cellA16.setCellValue(PortrecConstants.EMPTY);

			Row row10 = worksheet1.createRow((short) 14);
			Cell cellA17 = row10.createCell((short) 0);
			cellA17.setCellValue(PortrecConstants.TOTAL_TRADES_ELIGIBLE_FOR_NOTICE);
			Cell cellA18 = row10.createCell((short) 1);
			
			Long totalPortfolioSizeByFreq = null; 
			totalPortfolioSizeByFreq =	regRepPrCptyReconFreqRepository.totalTradesEligibleForNoticeQuartely(reconFrequency);
			
			if (null != totalPortfolioSizeByFreq)
			{
				cellA18.setCellValue(totalPortfolioSizeByFreq);
			} else {
				cellA18.setCellValue(0);
			}	
			
			Row row11 = worksheet1.createRow((short) 15);
			Cell cellA19 = row11.createCell((short) 0);
			cellA19.setCellValue(PortrecConstants.TRDAES_WITH_SD_MSP);
			Cell cellA20 = row11.createCell((short) 1);
			
			Long totalSdPortfolioSizeByFreq = null;
			totalSdPortfolioSizeByFreq = regRepPrCptyReconFreqRepository.tradeSDMspQuartely(reconFrequency);
			
			if (null != totalSdPortfolioSizeByFreq) {
				cellA20.setCellValue(totalSdPortfolioSizeByFreq);
			}
			else {
				cellA20.setCellValue(0);
			}
			
			Row row12 = worksheet1.createRow((short) 16);
			Cell cellA21 = row12.createCell((short) 0);
			cellA21.setCellValue(PortrecConstants.TRDAES_WITH_NON_SD_MSP);
			Cell cellA22 = row12.createCell((short) 1);
			
			Long totalNonSdMspPortfolioSizeByFreq = null;
			totalNonSdMspPortfolioSizeByFreq = regRepPrCptyReconFreqRepository.tradeNonSDMspQuartely(reconFrequency);
			
			if (null != totalNonSdMspPortfolioSizeByFreq)
			{
				cellA22.setCellValue(totalNonSdMspPortfolioSizeByFreq);
			}
			else {
				cellA22.setCellValue(0);
			}
			
			Date as_of_date_collateralized=asOfDate;
			
			if(null != as_of_date_collateralized)
			{
				as_of_date_collateralized=	new SimpleDateFormat("yyyy-MM-dd").parse(PortRecUtil
					.convertDateToString_yyyy_MM_dd(as_of_date_collateralized));
			}
			Row row14 = worksheet1.createRow((short) 18);
			Cell cellA25 = row14.createCell((short) 0);
			cellA25.setCellValue(PortrecConstants.TOTAL_COLLATERALIZED_TRADE);
			Cell cellA26 = row14.createCell((short) 1);
			
			Long numOfCollateralizedTrades=null;
			
			if(null != as_of_date_collateralized){
				numOfCollateralizedTrades = regRepPrLiveTradeRepository.totalCollateralizedTrade(reconFrequency,as_of_date_collateralized) ;
			}
			if(null!=numOfCollateralizedTrades)
				cellA26.setCellValue(numOfCollateralizedTrades);
			else
				cellA26.setCellValue(0);
			
			Row row15 = worksheet1.createRow((short) 19);
			Cell cellA27 = row15.createCell((short) 0);
			cellA27.setCellValue(PortrecConstants.TOTAL_NON_COLLATERALIZED_TRADE);
			Cell cellA28 = row15.createCell((short) 1);
			
			Long totalNonCollateralizedTrade = null;
			if (null != totalPortfolioSizeByFreq && null!=numOfCollateralizedTrades && (totalPortfolioSizeByFreq.compareTo(numOfCollateralizedTrades)>0))
			{
				totalNonCollateralizedTrade = totalPortfolioSizeByFreq - numOfCollateralizedTrades;
			}

			if(null!=totalNonCollateralizedTrade)
				cellA28.setCellValue(totalNonCollateralizedTrade);
			else
				cellA28.setCellValue(0);
			
			
			Row row16 = worksheet2.createRow((short) 0);
			prepareSummaryHeader(workbook, row16, (short) 0, PortrecConstants.lEGAL_NAME);
			prepareSummaryHeader(workbook, row16, (short) 1, PortrecConstants.lEGAL_ID);
			prepareSummaryHeader(workbook, row16, (short) 2, PortrecConstants.EMAIL_ADDRESS);
			prepareSummaryHeader(workbook, row16, (short) 3, PortrecConstants.RECON_TYPE);
			prepareSummaryHeader(workbook, row16, (short) 4, PortrecConstants.PORTFOLIO_SIZE);
			prepareSummaryHeader(workbook, row16, (short) 5, PortrecConstants.CPTY_TYPE);
			prepareSummaryHeader(workbook, row16, (short) 6, PortrecConstants.IR_COUNT);
			prepareSummaryHeader(workbook, row16, (short) 7, PortrecConstants.CR_COUNT);
			prepareSummaryHeader(workbook, row16, (short) 8, PortrecConstants.EQ_COUNT);
			prepareSummaryHeader(workbook, row16, (short) 9, PortrecConstants.FX_COUNT);
			prepareSummaryHeader(workbook, row16, (short) 10, PortrecConstants.FX_INTL_COUNT);
			prepareSummaryHeader(workbook, row16, (short) 11, PortrecConstants.COMM_COUNT);
			prepareSummaryHeader(workbook, row16, (short) 12, PortrecConstants.JS_INDICATOR);
			
			Set<Integer> setOfCparty = legalIdMap.keySet();
			
			logger.info("Number of Cp for which Pre Run Report going to generate : " + setOfCparty.size());
			
			int noOfrows = 1;
			for(Integer legalId : setOfCparty)
			{
				CptyReconInformation prCptyInformation = legalIdMap.get(legalId);		
			
				Row row = worksheet2.createRow((short) noOfrows);
				Cell cellA38 = row.createCell((short) 0);
				if (prCptyInformation.getFullLegalName() != null && !prCptyInformation.getFullLegalName().isEmpty()) {
					legalNameValue =prCptyInformation.getFullLegalName();
				} 
				else{
					legalNameValue=PortrecConstants.EMPTY;
				}
				cellA38.setCellValue(legalNameValue);

				Cell cellA39 = row.createCell((short) 1);
				if (String.valueOf(prCptyInformation.getCidCptyId()) !=null ) {
					legalIdValue = String.valueOf(prCptyInformation.getCidCptyId());
				} 
				else{
					legalIdValue=PortrecConstants.EMPTY;
				}
				cellA39.setCellValue(legalIdValue);

				Cell cellA40 = row.createCell((short) 2);
				if (prCptyInformation.getEmailAddress() != null) {
					emailAddressValue = prCptyInformation.getEmailAddress();
				}
				else
					emailAddressValue=PortrecConstants.EMPTY;
				 
				cellA40.setCellValue(emailAddressValue);

				Cell cellA41 = row.createCell((short) 3);
				if (reconFrequency != null) {
					reconTypeValue = reconFrequency.toString();
				} 
				else{
					reconTypeValue=PortrecConstants.EMPTY;}
				
				cellA41.setCellValue(reconTypeValue);
				Cell cellA42 = row.createCell((short) 4);
				if (String.valueOf(prCptyInformation.getPortfolioSize()) != null) {
					portfolioSizeValue = String.valueOf(prCptyInformation.getPortfolioSize());
				}
				else
				{
				portfolioSizeValue=PortrecConstants.EMPTY;
				}
				cellA42.setCellValue(portfolioSizeValue);
				Cell cellA43 = row.createCell((short) 5);
				if (prCptyInformation.getCptyType() != null) {
					cptyTypeValue = prCptyInformation.getCptyType();
				} 
				else
					cptyTypeValue=PortrecConstants.EMPTY;
				cellA43.setCellValue(cptyTypeValue);
				Cell cellA44 = row.createCell((short) 6);
				if (String.valueOf(prCptyInformation.getIrSize()) != null) {
					irCount = String.valueOf(prCptyInformation.getIrSize());
				} 
				else
				{
					irCount=PortrecConstants.EMPTY;
				}
				cellA44.setCellValue(irCount);
				Cell cellA45 = row.createCell((short) 7);
				if (String.valueOf(prCptyInformation.getCrSize()) != null) {
					crCount = String.valueOf(prCptyInformation.getCrSize());
				} 
				else
				{
					crCount=PortrecConstants.EMPTY;
				}
				cellA45.setCellValue(crCount);
				Cell cellA46 = row.createCell((short) 8);
				if (String.valueOf(prCptyInformation.getEquitySize()) != null) {
					eqCount = String.valueOf(prCptyInformation.getEquitySize());
				} 
				else
				{
					eqCount=PortrecConstants.EMPTY;
				}
				cellA46.setCellValue(eqCount);
				Cell cellA47 = row.createCell((short) 9);
				if (String.valueOf(prCptyInformation.getFxSize()) != null) {
					fxCount = String.valueOf(prCptyInformation.getFxSize());
				} 
				else
				{
					fxCount=PortrecConstants.EMPTY;
				}
				cellA47.setCellValue(fxCount);
				Cell cellA48 = row.createCell((short) 10);
				if (String.valueOf(prCptyInformation.getFxIntlSize()) != null) {
					fxIntlCount = String.valueOf(prCptyInformation.getFxIntlSize());
				} 
				else
				{
					fxIntlCount=PortrecConstants.EMPTY;
				}
				cellA48.setCellValue(fxIntlCount);
				Cell cellA49 = row.createCell((short) 11);
				if (String.valueOf(prCptyInformation.getCommoditySize()) != null) {
					commCount = String.valueOf(prCptyInformation.getCommoditySize());
				} 
				else
				{
					commCount=PortrecConstants.EMPTY;
				}
				cellA49.setCellValue(commCount);
				
				Cell cellA50 = row.createCell((short) 12);
				if (prCptyInformation.getJsFlag() != null) {
					jsFLag = prCptyInformation.getJsFlag();
				} 
				else
				{
					jsFLag="N";
				}
				cellA50.setCellValue(jsFLag);
				
				noOfrows ++;
			}
			
			workbook.write(fileOut);
			workbook.dispose();
			fileOut.flush();
			fileOut.close();
			
		} catch (Exception e) {
			throw e;
		}
	}
}
