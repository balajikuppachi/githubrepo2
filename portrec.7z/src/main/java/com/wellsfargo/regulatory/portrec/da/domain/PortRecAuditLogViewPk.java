package com.wellsfargo.regulatory.portrec.da.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PortRecAuditLogViewPk implements Serializable{

	@Column(name = "Legal_Id")
	String legalId = "";

	@Column(name = "Asset_Class")
	String assetClass = "";
	
	@Column(name = "Recon_Date")
	String reconDate = "";
	
	@Column(name = "Affirm_Date_Time")
	Date affirmDate;
	
	public String getLegalId() {
		return legalId;
	}

	public void setLegalId(String legalId) {
		this.legalId = legalId;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	

	public String getReconDate() {
		return reconDate;
	}

	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}

	
	public Date getAffirmDate() {
		return affirmDate;
	}

	public void setAffirmDate(Date affirmDate) {
		this.affirmDate = affirmDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((affirmDate == null) ? 0 : affirmDate.hashCode());
		result = prime * result
				+ ((assetClass == null) ? 0 : assetClass.hashCode());
		result = prime * result + ((legalId == null) ? 0 : legalId.hashCode());
		result = prime * result
				+ ((reconDate == null) ? 0 : reconDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortRecAuditLogViewPk other = (PortRecAuditLogViewPk) obj;
		if (affirmDate == null) {
			if (other.affirmDate != null)
				return false;
		} else if (!affirmDate.equals(other.affirmDate))
			return false;
		if (assetClass == null) {
			if (other.assetClass != null)
				return false;
		} else if (!assetClass.equals(other.assetClass))
			return false;
		if (legalId == null) {
			if (other.legalId != null)
				return false;
		} else if (!legalId.equals(other.legalId))
			return false;
		if (reconDate == null) {
			if (other.reconDate != null)
				return false;
		} else if (!reconDate.equals(other.reconDate))
			return false;
		return true;
	}


}