package com.wellsfargo.regulatory.portrec.mailer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PrEmailAddressValidation {

	@Value("${mail.env.portrec}")
	String enviroment;
	private static Pattern pattern;
	private static Matcher matcher;

	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	
	private final Logger logger = Logger.getLogger(PrEmailAddressValidation.class);

	public boolean validateMailPattern(String email) {
		pattern = Pattern.compile(EMAIL_PATTERN);
		matcher = pattern.matcher(email);
		return matcher.matches();

	}

	public boolean validate(String email) {
		if (validateMailPattern(email.trim())) {
			if (enviroment.equals("DEV")) { 
				if (StringUtils.startsWithAny(email.toLowerCase(), 
						new String[] {"pr_dev1@msgdev.wellsfargo.com".toLowerCase(),"pr_dev2@msgdev.wellsfargo.com".toLowerCase()})) {
					return true;
				}
			} else if (enviroment.equals("SIT")) { 
				if (StringUtils.startsWithAny(email.toLowerCase(), 
						new String[] {"pr_qa1@msgqa.wellsfargo.com".toLowerCase(),"pr_qa2@msgqa.wellsfargo.com".toLowerCase()})) {
					return true;
				}
			} else if (enviroment.equals("UAT")) {
				if (StringUtils.startsWithAny(email.toLowerCase(), 
						new String[] {"pr_qa1@msgqa.wellsfargo.com".toLowerCase(),"pr_qa2@msgqa.wellsfargo.com".toLowerCase()})) {
						return true;
				}
			}else if (enviroment.equals("PROD")) {
				return true;
			}
		}
		return false;
	}

	public String filterValidEmails(String cidEmail) {
		
		List<String> validEmailAddressList = new ArrayList<String>();
		List<String> inValidEmailAddressList = new ArrayList<String>();
		
		if(!StringUtils.isBlank(cidEmail)){
			
			if(cidEmail.contains(";") || cidEmail.contains(",")) {
				
				cidEmail = cidEmail.replaceAll(",", ";");
							
				StringTokenizer strToEmailTokenizer = new StringTokenizer(cidEmail, ";");
				while (strToEmailTokenizer.hasMoreElements()) 
				{
					String emailAddress = strToEmailTokenizer.nextToken();
					
					if (validateMailPattern(emailAddress.trim())) {
						validEmailAddressList.add(emailAddress.trim());
					}else{
						inValidEmailAddressList.add(emailAddress.trim());
					}
				}
			} else if (validateMailPattern(cidEmail.trim())) {
				validEmailAddressList.add(cidEmail.trim());
			} else {
				inValidEmailAddressList.add(cidEmail.trim());
			}
		
			if(!inValidEmailAddressList.isEmpty()){
				logger.error("Invalid email list : "+ Arrays.toString(inValidEmailAddressList.toArray()));
			}
		} 
		
		String validAddress = StringUtils.join(validEmailAddressList, ';');
		
		return validAddress;
	}
	
	
	
}
