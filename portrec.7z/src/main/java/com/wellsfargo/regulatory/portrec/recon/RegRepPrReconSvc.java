package com.wellsfargo.regulatory.portrec.recon;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.dao.RegRepPrCptyReconFreqDaoImpl;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrLiveTradeDaoImpl;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJob;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
public class RegRepPrReconSvc {
	
	public static String PORTFOLIO_SEGMENT_NAME = "RECON";
	
	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;
	
	@Autowired
	RegRepPrLiveTradeDaoImpl regRepPrLiveTradeDaoImpl;
	
	@Autowired
	RegRepPrCptyReconFreqDaoImpl regRepPrCptyReconFreqDaoImpl;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	@Autowired
	TransactionalLoaderServiceForRecon transactionalLoaderServiceforRecon;
	
	@Autowired
	RegRepPrJobDetailRepository regRepPrJobDetailRepository;
	
	RegRepPrJobDetail regRepPrJobDetail;
	
	@Autowired
	RegRepPrIRRecon regRepIRRecon;
	
	@Autowired
	RegRepPrCRRecon regRepCRRecon;

	@Autowired
	RegRepPrEQRecon regRepEQRecon;
	
	@Autowired
	RegRepPrCommRecon regRepCommRecon;

	@Autowired
	RegRepPrFxRecon regRepFXRecon;
	
	private static Logger logger = Logger.getLogger(RegRepPrReconSvc.class);
	
	public void fetchDetails() {
		
		List<RegRepPrJobDetail> jobDetails = regRepPrJobDetailRepository.findByjobName(PORTFOLIO_SEGMENT_NAME);
		if (jobDetails.size() != 1) {
			throw new RuntimeException(
					"Could not initialize Portfolio Segment '"	+ PORTFOLIO_SEGMENT_NAME + "'");
		}
		regRepPrJobDetail = jobDetails.get(0);
		
		logger.info("Starting RegRepPrReconSvc For "	+ regRepPrJobDetail.getJobDesc());
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = transactionalLoaderServiceforRecon.startLoad("RECON", regRepPrJobDetail, new Date());
			 
		List<Date> asOfDateList =  regRepPrLiveTradeRepository.findAsOfDate();
		if(null != asOfDateList) {
			if(asOfDateList.size() == 1){
				Date asOfdate = asOfDateList.get(0);
				
				List<RegRepPrJobExecutionDetail> jobDetailslist = regRepPrJobExecutionDetailRepository.findJobDetailsForAllFileLoads(asOfdate);
				List<RegRepPrJobExecutionDetail> eqJobs = new ArrayList<RegRepPrJobExecutionDetail>();
				List<RegRepPrJobExecutionDetail> commJobs = new ArrayList<RegRepPrJobExecutionDetail>();
				int irJobCounter = 0;
				int crJobCounter = 0;
				int fxJobCounter = 0;
				int commJobCounter = 0;
				int eqJobCounter = 0;
				
				for(RegRepPrJobExecutionDetail jobDetail : jobDetailslist)
				{
					RegRepPrJobDetail jobID = (RegRepPrJobDetail)jobDetail.getJobDetailsId();
					String jobName = jobID.getJobName();
					
					jobName = jobName.replaceAll("\\s","");
					if(jobName.contains(PortrecConstants.ASSETCLASS_IR) && irJobCounter == 0)
					{
						regRepIRRecon.doIRRecon(jobDetail, asOfdate);
						irJobCounter = irJobCounter+1;
					}
					if(jobName.contains(PortrecConstants.ASSETCLASS_CR) && crJobCounter == 0)
					{
						regRepCRRecon.doCRRecon(jobDetail, asOfdate);
						crJobCounter = crJobCounter+1;
					}
					if(jobName.contains(PortrecConstants.ASSETCLASS_EQ) && eqJobCounter < 9)
					{
						eqJobs.add(jobDetail);
						eqJobCounter = eqJobCounter + 1;
					}
					if(jobName.contains(PortrecConstants.ASSETCLASS_FX)  && fxJobCounter == 0)
					{
						regRepFXRecon.doFXRecon(jobDetail, asOfdate);
						fxJobCounter = fxJobCounter+1;
					}
					if(jobName.contains(PortrecConstants.ASSETCLASS_COMM) && commJobCounter < 2)
					{
						commJobs.add(jobDetail);
						commJobCounter = commJobCounter +1;
					}
				}
				
				if(!eqJobs.isEmpty()){
					regRepEQRecon.doEQRecon(eqJobs, asOfdate);
				} 
				if(!commJobs.isEmpty()){
					regRepCommRecon.doCommRecon(commJobs, asOfdate);
				}
				
			} else {
				logger.info("Check As of Date in Trade Table ");
			}
		}
		transactionalLoaderServiceforRecon.completeLoad(regRepPrJobExecutionDetail);
		logger.info("Completed RegRepPrReconSvc For "	+ regRepPrJobDetail.getJobDesc());
	
	}

	@Service
	@Transactional(value="portrec")
	public static class TransactionalLoaderServiceForRecon extends RegRepPrJob{
		@Autowired
		RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;
		
		@PersistenceContext(unitName = "Portrec")
		EntityManager entityManager;
		
		Logger logger = Logger.getLogger(getClass());

		public RegRepPrJobExecutionDetail startLoad(String fileName,
				RegRepPrJobDetail regRepPrJobDetail, Date asOfDate) {

			RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();
			regRepPrJobExecutionDetail.setJobDetailsId(regRepPrJobDetail);
			regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
			regRepPrJobExecutionDetail.setFileName(fileName);
			regRepPrJobExecutionDetail.setJobStatus("PROCESSING");
			regRepPrJobExecutionDetail.setCreateDatetime(new Date());

			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

			return regRepPrJobExecutionDetail;
		}
		
		public void completeLoad(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
								
			regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
			if(regRepPrJobExecutionDetail.getRecodsLoaded() == regRepPrJobExecutionDetail.getRecordsTotal())
			{	
				regRepPrJobExecutionDetail.setJobStatus("SUCCESS");
			}
			else
			{
				regRepPrJobExecutionDetail.setJobStatus("ERROR");
			}
						   
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		}
					
	}

}
