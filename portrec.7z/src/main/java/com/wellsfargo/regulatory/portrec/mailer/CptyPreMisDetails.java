package com.wellsfargo.regulatory.portrec.mailer;

public class CptyPreMisDetails {

	private int cidCptyId;
	
	private String emailAddress;
	private String fullLegalName;
	private String deliveryPortfolioDataEmail;
	private String reconType;
	private int portfolioSizeValue;
	private String cptyTypeValue;
	private int irSize;
	private int crSize;
	private int eqSize;
	private int fxSize;
	private int fxIntlSize;
	private int commSize;
	
	public int getCidCptyId() {
		return cidCptyId;
	}
	public void setCidCptyId(int cidCptyId) {
		this.cidCptyId = cidCptyId;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFullLegalName() {
		return fullLegalName;
	}
	public void setFullLegalName(String fullLegalName) {
		this.fullLegalName = fullLegalName;
	}
	public String getDeliveryPortfolioDataEmail() {
		return deliveryPortfolioDataEmail;
	}
	public void setDeliveryPortfolioDataEmail(String deliveryPortfolioDataEmail) {
		this.deliveryPortfolioDataEmail = deliveryPortfolioDataEmail;
	}
	public String getReconType() {
		return reconType;
	}
	public void setReconType(String reconType) {
		this.reconType = reconType;
	}
	
	public String getCptyTypeValue() {
		return cptyTypeValue;
	}
	public void setCptyTypeValue(String cptyTypeValue) {
		this.cptyTypeValue = cptyTypeValue;
	}
	public int getPortfolioSizeValue() {
		return portfolioSizeValue;
	}
	public void setPortfolioSizeValue(int portfolioSizeValue) {
		this.portfolioSizeValue = portfolioSizeValue;
	}
	public int getIrSize() {
		return irSize;
	}
	public void setIrSize(int irSize) {
		this.irSize = irSize;
	}
	public int getCrSize() {
		return crSize;
	}
	public void setCrSize(int crSize) {
		this.crSize = crSize;
	}
	public int getEqSize() {
		return eqSize;
	}
	public void setEqSize(int eqSize) {
		this.eqSize = eqSize;
	}
	public int getFxSize() {
		return fxSize;
	}
	public void setFxSize(int fxSize) {
		this.fxSize = fxSize;
	}
	public int getFxIntlSize() {
		return fxIntlSize;
	}
	public void setFxIntlSize(int fxIntlSize) {
		this.fxIntlSize = fxIntlSize;
	}
	public int getCommSize() {
		return commSize;
	}
	public void setCommSize(int commSize) {
		this.commSize = commSize;
	}
}
