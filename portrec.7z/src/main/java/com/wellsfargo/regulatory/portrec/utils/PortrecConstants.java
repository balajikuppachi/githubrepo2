package com.wellsfargo.regulatory.portrec.utils;


public class PortrecConstants
{
	
	public static final String SD_CPTY_TYPE = "SD";
	public static final String NON_SD_MSP_CPTY_TYPE = "NON_SD_MSP";
	
	public static final int NON_SD_QUARTERLY_SIZE = 100;
	public static final String FLAG_TRUE = "Y";
	
	public static final int SD_DAILY_SIZE = 500;
	public static final int SD_WEEKLY_SIZE = 51;	
	public static final String PORTREC_AS_OF_DATE_FORMAT = "yyyy-MM-dd";
	public static final String PORTREC_AS_OF_DATE_FORMAT_1 = "yyyyMMdd";
	public static final String PORTREC_JOB_NAME = "portrecJobName";
	public static final String PORTREC_JOB_HEADER_AS_OF_DATE = "asOfDate";
	public static final String PORTREC_JOB_HEADER_RECON_DATE = "reconDate";
	
	public static final String PORTREC_JOB_SUCCESS = "success";
	public static final String PORTREC_JOB_ERROR = "error";
	public static final String PORTREC_JOB_PROCESSING= "processing";
	
	public static final String INTERNAL_TRADE = "internalTrade";
	public static final String AFFILIATE_TRADE = "affiliateTrade";
	public static final String NON_AFFILIATE_TRADE = "nonAffiliateTrade";
	public static final String WELLS_BAID = "wellsBaId";
	public static final String WELLS_LEGAL_ID= "wellsLegalId";
	
	public static final String LEI_MISSING = "leiMissing";
	public final static String QUARTERLY = "QUARTERLY";
	public final static String QUARTER_1 = "QUARTER_1";
	public final static String QUARTER_2 = "QUARTER_2";
	public final static String QUARTER_3 = "QUARTER_3";
	public final static String QUARTER_4 = "QUARTER_4";
	public final static String ANNUAL = "ANNUAL"; 

	public final static String IR = "IR";
	public final static String CR = "CR";
	public final static String EQ = "EQ";
	public final static String COMM = "COMM";
	public final static String FX = "FX";
	public final static String ALL = "ALL";
	
	public final static String ASSETCLASS_IR = "InterestRate";
	public final static String ASSETCLASS_CR = "Credit";
	public final static String ASSETCLASS_EQ = "Equity";
	public final static String ASSETCLASS_COMM = "Commodity";
	public final static String ASSETCLASS_FX = "ForeignExchange";
	public final static String ASSETCLASS_FX_INTL = "FX_INTL";
	
	public final static String UNDERSCORE = "_";
	public final static String HYPHEN = "-";
	public final static String SPACE = " ";
	public final static String EMPTY = "";
	public final static String IR_MT_FILE_INITIAL = "IR_CPTY_DTCC";
	public final static String CR_MT_FILE_INITIAL = "CR_CPTY_DTCC";
	public final static String EQ_MT_FILE_INITIAL = "EQ_CPTY_DTCC";
	public final static String COMM_MT_FILE_INITIAL = "COMM_CPTY_DTCC";
	public final static String FX_MT_FILE_INITIAL = "FX_CPTY_DTCC";
	public final static String LEI_STARTS_WITH_DTCC = "DTCC";
	
	public final static String MT = "MT";
	public final static String VAL = "VAL";
	
	public static final String DOMESTIC = "D";
	public static final String INTERNATIONAL = "I";
	
	public final static String A = "A";
	public final static String Q = "Q";
	public final static String Q1 = "Q1";
	public final static String Q2 = "Q2";
	public final static String Q3 = "Q3";
	public final static String Q4 = "Q4";
	
	public final static String Y = "Y";
	public final static String N = "N";
	
	public static final String NOT_REVIEWED = "N";
	
	public final static String D = "D";
	public final static String I = "I";
	
	public final static String US = "US";
	public final static String BLANK = "";
	public final static String ZERO = "0";
	
	public final static String EXTN_CSV = ".csv";
	
	public final static String CURRENT_DATE = "CURRENT_DATE";
	public final static String PREVIOUS_WEEK = "PREVIOUS_WEEK";
	public final static String DATA_COB="Data cob";
	public final static String PRE_REPORT_HEADING = "Portfolio Reconciliation Pre-Run Report";
	public final static String CATEGORY = "Category";
	public final static String COUNT = "Count";
	public final static String RECON = "Recon";
	public final static String TOTAL_CP_ELIGIBLE_FOR_NOTICE = "Total Counterparties Eligible for Notice";
	public final static String SWAP_DEALER_MSP = "          Swap-Dealers and MSPs";
	public final static String NON_SWAP_DEALER_MSP = "          Non Swap-Dealers and MSPs";
	public final static String TOTAL_MATERIAL_TERM_FILE = "Total Material Terms files";
	public final static String TOTAL_VALUATION_FILE = "Total Valuation files";
	public final static String TOTAL_TRADES_ELIGIBLE_FOR_NOTICE = "Total Trades Eligible for Notice";
	public final static String TRDAES_WITH_SD_MSP = "          Trades with SD/MSP";
	public final static String TRDAES_WITH_NON_SD_MSP = "          Trades with Non SD/MSP";
	public final static String TRADES_WITH_AFFILIATES = "          Trades with Affiliates";
	public final static String TOTAL_COLLATERALIZED_TRADE = "Total Collateralized Trades";
	public final static String TOTAL_NON_COLLATERALIZED_TRADE = "Total Non-Collateralized Trades";
	public final static String TOTAL_AFFILIATE_TRADE = "Total Affiliate Trades";
	public final static String lEGAL_NAME = "Legal Name";
	public final static String lEGAL_ID = "Legal Id";
	public final static String lEI = "LEI";
	public final static String EMAIL_ADDRESS = "Email address";
	public final static String RECON_TYPE = "Recon Type";
	public final static String PORTFOLIO_SIZE = "Portfolio Size";
	public final static String CPTY_TYPE = "Counterparty Type";
	public final static String CR_COUNT = "CR Count";
	public final static String FX_COUNT = "FX Count";
	public final static String FX_INTL_COUNT = "FX INTL Count";
	public final static String EQ_COUNT = "EQ Count";
	public final static String IR_COUNT = "IR Count";
	public final static String COMM_COUNT = "COM Count";
	
	public final static String PR_PRE_FILE_NAME = "PrPreRun";
	
	public final static String POST_REPORT_HEADING = "Portfolio Reconciliation Post-Run Summary Report";
	public final static String MATERIAL_TERMS = "Material Terms";
	public final static String FILES_ISSUED_TO_CP = "     Files Issued to Counterparty";
	public final static String AFFIRMED = "     Affirmed";
	public final static String DISAFFIRMED = "     DisAffirmed";
	public final static String NO_RESPONSE = "     No Response";
	public final static String VALUATION = "Valuation";
	public final static String EMAIL_BOUNCEBACKS = "Email Bouncebacks";
	
	public final static String ASSET_CLASS = "Asset Class";
	public final static String FILE_NAME = "File Name";
	public final static String RECON_DATE = "Recon Date";
	public final static String FILE_TYPE = "File Type";
	public final static String AFFIRM = "Affirmed";
	public final static String AFFIRM_WITH_TIMESTAMP = "Affirm Update Time Stamp";
	public final static String COMMENTS = "Comments";
	public final static String JS_INDICATOR ="J&S Indicator";
	public final static String PR_POST_FILE_NAME = "PrPostRun";
	
	public final static String CONTROL_REPORT_HEADING ="Portfolio Reconciliation Summary Report";
	public final static String TOTAL_CP_SUBMITTED_TO_DA = "Total Counterparties Processed/Submitted to DA";
	public final static String TOTAL_CP_LOADED_TO_DA = "Total Counterparties Loaded to DA";

	
	public final static String BUS_ACC_ID = "Bus Acct ID";
	public final static String CTRL_EMAIL_ADDRESS = "Recipient Email";
	public final static String CFTC_REG = "CFTC Registration";
	public final static String VAL_ATTACHED = "Valuation Attached";
	public final static String RECON_PERIOD = "Recon Period";
	public final static String MT_ASSET_CLASS = "MT Asset Class";
	public final static String ALGO_CA_NAME = "Algo CA Name";
	public final static String PR_CONTROL_FILE_NAME = "PrControlSummary";
	
	public final static String DUC_PORTFOLIO_SIZE = "did not exceed 100 swaps during the year";
	public final static String FREQUENCY = "once per annum";
	public final static String PARTICIPANT = "not a Swaps Dealer or Major Swap Participant";
	public final static String DUC_FILE_NAME = "Duc_Domestic";
	public final static String DUC_INTL_FILE_NAME = "Duc_International";
	
	public final static String EMAIL_EXTN_COM = ".com";
	public final static String AT_THE_RATE = "@";
	public final static String EXCEPTION = "Exception";
	public final static String VALID = "Valid";
	
	public final static String PREVIOUS_RECORDS = "PREVIOUS_RECORDS";
	public final static String COMMA = ",";
	
	public final static String LEGAL_ID_NULL = "legalIdIsZero";
	public final static String REPORT_DATE = "Report Date";
	public final static String REPORT_RUNDATE = "Report Run Date";
	public static final String LIVE_TRADES = "live-trades";
	public static final String SRC_FX ="src-fx";
	public static final String ALGO_VAL ="algo-val";
	public static final String DTCC = "dtcc";
	public static final String ICE = "ice";
	public static final String DTCC_CR = "dtcc-cr";
	public static final String DTCC_ICE = "dtcc-ice";
	public static final String ICE_DB_LOAD = "icedbload";
	public static final String TRUE = "true";
	public static final String CLOSE_OF_BUSINESS_DATE = "CLOSE_OF_BUSINESS_DATE";
	
	
}
