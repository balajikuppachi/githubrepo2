package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrEqPositionReport;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrDtccEQVSCSVReader extends LoaderHelper<RegRepPrEqPositionReport> {
	public static String PORTFOLIO_SEGMENT_NAME = "Equity_VS, DTCC";
	public static String ASSETCLASS = "Equity";
	@Value("${file.dtcceqvs.epr.header}") int headerRows;
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.EQ_VS;
	}
	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}
	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new CsvWithHeaderReader(inputStream, headerRows);
	}
	@Override
	public RegRepPrEqPositionReport parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrEqPositionReport dtccTrade = new RegRepPrEqPositionReport();
		
		dtccTrade.setUti(fields[1]);
		//dtccTrade.setAssetClass(fields[2]);
		dtccTrade.setAssetClass(ASSETCLASS);
		dtccTrade.setSecAssetClass(fields[3]);
		dtccTrade.setUsi(fields[4] + fields[5]); //USI Prefix + USI Value
		//113 is party 1 lei  if 113 is empty then pick from 14 and 114 is party 2 lei  if 114 is empty then pick from 17
		String tradeParty1 = "";
		String tradeParty2 = "";
		if(StringUtils.isBlank(fields[113]))
			tradeParty1 = fields[14];
		else
			tradeParty1 = getLei(fields[113]);
		if(StringUtils.isBlank(fields[114]))
			tradeParty2 = fields[17];	
		else
			tradeParty2 = getLei(fields[114]);
		
		for (String s : exclude){
			if (tradeParty1.contains(s)) tradeParty1 = tradeParty1.replace(s, "");
			if (tradeParty2.contains(s)) tradeParty2 = tradeParty2.replace(s, "");
			}
		
		dtccTrade.setParty1(tradeParty1); //Party 1 Value
		dtccTrade.setParty2(tradeParty2); //Party 2 Value
		dtccTrade.setLeiCp(tradeParty1);
		dtccTrade.setLeiUs(tradeParty2);
		
		dtccTrade.setParty1Role(fields[19]);
		dtccTrade.setParty2Role(fields[20]); 
		
		if(StringUtils.isNotBlank(fields[18]))
			dtccTrade.setTradeParty2Name(fields[18]);
		
		dtccTrade.setExecutionVenue(fields[36]);
		dtccTrade.setBuyer(fields[70]);
		dtccTrade.setWeBuySell(fields[145]); // seller Field : Variance Seller in Report.
		
		dtccTrade.setReportingJurisdiction(fields[75]);
		dtccTrade.setAdditionalRepository1(fields[79]);
		dtccTrade.setReportedValuation(fields[91]);
		dtccTrade.setTradeParty1UspersonIndicator(fields[99]);
		dtccTrade.setTradeParty2UspersonIndicator(fields[100]);
		dtccTrade.setTradeParty1FinancialEntity(fields[101]);
		dtccTrade.setTradeParty2FinancialEntity(fields[102]);
		dtccTrade.setUnderlyingAssetIdentifierType(fields[266]); //previously (fields[133])

		dtccTrade.setUnderlyingAssets(fields[267]); //previously (fields[134])
		dtccTrade.setUnderlyingAssetsWeighting(fields[272]); //previously (fields[139])
		dtccTrade.setUnderlyingAssetsNotional(fields[273]);//previously (fields[140])
		dtccTrade.setUnderlyingAssetsNotionalCurr(fields[274]);//previously (fields[141])
		
		
		if(StringUtils.isNotBlank(fields[283]))//previously (fields[150])
			dtccTrade.setTradeDate(DateUtilLoader.getDateFromString(fields[283]));//previously (fields[150])
		
		// TODO : Termination Date : Mapping not known
		if(StringUtils.isNotBlank(fields[286]))//previously (fields[153])
			dtccTrade.setMaturityDate(DateUtilLoader.getDateFromString(fields[286]));//previously (fields[153])
		
		if(StringUtils.isNotBlank(fields[286]))//previously (fields[153])
			dtccTrade.setValuationDate(DateUtilLoader.getDateFromString(fields[286]));//previously (fields[153])
		
		// TODO : Equity Leg Final Valuation Date : Mapping not known
		if(StringUtils.isNotBlank(fields[286]))//previously (fields[153])
			dtccTrade.setEqLegFinalValuationDate(DateUtilLoader.getDateFromString(fields[286]));//previously (fields[153])
		
		if(StringUtils.isNotBlank(fields[295]))//previously (fields[162])
			dtccTrade.setEquityVarianceStrikePrice(convertStrToBigDecimalForNotionalAmt(fields[295]));//previously (fields[162])
			
		if(StringUtils.isNotBlank(fields[297]))//previously (fields[164])
			dtccTrade.setVolatilityStrikePrice(convertStrToBigDecimalForNotionalAmt(fields[297]));//previously (fields[164])
		
		// TODO : Mapping not known
		if(StringUtils.isNotBlank(fields[23]))
			dtccTrade.setParty1VegaNotionalAmount(convertStrToBigDecimalForNotionalAmt(fields[23]));
		
		dtccTrade.setVegaNotionalCurr(fields[24]);
		if(StringUtils.isNotBlank(fields[295]))//previously (fields[162])
			dtccTrade.setInitialPrice(convertStrToBigDecimalForNotionalAmt(fields[295]));//previously (fields[162])
		
		dtccTrade.setPriceNotation("");			
		dtccTrade.setPriceNotationType("");
		if(StringUtils.isNotBlank(fields[23]))
			dtccTrade.setParty1NotionalAmount(convertStrToBigDecimalForNotionalAmt(fields[23]));
		dtccTrade.setParty1NotionalCurr("");
		if(StringUtils.isNotBlank(fields[23]))
			dtccTrade.setPremiumAmount(convertStrToBigDecimalForNotionalAmt(fields[23]));		
		
		
			dtccTrade.setPremiumAmount(convertStrToBigDecimalForNotionalAmt(fields[23]));		
		dtccTrade.setEqLegValuationFreqPeriod("");			
		dtccTrade.setEqLegValuationFreqPeriodMult("");		
		dtccTrade.setFltLegPaymentFreqPeriod("");			
		dtccTrade.setFltLegPaymentFreqPeriodMult("");
		if(StringUtils.isNotBlank(fields[286])) //previously (fields[153])
			dtccTrade.setEqLegPaymentDate(DateUtilLoader.getDateFromString(fields[286]));//previously (fields[153])
		if(StringUtils.isNotBlank(fields[286]))//previously (fields[153])
			dtccTrade.setFltLegPaymentDate(DateUtilLoader.getDateFromString(fields[286]));//previously (fields[153])
		if(StringUtils.isNotBlank(fields[286]))//previously (fields[153])
			dtccTrade.setEqLegValuationDate(DateUtilLoader.getDateFromString(fields[286]));//previously (fields[153])
		dtccTrade.setCollaterlized(fields[72]);
		dtccTrade.setAsOfDate(asofDate);
		dtccTrade.setSubmittedFor(fields[11]);
		return dtccTrade;
	}
	@Override
	public boolean validate(RegRepPrEqPositionReport trade) {
		boolean canLoad = false;
		String repJur = trade.getReportingJurisdiction();
		if(repJur.contains("CFTC") || repJur.isEmpty() || (repJur==null)){
			canLoad = true;
		}	
		
		return canLoad;
	}
	@Override
	public RegRepPrEqPositionReport getTableName() {
		return new RegRepPrEqPositionReport();
	}
	@Override
	public boolean deletePrevDayRecords() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public String loadNextJob() {
		// TODO Auto-generated method stub
		return null;
	}	
	
}
