package com.wellsfargo.regulatory.portrec.mailer;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.da.domain.PortRecAuditLogView;
import com.wellsfargo.regulatory.portrec.da.domain.PortrecFilesList;
import com.wellsfargo.regulatory.portrec.da.domain.PortrecFilesListPk;
import com.wellsfargo.regulatory.portrec.da.repository.PortRecAuditLogViewRepository;
import com.wellsfargo.regulatory.portrec.da.repository.PortrecFilesListRepository;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrDaReport;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
public class DerivativesAccessService {
	
	private final Logger logger = Logger.getLogger(DerivativesAccessService.class);
	
	@Autowired
	PortrecFilesListRepository portrecFilesListRepository;
	
	@Value ("${portrec.nfs.folder}") String nfsFolder;
	
	@Value("${portrec.da.batch.commit.size}")	String dabatchSizeStr;
	
	@Autowired
	PortRecAuditLogViewRepository portRecAuditLogViewRepository;
	

	public List<PortrecFilesList> readPortrecFilesList() {	
		Iterable<PortrecFilesList> listOfGeneratedFiles = portrecFilesListRepository.findAll();
		List<PortrecFilesList> generatedFiles = new ArrayList<PortrecFilesList>();
		
		if(null != listOfGeneratedFiles){
			generatedFiles = (List<PortrecFilesList>) listOfGeneratedFiles;
		}
		
		return generatedFiles;
	}
	
	public void createPortrecFileListEntry(int legalId, String assetClass, String fileName, String period, Date reconDate, String fileTag) {		
			
		logger.info("Saving into PORT_REC_FILES_LIST. Legal Id = [" + legalId + "], Asset Class = [" + assetClass + "]");
		
		PortrecFilesList portrecFile = new PortrecFilesList();
		portrecFile.setFileName(fileName);
		portrecFile.setDirPath(nfsFolder);
		portrecFile.setPeriod(period);
		portrecFile.setFileTag(fileTag);
		portrecFile.setReviewed(PortrecConstants.NOT_REVIEWED);
		
		PortrecFilesListPk portrecFilesListPk = new PortrecFilesListPk();
		portrecFilesListPk.setCptyId(String.valueOf(legalId));
		portrecFilesListPk.setReconDate(PortRecUtil.convertDateToString_MMddyyyy(reconDate));
		portrecFilesListPk.setTemplateType(assetClass);
		
		portrecFile.setPortrecFilesListPk(portrecFilesListPk);
		
		portrecFilesListRepository.save(portrecFile);
	}
	
	
	public List<PortRecAuditLogView> readUserAcknowledgement(String date) {		
		Iterable<PortRecAuditLogView> listOfCpty = portRecAuditLogViewRepository.findForReconDate(date);
		List<PortRecAuditLogView> cptyAcknwledges = new ArrayList<PortRecAuditLogView>();
		
		if(null != listOfCpty){
			cptyAcknwledges = (List<PortRecAuditLogView>) listOfCpty;
		}
		
		return cptyAcknwledges;
	}
	
	public void persistDaMetaData(List<RegRepPrDaReport> daReports) {
		
		logger.info("Start persisting records into PORT_REC_FILES_LIST table ");
		long timeStart = System.currentTimeMillis();
		int batchSize = 0;
		
		if (null != dabatchSizeStr) 
		{
			batchSize = Integer.parseInt(dabatchSizeStr);
		}
		
		List<PortrecFilesList> portrecFilesList = new ArrayList<PortrecFilesList>();
		
		for(RegRepPrDaReport daReport : daReports){
			
			PortrecFilesList portrecFile = new PortrecFilesList();
			portrecFile.setFileName(daReport.getFileName());
			portrecFile.setDirPath(nfsFolder);
			
			String period = daReport.getReconFreq();
			portrecFile.setPeriod(period.substring(0,1));
			portrecFile.setFileTag(daReport.getMtValType());
			portrecFile.setReviewed(PortrecConstants.NOT_REVIEWED);
			portrecFile.setFileException(daReport.getFileException());
			portrecFile.setFileExceptionReason(daReport.getFileExceptionReason());
			
			PortrecFilesListPk portrecFilesListPk = new PortrecFilesListPk();
			portrecFilesListPk.setCptyId(String.valueOf(daReport.getCidCptyId()));
			portrecFilesListPk.setReconDate(PortRecUtil.convertDateToString_MMddyyyy(daReport.getAsOfDate()));
			portrecFilesListPk.setTemplateType(daReport.getAssetClass());
			
			portrecFile.setPortrecFilesListPk(portrecFilesListPk);
			
			portrecFilesList.add(portrecFile);
			
			if (portrecFilesList.size() == batchSize)
			{
				//logger.info("Persist records into PORT_REC_FILES_LIST table ");
				portrecFilesListRepository.save(portrecFilesList);
				portrecFilesList.clear();
			}
		}
		
		portrecFilesListRepository.save(portrecFilesList);
		portrecFilesList.clear();
	
		long timeEnd = System.currentTimeMillis();
		logger.info("End persisting records into PORT_REC_FILES_LIST table ");
		logger.info("Total time taken in DA update Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));
		
	}
	
	public List<PortRecAuditLogView> getUserAffirmedRecords(Date prevAffirmDate) {		
		
		Iterable<PortRecAuditLogView> listOfCpty = portRecAuditLogViewRepository.findRecordsAfterPrevAffirmDate(prevAffirmDate);
		List<PortRecAuditLogView> cptyAcknwledges = new LinkedList<PortRecAuditLogView>();
		
		if(null != listOfCpty){
			cptyAcknwledges = (List<PortRecAuditLogView>) listOfCpty;
		}
		
		return cptyAcknwledges;
	}
	
	public List<PortRecAuditLogView> getAllPortRecAuditLogView() {	
		
		Iterable<PortRecAuditLogView> listOfCpty = portRecAuditLogViewRepository.findRecordsOrderByAffirmDate();
		List<PortRecAuditLogView> cptyAcknwledges = new LinkedList<PortRecAuditLogView>();
		
		if(null != listOfCpty){
			cptyAcknwledges = (List<PortRecAuditLogView>) listOfCpty;
		}
		
		return cptyAcknwledges;
	}
	
}
