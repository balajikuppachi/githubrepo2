package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrIceOpenTransaction;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;


public interface RegRepPrReconPositionRptRepository extends CrudRepository<RegRepPrIceOpenTransaction, Long> {
	
	@Query("select openPosition from RegRepPrIceOpenTransaction openPosition where openPosition.runDate=?")
	public List<RegRepPrIceOpenTransaction>  findByRunDate(Date date);

}
