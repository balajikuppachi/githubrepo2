package com.wellsfargo.regulatory.portrec.mailer;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;

@Component
@ManagedResource(description = "Derivate Access File Upload Service")
public class DerivativesAccessFileUploadService {

	private final Logger logger = Logger.getLogger(DerivativesAccessFileUploadService.class);
	
	//@Value("${da.file.date}")	String daFileDate;
	@Value("${da.src.directory}")	String daSrcDirectory;
	@Value("${da.des.directory}")	String daDestDirectory;
		
	@Value("${da.file.upload.script}") String daFileUploadScript;
	
	@ManagedOperation(description = "Starting File Upload Process")
	public void uploadDaFiles(String daFileAsOfDate) throws PortrecException {
		
		logger.info("===============Inside DerivateAccessFileUploadService================");
		
		BufferedReader stdInput = null;
		BufferedReader stdError = null;
		
		String[] command = { daFileUploadScript.trim(),daFileAsOfDate.trim(), daSrcDirectory.trim(), daDestDirectory.trim() };
		
		int intVal = -1;
		
		try {
			Process p = null;			
			logger.info("===============Start Executing script================");
			p = Runtime.getRuntime().exec(command);
			logger.info("===============After Executing script================");
			stdInput = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			stdError = new BufferedReader(new InputStreamReader(
					p.getErrorStream()));
			String line;
			
			line = stdInput.readLine();
			while (line != null) {
				logger.info(line);
				line = stdInput.readLine();
			}
			
			line = stdError.readLine();
			while (line != null) {
				logger.info(line);
				line = stdError.readLine();
			}

			intVal = p.waitFor();
			try {
				if (stdInput != null)
					stdInput.close();
			} catch (Exception ignored) {
			}
			try {
				if (stdError != null)
					stdError.close();
			} catch (Exception ignored) {
			}

		} catch (Exception e) {
			String errorString = "Error in moving MT and VAL file to DA location";
			throw new PortrecException("DerivativesAccessFileUploadService-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString, e);
		}

	}
	
}
