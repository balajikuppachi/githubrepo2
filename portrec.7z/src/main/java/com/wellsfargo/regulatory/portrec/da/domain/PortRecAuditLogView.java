package com.wellsfargo.regulatory.portrec.da.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Port_Rec_Audit_Log_View")
public class PortRecAuditLogView {

	@EmbeddedId
	private PortRecAuditLogViewPk portRecAuditLogViewPk;
	
	@Column(name = "User_ID")
	String userId;
	
	@Column(name = "File_Name")
	String fileName = "";
	
	@Column(name = "Affirmed_Flag")
	String affirmedFlag = "";
	
	/*@Column(name = "Affirm_Date_Time")
	Date affirmDate;*/
	
	@Column(name = "User_Comment")
	String userComment;

	@Column(name = "Port_Rec_Period")
	String portRecPeriod = "";

	public PortRecAuditLogViewPk getPortRecAuditLogViewPk() {
		return portRecAuditLogViewPk;
	}

	public void setPortRecAuditLogViewPk(PortRecAuditLogViewPk portRecAuditLogViewPk) {
		this.portRecAuditLogViewPk = portRecAuditLogViewPk;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getAffirmedFlag() {
		return affirmedFlag;
	}

	public void setAffirmedFlag(String affirmedFlag) {
		this.affirmedFlag = affirmedFlag;
	}

	/*public Date getAffirmDate() {
		return affirmDate;
	}

	public void setAffirmDate(Date affirmDate) {
		this.affirmDate = affirmDate;
	}*/

	public String getUserComment() {
		return userComment;
	}

	public void setUserComment(String userComment) {
		this.userComment = userComment;
	}

	public String getPortRecPeriod() {
		return portRecPeriod;
	}

	public void setPortRecPeriod(String portRecPeriod) {
		this.portRecPeriod = portRecPeriod;
	}

}