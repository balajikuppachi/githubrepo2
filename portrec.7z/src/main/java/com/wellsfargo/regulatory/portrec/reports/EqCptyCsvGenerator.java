package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrEqPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.mailer.CptyDerivativeAccessService;
import com.wellsfargo.regulatory.portrec.mailer.PrExtractsTo;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrEqPositionReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class EqCptyCsvGenerator {
	
	private final Logger logger = Logger.getLogger(EqCptyCsvGenerator.class);
	
	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	@Autowired
	RegRepPrEqPositionReportRepository repPrEqPositionReportRepository;
	
	@Autowired
	EqDataCsvWriter eqDataCsvWriter;
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;

	public PrExtractsTo createFile(List<String> counterPartyLeiList, Long legalId, Date asOfDate, String frequency) throws Exception {
		
		boolean eqFileFlag = false;
		PrExtractsTo reportProp = new PrExtractsTo();
		reportProp.setAssetClass(PortrecConstants.EQ);
		
		boolean maskingFlag = portRecBusinessUtil.isCptyMaskingRequired(frequency);
		
		StringBuilder eqMtFileNameBuffer = new StringBuilder();
		
		eqMtFileNameBuffer.append(PortrecConstants.EQ_MT_FILE_INITIAL).append(PortrecConstants.UNDERSCORE).append(legalId).append(PortrecConstants.UNDERSCORE).append(PortRecUtil.convertDateToString_yyyyMdd(asOfDate)).
		append(PortrecConstants.UNDERSCORE).append(frequency.toUpperCase().charAt(0)).append(PortrecConstants.EXTN_CSV);

		String eqMtFileName = eqMtFileNameBuffer.toString();
		
		File eqMtFile  = new File(outputFolderName, eqMtFileName);
		
		List<RegRepPrEqPositionReport> cptyEqPositionsByLegalId = null;
		
		for(String counterPartyLei : counterPartyLeiList){
			
			List<RegRepPrEqPositionReport> cptyEqPositionsByLei = null;
			if(null!=counterPartyLei){
				cptyEqPositionsByLei = repPrEqPositionReportRepository.findCptyPositionsByLeiAndDate( asOfDate,counterPartyLei, counterPartyLei);
			}
			
			if(null != cptyEqPositionsByLei && cptyEqPositionsByLei.size() > 0){
				logger.info("Number of Cpty EQ Dtcc Positions :["+ cptyEqPositionsByLei.size() + "] with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
				eqFileFlag = true;
				
				if(!eqMtFile.exists()){
					eqMtFile.mkdirs();
				}
				
				if(null == cptyEqPositionsByLegalId){
					cptyEqPositionsByLegalId = new ArrayList<RegRepPrEqPositionReport>();
				}
				cptyEqPositionsByLegalId.addAll(cptyEqPositionsByLei);
				
			}else{
				logger.info("No records found for Cpty EQ Dtcc Position with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
		}
		
		if(eqFileFlag)
		{
			int eqCount = generateMTFile(cptyEqPositionsByLegalId,eqMtFile, maskingFlag);
			reportProp.setEqCount(eqCount);
			
			if(eqCount > 0){
				reportProp.setEqMtFileName(eqMtFileName);
				logger.info("EQ MT generated at  "+ outputFolderName);	
			}
		}
		
		reportProp.setFlag(eqFileFlag);
		return reportProp;
	}
	
	private int generateMTFile(List<RegRepPrEqPositionReport> cptyEqPositionsByLegalId, File eqMtFile, boolean maskingFlag) throws Exception 
	{
		Map<String,RegRepPrEqPositionReport> tradeMap = new ConcurrentHashMap<String, RegRepPrEqPositionReport>();
		int count = 0;
		
		try{
			for(RegRepPrEqPositionReport eqPositionReport : cptyEqPositionsByLegalId){	
				RegRepPrEqPositionReport trade=new RegRepPrEqPositionReport();
				BeanUtils.copyProperties(eqPositionReport, trade);
				tradeMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			eqDataCsvWriter.generateFile(eqMtFile, tradeMap, "DTCC", maskingFlag);
		}
		catch(Exception ce){
			throw ce;
		}
		
		count = tradeMap.size();
		
		return count;
	}
	
}
