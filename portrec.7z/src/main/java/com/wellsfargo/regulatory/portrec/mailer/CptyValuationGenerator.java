package com.wellsfargo.regulatory.portrec.mailer;

import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrAlgoValuation;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrAlgoValuationRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class CptyValuationGenerator {
	
	private final Logger logger = Logger.getLogger(CptyValuationGenerator.class);
	
	@Value("${file.portrec.data.extracts}") String valuationFilePath;
	
	@Autowired
	RegRepPrAlgoValuationRepository regRepPrAlgoValuationRepository;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	public PrExtractsTo generateValuationFile(Long legalId, Date asOfDate, String frequency, long jobExecutionId, List<Integer> listofLegalID) {
		
		logger.info("Start generating VAL - legalId :[" + legalId + "], asOfDate :["+ asOfDate +"]");
		
		PrExtractsTo valExTo = new PrExtractsTo();
		
		String valuationFileName = "CPPortfolio-LegalId-" + legalId + PortrecConstants.HYPHEN + PortRecUtil.convertDateToString_yyyyMdd(asOfDate) + PortrecConstants.HYPHEN + frequency.toUpperCase().charAt(0) + ".csv";
		List<RegRepPrAlgoValuation> entries= new ArrayList<RegRepPrAlgoValuation>();
		int valSize = 0;
		try {
			
			if(null != listofLegalID && !listofLegalID.isEmpty())
			{
				for (Integer lglID : listofLegalID){
					List<RegRepPrAlgoValuation> entriesperLegalID=regRepPrAlgoValuationRepository.findAlgoValuationByLegalIdAndCobDate(new BigInteger(String.valueOf(lglID)),asOfDate);
					entries.addAll(entriesperLegalID);
				}
			} else {
				// One LEI may be mapped to multiple Legal Ids, hence we have to consider portfolio size for all Legal Ids
				List<RegRepPrAlgoValuation> entriesperLegalID=regRepPrAlgoValuationRepository.findAlgoValuationByLegalIdAndCobDate(new BigInteger(String.valueOf(legalId)),asOfDate);
				entries.addAll(entriesperLegalID);
			}
			
			
			if(null != entries && entries.size() >0){
				
				valSize = entries.size();
				
				File file  = new File(valuationFilePath, valuationFileName);
				FileWriter fw = new FileWriter(file);
				fw.append("TradeID,ProductID,TradeDate,EndDate,MaturityDate,Notional1,Not. Ccy,PV,PVCcy\n");
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
				DecimalFormat numberFormat = new DecimalFormat("#0.00#");
				try {
					
					for (RegRepPrAlgoValuation entry : entries) {
						fw
						.append(entry.getSourceSystem().concat(entry.getTradeId()).concat(PortRecUtil.convertDateToString_yyyyMdd(entry.getTradeDate()))).append(',')			
						.append(entry.getProductId()).append(',')
						.append(PortRecUtil.safeDateFormat(dateFormat, entry.getTradeDate())).append(',')
						.append("").append(',')
						.append(PortRecUtil.safeDateFormat(dateFormat, entry.getMaturityDate())).append(',')
						.append(PortRecUtil.safeNumberFormat(numberFormat, entry.getNotional1())).append(',')
						.append(entry.getNotional1Ccy()).append(',')	
						.append(PortRecUtil.safeStringFormatAsNumberforPV(numberFormat, entry.getPv())).append(',')
						.append(entry.getPvCcy()).append(',')
						.append('\n');
					}
					
				} catch(Exception ae) {
					throw ae;
				} finally {
					fw.close();
				}
				
				logger.info("VAL For Counterparty '" + legalId + "' has been generated: " + file.getCanonicalPath());
			}
		
		} catch(Exception ae) {
			String errorMsg = "Error generating VAL File";
			try {
				portrecExceptionLogger.logExceptionScenario("CptyValuationGenerator", errorMsg, ae, jobExecutionId, legalId);
			} catch (Exception e) {
				logger.error("Exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}
			
			valuationFileName = null;
			valSize = 0;
		}
		
		valExTo.setValFileName(valuationFileName);
		valExTo.setValCount(valSize);
		
		logger.info("End generating VAL - legalId :[" + legalId + "], asOfDate :["+ asOfDate +"]");
		
		return valExTo;
	}
	
}
