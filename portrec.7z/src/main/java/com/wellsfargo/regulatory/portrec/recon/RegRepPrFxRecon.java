package com.wellsfargo.regulatory.portrec.recon;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrEqPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrFxPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrFxPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
public class RegRepPrFxRecon {
	@Autowired
	RegRepPrFxPositionReportRepository repPrFxPositionReportRepository;
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	private static Logger logger = Logger.getLogger(RegRepPrFxRecon.class);

	@Autowired
	RegRepPrReconHelper regRepPrReconHelper;
	
	@Value("${portrec.recon.file.Location}")
	String portrecReconFileLoc;
	
	
	public void doFXRecon(RegRepPrJobExecutionDetail jobDetail, Date asOfdate) {
		int fxLiveTradeCount = 0;
		int dtccPosCount =0;
		int dtccNotMatchingPos = 0;
		
		logger.info("Starting FX Recon ");
		List<RegRepPrLiveTrade> liveTrades = regRepPrLiveTradeRepository.findTradesBasedonAssetClass(PortrecConstants.ASSETCLASS_FX);
			liveTrades.addAll(regRepPrLiveTradeRepository.findTradesBasedonAssetClass(PortrecConstants.ASSETCLASS_FX_INTL));
		
			fxLiveTradeCount = liveTrades.size();
		Map<String,RegRepPrFxPositionReport> dtccUSIMap = new HashMap<String, RegRepPrFxPositionReport>();
		Map<String, RegRepPrLiveTrade> regrepUSIMap = new HashMap<String, RegRepPrLiveTrade>();
			
		logger.info("Size of LiveTrades for FX Trades : "	+	fxLiveTradeCount);
		
		List<RegRepPrFxPositionReport> dtccUSIList = null;
		
		if(null != jobDetail.getAsOfDate())
		{
			long startTime = System.currentTimeMillis();
			dtccUSIList =  repPrFxPositionReportRepository.findPositionsByDate(jobDetail);
			long endTime = System.currentTimeMillis();
			logger.info("Total Time Taken to get FX Position Counts : " + (endTime - startTime));
		}
		if(null != dtccUSIList) 
		{
			dtccPosCount = dtccUSIList.size();
			logger.info("Size of FX Positions "	+	dtccPosCount);
				for(RegRepPrFxPositionReport dtccUSI : dtccUSIList)
				{
					String usi = dtccUSI.getUsiValue();
					String submittedFor = dtccUSI.getSubmittedFor();
					String tradeParty1 = dtccUSI.getTradeParty1Lei();
					String tradeParty2 = dtccUSI.getTradeParty1Lei();
			
						if(null != usi && !submittedFor.contains("F226TOH6YD6XJB17KS62") 
								&& !tradeParty2.contains("F226TOH6YD6XJB17KS62") && !tradeParty1.contains("F226TOH6YD6XJB17KS62")) 
						{
							dtccUSIMap.put(usi, dtccUSI);
						}
				}	
		
				
				for(RegRepPrLiveTrade liveTrade : liveTrades){
					String usi = liveTrade.getUsi();
					String reconCpty = liveTrade.getReconCpty();
					if(dtccUSIMap.containsKey(usi)){
								dtccUSIMap.remove(usi);
					} else if(!reconCpty.contains("F226TOH6YD6XJB17KS62")){
						regrepUSIMap.put(liveTrade.getUsi(), liveTrade);
					}
				}
				
				dtccNotMatchingPos = dtccUSIMap.size();
				fxLiveTradeCount = regrepUSIMap.size();
				logger.info("Size of FX Positions Not matching : "	+	dtccNotMatchingPos + " And Live Trades : " + fxLiveTradeCount);
				
				if(fxLiveTradeCount>0){
					regRepPrReconHelper.generateliveTradeFile(PortrecConstants.ASSETCLASS_FX, regrepUSIMap, asOfdate);
				}
				if(dtccNotMatchingPos>0){
					generateFXDtccPosFile(PortrecConstants.ASSETCLASS_FX,dtccUSIMap, asOfdate);
				}
		}
	}
	
	private void generateFXDtccPosFile(String assetClass, Map<String, RegRepPrFxPositionReport> dtccUSIMap, Date asOfdate) {
		
		DateFormat formatter ; 
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reconFileName = "DTCC_Recon_"+assetClass+"_"+ formatter.format(asOfdate) +".xls";
		
		List<String> liveTrades1 = regRepPrLiveTradeRepository.findTradesonAssetClassandQN(assetClass);
		Map<String, String> usiLiveMapN = new HashMap<String, String>();
		
		for(String liveTrade : liveTrades1){
			usiLiveMapN.put(liveTrade, assetClass);
		}
		
		File dtccFolder = new File(portrecReconFileLoc+File.separator+ asOfdate);
	   	 File irFile;
	   	 if (dtccFolder.isDirectory()) {
		   	 	 irFile = new File(dtccFolder +File.separator+reconFileName);
		 }
	   	 else {
	   		dtccFolder.mkdirs();
	   		irFile = new File(dtccFolder +File.separator+reconFileName);
	   	 }
	   	FileWriter fw = null;
		try {
			fw = new FileWriter(irFile);
			fw.append("USI").append("\t").append("SubmittedFor").append("\t").append("TradeParty1").append("\t").append("TradeParty2").append("\t").
			append("Comment").append('\n');
			for (Map.Entry<String, RegRepPrFxPositionReport> entry : dtccUSIMap.entrySet()) {
				String usi = entry.getKey();
				String comment = "";
				
				if(usiLiveMapN.containsKey(usi))
				{
					comment = "Trade Qualifier is Set as N in Live Trade Table";
				}
					fw.append(usi).append("\t")
					.append(entry.getValue().getSubmittedFor()).append("\t")
					.append(entry.getValue().getTradeParty1Lei()).append("\t")
					.append(entry.getValue().getTradeParty2Lei()).append("\t")
					.append(comment)
					.append('\n');;
			}
			fw.close();
			
		} catch (Exception ex){
			logger.error("Error Creating DTCC IR Recon report");
		}
		logger.info("Recon report has been generated: " +  irFile.getAbsolutePath());
		
	}
}
