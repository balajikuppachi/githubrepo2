package com.wellsfargo.regulatory.portrec.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.dao.RegRepBusinessAccountDetailsExtnDaoImpl;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCid;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJob;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;

@Component
public class RegRepPrFetchCIDBusAccCDetails extends RegRepPrJob {
	private static Logger logger = Logger.getLogger(RegRepPrFetchCIDBusAccCDetails.class);

	public static String PORTFOLIO_SEGMENT_NAME = "CID LOAD";
	public static String PORTFOLIO_SEGMENT_NAME_CPTY_FREQ = "CptyReconFreqCalculatorSvc";

	@Autowired
	RegRepBusinessAccountDetailsExtnDaoImpl regRepCIDBusAccDetails;

	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRep;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;

	@Autowired
	RegRepPrJobDetailRepository regRepPrJobDetailRepository;

	@Autowired
	TransactionalLoaderServiceForCID transactionalLoaderServiceforcid;

	RegRepPrJobDetail regRepPrJobDetail;
	
	RegRepPrJobDetail regRepPrJobDetailCptyFreq;

	public Message<RegRepPrJobDetail> fetchDetails() {
		
		Message<RegRepPrJobDetail> regRepPrJobDetailMessage = null;
		List<RegRepPrJobDetail> jobDetails = regRepPrJobDetailRepository.findByjobName(PORTFOLIO_SEGMENT_NAME);
		if (jobDetails.size() != 1) {
			throw new RuntimeException(
					"Could not initialize Portfolio Segment '"	+ PORTFOLIO_SEGMENT_NAME + "'");
		}
		regRepPrJobDetail = jobDetails.get(0);
		List<RegRepPrJobDetail> jobDetailsFreq = regRepPrJobDetailRepository.findByjobName(PORTFOLIO_SEGMENT_NAME_CPTY_FREQ);
		if (jobDetailsFreq.size() != 1) {
			throw new RuntimeException(
					"Could not initialize Portfolio Segment '"	+ PORTFOLIO_SEGMENT_NAME_CPTY_FREQ + "'");
		}
		regRepPrJobDetailCptyFreq = jobDetailsFreq.get(0);
		
		logger.info("Starting RegRepPrFetchCIDBusAccCDetails For "	+ regRepPrJobDetail.getJobDesc());
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = transactionalLoaderServiceforcid.startLoad("CID_DATA_LOAD", regRepPrJobDetail, new Date());
		Set<RegRepPrCid> loadCIDData = loadBusAccDetails(regRepPrJobExecutionDetail);
		transactionalLoaderServiceforcid.saveTrades(regRepPrJobExecutionDetail,loadCIDData);
		String jobstatus = transactionalLoaderServiceforcid.completeLoad(regRepPrJobExecutionDetail);
		
		if(jobstatus.equalsIgnoreCase(PortrecConstants.TRUE)){
			regRepPrJobDetailMessage = MessageBuilder.withPayload(regRepPrJobDetailCptyFreq).setHeader(PortrecConstants.PORTREC_JOB_NAME,  
					PORTFOLIO_SEGMENT_NAME_CPTY_FREQ).build();	
		}
		
		logger.info("RegRepPrFetchCIDBusAccCDetails Load Finished For "	+ regRepPrJobDetail.getJobDesc());
		return regRepPrJobDetailMessage;
	}
	
	public Set<RegRepPrCid> loadBusAccDetails(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		
		Set<RegRepPrCid> cidBusAcc = new HashSet();
		List<Integer> distinctBAID = regRepPrLiveTradeRep.findForReconDate();
		/*Recon Missing Counts*/
		List<Integer> missingBAID = new ArrayList<Integer>();
		List<String> srcBAID = new ArrayList<String>();
		
			
		try {
			for (int baID : distinctBAID) {
				List<String> srcSystems = regRepPrLiveTradeRep.findSrcSystems(baID);
				List<RegRepPrCid> list = regRepCIDBusAccDetails.findBusinessAccountDetails(baID);
				Map<String, RegRepPrCid> systemMap = new Hashtable<String, RegRepPrCid>();
				if (!list.isEmpty()) {
					for (RegRepPrCid eachRecord : list) {
									systemMap.put(eachRecord.getSystemC(), eachRecord);
									/*cidBusAcc.add(eachRecord);*/
							}
						if (!systemMap.isEmpty()) {
						if (srcSystems.contains("InterestRate")	|| srcSystems.contains("Credit")){
							if (systemMap.containsKey("CLYP12")) {
								cidBusAcc.add(systemMap.get("CLYP12"));
							} else if (systemMap.containsKey("CLYPS3")) {
								cidBusAcc.add(systemMap.get("CLYPS3"));
							} else if (systemMap.containsKey("CLYPS2")) {
								cidBusAcc.add(systemMap.get("CLYPS2"));
							} else if (systemMap.containsKey("CLYPSO")) {
								cidBusAcc.add(systemMap.get("CLYPSO"));
							} else {
								srcBAID.add(baID + " for Calypso");
							}
						}
						if (srcSystems.contains("Equity")) {
							if (systemMap.containsKey("IMAGIN")) {
								cidBusAcc.add(systemMap.get("IMAGIN"));
							} else {
								srcBAID.add(baID + " for EquityPROD");
							}
						}
						if (srcSystems.contains("FX_INTL") || srcSystems.contains("ForeignExchange")) {
							if (systemMap.containsKey("WFOPIC")) {
								cidBusAcc.add(systemMap.get("WFOPIC"));
							} else {
								srcBAID.add(baID + " for FX_INTL");
							}
						}
						if (srcSystems.contains("Commodity")) {
							if (systemMap.containsKey("ENDUR")) {
								cidBusAcc.add(systemMap.get("ENDUR"));
							} else {
								srcBAID.add(baID + " for Endur GOLD");
							}
						}
					}
					} else {
						missingBAID.add(baID);
					}
				}
			} catch (Exception ex) {
			logger.error("Exception getting details from CID" +ex.getMessage());
		} finally {
			int listSize = cidBusAcc.size();
			regRepPrJobExecutionDetail.setRecordsTotal(listSize);
			if (!missingBAID.isEmpty()) {
				String errorString = "Business Account ID missing from CID";
				for (Integer baid : missingBAID) {
					try {
						RegRepPrException regRepPrException = new RegRepPrException();
						regRepPrException.setExceptionSource("CIDDATALOAD:1");
						regRepPrException.setJobExecutionId(regRepPrJobExecutionDetail.getJobExecutionId());
						regRepPrException.setExceptionDesc(errorString);
						regRepPrException.setExceptionType(ExceptionTypeEnum.CID_ERROR.toString());
						regRepPrException.setExceptionTrace("Missing Business Acc ID: "	+ baid);
						regRepPrException.setCreateDatetime(new Date()); 
						portrecExceptionLogger.logExceptionToDB(regRepPrException);
					} catch (Exception ex) {
						logger.error("exception while logging exception to DB "
								+ ExceptionUtils.getStackTrace(ex));
					}
				}
			}
			if (!srcBAID.isEmpty()) {
				for (String srcBaid : srcBAID) {
					String errorString = "Business Account ID missing from CID for Source System";
					try {
						RegRepPrException regRepPrException = new RegRepPrException();
						regRepPrException.setExceptionSource("CIDDATALOAD:1");
						regRepPrException.setJobExecutionId(regRepPrJobExecutionDetail.getJobExecutionId());
						regRepPrException.setExceptionDesc(errorString);
						regRepPrException.setExceptionType(ExceptionTypeEnum.CID_ERROR.toString());
						regRepPrException.setExceptionTrace("Missing Business Acc ID: "	+ srcBaid);
						regRepPrException.setCreateDatetime(new Date()); 
						portrecExceptionLogger.logExceptionToDB(regRepPrException);
					} catch (Exception ex) {
						logger.error("exception while logging exception to DB "
								+ ExceptionUtils.getStackTrace(ex));
					}
				}
			}
			logger.info("Total Number of Business Account ID's are " + listSize);
			logger.info("List of Missing Business Account ID's in CID are "	+ missingBAID);
			logger.info("List of Missing Business Account ID's against Source mapping in CID" + srcBAID);
		}
		return cidBusAcc;
	}

	@Service
	@Transactional(value="portrec")
	public static class TransactionalLoaderServiceForCID extends RegRepPrJob{
		@Autowired
		RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

		@Autowired
		CalendarService calendarService;
		
		@PersistenceContext(unitName = "Portrec")
		EntityManager entityManager;
		
		@Value("${portrec.job.request.onDemand.dir}") String source;
		@Value("${portrec.autocreate.file.cptyFreq}") String autoCreater;
		
		Logger logger = Logger.getLogger(getClass());

		public RegRepPrJobExecutionDetail startLoad(String fileName,
				RegRepPrJobDetail regRepPrJobDetail, Date asOfDate) {

			RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();
			regRepPrJobExecutionDetail.setJobDetailsId(regRepPrJobDetail);
			regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
			regRepPrJobExecutionDetail.setFileName(fileName);
			regRepPrJobExecutionDetail.setJobStatus("PROCESSING");
			regRepPrJobExecutionDetail.setCreateDatetime(new Date());

			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

			return regRepPrJobExecutionDetail;
		}

		public void saveTrades(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail, Collection<RegRepPrCid> loadCIDData) {
			/*int count = 0;*/
			for (RegRepPrJob trade : loadCIDData) {
				/*count = count + 1;*/
				trade.setJobExecutionId(regRepPrJobExecutionDetail);
				regRepPrJobExecutionDetail.setRecodsLoaded(regRepPrJobExecutionDetail.getRecodsLoaded() + 1);
				/*logger.info("Inserting Records " + count);*/
				entityManager.persist(trade);
			}
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		}
		
		public void deleteTrades(Long id){
			entityManager.flush();
			entityManager.clear();
			RegRepPrCid trade = new RegRepPrCid();
						
			Class<?> clazz = trade.getClass();
			Table table = clazz.getAnnotation( Table.class );
			
			Date asofDate = new Date();
			logger.info("DELETING ALL PREV RECORDS FROM " + table.name() + " TABLE BEFORE " + asofDate);
						
			Query upd =  entityManager.createNativeQuery("DELETE FROM " + table.name() + " where job_execution_id != :job_execution_id");
			
			upd.setParameter("job_execution_id", id);
			
			int updatedCnt = upd.executeUpdate();
			logger.info("" + updatedCnt + " rows deleted");
		}
		
		public void updateLiveTradesCptyID() {
			entityManager.flush();
			entityManager.clear();
			Query updForRates = entityManager.createNativeQuery(
					"update REG_REP_PR_LIVE_TRADES set legal_id = c.lgle_id_c from REG_REP_PR_CID c where REG_REP_PR_LIVE_TRADES.ba_id = c.bus_a_id_c AND REG_REP_PR_LIVE_TRADES.asset_class in ('InterestRate','Credit') and c.system_c in ('CLYP12','CLYPS3','CLYPS2','CLYPSO')");
			int updatedCntRates = updForRates.executeUpdate();
			logger.info("" + updatedCntRates + " trades updated with Cpty ID for Rates");
			
			Query updForEquity = entityManager.createNativeQuery(
					"update REG_REP_PR_LIVE_TRADES set legal_id = c.lgle_id_c from REG_REP_PR_CID c where REG_REP_PR_LIVE_TRADES.ba_id = c.bus_a_id_c AND REG_REP_PR_LIVE_TRADES.asset_class in ('Equity') AND c.system_c in ('IMAGIN')");
			int updatedCntEquity = updForEquity.executeUpdate();
			logger.info("" + updatedCntEquity + " trades updated with Cpty ID for Equity");
			
			Query updForFX = entityManager.createNativeQuery(
					"update REG_REP_PR_LIVE_TRADES set legal_id = c.lgle_id_c from REG_REP_PR_CID c where REG_REP_PR_LIVE_TRADES.ba_id = c.bus_a_id_c AND REG_REP_PR_LIVE_TRADES.asset_class in ('FX_INTL','ForeignExchange')  AND c.system_c in ('WFOPIC')");
			int updatedCntFX = updForFX.executeUpdate();
			logger.info("" + updatedCntFX + " trades updated with Cpty ID for FX");
			
			Query updForComm = entityManager.createNativeQuery(
					"update REG_REP_PR_LIVE_TRADES set legal_id = c.lgle_id_c from REG_REP_PR_CID c where REG_REP_PR_LIVE_TRADES.ba_id = c.bus_a_id_c AND REG_REP_PR_LIVE_TRADES.asset_class in ('Commodity') AND c.system_c in ('ENDUR')");
			int updatedCntComm = updForComm.executeUpdate();
			logger.info("" + updatedCntComm + " trades updated with Cpty ID for Commodities");
		}

		public String completeLoad(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
			String resp = null;
			
			deleteTrades(regRepPrJobExecutionDetail.getJobExecutionId());updateLiveTradesCptyID();
			regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
			if(regRepPrJobExecutionDetail.getRecodsLoaded() == regRepPrJobExecutionDetail.getRecordsTotal())
			{	
				resp=PortrecConstants.TRUE;			
				regRepPrJobExecutionDetail.setJobStatus("SUCCESS");
			}
			else
			{
				regRepPrJobExecutionDetail.setJobStatus("ERROR");
			}
						   
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
			return resp;
		}

	}
}
