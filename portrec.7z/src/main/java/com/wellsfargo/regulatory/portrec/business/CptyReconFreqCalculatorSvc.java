package com.wellsfargo.regulatory.portrec.business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrCptyReconFreqDaoImpl;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrLiveTradeDaoImpl;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrPortfolioSizeLogDaoImpl;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrPortfolioSizeLog;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;
import com.wellsfargo.regulatory.portrec.dto.CptyLiveTrades;
import com.wellsfargo.regulatory.portrec.dto.CptyReconFreq;
import com.wellsfargo.regulatory.portrec.dto.PortfolioSizeLog;
import com.wellsfargo.regulatory.portrec.enums.ReconDayEnum;
import com.wellsfargo.regulatory.portrec.enums.ReconFreqTypeEnum;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrPortfolioSizeLogRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.service.RegRepLiveTradeEnricherSvc;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author Raji Komatreddy
 */
@Component
public class CptyReconFreqCalculatorSvc
{
	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;

	@Autowired
	RegRepPrPortfolioSizeLogRepository regRepPrPortfolioSizeLogRepository;

	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	@Autowired
	RegRepPrLiveTradeDaoImpl regRepPrLiveTradeDaoImpl;

	@Autowired
	RegRepPrPortfolioSizeLogDaoImpl regRepPrPortfolioSizeLogDaoImpl;

	@Autowired
	RegRepPrCptyReconFreqDaoImpl regRepPrCptyReconFreqDaoImpl;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;

	@Autowired
	CalendarService calendarService;
	
	@Autowired
	RegRepLiveTradeEnricherSvc regRepLiveTradeEnricherSvc;

	@Value("${portrec.batch.commit.size}")
	String batchSizeStr;

	@Value("${portrec.cpty.recon.freq.non_sd_quarterly_size}")
	String nonSDQuarterlySizeStr;

	@Value("${portrec.cpty.recon.freq.sd_daily_size}")
	String sdDailySizeStr;

	@Value("${portrec.cpty.recon.freq.sd_weekly_size}")
	String sdWeeklySizeStr;

	private static final int WEEK_THUR = Calendar.THURSDAY;
	private static final int WEEK_FRI = Calendar.FRIDAY;

	List<PortfolioSizeLog> portfolioSizeLogList = new ArrayList<PortfolioSizeLog>();
	List<CptyReconFreq> cptyReconFreqList = new ArrayList<CptyReconFreq>();

	Map<Long, RegRepPrPortfolioSizeLog> portfolioSizeLogMap = new HashMap<Long, RegRepPrPortfolioSizeLog>();

	List<CptyLiveTrades> cptyLiveTradesList = new ArrayList<CptyLiveTrades>();

	List<CptyLiveTrades> mergedCptyLiveTradesList = new ArrayList<CptyLiveTrades>();

	Logger logger = Logger.getLogger(CptyReconFreqCalculatorSvc.class);
	Date currDate = new Date();
	int batchSize = 0;
	int nonSDQuarterlySize = 0;
	int sdWeeklySize = 0;
	int sdDailySize = 0;

	/**
	 * populates data in portfoliosizeLog and cptyReconFreq tables by reading data from liveTrades
	 * table
	 */
	public void populateCptyReconFreq(Message<?> message) throws PortrecException
	{

		Object ipMessage = null;
		String errorString = null;
		String jobName = null;
		Date reconDate = null;
		long currJobExecutionId = 0;
		String jobAsOfDate = null;
		Date asOfDate = null;
		Date runDate = null;

		RegRepPrJobDetail currRegRepPrJobDetail = null;
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);
		// reconDate = reconDateFormat.format(reconDate);

		if (null != nonSDQuarterlySizeStr) nonSDQuarterlySize = Integer.parseInt(nonSDQuarterlySizeStr);

		if (null != sdDailySizeStr) sdDailySize = Integer.parseInt(sdDailySizeStr);

		if (null != sdWeeklySizeStr) sdWeeklySize = Integer.parseInt(sdWeeklySizeStr);

		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconFreqCalculatorSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}
		ipMessage = message.getPayload();
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)) 
			jobAsOfDate = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();

		if (null != jobAsOfDate)
		{
			logger.info(" recon process running for asOfDate received from fileName " + jobAsOfDate);
			try
			{
				asOfDate = reconDateFormat.parse(jobAsOfDate);
				if (null != asOfDate)
				{
					reconDate = asOfDate;
				}
				else
				{
					reconDate = new Date();
				}
			}
			catch (ParseException e)
			{
				logger.error("########## " + e.getMessage());
				// e.printStackTrace();
			}
		}
		else
		{
			String realTimeConfig = regRepPrPortfolioSizeLogDaoImpl.getCobDateFromRealTimeConfig(PortrecConstants.CLOSE_OF_BUSINESS_DATE);
			logger.info(" recon process running for Date received from CLOSE_OF_BUSINESS_DATE " + realTimeConfig);
			try {
				
					if(null != realTimeConfig)
					{
						reconDate = reconDateFormat.parse(realTimeConfig);
					}
					else
					{
						reconDate = new Date();
					}
			} 
			catch (ParseException e) {
				logger.error("########## " + e.getMessage());
			}
		}

		if (ipMessage instanceof RegRepPrJobDetail)
		{
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail)
		{
			errorString = "Null incoming PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconFreqCalculatorSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		// tradeFile.setId(new BigDecimal(10000001));
		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(reconDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail.getJobName());
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconFreqCalculatorSvc-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		logger.info("jobExecution id for current run of CptyReconFreqCalculatorSvc " + currJobExecutionId);

		if (null != batchSizeStr) batchSize = Integer.parseInt(batchSizeStr);

		String reconDay = null;
		reconDay = calculateReconDay(reconDate);
		int numRowsDeletedFromPortfolioLog = 0;

		logger.info("reconDay for jobExecution is: " + reconDay);

		try
		{
			if (null != reconDay && !reconDay.equalsIgnoreCase(ReconDayEnum.HOLIDAY.toString()))
			{
				//enrich live trade table with recon eligible and recon_cpty information
				if(null != regRepLiveTradeEnricherSvc)
				{
					regRepLiveTradeEnricherSvc.enrichLiveTradeData();
				}
				
				// get live trades list

				if (null != regRepPrLiveTradeDaoImpl)
				{
					cptyLiveTradesList = regRepPrLiveTradeDaoImpl.getCptyLiveTrades();

					// cpty list comes with assetclass wise counts add total counts for each legal
					// id add make one record for legal id
					if (null != cptyLiveTradesList)
					{
						mergedCptyLiveTradesList = mergeLiveTradesByLegalId(cptyLiveTradesList);
					}

				}

				// get counterparty deatils for last working day from PortfolioSizeLog table and
				// place it in hashmap
				// Date prevReconDate = calendarService.getPreviousWorkingDay(reconDate);
				Date prevReconDate = regRepPrJobExecutionDetailRepository.findLastSuccessFulReconFreqRun();
				
				List<RegRepPrPortfolioSizeLog> prevPortfolioList = regRepPrPortfolioSizeLogRepository.findForAsofDate(prevReconDate);

				// delete from PortfolioSizeLog table for reconDate -- this will delete records if
				// already exist for the same reconDate,
				// which we are running now (happens incase of rerun of this job
				numRowsDeletedFromPortfolioLog = regRepPrPortfolioSizeLogDaoImpl.deleteFromPortfolioSizeLog(new java.sql.Date(reconDate.getTime()));
				logger.info("number of rows deleted from PortfolioSizeLog table for same asOfDate as reconDate " + numRowsDeletedFromPortfolioLog);

				if (null != prevPortfolioList)
				{
					logger.info("previous working day CptyPortfolioLog records :" + prevPortfolioList.size());
					for (RegRepPrPortfolioSizeLog prevPortfolio : prevPortfolioList)
					{
						Long cidCptyId = (long) (prevPortfolio.getCidCptyId());

						portfolioSizeLogMap.put(cidCptyId, prevPortfolio);
					}
				}

				if (null != mergedCptyLiveTradesList)
				{
					logger.info("number of live trades from CptyLiveTrades table :" + cptyLiveTradesList.size());
					// delete existing records from CptyReconFreq table
					regRepPrCptyReconFreqDaoImpl.deleteFromCptyReconFreq();

					for (CptyLiveTrades currCptyLiveTrade : mergedCptyLiveTradesList)
					{
						RegRepPrPortfolioSizeLog prevPortfolioSizeLog = null;
						RegRepPrPortfolioSizeLog presentPortfolioSizeLog = null;

						PortfolioSizeLog currPortfolioSizeLog = new PortfolioSizeLog();
						CptyReconFreq currCptyReconFreq = new CptyReconFreq();
						String legalType = null;

						int cidId = currCptyLiveTrade.getCidCptyId();
						Long cidIdLong = (long) cidId;
						if (null != portfolioSizeLogMap) prevPortfolioSizeLog = portfolioSizeLogMap.get(cidIdLong);

						if (null != prevPortfolioSizeLog && null != currCptyLiveTrade)
						{
							legalType = currCptyLiveTrade.getCptyType();
							prevPortfolioSizeLog.setPortfolioSize(currCptyLiveTrade.getPortfolioSize());
							prevPortfolioSizeLog.setCptyType(legalType);
							prevPortfolioSizeLog.setAsOfDate(reconDate);

							if (null != legalType && !legalType.equalsIgnoreCase(PortrecConstants.SD_CPTY_TYPE))
							{
								presentPortfolioSizeLog = resetQuarterlyReconFlagsForNonSD(prevPortfolioSizeLog);
								presentPortfolioSizeLog = calculateReconFrequencyForNonSD(presentPortfolioSizeLog);
								presentPortfolioSizeLog.setReconDay(reconDay);

								currPortfolioSizeLog = convertRegRepPortfoliosizeToDto(presentPortfolioSizeLog, currJobExecutionId);
								currCptyReconFreq = setDataToCptyReconFreq(presentPortfolioSizeLog);

								currPortfolioSizeLog.setCommSize(currCptyLiveTrade.getCommSize());
								currPortfolioSizeLog.setIrSize(currCptyLiveTrade.getIrSize());
								currPortfolioSizeLog.setCrSize(currCptyLiveTrade.getCrSize());
								currPortfolioSizeLog.setEqSize(currCptyLiveTrade.getEqSize());
								currPortfolioSizeLog.setFxSize(currCptyLiveTrade.getFxSize());
								currPortfolioSizeLog.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

								currCptyReconFreq.setCommSize(currCptyLiveTrade.getCommSize());
								currCptyReconFreq.setIrSize(currCptyLiveTrade.getIrSize());
								currCptyReconFreq.setCrSize(currCptyLiveTrade.getCrSize());
								currCptyReconFreq.setEqSize(currCptyLiveTrade.getEqSize());
								currCptyReconFreq.setFxSize(currCptyLiveTrade.getFxSize());
								currCptyReconFreq.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

								cptyReconFreqList.add(currCptyReconFreq);
								portfolioSizeLogList.add(currPortfolioSizeLog);
							}
							else
							{

								presentPortfolioSizeLog = resetReconFlagsForSD(prevPortfolioSizeLog);
								presentPortfolioSizeLog = calculateReconFrequencyForSD(presentPortfolioSizeLog);
								presentPortfolioSizeLog.setReconDay(reconDay);

								currPortfolioSizeLog = convertRegRepPortfoliosizeToDto(presentPortfolioSizeLog, currJobExecutionId);
								currCptyReconFreq = setDataToCptyReconFreq(presentPortfolioSizeLog);

								currPortfolioSizeLog.setCommSize(currCptyLiveTrade.getCommSize());
								currPortfolioSizeLog.setIrSize(currCptyLiveTrade.getIrSize());
								currPortfolioSizeLog.setCrSize(currCptyLiveTrade.getCrSize());
								currPortfolioSizeLog.setEqSize(currCptyLiveTrade.getEqSize());
								currPortfolioSizeLog.setFxSize(currCptyLiveTrade.getFxSize());
								currPortfolioSizeLog.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

								currCptyReconFreq.setCommSize(currCptyLiveTrade.getCommSize());
								currCptyReconFreq.setIrSize(currCptyLiveTrade.getIrSize());
								currCptyReconFreq.setCrSize(currCptyLiveTrade.getCrSize());
								currCptyReconFreq.setEqSize(currCptyLiveTrade.getEqSize());
								currCptyReconFreq.setFxSize(currCptyLiveTrade.getFxSize());
								currCptyReconFreq.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

								cptyReconFreqList.add(currCptyReconFreq);
								portfolioSizeLogList.add(currPortfolioSizeLog);

							}

						}
						else
						{
							// logger.info("no previous records exist for this counter party in PortifolioSizeLog table");
							if (null != currCptyLiveTrade)
							{
								legalType = currCptyLiveTrade.getCptyType();
								presentPortfolioSizeLog = new RegRepPrPortfolioSizeLog();

								presentPortfolioSizeLog.setCidCptyId(currCptyLiveTrade.getCidCptyId());
								presentPortfolioSizeLog.setCptyType(legalType);
								presentPortfolioSizeLog.setPortfolioSize(currCptyLiveTrade.getPortfolioSize());
								presentPortfolioSizeLog.setAsOfDate(reconDate);
								presentPortfolioSizeLog.setReconDay(reconDay);

								if (null != legalType && !legalType.equalsIgnoreCase(PortrecConstants.SD_CPTY_TYPE))
								{
									presentPortfolioSizeLog = calculateReconFrequencyForNonSD(presentPortfolioSizeLog);

									currPortfolioSizeLog = convertRegRepPortfoliosizeToDto(presentPortfolioSizeLog, currJobExecutionId);
									currCptyReconFreq = setDataToCptyReconFreq(presentPortfolioSizeLog);

									currPortfolioSizeLog.setCommSize(currCptyLiveTrade.getCommSize());
									currPortfolioSizeLog.setIrSize(currCptyLiveTrade.getIrSize());
									currPortfolioSizeLog.setCrSize(currCptyLiveTrade.getCrSize());
									currPortfolioSizeLog.setEqSize(currCptyLiveTrade.getEqSize());
									currPortfolioSizeLog.setFxSize(currCptyLiveTrade.getFxSize());
									currPortfolioSizeLog.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

									currCptyReconFreq.setCommSize(currCptyLiveTrade.getCommSize());
									currCptyReconFreq.setIrSize(currCptyLiveTrade.getIrSize());
									currCptyReconFreq.setCrSize(currCptyLiveTrade.getCrSize());
									currCptyReconFreq.setEqSize(currCptyLiveTrade.getEqSize());
									currCptyReconFreq.setFxSize(currCptyLiveTrade.getFxSize());
									currCptyReconFreq.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

									cptyReconFreqList.add(currCptyReconFreq);
									portfolioSizeLogList.add(currPortfolioSizeLog);
								}
								else
								{
									presentPortfolioSizeLog = calculateReconFrequencyForSD(presentPortfolioSizeLog);

									currPortfolioSizeLog = convertRegRepPortfoliosizeToDto(presentPortfolioSizeLog, currJobExecutionId);
									currCptyReconFreq = setDataToCptyReconFreq(presentPortfolioSizeLog);

									currPortfolioSizeLog.setCommSize(currCptyLiveTrade.getCommSize());
									currPortfolioSizeLog.setIrSize(currCptyLiveTrade.getIrSize());
									currPortfolioSizeLog.setCrSize(currCptyLiveTrade.getCrSize());
									currPortfolioSizeLog.setEqSize(currCptyLiveTrade.getEqSize());
									currPortfolioSizeLog.setFxSize(currCptyLiveTrade.getFxSize());
									currPortfolioSizeLog.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

									currCptyReconFreq.setCommSize(currCptyLiveTrade.getCommSize());
									currCptyReconFreq.setIrSize(currCptyLiveTrade.getIrSize());
									currCptyReconFreq.setCrSize(currCptyLiveTrade.getCrSize());
									currCptyReconFreq.setEqSize(currCptyLiveTrade.getEqSize());
									currCptyReconFreq.setFxSize(currCptyLiveTrade.getFxSize());
									currCptyReconFreq.setFxIntlSize(currCptyLiveTrade.getFxIntlSize());

									cptyReconFreqList.add(currCptyReconFreq);
									portfolioSizeLogList.add(currPortfolioSizeLog);

								}
							}

						}

						// persist data into CptyReconFreq and PortifolioSizeLog tables once list
						// size equal to batch size
						if (cptyReconFreqList.size() == batchSize)
						{
							logger.info("before inserting records into CptyReconFrequency table ");
							regRepPrCptyReconFreqDaoImpl.batchInsertCptyReconFreq(cptyReconFreqList);
							cptyReconFreqList.clear();

						}
						if (portfolioSizeLogList.size() == batchSize)
						{
							logger.info("before inserting records into CptyPortfolioSizeLog table ");
							regRepPrPortfolioSizeLogDaoImpl.batchInsertPortfolioSize(portfolioSizeLogList);
							portfolioSizeLogList.clear();

						}

					}
				}
				regRepPrCptyReconFreqDaoImpl.batchInsertCptyReconFreq(cptyReconFreqList);
				cptyReconFreqList.clear();

				regRepPrPortfolioSizeLogDaoImpl.batchInsertPortfolioSize(portfolioSizeLogList);
				portfolioSizeLogList.clear();

			}
			else
			{
				logger.info("It is wellsfargo holdiay : recon process won't run for today");
			}
		}
		catch (PortrecException ex)
		{

			try
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				RegRepPrException regRepPrException = new RegRepPrException();
				regRepPrException.setExceptionSource("CptyReconFreqCalculatorSvc");
				regRepPrException.setJobExecutionId(currJobExecutionId);
				regRepPrException.setExceptionDesc(errorString);
				regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
				regRepPrException.setExceptionTrace(ExceptionUtils.getStackTrace(ex));
				regRepPrException.setCreateDatetime(new Date());
				portrecExceptionLogger.logExceptionToDB(regRepPrException);
				logger.error("Exception occurred inside CptyReconFreqCalculatorSvc for jobId #" + currJobExecutionId + "exception message " + errorString);
			}
			catch (Exception e)
			{
				logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}

		}
		logger.info("finshed CptyReconFreqCalculatorSvc successfully ");
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

	}

	/**
	 * caluclates reconday for the run
	 * 
	 * @param portfolioSizeLog
	 * @return
	 */
	private String calculateReconDay(Date date)
	{
		String reconDay = null;
		boolean isWorkingDay = true;

		Calendar calInstance = Calendar.getInstance();
		calInstance.setTime(date);

		int weekDay = calInstance.get(Calendar.DAY_OF_WEEK);

		isWorkingDay = calendarService.isWorkingDay(date);
		if (isWorkingDay)
		{
			if (weekDay == WEEK_THUR)
			{
				calInstance.add(Calendar.DATE, 1);
				boolean isFridayWorkingDay = calendarService.isWorkingDay(calInstance.getTime());
				if (isFridayWorkingDay)
				{
					reconDay = ReconDayEnum.WEEKDAY.toString();
				}
				else
				{
					reconDay = ReconDayEnum.WEEKEND.toString();
				}
			}
			if (weekDay == WEEK_FRI)
			{
				reconDay = ReconDayEnum.WEEKEND.toString();
			}
			else
			{
				reconDay = ReconDayEnum.WEEKDAY.toString();
			}

			List<RegRepPrReconCalendar> regRepPrReconCalendarList = regRepPrReconCalendarRepository.findByAsOfDateQTR(date);
			if (null != regRepPrReconCalendarList && regRepPrReconCalendarList.size() > 0)
			{
				reconDay = ReconDayEnum.QUARTEREND.toString();
			}

		}
		else
		{
			reconDay = ReconDayEnum.HOLIDAY.toString();
		}

		return reconDay;

	}

	/**
	 * calculates recon frequency for NON-SD counter parties if portifolio size is more than 100 -
	 * it is Quarterly Recon. if size is less than 100 and quarterly flag is null then Annual,
	 * otherwise if quaterly recon ran no need to run Annual
	 * 
	 * @param portfolioSizeLog
	 * @return
	 */
	private RegRepPrPortfolioSizeLog calculateReconFrequencyForNonSD(RegRepPrPortfolioSizeLog portfolioSizeLog) throws PortrecException
	{

		String quarterlyFlag = null;
		String currReconFreq = null;
		int portfolioSize = 0;

		try
		{

			if (null != portfolioSizeLog)
			{
				portfolioSize = portfolioSizeLog.getPortfolioSize();
				quarterlyFlag = portfolioSizeLog.getQuarterly();

				if (portfolioSize >= nonSDQuarterlySize)
				{
					currReconFreq = ReconFreqTypeEnum.QUARTERLY.toString();
					portfolioSizeLog.setQuarterly(PortrecConstants.FLAG_TRUE);

				}
				else
				{
					if (null != quarterlyFlag && quarterlyFlag.equalsIgnoreCase(PortrecConstants.FLAG_TRUE))
					{
						currReconFreq = ReconFreqTypeEnum.QUARTERLY.toString();
					}
					else
					{
						currReconFreq = ReconFreqTypeEnum.ANNUAL.toString();
						portfolioSizeLog.setAnnual(PortrecConstants.FLAG_TRUE);
					}

				}
				portfolioSizeLog.setReconFreq(currReconFreq);

			}
			else
			{
				logger.error("not able to calculate recon frequency as portfolioSizeLog is null ");

			}
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred insidecalculateReconFrequencyForNonSD method" + ex.getMessage();
			logger.error("exception occurred inside calculateReconFrequencyForNonSD method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("CptyReconFreqCalculatorSvc:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);
		}

		return portfolioSizeLog;
	}

	/**
	 * reset the quartly flag after quarterly recon run
	 * 
	 * @param portfolioSizeLog
	 * @return
	 */
	private RegRepPrPortfolioSizeLog resetQuarterlyReconFlagsForNonSD(RegRepPrPortfolioSizeLog portfolioSizeLog)
	{
		String reconDay = null;
		if (null != portfolioSizeLog)
		{
			reconDay = portfolioSizeLog.getReconDay();
			if (null != reconDay && reconDay.equalsIgnoreCase(ReconDayEnum.QUARTEREND.toString()))
			{
				portfolioSizeLog.setQuarterly(null);
			}
		}
		else
		{
			logger.error("not able to calculate recon frequency as portfolioSizeLog is null ");
		}

		return portfolioSizeLog;
	}

	/**
	 * calculates recon frequency for SD counter parties if portifolio size is more than 499 - it is
	 * Daily Recon. if size is more than 50 than weekly, if daily flag is present no recon required,
	 * otherwise if quaterly recon , if either daily or weekly flag - no recon required
	 * 
	 * @param portfolioSizeLog
	 * @return
	 */
	private RegRepPrPortfolioSizeLog calculateReconFrequencyForSD(RegRepPrPortfolioSizeLog portfolioSizeLog) throws PortrecException
	{
		String dailyFlag = null;
		String weeklyFlag = null;
		String currReconFreq = null;
		String overrideFlag = null;
		int portfolioSize = 0;

		try
		{

			if (null != portfolioSizeLog)
			{
				portfolioSize = portfolioSizeLog.getPortfolioSize();
				dailyFlag = portfolioSizeLog.getDaily();
				weeklyFlag = portfolioSizeLog.getWeekly();
				overrideFlag = portfolioSizeLog.getOverrideFreq();

				if (portfolioSize >= sdDailySize)
				{
					currReconFreq = ReconFreqTypeEnum.DAILY.toString();
					portfolioSizeLog.setDaily(PortrecConstants.FLAG_TRUE);

				}
				else if (portfolioSize >= sdWeeklySize)
				{
					if (null != dailyFlag && dailyFlag.equalsIgnoreCase(PortrecConstants.FLAG_TRUE))
					{
						currReconFreq = ReconFreqTypeEnum.NONE.toString();
					}
					else
					{
						currReconFreq = ReconFreqTypeEnum.WEEKLY.toString();
						portfolioSizeLog.setWeekly(PortrecConstants.FLAG_TRUE);
						portfolioSizeLog.setOverrideFreq(ReconFreqTypeEnum.WEEKLY.toString());
					}

				}
				else if (null != overrideFlag && overrideFlag.equalsIgnoreCase(ReconFreqTypeEnum.WEEKLY.toString()))
				{
					currReconFreq = ReconFreqTypeEnum.WEEKLY.toString();
					portfolioSizeLog.setWeekly(PortrecConstants.FLAG_TRUE);
					portfolioSizeLog.setOverrideFreq(ReconFreqTypeEnum.WEEKLY.toString());
				}

				else
				{
					if ((null != dailyFlag && dailyFlag.equalsIgnoreCase(PortrecConstants.FLAG_TRUE)) || (null != weeklyFlag && weeklyFlag.equalsIgnoreCase(PortrecConstants.FLAG_TRUE)))
					{
						currReconFreq = ReconFreqTypeEnum.NONE.toString();
					}
					else
					{
						currReconFreq = ReconFreqTypeEnum.QUARTERLY.toString();
						portfolioSizeLog.setQuarterly(PortrecConstants.FLAG_TRUE);
					}

				}
				portfolioSizeLog.setReconFreq(currReconFreq);

			}
			else
			{
				logger.error("not able to calculate recon frequency as portfolioSizeLog is null ");
			}
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside  calculateReconFrequencyForSD method" + ex.getMessage();
			logger.error("exception occurred inside calculateReconFrequencyForSD method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("CptyReconFreqCalculatorSvc:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);

		}

		return portfolioSizeLog;
	}

	/**
	 * reset the daily flag after weekly recon run reset the daily and weekly flag after quarterly
	 * recon run
	 * 
	 * @param portfolioSizeLog
	 * @return
	 */
	private RegRepPrPortfolioSizeLog resetReconFlagsForSD(RegRepPrPortfolioSizeLog portfolioSizeLog)
	{
		String reconDay = null;
		if (null != portfolioSizeLog)
		{
			reconDay = portfolioSizeLog.getReconDay();
			if (null != reconDay && reconDay.equalsIgnoreCase(ReconDayEnum.QUARTEREND.toString()))
			{
				portfolioSizeLog.setDaily(null);
				portfolioSizeLog.setWeekly(null);
				portfolioSizeLog.setOverrideFreq(null);
			}
			else if (null != reconDay && reconDay.equalsIgnoreCase(ReconDayEnum.WEEKEND.toString()))
			{
				portfolioSizeLog.setDaily(null);
				portfolioSizeLog.setOverrideFreq(null);

			}
		}
		else
		{
			logger.error("not able to calculate recon frequency as portfolioSizeLog is null ");
		}

		return portfolioSizeLog;
	}

	private PortfolioSizeLog convertRegRepPortfoliosizeToDto(RegRepPrPortfolioSizeLog regRepPrPortfolioSizeLog, long jobExeuctionId)
	{
		PortfolioSizeLog currPortfolioSizeLog = new PortfolioSizeLog();
		currPortfolioSizeLog.setJobExecutionId(jobExeuctionId);
		currPortfolioSizeLog.setAnnual(regRepPrPortfolioSizeLog.getAnnual());
		currPortfolioSizeLog.setAsOfDate(regRepPrPortfolioSizeLog.getAsOfDate());
		currPortfolioSizeLog.setCalculatedFreq(regRepPrPortfolioSizeLog.getReconFreq());
		currPortfolioSizeLog.setCidCptyId(regRepPrPortfolioSizeLog.getCidCptyId());
		currPortfolioSizeLog.setCreateDatetime(currDate);
		currPortfolioSizeLog.setDaily(regRepPrPortfolioSizeLog.getDaily());
		currPortfolioSizeLog.setLegalType(regRepPrPortfolioSizeLog.getCptyType());
		currPortfolioSizeLog.setOverrideFreq(regRepPrPortfolioSizeLog.getOverrideFreq());
		currPortfolioSizeLog.setPortfolioSize(regRepPrPortfolioSizeLog.getPortfolioSize());
		currPortfolioSizeLog.setQuarterly(regRepPrPortfolioSizeLog.getQuarterly());
		currPortfolioSizeLog.setReconDay(regRepPrPortfolioSizeLog.getReconDay());
		currPortfolioSizeLog.setWeekly(regRepPrPortfolioSizeLog.getWeekly());

		return currPortfolioSizeLog;
	}

	private CptyReconFreq setDataToCptyReconFreq(RegRepPrPortfolioSizeLog regRepPrPortfolioSizeLog)
	{
		CptyReconFreq currCptyReconFreq = new CptyReconFreq();

		currCptyReconFreq.setCidCptyId(regRepPrPortfolioSizeLog.getCidCptyId());
		currCptyReconFreq.setLegalType(regRepPrPortfolioSizeLog.getCptyType());
		currCptyReconFreq.setPortfolioSize(regRepPrPortfolioSizeLog.getPortfolioSize());
		currCptyReconFreq.setReconFreq(regRepPrPortfolioSizeLog.getReconFreq());

		return currCptyReconFreq;
	}

	private List<CptyLiveTrades> mergeLiveTradesByLegalId(List<CptyLiveTrades> cptyLiveTradesLsit)
	{
		List<CptyLiveTrades> currLiveTrades = new ArrayList<CptyLiveTrades>();
		int totalSize = 0;
		int commSize = 0;
		int crSize = 0;
		int irSize = 0;
		int eqSize = 0;
		int fxSize = 0;
		int fxIntlSize = 0;
		int assetClassSize = 0;

		int prevLegalId = 0;
		int currLegalId = 0;
		String currAssetClass = null;
		String prevCptyType = null;

		if (null != cptyLiveTradesLsit)
		{
			for (CptyLiveTrades currCptyLiveTrades : cptyLiveTradesLsit)
			{
				currLegalId = currCptyLiveTrades.getCidCptyId();
				currAssetClass = currCptyLiveTrades.getAssetClass();
				assetClassSize = currCptyLiveTrades.getPortfolioSize();

				if (prevLegalId == currLegalId)
				{
					totalSize = totalSize + assetClassSize;
					prevCptyType = currCptyLiveTrades.getCptyType();

				}
				else if (prevLegalId != currLegalId && prevLegalId != 0)
				{
					CptyLiveTrades mergedCptyLiveTrades = new CptyLiveTrades();
					mergedCptyLiveTrades.setCidCptyId(prevLegalId);
					mergedCptyLiveTrades.setPortfolioSize(totalSize);
					mergedCptyLiveTrades.setCptyType(prevCptyType);
					mergedCptyLiveTrades.setCommSize(commSize);
					mergedCptyLiveTrades.setIrSize(irSize);
					mergedCptyLiveTrades.setCrSize(crSize);
					mergedCptyLiveTrades.setEqSize(eqSize);
					mergedCptyLiveTrades.setFxSize(fxSize);
					mergedCptyLiveTrades.setFxIntlSize(fxIntlSize);

					currLiveTrades.add(mergedCptyLiveTrades);

					// reset the counts
					totalSize = 0;
					commSize = 0;
					crSize = 0;
					irSize = 0;
					eqSize = 0;
					fxSize = 0;
					fxIntlSize = 0;
					prevLegalId = currLegalId;
					prevCptyType = currCptyLiveTrades.getCptyType();
					totalSize = assetClassSize;

				}
				else
				{
					prevLegalId = currLegalId;
					totalSize =  assetClassSize;
					prevCptyType = currCptyLiveTrades.getCptyType();
				}

				if (currAssetClass.equalsIgnoreCase(PortrecConstants.ASSETCLASS_IR))
				{
					irSize = assetClassSize;
				}
				else if (currAssetClass.equalsIgnoreCase(PortrecConstants.ASSETCLASS_CR))
				{
					crSize = assetClassSize;

				}
				else if (currAssetClass.equalsIgnoreCase(PortrecConstants.ASSETCLASS_EQ))
				{
					eqSize = assetClassSize;

				}
				else if (currAssetClass.equalsIgnoreCase(PortrecConstants.ASSETCLASS_COMM))
				{
					commSize = assetClassSize;

				}
				else if (currAssetClass.equalsIgnoreCase(PortrecConstants.ASSETCLASS_FX))
				{
					fxSize = assetClassSize;

				}
				else if (currAssetClass.equalsIgnoreCase(PortrecConstants.ASSETCLASS_FX_INTL))
				{
					fxIntlSize = assetClassSize;

				}

			}
			
			if(prevLegalId !=0 || currLegalId != 0)				
			{
				CptyLiveTrades mergedCptyLiveTrades = new CptyLiveTrades();
				mergedCptyLiveTrades.setCidCptyId(prevLegalId);
				mergedCptyLiveTrades.setPortfolioSize(totalSize);
				mergedCptyLiveTrades.setCptyType(prevCptyType);
				mergedCptyLiveTrades.setCommSize(commSize);
				mergedCptyLiveTrades.setIrSize(irSize);
				mergedCptyLiveTrades.setCrSize(crSize);
				mergedCptyLiveTrades.setEqSize(eqSize);
				mergedCptyLiveTrades.setFxSize(fxSize);
				mergedCptyLiveTrades.setFxIntlSize(fxIntlSize);

				currLiveTrades.add(mergedCptyLiveTrades);

				// reset the counts
				totalSize = 0;
				commSize = 0;
				crSize = 0;
				irSize = 0;
				eqSize = 0;
				fxSize = 0;
				fxIntlSize = 0;
				prevLegalId = 0;				
				totalSize = 0;

			
			}

		}

		return currLiveTrades;
	}

}
