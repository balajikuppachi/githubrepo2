package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrLiveTradeCSVReader extends LoaderHelper<RegRepPrLiveTrade> {
	public static String PORTFOLIO_SEGMENT_NAME = "Live Trades, SDR";
	@Value("${file.livetrades.epr.header}") int headerRows;
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.LIVE_TRADE;
	}

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new CsvWithHeaderReader(inputStream, headerRows);
	}

	@Override
	public RegRepPrLiveTrade parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrLiveTrade trades = new RegRepPrLiveTrade();
	
		trades.setTradeId(fields[0]);
		trades.setAssetClass(fields[1]);
		trades.setParty1Lei(fields[2]);
		trades.setParty2Lei(fields[3]);
		trades.setBaId(convertStrtoInt(fields[4]));
		trades.setUltimateCptyId(convertStrtoInt(fields[5]));
		trades.setUsi(fields[6]);
		trades.setUti(fields[7]);
		trades.setAsOfDate(asofDate);
	return trades;
	}

	@Override
	public boolean validate(RegRepPrLiveTrade trade) {
		boolean canLoad = true;
		return canLoad;
	}
	
	private int convertStrtoInt(String baid){
		baid.trim();
		int baID = 0;
			try {
				baID = Integer.parseInt(baid);
			}catch (Exception ex){
				ex.getMessage();}
		return baID;
	}

	@Override
	public RegRepPrLiveTrade getTableName() {
		return new RegRepPrLiveTrade();
	}

	@Override
	public boolean deletePrevDayRecords() {
		return true;
	}

	@Override
	public String loadNextJob() {
		return null;
	}
}
