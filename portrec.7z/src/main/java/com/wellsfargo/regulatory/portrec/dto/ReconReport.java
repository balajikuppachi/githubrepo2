package com.wellsfargo.regulatory.portrec.dto;

import java.sql.Timestamp;
import java.util.Date;

/**
 * @author Raji Komatreddy
 */
public class ReconReport
{
	private Long reconReportId;
	private long jobExecutionId;
	private int cidCptyId;
	private String cptyType;
	private Date asOfDate;
	private String reconFreq;
	private int portfolioSize;
	private int jsFlag;
	private String domInt1;
	private String commType;
	private String emailAddress;
	private String customerName1;
	private String customerName2;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String zipCode;
	private String country;
	private String lgleFullN;
	private Date createDatetime;

	public Long getReconReportId()
	{
		return reconReportId;
	}

	public void setReconReportId(Long reconReportId)
	{
		this.reconReportId = reconReportId;
	}

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public int getCidCptyId()
	{
		return cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public String getCptyType()
	{
		return cptyType;
	}

	public void setCptyType(String cptyType)
	{
		this.cptyType = cptyType;
	}

	public Date getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getReconFreq()
	{
		return reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public int getPortfolioSize()
	{
		return portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public int getJsFlag()
	{
		return jsFlag;
	}

	public void setJsFlag(int jsFlag)
	{
		this.jsFlag = jsFlag;
	}

	public String getDomInt1()
	{
		return domInt1;
	}

	public void setDomInt1(String domInt1)
	{
		this.domInt1 = domInt1;
	}

	public String getCommType()
	{
		return commType;
	}

	public void setCommType(String commType)
	{
		this.commType = commType;
	}

	public String getEmailAddress()
	{
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}

	public String getCustomerName1()
	{
		return customerName1;
	}

	public void setCustomerName1(String customerName1)
	{
		this.customerName1 = customerName1;
	}

	public String getCustomerName2()
	{
		return customerName2;
	}

	public void setCustomerName2(String customerName2)
	{
		this.customerName2 = customerName2;
	}

	public String getAddressLine1()
	{
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2()
	{
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2)
	{
		this.addressLine2 = addressLine2;
	}

	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getZipCode()
	{
		return zipCode;
	}

	public void setZipCode(String zipCode)
	{
		this.zipCode = zipCode;
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getLgleFullN()
	{
		return lgleFullN;
	}

	public void setLgleFullN(String lgleFullN)
	{
		this.lgleFullN = lgleFullN;
	}

	public Date getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

}
