package com.wellsfargo.regulatory.portrec.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dto.PrException;

/**
 * @author Raji Komatreddy
 */
@Component
public class RegRepPrExceptionDaoImpl
{

	@Autowired
	@Qualifier("portrecJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	String sql = "insert into REG_REP_PR_EXCEPTION (job_execution_id, cid_cpty_id," 
				+ " exception_type, exception_source, exception_desc, exception_trace,  create_datetime) "
				+ "values (?, ?, ?, ?,  ?, ?,?)";

	Logger logger = Logger.getLogger(RegRepPrCptyReconFreqDaoImpl.class);

	public int batchInsertPrException(final List<PrException> PrExceptionList) throws PortrecException
	{

		java.util.Date currDate = new java.util.Date();
		try
		{
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{

					PrException currPrException = PrExceptionList.get(i);

					ps.setLong(1, currPrException.getJobExecutionId());
					ps.setLong(2, currPrException.getCidCptyId());
					ps.setString(3, currPrException.getExceptionType());
					ps.setString(4, currPrException.getExceptionSource());
					ps.setString(5, currPrException.getExceptionDesc());
					ps.setString(6, currPrException.getExceptionTrace());
					ps.setDate(7, new java.sql.Date(currDate.getTime()));

				}

				@Override
				public int getBatchSize()
				{
					return PrExceptionList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrExceptionDaoImpl :batchInsertPrException method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrExceptionDaoImpl :batchInsertPrException method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrExceptionDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);
		}

		logger.info("from batchInsertPrException : number of records inserted" + PrExceptionList.size());

		return PrExceptionList.size();

	}

}
