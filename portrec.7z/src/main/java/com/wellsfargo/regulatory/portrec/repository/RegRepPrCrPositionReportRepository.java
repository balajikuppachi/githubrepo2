package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
/**
 * 
 * @author Raji Komatreddy
 *Repository to save or get data from RegRepPrCrPositionReport table
 */
public interface RegRepPrCrPositionReportRepository extends CrudRepository<RegRepPrCrPositionReport, Long>
{

	@Query("select cr from RegRepPrCrPositionReport cr where cr.asOfDate=?1 and (cr.tradeParty1=?2 or cr.tradeParty2=?3) ")
	public List<RegRepPrCrPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);
	
	/*@Query("select cr from RegRepPrCrPositionReport cr where cr.asOfDate=?1 and (cr.tradeParty1 LIKE %?2 or cr.tradeParty2 LIKE %?3) ")
	public List<RegRepPrCrPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);*/
	
	@Query("select cr.usi from RegRepPrCrPositionReport cr where cr.usi!='' and cr.regRepPrJobExecutionDetail=?")
	List<String> findUsiCr(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select ir from RegRepPrCrPositionReport ir where ir.regRepPrJobExecutionDetail=?1 ")
	public List<RegRepPrCrPositionReport> findPositionsByDate(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
}
