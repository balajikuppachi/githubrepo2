package com.wellsfargo.regulatory.portrec.repository;

import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;

/**
 * 
 * @author Raji Komatreddy
 *Repository to save or get data from RegRepPrException table  
 */
public interface RegRepPrExceptionRepository extends CrudRepository<RegRepPrException, Long>
{

}
