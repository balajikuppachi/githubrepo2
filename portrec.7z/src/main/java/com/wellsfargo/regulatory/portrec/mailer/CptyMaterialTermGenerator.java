package com.wellsfargo.regulatory.portrec.mailer;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.reports.CmCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.CrCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.EqCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.FxCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.IrCptyCsvGenerator;

/**
 * @author u235720
 *
 */
@Component
public class CptyMaterialTermGenerator {
	
	private final Logger logger = Logger.getLogger(CptyMaterialTermGenerator.class);

	@Autowired
	IrCptyCsvGenerator iRCptyCsvGenerator;
	
	@Autowired
	CrCptyCsvGenerator cRCptyCsvGenerator;
	
	@Autowired
	FxCptyCsvGenerator fxCptyCsvGenerator;
	
	@Autowired
	EqCptyCsvGenerator eQCptyCsvGenerator;
	
	@Autowired
	CmCptyCsvGenerator cmCptyCsvGenerator;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	
	public PrExtractsTo generateMeterialTermFiles(List<String> counterPartyLeiList, Long legalId, Date asOfDate, String frequency, long jobExecutionId) {
		
		logger.info("Start generating MT - legalId :[" + legalId + "], asOfDate :["+ asOfDate +"]");
		
		PrExtractsTo matExTo = new PrExtractsTo();
		
		int totalMtCount = 0;
		
		try{
			PrExtractsTo irExTo = iRCptyCsvGenerator.createFile(counterPartyLeiList,legalId, asOfDate, frequency);
			matExTo.setIrCount(irExTo.getIrCount());
			matExTo.setIrMtFileName(irExTo.getIrMtFileName());
			totalMtCount = totalMtCount + irExTo.getIrCount();
		}
		catch(Exception ce){
			String errorMsg = "Error generating IR MT File";
			portrecExceptionLogger.logExceptionScenario("CptyMaterialTermGenerator-1",errorMsg, ce, jobExecutionId, legalId);
		}
		
		try{
			PrExtractsTo crExTo = cRCptyCsvGenerator.createFile(counterPartyLeiList,legalId, asOfDate, frequency);
			matExTo.setCrCount(crExTo.getCrCount());
			matExTo.setCrMtFileName(crExTo.getCrMtFileName());
			totalMtCount = totalMtCount + crExTo.getCrCount();
		}
		catch(Exception ce){
			String errorMsg = "Error generating CR MT File";
			portrecExceptionLogger.logExceptionScenario("CptyMaterialTermGenerator-2",errorMsg, ce, jobExecutionId, legalId);
		}
		
		try{
			PrExtractsTo fxExTo = fxCptyCsvGenerator.createFile(counterPartyLeiList,legalId, asOfDate, frequency);
			matExTo.setFxCount(fxExTo.getFxCount());
			matExTo.setFxMtFileName(fxExTo.getFxMtFileName());
			totalMtCount = totalMtCount + fxExTo.getFxCount();
		}
		catch(Exception ce){
			String errorMsg = "Error generating FX MT File";
			portrecExceptionLogger.logExceptionScenario("CptyMaterialTermGenerator-3",errorMsg, ce, jobExecutionId, legalId);
		}
		
		try{
			PrExtractsTo eqExTo = eQCptyCsvGenerator.createFile(counterPartyLeiList,legalId, asOfDate, frequency);
			matExTo.setEqCount(eqExTo.getEqCount());
			matExTo.setEqMtFileName(eqExTo.getEqMtFileName());
			totalMtCount = totalMtCount + eqExTo.getEqCount();
		}
		catch(Exception ce){
			String errorMsg = "Error generating EQ MT File";
			portrecExceptionLogger.logExceptionScenario("CptyMaterialTermGenerator-4",errorMsg, ce, jobExecutionId, legalId);
		}

		try{
			PrExtractsTo cmExTo = cmCptyCsvGenerator.createFile(counterPartyLeiList,legalId, asOfDate, frequency);
			matExTo.setComCount(cmExTo.getComCount());
			matExTo.setComMtFileName(cmExTo.getComMtFileName());
			totalMtCount = totalMtCount + cmExTo.getComCount();
		}
		catch(Exception ce){
			String errorMsg = "Error generating COMM MT File";
			portrecExceptionLogger.logExceptionScenario("CptyMaterialTermGenerator-5",errorMsg, ce, jobExecutionId, legalId);
		}
	
		matExTo.setTotalMtCount(totalMtCount);
		
		logger.info("End generating MT - legalId :[" + legalId + "], asOfDate :["+ asOfDate +"]");
		
		return matExTo;
	}
	
}
