package com.wellsfargo.regulatory.portrec.da.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


@Embeddable
public class PortrecFilesListPk  implements Serializable{
	
	@Column(name = "BO_Cntr_Pty_ID", nullable = false)
	String cptyId = "";
	
	@Column(name = "Template_Type", nullable = false)
	String templateType;
	
	@Column(name = "Recon_Date", nullable = false)
	String reconDate = "";

	public String getCptyId() {
		return cptyId;
	}

	public void setCptyId(String cptyId) {
		this.cptyId = cptyId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public String getReconDate() {
		return reconDate;
	}

	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cptyId == null) ? 0 : cptyId.hashCode());
		result = prime * result
				+ ((reconDate == null) ? 0 : reconDate.hashCode());
		result = prime * result
				+ ((templateType == null) ? 0 : templateType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortrecFilesListPk other = (PortrecFilesListPk) obj;
		if (cptyId == null) {
			if (other.cptyId != null)
				return false;
		} else if (!cptyId.equals(other.cptyId))
			return false;
		if (reconDate == null) {
			if (other.reconDate != null)
				return false;
		} else if (!reconDate.equals(other.reconDate))
			return false;
		if (templateType == null) {
			if (other.templateType != null)
				return false;
		} else if (!templateType.equals(other.templateType))
			return false;
		return true;
	}

	

}