package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrIrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;

/**
 * 
 * @author Raji Komatreddy
 * Repository to save or get data from RegRepPrAlgoValuation table
 *
 */
public interface RegRepPrIrPositionReportRepository extends CrudRepository<RegRepPrIrPositionReport, Long>
{

	
	@Query("select ir from RegRepPrIrPositionReport ir where ir.asOfDate=?1 and (ir.tradeParty1=?2 or ir.tradeParty2=?3) ")
	public List<RegRepPrIrPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);
	
	/*@Query("select ir from RegRepPrIrPositionReport ir where ir.asOfDate=?1 and (ir.tradeParty1 LIKE %?2 or ir.tradeParty2 LIKE %?3) ")
	public List<RegRepPrIrPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);*/
	
	@Query("select ir.usi from RegRepPrIrPositionReport ir where ir.usi!='' and ir.regRepPrJobExecutionDetail=?")
	List<String> findUsiIr(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select ir from RegRepPrIrPositionReport ir where ir.regRepPrJobExecutionDetail=?1 ")
	public List<RegRepPrIrPositionReport> findPositionsByDate(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	

	
}
