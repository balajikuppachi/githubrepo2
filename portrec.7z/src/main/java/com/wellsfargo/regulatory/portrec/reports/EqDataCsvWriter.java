package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.FileWriter;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrEqPositionReport;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;

/**
 * @author u235720
 *
 */
@Component
public class EqDataCsvWriter {

	private final Logger logger = Logger.getLogger(EqDataCsvWriter.class);
	
	static char SEPARATOR = ',';
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;

	public void generateFile(File targetFile, Map<String,RegRepPrEqPositionReport> usiTrdIdMap, String src, boolean maskingFlag) throws Exception{		
		try {			

			if (targetFile.exists()) {
				targetFile.delete();
			}	
			
			FileWriter writer = new FileWriter(targetFile);
			
			writer.append("USI");
			writer.append(SEPARATOR);
			writer.append("Trade Id");
			writer.append(SEPARATOR);
			writer.append("Reporting prty LEI");
			writer.append(SEPARATOR);
			writer.append("Report SD");
			writer.append(SEPARATOR);
			writer.append("Report MSP");
			writer.append(SEPARATOR);
			writer.append("Report Fin");
			writer.append(SEPARATOR);
			writer.append("Report US");
			writer.append(SEPARATOR);
			writer.append("Non Report LEI");
			writer.append(SEPARATOR);
			writer.append("Non Report ident");
			writer.append(SEPARATOR);
			writer.append("Non Rept SD");
			writer.append(SEPARATOR);
			writer.append("Non Rep MSP");
			writer.append(SEPARATOR);
			writer.append("Non Rep Fin");
			writer.append(SEPARATOR);
			writer.append("Non Rep US");
			writer.append(SEPARATOR);
			writer.append("Product ID");
			writer.append(SEPARATOR);
			writer.append("CFTC Prod Id");
			writer.append(SEPARATOR);
			writer.append("Int Prod Id");
			writer.append(SEPARATOR);
			writer.append("Multi Asset");
			writer.append(SEPARATOR);
			writer.append("Pri Asset Class");
			writer.append(SEPARATOR);
			writer.append("Sec Asset Class");
			writer.append(SEPARATOR);
			writer.append("Mixed Swap");
			
			writer.append(SEPARATOR);
			writer.append("SDR2");
			writer.append(SEPARATOR);
			writer.append("Buyer");
			writer.append(SEPARATOR);
			writer.append("Seller");
			writer.append(SEPARATOR);
			writer.append("Under Asset Id Type");
			writer.append(SEPARATOR);
			writer.append("Under Asset");
			writer.append(SEPARATOR);
			writer.append("Under Asset Notional");
			writer.append(SEPARATOR);
			writer.append("Under Asset Notional Ccy");

			writer.append(SEPARATOR);
			writer.append("Under Asset Weight");
			writer.append(SEPARATOR);
			writer.append("Contract Type");
			writer.append(SEPARATOR);
			writer.append("Exec Venue");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Term date");
			writer.append(SEPARATOR);
			writer.append("Valuation Date");
			writer.append(SEPARATOR);
			writer.append("Eq Leg Val Date");

			writer.append(SEPARATOR);
			writer.append("Eq Variance Strike Price");
			writer.append(SEPARATOR);
			writer.append("Volatility Strike Price");
			writer.append(SEPARATOR);
			writer.append("Initial Price");
			writer.append(SEPARATOR);
			writer.append("Price Notation");
			writer.append(SEPARATOR);
			writer.append("Price Notation type");
			writer.append(SEPARATOR);
			writer.append("Vega Notional Amt");
			writer.append(SEPARATOR);
			writer.append("Vega Notional Ccy");
			
			writer.append(SEPARATOR);
			writer.append("Party 1 Notional Amt");
			writer.append(SEPARATOR);
			writer.append("Party 1 Notional Ccy");
			writer.append(SEPARATOR);
			writer.append("Premium");
			writer.append(SEPARATOR);
			writer.append("Eq Pay Freq Period");
			writer.append(SEPARATOR);
			writer.append("Eq Pay Freq Multiplier");
			writer.append(SEPARATOR);
			writer.append("Float Leg Pay Freq Period");
			writer.append(SEPARATOR);
			writer.append("Float Pay Freq Multiplier");

			
			writer.append(SEPARATOR);
			writer.append("Eq Pay Dat");
			writer.append(SEPARATOR);
			writer.append("Float Pay Dt");
			writer.append(SEPARATOR);
			writer.append("Eq Val Dt");
			writer.append(SEPARATOR);
			writer.append("Float Val Dt");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);			
			writer.append("Execution Date");
			writer.append(SEPARATOR);
			writer.append("Cpty Name");
			writer.append('\n');
			
			//for (RegRepPrEqPositionReport srcViewDomain : srcViewDomainList) {
			if(StringUtils.contains(src, "SRC")){
				Iterator it = usiTrdIdMap.entrySet().iterator();
				while (it.hasNext()) {
			        Map.Entry pairs = (Map.Entry)it.next();
			        RegRepPrEqPositionReport srcViewDomain = (RegRepPrEqPositionReport)pairs.getValue();
			        String usi = (String)pairs.getKey();
			        String[] parts = usi.split(":");
			        usi=parts[0];
			        srcViewDomain.setUsi(usi);
			       
			        writer.append(null != srcViewDomain.getUsi() ? srcViewDomain.getUsi() : "");
			        writer.append(SEPARATOR);
			        writer.append(null != srcViewDomain.getOrigTradeId() ? srcViewDomain.getOrigTradeId() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiCp() ? srcViewDomain.getLeiCp() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2FinancialEntity() ? srcViewDomain.getTradeParty2FinancialEntity() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2UspersonIndicator() ? srcViewDomain.getTradeParty2UspersonIndicator() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiUs() ? srcViewDomain.getLeiUs() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiUs() ? srcViewDomain.getLeiUs() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : "");  
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1FinancialEntity() ? srcViewDomain.getTradeParty1FinancialEntity() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1UspersonIndicator() ? srcViewDomain.getTradeParty1UspersonIndicator() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getProductIdValue() ? srcViewDomain.getProductIdValue() : ""); 
					writer.append(SEPARATOR);  
					writer.append("");  // CFTC Prod Id
					writer.append(SEPARATOR);
					writer.append(""); // Internal Prod Id
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMultiAsset() ? srcViewDomain.getIsSwapMultiAsset() : ""); 				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAssetClass() ? srcViewDomain.getAssetClass() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getSecAssetClass() ? srcViewDomain.getSecAssetClass() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMixed() ? srcViewDomain.getIsSwapMixed() : "");	
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAdd_SDR_for_mixed_swap() ? srcViewDomain.getAdd_SDR_for_mixed_swap() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getBuyer() ? srcViewDomain.getBuyer() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getWeBuySell() ? srcViewDomain.getWeBuySell() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetIdentifierType() ? srcViewDomain.getUnderlyingAssetIdentifierType() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssets() ? srcViewDomain.getUnderlyingAssets(): ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotional() ? srcViewDomain.getUnderlyingAssetsNotional() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotionalCurr() ? srcViewDomain.getUnderlyingAssetsNotionalCurr() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsWeighting() ? srcViewDomain.getUnderlyingAssetsWeighting() : ""); 			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getProductIdValue() ? srcViewDomain.getProductIdValue() : ""); 		
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionVenue() ? srcViewDomain.getExecutionVenue() : "");			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getTradeDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getMaturityDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getMaturityDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getValuationDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getEqLegValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEquityVarianceStrikePrice() ? srcViewDomain.getEquityVarianceStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVolatilityStrikePrice() ? srcViewDomain.getVolatilityStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getInitialPrice() ? srcViewDomain.getInitialPrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotation() ? srcViewDomain.getPriceNotation() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotationType() ? srcViewDomain.getPriceNotationType() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1VegaNotionalAmount() ? srcViewDomain.getParty1VegaNotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVegaNotionalCurr() ? srcViewDomain.getVegaNotionalCurr().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalAmount() ? srcViewDomain.getParty1NotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalCurr() ? srcViewDomain.getParty1NotionalCurr().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpFrontPaymentAmount() ? srcViewDomain.getUpFrontPaymentAmount().toString() : "");				
					writer.append(SEPARATOR);
					writer.append(""); // Eq Pay Freq Period
					writer.append(SEPARATOR);
					writer.append(""); // Eq Pay Freq Multiplier
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFreqPeriod() ? srcViewDomain.getFloatingLegPaymentFreqPeriod() : "");					
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFreqPeriodMult() ? srcViewDomain.getFloatingLegPaymentFreqPeriodMult() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegPaymentDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getEqLegPaymentDate()) : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFltLegPaymentDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getFltLegPaymentDate()) : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getEqLegValuationDate()) : "");				
					writer.append(SEPARATOR);
					writer.append("");				 // Float Val Dt
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getCollaterlized() ? srcViewDomain.getCollaterlized() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getExecutionDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2Name() ? srcViewDomain.getTradeParty2Name() : "");
					writer.append('\n');
				}
			}else {
				Iterator it = usiTrdIdMap.entrySet().iterator();
				while (it.hasNext()) {
					 Map.Entry pairs = (Map.Entry)it.next();
			        RegRepPrEqPositionReport srcViewDomain = (RegRepPrEqPositionReport)pairs.getValue();
			        String usi = (String)pairs.getKey();
			        String[] parts = usi.split(":");
			        usi=parts[0];
			        srcViewDomain.setUsi(usi);
			        writer.append(null != srcViewDomain.getUsi() ? srcViewDomain.getUsi() : "");
			        writer.append(SEPARATOR);
			        if(StringUtils.isNotBlank(srcViewDomain.getOrigTradeId()))
			        	 writer.append(srcViewDomain.getOrigTradeId());
			        else 
			        	writer.append("");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiUs() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getLeiUs(), maskingFlag) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : ""); // Party 1 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty2Role() ? srcViewDomain.getParty2Role() : ""); // Party 2 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1FinancialEntity() ? srcViewDomain.getTradeParty1FinancialEntity() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty1UspersonIndicator() ? srcViewDomain.getTradeParty1UspersonIndicator() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiCp() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getLeiCp(), maskingFlag) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getLeiCp() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getLeiCp(), maskingFlag) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : ""); // Party 1 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1Role() ? srcViewDomain.getParty1Role() : "");  // Party 2 role
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2FinancialEntity() ? srcViewDomain.getTradeParty2FinancialEntity() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2UspersonIndicator() ? srcViewDomain.getTradeParty2UspersonIndicator() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getProductIdValue() ? srcViewDomain.getProductIdValue() : ""); 
					writer.append(SEPARATOR);  
					writer.append("");  // CFTC Prod Id
					writer.append(SEPARATOR);
					writer.append(""); // Internal Prod Id
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMultiAsset() ? srcViewDomain.getIsSwapMultiAsset() : ""); 				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAssetClass() ? srcViewDomain.getAssetClass() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getSecAssetClass() ? srcViewDomain.getSecAssetClass() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getIsSwapMixed() ? srcViewDomain.getIsSwapMixed() : "");	
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getAdd_SDR_for_mixed_swap() ? srcViewDomain.getAdd_SDR_for_mixed_swap() : "");				
					writer.append(SEPARATOR);
					String buyer = srcViewDomain.getBuyer(); // We are breaking on Buyer  column where counterparty used DTCC ID (6192- Wells Fargo DTCC id  ) in place of LEI – would it be possible translate it to LEI?
					if(StringUtils.isNotBlank(srcViewDomain.getBuyer()) && (buyer.equalsIgnoreCase("6192") || buyer.equalsIgnoreCase("006192") || buyer.equalsIgnoreCase("00006192")))
						buyer = "KB1H1DSPRFMYMCUFXT09";
					writer.append(null != buyer ? portRecBusinessUtil.maskCounterPartyDetails(buyer, maskingFlag) : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getWeBuySell() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getWeBuySell(), maskingFlag) : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetIdentifierType() ? srcViewDomain.getUnderlyingAssetIdentifierType() : ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssets() ? srcViewDomain.getUnderlyingAssets(): ""); 
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotional() ? srcViewDomain.getUnderlyingAssetsNotional() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsNotionalCurr() ? srcViewDomain.getUnderlyingAssetsNotionalCurr() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUnderlyingAssetsWeighting() ? srcViewDomain.getUnderlyingAssetsWeighting() : ""); 			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getProductIdValue() ? srcViewDomain.getProductIdValue() : ""); 		
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionVenue() ? srcViewDomain.getExecutionVenue() : "");			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getTradeDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getMaturityDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getMaturityDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getValuationDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getEqLegValuationDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEquityVarianceStrikePrice() ? srcViewDomain.getEquityVarianceStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVolatilityStrikePrice() ? srcViewDomain.getVolatilityStrikePrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getInitialPrice() ? srcViewDomain.getInitialPrice().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotation() ? srcViewDomain.getPriceNotation() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getPriceNotationType() ? srcViewDomain.getPriceNotationType() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1VegaNotionalAmount() ? srcViewDomain.getParty1VegaNotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getVegaNotionalCurr() ? srcViewDomain.getVegaNotionalCurr().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalAmount() ? srcViewDomain.getParty1NotionalAmount().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getParty1NotionalCurr() ? srcViewDomain.getParty1NotionalCurr().toString() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getUpFrontPaymentAmount() ? srcViewDomain.getUpFrontPaymentAmount().toString() : "");				
					writer.append(SEPARATOR);
					writer.append("");
					writer.append(SEPARATOR);
					writer.append("");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFreqPeriod() ? srcViewDomain.getFloatingLegPaymentFreqPeriod() : "");					
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFloatingLegPaymentFreqPeriodMult() ? srcViewDomain.getFloatingLegPaymentFreqPeriodMult() : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegPaymentDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getEqLegPaymentDate()) : "");			
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getFltLegPaymentDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getFltLegPaymentDate()) : "");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getEqLegValuationDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getEqLegValuationDate()) : "");				
					writer.append(SEPARATOR);
					writer.append("");				
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getCollaterlized() ? srcViewDomain.getCollaterlized() : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getExecutionDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getExecutionDate()) : "");
					writer.append(SEPARATOR);
					writer.append(null != srcViewDomain.getTradeParty2Name() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getTradeParty2Name(), maskingFlag) : "");
					writer.append('\n');
				}
			}
			writer.flush();
			writer.close();
		}
		catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
	}
	
	/*private String maskCounterPartyDetails(String leiValue){
		String cpVal = "";
		if(null!=leiValue){
			if(StringUtils.contains(wfLeiList, leiValue)){
				cpVal = leiValue;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}*/
	
}
