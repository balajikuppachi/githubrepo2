package com.wellsfargo.regulatory.portrec.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;

/**
 * 
 * @author Raji Komatreddy
 * Repository to save or get data from RegRepPrJobDetail table
 *
 */
public interface RegRepPrJobDetailRepository extends CrudRepository<RegRepPrJobDetail, Long>
{
	List<RegRepPrJobDetail> findByjobName(String jobName);
	
	@Query(value = "Select recal.* from REG_REP_PR_JOB_DETAILS recal where recal.job_desc not in (?1)", nativeQuery = true)
	List<RegRepPrJobDetail> findOtherjobID(Collection<String> jobID);

}
