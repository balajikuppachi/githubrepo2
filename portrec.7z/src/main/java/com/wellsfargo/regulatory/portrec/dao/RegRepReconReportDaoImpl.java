package com.wellsfargo.regulatory.portrec.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dto.ReconReport;

/**
 * @author Raji Komatreddy
 */
@Component
public class RegRepReconReportDaoImpl
{

	@Autowired
	@Qualifier("portrecJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	String sql = "insert into REG_REP_PR_RECON_REPORT (job_execution_id, cid_cpty_id, cptyl_type, as_of_date,"
	        + " recon_freq, portfolio_size, js_flag, dom_intl, comm_type, email_address, customer_name1,"
	        + " customer_name2, address_line1, address_line2, city, state, zip_code, country, legal_name, create_datetime)" 
	        + " values(?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?,?,?, ?, ?, ?)";

	Logger logger = Logger.getLogger(RegRepPrDaReportDaoImpl.class);

	public int batchInsertReconReport(final List<ReconReport> reconReportList) throws PortrecException
	{

		java.util.Date currDate = new java.util.Date();
		try
		{
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{
					ReconReport currReconReport = reconReportList.get(i);

					ps.setLong(1, currReconReport.getJobExecutionId());
					ps.setInt(2, currReconReport.getCidCptyId());
					ps.setString(3, currReconReport.getCptyType());
					if (null != currReconReport.getAsOfDate())
					{
						ps.setDate(4, (Date) new java.sql.Date(currReconReport.getAsOfDate().getTime()));
					}
					else
					{
						ps.setDate(4, null);
					}
					ps.setString(5, currReconReport.getReconFreq());
					ps.setInt(6, currReconReport.getPortfolioSize());
					ps.setInt(7, currReconReport.getJsFlag());
					ps.setString(8, currReconReport.getDomInt1());
					ps.setString(9, currReconReport.getCommType());
					ps.setString(10, currReconReport.getEmailAddress());
					ps.setString(11, currReconReport.getCustomerName1());
					ps.setString(12, currReconReport.getCustomerName2());
					ps.setString(13, currReconReport.getAddressLine1());
					ps.setString(14, currReconReport.getAddressLine2());
					ps.setString(15, currReconReport.getCity());
					ps.setString(16, currReconReport.getState());
					ps.setString(17, currReconReport.getZipCode());
					ps.setString(18, currReconReport.getCountry());
					ps.setString(19, currReconReport.getLgleFullN());
					ps.setDate(20, new java.sql.Date(currDate.getTime()));

				}

				@Override
				public int getBatchSize()
				{
					return reconReportList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepReconReportDaoImpl :batchInsertReconReport method" + ex.getMessage();
			logger.error("exception occurred inside RegRepReconReportDaoImpl :batchInsertReconReport method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepReconReportDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);
		}

		logger.info("from batchInsertReconReport : number of records inserted" + reconReportList.size());

		return reconReportList.size();

	}

}
