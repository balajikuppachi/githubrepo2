package com.wellsfargo.regulatory.portrec.mailer;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.da.domain.PortRecAuditLogView;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrDaAffirmLog;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrDaReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrDaAffirmLogRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrDaReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;

/**
 * @author u235720
 *
 */
@Component
public class CptyDerivativeAccessService {
	
	private final Logger logger = Logger.getLogger(CptyDerivativeAccessService.class);

	@Autowired
	RegRepPrDaReportRepository regRepPrDaReportRepository ;
	
	@Autowired
	RegRepPrDaAffirmLogRepository regRepPrDaAckHistoryRepository;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	public void makeDaEntry(Date asOfDate, String assetClass, Long legalId, String fileName, String cptyType, String mtValType, String reconFreq, 
			String fileException, String fileExceptionReason, int portfolioSize, RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {		
			
		logger.info("Saving into REG_REP_PR_DA_REPORT. Legal Id = [" + legalId + "], Asset Class = [" + assetClass + "]");
		RegRepPrDaReport repPrDaReport = new RegRepPrDaReport();
		repPrDaReport.setAsOfDate(asOfDate);
		repPrDaReport.setAssetClass(assetClass);
		repPrDaReport.setCidCptyId(legalId.intValue());	
		repPrDaReport.setCreateDatetime(new Date());
		repPrDaReport.setFileName(fileName);
		repPrDaReport.setCptyType(cptyType);
		repPrDaReport.setMtValType(mtValType);
		repPrDaReport.setReconFreq(reconFreq);
		repPrDaReport.setJobExecutionId(regRepPrJobExecutionDetail);
		repPrDaReport.setFileException(fileException);
		repPrDaReport.setFileExceptionReason(fileExceptionReason);
		repPrDaReport.setPortfolioSize(portfolioSize);
		
		regRepPrDaReportRepository.save(repPrDaReport);
	}
	
	
	public List<RegRepPrDaReport> getCptyDaReportDetailByJobExecutionId(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		return regRepPrDaReportRepository.findByJobExecutionId(regRepPrJobExecutionDetail);
	}
	
	
	public void updateDaReportWithUserAck(PortRecAuditLogView acknwledge, RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		
		Long legalId = null;
		try {
			
			RegRepPrDaReport cptyReportDetail = regRepPrDaReportRepository.findByFileName(acknwledge.getFileName());
			
			if(null != cptyReportDetail){
				
				boolean flag = false;
				
				if(null == cptyReportDetail.getAffirmedFlag()){
					flag = true;
				}
				
				if(null != cptyReportDetail.getAffirmedFlag() && !cptyReportDetail.getAffirmedFlag().equalsIgnoreCase(acknwledge.getAffirmedFlag())){
					flag = true;
				}
				
				if(flag){
					logger.info("Record found in REG_REP_PR_DA_REPORT table with provided file name =["+acknwledge.getFileName()+"]");
					legalId = Long.valueOf(cptyReportDetail.getCidCptyId());
					cptyReportDetail.setAffirmedFlag(acknwledge.getAffirmedFlag());
					cptyReportDetail.setAffirmDatetime(acknwledge.getPortRecAuditLogViewPk().getAffirmDate());
					cptyReportDetail.setAffirmComments(acknwledge.getUserComment());
					regRepPrDaReportRepository.save(cptyReportDetail);
					
					createDaAffirmLogEntry(acknwledge, regRepPrJobExecutionDetail);
				}
				
			}else{
				logger.error("No record found in REG_REP_PR_DA_REPORT table with provided file name =["+acknwledge.getFileName()+"]");
			}
		
		} catch (Exception e) {
			String errorMsg = "Error saving DA User Ack information";
			long jobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
			portrecExceptionLogger.logExceptionScenario("CptyDerivativeAccessService-2", errorMsg, e, jobExecutionId, legalId);
		}
	}


	public void saveDaAffirmLog(RegRepPrDaAffirmLog regRepPrDaAckHistory, RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		
		Long legalId = Long.valueOf(regRepPrDaAckHistory.getCidCptyId());
		try {
			regRepPrDaAckHistoryRepository.save(regRepPrDaAckHistory);
		} catch (Exception e) {
			String errorMsg = "Error saving DA User affirm log information";
			long jobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
			portrecExceptionLogger.logExceptionScenario("CptyDerivativeAccessService-3", errorMsg, e, jobExecutionId, legalId);
		}
		
	}


	public void createDaAffirmLogEntry(PortRecAuditLogView portRecAuditLogView, RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		
		RegRepPrDaAffirmLog regRepPrDaAffirmLog = new RegRepPrDaAffirmLog();
		
		String legalId = portRecAuditLogView.getPortRecAuditLogViewPk().getLegalId(); 
		
		Long longLegalId = null;
		
		if(null != legalId){
			longLegalId = Long.valueOf(legalId);
		}
		
		try {
			
			regRepPrDaAffirmLog.setJobExecutionId(regRepPrJobExecutionDetail);
			regRepPrDaAffirmLog.setCidCptyId(Integer.valueOf(legalId));
			regRepPrDaAffirmLog.setAssetClass(portRecAuditLogView.getPortRecAuditLogViewPk().getAssetClass());
			regRepPrDaAffirmLog.setFileName(portRecAuditLogView.getFileName());
			regRepPrDaAffirmLog.setReconFreq(portRecAuditLogView.getPortRecPeriod());
			
			regRepPrDaAffirmLog.setAsOfDate(PortRecUtil.convertStringToDate_yyyy_MM_dd(portRecAuditLogView.getPortRecAuditLogViewPk().getReconDate()));
		
			regRepPrDaAffirmLog.setMtValType(portRecAuditLogView.getPortRecAuditLogViewPk().getAssetClass().equalsIgnoreCase("VAL") ? "VAL" : "MT");
			regRepPrDaAffirmLog.setAffirmedFlag(portRecAuditLogView.getAffirmedFlag());
			regRepPrDaAffirmLog.setAffirmDatetime(portRecAuditLogView.getPortRecAuditLogViewPk().getAffirmDate());
			regRepPrDaAffirmLog.setAffirmComments(portRecAuditLogView.getUserComment());				
			regRepPrDaAffirmLog.setCreateDatetime(new Date());
		
		} catch (Exception e) {
			String errorMsg = "Error creating DA User Affirm log pojo";
			long jobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
			portrecExceptionLogger.logExceptionScenario("CptyDerivativeAccessService-4", errorMsg, e, jobExecutionId, longLegalId);
		}
		
		saveDaAffirmLog(regRepPrDaAffirmLog, regRepPrJobExecutionDetail);
	}
	
	
	public Date getLatestUpdatedAffirmDateTime(){
		return regRepPrDaReportRepository.findMaxAffirmDateTime();
	}
	
}
