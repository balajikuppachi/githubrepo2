package com.wellsfargo.regulatory.portrec.mailer;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrPositionRecon;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrPositionReconRepository;

/**
 * @author u235720
 *
 */
@Component
public class CptyPositionReconService {
	
	private final Logger logger = Logger.getLogger(CptyPositionReconService.class);

	@Autowired
	RegRepPrPositionReconRepository repPrPositionReconRepository ;
	
	public void makePositionReconEntry(int cidCptyId, Date asOfDate, String reconFrequency, int totalMtCount, int irPosCount, int crPosCount, int eqPosCount, 
			int fxPosCount, int commPosCount, int valuationSize, RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {		
			
		logger.info("Start save into REG_REP_PR_POSITION_RECON. Legal Id = [" + cidCptyId + "]");
		RegRepPrPositionRecon regRepPrPositionRecon = new RegRepPrPositionRecon();

		regRepPrPositionRecon.setCidCptyId(cidCptyId);
		regRepPrPositionRecon.setAsOfDate(asOfDate);
		regRepPrPositionRecon.setReconFreq(reconFrequency);
		regRepPrPositionRecon.setPortfolioSize(totalMtCount);
		regRepPrPositionRecon.setIrPositionSize(irPosCount);
		regRepPrPositionRecon.setCrPositionSize(crPosCount);
		regRepPrPositionRecon.setEqPositionSize(eqPosCount);
		regRepPrPositionRecon.setFxPositionSize(fxPosCount);
		regRepPrPositionRecon.setCommPositionSize(commPosCount);
		regRepPrPositionRecon.setValuationSize(valuationSize);
		regRepPrPositionRecon.setCreateDatetime(new Date());		
		regRepPrPositionRecon.setJobExecutionId(regRepPrJobExecutionDetail);
	
		repPrPositionReconRepository.save(regRepPrPositionRecon);
		
		logger.info("End save into REG_REP_PR_POSITION_RECON. Legal Id = [" + cidCptyId + "]");
	}

	public void updateCptyPosition(int cidCptyId, Date asOfDate, String reconFrequency, int portfolioSize, int valCount, RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {

		logger.info("Start update REG_REP_PR_POSITION_RECON. Legal Id = [" + cidCptyId + "] and valuation count = [" + valCount + "]");
		
		RegRepPrPositionRecon regRepPrPositionRecon = repPrPositionReconRepository.findByCidCptyIdAsOfDate(cidCptyId, asOfDate);
		
		if(null != regRepPrPositionRecon){
			regRepPrPositionRecon.setValuationSize(valCount);
		}else{
			regRepPrPositionRecon = new RegRepPrPositionRecon();
			regRepPrPositionRecon.setCidCptyId(cidCptyId);
			regRepPrPositionRecon.setAsOfDate(asOfDate);
			regRepPrPositionRecon.setReconFreq(reconFrequency);
			regRepPrPositionRecon.setPortfolioSize(portfolioSize);
			regRepPrPositionRecon.setValuationSize(valCount);
			regRepPrPositionRecon.setJobExecutionId(regRepPrJobExecutionDetail);
			regRepPrPositionRecon.setCreateDatetime(new Date());
		}
		
		repPrPositionReconRepository.save(regRepPrPositionRecon);
		
		logger.info("End Update REG_REP_PR_POSITION_RECON. Legal Id = [" + cidCptyId + "]");
	}
	

	
	public List<RegRepPrPositionRecon> getCptyPostionsByPrevJobExecutionId(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		return repPrPositionReconRepository.findByJobExecutionId(regRepPrJobExecutionDetail);
	}
	
	
}
