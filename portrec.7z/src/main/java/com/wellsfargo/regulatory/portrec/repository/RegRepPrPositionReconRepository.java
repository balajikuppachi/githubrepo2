package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrPositionRecon;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public interface RegRepPrPositionReconRepository extends CrudRepository<RegRepPrPositionRecon, Long>
{

	@Query("Select pos from RegRepPrPositionRecon pos where pos.cidCptyId=?1 and pos.asOfDate=?2")
	public RegRepPrPositionRecon findByCidCptyIdAsOfDate(int cidCptyId,Date asOfDate);
	
	
	@Query("Select pos from RegRepPrPositionRecon pos where pos.regRepPrJobExecutionDetail=?1")
	public List<RegRepPrPositionRecon> findByJobExecutionId(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
}
