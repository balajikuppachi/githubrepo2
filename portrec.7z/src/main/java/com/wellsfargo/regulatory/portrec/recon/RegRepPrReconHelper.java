package com.wellsfargo.regulatory.portrec.recon;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;

@Component
public class RegRepPrReconHelper {
	

	@Value("${portrec.recon.file.Location}")
	String portrecReconFileLoc;
	
	private static Logger logger = Logger.getLogger(RegRepPrReconHelper.class);

	public void generateliveTradeFile(String assetclass, Map<String, RegRepPrLiveTrade> liveTradeCount, Date asOfdate) {

		
		DateFormat formatter ; 
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reconFileName = "WFBNA_Recon_"+assetclass+"_"+ formatter.format(asOfdate) +".xls";
		
		File dtccFolder = new File(portrecReconFileLoc+File.separator+ asOfdate);
	   	 File irFile;
	   	 if (dtccFolder.isDirectory()) {
		   	 	 irFile = new File(dtccFolder +File.separator+reconFileName);
		 }
	   	 else {
	   		dtccFolder.mkdirs();
	   		irFile = new File(dtccFolder +File.separator+reconFileName);
	   	 }
	   	FileWriter fw = null;
		try {
			fw = new FileWriter(irFile);
			fw.append("USI").append("\t").append("TradeID").append("\t").append("AssetClass").append("\t").append("Party1LEI").
			append("\t").append("Party2LEI").append("\t").append("ReconCpty").append("\t").append("BAID").append("\t").append("LegalID").append('\n');
			for (Map.Entry<String, RegRepPrLiveTrade> entry : liveTradeCount.entrySet()) {
				/*String tradeID = entry.getValue().getTradeId();*/
				
					fw.append(entry.getKey()).append("\t")
					.append(entry.getValue().getTradeId()).append("\t")
					.append(entry.getValue().getAssetClass()).append("\t")
					.append(entry.getValue().getParty1Lei()).append("\t")
					.append(entry.getValue().getParty2Lei()).append("\t")
					.append(entry.getValue().getReconCpty()).append("\t")
					.append(Integer.toString(entry.getValue().getBaId())).append("\t")
					.append(Integer.toString(entry.getValue().getLegalId())).append("\t")
					.append('\n');;
			}
			fw.close();
			
		} catch (Exception ex){
			logger.error("Error Creating DTCC IR Recon report");
		}
		logger.info("Recon report has been generated: " +  irFile.getAbsolutePath());
		
	
		
	}

}
