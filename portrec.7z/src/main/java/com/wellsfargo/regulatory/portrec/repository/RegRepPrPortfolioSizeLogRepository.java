package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrPortfolioSizeLog;

/**
 * 
 * @author Raji Komatreddy
 *  Repository to save or get data from RegRepPrPortfolioSizeLog table 
 */
public interface RegRepPrPortfolioSizeLogRepository extends CrudRepository<RegRepPrPortfolioSizeLog, Long>
{
	
	@Query("select plog from RegRepPrPortfolioSizeLog plog where plog.asOfDate = ?1")
	List<RegRepPrPortfolioSizeLog> findForAsofDate(Date date);

}
