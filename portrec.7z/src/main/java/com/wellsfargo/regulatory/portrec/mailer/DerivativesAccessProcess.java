package com.wellsfargo.regulatory.portrec.mailer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrDaReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Service
@ManagedResource(description = "DA Process involves Table update and File upload")
public class DerivativesAccessProcess {
	
	private final Logger logger = Logger.getLogger(DerivativesAccessProcess.class);
	
	@Autowired
	private CptyDerivativeAccessService cptyDerivativeAccessService;
	
	@Autowired
	private DerivativesAccessService derivativesAccessService;
	
	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;
	
	@Autowired
	DerivativesAccessFileUploadService derivativesAccessFileUploadService;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;	
	
	@ManagedOperation(description = "Starting DA Process")
	public void startDaActivity(Message<?> message) throws PortrecException
	{
		
		long timeStart = System.currentTimeMillis();
		logger.info("Start DA Process - ");
		
		Object ipMessage = null;
		String errorString = null;
		long currJobExecutionId = 0;
		String jobAsOfDate = null;
		Date asOfDate = new Date();

		RegRepPrJobDetail currRegRepPrJobDetail = null;
		
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);

		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessProcess-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		
		ipMessage = message.getPayload();
		
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)) 
		{
			jobAsOfDate = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();
		}
		
		if (null != jobAsOfDate)
		{
			logger.info(" DA process running for asOfDate received from fileName " + jobAsOfDate);
			try
			{
				asOfDate = reconDateFormat.parse(jobAsOfDate);
				
			}
			catch (ParseException e)
			{
				logger.error("########## " + e.getMessage());
			}
		}

		if (ipMessage instanceof RegRepPrJobDetail)
		{
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail)
		{
			errorString = "Null incoming PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessProcess-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail.getJobName());
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "Exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessProcess-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);

		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		logger.info("JobExecution id for current run of DerivativesAccessProcess " + currJobExecutionId);

		String fileName = "CptyReconMailerProcess";
		String status = "success";
		RegRepPrJobExecutionDetail prevRegRepPrJobExecutionDetail= regRepPrJobExecutionDetailRepository.findPreviousJobExecutionDetail(fileName, status);
		long prevJobExecutionId  = prevRegRepPrJobExecutionDetail.getJobExecutionId();
		
		logger.info("JobExecution id for previous run Mailing Process " + prevJobExecutionId);
		
		try
		{
			
			String daFileAsOfDate = null;
			
			if(null != asOfDate)
			{
				daFileAsOfDate = PortRecUtil.convertDateToString_yyyyMdd(asOfDate);	
			}
			
			if(null != daFileAsOfDate)
			{
				logger.info("Files to be picked are with asOfDate : " + daFileAsOfDate);
				boolean daDataUpdated = updateDaByCurrentJobExecution(prevRegRepPrJobExecutionDetail);

				if(daDataUpdated){
					derivativesAccessFileUploadService.uploadDaFiles(daFileAsOfDate);
				}
				
			}else{
				errorString = "as of date can not be null";
				logger.error("########## " + errorString);
				throw new PortrecException("DerivativesAccessProcess-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
			}
			
		}
		catch (Exception ex)
		{
			logger.error("Error in DA Process : " + ex.getMessage());
			try
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				RegRepPrException regRepPrException = new RegRepPrException();
				regRepPrException.setExceptionSource("DerivativesAccessProcess");
				regRepPrException.setJobExecutionId(currJobExecutionId);
				regRepPrException.setExceptionDesc(errorString);
				regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
				regRepPrException.setExceptionTrace(ExceptionUtils.getStackTrace(ex));
				regRepPrException.setCreateDatetime(new Date());
				portrecExceptionLogger.logExceptionToDB(regRepPrException);
				logger.error("Exception occurred inside DerivativesAccessProcess for jobId #" + currJobExecutionId + "exception message " + errorString);
			}
			catch (Exception e)
			{
				logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}

		}
		
		
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		
		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in DA Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));
	}
	
	
	private boolean updateDaByCurrentJobExecution(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		
		List<RegRepPrDaReport> daReports = cptyDerivativeAccessService.getCptyDaReportDetailByJobExecutionId(regRepPrJobExecutionDetail);
		
		long currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		
		boolean isUpdated = false;
		
		if(null != daReports && !daReports.isEmpty()){
			logger.info("Number of records to be updated : " + daReports.size());
			isUpdated = true;
			derivativesAccessService.persistDaMetaData(daReports);
		}else{
			String errorMsg = "No record found to update DA";
			portrecExceptionLogger.logExceptionScenario("DerivativesAccessProcess-4", errorMsg, null, currJobExecutionId, null);
		}
		
		return isUpdated;
	}
	
}
