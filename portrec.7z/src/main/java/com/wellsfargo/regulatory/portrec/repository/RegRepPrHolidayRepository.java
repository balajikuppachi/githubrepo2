package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrHoliday;

public interface RegRepPrHolidayRepository extends CrudRepository<RegRepPrHoliday, Long>
{
	
	public List<RegRepPrHoliday> findByCodeName(String codeName);
	
	@Query("from RegRepPrHoliday where holidayDate=?1")
	public RegRepPrHoliday isHolidayDate(Date date);
	
	

}
