package com.wellsfargo.regulatory.portrec.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrUsiException;

@Repository
public interface RegRepPrUsiExceptionRepository extends
CrudRepository<RegRepPrUsiException, Long>{

}
