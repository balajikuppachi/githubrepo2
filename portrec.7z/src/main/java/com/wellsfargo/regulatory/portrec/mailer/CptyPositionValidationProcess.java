package com.wellsfargo.regulatory.portrec.mailer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrPositionRecon;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrExceptionRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;

/**
 * @author u235720
 *
 */
@Service
@ManagedResource(description = "Counter Party Position Count Validation")
public class CptyPositionValidationProcess {
	
	private final Logger logger = Logger.getLogger(CptyPositionValidationProcess.class);
	
	/*@Autowired
	PortrecExceptionLogger portrecExceptionLogger;	*/
	
	@Autowired
	RegRepPrExceptionRepository regRepPrExceptionRepository;
	
	@Autowired
	CptyPositionReconService cptyPositionReconService;
	
	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;
	
	@ManagedOperation(description = "Starting Position Validation")
	public void startCptyCountValidation(/*Message<?> message*/) throws PortrecException
	{
		
		long timeStart = System.currentTimeMillis();
		logger.info("Start Position Validation- ");
		
		/*Object ipMessage = null;
		String errorString = null;
		Date reconDate = null;
		long currJobExecutionId = 0;
		String jobAsOfDate = null;
		Date asOfDate = null;

		RegRepPrJobDetail currRegRepPrJobDetail = null;
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);

		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessProcess-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		ipMessage = message.getPayload();
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)) jobAsOfDate = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();

		if (null != jobAsOfDate)
		{
			logger.info(" recon process running for asOfDate received from fileName " + jobAsOfDate);
			try
			{
				asOfDate = reconDateFormat.parse(jobAsOfDate);
				if (null != asOfDate)
				{
					reconDate = asOfDate;
				}
				else
				{
					reconDate = new Date();
				}
			}
			catch (ParseException e)
			{
				logger.error("########## " + e.getMessage());
			}
		}
		else
		{
			reconDate = new Date();
		}

		if (ipMessage instanceof RegRepPrJobDetail)
		{
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail)
		{
			errorString = "Null incoming PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessProcess-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(reconDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail.getJobName());
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessProcess-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);

		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		logger.info("jobExecution id for current run of DerivativesAccessProcess " + currJobExecutionId);*/

		String fileName = "CptyReconMailerProcess";
		String status = "success";
		RegRepPrJobExecutionDetail prevRegRepPrJobExecutionDetail= regRepPrJobExecutionDetailRepository.findPreviousJobExecutionDetail(fileName, status);
		
		
		int batchSize = 0;
		
		
		try{
			
			List<RegRepPrException> exceptionLogs = new ArrayList<RegRepPrException>();

			List<RegRepPrPositionRecon> cptyPositions = cptyPositionReconService.getCptyPostionsByPrevJobExecutionId(prevRegRepPrJobExecutionDetail);
			
			for(RegRepPrPositionRecon positionRecon : cptyPositions){
				
				int irCount = positionRecon.getIrPositionSize();
				int crCount = positionRecon.getCrPositionSize();
				int eqCount = positionRecon.getEqPositionSize();
				int fxCount = positionRecon.getFxPositionSize();
				int cmCount = positionRecon.getCommPositionSize();
				int valCount = positionRecon.getValuationSize();
				
				int portfolioSize = positionRecon.getPortfolioSize();
				
				int mtCount = irCount + crCount + eqCount + fxCount + cmCount;
				
				String errorString = null;
				
				if(mtCount != valCount){
					errorString = "MT and VAL count does not match legal id = " + positionRecon.getCidCptyId();
					exceptionLogs.add(createExceptions(errorString, null));
				}
				
				if(portfolioSize != (valCount + mtCount)){
					errorString = "Portfolio size and MT/VAL count does not match legal id = " + positionRecon.getCidCptyId();
					exceptionLogs.add(createExceptions(errorString, null));
				}
				
				
				if (exceptionLogs.size() == batchSize)
				{
					regRepPrExceptionRepository.save(exceptionLogs);
					exceptionLogs.clear();
				}
			}
			
			regRepPrExceptionRepository.save(exceptionLogs);
			exceptionLogs.clear();
			
		}
		catch (Exception ex)
		{
			logger.error("Error in Position Validation Process : " + ex.getMessage());
			/*try
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				RegRepPrException regRepPrException = new RegRepPrException();
				regRepPrException.setExceptionSource("DerivativesAccessProcess");
				regRepPrException.setJobExecutionId(currJobExecutionId);
				regRepPrException.setExceptionDesc(errorString);
				regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
				regRepPrException.setExceptionTrace(ExceptionUtils.getStackTrace(ex));
				regRepPrException.setCreateDatetime(new Date());
				portrecExceptionLogger.logExceptionToDB(regRepPrException);
				logger.error("Exception occurred inside DerivativesAccessProcess for jobId #" + currJobExecutionId + "exception message " + errorString);
			}
			catch (Exception e)
			{
				logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}*/

		}
		
		
		/*regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);*/
		
		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in Position Validation Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));
	}
	
	
	public RegRepPrException createExceptions(String errorString, Long currJobExecutionId){
		
		RegRepPrException regRepPrException = new RegRepPrException();
		
		try
		{
			regRepPrException.setExceptionSource("CptyPositionValidationProcess");
			regRepPrException.setJobExecutionId(currJobExecutionId);
			regRepPrException.setExceptionDesc(errorString);
			regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
			regRepPrException.setCreateDatetime(new Date());
			//portrecExceptionLogger.logExceptionToDB(regRepPrException);
		
		}
		catch (Exception e)
		{
			logger.error("exception while creating logging exception" + ExceptionUtils.getStackTrace(e));
		}
		
		return regRepPrException;
	}
	
	
	
}
