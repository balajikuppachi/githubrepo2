package com.wellsfargo.regulatory.portrec.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrLiveTradeDaoImpl;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.dto.CptyLiveTrades;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author Raji Komatreddy
 *  this class loads data into Reg_Rep_Pr_Live_Trades by executing storedProc
 * written in 1SDR
 */
@Component
public class RegRepPrLiveTradeLoaderSvc
{

	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;

	@Autowired
	RegRepPrLiveTradeDaoImpl regRepPrLiveTradeDaoImpl;
	

	@Value("${portrec.batch.commit.size}")
	String batchSizeStr;
	
	int batchSize = 0;

	
	Logger logger = Logger.getLogger(RegRepPrLiveTradeLoaderSvc.class);

	public void loadLiveTrades(Message<?> message) throws PortrecException
	{

		Object ipMessage = null;
		String errorString = null;
		String jobName = null;
		Date reconDate = null;
		long currJobExecutionId = 0;
		String jobAsOfDate = null;
		Date asOfDate = null;

		RegRepPrJobDetail currRegRepPrJobDetail = null;
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);
		// reconDate = reconDateFormat.format(reconDate);

		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconFreqCalculatorSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}
		ipMessage = message.getPayload();
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)) jobAsOfDate = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();

		if (null != jobAsOfDate)
		{
			logger.info(" recon process running for asOfDate received from fileName " + jobAsOfDate);
			try
			{
				asOfDate = reconDateFormat.parse(jobAsOfDate);
				if (null != asOfDate)
				{
					reconDate = asOfDate;
				}
				else
				{
					reconDate = new Date();
				}
			}
			catch (ParseException e)
			{
				logger.error("########## " + e.getMessage());
				// e.printStackTrace();
			}
		}
		else
		{
			reconDate = new Date();
		}

		if (ipMessage instanceof RegRepPrJobDetail)
		{
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail)
		{
			errorString = "Null incoming PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconFreqCalculatorSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		// tradeFile.setId(new BigDecimal(10000001));
		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(reconDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail.getJobName());
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconFreqCalculatorSvc-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		logger.info("jobExecution id for current run of CptyReconFreqCalculatorSvc " + currJobExecutionId);
		
		if (null != batchSizeStr) batchSize = Integer.parseInt(batchSizeStr);
		
		//read live trade data from 1sdr
		
		List<CptyLiveTrades> liveTradesList = new ArrayList<CptyLiveTrades>();
		    liveTradesList = regRepPrLiveTradeDaoImpl.getLiveTradesFromSdr();
		    
		    
		
		//delete existing data from RegRepPrLiveTrades table
		    if( null != liveTradesList && liveTradesList.size()> 1)
		    {
		    	regRepPrLiveTradeDaoImpl.deleteFromPrLiveTrades();
		    }
		
		//insert new data into RegRepPrLiveTrades table
		    if( null != liveTradesList && liveTradesList.size()> 1)
		    {
		    	List<CptyLiveTrades> currliveTradesList = new ArrayList<CptyLiveTrades>();
		    	for(  CptyLiveTrades currCptyLiveTrades:liveTradesList)
		    	{
		    		currliveTradesList.add(currCptyLiveTrades);
		    		if( batchSize == currliveTradesList.size())
		    		{
		    			regRepPrLiveTradeDaoImpl.batchInsertPrLiveTrades(currliveTradesList);
		    			currliveTradesList.clear();
		    		}
		    	}
		    	regRepPrLiveTradeDaoImpl.batchInsertPrLiveTrades(currliveTradesList);
		    	
		    }
	}

}
