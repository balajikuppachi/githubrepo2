package com.wellsfargo.regulatory.portrec.loader;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCommPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrIceOpenTransaction;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrIceCommDataReader extends DbLoaderHelper<RegRepPrCommPositionReport>{
	
	
	ArrayList<RegRepPrCommPositionReport> openPositionList = new ArrayList<RegRepPrCommPositionReport>();
	public static String PORTFOLIO_SEGMENT_NAME = "CommodityDataLoad, ICE";

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}
	
	
	@Override
	public RegRepPrCommPositionReport parseRecords(RegRepPrIceOpenTransaction openTransactionList,Date asofDate) throws ParseException {
		
		{	
		RegRepPrCommPositionReport commTradeUnfiltered = new RegRepPrCommPositionReport();
		//commTradeUnfiltered.setJobExecutionId(prevRegRepPrJobExecutionDetail);
		commTradeUnfiltered.setProductId(openTransactionList.getTvProductId());
		commTradeUnfiltered.setCftcProductId(openTransactionList.getTvProductId());
		commTradeUnfiltered.setIntProductId(openTransactionList.getTvProductId());
		commTradeUnfiltered.setTvProdId(openTransactionList.getTvProductId());
		commTradeUnfiltered.setMultAssetClassSwap(openTransactionList.getMultiAssetClassSwap());
		commTradeUnfiltered.setMacPriAssetClass(openTransactionList.getMacsPrimaryAssetClass());
		commTradeUnfiltered.setMacSecAssetClass(openTransactionList.getMacsSecondaryAssetClass()); //previously fields[226]
		commTradeUnfiltered.setMixedSwap(openTransactionList.getMixedSwap()); //previously fields[227]
		commTradeUnfiltered.setMixedSwapReportSdr(openTransactionList.getMixedSwapReportSdr()); //previously fields[228]
		commTradeUnfiltered.setContractType(openTransactionList.getContractType());
		commTradeUnfiltered.setExecutionVenue(openTransactionList.getExecutionVenue());
		if (StringUtils.isNotBlank(openTransactionList.getStartDate())) //previously fields[20]
			commTradeUnfiltered.setStartDate(DateUtilLoader.getDateFromStrComm(openTransactionList.getStartDate())); //previously fields[20]
		if (StringUtils.isNotBlank(openTransactionList.getEndDate())) //previously fields[21]
			commTradeUnfiltered.setEndDate(DateUtilLoader.getDateFromStrComm(openTransactionList.getEndDate())); //previously fields[21]
		commTradeUnfiltered.setBuyer(openTransactionList.getBuyer());
		commTradeUnfiltered.setSeller(openTransactionList.getSeller());
		commTradeUnfiltered.setQantityUnit(openTransactionList.getQuantityUnit()); //previously fields[30]
		commTradeUnfiltered.setQantity(openTransactionList.getQuantity()); //previously fields[27]
		commTradeUnfiltered.setQantityFreq(openTransactionList.getQuantityFrequency()); //previously fields[29]
		commTradeUnfiltered.setTotalFreq(openTransactionList.getTotalQuantity()); //previously fields[28]
		commTradeUnfiltered.setSettlementMethod(openTransactionList.getSettlementMethod()); //previously fields[59]
		commTradeUnfiltered.setPrice(openTransactionList.getPrice()); //previously fields[22]
		commTradeUnfiltered.setPriceUnit(openTransactionList.getPriceUnit()); //previously fields[23]
		commTradeUnfiltered.setPriceCurr(openTransactionList.getPriceCurrency()); //previously fields[24]
		commTradeUnfiltered.setBuyerPayIndex(openTransactionList.getBuyerPayIndex()); //previously fields[31]
		commTradeUnfiltered.setBuyerPayindexAvgMethod(openTransactionList.getBuyerPayIndexAveragingMethod()); //previously fields[32]
		commTradeUnfiltered.setSellerPayIndex(openTransactionList.getSellarPayIndex()); //previously fields[35]
		commTradeUnfiltered.setSellerPayindexAvgMethod(openTransactionList.getSellerPayIndexAveragingMethod()); //previously fields[36]
		commTradeUnfiltered.setGrade(openTransactionList.getGrade()); //previously fields[206]
		commTradeUnfiltered.setOptionType(openTransactionList.getOptionType()); //previously fields[43]
		commTradeUnfiltered.setOptionStyle(openTransactionList.getOptionStyle()); //previously fields[44]
		commTradeUnfiltered.setOptionPremium(openTransactionList.getOptionPremium()); //previously fields[45]
		commTradeUnfiltered.setHrFromThr(openTransactionList.getHoursFromThru()); //previously fields[39]
		commTradeUnfiltered.setHrFromThrTimezone(openTransactionList.getHoursFromThruTimezone()); //previously fields[40]
		commTradeUnfiltered.setDaysOfWeek(openTransactionList.getDaysOfWeek()); //previously fields[42]
		commTradeUnfiltered.setLoadType(openTransactionList.getLoadType()); //previously fields[41]
		commTradeUnfiltered.setCollaterlized(openTransactionList.getCollaterlized()); //previously fields[149]
		
		commTradeUnfiltered.setUsiValue(openTransactionList.getUsiUti());
		String wfbna = "Wells Fargo Bank, N.A.";
		
		if(StringUtils.equalsIgnoreCase(openTransactionList.getBuyer(),wfbna)){
			commTradeUnfiltered.setSrcTradeId(openTransactionList.getBuyerSenderTradeRefId()); //previously fields[93]
		}else if(StringUtils.equalsIgnoreCase(openTransactionList.getSeller(),wfbna)){
			commTradeUnfiltered.setSrcTradeId(openTransactionList.getSellerSenderTradeRefId()); //previously fields[102]
		}else{
			commTradeUnfiltered.setSrcTradeId("");
		}
		String buyerLEI = openTransactionList.getBuyerLei();
		String sellerLEI = openTransactionList.getSellerLei();
		if (null != buyerLEI && buyerLEI.contains("OL:C:")) buyerLEI = buyerLEI.replace("OL:C:", "");
		if (null != buyerLEI && buyerLEI.contains("UK:C:")) buyerLEI = buyerLEI.replace("UK:C:", "");
		if (null != sellerLEI && sellerLEI.contains("OL:C:")) sellerLEI = sellerLEI.replace("OL:C:", "");
		if (null != sellerLEI && sellerLEI.contains("UK:C:")) sellerLEI = sellerLEI.replace("UK:C:", "");

		//commTradeUnfiltered.setBuyerLei(fields[87]); //previously fields[85]
		//commTradeUnfiltered.setSellerLei(fields[96]); //previously fields[94]
		commTradeUnfiltered.setBuyerLei(openTransactionList.getBuyerLei()); //previously fields[85]
		commTradeUnfiltered.setSellerLei(sellerLEI); //previously fields[94]
		commTradeUnfiltered.setBuyerUsRegDesg(openTransactionList.getBuyerUsregulatoryDesignation()); //previously fields[86]
		commTradeUnfiltered.setSellerUsRegDesg(openTransactionList.getSellerUsregulatoryDesignation()); //previously fields[95]
		commTradeUnfiltered.setBuyerUsEnt(openTransactionList.getBuyerUsEnt()); //previously fields[91]
		commTradeUnfiltered.setSellerUsEnt(openTransactionList.getSellerUsEnt()); //previously fields[100]
		commTradeUnfiltered.setBuyerFinEnt(openTransactionList.getBuyerFinEnt()); //previously fields[89]
		commTradeUnfiltered.setSellerFinEnt(openTransactionList.getSellerFinEnt()); //previously fields[98]
		
		if(StringUtils.equalsIgnoreCase(openTransactionList.getBuyer(),openTransactionList.getUsReportingEntityPetData())){ //previously fields[80]
			commTradeUnfiltered.setReportPrtyLei(commTradeUnfiltered.getBuyerLei());
			commTradeUnfiltered.setNonReportLei(commTradeUnfiltered.getSellerLei());
			commTradeUnfiltered.setTradeParty1Name(openTransactionList.getBuyerLei()); //previously fields[85]
			commTradeUnfiltered.setTradeParty2Name(openTransactionList.getSellerLei()); //previously fields[94]
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setReportSd("Y");
				commTradeUnfiltered.setReportMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("Y");
			}else{
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("N");
			}
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("Y");
				commTradeUnfiltered.setNonRepMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("Y");
			}else{
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("N");
			}
			
			commTradeUnfiltered.setReportFin(commTradeUnfiltered.getBuyerFinEnt());
			commTradeUnfiltered.setReportUs(commTradeUnfiltered.getBuyerUsEnt());
			commTradeUnfiltered.setNonReportId(commTradeUnfiltered.getSellerLei());
			commTradeUnfiltered.setNonRepFin(commTradeUnfiltered.getSellerFinEnt());
			commTradeUnfiltered.setNonRepUs(commTradeUnfiltered.getSellerUsEnt());
	//	}else if((StringUtils.equalsIgnoreCase(fields[15],fields[81]))){
		} else {
			commTradeUnfiltered.setReportPrtyLei(commTradeUnfiltered.getSellerLei());
			commTradeUnfiltered.setTradeParty1Name(openTransactionList.getSellerLei()); //previously fields[94]
			commTradeUnfiltered.setTradeParty2Name(openTransactionList.getBuyerLei()); //previously fields[85]
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setReportSd("Y");
				commTradeUnfiltered.setReportMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("Y");
			}else{
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("N");
			}
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("Y");
				commTradeUnfiltered.setNonRepMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("Y");
			}else{
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("N");
			}
			
			/*commTrade.setReportSd(commTrade.getSellerUsLeiDesg());
			commTrade.setReportMsp(commTrade.getSellerUsLeiDesg());*/
			commTradeUnfiltered.setReportFin(commTradeUnfiltered.getSellerFinEnt());
			commTradeUnfiltered.setReportUs(commTradeUnfiltered.getSellerUsEnt());
			commTradeUnfiltered.setNonReportLei(commTradeUnfiltered.getBuyerLei());
			commTradeUnfiltered.setNonReportId(commTradeUnfiltered.getBuyerLei());
			/*commTrade.setNonReptSd(commTrade.getBuyerUsLeiDesg());
			commTrade.setNonRepMsp(commTrade.getBuyerUsLeiDesg());
			*/commTradeUnfiltered.setNonRepFin(commTradeUnfiltered.getBuyerFinEnt());
			commTradeUnfiltered.setNonRepUs(commTradeUnfiltered.getBuyerUsEnt());
			}
		commTradeUnfiltered.setAsOfDate(asofDate);
		
		return commTradeUnfiltered;
		}
	}

	@Override
	public boolean validate(RegRepPrCommPositionReport trade) {
		boolean canLoad = true;
		return canLoad;
	}

	@Override
	public RegRepPrCommPositionReport getTableName() {
		return new RegRepPrCommPositionReport();
	}

	@Override
	public boolean deletePrevDayRecords() {
		// TODO Auto-generated method stub
		return false;
	}

}
