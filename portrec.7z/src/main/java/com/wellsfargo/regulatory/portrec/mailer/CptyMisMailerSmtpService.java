package com.wellsfargo.regulatory.portrec.mailer;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
@ManagedResource(description="Smtp Service")
public class CptyMisMailerSmtpService {
	
	@Value("${file.mis.outputFolder}") String misFilePath;
	@Value("${mis.mail.to.portrec}")		String toEmailAddresses;
	@Value("${mis.mail.cc.portrec}")		String ccAddresses;
	@Value("${mis.mail.from.portrec}")		String fromAddresses;
	@Value("${mail.env.portrec}")
	String enviroment;
	
	@Autowired
	PrSmtpConfig prSmtpConfig;
	private final Logger logger = Logger.getLogger(CptyMisMailerSmtpService.class);
	
	@ManagedOperation(description="Smtp process")
	public void invokeService(String date,String reconFreq,String reportType) throws ParseException{
		logger.info("invoking smtp service");
		sendEmail(date,reconFreq,reportType);
	}
	
public void sendEmail(String date,String reconFreq,String reportType) throws ParseException {
		

	String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
	SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);
	Date asOfDate = reconDateFormat.parse(date);
	String asOFDateString=PortRecUtil.convertDateToString_Mmddyyyy(asOfDate);
	logger.info("Started Mis Mail Process - ");
	Map<String, String> attachmentDetails = new HashMap<String, String>();
	boolean attachFilePresentFlag = false;
	String[] toArr = null;
	String[] toCCArr = null;
	String messageBody="Please find the attached mis report.";
	String subject=null;
	String testSubject = null;
	
	if(null !=reconFreq && reconFreq.length()>1){
	
	subject =reconFreq.substring(0,1)+reconFreq.substring(1).toLowerCase()+" Portfolio Reconciliation "+date+"-"+reportType+" report";
		
		if(!enviroment.equals("PROD"))	{
			subject = "DEVELOPMENT AND TESTING - " + subject;
		}
		
		reconFreq=reconFreq.toLowerCase();
	}
		if (reportType.equals("Pre Run")) {
			attachmentDetails.putAll(getMisPreFileDetails(asOFDateString,
					reconFreq));
		}
		if (reportType.equals("Control Summary")) {
			attachmentDetails.putAll(getMisControlFileDetails(asOFDateString,
					reconFreq));
		}
		if (reportType.equals("Post Run")) {
			attachmentDetails.putAll(getMisPostFileDetails(asOFDateString,
					reconFreq));
		}
		logger.info("File Attached ");

		if (toEmailAddresses.contains(","))
			toArr = toEmailAddresses.split(",");
		if (ccAddresses.contains(","))
			toCCArr = ccAddresses.split(",");
		MimeMessage message = prSmtpConfig.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			String body = messageBody;
			if (null != subject) {
				helper.setSubject(subject);
			}
			helper.setText(body, true);
			if (null != fromAddresses && !StringUtils.isBlank(fromAddresses)) {
				helper.setFrom(fromAddresses);
			}
			if (null!=toArr)
				helper.setTo(toArr);
			else if (null!=toEmailAddresses && !StringUtils.isBlank(toEmailAddresses))
				helper.setTo(toEmailAddresses);
			if (null !=toCCArr)
				helper.setCc(toCCArr);
			else if(null!=ccAddresses && !StringUtils.isBlank(ccAddresses))
				helper.setCc(ccAddresses);
			if (null != attachmentDetails)
				for (String fileName : attachmentDetails.keySet()) {
					if (!StringUtils.isBlank(fileName)) {
						logger.info("attaching the files in mail");
						String filePath = attachmentDetails.get(fileName);
						File fileToBeAttached = new File(filePath, fileName);
						FileSystemResource file = new FileSystemResource(fileToBeAttached);
						if (file.exists()) {
							attachFilePresentFlag = true;
							helper.addAttachment(fileName, new ByteArrayResource(IOUtils.toByteArray(file.getInputStream())));
						}
					}
				}
		if(attachFilePresentFlag){
			logger.info("sending the mail");
			prSmtpConfig.send(message);
			logger.info(reportType+" "+reconFreq+" Mail Sent");
		}
		else
		{
			logger.info("No attachment is available for mail");
		}

		} catch (Exception me) {
			logger.info("Error in Sending Mail" + me);
		}

	}
	
	public Map<String, String> getMisFileDetails(String asOfDate,String reconFrequency){
		Map<String, String> fileDetails = new HashMap<String, String>();
		String fileName = "";
		String reconFreq=reconFrequency.toLowerCase();
		String appender=PortrecConstants.UNDERSCORE+reconFreq+PortrecConstants.UNDERSCORE+asOfDate+".xls";
		logger.info("Attaching the mis files");
		
			fileName = "PrPreRun"+appender;
			if(checkIfFileExists(fileName, misFilePath))
				fileDetails.put(fileName, misFilePath);
			
			fileName = "PrControlSummary"+appender;
			if(checkIfFileExists(fileName, misFilePath))
				fileDetails.put(fileName, misFilePath);
			
			fileName = "PrPostRun"+appender;
			if(checkIfFileExists(fileName, misFilePath))
				fileDetails.put(fileName, misFilePath);	
				
		return fileDetails;
	}
	
	public Map<String, String> getMisPreFileDetails(String asOfDate,String reconFrequency){
		Map<String, String> fileDetails = new HashMap<String, String>();
		String fileName = "";
		
		String appender=PortrecConstants.UNDERSCORE+reconFrequency+PortrecConstants.UNDERSCORE+asOfDate+".xls";
		logger.info("Attaching the mis pre files");
		
			fileName = "PrPreRun"+appender;
			if(checkIfFileExists(fileName, misFilePath))
				fileDetails.put(fileName, misFilePath);
				
		return fileDetails;
	}
	
	public Map<String, String> getMisPostFileDetails(String asOfDate,String reconFrequency){
		Map<String, String> fileDetails = new HashMap<String, String>();
		String fileName = "";
		
		String appender=PortrecConstants.UNDERSCORE+reconFrequency+PortrecConstants.UNDERSCORE+asOfDate+".xls";
		logger.info("Attaching the mis post files");
		
		fileName = "PrPostRun"+appender;
		if(checkIfFileExists(fileName, misFilePath))
			fileDetails.put(fileName, misFilePath);	
				
		return fileDetails;
	}
	
	public Map<String, String> getMisControlFileDetails(String asOfDate,String reconFrequency){
		Map<String, String> fileDetails = new HashMap<String, String>();
		String fileName = "";
		
		String appender=PortrecConstants.UNDERSCORE+reconFrequency+PortrecConstants.UNDERSCORE+asOfDate+".xls";
		logger.info("Attaching the mis control files");
		fileName = "PrControlSummary"+appender;
		if(checkIfFileExists(fileName, misFilePath))
			fileDetails.put(fileName, misFilePath);
				
		return fileDetails;
	}
	
	public boolean checkIfFileExists(String fileName, String filePath) {
		File fileToBeAttached = new File(filePath, fileName);
		return fileToBeAttached.exists();
	}
	
}
