package com.wellsfargo.regulatory.portrec.repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;

/**
 * 
 * @author Raji Komatreddy
 *Repository to save or get data from RegRepPrJobExecutionDetail table
 */
public interface RegRepPrJobExecutionDetailRepository extends CrudRepository<RegRepPrJobExecutionDetail, Long>
{

	@Query(value = "Select top 1*  from REG_REP_PR_JOB_EXECUTION_DETAILS where file_name = ?1 and job_status = ?2 order by create_datetime desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findPreviousJobExecutionDetail(String fileName, String status);
	
	@Query(value = "Select max(je.job_execution_id) from REG_REP_PR_JOB_EXECUTION_DETAILS je, REG_REP_PR_JOB_DETAILS jd where je.job_details_id = jd.job_details_id and jd.job_name = ?1 and je.as_of_date =  ?2 ", nativeQuery = true)
	BigDecimal findPreviousExecutionDetail(String portfolioSeg, Date asofDate);
	
	@Query(value = "Select max(je.job_execution_id) from REG_REP_PR_JOB_EXECUTION_DETAILS je, REG_REP_PR_JOB_DETAILS jd where je.job_details_id = jd.job_details_id and jd.job_name = ?1 and je.create_datetime <=  ?2 ", nativeQuery = true)
	BigDecimal findPreviousWeekExecutionDetail(String portfolioSeg, Date asofDate);
	
	@Query(value = "Select max(je.job_execution_id) from REG_REP_PR_JOB_EXECUTION_DETAILS je, REG_REP_PR_JOB_DETAILS jd where je.job_details_id = jd.job_details_id and jd.job_name = ?1 and je.create_datetime < ?2 ", nativeQuery = true)
	BigDecimal findPreviousRunExecutionDetail(String portfolioSegmentName, Date asofDate);
	
	@Query(value = "Select je.job_status, jd.job_desc, jd.job_freq from REG_REP_PR_JOB_EXECUTION_DETAILS je, REG_REP_PR_JOB_DETAILS jd where je.job_details_id = jd.job_details_id and je.as_of_date = ?1", nativeQuery = true)
	List<Object[]> findCurrDateJobExecutionDetail(Date currentDate);
	
	@Query(value="select jd.as_of_date from REG_REP_PR_JOB_EXECUTION_DETAILS jd "+ 
   " where jd.file_name = 'CptyReconFreqCalculatorSvc'  " +
    " and job_status = 'success' and jd.job_execution_id in  "+ 
    " (select max(jd.job_execution_id) from REG_REP_PR_JOB_EXECUTION_DETAILS jd " +
    " where jd.file_name = 'CptyReconFreqCalculatorSvc'  " +
   " and job_status = 'success')", nativeQuery = true)
	Date findLastSuccessFulReconFreqRun();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Interest Rate, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findInterestRateJobExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Credit, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findCreditJobExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Commodity, ICE')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findCommodityJobExecutionIdIce();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Commodity, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findCommodityJobExecutionIdDtcc();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'ForeignExchange, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findFxJobExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_VS, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquityVSExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_CFD, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquityCFDExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_ES, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquityESExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_SP, DTCC')"
			+ "and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquitySPExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_DS, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquityDSExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_OPT, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquityOPTExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_FWD, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquityFWDExecutionId();
	
	@Query(value = "select top 1* from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_name = 'Equity_PO, DTCC')"
			+ " and job_status='success' order by job_execution_id desc", nativeQuery = true)
	RegRepPrJobExecutionDetail findEquityPOExecutionId();
	
	@Query(value = "select * from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id in (select job_details_id from REG_REP_PR_JOB_DETAILS where job_type like 'FileLoading')"
			+ " and as_of_date = ?  group by job_details_id having create_datetime = max(create_datetime) and job_status='success'" , nativeQuery = true)
	List<RegRepPrJobExecutionDetail> findJobDetailsForAllFileLoads(Date asOfdate);
		
}
