package com.wellsfargo.regulatory.portrec.recon;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.dao.RegRepPrLiveTradeDaoImpl;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrIrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;
import com.wellsfargo.regulatory.portrec.dto.CptyLiveTrades;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCrPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrIrPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
public class RegRepPrIRRecon {

	@Autowired
	RegRepPrIrPositionReportRepository repPrIrPositionReportRepository;
	
	@Autowired
	RegRepPrCrPositionReportRepository repPrCrPositionReportRepository;
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	@Autowired
	RegRepPrReconHelper regRepPrReconHelper;
	
	@Value("${portrec.recon.file.Location}")
	String portrecReconFileLoc;
		
	private static Logger logger = Logger.getLogger(RegRepPrIRRecon.class);
	
	public void doIRRecon(RegRepPrJobExecutionDetail jobDetail, Date asOfdate) {
		int irLiveTradeCount = 0;
		int dtccPosCount =0;
		int dtccNotMatchingPos = 0;
		
		logger.info("Starting IR Recon ");
		List<RegRepPrLiveTrade> liveTrades = 	regRepPrLiveTradeRepository.findTradesBasedonAssetClass(PortrecConstants.ASSETCLASS_IR);
		
		irLiveTradeCount = liveTrades.size();
		Map<String,RegRepPrIrPositionReport> dtccUSIMap = new HashMap<String, RegRepPrIrPositionReport>();
		Map<String, RegRepPrLiveTrade> regrepUSIMap = new HashMap<String, RegRepPrLiveTrade>();
				
		logger.info("Size of LiveTrades for IR Trades : "	+	irLiveTradeCount);
		
		List<RegRepPrIrPositionReport> dtccUSIList = null;
		
		if(null != jobDetail.getAsOfDate())
		{
			long startTime = System.currentTimeMillis();
			dtccUSIList =  repPrIrPositionReportRepository.findPositionsByDate(jobDetail);
			long endTime = System.currentTimeMillis();
			logger.info("Total Time Taken to get IR Position Counts : " + (endTime - startTime));
		}
		if(null != dtccUSIList) 
		{
			dtccPosCount = dtccUSIList.size();
			logger.info("Size of IR Positions : "	+	dtccPosCount);
				for(RegRepPrIrPositionReport dtccUSI : dtccUSIList)
				{
					String usi = dtccUSI.getUsi();
					String submittedFor = dtccUSI.getSubmittedFor();
					String tradeParty1 = dtccUSI.getTradeParty1();
					String tradeParty2 = dtccUSI.getTradeParty2();
			
						if(null != usi && !submittedFor.contains("F226TOH6YD6XJB17KS62") 
								&& !tradeParty2.contains("F226TOH6YD6XJB17KS62") && !tradeParty1.contains("F226TOH6YD6XJB17KS62")) 
						{
							dtccUSIMap.put(usi, dtccUSI);
						}
				}	
		
				
				for(RegRepPrLiveTrade liveTrade : liveTrades){
					String usi = liveTrade.getUsi();
					usi = usi.replaceAll(":", "");
					String reconCpty = liveTrade.getReconCpty();
					if(dtccUSIMap.containsKey(usi)){
						/*removeLiveTradesList.add(liveTrade);*/
						dtccUSIMap.remove(usi);
					} else if(!reconCpty.contains("F226TOH6YD6XJB17KS62")){
						regrepUSIMap.put(liveTrade.getUsi(), liveTrade);
					}
				}
				
				dtccNotMatchingPos = dtccUSIMap.size();
				irLiveTradeCount = regrepUSIMap.size();
				logger.info("Size of IR Positions Not matching : "	+	dtccNotMatchingPos + " And Live Trades : " + irLiveTradeCount);
				
				if(irLiveTradeCount>0){
					regRepPrReconHelper.generateliveTradeFile(PortrecConstants.ASSETCLASS_IR, regrepUSIMap, asOfdate);
				}
				if(dtccNotMatchingPos>0){
					generateIRDtccPosFile(PortrecConstants.ASSETCLASS_IR,dtccUSIMap, asOfdate);
				}
				
			}
	}

	private void generateIRDtccPosFile(String assetClass, Map<String, RegRepPrIrPositionReport> dtccUSIMap, Date asOfdate) {
		
		DateFormat formatter ; 
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reconFileName = "DTCC_Recon_"+assetClass+"_"+ formatter.format(asOfdate) +".xls";
		
		List<String> liveTrades1 = regRepPrLiveTradeRepository.findTradesonAssetClassandQN(assetClass);
		Map<String, String> usiLiveMapN = new HashMap<String, String>();
		
		for(String liveTrade : liveTrades1){
			usiLiveMapN.put(liveTrade, assetClass);
		}
		
		logger.info("Size of Trades with N qualifier : " + usiLiveMapN.size());
		
		File dtccFolder = new File(portrecReconFileLoc+File.separator+ asOfdate);
	   	 File irFile;
	   	 if (dtccFolder.isDirectory()) {
		   	 	 irFile = new File(dtccFolder +File.separator+reconFileName);
		 }
	   	 else {
	   		dtccFolder.mkdirs();
	   		irFile = new File(dtccFolder +File.separator+reconFileName);
	   	 }
	   	FileWriter fw = null;
		try {
			fw = new FileWriter(irFile);
			fw.append("USI").append("\t").append("DataSubmitter").append("\t").append("SubmittedFor").append("\t").append("OrigTradeID").
			append("\t").append("TradeParty1").append("\t").append("TradeParty2").append("\t").append("Comment").append('\n');
			for (Map.Entry<String, RegRepPrIrPositionReport> entry : dtccUSIMap.entrySet()) {
				String usi = entry.getKey();
				String comment = "";
				
				if(usiLiveMapN.containsKey(usi))
				{
					comment = "Trade Qualifier is Set as N in Live Trade Table";
				}
					fw.append(usi).append("\t")
					.append(entry.getValue().getDataSubmitter()).append("\t")
					.append(entry.getValue().getSubmittedFor()).append("\t")
					.append(entry.getValue().getOrigTradeId()).append("\t")
					.append(entry.getValue().getTradeParty1()).append("\t")
					.append(entry.getValue().getTradeParty2()).append("\t")
					.append(comment)
					.append('\n');;
			}
			fw.close();
			logger.info("Recon report has been generated: " +  irFile.getAbsolutePath());
		} catch (Exception ex){
			logger.error("Error Creating DTCC IR Recon report");
		}
	
		
	}
	
}
