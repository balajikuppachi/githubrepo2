package com.wellsfargo.regulatory.portrec.utils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.time.DurationFormatUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PortRecUtil 
{
	private static Logger logger = Logger.getLogger(PortRecUtil.class);
	
	@Value ( "${portrec.config.env}")
	private String utilString;
	
	
	public void getUtilString()
	{
		logger.info("---------------------------------------- > UTIL String Called " + utilString);
	}
	
	public static String convertDateToString_MMddyyyy(Date askDate){
		
		String convertedDate = null;
		if(null != askDate){
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			convertedDate = dateFormat.format(askDate);
		}

		return convertedDate;
	}
	
	public static String getExecTimestampAsString(Date date){		
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return dateFormat.format(date);
	}
	
	public static String convertDateToString_yyyyMdd(Date date){
		
		String convertedDate = null;
		if(null != date){
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			convertedDate = dateFormat.format(date);
		}

		return convertedDate;
		
		
	}

	public static String convertDateToString_Mmddyyyy(Date date) {

		String convertedDate = null;
		if (null != date) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
			convertedDate = dateFormat.format(date);
		}

		return convertedDate;

	}

	public static String convertDateToString_Mmddyy(Date date) {

		String convertedDate = null;
		if (null != date) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
			convertedDate = dateFormat.format(date);
		}

		return convertedDate;
	}
	
	public static String convertDateToString_yyyy_MM_dd(Date date){
		
		String convertedDate = null;
		if(null != date){
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			convertedDate = dateFormat.format(date);
		}

		return convertedDate;
	}
	
	public static Timestamp convertDateToTimeStamp(Date askDate){
		
		Timestamp askDatetimestamp = null;
		if(null != askDate){
			Calendar cal = Calendar.getInstance();
			cal.setTime(askDate);
			cal.set(Calendar.MILLISECOND, 0);
			askDatetimestamp = new java.sql.Timestamp(askDate.getTime());
		}
		return askDatetimestamp;
		
	}
	
	public static String safeDateFormat(DateFormat format, Date value) {
		if (value == null)
			return "";
		
		try {
			return format.format(value);
		} catch (Exception e) {
			throw new RuntimeException("Couldn't format " + value + " as date");
		}
	}
	
	public static String safeNumberFormat(NumberFormat format, Number value) {
		if (value == null)
			return "";
		
		try {
			return format.format(value);
		} catch (Exception e) {
			throw new RuntimeException("Couldn't format " + value + " as number");
		}
	}
	
	public static String safeStringFormatAsNumberforPV(NumberFormat format, String value) {
		if (value == null)
			return "";
		
		BigDecimal decimal = null;
		try {
			decimal = new BigDecimal(value);
			//multiply with -1 to flip signs
			decimal = decimal.multiply(new BigDecimal(-1));
		} catch (NumberFormatException nfe) {
			throw new RuntimeException("Couldn't format " + value + " as number");
		}
		
		return format.format(decimal);
	}
	
	public static String printTimeTaken(long totalTimeInMillis){
		
		String timeTaken = String.format("%02d hr, %02d min, %02d sec, %02d millisec", TimeUnit.MILLISECONDS.toHours(totalTimeInMillis),
			    TimeUnit.MILLISECONDS.toMinutes(totalTimeInMillis) % TimeUnit.HOURS.toMinutes(1),
			    TimeUnit.MILLISECONDS.toSeconds(totalTimeInMillis) % TimeUnit.MINUTES.toSeconds(1),
			    TimeUnit.MILLISECONDS.toMillis(totalTimeInMillis) % TimeUnit.SECONDS.toMillis(1));
		
		//String timeTaken = DurationFormatUtils.formatDuration(totalTimeInMillis, "HH:mm:ss:SSS");
		
		return timeTaken;
		
	}
	
	public static Date convertStringToDate_yyyy_MM_dd(String strDate) throws ParseException {
		
		Date convertedDate = null;
		if(null != strDate){
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			convertedDate = dateFormat.parse(strDate);
		}

		return convertedDate;
	}
	
	public static String getEmailDispatchDate(Date date){
		
		String subjectDate = null;

		if(null != date){
			SimpleDateFormat sdfOutput = new SimpleDateFormat("MMMM d, yyyy");
			subjectDate =  sdfOutput.format(date);
		}
		return subjectDate;
	}
	
	public static String getEmailSubjectPrintDate(Date date){
		
		String subjectDate = null;

		if(null != date){
			SimpleDateFormat sdfOutput = new SimpleDateFormat("MM/dd/yyyy");
			subjectDate =  sdfOutput.format(date);
		}
		return subjectDate;
	}
	
	public static String getQuarterlyPortfolioSize(Date date){
		
		Calendar calInstance = Calendar.getInstance();
		calInstance.setTime(date);
		int month = calInstance.get(Calendar.MONTH);
		int year=calInstance.get(Calendar.YEAR);
		String portfolioSize = null;
		//____ quarter, 20__
		
		if(month==0 || month==1 || month ==2)
		{
			portfolioSize="1st quarter"+PortrecConstants.COMMA+PortrecConstants.SPACE+String.valueOf(year);
		}
		else if(month==3 || month==4 || month ==5)
		{
			portfolioSize="2nd quarter"+PortrecConstants.COMMA+PortrecConstants.SPACE+String.valueOf(year);
		}
		else if(month==6 || month==7 || month ==8)
		{
			portfolioSize="3rd quarter"+PortrecConstants.COMMA+PortrecConstants.SPACE+String.valueOf(year);
		}
		else 
		{
			portfolioSize="4th quarter"+PortrecConstants.COMMA+PortrecConstants.SPACE+String.valueOf(year);
		}
			return portfolioSize;
	}
	
	public static String obfuscate(final String string) 
    {
        if (string.length() > 2) 
        {
            char[] charArray = string.toCharArray();
            
            for (int i = 0; i < charArray.length; i++) 
            {
                if (i > 0 && i < charArray.length - 1) 
                {
                    charArray[i] = '*';
                }
            }
            
            return new String(charArray);
        }
        
        return "**";
    }
    
	public static void main(String[] arg) throws ParseException {
		
		//System.out.println(printTimeTaken(12345678));
		System.out.println(getQuarterlyPortfolioSize(convertStringToDate_yyyy_MM_dd("2015-07-26")));
	}

}
