package com.wellsfargo.regulatory.portrec.reports;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;

@Component
public class JobExecutionDetailsTableWatch {
	
	private static Logger logger = Logger.getLogger(JobExecutionDetailsTableWatch.class);
	
	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;
	
	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;
	
	@Autowired
	RegRepPrJobDetailRepository regRepPrJobDetailRepository;
	
	@Autowired
	JavaEmailExtension mailsender;
	
	@Value("${mail.from.qualifyrep}") String mailFromqualifyrep;
	@Value("${mail.to.qualifyrep}") String mailToqualifyrep;
	@Value("${mail.cc.qualifyrep}") String mailCCqualifyrep;
	
	RegRepPrJobDetail regRepPrJobDetail;

	public void checkJobStatus(){
		
		logger.info("Starting JOB status monitoring");
		
		HashMap<String, List<String>> jobDetailsHash = new HashMap<String, List<String>>();		
		List<String> jobDetailsSucessList = new ArrayList<String>();
		List<String> jobDetailsProcessList = new ArrayList<String>();
		List<String> jobDetailsErrorList = new ArrayList<String>();
		List<String> jobDetailsRemaining = new ArrayList<String>();
		List<RegRepPrReconCalendar> reconCalList = null;
		
		try {
			List<Object[]> jobDetails = regRepPrJobExecutionDetailRepository.findCurrDateJobExecutionDetail(new Date());
			
			if(!jobDetails.isEmpty()){
						
			for (Object[] e : jobDetails){
				
				String jobStatus = (String) e[0];
				String jobDesc = (String) e[1];
				String jobFreq = (String) e[2];
										
				if(jobStatus.equalsIgnoreCase("success") && jobFreq.equalsIgnoreCase("DAILY")){
					String outPut =  jobDesc;
					jobDetailsSucessList.add(outPut);		
					jobDetailsRemaining.add(jobDesc);
					jobDetailsHash.put("SUCCESS", jobDetailsSucessList);
				}
			
				if(jobStatus.equalsIgnoreCase("processing") && jobFreq.equalsIgnoreCase("DAILY")){
					String outPut = jobDesc;
					jobDetailsProcessList.add(outPut);		
					jobDetailsRemaining.add(jobDesc);
					jobDetailsHash.put("PROCESSING", jobDetailsProcessList);
				}
			
				if(jobStatus.equalsIgnoreCase("error") && jobFreq.equalsIgnoreCase("DAILY")){
					String outPut = jobDesc;
					jobDetailsErrorList.add(outPut);		
					jobDetailsRemaining.add(jobDesc);
					jobDetailsHash.put("ERROR", jobDetailsErrorList);
				}
				
			}
		}
		}
		catch (Exception e){
			logger.error("Error getting Job Execution Details : " + e.getMessage());
		}
		
		try {
			Date reconDate = new SimpleDateFormat("yyyy-MM-dd").parse(PortRecUtil.convertDateToString_yyyy_MM_dd(new Date()));
			reconCalList = regRepPrReconCalendarRepository.findByDate(reconDate);	
			
			if (!reconCalList.isEmpty()){
				List<Object[]> jobDetails = regRepPrJobExecutionDetailRepository.findCurrDateJobExecutionDetail(new Date());
				
				if(!jobDetails.isEmpty()){
							
				for (Object[] e : jobDetails){
					String jobStatus = (String) e[0];
					String jobDesc = (String) e[1];
					String jobFreq = (String) e[2];
																						
					if(jobStatus.equalsIgnoreCase("success") && jobFreq.equalsIgnoreCase("RECON")){
						String outPut = "Job Completed Successfully for " + jobDesc;
						jobDetailsSucessList.add(outPut);		
						jobDetailsRemaining.add(jobDesc);
						jobDetailsHash.put("SUCCESS", jobDetailsSucessList);
					}
				
					if(jobStatus.equalsIgnoreCase("processing") && jobFreq.equalsIgnoreCase("RECON")){
						String outPut = "Job Still Processing for " + jobDesc;
						jobDetailsProcessList.add(outPut);		
						jobDetailsRemaining.add(jobDesc);
						jobDetailsHash.put("PROCESSING", jobDetailsProcessList);
					}
					
					if(jobStatus.equalsIgnoreCase("error") && jobFreq.equalsIgnoreCase("RECON")){
						String outPut = "Job in ERROR status for " + jobDesc;
						jobDetailsErrorList.add(outPut);		
						jobDetailsRemaining.add(jobDesc);
						jobDetailsHash.put("ERROR", jobDetailsErrorList);
					}
				
				}
				}
			}
		}
		catch (Exception e){
			logger.error("Error getting Job Execution Details for the Current Date : " + e.getStackTrace());
		}
		
		StringBuilder messageBuilder = new StringBuilder();
		String messageBody = null;
		
			List<String> listOfMessages = jobDetailsHash.get("ERROR");
			if(!listOfMessages.isEmpty()){
				messageBuilder.append("***************************************").append("<br />");
				messageBuilder.append("List of Jobs in ERROR STATUS ").append("<br />");
				messageBuilder.append("***************************************").append("<br />");
			for (String message: listOfMessages ){
					messageBuilder.append(message).append("<br />");
				}
			messageBuilder.append("<br />");
			}
			List<String> listOfProcessingMessages = jobDetailsHash.get("PROCESSING");
			if(!listOfProcessingMessages.isEmpty()){
				messageBuilder.append("***************************************").append("<br />");
				messageBuilder.append("List of Jobs in PROCESSING STATUS ").append("<br />");
				messageBuilder.append("***************************************").append("<br />");
			for (String message: listOfProcessingMessages ){
					messageBuilder.append(message).append("<br />");
				}
			messageBuilder.append("<br />");
			}
			List<String> listOfSuccessMessages = jobDetailsHash.get("SUCCESS");
			if(!listOfSuccessMessages.isEmpty()){
				messageBuilder.append("***************************************").append("<br />");
				messageBuilder.append("List of Jobs in SUCCESS STATUS ").append("<br />");
				messageBuilder.append("***************************************").append("<br />");
			for (String message: listOfSuccessMessages ){
					messageBuilder.append(message).append("<br />");
				}
			messageBuilder.append("<br />");
			}
			
			List<RegRepPrJobDetail> jobDetailer = regRepPrJobDetailRepository.findOtherjobID(jobDetailsRemaining);
			if(jobDetailer.isEmpty()){
				messageBuilder.append("<br />");
				messageBuilder.append("ALL reports have been executed for Today");
			} else {
				if (!reconCalList.isEmpty()){
					messageBuilder.append("***************************************").append("<br />");
					messageBuilder.append("List of Jobs still need to be Executed").append("<br />");	
					messageBuilder.append("***************************************");
					for(RegRepPrJobDetail jd : jobDetailer){
						messageBuilder.append("<br />");
						messageBuilder.append(jd.getJobName() + " ---> " + jd.getJobDesc());
						
					}
				} else {
					for(RegRepPrJobDetail jd : jobDetailer){
						messageBuilder.append("***************************************").append("<br />");
						messageBuilder.append("List of Jobs still need to be Executed").append("<br />");	
						messageBuilder.append("***************************************");
						if(jd.getJobFreq().equalsIgnoreCase("DAILY")){
							messageBuilder.append("<br />");
							messageBuilder.append(jd.getJobName() + " ---> " + jd.getJobDesc());
						}
					}
				}
			}				
			messageBody=messageBuilder.toString();
			
	try {
		sendEmail(mailToqualifyrep, mailCCqualifyrep, mailFromqualifyrep, messageBody);
		}
		catch (Exception ex){
			logger.error("Error Sending Email " + ex.getStackTrace());
		}
	}

	public void sendEmail(String to, String cc, String from, String messageBody) {
		
		
		Date sentDate = null;
		try {
			sentDate = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(PortRecUtil.getExecTimestampAsString(new Date()));
		} catch (Exception e) {
			logger.error("Exception while parsing the date " + e.getStackTrace());
		}
		
		if(messageBody==null){
			messageBody="No JOBS Have been Executed for " + sentDate;
		}
		
		
		logger.info("Sending mail for Job monitoring status Report " + sentDate);

		String subject = "***JOB MONITORING STATUS " + sentDate;
		String[] toArr = null;
		String[] toCCArr = null;

		if (to.contains(","))
			toArr = to.split(",");
		if (cc.contains(","))
			toCCArr = cc.split(",");
		MimeMessage message = mailsender.createMimeMessage();

		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			String body = messageBody;
			helper.setSubject(subject);
			helper.setText(body, true);
			helper.setFrom(from);
			if (toArr != null)
				helper.setTo(toArr);
			else
				helper.setTo(to);
			if (toCCArr != null)
				helper.setCc(toCCArr);
			else
				helper.setCc(cc);
		
			mailsender.send(message);
			logger.info("Mail Sent :" + subject);

		} catch (Exception me) {
			logger.info("Error in Sending Mail" + me);
		}

	}
}
