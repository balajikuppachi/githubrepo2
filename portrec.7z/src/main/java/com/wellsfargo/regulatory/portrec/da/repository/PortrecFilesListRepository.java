package com.wellsfargo.regulatory.portrec.da.repository;

import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.da.domain.PortrecFilesList;
import com.wellsfargo.regulatory.portrec.da.domain.PortrecFilesListPk;

public interface PortrecFilesListRepository extends CrudRepository<PortrecFilesList, PortrecFilesListPk> {

	
}
