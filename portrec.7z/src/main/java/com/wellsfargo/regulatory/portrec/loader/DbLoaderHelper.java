package com.wellsfargo.regulatory.portrec.loader;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrPortfolioSizeLogDaoImpl;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrIceOpenTransaction;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJob;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconPositionRptRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

public abstract class DbLoaderHelper <T extends RegRepPrJob> {

	
	@Autowired
	RegRepPrJobDetailRepository regRepPrJobDetailRepository;
	
	@Autowired
	TransactionalLoaderService<T> transactionalLoaderService;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	CalendarService calendarService;
	
	@Autowired
	RegRepPrReconPositionRptRepository regRepPrReconPositionRptRepository;
	

	@Autowired
	RegRepPrPortfolioSizeLogDaoImpl regRepPrPortfolioSizeLogDaoImpl;
	
	RegRepPrJobDetail regRepPrJobDetail;

	private Logger logger = Logger.getLogger(DbLoaderHelper.class);
	private static int invalidTrades=0;
	
	
	@PostConstruct
	void init() {
		List<RegRepPrJobDetail> jobDetails = regRepPrJobDetailRepository.findByjobName(getPortfolioSegmentName());
		if (jobDetails.size() != 1) {
			throw new RuntimeException("Could not initialize Portfolio Segment '" + getPortfolioSegmentName() + "'");
		}
		regRepPrJobDetail = jobDetails.get(0);
	}
	
	public abstract String getPortfolioSegmentName();
	
	public abstract T parseRecords(RegRepPrIceOpenTransaction openTransactionList,Date asofDate) throws ParseException;
	
	public abstract boolean validate(T trade);
	
	public abstract T getTableName();
	
	public abstract boolean deletePrevDayRecords();
	
	public void postLoad() {};
	
	public String read() throws ParseException, PortrecException {
		logger.info("Loading data from table: ");
			Date asOfDate = extractAsOfDate();
			this.read(asOfDate);
			return null;
	}
	
	public RegRepPrJobExecutionDetail read(Date asOfDate) throws ParseException, PortrecException{
		Boolean errors = false;
		int jobdetails = transactionalLoaderService.getPrevJobDetails(getPortfolioSegmentName(), asOfDate);
		T deletetrades = getTableName();
		if(jobdetails != 0){
			transactionalLoaderService.deleteTrades(deletetrades, asOfDate, PortrecConstants.CURRENT_DATE, jobdetails );
		}
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = transactionalLoaderService.startLoad(regRepPrJobDetail, asOfDate);
		errors = loadFile(regRepPrJobExecutionDetail,asOfDate);
		transactionalLoaderService.completeLoad(regRepPrJobExecutionDetail, errors);
		return regRepPrJobExecutionDetail;
	}
	
	boolean loadFile(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail,Date asofDate) throws ParseException {
		
		List<T> trades = new ArrayList<T>();
		Boolean errors = false;
		
		if(!deletePrevDayRecords()){
		Date prevWeekDate = calendarService.getPreviousWeekDay(new Date());
		int jobdetails = transactionalLoaderService.getPrevWeekJobDetails(getPortfolioSegmentName(), prevWeekDate);
		if (jobdetails !=0){
			T deletetrades = getTableName();
			transactionalLoaderService.deleteTrades(deletetrades, prevWeekDate, PortrecConstants.PREVIOUS_WEEK, jobdetails);
			}
		} else {
		int jobdetails = transactionalLoaderService.getPrevRunJobDetails(getPortfolioSegmentName(), new Date());
		if (jobdetails !=0){
			T deletetrades = getTableName();
			transactionalLoaderService.deleteTrades(deletetrades,  new Date(), PortrecConstants.PREVIOUS_RECORDS, jobdetails);
			}
		}		
			String errorString = null;
			long start = System.currentTimeMillis();
			List<RegRepPrIceOpenTransaction> regRepIceOpenTransaction=regRepPrReconPositionRptRepository.findByRunDate(asofDate);
			for (RegRepPrIceOpenTransaction openTransactionList: regRepIceOpenTransaction) {
				if(regRepIceOpenTransaction.size() > 1){
				regRepPrJobExecutionDetail.setRecordsTotal(regRepPrJobExecutionDetail.getRecordsTotal() + 1);
				try {
					T trade = parseRecords(openTransactionList,asofDate);
					if(validate(trade)){
						trade.setJobExecutionId(regRepPrJobExecutionDetail);
						trades.add(trade);
						regRepPrJobExecutionDetail.setRecodsLoaded(regRepPrJobExecutionDetail.getRecodsLoaded() + 1);
					}else {
						invalidTrades++;
					}
				} catch (Exception e) {
					try
					{
					errors = true;	
					errorString = "Couldn't parse record: file #" + regRepPrJobExecutionDetail.getJobExecutionId();
					RegRepPrException regRepPrException = new RegRepPrException();										
					regRepPrException.setExceptionSource("LoaderHelper:1");
					regRepPrException.setJobExecutionId(regRepPrJobExecutionDetail.getJobExecutionId());
					regRepPrException.setExceptionDesc(errorString);
					regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
					regRepPrException.setExceptionTrace(ExceptionUtils.getStackTrace(e));
					regRepPrException.setCreateDatetime(new Date());
					portrecExceptionLogger.logExceptionToDB(regRepPrException);
					logger.error("Couldn't parse record: file #" + regRepPrJobExecutionDetail.getJobExecutionId());
					}
					catch(Exception ex)
					{
						logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(ex));
					}
				}
					
				if (regRepPrJobExecutionDetail.getRecodsLoaded() % 1000 == 0 && regRepPrJobExecutionDetail.getRecodsLoaded() > 0) {
					logger.info("Processed " + regRepPrJobExecutionDetail.getRecodsLoaded() + " records. Saving");
					transactionalLoaderService.saveTrades(regRepPrJobExecutionDetail, trades);
					trades.clear();
				}
			}
		}
				
			
			logger.info("Processed " + regRepPrJobExecutionDetail.getRecodsLoaded() + " records. Saving");
			transactionalLoaderService.saveTrades(regRepPrJobExecutionDetail, trades);
			long end = System.currentTimeMillis();
			logger.info("Total Time: " + (end - start));
			
			if(errors){
				logger.info("Error while Loading from table "+ regRepPrJobDetail.getJobName() +" from table on "+new Date());
			} else {
				logger.info("Data has been Loaded for "+ regRepPrJobDetail.getJobName() +" from table on "+new Date());
			}
		
		postLoad();
		return errors;
	}
	
	
	Date extractAsOfDate(){
		/*Using Real Time config date */
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);
		Date cobDate = null;
		String realTimeConfig = regRepPrPortfolioSizeLogDaoImpl.getCobDateFromRealTimeConfig(PortrecConstants.CLOSE_OF_BUSINESS_DATE);
		logger.info(" recon process running for Date received from CLOSE_OF_BUSINESS_DATE " + realTimeConfig);
		try {
			
				if(null != realTimeConfig)
				{
					cobDate = reconDateFormat.parse(realTimeConfig);
				}
				else
				{
					cobDate = new Date();
				}
		} 
		catch (ParseException e) {
			logger.error("########## " + e.getMessage());
		}
		
		return cobDate;
		/*Date currDate = new Date();
		Date date=calendarService.getPreviousWorkingDay(currDate);
		//RegRepIceOpenTransactionDaoImpl regRepIceOpenTransactionDaoImpl = new RegRepIceOpenTransactionDaoImpl();
		
		java.sql.Date convertedDate = null;
		String convertedString=null;
		if(null != date){
			DateFormat  dateFormat = new SimpleDateFormat("yyyy-MM-dd");			 
			convertedString =dateFormat.format(date);
			 java.util.Date parsedUtilDate;
			try {
				parsedUtilDate = dateFormat.parse(convertedString);
				convertedDate= new java.sql.Date(parsedUtilDate.getTime());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return convertedDate;
		*/
	}
	
	
	
	@Service
	@Transactional(value="portrec")
	static class TransactionalLoaderService<T extends RegRepPrJob> {
		@Autowired
		RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

		
		@PersistenceContext(unitName="Portrec")
		EntityManager entityManager;
		
		Logger logger = Logger.getLogger(getClass());
		
		public RegRepPrJobExecutionDetail startLoad(RegRepPrJobDetail regRepPrJobDetail,Date asOfDate) {
					
			RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();
			//tradeFile.setId(new BigDecimal(10000001));
			regRepPrJobExecutionDetail.setJobDetailsId(regRepPrJobDetail);
			regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
			regRepPrJobExecutionDetail.setFileName(PortrecConstants.ICE_DB_LOAD);
			regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
			regRepPrJobExecutionDetail.setCreateDatetime( new Date());				
			
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
			
			return regRepPrJobExecutionDetail;
		}
		
		public int getPrevJobDetails(String PortfolioSegmentName, Date asofDate) {
			int jobDetail = 0;
			BigDecimal regRepPrJobExecutionDetail;
			
			try {
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.findPreviousExecutionDetail(PortfolioSegmentName, asofDate);
				if (regRepPrJobExecutionDetail != null )
					{
						jobDetail = Integer.valueOf(regRepPrJobExecutionDetail.intValue());
					}
				}
			catch (Exception ex)
			{
				logger.error("Exception getting Prev job Details " + ex.getMessage());
			}
			return jobDetail;
		}
		
		public int getPrevWeekJobDetails(String PortfolioSegmentName, Date asofDate) {
			int jobDetail = 0;
			BigDecimal regRepPrJobExecutionDetail;
			Timestamp dateTime = new Timestamp(asofDate.getTime());
			try {
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.findPreviousWeekExecutionDetail(PortfolioSegmentName, DateUtils.truncate(dateTime, Calendar.DATE));
				if (regRepPrJobExecutionDetail != null )
					{
						jobDetail = Integer.valueOf(regRepPrJobExecutionDetail.intValue());
					}
				}
			catch (Exception ex)
			{
				logger.error("Exception getting Prev job Details " + ex.getMessage());
			}
			return jobDetail;
		}
		
		public int getPrevRunJobDetails(String PortfolioSegmentName, Date asofDate) {
			int jobDetail = 0;
			BigDecimal regRepPrJobExecutionDetail;
			
			Timestamp dateTime = new Timestamp(asofDate.getTime());
	
			try {
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.findPreviousRunExecutionDetail(PortfolioSegmentName, DateUtils.truncate(dateTime, Calendar.DATE));
				if (regRepPrJobExecutionDetail != null )
					{
						jobDetail = Integer.valueOf(regRepPrJobExecutionDetail.intValue());
					}
				}
			catch (Exception ex)
			{
				logger.error("Exception getting Prev job Details " + ex.getMessage());
			}
			return jobDetail;
		}
		
		public void saveTrades(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail, Collection<T> trades) {
			for (RegRepPrJob trade : trades) {
				//tradeRepo.save(trade);
				//tradeRevisionRepo.save(trade.getTradeRevision());
				entityManager.persist(trade);
			}
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		}
		
		public void deleteTrades(T trade, Date asofDate, String value, int jobdetails) {
			entityManager.flush();
			entityManager.clear();
						
			Class<?> clazz = trade.getClass();
			Table table = clazz.getAnnotation( Table.class );
			
			String query = null; 
			
			if(value.equals(PortrecConstants.PREVIOUS_WEEK) || value.equals(PortrecConstants.PREVIOUS_RECORDS)){
				query = "DELETE TOP 100000 FROM " + table.name() + " where job_execution_id <= :jobdetails";
				logger.info("DELETING ALL RECORDS FROM " + table.name() + " TABLE BEFORE " + asofDate + " For Job Details ID : " + jobdetails);
			} else if(value.equals(PortrecConstants.CURRENT_DATE)){
				query = "DELETE TOP 100000 FROM " + table.name() + " where job_execution_id = :jobdetails";
				logger.info("DELETING ALL RECORDS FROM " + table.name() + " TABLE FOR CURRENT DATE " + asofDate + " For Job Details ID : " + jobdetails);
			}
			try{
			Query upd =  entityManager.createNativeQuery(query);
			upd.setParameter("jobdetails", jobdetails);
					
			int updatedCnt = 0;
			do {
				updatedCnt = upd.executeUpdate();
				logger.info("" + updatedCnt + " trades deleted");
			} while (updatedCnt>0);
			
			} catch (Exception ex)
			{
				logger.error("Exception deleting Trades " +ex.getMessage());
			}
		}
		
		public void completeLoad(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail, Boolean errors) {
			regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
			
			if(regRepPrJobExecutionDetail.getRecodsLoaded() == regRepPrJobExecutionDetail.getRecordsTotal() || (!errors))
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
			}
			else
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
			}
			   
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
			logger.info(">>>>>>>>>>>>>> Excluded trades: " + invalidTrades);
		}
	}
	

	/** To Get Lei based on the - or :
	 * @param lei
	 * @return lei String
	 */
	public String getLei(String lei) {
		if (StringUtils.isNotBlank(lei)) {
			String patterns[] = { ":", "-" };
			for (int i = 0; i < patterns.length; i++) {
				if (lei.contains(patterns[i])) {
					String[] partyParts = lei.split(patterns[i]);
					if (partyParts.length == 2 && StringUtils.isNotBlank(partyParts[1]))
						lei = partyParts[1];
					else
						lei = "";
				}
			}
			return lei;
		} else
			return "";
	}
	
	
}
