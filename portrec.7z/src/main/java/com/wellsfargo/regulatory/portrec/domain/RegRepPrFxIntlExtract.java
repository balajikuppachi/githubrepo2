package com.wellsfargo.regulatory.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy 
 * The persistent class for the REG_REP_PR_FX_INTL_EXTRACT database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_FX_INTL_EXTRACT")
public class RegRepPrFxIntlExtract extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fx_intl_position_report_id")
	private Long fxIntlPositionReportId;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;
	
	/*@Column(name = "usi_prefix")
	private String usiPrefix;*/

	@Column(name = "usi_value")
	private String usiValue;
	
	@Column(name = "party_1_lei")
	private String party1Lei;
	
	@Column(name = "is_party1_sd")
	private String isParty1Sd;
	
	@Column(name = "is_party1_msp")
	private String isParty1Msp;
	
	@Column(name = "is_party1_fin")
	private String isParty1Fin;

	@Column(name = "is_party1_us_person")
	private String isParty1UsPerson;

	@Column(name = "allocation_indicator")
	private String allocationIndicator;
	
	@Column(name = "agent_lei")
	private String agentLei;
	
	@Column(name = "is_postallocation")
	private String isPostallocation;

	@Column(name = "party1_agent_usi_value")
	private String party1AgentUsiValue;

	@Column(name = "party_2_lei")
	private String party2Lei;
	
	@Column(name = "party2_internal_id")
	private String party2InternalId;
	
	@Column(name = "is_party2_sd")
	private String isParty2Sd;
	
	@Column(name = "is_party2_msp")
	private String isParty2Msp;
	
	@Column(name = "is_party2_fin")
	private String isParty2Fin;

	@Column(name = "is_party2_us_person")
	private String isParty2UsPerson;
	
	@Column(name = "product_id")
	private String productId;

	@Column(name = "cftc_product_id")
	private String cftcProductId;
	
	@Column(name = "sdr_internal_product_id")
	private String sdrInternalProductId;
	
	@Column(name = "is_multiasset_swap")
	private String isMultiassetSwap;
	
	@Column(name = "primary_asset_class")
	private String primaryAssetClass;
	
	@Column(name = "secondary_asset_class")
	private String secondaryAssetClass;

	@Column(name = "is_mixed_swap")
	private String isMixedSwap;
	
	@Column(name = "sdr2_id")
	private String sdr2Id;
	
	@Column(name = "contract_type")
	private String contractType;
	
	@Column(name = "block_trade_indicator")
	private String blockTradeIndicator;
	
	@Column(name = "execution_timestamp")
	private String executionTimestamp;
	
	@Column(name = "execution_venue")
	private String executionVenue;
	
	@Column(name = "CCY1")
	private String ccy1;

	@Column(name = "CCY2")
	private String ccy2;
	
	@Column(name = "notional_amount_1")
	private BigDecimal notionalAmount1;

	@Column(name = "notional_amount_2")
	private BigDecimal notionalAmount2;
	
	@Column(name = "exchange_rate")
	private BigDecimal exchangeRate;
	
	@Column(name = "delivery_type")
	private String deliveryType;

	@Temporal(TemporalType.DATE)
	@Column(name = "settlement_expiration_date")
	private Date settlementExpirationDate;
	
	@Column(name = "submission_timestamp")
	private String submissionTimestamp;
	
	@Column(name = "is_clearing_indicator")
	private String isClearingIndicator;
	
	@Column(name = "clearing_venue")
	private String clearingVenue;
	
	@Column(name = "is_clearing_req_exc")
	private String isClearingReqExc;

	@Column(name = "clearing_req_exc_id")
	private String clearingReqExcId;

	@Column(name = "collaterized")
	private String collaterized;
	
	@Column(name = "premium_currency")
	private String premiumCurrency;

	@Column(name = "premium_amount")
	private BigDecimal premiumAmount;

	@Temporal(TemporalType.DATE)
	@Column(name = "fixing_date")
	private Date fixingDate;

	@Column(name = "settlement_ccy")
	private String settlementCcy;
	
	@Column(name = "reporting_party")
	private String reportingParty;

	@Column(name = "is_cleared_trade")
	private String isClearedTrade;

	@Temporal(TemporalType.DATE)
	@Column(name = "settlement_fixing_date")
	private Date settlementFixingDate;

	@Temporal(TemporalType.TIME)
	@Column(name = "settlement_fixing_time")
	private Date settlementFixingTime;

	@Column(name = "settlement_fixing_bus_center")
	private String settlementFixingBusCenter;
	
	@Column(name = "mtm_position_value")
	private String mtmPositionValue;
	
	@Column(name = "business_account_id")
	private BigDecimal businessAccountId;


	public RegRepPrFxIntlExtract()
	{
	}


	public Long getFxIntlPositionReportId() {
		return fxIntlPositionReportId;
	}


	public void setFxIntlPositionReportId(Long fxIntlPositionReportId) {
		this.fxIntlPositionReportId = fxIntlPositionReportId;
	}


	public Date getAsOfDate() {
		return asOfDate;
	}


	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}


	public String getUsiValue() {
		return usiValue;
	}


	public void setUsiValue(String usiValue) {
		this.usiValue = usiValue;
	}


	public String getParty1Lei() {
		return party1Lei;
	}


	public void setParty1Lei(String party1Lei) {
		this.party1Lei = party1Lei;
	}


	public String getIsParty1Sd() {
		return isParty1Sd;
	}


	public void setIsParty1Sd(String isParty1Sd) {
		this.isParty1Sd = isParty1Sd;
	}


	public String getIsParty1Msp() {
		return isParty1Msp;
	}


	public void setIsParty1Msp(String isParty1Msp) {
		this.isParty1Msp = isParty1Msp;
	}


	public String getIsParty1Fin() {
		return isParty1Fin;
	}


	public void setIsParty1Fin(String isParty1Fin) {
		this.isParty1Fin = isParty1Fin;
	}


	public String getIsParty1UsPerson() {
		return isParty1UsPerson;
	}


	public void setIsParty1UsPerson(String isParty1UsPerson) {
		this.isParty1UsPerson = isParty1UsPerson;
	}


	public String getAllocationIndicator() {
		return allocationIndicator;
	}


	public void setAllocationIndicator(String allocationIndicator) {
		this.allocationIndicator = allocationIndicator;
	}


	public String getAgentLei() {
		return agentLei;
	}


	public void setAgentLei(String agentLei) {
		this.agentLei = agentLei;
	}


	public String getIsPostallocation() {
		return isPostallocation;
	}


	public void setIsPostallocation(String isPostallocation) {
		this.isPostallocation = isPostallocation;
	}


	public String getParty1AgentUsiValue() {
		return party1AgentUsiValue;
	}


	public void setParty1AgentUsiValue(String party1AgentUsiValue) {
		this.party1AgentUsiValue = party1AgentUsiValue;
	}


	public String getParty2Lei() {
		return party2Lei;
	}


	public void setParty2Lei(String party2Lei) {
		this.party2Lei = party2Lei;
	}


	public String getParty2InternalId() {
		return party2InternalId;
	}


	public void setParty2InternalId(String party2InternalId) {
		this.party2InternalId = party2InternalId;
	}


	public String getIsParty2Sd() {
		return isParty2Sd;
	}


	public void setIsParty2Sd(String isParty2Sd) {
		this.isParty2Sd = isParty2Sd;
	}


	public String getIsParty2Msp() {
		return isParty2Msp;
	}


	public void setIsParty2Msp(String isParty2Msp) {
		this.isParty2Msp = isParty2Msp;
	}


	public String getIsParty2Fin() {
		return isParty2Fin;
	}


	public void setIsParty2Fin(String isParty2Fin) {
		this.isParty2Fin = isParty2Fin;
	}


	public String getIsParty2UsPerson() {
		return isParty2UsPerson;
	}


	public void setIsParty2UsPerson(String isParty2UsPerson) {
		this.isParty2UsPerson = isParty2UsPerson;
	}


	public String getProductId() {
		return productId;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}


	public String getCftcProductId() {
		return cftcProductId;
	}


	public void setCftcProductId(String cftcProductId) {
		this.cftcProductId = cftcProductId;
	}


	public String getSdrInternalProductId() {
		return sdrInternalProductId;
	}


	public void setSdrInternalProductId(String sdrInternalProductId) {
		this.sdrInternalProductId = sdrInternalProductId;
	}


	public String getIsMultiassetSwap() {
		return isMultiassetSwap;
	}


	public void setIsMultiassetSwap(String isMultiassetSwap) {
		this.isMultiassetSwap = isMultiassetSwap;
	}


	public String getPrimaryAssetClass() {
		return primaryAssetClass;
	}


	public void setPrimaryAssetClass(String primaryAssetClass) {
		this.primaryAssetClass = primaryAssetClass;
	}


	public String getSecondaryAssetClass() {
		return secondaryAssetClass;
	}


	public void setSecondaryAssetClass(String secondaryAssetClass) {
		this.secondaryAssetClass = secondaryAssetClass;
	}


	public String getIsMixedSwap() {
		return isMixedSwap;
	}


	public void setIsMixedSwap(String isMixedSwap) {
		this.isMixedSwap = isMixedSwap;
	}


	public String getSdr2Id() {
		return sdr2Id;
	}


	public void setSdr2Id(String sdr2Id) {
		this.sdr2Id = sdr2Id;
	}


	public String getContractType() {
		return contractType;
	}


	public void setContractType(String contractType) {
		this.contractType = contractType;
	}


	public String getBlockTradeIndicator() {
		return blockTradeIndicator;
	}


	public void setBlockTradeIndicator(String blockTradeIndicator) {
		this.blockTradeIndicator = blockTradeIndicator;
	}


	public String getExecutionTimestamp() {
		return executionTimestamp;
	}


	public void setExecutionTimestamp(String executionTimestamp) {
		this.executionTimestamp = executionTimestamp;
	}


	public String getExecutionVenue() {
		return executionVenue;
	}


	public void setExecutionVenue(String executionVenue) {
		this.executionVenue = executionVenue;
	}


	public String getCcy1() {
		return ccy1;
	}


	public void setCcy1(String ccy1) {
		this.ccy1 = ccy1;
	}


	public String getCcy2() {
		return ccy2;
	}


	public void setCcy2(String ccy2) {
		this.ccy2 = ccy2;
	}


	public BigDecimal getNotionalAmount1() {
		return notionalAmount1;
	}


	public void setNotionalAmount1(BigDecimal notionalAmount1) {
		this.notionalAmount1 = notionalAmount1;
	}


	public BigDecimal getNotionalAmount2() {
		return notionalAmount2;
	}


	public void setNotionalAmount2(BigDecimal notionalAmount2) {
		this.notionalAmount2 = notionalAmount2;
	}


	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}


	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}


	public String getDeliveryType() {
		return deliveryType;
	}


	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}


	public Date getSettlementExpirationDate() {
		return settlementExpirationDate;
	}


	public void setSettlementExpirationDate(Date settlementExpirationDate) {
		this.settlementExpirationDate = settlementExpirationDate;
	}


	public String getSubmissionTimestamp() {
		return submissionTimestamp;
	}


	public void setSubmissionTimestamp(String submissionTimestamp) {
		this.submissionTimestamp = submissionTimestamp;
	}


	public String getIsClearingIndicator() {
		return isClearingIndicator;
	}


	public void setIsClearingIndicator(String isClearingIndicator) {
		this.isClearingIndicator = isClearingIndicator;
	}


	public String getClearingVenue() {
		return clearingVenue;
	}


	public void setClearingVenue(String clearingVenue) {
		this.clearingVenue = clearingVenue;
	}


	public String getIsClearingReqExc() {
		return isClearingReqExc;
	}


	public void setIsClearingReqExc(String isClearingReqExc) {
		this.isClearingReqExc = isClearingReqExc;
	}


	public String getClearingReqExcId() {
		return clearingReqExcId;
	}


	public void setClearingReqExcId(String clearingReqExcId) {
		this.clearingReqExcId = clearingReqExcId;
	}


	public String getCollaterized() {
		return collaterized;
	}


	public void setCollaterized(String collaterized) {
		this.collaterized = collaterized;
	}


	public String getPremiumCurrency() {
		return premiumCurrency;
	}


	public void setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
	}


	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}


	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}


	public Date getFixingDate() {
		return fixingDate;
	}


	public void setFixingDate(Date fixingDate) {
		this.fixingDate = fixingDate;
	}


	public String getSettlementCcy() {
		return settlementCcy;
	}


	public void setSettlementCcy(String settlementCcy) {
		this.settlementCcy = settlementCcy;
	}


	public String getReportingParty() {
		return reportingParty;
	}


	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}


	public String getIsClearedTrade() {
		return isClearedTrade;
	}


	public void setIsClearedTrade(String isClearedTrade) {
		this.isClearedTrade = isClearedTrade;
	}


	public Date getSettlementFixingDate() {
		return settlementFixingDate;
	}


	public void setSettlementFixingDate(Date settlementFixingDate) {
		this.settlementFixingDate = settlementFixingDate;
	}


	public Date getSettlementFixingTime() {
		return settlementFixingTime;
	}


	public void setSettlementFixingTime(Date settlementFixingTime) {
		this.settlementFixingTime = settlementFixingTime;
	}


	public String getSettlementFixingBusCenter() {
		return settlementFixingBusCenter;
	}


	public void setSettlementFixingBusCenter(String settlementFixingBusCenter) {
		this.settlementFixingBusCenter = settlementFixingBusCenter;
	}


	public String getMtmPositionValue() {
		return mtmPositionValue;
	}


	public void setMtmPositionValue(String mtmPositionValue) {
		this.mtmPositionValue = mtmPositionValue;
	}


	public BigDecimal getBusinessAccountId() {
		return businessAccountId;
	}


	public void setBusinessAccountId(BigDecimal businessAccountId) {
		this.businessAccountId = businessAccountId;
	}

	

}