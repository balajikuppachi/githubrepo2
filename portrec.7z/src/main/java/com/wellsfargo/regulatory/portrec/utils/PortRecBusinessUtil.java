package com.wellsfargo.regulatory.portrec.utils;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author u235720
 *
 */
@Component
public class PortRecBusinessUtil {
	private static Logger logger = Logger.getLogger(PortRecBusinessUtil.class);

	@Value("${customer.name.char.limit}")
	private String customerNameCharLimit;

	@Value("${customer.address.char.limit}")
	private String customerAddressCharLimit;

	private static final int DEFAULT_CHAR_LIMIT = 48;

	@Value("${mask.counterparty.text}")
	private String cptyMaskText;

	@Value("${wf.affiliatebank.leis}")
	private String wfLeiList;

	@Value("${mask.counterparty.quarterly.flag}")
	private String isQuarterlyCptyMasked;

	@Value("${mask.counterparty.annual.flag}")
	private String isAnnualCptyMasked;

	public String[] getCustomerName(String customerFullName) {

		//logger.info("Start spliting customer name : " + PortRecUtil.obfuscate((null == customerFullName?"????":customerFullName)));

		String[] customerName = new String[2];
		int charLimit = 0;

		if (null != customerNameCharLimit
				&& !customerNameCharLimit.equalsIgnoreCase("")) {
			charLimit = Integer.valueOf(customerNameCharLimit);
		} else {
			charLimit = DEFAULT_CHAR_LIMIT;
		}

		// String customer_name =
		// "testing duc interface using reg rep data testing duc interface using reg rep data testing duc interface using reg rep data testing duc interface using reg rep data testing duc interface using reg rep data testing duc interface using reg rep data";

		if (null != customerFullName && !customerFullName.equalsIgnoreCase("")) {
			customerFullName = customerFullName.replaceAll("'", "").replaceAll(",", " ");
			int length = customerFullName.length();

			String customerFirstName = null;
			String customerSecondName = null;
			int i = 0, j = 0;
			if (length <= charLimit) {
				customerFirstName = customerFullName;
			} else {
				for (i = charLimit; i <customerFullName.length(); i--) {
					if (customerFullName.charAt(i) == ' ') {
						break;
					}
				}
				customerFirstName = customerFullName.substring(0, i);
			}
			if (length > charLimit) {
				if (length < (2 * charLimit)) {
					if((length-i)>48){
						customerSecondName = customerFullName.substring(i + 1,
								i+1+48);
					}else{
						
					customerSecondName = customerFullName.substring(i + 1,
							length);
					}
				} else
					customerSecondName = customerFullName.substring(i + 1,
							i+1+48);
			} /*else {
				for (j = (2 * charLimit + 1); j < customerFullName.length(); j--) {
					if (customerFullName.charAt(j) == ' ') {
						break;
					}
				}
				customerSecondName = customerFullName.substring(i + 1, j);
			}*/

			customerName[0] = customerFirstName;
			customerName[1] = customerSecondName;
		}

		// logger.info("End spliting customer name : " + customerFullName);

		return customerName;

	}

	public String[] getCustomerAddress(String customerFullAddress) {

		//logger.info("Start spliting customer address : " + PortRecUtil.obfuscate((null == customerFullAddress?"????":customerFullAddress)));

		String[] customerAddress = new String[2];
		int charLimit = 0;

		if (null != customerAddressCharLimit
				&& !customerAddressCharLimit.equalsIgnoreCase("")) {
			charLimit = Integer.valueOf(customerAddressCharLimit);
		} else {
			charLimit = DEFAULT_CHAR_LIMIT;
		}

		if (null != customerFullAddress
				&& !customerFullAddress.equalsIgnoreCase("")) {
			customerFullAddress = customerFullAddress.replace("'", "").replaceAll(",", " ");
			int length = customerFullAddress.length();

			//String customerAddress1 = null;
			//String customerAddress2 = null;
			/*int i = 0, j = 0;
			if (length <= charLimit) {
				customerAddress1 = customerFullAddress;
			} else {
				for (i = charLimit + 1; i < customerFullAddress.length(); i--) {
					if (customerFullAddress.charAt(i) == ' ') {
						break;
					}
				}
				customerAddress1 = customerFullAddress.substring(0, i);
			}
			if (length > charLimit) {
				if (length < (2 * charLimit)) {
					customerAddress2 = customerFullAddress.substring(i + 1,
							length);
				} else
					customerAddress2 = customerFullAddress.substring(i + 1,
							2 * charLimit);
			}*/

			if(length > charLimit){
				customerAddress[0] = customerFullAddress.substring(0, charLimit);
				customerAddress[1] = customerFullAddress.substring(charLimit, customerFullAddress.length());
				
			}else{
				customerAddress[0] = customerFullAddress;
				customerAddress[1] = null;
			}
		}
		return customerAddress;
	}

	public String isCustomerDomOrIntl(String customerCountry) {

		String domIntl = null;

		if (null != customerCountry && !customerCountry.equalsIgnoreCase("") && !customerCountry.equalsIgnoreCase("0") && !customerCountry.equalsIgnoreCase(PortrecConstants.US)) {
			domIntl = PortrecConstants.INTERNATIONAL;
		} else {
			domIntl = PortrecConstants.DOMESTIC;
		}

		return domIntl;
	}

	public boolean isCptyMaskingRequired(String frequency) {

		// logger.info("Start checking if masking needed for frequency :" +
		// frequency);

		Boolean maskingFlag = null;

		if (null != frequency
				&& frequency.equalsIgnoreCase(PortrecConstants.QUARTERLY)) {

			if (null != isQuarterlyCptyMasked
					&& !isQuarterlyCptyMasked.equalsIgnoreCase("")) {

				maskingFlag = new Boolean(isQuarterlyCptyMasked);
			}
		} else if (null != frequency
				&& frequency.equalsIgnoreCase(PortrecConstants.ANNUAL)) {

			if (null != isAnnualCptyMasked
					&& !isAnnualCptyMasked.equalsIgnoreCase("")) {

				maskingFlag = new Boolean(isAnnualCptyMasked);
			}
		}

		// logger.info("End checking if masking needed : " + maskingFlag);
		return maskingFlag;
	}

	public String maskCounterPartyDetails(String leiValue, boolean maskingFlag) {

		// logger.info("Start Masking Party : "+ leiValue + ", maskingFlag :" +
		// maskingFlag);

		String cpVal = "";

		if (null != leiValue) {

			if (maskingFlag) {
				if (StringUtils.contains(wfLeiList, leiValue)) {
					cpVal = leiValue;
				} else {
					cpVal = cptyMaskText;
				}
			} else {
				cpVal = leiValue;
			}
		}
		// logger.info("End Masking Party : "+ cpVal);
		return cpVal;
	}

	public String maskCounterPartyName(String partyName, boolean maskingFlag) {

		// logger.info("Start Masking Party Name : "+ partyName +
		// ", maskingFlag :" + maskingFlag);

		String cpVal = "";

		if (null != partyName) {

			if (maskingFlag) {
				if (StringUtils.containsIgnoreCase(partyName, "Wells Fargo")) {
					cpVal = partyName;
				} else {
					cpVal = cptyMaskText;
				}
			} else {
				cpVal = partyName;
			}
		}
		// logger.info("End Masking Party Name : "+ cpVal);
		return cpVal;
	}

	public static void main(String[] arg) {

		String testName = "INTERNATIONAL SHIP REPAIR & MARINE SERVICES, INC.";
		//String testName = "8200 JONES BRANCH DRIVE";
		String arr[] = new String[2];

		PortRecBusinessUtil businessUtil = new PortRecBusinessUtil();
		//arr = businessUtil.getCustomerName(testName);
		
		//String newStr = testName.replaceAll(",", " ");
		/*String newStr = null;
		String newStr1 = null;
		
		if(testName.length() > 48){
			newStr = testName.substring(0, 48);
			newStr1 = testName.substring(48, testName.length());
			
		}else{
			newStr = testName;
			newStr1 = null;
		}*/
		arr=businessUtil.getCustomerName(testName);
		System.out.println(arr[0]+"6");
		System.out.println(arr[1]+"7");

	}

}
