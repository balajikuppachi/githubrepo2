package com.wellsfargo.regulatory.portrec.da.repository;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.da.domain.PortRecAuditLogView;
import com.wellsfargo.regulatory.portrec.da.domain.PortRecAuditLogViewPk;

public interface PortRecAuditLogViewRepository extends CrudRepository<PortRecAuditLogView, PortRecAuditLogViewPk> {

	@Query("select cpr from PortRecAuditLogView cpr where cpr.portRecAuditLogViewPk.reconDate = ?")
	List<PortRecAuditLogView> findForReconDate(String date);
	
	@Query("select cpr from PortRecAuditLogView cpr where cpr.portRecAuditLogViewPk.affirmDate > ? order by cpr.portRecAuditLogViewPk.affirmDate")
	List<PortRecAuditLogView> findRecordsAfterPrevAffirmDate(Date date);
	
	@Query("select cpr from PortRecAuditLogView cpr order by cpr.portRecAuditLogViewPk.affirmDate")
	List<PortRecAuditLogView> findRecordsOrderByAffirmDate();
}
