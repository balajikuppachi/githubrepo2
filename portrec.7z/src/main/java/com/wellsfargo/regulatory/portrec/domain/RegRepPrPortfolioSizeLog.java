package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_PORTFOLIO_SIZE_LOG database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_PORTFOLIO_SIZE_LOG")
public class RegRepPrPortfolioSizeLog extends RegRepPrJob
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "portfolio_size_log_id")
	private Long portfolioSizeLogId;

	private String annual;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "cid_cpty_id")
	private int cidCptyId;

	@Column(name = "create_datetime")
	private Date createDatetime;

	private String daily;

	@Column(name = "cpty_type")
	private String cptyType;

	@Column(name = "override_freq")
	private String overrideFreq;

	@Column(name = "comm_size")
	private int commoditySize;

	@Column(name = "cr_size")
	private int crSize;

	@Column(name = "ir_size")
	private int irSize;

	@Column(name = "eq_size")
	private int equitySize;

	@Column(name = "fx_size")
	private int fxSize;

	@Column(name = "fx_intl_size")
	private int fxIntlSize;

	@Column(name = "portfolio_size")
	private int portfolioSize;

	private String quarterly;

	@Column(name = "recon_day")
	private String reconDay;

	@Column(name = "recon_freq")
	private String reconFreq;

	private String weekly;

	public RegRepPrPortfolioSizeLog()
	{
	}

	public long getPortfolioSizeLogId()
	{
		return this.portfolioSizeLogId;
	}

	public void setPortfolioSizeLogId(long portfolioSizeLogId)
	{
		this.portfolioSizeLogId = portfolioSizeLogId;
	}

	public String getAnnual()
	{
		return this.annual;
	}

	public void setAnnual(String annual)
	{
		this.annual = annual;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public int getCidCptyId()
	{
		return this.cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public Date getCreateDatetime()
	{
		return this.createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

	public String getDaily()
	{
		return this.daily;
	}

	public void setDaily(String daily)
	{
		this.daily = daily;
	}

	public String getCptyType()
	{
		return cptyType;
	}

	public void setCptyType(String cptyType)
	{
		this.cptyType = cptyType;
	}

	public String getOverrideFreq()
	{
		return this.overrideFreq;
	}

	public void setOverrideFreq(String overrideFreq)
	{
		this.overrideFreq = overrideFreq;
	}

	public int getCommoditySize()
	{
		return commoditySize;
	}

	public void setCommoditySize(int commoditySize)
	{
		this.commoditySize = commoditySize;
	}

	public int getCrSize()
	{
		return crSize;
	}

	public void setCrSize(int crSize)
	{
		this.crSize = crSize;
	}

	public int getIrSize()
	{
		return irSize;
	}

	public void setIrSize(int irSize)
	{
		this.irSize = irSize;
	}

	public int getEquitySize()
	{
		return equitySize;
	}

	public void setEquitySize(int equitySize)
	{
		this.equitySize = equitySize;
	}

	public int getFxSize()
	{
		return fxSize;
	}

	public void setFxSize(int fxSize)
	{
		this.fxSize = fxSize;
	}

	public int getFxIntlSize()
	{
		return fxIntlSize;
	}

	public void setFxIntlSize(int fxIntlSize)
	{
		this.fxIntlSize = fxIntlSize;
	}

	public int getPortfolioSize()
	{
		return this.portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public String getQuarterly()
	{
		return this.quarterly;
	}

	public void setQuarterly(String quarterly)
	{
		this.quarterly = quarterly;
	}

	public String getReconDay()
	{
		return this.reconDay;
	}

	public void setReconDay(String reconDay)
	{
		this.reconDay = reconDay;
	}

	public String getReconFreq()
	{
		return this.reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public String getWeekly()
	{
		return this.weekly;
	}

	public void setWeekly(String weekly)
	{
		this.weekly = weekly;
	}

}