package  com.wellsfargo.regulatory.portrec.common;

public interface Location {
	String asString();
}
