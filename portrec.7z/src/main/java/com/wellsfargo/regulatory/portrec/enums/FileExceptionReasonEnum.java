package com.wellsfargo.regulatory.portrec.enums;

/**
 * @author u235720
 *
 */
public enum FileExceptionReasonEnum
{

	NO_MT_VAL("NO_MT_VAL"), NO_VAL("NO_VAL"), NO_MT("NO_MT"), MT_VAL_COUNT_MISMATCH("MT_VAL_COUNT_MISMATCH")
	, MT_COUNT_GREATER_THAN_VAL_COUNT ("MT_COUNT_GREATER_THAN_VAL_COUNT") ;

	private final String value;

	public String type()
	{

		return toString();
	}

	public String getValue()
	{

		return toString();
	}

	FileExceptionReasonEnum(String v)
	{

		value = v;
	}

	public static FileExceptionReasonEnum fromValue(String v)
	{

		for (FileExceptionReasonEnum c : FileExceptionReasonEnum.values())
		{

			if (c.value.equals(v))
			{
				return c;
			}
		}

		throw new IllegalArgumentException(v);
	}
}
