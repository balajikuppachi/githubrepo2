package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;

/**
 * 
 * @author Raji Komatreddy
 * Repository to save or get data from RegRepPrLiveTrade table  
 *
 */
public interface RegRepPrLiveTradeRepository extends CrudRepository<RegRepPrLiveTrade, Long>
{
	public List<RegRepPrLiveTrade> findAll();
	
	@Query("select distinct lt.baId from RegRepPrLiveTrade lt where lt.baId != 0")
	public List<Integer> findForReconDate();
	
	@Query("select distinct lt.assetClass from RegRepPrLiveTrade lt where lt.baId = ?1")
	public List<String> findSrcSystems(int baID);
	

	@Query("select  count(distinct lt.tradeId) from RegRepPrLiveTrade lt,RegRepPrCptyReconFreq cpr,RegRepPrAlgoValuation palgova where lt.legalId=cpr.cidCptyId and lt.tradeId=palgova.tradeId and  lt.legalId=palgova.legalId and palgova.collateralized='Y' and cpr.reconFreq=?1 and palgova.asOfDate=?2")
	public Long totalCollateralizedTrade(String reconFreq,Date date);


	/*@Query("select  count(lt) from RegRepPrAlgoValuation palgova,RegRepPrLiveTrade lt,RegRepPrCptyReconFreq cpr where palgova.collateralized='N' and lt.tradeId=palgova.tradeId and cpr.cidCptyId=lt.legalId and cpr.reconFreq=?1")
	public Long totalNonCollateralizedTrade(String reconFreq);*/
	
	@Query("Select DISTINCT lt.party2Lei from RegRepPrLiveTrade lt where lt.party2Lei != '' and lt.party2Lei != null and lt.baId = ?1 ")
	List<String> findPartyLei2ByBAID(int baid);
	
	@Query("Select DISTINCT lt.reconCpty from RegRepPrLiveTrade lt where lt.reconCpty != null and lt.reconEligible = 'Y' and lt.legalId = ?1 ")
	List<String> findReconCptyByLegalId(int legalId);
	
	@Query("select DISTINCT lt.reconCpty, lt.legalId from RegRepPrLiveTrade lt where lt.reconEligible = 'Y'  group by lt.reconCpty having count(distinct lt.legalId) > 1  ")
	List<Object[]> findLegalIDLEIS();

	@Query("select DISTINCT lt.usi,lt.assetClass from RegRepPrLiveTrade lt where lt.reconEligible = 'Y' and lt.usi!='' ")
	List<Object[]> findUsi();
	
	@Query("select distinct lt.asOfDate from RegRepPrLiveTrade lt where lt.reconEligible = 'Y' ")
	public List<Date> findAsOfDate();
	
	@Query("select lt from RegRepPrLiveTrade lt where lt.reconEligible = 'Y' and assetClass = ?")
	public List<RegRepPrLiveTrade> findTradesBasedonAssetClass(String assetClasses);
	
	
	@Query("select lt.usi from RegRepPrLiveTrade lt where lt.reconEligible != 'Y' and assetClass = ? ")
	public List<String> findTradesonAssetClassandQN(String assetClasses);
}
