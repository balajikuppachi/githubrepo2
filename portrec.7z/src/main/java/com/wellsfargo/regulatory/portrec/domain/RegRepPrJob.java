package com.wellsfargo.regulatory.portrec.domain;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class RegRepPrJob
{
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "job_execution_id", nullable = false)
	private RegRepPrJobExecutionDetail regRepPrJobExecutionDetail;

	public RegRepPrJobExecutionDetail getJobExecutionId()
	{
		return this.regRepPrJobExecutionDetail;
	}

	public void setJobExecutionId(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail)
	{
		this.regRepPrJobExecutionDetail = regRepPrJobExecutionDetail;
	}

}
