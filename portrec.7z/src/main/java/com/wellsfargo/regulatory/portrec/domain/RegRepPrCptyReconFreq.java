package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_CPTY_RECON_FREQ database table.
 */
@Entity
@Table(name = "REG_REP_PR_CPTY_RECON_FREQ")
public class RegRepPrCptyReconFreq
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cpty_recon_freq_id")
	private Long cptyReconFreqId;
	@Column(name = "cid_cpty_id")
	private int cidCptyId;

	@Column(name = "cpty_type")
	private String cptyType;

	@Column(name = "comm_size")
	private int commoditySize;

	@Column(name = "cr_size")
	private int crSize;

	@Column(name = "ir_size")
	private int irSize;

	@Column(name = "eq_size")
	private int equitySize;

	@Column(name = "fx_size")
	private int fxSize;

	@Column(name = "fx_intl_size")
	private int fxIntlSize;

	@Column(name = "portfolio_size")
	private int portfolioSize;

	@Column(name = "recon_freq")
	private String reconFreq;

	@Column(name = "update_datetime")
	private Date updateDatetime;

	public RegRepPrCptyReconFreq()
	{
	}

	public long getCptyReconFreqId()
	{
		return this.cptyReconFreqId;
	}

	public void setCptyReconFreqId(long cptyReconFreqId)
	{
		this.cptyReconFreqId = cptyReconFreqId;
	}

	public int getCidCptyId()
	{
		return this.cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public String getCptyType()
	{
		return cptyType;
	}

	public void setCptyType(String cptyType)
	{
		this.cptyType = cptyType;
	}

	public int getPortfolioSize()
	{
		return this.portfolioSize;
	}

	public int getCommoditySize()
	{
		return commoditySize;
	}

	public void setCommoditySize(int commoditySize)
	{
		this.commoditySize = commoditySize;
	}

	public int getCrSize()
	{
		return crSize;
	}

	public void setCrSize(int crSize)
	{
		this.crSize = crSize;
	}

	public int getIrSize()
	{
		return irSize;
	}

	public void setIrSize(int irSize)
	{
		this.irSize = irSize;
	}

	public int getEquitySize()
	{
		return equitySize;
	}

	public void setEquitySize(int equitySize)
	{
		this.equitySize = equitySize;
	}

	public int getFxSize()
	{
		return fxSize;
	}

	public void setFxSize(int fxSize)
	{
		this.fxSize = fxSize;
	}

	public int getFxIntlSize()
	{
		return fxIntlSize;
	}

	public void setFxIntlSize(int fxIntlSize)
	{
		this.fxIntlSize = fxIntlSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public String getReconFreq()
	{
		return this.reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public Date getUpdateDatetime()
	{
		return this.updateDatetime;
	}

	public void setUpdateDatetime(Date updateDatetime)
	{
		this.updateDatetime = updateDatetime;
	}

}