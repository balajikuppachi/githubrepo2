package com.wellsfargo.regulatory.portrec.common;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CSVDateReader  implements DataReader<String[]>{
	
	static char SEPARATOR = ',';
	
	CSVReader csvReader;
	int headerRows = 0;
	int lineNo = 0;
	
	public CSVDateReader(InputStream is, int headerRows) {
		this.headerRows = headerRows;
		csvReader = new CSVReader(new InputStreamReader(new BufferedInputStream(is)), SEPARATOR);
	}
	
	@Override
	public void close() throws IOException {
		csvReader.close();
	}

	@Override
	public String[] readNext() throws IOException {
		while (lineNo != headerRows) {
			csvReader.readNext();
			lineNo++;
		}
		
		lineNo++;
		return csvReader.readNext();
	}

	@Override
	public Location currentLocation() {
		return new Location() {
			@Override
			public String asString() {
				return "line " + lineNo;
			}
		};
	}

}
