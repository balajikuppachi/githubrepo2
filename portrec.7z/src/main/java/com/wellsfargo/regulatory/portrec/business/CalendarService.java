package com.wellsfargo.regulatory.portrec.business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrHoliday;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrHolidayRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;


@Service
@Transactional(value = "portrec")
public class CalendarService
{

	private static final int WEEKEND_1 = Calendar.SATURDAY;
	private static final int WEEKEND_2 = Calendar.SUNDAY;

	@Autowired
	RegRepPrHolidayRepository regRepPrHolidayRepository;
	
	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;

	public boolean isWorkingDay(Date date)
	{
		boolean isWorkingDay = true;
		Calendar calInstance = Calendar.getInstance();
		calInstance.setTime(date);

		int weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
		if (weekDay == WEEKEND_1 || weekDay == WEEKEND_2)
		{
			isWorkingDay = false;
		}
		RegRepPrHoliday holiday = regRepPrHolidayRepository.isHolidayDate(date);	
		if (holiday != null && holiday.getHolidayDate() != null)
		{
			isWorkingDay = false;
		}

		return isWorkingDay;
	}
	
	

	public Date getPreviousWorkingDay(Date date)
	{
		Date previousWorkingDate = null;
		try
		{
			if (date != null)
			{
				Calendar calInstance = Calendar.getInstance();
				calInstance.setTime(date);
				int weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
			/*	if (!(weekDay == WEEKEND_1 || weekDay == WEEKEND_2 || !isWorkingDay(calInstance.getTime())))
				{
					return date;
				}*/

				do
				{
					calInstance.add(Calendar.DATE, -1);
					/*weekDay = calInstance.get(Calendar.DAY_OF_WEEK);*/
				}
				while (weekDay == WEEKEND_1 || weekDay == WEEKEND_2 || !isWorkingDay(calInstance.getTime()));

				previousWorkingDate = calInstance.getTime();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return previousWorkingDate;
	}

	public Date getNextWorkingDay(Date reconDate)
	{
		Date nextWorkingDate = null;
		try
		{
			if (reconDate != null)
			{
				Calendar calInstance = Calendar.getInstance();
				calInstance.setTime(reconDate);
				int weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
				/*
				 * if(!(weekDay == WEEKEND_1 || weekDay == WEEKEND_2 ||
				 * !isWorkingDay(calInstance.getTime()))){ return reconDate; }
				 */
				do
				{
					calInstance.add(Calendar.DATE, 1);
					weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
				}
				while (weekDay == WEEKEND_1 || weekDay == WEEKEND_2 || !isWorkingDay(calInstance.getTime()));

				nextWorkingDate = calInstance.getTime();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return nextWorkingDate;
	}
	
	public Date getPreviousWeekDay(Date date)
	{
		Date previousWorkingDate = null;
		try
		{
			if (date != null)
			{
				Calendar calInstance = Calendar.getInstance();
				calInstance.setTime(date);
				calInstance.add(Calendar.DATE, -7);
				previousWorkingDate = calInstance.getTime();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return previousWorkingDate;
	}
	
	//days increment for duc report
	public Date dateIncrement(Date input, int noOfdays) {
		int dayCount = 0;
		Calendar calInstance = Calendar.getInstance();
		Date date = input;
		calInstance.setTime(date);
		int weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
		for (int count = 0; dayCount < noOfdays; count++) {
			if ((date != null)
					&& (!(weekDay == WEEKEND_1) || !(weekDay == WEEKEND_2) || isWorkingDay(calInstance
							.getTime()))) {
				date = getNextWorkingDay(date);
				calInstance.setTime(date);
				weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
				dayCount++;
			}

		}
		 return date;

	}
	
	//Return Recon frequency with year for Mis reports
		public String reconFrequency(Date date,String reconFreq ){
		Calendar calInstance = Calendar.getInstance();
		calInstance.setTime(date);
		int month = calInstance.get(Calendar.MONTH);
		int year=calInstance.get(Calendar.YEAR);
		if(reconFreq.equalsIgnoreCase("QUARTERLY"))
		{
		if(month==0 || month==1 || month ==2)
			reconFreq="Quarter 1"+PortrecConstants.SPACE+String.valueOf(year);
		else if(month==3 || month==4 || month ==5)
			reconFreq="Quarter 2"+PortrecConstants.SPACE+String.valueOf(year);
		else if(month==6 || month==7 || month ==8)
			reconFreq="Quarter 3"+PortrecConstants.SPACE+String.valueOf(year);
		else 
			reconFreq="Quarter 4"+PortrecConstants.SPACE+String.valueOf(year);
		}
		else
			reconFreq="Annual"+PortrecConstants.SPACE+String.valueOf(year);
		return reconFreq;
		}
		
		public Date returnDate(Date date) throws ParseException{
			
			String todayDate = PortRecUtil
					.convertDateToString_yyyy_MM_dd(date);
			Date as_of_date = regRepPrReconCalendarRepository
					.findByAsOfDate(todayDate);
			return as_of_date;
			
		}
		
		
}
