package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrDaReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public interface RegRepPrDaReportRepository extends CrudRepository<RegRepPrDaReport, Long>
{
	@Query("Select crd from RegRepPrDaReport crd where crd.regRepPrJobExecutionDetail = ?1")
	List<RegRepPrDaReport> findByJobExecutionId(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	
	@Query("Select crd from RegRepPrDaReport crd where crd.fileName = ?1")
	RegRepPrDaReport findByFileName(String fileName);
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='MT' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalMaterialTermFileCtrl(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='VAL' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalValuationFileCtrl(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(distinct prep.cidCptyId) from RegRepPrDaReport prep where prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalCptyProcessedToDA(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='MT' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalMaterialTermFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='MT' and prep.affirmedFlag='Y' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalAffirmMaterialTermFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='MT' and prep.affirmedFlag='N' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalDisAffirmMaterialTermFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='MT' and prep.affirmedFlag=null and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalNoResponseMaterialTermFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='VAL' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalValuationFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='VAL' and prep.affirmedFlag='Y' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalAffirmValuationFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='VAL' and prep.affirmedFlag='N' and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalDisAffirmValuationFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select count(prep) from RegRepPrDaReport prep where prep.mtValType='VAL' and prep.affirmedFlag=null and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=?2")
	public Long totalNoResponseValuationFile(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select rep.cidCptyId,rep.lgleFullN,prep.assetClass,prep.fileName,prep.reconFreq,prep.asOfDate,prep.mtValType,rep.jsFlag,prep.affirmedFlag,prep.affirmDatetime,prep.affirmComments from RegRepPrDaReport prep,RegRepPrReconReport rep  where prep.cidCptyId=rep.cidCptyId and prep.mtValType in ('MT','VAL') and prep.reconFreq=?1 and prep.regRepPrJobExecutionDetail=rep.regRepPrJobExecutionDetail and rep.regRepPrJobExecutionDetail=?2")
	List<Object []> postReportdetails(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);

	@Query("Select max(crd.affirmDatetime) from RegRepPrDaReport crd")
	Date findMaxAffirmDateTime();
}

