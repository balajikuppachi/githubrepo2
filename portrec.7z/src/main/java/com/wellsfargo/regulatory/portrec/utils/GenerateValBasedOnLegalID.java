package com.wellsfargo.regulatory.portrec.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrAlgoValuation;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrAlgoValuationRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;

@Service
@ManagedResource(description="Generating Val Files")
public class GenerateValBasedOnLegalID {
	
	private static Logger logger = Logger.getLogger(GenerateValBasedOnLegalID.class);
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	@Autowired
	RegRepPrAlgoValuationRepository regRepPrAlgoValuationRepository;
			
	@Value("${file.portrec.data.extracts}") String valuationFilePath;
	
	@ManagedOperation(description="Generate")
	public void generateValFiles(String legals, String valdate, String frequency) throws IOException{
		
		String[] legalIDs = legals.split(",");
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		List<RegRepPrAlgoValuation> entries= new ArrayList<RegRepPrAlgoValuation>();
		Date asOfDate = null;
		
		logger.info("Generating Val files for " + legalIDs.length +  " Legal ID's ");	
		
		try {
			asOfDate = format.parse(valdate);
		} catch (ParseException e) {
			logger.error("Format Exception for As of Date " + e.getMessage());
		}
		
		HashMap<String, List<Integer>>  mulLegalIDMap = new HashMap<String, List<Integer>>();		
		
		// Added for LEI mapping multiple legal ID issue
		List<Object[]> leisWithMulLglID = regRepPrLiveTradeRepository.findLegalIDLEIS();
		
		if(!leisWithMulLglID.isEmpty()){
			for (Object[] e : leisWithMulLglID){
			String lei = (String) e[0];
			int lglID = (int) e[1];
			if(lglID!=0){
			List<Integer> lgllist = new ArrayList<Integer>();
				lgllist.add(lglID);
				if(mulLegalIDMap.containsKey(lei)){
					List<Integer> l = mulLegalIDMap.get(lei);
						for(Integer lg : l){
								lgllist.add(lg);
						}
					}
					mulLegalIDMap.put(lei, lgllist);		
				}
			}
		} // ENDS for LEI mapping multiple legal ID issue
		
	
		for (String legalID :legalIDs ){
			
			List<Integer> listofLegalIDs = new ArrayList<Integer>();
						
			String valuationFileName = "CPPortfolio-LegalId-" + legalID + PortrecConstants.HYPHEN + PortRecUtil.convertDateToString_yyyyMdd(asOfDate) + PortrecConstants.HYPHEN + frequency.toUpperCase().charAt(0) + ".csv";
			
			int legalId = Integer.parseInt(legalID);
			
			BigInteger legal = null;
			try {		
				legal = new BigInteger(legalID);
			}
			catch (Exception e) {
				logger.error("Format Exception for Legal ID " + e.getMessage());
			}
			
			List<String> listOfLeis = regRepPrLiveTradeRepository.findReconCptyByLegalId(legalId);
			
			boolean exists = false;
			for (String lei : listOfLeis)
			{
				if (mulLegalIDMap.containsKey(lei))
				{
					List<Integer> lglID = mulLegalIDMap.get(lei);
					Iterator<Integer> itr = lglID.iterator();
					while (itr.hasNext())
					{
						Integer element = itr.next();
						listofLegalIDs.add(element);
						if (element == legalId)
						{
							exists = true;
						}
					}
				}
			}
			if (exists == false)
			{
				listofLegalIDs = null;
			}
								
			if(legal!=null){
				
				if(null != listofLegalIDs && !listofLegalIDs.isEmpty())
				{
					for (Integer lglID : listofLegalIDs){
						List<RegRepPrAlgoValuation> entriesperLegalID=regRepPrAlgoValuationRepository.findAlgoValuationByLegalIdAndCobDate(new BigInteger(String.valueOf(lglID)),asOfDate);
						entries.addAll(entriesperLegalID);
					}
				} else {
					// One LEI may be mapped to multiple Legal Ids, hence we have to consider portfolio size for all Legal Ids
					List<RegRepPrAlgoValuation> entriesperLegalID=regRepPrAlgoValuationRepository.findAlgoValuationByLegalIdAndCobDate(new BigInteger(String.valueOf(legalId)),asOfDate);
					entries.addAll(entriesperLegalID);
				}	
				
		if(null != entries && entries.size() >0){
					
			File file  = new File(valuationFilePath, valuationFileName);
			FileWriter fw = new FileWriter(file);
			fw.append("TradeID,ProductID,TradeDate,EndDate,MaturityDate,Notional1,Not. Ccy,PV,PVCcy\n");
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			DecimalFormat numberFormat = new DecimalFormat("#0.00#");
			try {
						
				for (RegRepPrAlgoValuation entry : entries) {
					fw
					.append(entry.getSourceSystem().concat(entry.getTradeId()).concat(PortRecUtil.convertDateToString_yyyyMdd(entry.getTradeDate()))).append(',')			
					.append(entry.getProductId()).append(',')
					.append(PortRecUtil.safeDateFormat(dateFormat, entry.getTradeDate())).append(',')
					.append("").append(',')
					.append(PortRecUtil.safeDateFormat(dateFormat, entry.getMaturityDate())).append(',')
					.append(PortRecUtil.safeNumberFormat(numberFormat, entry.getNotional1())).append(',')
					.append(entry.getNotional1Ccy()).append(',')	
					.append(PortRecUtil.safeStringFormatAsNumberforPV(numberFormat, entry.getPv())).append(',')
					.append(entry.getPvCcy()).append(',')
					.append('\n');
				}
						
			} catch(Exception ae) {
						throw ae;
			} finally {
						fw.close();
				}
					
			logger.info("VAL For Counterparty '" + legalID + "' has been generated: " + file.getCanonicalPath());
				}
			}
		}
			
		}
	}

	