package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCptyReconFreq;

/**
 * 
 * @author Raji Komatreddy
 * Repository to save or get data from RegRepPrCptyReconFreq table 
 *
 */
public interface RegRepPrCptyReconFreqRepository extends CrudRepository<RegRepPrCptyReconFreq, Long>
{

	@Query("select cpr from RegRepPrCptyReconFreq cpr where cpr.updateDatetime = ?1")
	List<RegRepPrCptyReconFreq> findByUpdateDateTime(Date date);
	
	
	@Query("select cpr from RegRepPrCptyReconFreq cpr where cpr.reconFreq = ?1")
	List<RegRepPrCptyReconFreq> findByReconFrequency(String reconFreq);
	
	@Query("select count(cpr) from RegRepPrCptyReconFreq cpr where cpr.reconFreq =?1")
	public Long findTotalCpEligibleForNotice(String reconFreq);
	@Query("select count(cpr) from RegRepPrCptyReconFreq cpr where cpr.cptyType in ('SD','MSP') and cpr.reconFreq =?1")
	public Long findSwapDealerAndMsp(String reconFreq);
	@Query("select count(cpr) from RegRepPrCptyReconFreq cpr where cpr.cptyType='NON_SD_MSP' and cpr.reconFreq =?1")
	public Long findNonSwapDealerAndMsp(String reconFreq);
	@Query("select sum(cpr.portfolioSize) from RegRepPrCptyReconFreq cpr where cpr.reconFreq =?1")
	public Long totalTradesEligibleForNoticeQuartely(String reconFreq);
	@Query("select sum(cpr.portfolioSize) from RegRepPrCptyReconFreq cpr where cpr.reconFreq =?1 and cpr.cptyType='SD'")
	public Long tradeSDMspQuartely(String reconFreq);
	@Query("select sum(cpr.portfolioSize) from RegRepPrCptyReconFreq cpr where cpr.reconFreq =?1 and cpr.cptyType='NON_SD_MSP'")
	public Long tradeNonSDMspQuartely(String reconFreq);

}
