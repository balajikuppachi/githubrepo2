package com.wellsfargo.regulatory.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy 
 * The persistent class for the REG_REP_PR_FX_POSITION_REPORT database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_FX_POSITION_REPORT")
public class RegRepPrFxPositionReport extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fx_position_report_id")
	private long fxPositionReportId;

	@Column(name = "additional_repository_1_prefix")
	private String additionalRepository1Prefix;

	@Column(name = "additional_repository1_lei")
	private String additionalRepository1Lei;

	@Column(name = "allocation_indicator")
	private String allocationIndicator;

	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "bloack_trade_indicator")
	private String bloackTradeIndicator;

	@Column(name = "broker_location_party_1")
	private String brokerLocationParty1;

	@Column(name = "broker_location_party_2")
	private String brokerLocationParty2;

	@Column(name = "CCY1")
	private String ccy1;

	@Column(name = "CCY2")
	private String ccy2;

	@Column(name = "cftc_product_id")
	private String cftcProductId;

	@Column(name = "clearing_exception_party_prefix")
	private String clearingExceptionPartyPrefix;

	@Column(name = "clearing_exception_party_value")
	private String clearingExceptionPartyValue;

	@Column(name = "clearing_venue")
	private String clearingVenue;

	private String collateralized;

	@Column(name = "contract_type")
	private String contractType;

	@Column(name = "data_submitter_lei_prefix")
	private String dataSubmitterLeiPrefix;

	@Column(name = "data_submitter_lei_value")
	private String dataSubmitterLeiValue;

	@Column(name = "delivery_type")
	private String deliveryType;

	@Column(name = "desk_location_party_1")
	private String deskLocationParty1;

	@Column(name = "desk_location_party_2")
	private String deskLocationParty2;

	@Column(name = "exchange_currency_1")
	private String exchangeCurrency1;

	@Column(name = "exchange_currency_2")
	private String exchangeCurrency2;

	@Column(name = "exchange_currency1_amount")
	private BigDecimal exchangeCurrency1Amount;

	@Column(name = "exchange_currency2_amount")
	private BigDecimal exchangeCurrency2Amount;

	@Column(name = "exchange_rate")
	private BigDecimal exchangeRate;

	@Column(name = "execution_timestamp")
	private String executionTimestamp;

	@Column(name = "execution_venue")
	private String executionVenue;

	@Temporal(TemporalType.DATE)
	@Column(name = "exotic_expiration_date")
	private Date exoticExpirationDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "expiration_date")
	private Date expirationDate;

	@Column(name = "expiration_time")
	private String expirationTime;

	@Column(name = "is_clearing_req_exc")
	private String isClearingReqExc;

	@Column(name = "is_mixed_swap")
	private String isMixedSwap;

	@Column(name = "is_multiasset_swap")
	private String isMultiassetSwap;

	@Column(name = "is_party1_fin")
	private String isParty1Fin;

	@Column(name = "is_party1_msp")
	private String isParty1Msp;

	@Column(name = "is_party1_sd")
	private String isParty1Sd;

	@Column(name = "is_party1_us_person")
	private String isParty1UsPerson;

	@Column(name = "is_party2_fin")
	private String isParty2Fin;

	@Column(name = "is_party2_msp")
	private String isParty2Msp;

	@Column(name = "is_party2_sd")
	private String isParty2Sd;

	@Column(name = "is_party2_us_person")
	private String isParty2UsPerson;

	@Column(name = "mandatory_clearing_indicator")
	private String mandatoryClearingIndicator;

	@Column(name = "mtm_position_value")
	private String mtmPositionValue;

	@Column(name = "notional_amount_1")
	private BigDecimal notionalAmount1;

	@Column(name = "notional_amount_2")
	private BigDecimal notionalAmount2;

	@Column(name = "notional_currency_1")
	private String notionalCurrency1;

	@Column(name = "notional_currency_2")
	private String notionalCurrency2;

	@Column(name = "party_1_lei")
	private String party1Lei;

	@Column(name = "party_2_lei")
	private String party2Lei;

	@Column(name = "party2_internal_id")
	private String party2InternalId;

	@Column(name = "premium_amount")
	private BigDecimal premiumAmount;

	@Column(name = "premium_currency")
	private String premiumCurrency;

	@Column(name = "primary_asset_class")
	private String primaryAssetClass;

	@Column(name = "product_id")
	private String productId;

	@Column(name = "product_id_prefix")
	private String productIdPrefix;

	@Column(name = "product_id_value")
	private String productIdValue;

	@Column(name = "reporting_party")
	private String reportingParty;

	@Column(name = "sdr_internal_product_id")
	private String sdrInternalProductId;

	@Column(name = "sdr_submision_timestamp")
	private String sdrSubmisionTimestamp;

	@Column(name = "sdr2_id")
	private String sdr2Id;

	@Column(name = "secondary_asset_class")
	private String secondaryAssetClass;

	@Column(name = "settlement_currency")
	private String settlementCurrency;

	@Temporal(TemporalType.DATE)
	@Column(name = "settlement_expiration_date")
	private Date settlementExpirationDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "settlement_fixing_date")
	private Date settlementFixingDate;

	@Column(name = "submission_timestamp")
	private String submissionTimestamp;

	@Column(name = "submitted_for")
	private String submittedFor;

	@Column(name = "system_derived_reporting_party")
	private String systemDerivedReportingParty;

	@Column(name = "trade_party_1")
	private String tradeParty1;

	@Column(name = "trade_party_1_lei")
	private String tradeParty1Lei;

	@Column(name = "trade_party_2")
	private String tradeParty2;

	@Column(name = "trade_party_2_lei")
	private String tradeParty2Lei;

	@Column(name = "trade_party1_fin_ent")
	private String tradeParty1FinEnt;

	@Column(name = "trade_party1_prefix")
	private String tradeParty1Prefix;

	@Column(name = "trade_party1_role")
	private String tradeParty1Role;

	@Column(name = "trade_party1_us_person_indicator")
	private String tradeParty1UsPersonIndicator;

	@Column(name = "trade_party2_fin_ent")
	private String tradeParty2FinEnt;

	@Column(name = "trade_party2_prefix")
	private String tradeParty2Prefix;

	@Column(name = "trade_party2_role")
	private String tradeParty2Role;

	@Column(name = "trade_party2_us_person_indicator")
	private String tradeParty2UsPersonIndicator;

	@Temporal(TemporalType.DATE)
	@Column(name = "trade_revision_id")
	private Date tradeRevisionId;

	@Column(name = "trader_location_party_1")
	private String traderLocationParty1;

	@Column(name = "trader_location_party_2")
	private String traderLocationParty2;

	@Column(name = "usi_prefix")
	private String usiPrefix;

	@Column(name = "usi_value")
	private String usiValue;

	public RegRepPrFxPositionReport()
	{
	}

	public long getFxPositionReportId()
	{
		return this.fxPositionReportId;
	}

	public void setFxPositionReportId(long fxPositionReportId)
	{
		this.fxPositionReportId = fxPositionReportId;
	}

	public String getAdditionalRepository1Prefix()
	{
		return this.additionalRepository1Prefix;
	}

	public void setAdditionalRepository1Prefix(String additionalRepository1Prefix)
	{
		this.additionalRepository1Prefix = additionalRepository1Prefix;
	}

	public String getAdditionalRepository1Lei()
	{
		return this.additionalRepository1Lei;
	}

	public void setAdditionalRepository1Lei(String additionalRepository1Lei)
	{
		this.additionalRepository1Lei = additionalRepository1Lei;
	}

	public String getAllocationIndicator()
	{
		return this.allocationIndicator;
	}

	public void setAllocationIndicator(String allocationIndicator)
	{
		this.allocationIndicator = allocationIndicator;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getBloackTradeIndicator()
	{
		return this.bloackTradeIndicator;
	}

	public void setBloackTradeIndicator(String bloackTradeIndicator)
	{
		this.bloackTradeIndicator = bloackTradeIndicator;
	}

	public String getBrokerLocationParty1()
	{
		return this.brokerLocationParty1;
	}

	public void setBrokerLocationParty1(String brokerLocationParty1)
	{
		this.brokerLocationParty1 = brokerLocationParty1;
	}

	public String getBrokerLocationParty2()
	{
		return this.brokerLocationParty2;
	}

	public void setBrokerLocationParty2(String brokerLocationParty2)
	{
		this.brokerLocationParty2 = brokerLocationParty2;
	}

	public String getCcy1()
	{
		return this.ccy1;
	}

	public void setCcy1(String ccy1)
	{
		this.ccy1 = ccy1;
	}

	public String getCcy2()
	{
		return this.ccy2;
	}

	public void setCcy2(String ccy2)
	{
		this.ccy2 = ccy2;
	}

	public String getCftcProductId()
	{
		return this.cftcProductId;
	}

	public void setCftcProductId(String cftcProductId)
	{
		this.cftcProductId = cftcProductId;
	}

	public String getClearingExceptionPartyPrefix()
	{
		return this.clearingExceptionPartyPrefix;
	}

	public void setClearingExceptionPartyPrefix(String clearingExceptionPartyPrefix)
	{
		this.clearingExceptionPartyPrefix = clearingExceptionPartyPrefix;
	}

	public String getClearingExceptionPartyValue()
	{
		return this.clearingExceptionPartyValue;
	}

	public void setClearingExceptionPartyValue(String clearingExceptionPartyValue)
	{
		this.clearingExceptionPartyValue = clearingExceptionPartyValue;
	}

	public String getClearingVenue()
	{
		return this.clearingVenue;
	}

	public void setClearingVenue(String clearingVenue)
	{
		this.clearingVenue = clearingVenue;
	}

	public String getCollateralized()
	{
		return this.collateralized;
	}

	public void setCollateralized(String collateralized)
	{
		this.collateralized = collateralized;
	}

	public String getContractType()
	{
		return this.contractType;
	}

	public void setContractType(String contractType)
	{
		this.contractType = contractType;
	}

	public String getDataSubmitterLeiPrefix()
	{
		return this.dataSubmitterLeiPrefix;
	}

	public void setDataSubmitterLeiPrefix(String dataSubmitterLeiPrefix)
	{
		this.dataSubmitterLeiPrefix = dataSubmitterLeiPrefix;
	}

	public String getDataSubmitterLeiValue()
	{
		return this.dataSubmitterLeiValue;
	}

	public void setDataSubmitterLeiValue(String dataSubmitterLeiValue)
	{
		this.dataSubmitterLeiValue = dataSubmitterLeiValue;
	}

	public String getDeliveryType()
	{
		return this.deliveryType;
	}

	public void setDeliveryType(String deliveryType)
	{
		this.deliveryType = deliveryType;
	}

	public String getDeskLocationParty1()
	{
		return this.deskLocationParty1;
	}

	public void setDeskLocationParty1(String deskLocationParty1)
	{
		this.deskLocationParty1 = deskLocationParty1;
	}

	public String getDeskLocationParty2()
	{
		return this.deskLocationParty2;
	}

	public void setDeskLocationParty2(String deskLocationParty2)
	{
		this.deskLocationParty2 = deskLocationParty2;
	}

	public String getExchangeCurrency1()
	{
		return this.exchangeCurrency1;
	}

	public void setExchangeCurrency1(String exchangeCurrency1)
	{
		this.exchangeCurrency1 = exchangeCurrency1;
	}

	public String getExchangeCurrency2()
	{
		return this.exchangeCurrency2;
	}

	public void setExchangeCurrency2(String exchangeCurrency2)
	{
		this.exchangeCurrency2 = exchangeCurrency2;
	}

	public BigDecimal getExchangeCurrency1Amount()
	{
		return this.exchangeCurrency1Amount;
	}

	public void setExchangeCurrency1Amount(BigDecimal exchangeCurrency1Amount)
	{
		this.exchangeCurrency1Amount = exchangeCurrency1Amount;
	}

	public BigDecimal getExchangeCurrency2Amount()
	{
		return this.exchangeCurrency2Amount;
	}

	public void setExchangeCurrency2Amount(BigDecimal exchangeCurrency2Amount)
	{
		this.exchangeCurrency2Amount = exchangeCurrency2Amount;
	}

	public BigDecimal getExchangeRate()
	{
		return this.exchangeRate;
	}

	public void setExchangeRate(BigDecimal exchangeRate)
	{
		this.exchangeRate = exchangeRate;
	}

	public String getExecutionTimestamp()
	{
		return this.executionTimestamp;
	}

	public void setExecutionTimestamp(String executionTimestamp)
	{
		this.executionTimestamp = executionTimestamp;
	}

	public String getExecutionVenue()
	{
		return this.executionVenue;
	}

	public void setExecutionVenue(String executionVenue)
	{
		this.executionVenue = executionVenue;
	}

	public Date getExoticExpirationDate()
	{
		return this.exoticExpirationDate;
	}

	public void setExoticExpirationDate(Date exoticExpirationDate)
	{
		this.exoticExpirationDate = exoticExpirationDate;
	}

	public Date getExpirationDate()
	{
		return this.expirationDate;
	}

	public void setExpirationDate(Date expirationDate)
	{
		this.expirationDate = expirationDate;
	}

	public String getExpirationTime()
	{
		return this.expirationTime;
	}

	public void setExpirationTime(String expirationTime)
	{
		this.expirationTime = expirationTime;
	}

	public String getIsClearingReqExc()
	{
		return this.isClearingReqExc;
	}

	public void setIsClearingReqExc(String isClearingReqExc)
	{
		this.isClearingReqExc = isClearingReqExc;
	}

	public String getIsMixedSwap()
	{
		return this.isMixedSwap;
	}

	public void setIsMixedSwap(String isMixedSwap)
	{
		this.isMixedSwap = isMixedSwap;
	}

	public String getIsMultiassetSwap()
	{
		return this.isMultiassetSwap;
	}

	public void setIsMultiassetSwap(String isMultiassetSwap)
	{
		this.isMultiassetSwap = isMultiassetSwap;
	}

	public String getIsParty1Fin()
	{
		return this.isParty1Fin;
	}

	public void setIsParty1Fin(String isParty1Fin)
	{
		this.isParty1Fin = isParty1Fin;
	}

	public String getIsParty1Msp()
	{
		return this.isParty1Msp;
	}

	public void setIsParty1Msp(String isParty1Msp)
	{
		this.isParty1Msp = isParty1Msp;
	}

	public String getIsParty1Sd()
	{
		return this.isParty1Sd;
	}

	public void setIsParty1Sd(String isParty1Sd)
	{
		this.isParty1Sd = isParty1Sd;
	}

	public String getIsParty1UsPerson()
	{
		return this.isParty1UsPerson;
	}

	public void setIsParty1UsPerson(String isParty1UsPerson)
	{
		this.isParty1UsPerson = isParty1UsPerson;
	}

	public String getIsParty2Fin()
	{
		return this.isParty2Fin;
	}

	public void setIsParty2Fin(String isParty2Fin)
	{
		this.isParty2Fin = isParty2Fin;
	}

	public String getIsParty2Msp()
	{
		return this.isParty2Msp;
	}

	public void setIsParty2Msp(String isParty2Msp)
	{
		this.isParty2Msp = isParty2Msp;
	}

	public String getIsParty2Sd()
	{
		return this.isParty2Sd;
	}

	public void setIsParty2Sd(String isParty2Sd)
	{
		this.isParty2Sd = isParty2Sd;
	}

	public String getIsParty2UsPerson()
	{
		return this.isParty2UsPerson;
	}

	public void setIsParty2UsPerson(String isParty2UsPerson)
	{
		this.isParty2UsPerson = isParty2UsPerson;
	}

	public String getMandatoryClearingIndicator()
	{
		return this.mandatoryClearingIndicator;
	}

	public void setMandatoryClearingIndicator(String mandatoryClearingIndicator)
	{
		this.mandatoryClearingIndicator = mandatoryClearingIndicator;
	}

	public String getMtmPositionValue()
	{
		return this.mtmPositionValue;
	}

	public void setMtmPositionValue(String mtmPositionValue)
	{
		this.mtmPositionValue = mtmPositionValue;
	}

	public BigDecimal getNotionalAmount1()
	{
		return this.notionalAmount1;
	}

	public void setNotionalAmount1(BigDecimal notionalAmount1)
	{
		this.notionalAmount1 = notionalAmount1;
	}

	public BigDecimal getNotionalAmount2()
	{
		return this.notionalAmount2;
	}

	public void setNotionalAmount2(BigDecimal notionalAmount2)
	{
		this.notionalAmount2 = notionalAmount2;
	}

	public String getNotionalCurrency1()
	{
		return this.notionalCurrency1;
	}

	public void setNotionalCurrency1(String notionalCurrency1)
	{
		this.notionalCurrency1 = notionalCurrency1;
	}

	public String getNotionalCurrency2()
	{
		return this.notionalCurrency2;
	}

	public void setNotionalCurrency2(String notionalCurrency2)
	{
		this.notionalCurrency2 = notionalCurrency2;
	}

	public String getParty1Lei()
	{
		return this.party1Lei;
	}

	public void setParty1Lei(String party1Lei)
	{
		this.party1Lei = party1Lei;
	}

	public String getParty2Lei()
	{
		return this.party2Lei;
	}

	public void setParty2Lei(String party2Lei)
	{
		this.party2Lei = party2Lei;
	}

	public String getParty2InternalId()
	{
		return this.party2InternalId;
	}

	public void setParty2InternalId(String party2InternalId)
	{
		this.party2InternalId = party2InternalId;
	}

	public BigDecimal getPremiumAmount()
	{
		return this.premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount)
	{
		this.premiumAmount = premiumAmount;
	}

	public String getPremiumCurrency()
	{
		return this.premiumCurrency;
	}

	public void setPremiumCurrency(String premiumCurrency)
	{
		this.premiumCurrency = premiumCurrency;
	}

	public String getPrimaryAssetClass()
	{
		return this.primaryAssetClass;
	}

	public void setPrimaryAssetClass(String primaryAssetClass)
	{
		this.primaryAssetClass = primaryAssetClass;
	}

	public String getProductId()
	{
		return this.productId;
	}

	public void setProductId(String productId)
	{
		this.productId = productId;
	}

	public String getProductIdPrefix()
	{
		return this.productIdPrefix;
	}

	public void setProductIdPrefix(String productIdPrefix)
	{
		this.productIdPrefix = productIdPrefix;
	}

	public String getProductIdValue()
	{
		return this.productIdValue;
	}

	public void setProductIdValue(String productIdValue)
	{
		this.productIdValue = productIdValue;
	}

	public String getReportingParty()
	{
		return this.reportingParty;
	}

	public void setReportingParty(String reportingParty)
	{
		this.reportingParty = reportingParty;
	}

	public String getSdrInternalProductId()
	{
		return this.sdrInternalProductId;
	}

	public void setSdrInternalProductId(String sdrInternalProductId)
	{
		this.sdrInternalProductId = sdrInternalProductId;
	}

	public String getSdrSubmisionTimestamp()
	{
		return this.sdrSubmisionTimestamp;
	}

	public void setSdrSubmisionTimestamp(String sdrSubmisionTimestamp)
	{
		this.sdrSubmisionTimestamp = sdrSubmisionTimestamp;
	}

	public String getSdr2Id()
	{
		return this.sdr2Id;
	}

	public void setSdr2Id(String sdr2Id)
	{
		this.sdr2Id = sdr2Id;
	}

	public String getSecondaryAssetClass()
	{
		return this.secondaryAssetClass;
	}

	public void setSecondaryAssetClass(String secondaryAssetClass)
	{
		this.secondaryAssetClass = secondaryAssetClass;
	}

	public String getSettlementCurrency()
	{
		return this.settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency)
	{
		this.settlementCurrency = settlementCurrency;
	}

	public Date getSettlementExpirationDate()
	{
		return this.settlementExpirationDate;
	}

	public void setSettlementExpirationDate(Date settlementExpirationDate)
	{
		this.settlementExpirationDate = settlementExpirationDate;
	}

	public Date getSettlementFixingDate()
	{
		return this.settlementFixingDate;
	}

	public void setSettlementFixingDate(Date settlementFixingDate)
	{
		this.settlementFixingDate = settlementFixingDate;
	}

	public String getSubmissionTimestamp()
	{
		return this.submissionTimestamp;
	}

	public void setSubmissionTimestamp(String submissionTimestamp)
	{
		this.submissionTimestamp = submissionTimestamp;
	}

	public String getSubmittedFor()
	{
		return this.submittedFor;
	}

	public void setSubmittedFor(String submittedFor)
	{
		this.submittedFor = submittedFor;
	}

	public String getSystemDerivedReportingParty()
	{
		return this.systemDerivedReportingParty;
	}

	public void setSystemDerivedReportingParty(String systemDerivedReportingParty)
	{
		this.systemDerivedReportingParty = systemDerivedReportingParty;
	}

	public String getTradeParty1()
	{
		return this.tradeParty1;
	}

	public void setTradeParty1(String tradeParty1)
	{
		this.tradeParty1 = tradeParty1;
	}

	public String getTradeParty1Lei()
	{
		return this.tradeParty1Lei;
	}

	public void setTradeParty1Lei(String tradeParty1Lei)
	{
		this.tradeParty1Lei = tradeParty1Lei;
	}

	public String getTradeParty2()
	{
		return this.tradeParty2;
	}

	public void setTradeParty2(String tradeParty2)
	{
		this.tradeParty2 = tradeParty2;
	}

	public String getTradeParty2Lei()
	{
		return this.tradeParty2Lei;
	}

	public void setTradeParty2Lei(String tradeParty2Lei)
	{
		this.tradeParty2Lei = tradeParty2Lei;
	}

	public String getTradeParty1FinEnt()
	{
		return this.tradeParty1FinEnt;
	}

	public void setTradeParty1FinEnt(String tradeParty1FinEnt)
	{
		this.tradeParty1FinEnt = tradeParty1FinEnt;
	}

	public String getTradeParty1Prefix()
	{
		return this.tradeParty1Prefix;
	}

	public void setTradeParty1Prefix(String tradeParty1Prefix)
	{
		this.tradeParty1Prefix = tradeParty1Prefix;
	}

	public String getTradeParty1Role()
	{
		return this.tradeParty1Role;
	}

	public void setTradeParty1Role(String tradeParty1Role)
	{
		this.tradeParty1Role = tradeParty1Role;
	}

	public String getTradeParty1UsPersonIndicator()
	{
		return this.tradeParty1UsPersonIndicator;
	}

	public void setTradeParty1UsPersonIndicator(String tradeParty1UsPersonIndicator)
	{
		this.tradeParty1UsPersonIndicator = tradeParty1UsPersonIndicator;
	}

	public String getTradeParty2FinEnt()
	{
		return this.tradeParty2FinEnt;
	}

	public void setTradeParty2FinEnt(String tradeParty2FinEnt)
	{
		this.tradeParty2FinEnt = tradeParty2FinEnt;
	}

	public String getTradeParty2Prefix()
	{
		return this.tradeParty2Prefix;
	}

	public void setTradeParty2Prefix(String tradeParty2Prefix)
	{
		this.tradeParty2Prefix = tradeParty2Prefix;
	}

	public String getTradeParty2Role()
	{
		return this.tradeParty2Role;
	}

	public void setTradeParty2Role(String tradeParty2Role)
	{
		this.tradeParty2Role = tradeParty2Role;
	}

	public String getTradeParty2UsPersonIndicator()
	{
		return this.tradeParty2UsPersonIndicator;
	}

	public void setTradeParty2UsPersonIndicator(String tradeParty2UsPersonIndicator)
	{
		this.tradeParty2UsPersonIndicator = tradeParty2UsPersonIndicator;
	}

	public Date getTradeRevisionId()
	{
		return this.tradeRevisionId;
	}

	public void setTradeRevisionId(Date tradeRevisionId)
	{
		this.tradeRevisionId = tradeRevisionId;
	}

	public String getTraderLocationParty1()
	{
		return this.traderLocationParty1;
	}

	public void setTraderLocationParty1(String traderLocationParty1)
	{
		this.traderLocationParty1 = traderLocationParty1;
	}

	public String getTraderLocationParty2()
	{
		return this.traderLocationParty2;
	}

	public void setTraderLocationParty2(String traderLocationParty2)
	{
		this.traderLocationParty2 = traderLocationParty2;
	}

	public String getUsiPrefix()
	{
		return this.usiPrefix;
	}

	public void setUsiPrefix(String usiPrefix)
	{
		this.usiPrefix = usiPrefix;
	}

	public String getUsiValue()
	{
		return this.usiValue;
	}

	public void setUsiValue(String usiValue)
	{
		this.usiValue = usiValue;
	}

}