package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCommPositionReport;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrDtccCommCSVReader extends LoaderHelper<RegRepPrCommPositionReport> {
	Logger logger = Logger.getLogger(getClass());
	
	public static String PORTFOLIO_SEGMENT_NAME = "Commodity, DTCC";
	
	@Value("${file.dtcccomm.epr.header}") int headerRows;
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.COM_DTCC;
	}
	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}
	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new CsvWithHeaderReader(inputStream, headerRows);
	}
	@Override
	public RegRepPrCommPositionReport parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrCommPositionReport commodityTradeUnfiltered = new RegRepPrCommPositionReport();
		commodityTradeUnfiltered.setUsiValue(fields[3]+fields[4]);  // usi_or_uti
		commodityTradeUnfiltered.setTradeParty1Name(fields[42]);
		if(fields[41]!=null && StringUtils.isNotBlank(fields[41]) && StringUtils.equalsIgnoreCase(fields[41],"Swap Dealer")){
			commodityTradeUnfiltered.setReportSd("Y");		
			commodityTradeUnfiltered.setReportMsp("N");		
			commodityTradeUnfiltered.setReportFin("N");
		}else if (fields[41]!=null && StringUtils.isNotBlank(fields[41]) && StringUtils.equalsIgnoreCase(fields[41],"Swap Dealer")){
			commodityTradeUnfiltered.setReportSd("N");		
			commodityTradeUnfiltered.setReportMsp("Y");	
			commodityTradeUnfiltered.setReportFin("N");
		}else if (fields[41]!=null && StringUtils.isNotBlank(fields[41]) && StringUtils.equalsIgnoreCase(fields[41],"Non-SD/MSP Financial Entity")){
			commodityTradeUnfiltered.setReportSd("N");		
			commodityTradeUnfiltered.setReportMsp("N");		
			commodityTradeUnfiltered.setReportFin("Y");
		}else {
			commodityTradeUnfiltered.setReportSd("N");		
			commodityTradeUnfiltered.setReportMsp("N");	
			commodityTradeUnfiltered.setReportFin("N");
		}
		commodityTradeUnfiltered.setReportUs(fields[44]);			
		commodityTradeUnfiltered.setTradeParty2Name(fields[38]);
		commodityTradeUnfiltered.setNonReportId(fields[39]);
		if(fields[37]!=null && StringUtils.isNotBlank(fields[37]) && StringUtils.equalsIgnoreCase(fields[37],"Swap Dealer")){
			commodityTradeUnfiltered.setNonReptSd("Y");		
			commodityTradeUnfiltered.setNonRepMsp("N");	
			commodityTradeUnfiltered.setNonRepFin("N");		
		}else if (fields[37]!=null && StringUtils.isNotBlank(fields[37]) && StringUtils.equalsIgnoreCase(fields[37],"Swap Dealer")){
			commodityTradeUnfiltered.setNonReptSd("N");		
			commodityTradeUnfiltered.setNonRepMsp("Y");	
			commodityTradeUnfiltered.setNonRepFin("N");
		}else if (fields[37]!=null && StringUtils.isNotBlank(fields[37]) && StringUtils.equalsIgnoreCase(fields[37],"Non-SD/MSP Financial Entity")){
			commodityTradeUnfiltered.setNonReptSd("N");		
			commodityTradeUnfiltered.setNonRepMsp("N");	
			commodityTradeUnfiltered.setNonRepFin("Y");
		}else {
			commodityTradeUnfiltered.setNonReptSd("N");		
			commodityTradeUnfiltered.setNonRepMsp("N");	
			commodityTradeUnfiltered.setNonRepFin("N");
		}
		commodityTradeUnfiltered.setNonRepUs(fields[40]);
		commodityTradeUnfiltered.setProductId(fields[10]);
		commodityTradeUnfiltered.setCftcProductId(fields[10]);
		commodityTradeUnfiltered.setIntProductId(fields[10]);
		commodityTradeUnfiltered.setMultAssetClassSwap(fields[34]);	
		commodityTradeUnfiltered.setMacPriAssetClass(fields[24]);//TODO
		commodityTradeUnfiltered.setMacSecAssetClass(fields[23]);//TODO
		commodityTradeUnfiltered.setMixedSwap(fields[33]);	
		commodityTradeUnfiltered.setMixedSwapReportSdr(fields[36]);//TODO
		commodityTradeUnfiltered.setContractType(fields[10]);
		commodityTradeUnfiltered.setExecutionVenue(fields[42]);
		if(StringUtils.isNotBlank(fields[136]))
			commodityTradeUnfiltered.setStartDate(DateUtilLoader.getDateFromString(fields[136]));
		if(StringUtils.isNotBlank(fields[140]))
			commodityTradeUnfiltered.setEndDate(DateUtilLoader.getDateFromString(fields[140]));
		commodityTradeUnfiltered.setBuyer(fields[146]);
		commodityTradeUnfiltered.setSeller(fields[147]);
		commodityTradeUnfiltered.setQantityUnit(fields[188]);
		commodityTradeUnfiltered.setQantity(fields[186]);
		commodityTradeUnfiltered.setQantityFreq(fields[187]);
		commodityTradeUnfiltered.setTotalFreq(fields[192]);
		
		
		
		String settlementMethodStr = "";
		if(StringUtils.isNotBlank(fields[10])){
			String settlementMethodArr[] = fields[10].split(":");
			if(settlementMethodArr!=null && settlementMethodArr.length>0)
				settlementMethodStr = settlementMethodArr[settlementMethodArr.length-1];
		}
		commodityTradeUnfiltered.setSettlementMethod(settlementMethodStr);
		
		commodityTradeUnfiltered.setPrice(fields[168]);
		commodityTradeUnfiltered.setPriceUnit(fields[170]);
		commodityTradeUnfiltered.setPriceCurr(fields[169]);
		commodityTradeUnfiltered.setBuyerPayIndex(""); //TODO
		commodityTradeUnfiltered.setBuyerPayindexAvgMethod(""); //TODO
		commodityTradeUnfiltered.setSellerPayIndex(""); //TODO
		commodityTradeUnfiltered.setSellerPayindexAvgMethod(""); //TODO
		commodityTradeUnfiltered.setGrade(fields[5]);
		commodityTradeUnfiltered.setOptionType(fields[414]);
		commodityTradeUnfiltered.setOptionStyle(fields[464]);
		commodityTradeUnfiltered.setOptionPremium(fields[612]);
		commodityTradeUnfiltered.setHrFromThr(""); //TODO
		commodityTradeUnfiltered.setHrFromThrTimezone(""); //TODO
		commodityTradeUnfiltered.setDaysOfWeek(fields[268]);
		commodityTradeUnfiltered.setLoadType(fields[807]);
		commodityTradeUnfiltered.setCollaterlized(fields[54]);
		commodityTradeUnfiltered.setSubmittedOnbehalfPartyIdValue(fields[35]);
		commodityTradeUnfiltered.setTradeParty1(fields[13]);
		commodityTradeUnfiltered.setTradeParty2(fields[12]);
		commodityTradeUnfiltered.setAsOfDate(asofDate);
		
		commodityTradeUnfiltered.setBuyerLei(fields[1083]); //previously fields[85]
		commodityTradeUnfiltered.setSellerLei(fields[1084]); //previously fields[94]
		
		return commodityTradeUnfiltered;
	}
	@Override
	public boolean validate(RegRepPrCommPositionReport trade) {
		return true;
	}
	@Override
	public RegRepPrCommPositionReport getTableName() {
			return new RegRepPrCommPositionReport();
	}
	@Override
	public boolean deletePrevDayRecords() {
		return false;
	}
	@Override
	public String loadNextJob() {
		// TODO Auto-generated method stub
		return null;
	}	
}
