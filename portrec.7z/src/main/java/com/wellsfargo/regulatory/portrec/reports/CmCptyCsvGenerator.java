package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCommPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.mailer.CptyDerivativeAccessService;
import com.wellsfargo.regulatory.portrec.mailer.PrExtractsTo;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCommPositionReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class CmCptyCsvGenerator {
	
	private final Logger logger = Logger.getLogger(CmCptyCsvGenerator.class);	
	
	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	@Autowired
	RegRepPrCommPositionReportRepository repPrCommPositionReportRepository;
	
	@Autowired
	CmDataCsvWriter commDataCsvWriter;
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;
	
	public PrExtractsTo createFile(List<String> counterPartyLeiList, Long legalId, Date asOfDate, String frequency) throws Exception {		
		
		boolean commFileFlag = false;
		PrExtractsTo reportProp = new PrExtractsTo();
		reportProp.setAssetClass(PortrecConstants.COMM);
		
		boolean maskingFlag = portRecBusinessUtil.isCptyMaskingRequired(frequency);
		
		StringBuilder cmMtFileNameBuffer = new StringBuilder();
		
		cmMtFileNameBuffer.append(PortrecConstants.COMM_MT_FILE_INITIAL).append(PortrecConstants.UNDERSCORE).append(legalId).append(PortrecConstants.UNDERSCORE).append(PortRecUtil.convertDateToString_yyyyMdd(asOfDate)).
		append(PortrecConstants.UNDERSCORE).append(frequency.toUpperCase().charAt(0)).append(PortrecConstants.EXTN_CSV);

		String commMtFileName = cmMtFileNameBuffer.toString();
		
		File commMtFile  = new File(outputFolderName, commMtFileName);
		
		List<RegRepPrCommPositionReport> cptyCommPositionsByLegalId = null;
		
		for(String counterPartyLei : counterPartyLeiList){
			
			List<RegRepPrCommPositionReport> cptyFxPositionsByLei = null;
			
			if(null!= counterPartyLei){
				cptyFxPositionsByLei = repPrCommPositionReportRepository.findCptyPositionsByLeiAndDate(asOfDate,counterPartyLei,counterPartyLei);
			}
			
			if(null != cptyFxPositionsByLei && cptyFxPositionsByLei.size() > 0) {
				logger.info("Number of Cpty COMM Dtcc Positions :["+ cptyFxPositionsByLei.size() + "]");
				commFileFlag = true;
				
				if(!commMtFile.exists()){
					commMtFile.mkdirs();
				}
				
				if(null == cptyCommPositionsByLegalId){
					cptyCommPositionsByLegalId = new ArrayList<RegRepPrCommPositionReport>();
				}
				cptyCommPositionsByLegalId.addAll(cptyFxPositionsByLei);
				
			}else{
				logger.info("No records found for Cpty COMM Dtcc Position with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
		}
		
		if(commFileFlag)
		{
			int commCount = generateMTFile(cptyCommPositionsByLegalId,commMtFile, maskingFlag);
			reportProp.setComCount(commCount);
			
			if(commCount > 0){
				reportProp.setComMtFileName(commMtFileName);
				logger.info("COMM MT generated at  "+ outputFolderName);	
			}
		}
		
		reportProp.setFlag(commFileFlag);
		return reportProp;
	}
	
	private int generateMTFile(List<RegRepPrCommPositionReport> cptyCommPositionsByLegalId, File commMtFile, boolean maskingFlag) throws Exception 
	{
		Map<String,RegRepPrCommPositionReport> tradeMap = new ConcurrentHashMap<String,RegRepPrCommPositionReport>();
		int count = 0;
		
		try{
			for(RegRepPrCommPositionReport commPositionReport:cptyCommPositionsByLegalId){
				RegRepPrCommPositionReport trade=new RegRepPrCommPositionReport();
				BeanUtils.copyProperties(commPositionReport, trade);
				tradeMap.put(trade.getUsiValue()+":"+trade.getSrcTradeId(), trade);
			}
			commDataCsvWriter.generateFile(commMtFile, tradeMap, maskingFlag);
		}
		catch(Exception ce){
			throw ce;
		}
		
		count = tradeMap.size();
		
		return count;
	}
	
}
