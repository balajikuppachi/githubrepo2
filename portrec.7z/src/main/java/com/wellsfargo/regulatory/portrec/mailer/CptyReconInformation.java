package com.wellsfargo.regulatory.portrec.mailer;

import java.sql.Timestamp;
import java.util.Date;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.enums.CommunicationTypeEnum;

/**
 * @author u235720
 *
 */
public class CptyReconInformation {
	
	private int cidCptyId;
	
	private String customerName1;

	private String customerName2;
	
	private String addressLine1;

	private String addressLine2;
	
	private String emailAddress;
	
	private String DomIntl;
	
	private String jsFlag;
	
	private String city;
	
	private String state;
	
	private String country;
	
	private String zipCode;
	
	private String cptyType;

	private int portfolioSize;

	private String reconFreq;
	
	private Date dispatchDate;
	
	private Date dataDeliveryDate;
	
	private Date recordDate;
	
	private Date affirmDate;

	private Date asOfDate;
	
	private Date nextBusWorkingDate;

	private Timestamp createDatetime;
	
	private CommunicationTypeEnum communicationType;
	
	private RegRepPrJobExecutionDetail regRepPrJobExecutionDetail;
	
	private int commoditySize;

	private int crSize;

	private int irSize;

	private int equitySize;

	private int fxSize;

	private int fxIntlSize;
	
	private String fullLegalName;
	
	private String lei;
	
	private Date jobAsOfDate;
	
	private boolean fileExceptionFlag; 
	
	private long jobExecutionId;
	
	public CommunicationTypeEnum getCommunicationType() {
		return communicationType;
	}

	public void setCommunicationType(CommunicationTypeEnum communicationType) {
		this.communicationType = communicationType;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public Date getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}

	public int getCidCptyId() {
		return cidCptyId;
	}

	public void setCidCptyId(int cidCptyId) {
		this.cidCptyId = cidCptyId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Timestamp getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Timestamp createDatetime) {
		this.createDatetime = createDatetime;
	}

	public String getCustomerName1() {
		return customerName1;
	}

	public void setCustomerName1(String customerName1) {
		this.customerName1 = customerName1;
	}

	public String getCustomerName2() {
		return customerName2;
	}

	public void setCustomerName2(String customerName2) {
		this.customerName2 = customerName2;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getJsFlag() {
		return jsFlag;
	}

	public void setJsFlag(String jsFlag) {
		this.jsFlag = jsFlag;
	}

	public int getPortfolioSize() {
		return portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize) {
		this.portfolioSize = portfolioSize;
	}

	public String getReconFreq() {
		return reconFreq;
	}

	public void setReconFreq(String reconFreq) {
		this.reconFreq = reconFreq;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Date getDispatchDate() {
		return dispatchDate;
	}

	public void setDispatchDate(Date dispatchDate) {
		this.dispatchDate = dispatchDate;
	}

	public Date getDataDeliveryDate() {
		return dataDeliveryDate;
	}

	public void setDataDeliveryDate(Date dataDeliveryDate) {
		this.dataDeliveryDate = dataDeliveryDate;
	}

	public Date getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(Date recordDate) {
		this.recordDate = recordDate;
	}

	public Date getAffirmDate() {
		return affirmDate;
	}

	public void setAffirmDate(Date affirmDate) {
		this.affirmDate = affirmDate;
	}

	public String getDomIntl() {
		return DomIntl;
	}

	public void setDomIntl(String domIntl) {
		DomIntl = domIntl;
	}

	public String getCptyType() {
		return cptyType;
	}

	public void setCptyType(String cptyType) {
		this.cptyType = cptyType;
	}

	public RegRepPrJobExecutionDetail getRegRepPrJobExecutionDetail() {
		return regRepPrJobExecutionDetail;
	}

	public void setRegRepPrJobExecutionDetail(
			RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
		this.regRepPrJobExecutionDetail = regRepPrJobExecutionDetail;
	}

	public Date getNextBusWorkingDate() {
		return nextBusWorkingDate;
	}

	public void setNextBusWorkingDate(Date nextBusWorkingDate) {
		this.nextBusWorkingDate = nextBusWorkingDate;
	}

	public int getCommoditySize() {
		return commoditySize;
	}

	public void setCommoditySize(int commoditySize) {
		this.commoditySize = commoditySize;
	}

	public int getCrSize() {
		return crSize;
	}

	public void setCrSize(int crSize) {
		this.crSize = crSize;
	}

	public int getIrSize() {
		return irSize;
	}

	public void setIrSize(int irSize) {
		this.irSize = irSize;
	}

	public int getEquitySize() {
		return equitySize;
	}

	public void setEquitySize(int equitySize) {
		this.equitySize = equitySize;
	}

	public int getFxSize() {
		return fxSize;
	}

	public void setFxSize(int fxSize) {
		this.fxSize = fxSize;
	}

	public int getFxIntlSize() {
		return fxIntlSize;
	}

	public void setFxIntlSize(int fxIntlSize) {
		this.fxIntlSize = fxIntlSize;
	}

	public String getFullLegalName() {
		return fullLegalName;
	}

	public void setFullLegalName(String fullLegalName) {
		this.fullLegalName = fullLegalName;
	}

	public String getLei() {
		return lei;
	}

	public void setLei(String lei) {
		this.lei = lei;
	}

	public Date getJobAsOfDate() {
		return jobAsOfDate;
	}

	public void setJobAsOfDate(Date jobAsOfDate) {
		this.jobAsOfDate = jobAsOfDate;
	}

	public boolean isFileExceptionFlag()
	{
		return fileExceptionFlag;
	}

	public void setFileExceptionFlag(boolean fileExceptionFlag)
	{
		this.fileExceptionFlag = fileExceptionFlag;
	}

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}
	
	
}
