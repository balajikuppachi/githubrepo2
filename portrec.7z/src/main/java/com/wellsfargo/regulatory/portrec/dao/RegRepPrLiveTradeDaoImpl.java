package com.wellsfargo.regulatory.portrec.dao;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dto.CptyLiveTrades;

/**
 * @author Raji Komatreddy
 */

public class RegRepPrLiveTradeDaoImpl
{

	@Autowired
	@Qualifier("portrecJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("sdrJdbcTemplate")
	private JdbcTemplate sdrJdbcTemplateForIpMsg;

	private DataSource dataSource;

	private LiveTradesFromSdrSP liveTradesFromSdrSP;

	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		liveTradesFromSdrSP = new LiveTradesFromSdrSP(dataSource);
	}

	String selectAllLiveTrades = "select lv.live_trades_id, lv.ba_id, lv.legal_id, lv.party1_lei, "
	               + "lv.party2_lei, lv.reportying_party from dbo.REG_REP_PR_LIVE_TRADES lv";	
	

	String selectSql = "select pr.legal_id , ciddata.cpty_type,pr.asset_class, count(*) as portfoliosize from  dbo.REG_REP_PR_LIVE_TRADES pr,"
	        + " (select distinct cid.lgle_id_c as legal_id,  case when (etSD_rates='Y' or" + " etSD_creditderivatives='Y' or etSD_equityderivatives = 'Y' or"
	        + " etSD_commodities = 'Y' or etSD_FX = 'Y' or regEntitySwapDealer='Y') then 'SD'" + "    else 'NON_SD_MSP'  end as cpty_type" + "   from dbo.REG_REP_PR_CID cid) ciddata"
	        + "  where pr.legal_id = ciddata.legal_id  and pr.recon_eligible = 'Y'"  
	        + " group by pr.legal_id, ciddata.cpty_type," + " pr.asset_class  order by pr.legal_id";

	/*
	 * String selectSql =
	 * "select pr.legal_id , ciddata.cpty_type, count(*) as portfoliosize from  dbo.REG_REP_PR_LIVE_TRADES pr,"
	 * + " (select distinct cid.lgle_id_c as legal_id,  case when (etSD_rates='Y' or" +
	 * " etSD_creditderivatives='Y' or etSD_equityderivatives = 'Y' or" +
	 * " etSD_commodities = 'Y' or etSD_FX = 'Y' or regEntitySwapDealer='Y') then 'SD'" +
	 * "    else 'NON_SD_MSP'  end as cpty_type" + "   from dbo.REG_REP_PR_CID cid) ciddata" +
	 * "  where pr.legal_id = ciddata.legal_id" + " group by pr.legal_id, ciddata.cpty_type";
	 */

	String insertSql = "INSERT INTO REG_REP_PR_LIVE_TRADES (job_execution_id,as_of_date,trade_id," + "asset_class,	ba_id,legal_id,ultimate_cpty_id,party1_lei,party2_lei,usi,uti)"
	        + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";

	String updateSql = "update REG_REP_PR_LIVE_TRADES set recon_eligible =?, " + "recon_cpty=?, recon_comment = ? where live_trades_id= ?";

	String deleteSql = "delete from REG_REP_PR_LIVE_TRADES";

	/*String selectBufferSql = "SELECT b.buffer_data, i.send_id, i.src_trade_id, " + "i.src_asset_class,i.src_cparty_name, t.party2_lei FROM input_msg_store i,"
	        + " temp_open_trade_details t, buffer_store b WHERE i.send_id = t.send_id " + "and i.buffer_id = b.buffer_id and t.bus_acc_id is null";*/
	
	String selectSendIdsFromTempOPenSql = "select  td.send_id from temp_open_trade_details td"; // where td.send_id = 793609
	
	String selectBufferSql = "SELECT bs.buffer_data,  ims.rep_party  , td.party1_lei,  td.party2_lei, ims.bus_acc_id,ims.send_id, ims.src_trade_id,"
			+ " ims.src_asset_class,ims.src_cparty_name FROM input_msg_store ims,"
			+ " temp_open_trade_details td, buffer_store bs  WHERE ims.send_id = td.send_id and ims.buffer_id = bs.buffer_id and td.send_id = ?";
	
	String selectLeiFromMappingBussAct = "select top 1  mbl.lei from mapping_bussaccid_lei mbl  where mbl.bus_acc_id = ?";
	
	String selectBaIdFromMappingBussAct = "select  top 1	mbl.bus_acc_id from mapping_bussaccid_lei mbl  where mbl.lei = ? ";
	
	String getAllLiveTradesSql = "select trade_id, asset_class, ba_id, legal_id, party1_lei, party2_lei, usi, recon_cpty  from REG_REP_PR_LIVE_TRADES where recon_eligible = 'Y'  ";
	
	Logger logger = Logger.getLogger(RegRepPrLiveTradeDaoImpl.class);

	public List<CptyLiveTrades> getAllCptyLiveTrades()
	{
		List<CptyLiveTrades> cptyLiveTradesList = new ArrayList<CptyLiveTrades>();

		try
		{
			
		
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectAllLiveTrades);

		for (Map<String, Object> row : rows)
		{
			CptyLiveTrades currCptyLiveTrades = new CptyLiveTrades();
			currCptyLiveTrades.setLiveTradesId((BigDecimal) row.get("live_trades_id"));
			currCptyLiveTrades.setBaId((Integer) row.get("ba_id"));
			currCptyLiveTrades.setCidCptyId((Integer) row.get("legal_id"));
			currCptyLiveTrades.setParty1Lei((String) row.get("party1_lei"));
			currCptyLiveTrades.setParty2Lei((String) row.get("party2_lei"));
			currCptyLiveTrades.setReportyingParty((String) row.get("reportying_party"));		
			cptyLiveTradesList.add(currCptyLiveTrades);
		}
		
		}
		catch(Exception ex)
		{
			logger.error("exception occurred while getting all liveTrade data");
			logger.error("exception details are " + ExceptionUtils.getFullStackTrace(ex));
		}

		return cptyLiveTradesList;
	}

	public List<CptyLiveTrades> getCptyLiveTrades()
	{
		List<CptyLiveTrades> cptyLiveTradesList = new ArrayList<CptyLiveTrades>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(selectSql);

		for (Map<String, Object> row : rows)
		{
			CptyLiveTrades currCptyLiveTrades = new CptyLiveTrades();
			currCptyLiveTrades.setCidCptyId((Integer) row.get("legal_id"));
			currCptyLiveTrades.setCptyType((String) row.get("cpty_type"));
			currCptyLiveTrades.setAssetClass((String) row.get("asset_class"));
			currCptyLiveTrades.setPortfolioSize((Integer) row.get("portfoliosize"));
			cptyLiveTradesList.add(currCptyLiveTrades);
		}

		return cptyLiveTradesList;
	}

	public int batchInsertPrLiveTrades(final List<CptyLiveTrades> cptyLiveTradesList) throws PortrecException
	{
		try
		{
			jdbcTemplate.batchUpdate(insertSql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{

					CptyLiveTrades currCptyLiveTrades = cptyLiveTradesList.get(i);
					ps.setLong(1, currCptyLiveTrades.getJobExecutionId());
					if (null != currCptyLiveTrades.getAsOfDate())
					{
						ps.setDate(2, (Date) new java.sql.Date(currCptyLiveTrades.getAsOfDate().getTime()));
					}
					else
					{
						ps.setDate(2, null);
					}

					ps.setString(3, currCptyLiveTrades.getTradeId());
					ps.setString(4, currCptyLiveTrades.getAssetClass());
					ps.setInt(5, currCptyLiveTrades.getBaId());
					ps.setInt(6, currCptyLiveTrades.getLegalId());
					ps.setInt(7, currCptyLiveTrades.getUltimateCptyId());
					ps.setString(8, currCptyLiveTrades.getParty1Lei());
					ps.setString(9, currCptyLiveTrades.getParty2Lei());
					ps.setString(10, currCptyLiveTrades.getUsi());
					ps.setString(11, currCptyLiveTrades.getUti());

				}

				@Override
				public int getBatchSize()
				{
					return cptyLiveTradesList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrLiveTradeDaoImpl :batchInsertPrLiveTrades method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrLiveTradeDaoImpl :batchInsertPrLiveTrades method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrLiveTradeDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);

		}

		logger.info("from batchInsertPortfolioSize : number of records inserted : " + cptyLiveTradesList.size());

		return cptyLiveTradesList.size();
	}

	public int batchUpdatePrLiveTrades(final List<CptyLiveTrades> cptyLiveTradesList) throws PortrecException
	{
		try
		{
			jdbcTemplate.batchUpdate(updateSql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{

					CptyLiveTrades currCptyLiveTrades = cptyLiveTradesList.get(i);

					ps.setString(1, currCptyLiveTrades.getReconEligible());
					ps.setString(2, currCptyLiveTrades.getReconCpty());
					ps.setString(3, currCptyLiveTrades.getReconComment());
					ps.setBigDecimal(4, currCptyLiveTrades.getLiveTradesId());

				}

				@Override
				public int getBatchSize()
				{
					return cptyLiveTradesList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrLiveTradeDaoImpl :batchUpdatePrLiveTrades method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrLiveTradeDaoImpl :batchUpdatePrLiveTrades method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrLiveTradeDaoImpl:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);

		}

		logger.info("from RegRepPrLiveTradeDaoImpl : number of records updated in LiveTrade table : " + cptyLiveTradesList.size());

		return cptyLiveTradesList.size();
	}

	public int deleteFromPrLiveTrades() throws PortrecException
	{
		int numRowsDeleted = 0;
		try
		{

			numRowsDeleted = jdbcTemplate.update(deleteSql);

			return numRowsDeleted;

		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrLiveTradeDaoImpl :deleteFromPrLiveTrades method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrLiveTradeDaoImpl :deleteFromPrLiveTrades method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrLiveTradeDaoImpl:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);

		}

	}

	public List<CptyLiveTrades> getLiveTradesFromSdr() throws PortrecException
	{
		String errorString = null;
		if (null == liveTradesFromSdrSP)
		{

			errorString = "Null liveTradesFromSdrSP from RegRepPrLiveTradeDaoImpl";
			logger.error("########## " + errorString);
			throw new PortrecException("RegRepPrLiveTradeDaoImpl-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

		}
		List<CptyLiveTrades> cptyLiveTradesList = new ArrayList<CptyLiveTrades>();
		cptyLiveTradesList = liveTradesFromSdrSP.getSdrLiveTrades();

		return cptyLiveTradesList;
	}

	// get all sends from temp-open_trade table
	public SqlRowSet getsendIdsFromTempOpen()
	{
		SqlRowSet results = sdrJdbcTemplateForIpMsg.queryForRowSet(selectSendIdsFromTempOPenSql);
		return results;
		
	}
	
	// returns inputmsg buffer for all reconrds which are having null ba_id in
	// temp_open_trade table
	public SqlRowSet getInputMsgBuffer(int sendId)
	{
		 Object[] parameters = new Object[] { new Integer(sendId) };

		SqlRowSet results = sdrJdbcTemplateForIpMsg.queryForRowSet(selectBufferSql , parameters);
		return results;
	}
	
	public String getLeiFromMappingBussinessLei(String bussAccId)
	{
		String lei = null;
		try
		{
			 lei = sdrJdbcTemplateForIpMsg.queryForObject(selectLeiFromMappingBussAct,  new Object[] { bussAccId }, String.class);
		}
		catch(Exception ex)
		{
			logger.error("No Lei found for bussiness Account Id " + bussAccId);
		}
		
		return lei;
	}
	
	public String getBaIdFromMappingBussinessLei(String lei)
	{
		String baId = null;
		try
		{
			baId = sdrJdbcTemplateForIpMsg.queryForObject(selectBaIdFromMappingBussAct,  new Object[] { lei }, String.class);
		}
		catch(Exception ex)
		{
			logger.error("No baId found for bussiness Account Id  for let " +lei );
		}
		
		return baId;
	}
	
	public List<CptyLiveTrades> getAllLiveTradesYIndicator(String assetClass){
		
		List<CptyLiveTrades> cptyLiveTradesList = new ArrayList<CptyLiveTrades>();
		
		try
		{
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(getAllLiveTradesSql);

		for (Map<String, Object> row : rows)
		{
			CptyLiveTrades currCptyLiveTrades = new CptyLiveTrades();
			currCptyLiveTrades.setLiveTradesId((BigDecimal) row.get("trade_id"));
			currCptyLiveTrades.setAssetClass((String) row.get("asset_class"));
			currCptyLiveTrades.setBaId((Integer) row.get("ba_id"));
			currCptyLiveTrades.setCidCptyId((Integer) row.get("legal_id"));
			currCptyLiveTrades.setParty1Lei((String) row.get("party1_lei"));
			currCptyLiveTrades.setParty2Lei((String) row.get("party2_lei"));
			currCptyLiveTrades.setUsi((String) row.get("usi"));		
			currCptyLiveTrades.setReconCpty((String) row.get("recon_cpty"));		
			cptyLiveTradesList.add(currCptyLiveTrades);
		}
		
		}
		catch(Exception ex)
		{
			logger.error("exception occurred while getting all liveTrade data");
			logger.error("exception details are " + ExceptionUtils.getFullStackTrace(ex));
		}

		return cptyLiveTradesList;
		
	}


	// internal class to execute stored procedure
	public class LiveTradesFromSdrSP extends StoredProcedure
	{
		private JdbcTemplate sdrJdbcTemplate;
		private String spName = "xyz";
		private String SDR_LIVE_DETAILS = "sdr_Live_Trade_Details";

		public LiveTradesFromSdrSP(DataSource dataSource)
		{
			sdrJdbcTemplate = new JdbcTemplate(dataSource);
			sdrJdbcTemplate.setSkipUndeclaredResults(true);
			super.setJdbcTemplate(sdrJdbcTemplate);
			super.setSql(spName);
			// declareParameter(new SqlParameter(AS_OF_DATE, Types.INTEGER)); declare input
			// parameters
			declareParameter(new SqlReturnResultSet(SDR_LIVE_DETAILS, new ResultSetExtractor<List<CptyLiveTrades>>()
			{

				@Override
				public List<CptyLiveTrades> extractData(ResultSet rs) throws SQLException, DataAccessException
				{
					List<CptyLiveTrades> currcptyLiveTradesList = new ArrayList<CptyLiveTrades>();
					while (rs.next())
					{
						CptyLiveTrades currCptyLiveTrades = new CptyLiveTrades();
						// currCptyLiveTrades.setJobExecutionId(rs.getLong(1));
						// currCptyLiveTrades.setAsOfDate(rs.getDate(2));
						currCptyLiveTrades.setTradeId(rs.getString(1));
						currCptyLiveTrades.setAssetClass(rs.getString(2));
						currCptyLiveTrades.setBaId(rs.getInt(3));
						// currCptyLiveTrades.setLegalId(rs.getInt(4));
						currCptyLiveTrades.setUltimateCptyId(rs.getInt(4));
						currCptyLiveTrades.setParty1Lei(rs.getString(5));
						currCptyLiveTrades.setParty2Lei(rs.getString(6));
						currCptyLiveTrades.setUsi(rs.getString(7));
						currCptyLiveTrades.setUti(rs.getString(8));
						currcptyLiveTradesList.add(currCptyLiveTrades);
					}

					return currcptyLiveTradesList;
				}
			}));
			compile();

		}

		@SuppressWarnings("unchecked")
		public List<CptyLiveTrades> getSdrLiveTrades() throws PortrecException
		{
			// Map<String, Integer> inParams = new HashMap<String, Integer>();
			// inParams.put(AS_OF_DATE, asOfDate);

			Map<String, Object> results = execute();
			List<CptyLiveTrades> cptyList = (List<CptyLiveTrades>) results.get(SDR_LIVE_DETAILS);
			return cptyList;

		}

	}

}
