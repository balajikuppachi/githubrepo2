package com.wellsfargo.regulatory.portrec.utils;

import com.wellsfargo.regulatory.portrec.service.PortrecReportDeliveryRequest;

public interface PortRecReportDeliveryRequestSubmitterService {
	public void submit(PortrecReportDeliveryRequest repDelivReq);

}
