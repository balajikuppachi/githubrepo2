package com.wellsfargo.regulatory.portrec.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_JOB_EXECUTION_DETAILS database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_JOB_EXECUTION_DETAILS")
public class RegRepPrJobExecutionDetail
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "job_execution_id")
	private Long jobExecutionId;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "create_datetime")
	private Date createDatetime;

	@Column(name = "file_name")
	private String fileName;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "job_details_id", nullable = false)
	private RegRepPrJobDetail jobDetailsId;

	@Column(name = "job_status")
	private String jobStatus;

	@Column(name = "records_loaded")
	private int recodsLoaded;

	@Column(name = "records_total")
	private int recordsTotal;

	@Column(name = "update_datetime")
	private Date updateDatetime;

	public RegRepPrJobExecutionDetail()
	{
	}

	public Long getJobExecutionId()
	{
		return this.jobExecutionId;
	}

	public void setJobExecutionId(Long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public Date getCreateDatetime()
	{
		return this.createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

	public String getFileName()
	{
		return this.fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public RegRepPrJobDetail getJobDetailsId()
	{
		return this.jobDetailsId;
	}

	public void setJobDetailsId(RegRepPrJobDetail jobDetailsId)
	{
		this.jobDetailsId = jobDetailsId;
	}

	public String getJobStatus()
	{
		return this.jobStatus;
	}

	public void setJobStatus(String jobStatus)
	{
		this.jobStatus = jobStatus;
	}

	public int getRecodsLoaded()
	{
		return this.recodsLoaded;
	}

	public void setRecodsLoaded(int recodsLoaded)
	{
		this.recodsLoaded = recodsLoaded;
	}

	public int getRecordsTotal()
	{
		return this.recordsTotal;
	}

	public void setRecordsTotal(int recordsTotal)
	{
		this.recordsTotal = recordsTotal;
	}

	public Date getUpdateDatetime()
	{
		return this.updateDatetime;
	}

	public void setUpdateDatetime(Date updateDatetime)
	{
		this.updateDatetime = updateDatetime;
	}

}