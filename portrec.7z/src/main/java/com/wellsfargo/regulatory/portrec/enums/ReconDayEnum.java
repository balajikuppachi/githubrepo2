package com.wellsfargo.regulatory.portrec.enums;

/**
 * @author Raji Komatreddy
 */

public enum ReconDayEnum
{

	WEEKDAY("WEEKDAY"), WEEKEND("WEEKEND"), QUARTEREND("QUARTEREND"), YEAREND("YEAREND"),HOLIDAY("HOLIDAY");

	private final String value;

	public String type()
	{

		return toString();
	}

	public String getValue()
	{

		return toString();
	}

	ReconDayEnum(String v)
	{

		value = v;
	}

	public static ReconDayEnum fromValue(String v)
	{

		for (ReconDayEnum c : ReconDayEnum.values())
		{

			if (c.value.equals(v))
			{
				return c;
			}
		}

		throw new IllegalArgumentException(v);
	}
}
