package com.wellsfargo.regulatory.portrec.service;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.ChannelInterceptorAdapter;
import org.springframework.stereotype.Component;

@Component
public class PortrecSftpLoggingInterceptor extends ChannelInterceptorAdapter {
	
	private final Logger logger = Logger.getLogger(PortrecSftpLoggingInterceptor.class);

	
	@Override
	public void postSend(Message<?> message, MessageChannel channel,
			boolean sent) {

		File f = (File) message.getPayload();
		if (sent) {
			logger.info(f.getName()+" : File has been delivered: " + message.getPayload());
		} else {
			logger.warn(f.getName()+" : File has NOT been delivered: " + message.getPayload());
		}
		
		
	}
}
