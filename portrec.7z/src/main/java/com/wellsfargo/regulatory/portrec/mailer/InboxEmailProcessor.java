package com.wellsfargo.regulatory.portrec.mailer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import microsoft.exchange.webservices.data.BasePropertySet;
import microsoft.exchange.webservices.data.EmailMessageSchema;
import microsoft.exchange.webservices.data.ExchangeCredentials;
import microsoft.exchange.webservices.data.ExchangeService;
import microsoft.exchange.webservices.data.ExchangeVersion;
import microsoft.exchange.webservices.data.FindItemsResults;
import microsoft.exchange.webservices.data.FolderId;
import microsoft.exchange.webservices.data.Item;
import microsoft.exchange.webservices.data.ItemView;
import microsoft.exchange.webservices.data.LogicalOperator;
import microsoft.exchange.webservices.data.Mailbox;
import microsoft.exchange.webservices.data.PropertySet;
import microsoft.exchange.webservices.data.SearchFilter;
import microsoft.exchange.webservices.data.ServiceResponseException;
import microsoft.exchange.webservices.data.WebCredentials;
import microsoft.exchange.webservices.data.WellKnownFolderName;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;

@Component
@ManagedResource(description="Inbox Read")
public class InboxEmailProcessor {
	
	@Value("${mail.userid.portrec}")	String userId;
	@Value("${mail.password.portrec}")	String passwd;
	@Value("${mail.domain.portrec}")	String domain;
	@Value("${mail.uri.portrec}")		String uri;
	@Value("${mail.server.email.address}")  String serverEmailAddress;
	@Value("${mail.subject.search.text}")	String emailSubject;
	@Value("${mail.subject.search.asOfDate}")	String emailAsOfDate;
	@Value("${file.mis.outputFolder}")	String outputFolder;
	
	@Autowired
	SecureDBPwdFactory secureDBPwdFactory;
	
	Logger logger = Logger.getLogger(PrEmailSenderService.class);
	
	private ExchangeService getExchangeService() {
		logger.info("Connecting Exchange Server... ");
    	
    	ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
    	String decryptedPassword = secureDBPwdFactory.getPassword(passwd.trim());
		ExchangeCredentials credentials = new WebCredentials(userId.trim(), decryptedPassword, domain.trim());
		service.setCredentials(credentials);
    	
		logger.info("Exchange Connected..");
		
		try 
		{
			service.setUrl(new URI(uri));
		} 
		catch (URISyntaxException e) 
		{
			throw new RuntimeException(e);
		} 
		catch (Exception e) 
		{
			throw new RuntimeException(e);
		}
		
		return service;
	}
	
	/**
	 * @param service
	 * @return
	 * @throws ServiceResponseException
	 * @throws Exception
	 */
	@ManagedOperation(description="Inbox reading")
	public void searchEmailAndCreateReport() {
		ExchangeService service = getExchangeService();
		if (service == null) {
			throw new RuntimeException("ExchangeService can not be null");
		}
		try 
		{
			Mailbox mb = new Mailbox();
			mb.setAddress(serverEmailAddress);
			FolderId folderId = new FolderId(WellKnownFolderName.Inbox, mb);
			//Undeliverable
			//Delivery delayed
			SearchFilter itemFilter = new SearchFilter.SearchFilterCollection(LogicalOperator.And, new SearchFilter.ContainsSubstring(EmailMessageSchema.Subject, emailSubject), 
					new SearchFilter.ContainsSubstring(EmailMessageSchema.Subject, emailAsOfDate));
			
			FindItemsResults<Item> findResults = service.findItems(folderId, itemFilter, new ItemView(Integer.MAX_VALUE));
			
			//FindItemsResults<Item> findResults = service.findItems(folderId, new ItemView(Integer.MAX_VALUE));
			
			if(null != findResults && null != findResults.getItems() && !findResults.getItems().isEmpty()){
				service.loadPropertiesForItems(findResults, new PropertySet(BasePropertySet.FirstClassProperties));
				
				logger.info("Number of emails retrieved from Inbox : "+findResults.getTotalCount());
				
				List<String> emailTokens = new ArrayList<String>();
				
				for (Item item : findResults.getItems()) {			
					String subject = item.getSubject();
					//System.out.println("Subject :  "+ subject);
					
					String legalName = null;
					
					if(null != subject){
						String[] subArr = subject.split(":");
						
						if(null != subArr && subArr.length > 1)
						{
							String[] subArr2 = subArr[1].split("\\|");
							
							if(null != subArr2 && subArr2.length > 2)
							{
								legalName = subArr2[0];
							}
						}
						
					}				

					String toEmailAddress = item.getDisplayTo();
					logger.info("Legal Name : " + legalName +  " == > Email Address :  "+ toEmailAddress);
					
					emailTokens.add(legalName+":"+toEmailAddress);
				}	
				
				generateExcel(emailTokens);
			}
			else{
				logger.info("No Emails matched the provided search criteria");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	private void generateExcel(List<String> emailTokens) throws FileNotFoundException {
		
		logger.info("Start generating report...");
		
		try {
			File file = new File(outputFolder + File.separator + "LegalNamesWithToEmailAddresses.xls");
			
			FileOutputStream fileOut = new FileOutputStream(file);
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet worksheet = workbook.createSheet("Report");

			int row = 0;
			
			for(String token : emailTokens){
				
				String[] strArr = token.split(":");
				
				String legalName = null;
				String emailAddress = null;
				
				if(null != strArr && strArr.length > 1)
				{
					legalName = strArr[0];
					emailAddress = strArr[1];
				}
				
				Row row1 = worksheet.createRow((short) row);

				int col = 0;
				
				Cell cellA1 = row1.createCell((short) col);
				cellA1.setCellValue(null != legalName ? legalName : "");
				CellStyle cellStyle = workbook.createCellStyle();
				cellStyle.setFillForegroundColor(HSSFColor.GOLD.index);
				cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				cellA1.setCellStyle(cellStyle);

				col ++ ;
				
				Cell cellB1 = row1.createCell((short) col);
				cellB1.setCellValue(null != emailAddress ? emailAddress : "");
				cellStyle = workbook.createCellStyle();
				cellStyle.setFillForegroundColor(HSSFColor.LIGHT_CORNFLOWER_BLUE.index);
				cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				cellB1.setCellStyle(cellStyle);
				
				row ++;
			}
			
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
			
			logger.info("Report generated " + file.getCanonicalPath());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		logger.info("End generating report...");
		
	}
	
	
	
}
