package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrDtccCRCSVReader extends LoaderHelper<RegRepPrCrPositionReport> {
	Logger logger = Logger.getLogger(getClass());
	public static String PORTFOLIO_SEGMENT_NAME = "Credit, DTCC";
	@Value("${file.dtcccr.epr.header}") int headerRows;	
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.CR;
	}

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new CsvWithHeaderReader(inputStream, headerRows);
	}

	@Override
	public RegRepPrCrPositionReport parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrCrPositionReport crTrade = new RegRepPrCrPositionReport();
		crTrade.setUsiPrefix(fields[0]);
		crTrade.setUsi(fields[0]+fields[1]); 
		
		crTrade.setPrimaryAssetClass(fields[2]);
		crTrade.setSecondaryAssetClass(fields[50]);
		String[] tradeParty  = tradeParty(fields,exclude);
		crTrade.setTradeParty1(tradeParty[0]);
		crTrade.setTradeParty2(tradeParty[1]);
		crTrade.setUnderlyingAsset(fields[22]);
		crTrade.setTradeParty1Role(fields[3]);
		crTrade.setTradeParty2Role(fields[5]);
		crTrade.setTradeParty1FinancialEntity(fields[163]);
		crTrade.setTradeParty2FinancialEntity(fields[164]);
		crTrade.setTradeParty1UspersonIndicator(fields[165]);
		crTrade.setTradeParty2UspersonIndicator(fields[166]);
		crTrade.setProductTypePrefix(fields[7]);
		crTrade.setProductType(fields[8]);
		if (StringUtils.isNotBlank(fields[89]))
			crTrade.setTradeDate(DateUtilLoader.getDateFromString(fields[89]));
		if (StringUtils.isNotBlank(fields[9]))
			crTrade.setExecutionDate(DateUtilLoader.getDateTimeStampFromStrCR(fields[9]));
		crTrade.setExecutionVenuePrefix(fields[10]);
		crTrade.setReferenceEntity(fields[23]);
		crTrade.setOptionStrikePrice(fields[29]);
		crTrade.setBuyer(fields[36]);
		String buyer = "";
		String seller="";
		if(StringUtils.isNotBlank(fields[36])){
			buyer = fields[36];
			if(StringUtils.equalsIgnoreCase(buyer,"DTCC-00006192") || buyer.contains("KB1H1DSPRFMYMCUFXT09")){
				if(StringUtils.equalsIgnoreCase(tradeParty[0],"KB1H1DSPRFMYMCUFXT09")){
					seller=tradeParty[1];
				}else{
					seller=tradeParty[0];
				}
			}else{
				if(StringUtils.equalsIgnoreCase(tradeParty[0],"KB1H1DSPRFMYMCUFXT09")){
					seller=tradeParty[0];
				}else{
					seller=tradeParty[1];
				}
			}
		}
		crTrade.setBuyer(buyer);		
		crTrade.setSeller(seller); // Counterparty who is not 'Buyer' is Seller.
		crTrade.setMandatoryClearingIndicator(fields[37]);
		crTrade.setTraderLocationParty1(fields[66]);
		crTrade.setTraderLocationParty2(fields[67]);
		crTrade.setAllocationIndicator(fields[72]);
		crTrade.setAdditionalRepository1Lei(fields[75]);
		crTrade.setExecutionVenue(fields[11]);
		if (StringUtils.isNotBlank(fields[16]))
			crTrade.setEffectiveDate(DateUtilLoader.getDateFromString(fields[16]));
		if (StringUtils.isNotBlank(fields[17]))
			crTrade.setScheduledTerminationDate(DateUtilLoader.getDateFromString(fields[17]));
		if (StringUtils.isNotBlank(fields[170]))
			crTrade.setFixedRatePerAnnum(stringToBigDecimal(fields[170])); 
		if (StringUtils.isNotBlank(fields[175]))
			crTrade.setNotionalAmount1(convertStrToBigDecimalForNotionalAmt(fields[175]));
		crTrade.setNotionalCurrency1(fields[153]);
		if (StringUtils.isNotBlank(fields[154]))
			crTrade.setDisputedNotionalAmount1(convertStrToBigDecimalForNotionalAmt(fields[154]));
		crTrade.setDisputedNotionalCurrency1(fields[155]);
		if (StringUtils.isNotBlank(fields[96]))
			crTrade.setSinglePaymentAmount(convertStrToBigDecimalForNotionalAmt(fields[96]));
		crTrade.setSinglePaymentCurrency(fields[97]);
		if (StringUtils.isNotBlank(fields[101]))
			crTrade.setInitialPaymentAmount(convertStrToBigDecimalForNotionalAmt(fields[101]));
		crTrade.setInitialPaymentCurrency(fields[102]);
		crTrade.setPaymentFrequencyPeriod1(fields[24]);
		crTrade.setPaymentFrequencyPeriodMultiplier1(fields[25]);
		crTrade.setCollateralized(fields[38]);
		crTrade.setTradeParty1Lei(fields[160]);
		crTrade.setTradeParty2Lei(fields[161]);
		crTrade.setReportingParty(fields[158]);
		crTrade.setSubmittedFor(fields[176]);
		crTrade.setReportingJurisdiction(fields[40]);
		crTrade.setAsOfDate(asofDate);
		return crTrade;
	}

	@Override
	public boolean validate(RegRepPrCrPositionReport trade) {
		boolean canLoad = false;
		String repJur = trade.getReportingJurisdiction();
		if(repJur.contains("CFTC") || repJur.isEmpty() || (repJur==null)){
			canLoad = true;
		}	
		
		return canLoad;
	}
	
	private String[] tradeParty(String[] fields, String[] exclude) {
		String[] tradeParty = new String[2];
		String tradeParty1 = "";
		String tradeParty2 = "";
		if(StringUtils.isNotEmpty(fields[160])){
			tradeParty1 = fields[160];			
		}else{
			tradeParty1 = fields[4];						
		}
		if(StringUtils.isNotEmpty(fields[161])){
			tradeParty2 = fields[161];			
		}else{
			tradeParty2 = fields[6];						
		}
		if (tradeParty1.contains("%"))tradeParty1=tradeParty1.replace("%", "");
		if (tradeParty2.contains("%")) tradeParty2 = tradeParty2.replace("%", "");
		
		for (String s : exclude){
			if (tradeParty1.contains(s)) tradeParty1 = tradeParty1.replace(s, "");
			if (tradeParty2.contains(s)) tradeParty2 = tradeParty2.replace(s, "");
			}
		
		tradeParty[0] = tradeParty1;
		tradeParty[1] = tradeParty2;
		return tradeParty;
	}

	@Override
	public RegRepPrCrPositionReport getTableName() {
			return new RegRepPrCrPositionReport();
	}

	@Override
	public boolean deletePrevDayRecords() {
		return false;
	}

	@Override
	public String loadNextJob() {
		// TODO Auto-generated method stub
		return null;
	}

}
