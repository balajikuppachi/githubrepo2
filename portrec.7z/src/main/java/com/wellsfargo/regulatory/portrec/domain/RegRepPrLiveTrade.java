package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_LIVE_TRADES database table.
 */
@Entity
@Table(name = "REG_REP_PR_LIVE_TRADES")
public class RegRepPrLiveTrade extends RegRepPrJob
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "live_trades_id")
	private long liveTradesId;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "asset_class")
	private String assetClass;

	@Column(name = "ba_id")
	private int baId;

	@Column(name = "legal_id")
	private int legalId;

	@Column(name = "party1_lei")
	private String party1Lei;

	@Column(name = "party2_lei")
	private String party2Lei;

	@Column(name = "trade_id")
	private String tradeId;

	@Column(name = "ultimate_cpty_id")
	private int ultimateCptyId;

	private String usi;

	private String uti;

	@Column(name = "recon_eligible")
	private String reconEligible;

	@Column(name = "reportying_party")
	private String reportyingParty;

	@Column(name = "recon_cpty")
	private String reconCpty;

	@Column(name = "recon_comment")
	private String reconComment;

	public RegRepPrLiveTrade()
	{
	}

	public long getLiveTradesId()
	{
		return this.liveTradesId;
	}

	public void setLiveTradesId(long liveTradesId)
	{
		this.liveTradesId = liveTradesId;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getAssetClass()
	{
		return this.assetClass;
	}

	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}

	public int getBaId()
	{
		return this.baId;
	}

	public void setBaId(int baId)
	{
		this.baId = baId;
	}

	public int getLegalId()
	{
		return this.legalId;
	}

	public void setLegalId(int legalId)
	{
		this.legalId = legalId;
	}

	public String getParty1Lei()
	{
		return this.party1Lei;
	}

	public void setParty1Lei(String party1Lei)
	{
		this.party1Lei = party1Lei;
	}

	public String getParty2Lei()
	{
		return this.party2Lei;
	}

	public void setParty2Lei(String party2Lei)
	{
		this.party2Lei = party2Lei;
	}

	public String getTradeId()
	{
		return this.tradeId;
	}

	public void setTradeId(String tradeId)
	{
		this.tradeId = tradeId;
	}

	public int getUltimateCptyId()
	{
		return this.ultimateCptyId;
	}

	public void setUltimateCptyId(int ultimateCptyId)
	{
		this.ultimateCptyId = ultimateCptyId;
	}

	public String getUsi()
	{
		return this.usi;
	}

	public void setUsi(String usi)
	{
		this.usi = usi;
	}

	public String getUti()
	{
		return this.uti;
	}

	public void setUti(String uti)
	{
		this.uti = uti;
	}

	public String getReconEligible()
	{
		return reconEligible;
	}

	public void setReconEligible(String reconEligible)
	{
		this.reconEligible = reconEligible;
	}

	public String getReportyingParty()
	{
		return reportyingParty;
	}

	public void setReportyingParty(String reportyingParty)
	{
		this.reportyingParty = reportyingParty;
	}

	public String getReconCpty()
	{
		return reconCpty;
	}

	public void setReconCpty(String reconCpty)
	{
		this.reconCpty = reconCpty;
	}

	public String getReconComment()
	{
		return reconComment;
	}

	public void setReconComment(String reconComment)
	{
		this.reconComment = reconComment;
	}

}