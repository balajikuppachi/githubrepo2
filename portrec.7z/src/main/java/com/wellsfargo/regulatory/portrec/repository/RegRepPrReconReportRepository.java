package com.wellsfargo.regulatory.portrec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconReport;

@Repository
public interface RegRepPrReconReportRepository extends
		CrudRepository<RegRepPrReconReport, Long> {

	@Query("select pr from RegRepPrReconReport pr where pr.commType='DUC' and pr.domInt1='D' and pr.regRepPrJobExecutionDetail = ?1")
	public List<RegRepPrReconReport> findByDomesticType(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);

	@Query("select pr from RegRepPrReconReport pr where pr.commType='DUC' and pr.domInt1='I' and pr.regRepPrJobExecutionDetail = ?1")
	public List<RegRepPrReconReport> findByInternationalType(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	@Query("select pr from RegRepPrReconReport pr where pr.commType='EMAIL' and pr.regRepPrJobExecutionDetail = ?1")
	public List<RegRepPrReconReport> findByPrevMailingJobExecution(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
}
