package com.wellsfargo.regulatory.portrec.utils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.portrec.mailer.PrExtractsTo;
import com.wellsfargo.regulatory.portrec.reports.CmCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.CrCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.EqCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.FxCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.reports.IrCptyCsvGenerator;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;

@Service
@ManagedResource(description="Generating Val Files")
public class GenerateMTBasedOnLegalID {

	private static Logger logger = Logger.getLogger(GenerateMTBasedOnLegalID.class);

	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRep;
	
	@Autowired
	IrCptyCsvGenerator iRCptyCsvGenerator;
	
	@Autowired
	CrCptyCsvGenerator cRCptyCsvGenerator;
	
	@Autowired
	FxCptyCsvGenerator fxCptyCsvGenerator;
	
	@Autowired
	EqCptyCsvGenerator eQCptyCsvGenerator;
		
	@Autowired
	CmCptyCsvGenerator cmCptyCsvGenerator;
		
	
	@ManagedOperation(description="Generate")
	public void generateMTFiles(String legals, String mtDate, String frequency,String assetClass) throws IOException{
		
		String[] legalIDs = legals.split(",");
		
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		Date asOfDate = null;
		int MtCount = 0;
		
		if (null != legalIDs && null != mtDate && null != frequency && null != assetClass ){
		
		logger.info("Generating MT files for " + legalIDs.length +  " Legal ID's ");	
			
		try {
			asOfDate = format.parse(mtDate);
		} catch (ParseException e) {
			logger.error("Error Parsing the date ");
			e.printStackTrace();
		}
		
		for (String legal :legalIDs ){
			int legalId = Integer.parseInt(legal);
			List<String> counterPartyLeiList = regRepPrLiveTradeRep.findReconCptyByLegalId(legalId);
			
			Long legalid = Long.valueOf(legalId);
			if(assetClass.equalsIgnoreCase("InterestRate") || assetClass.equalsIgnoreCase("ALL")){
				try{
					PrExtractsTo irExTo = iRCptyCsvGenerator.createFile(counterPartyLeiList,legalid, asOfDate, frequency);
					MtCount = MtCount + irExTo.getIrCount();
					logger.info("Number of Positions in Material Term for " + legalId + " and Asset Class : InterestRate, are : " + MtCount);
				}
				catch(Exception ce){
					logger.error("Error Creating file for " + legalId);				
					}
				}
			if(assetClass.equalsIgnoreCase("Credit")  || assetClass.equalsIgnoreCase("ALL") ){
				try{
					PrExtractsTo crExTo = cRCptyCsvGenerator.createFile(counterPartyLeiList,legalid, asOfDate, frequency);
					MtCount = MtCount + crExTo.getCrCount();
					logger.info("Number of Positions in Material Term for " + legalId + " and Asset Class : Credit, are : " + MtCount);
				}
				catch(Exception ce){
					logger.error("Error Creating file for " + legalId);				
					}
				}
			if(assetClass.equalsIgnoreCase("Equity")  || assetClass.equalsIgnoreCase("ALL")){
				try{
					PrExtractsTo eqExTo = eQCptyCsvGenerator.createFile(counterPartyLeiList,legalid, asOfDate, frequency);
					MtCount = MtCount + eqExTo.getEqCount();
					logger.info("Number of Positions in Material Term for " + legalId + " and Asset Class : Equity, are : " + MtCount);
				}
				catch(Exception ce){
					logger.error("Error Creating file for " + legalId);				
					}
				}
			if(assetClass.equalsIgnoreCase("ForeignExchange")  || assetClass.equalsIgnoreCase("ALL")){
				try{
					PrExtractsTo fxExTo = fxCptyCsvGenerator.createFile(counterPartyLeiList,legalid, asOfDate, frequency);
					MtCount = MtCount + fxExTo.getFxCount();
					logger.info("Number of Positions in Material Term for " + legalId + " and Asset Class : ForeignExchange, are : " + MtCount);
				}
				catch(Exception ce){
					logger.error("Error Creating file for " + legalId);				
					}
				}
						
			if(assetClass.equalsIgnoreCase("Commodity")  || assetClass.equalsIgnoreCase("ALL")){
			try{
				PrExtractsTo cmExTo = cmCptyCsvGenerator.createFile(counterPartyLeiList,legalid, asOfDate, frequency);
				MtCount = MtCount + cmExTo.getComCount();
				logger.info("Number of Positions in Material Term for " + legalId + " and Asset Class : Commodity, are : " + MtCount);
			}
			catch(Exception ce){
				logger.error("Error Creating file for " + legalId);				
				}
			}
			
	
			}
		}
	}
}
