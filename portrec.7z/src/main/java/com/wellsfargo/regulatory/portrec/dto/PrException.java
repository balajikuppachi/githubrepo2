package com.wellsfargo.regulatory.portrec.dto;

import java.util.Date;

/**
 * @author Raji Komatreddy
 */
public class PrException
{
	private Long exceptionId;
	private long jobExecutionId;
	private String exceptionType;
	private String exceptionSource;
	private String exceptionDesc;
	private String exceptionTrace;
	private Long cidCptyId;
	private Date createDatetime;

	public Long getExceptionId()
	{
		return exceptionId;
	}

	public void setExceptionId(Long exceptionId)
	{
		this.exceptionId = exceptionId;
	}

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public String getExceptionType()
	{
		return exceptionType;
	}

	public void setExceptionType(String exceptionType)
	{
		this.exceptionType = exceptionType;
	}

	public String getExceptionSource()
	{
		return exceptionSource;
	}

	public void setExceptionSource(String exceptionSource)
	{
		this.exceptionSource = exceptionSource;
	}

	public String getExceptionDesc()
	{
		return exceptionDesc;
	}

	public void setExceptionDesc(String exceptionDesc)
	{
		this.exceptionDesc = exceptionDesc;
	}

	public String getExceptionTrace()
	{
		return exceptionTrace;
	}

	public void setExceptionTrace(String exceptionTrace)
	{
		this.exceptionTrace = exceptionTrace;
	}

	public Long getCidCptyId()
	{
		return cidCptyId;
	}

	public void setCidCptyId(Long cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public Date getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

}
