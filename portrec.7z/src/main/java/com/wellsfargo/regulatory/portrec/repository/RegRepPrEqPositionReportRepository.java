package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrEqPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
/**
 * 
 * @author Raji Komatreddy
 *Repository to save or get data from RegRepPrEqPositionReport table  
 */
public interface RegRepPrEqPositionReportRepository extends CrudRepository<RegRepPrEqPositionReport, Long>
{

	@Query("select eq from RegRepPrEqPositionReport eq where eq.asOfDate=?1 and (eq.party1=?2 or eq.party2=?3) ")
	public List<RegRepPrEqPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);
	
	/*@Query("select eq from RegRepPrEqPositionReport eq where eq.asOfDate=?1 and (eq.party1 LIKE %?2 or eq.party2 LIKE %?3) ")
	public List<RegRepPrEqPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);*/
	
	@Query("select eq.usi from RegRepPrEqPositionReport eq where eq.usi!='' and eq.regRepPrJobExecutionDetail=?")
	List<String> findUsiEq(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);

	@Query("select eq from RegRepPrEqPositionReport eq where eq.regRepPrJobExecutionDetail=?")
	public List<RegRepPrEqPositionReport> findPositionsByDate(RegRepPrJobExecutionDetail jobDetail);
}
