package com.wellsfargo.regulatory.portrec.repository;

import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrDaAffirmLog;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public interface RegRepPrDaAffirmLogRepository extends CrudRepository<RegRepPrDaAffirmLog, Long>
{

	
}

