package com.wellsfargo.regulatory.portrec.domain;

public enum TradeRecordTypeEnum {
	
	IR("InterestRate"), CR("Credit"), FX("ForeignExchange"), COM_DTCC("Commodity"), EQ_VS("Equity_VS"), VA_CDBO("VA_CDBO"), VA_ALGO("VA_ALGO"), EQ_CFD("Equity_CFD"),
	EQ_DS("Equity_DS"), EQ_ES("Equity_ES"), EQ_SP("Equity_SP"),COM_ICE("ICE"),LIVE_TRADE("LIVE_TRADES"), FX_LIVE_TRADE("FX_LIVE_TRADES"), ALGO_LOAD("ALGO_FILE_LOAD"), EQ_OPT("Equity_OPT"),
	EQ_PO("Equity_PO"),EQ_FWD("Equity_FWD");

	final String recordType;

	private TradeRecordTypeEnum(String recordType) {
		this.recordType = recordType;
	}

	public String getRecordType() {
		return recordType;
	}

	public static TradeRecordTypeEnum getRecordType(String recordType) {
		for (TradeRecordTypeEnum value : TradeRecordTypeEnum.values()) {
			if (value.getRecordType() == recordType) {
				return value;
			}
		}

		throw new IllegalArgumentException("Unknown record type :" + recordType);
	}
}
