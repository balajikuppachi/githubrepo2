package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrFxPositionReport;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrDtccFXCSVReader extends LoaderHelper<RegRepPrFxPositionReport> {
	Logger logger = Logger.getLogger(getClass());
	public static String PORTFOLIO_SEGMENT_NAME = "ForeignExchange, DTCC";
	@Value("${file.dtcceqes.epr.header}") int headerRows;	
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.FX;
	}

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new CsvWithHeaderReader(inputStream, headerRows);
	}

	@Override
	public RegRepPrFxPositionReport parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrFxPositionReport fxTradeDTCC = new RegRepPrFxPositionReport();
		
		fxTradeDTCC.setUsiPrefix(fields[10]);
		fxTradeDTCC.setUsiValue(fields[11]);
		
		String tradeParty1lei = fields[169];
		String tradeParty2lei = fields[170];
		String tradeparty1 = fields[29];
		
		for (String s : exclude){
			if (tradeParty1lei.contains(s)) tradeParty1lei = tradeParty1lei.replace(s, "");
			if (tradeparty1.contains(s)) tradeparty1 = tradeparty1.replace(s, "");
			}
		
		// TRADE PARTY 1 VALUE. If TRADE PARTY 1 PREFIX is not CICI,DTCC or IF TRADE PARTY 1 VALUE is blank, use TRADE_PARTY1_LEI
		if(!StringUtils.equalsIgnoreCase(fields[28], "CICI") || !StringUtils.equalsIgnoreCase(fields[28], "DTCC") || StringUtils.isBlank(fields[29]) )
			fxTradeDTCC.setTradeParty1(tradeParty1lei);
		else
			fxTradeDTCC.setTradeParty1(tradeparty1);
		
		// TRADE PARTY 2 VALUE. If TRADE PARTY 2 PREFIX is not CICI,LEI or IF TRADE PARTY 2 VALUE is blank, use TRADE_PARTY2_LEI
		/*if(!StringUtils.equalsIgnoreCase(fields[37], "CICI") || !StringUtils.equalsIgnoreCase(fields[37], "LEI") || StringUtils.isBlank(fields[38]) )
			fxTradeDTCC.setTradeParty2(tradeParty2lei);
		else*/
		//TODO
		String tradeParty2 = fields[38];
		for (String s : exclude){
			if (tradeParty2.contains(s)) tradeParty2 = tradeParty2.replace(s, "");
			}
		fxTradeDTCC.setTradeParty2(tradeParty2);
		
		// TRADE PARTY 2 VALUE(Populate only if TRADE PARTY 2 VALUE, TRADE_PARTY2_LEI above is blank)
		fxTradeDTCC.setParty2InternalId("");
		
		fxTradeDTCC.setTradeParty1Role(fields[27]);		
		fxTradeDTCC.setTradeParty2Role(fields[36]);
		

		if(StringUtils.equalsIgnoreCase("SD", fields[27])) 
			fxTradeDTCC.setIsParty1Sd("YES");
		else if(StringUtils.equalsIgnoreCase("MSP", fields[27]))
			fxTradeDTCC.setIsParty1Msp("YES");
	
		if(StringUtils.equalsIgnoreCase("SD", fields[36])) 
			fxTradeDTCC.setIsParty2Sd("YES");
		else if(StringUtils.equalsIgnoreCase("MSP", fields[36]))
			fxTradeDTCC.setIsParty2Msp("YES");
		
		
		fxTradeDTCC.setIsParty1Fin(setVal(fields[174]));
		fxTradeDTCC.setIsParty2Fin(setVal(fields[175]));
		fxTradeDTCC.setIsParty1UsPerson(setVal(fields[172]));
		fxTradeDTCC.setIsParty2UsPerson(setVal(fields[173]));
		
		if(StringUtils.isNotBlank(fields[12]) && StringUtils.isNotBlank(fields[13]))
			fxTradeDTCC.setIsMultiassetSwap("YES");
		else
			fxTradeDTCC.setIsMultiassetSwap("NO");
		
		//If �REPORTING JURISDICTION� contains CFTC & SEC(separated by ;), then Mixed Swap = Y, else populate blanks.
		if(StringUtils.isNotBlank(fields[91]) && StringUtils.contains(fields[91],"CFTC;SEC"))
			fxTradeDTCC.setIsMixedSwap("Y");
		else
			fxTradeDTCC.setIsMixedSwap("");
		
		//SETTLEMENT FIXING DATE. If its blank EXPIRATION DATE. If both are blank EXOTIC EXPIRATION DATE.
		if (StringUtils.isNotBlank(fields[148]))
			fxTradeDTCC.setSettlementFixingDate(DateUtilLoader.getDateFromString(fields[148]));
		else if (StringUtils.isNotBlank(fields[132]))
			fxTradeDTCC.setSettlementFixingDate(DateUtilLoader.getDateFromString(fields[132]));
		else if(StringUtils.isNotBlank(fields[161]))
			fxTradeDTCC.setSettlementFixingDate(DateUtilLoader.getDateFromString(fields[161]));
		fxTradeDTCC.setSubmittedFor(fields[48]);
		fxTradeDTCC.setSubmissionTimestamp(fields[0]);
		fxTradeDTCC.setPrimaryAssetClass(fields[12]);
		fxTradeDTCC.setReportingParty(fields[11]);
		fxTradeDTCC.setSystemDerivedReportingParty(fields[4]);
		fxTradeDTCC.setSecondaryAssetClass(fields[13]);
		fxTradeDTCC.setMandatoryClearingIndicator(fields[15]);
		fxTradeDTCC.setAdditionalRepository1Prefix(fields[22]);
		fxTradeDTCC.setProductIdPrefix(fields[25]);
		fxTradeDTCC.setProductIdValue(fields[26]);
		fxTradeDTCC.setDeliveryType(fields[26]);	//Email conf. required
		fxTradeDTCC.setContractType(fields[26]);		
		fxTradeDTCC.setTradeParty1Role(fields[27]);
		fxTradeDTCC.setTradeParty2Role(fields[36]);
		fxTradeDTCC.setDataSubmitterLeiPrefix(fields[45]);
		fxTradeDTCC.setDataSubmitterLeiValue(fields[46]);
		fxTradeDTCC.setAllocationIndicator(fields[51]);
		fxTradeDTCC.setExecutionTimestamp(fields[52]);					
		fxTradeDTCC.setExecutionVenue(fields[55]);
		fxTradeDTCC.setClearingExceptionPartyPrefix(fields[59]);
		fxTradeDTCC.setClearingExceptionPartyValue(fields[60]);
		fxTradeDTCC.setCollateralized(fields[63]);
		fxTradeDTCC.setBrokerLocationParty1(fields[68]);
		fxTradeDTCC.setBrokerLocationParty2(fields[69]);
		fxTradeDTCC.setTraderLocationParty1(fields[70]);
		fxTradeDTCC.setTraderLocationParty2(fields[71]);
		fxTradeDTCC.setDeskLocationParty1(fields[72]);
		fxTradeDTCC.setDeskLocationParty2(fields[73]);
		//fxTrade.setExchangeCurrency1Amount(StringUtils.isNotBlank(fields[109]) ? stringToBigDecimalTest(fields[109]) : new BigDecimal(0));
		if (StringUtils.isNotBlank(fields[109]))
			fxTradeDTCC.setNotionalAmount1(convertStrToBigDecimalForNotionalAmt(fields[109]));
		//fxTrade.setExchangeCurrency2Amount(StringUtils.isNotBlank(fields[113]) ? stringToBigDecimalTest(fields[113]) : new BigDecimal(0));
		if (StringUtils.isNotBlank(fields[113]))
			fxTradeDTCC.setNotionalAmount2(convertStrToBigDecimalForNotionalAmt(fields[113]));
		//fxTrade.setExchangeCurrency2(fields[114]);
		fxTradeDTCC.setNotionalCurrency2(fields[114]);
		//fxTrade.setExchangeRate(fields[118]);
		if (StringUtils.isNotBlank(fields[118]))
		fxTradeDTCC.setExchangeRate(stringToBigDecimal(fields[118]));
		if (StringUtils.isNotBlank(fields[132]))
			fxTradeDTCC.setExpirationDate(DateUtilLoader.getDateFromString(fields[132]));
		fxTradeDTCC.setExpirationTime(fields[133]);
		if(StringUtils.isNotBlank(fields[161]))
			fxTradeDTCC.setExoticExpirationDate(DateUtilLoader.getDateFromString(fields[161]));
		
		fxTradeDTCC.setTradeParty1Lei(fields[169]);
		fxTradeDTCC.setTradeParty2Lei(fields[170]);
		
		fxTradeDTCC.setPremiumCurrency(fields[139]);
		fxTradeDTCC.setSettlementCurrency(fields[146]);
		fxTradeDTCC.setParty1Lei(tradeParty1lei);
		fxTradeDTCC.setParty2Lei(tradeParty2lei);
		
		fxTradeDTCC.setBloackTradeIndicator("NA");
		fxTradeDTCC.setTradeParty1Prefix(fields[28]);
		fxTradeDTCC.setTradeParty1FinEnt(fields[174]);				//TRADE_PARTY1_FINANCIAL_ENTITY_STATUS
		fxTradeDTCC.setTradeParty1UsPersonIndicator(fields[172]);
		fxTradeDTCC.setTradeParty2Prefix(fields[38]);
		fxTradeDTCC.setTradeParty2FinEnt(fields[175]);				//TRADE_PARTY2_FINANCIAL_ENTITY_STATUS
		fxTradeDTCC.setTradeParty2UsPersonIndicator(fields[173]);
		fxTradeDTCC.setAdditionalRepository1Lei(fields[96]);
		//fxTrade.setExchangeCurrency1(fields[110]);
		//fxTrade.setCcy1(fields[110]);
		fxTradeDTCC.setNotionalCurrency1(fields[110]);
		fxTradeDTCC.setAsOfDate(asofDate);
		return fxTradeDTCC;
	}

	@Override
	public boolean validate(RegRepPrFxPositionReport trade) {
		boolean canLoad = true;
		return canLoad;
	}
	private String setVal(String fieldString){
		if(StringUtils.equalsIgnoreCase("TRUE", fieldString)){
			return "YES";
		}else if(StringUtils.equalsIgnoreCase("FALSE", fieldString)){
			return "NO";
		}else return "";
	}

	@Override
	public RegRepPrFxPositionReport getTableName() {
		return new RegRepPrFxPositionReport() ;
	}

	@Override
	public boolean deletePrevDayRecords() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String loadNextJob() {
		// TODO Auto-generated method stub
		return null;
	}

}
