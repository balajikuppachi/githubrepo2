package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_DA_REPORT database table.
 */
@Entity
@Table(name = "REG_REP_PR_DA_REPORT")
public class RegRepPrDaReport extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "da_report_id")
	private Long daReportId;

	@Column(name = "affirm_datetime")
	private Date affirmDatetime;

	@Column(name = "affirmed_flag")
	private String affirmedFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "asset_class")
	private String assetClass;

	@Column(name = "cid_cpty_id")
	private int cidCptyId;

	@Column(name = "create_datetime")
	private Date createDatetime;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "cpty_type")
	private String cptyType;

	@Column(name = "mt_val_type")
	private String mtValType;

	@Column(name = "portfolio_size")
	private Integer portfolioSize;
	
	@Column(name = "recon_freq")
	private String reconFreq;
	
	@Column(name = "affirm_comments")
	private String affirmComments;
	
	@Column(name = "file_exception")
	private String fileException;
	
	@Column(name = "file_exception_reason")
	private String fileExceptionReason;
	
	public RegRepPrDaReport()
	{
	}

	public Long getDaReportId()
	{
		return this.daReportId;
	}

	public void setDaReportId(Long daReportId)
	{
		this.daReportId = daReportId;
	}

	public Date getAffirmDatetime()
	{
		return this.affirmDatetime;
	}

	public void setAffirmDatetime(Date affirmDatetime)
	{
		this.affirmDatetime = affirmDatetime;
	}

	public String getAffirmedFlag()
	{
		return this.affirmedFlag;
	}

	public void setAffirmedFlag(String affirmedFlag)
	{
		this.affirmedFlag = affirmedFlag;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getAssetClass()
	{
		return this.assetClass;
	}

	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}

	public int getCidCptyId()
	{
		return this.cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public Date getCreateDatetime()
	{
		return this.createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

	public String getFileName()
	{
		return this.fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String getCptyType()
	{
		return cptyType;
	}

	public void setCptyType(String cptyType)
	{
		this.cptyType = cptyType;
	}

	public String getMtValType()
	{
		return this.mtValType;
	}

	public void setMtValType(String mtValType)
	{
		this.mtValType = mtValType;
	}

	public String getReconFreq()
	{
		return this.reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public String getAffirmComments() {
		return affirmComments;
	}

	public void setAffirmComments(String affirmComments) {
		this.affirmComments = affirmComments;
	}

	public String getFileException() {
		return fileException;
	}

	public void setFileException(String fileException) {
		this.fileException = fileException;
	}

	public String getFileExceptionReason() {
		return fileExceptionReason;
	}

	public void setFileExceptionReason(String fileExceptionReason) {
		this.fileExceptionReason = fileExceptionReason;
	}

	public Integer getPortfolioSize() {
		return portfolioSize;
	}

	public void setPortfolioSize(Integer portfolioSize) {
		this.portfolioSize = portfolioSize;
	}

}