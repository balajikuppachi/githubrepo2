package com.wellsfargo.regulatory.portrec.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrLiveTradeDaoImpl;
import com.wellsfargo.regulatory.portrec.dto.CptyLiveTrades;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author Raji Komatreddy
 */
@Component
public class RegRepLiveTradeEnricherSvc
{

	@Autowired
	RegRepPrLiveTradeDaoImpl regRepPrLiveTradeDaoImpl;

	@Value("${portrec.livetrades.wellsfargo.affiliates}")
	String wfAffiliates;

	@Value("${portrec.batch.commit.size}")
	String batchSizeStr;
	
	
	@Value("${portrec.livetrades.wellsfargo.wellsLegalIds}")
	 String wellsLegalIds;

	Logger logger = Logger.getLogger(RegRepLiveTradeEnricherSvc.class);

	public void enrichLiveTradeData() throws PortrecException
	{
		logger.info("inside RegRepLiveTradeEnricherSvc :enrichLiveTradeData" );
		List<CptyLiveTrades> cptyLiveTradesList = null;
		List<CptyLiveTrades> enrichedCptyList = new ArrayList<CptyLiveTrades>();
		String party1lei = null;
		String party2lei = null;
		int legalID = 0;
		List<String> wfAffiliatesList = new ArrayList<String>();
		String[] wfAffiliateArray = null;
		
		List<String> wfLegalidList = new ArrayList<String>();
		String[] wfLegalidArray = null;
		
		boolean party1WfAffiliateFlag = false;
		boolean party2WfAffiliateFlag = false;
		int batchSize = 0;
		

		if (null != regRepPrLiveTradeDaoImpl)
		{

			if (null != batchSizeStr) batchSize = Integer.parseInt(batchSizeStr);
			if (null != wfAffiliates)
			{
				wfAffiliateArray = wfAffiliates.split(":");

				for (String currwfAffiliate : wfAffiliateArray)
				{
					wfAffiliatesList.add(currwfAffiliate);

				}
			}
			
			if (null != wellsLegalIds)
			{
				wfLegalidArray = wellsLegalIds.split(":");

				for (String currwellsBaids : wfLegalidArray)
				{
					wfLegalidList.add(currwellsBaids);

				}
			}

			cptyLiveTradesList = regRepPrLiveTradeDaoImpl.getAllCptyLiveTrades();
			if (null != cptyLiveTradesList)
			{
				for (CptyLiveTrades currCptyLiveTrades : cptyLiveTradesList)
				{
					party1lei = currCptyLiveTrades.getParty1Lei();
					party2lei = currCptyLiveTrades.getParty2Lei();
					legalID = currCptyLiveTrades.getCidCptyId();
				

					if (StringUtils.isBlank(party1lei) || StringUtils.isBlank(party2lei))
					{
						currCptyLiveTrades.setReconEligible(PortrecConstants.N);
						currCptyLiveTrades.setReconComment(PortrecConstants.LEI_MISSING);
					}
					else if (legalID <= 0){
						currCptyLiveTrades.setReconEligible(PortrecConstants.N);
						currCptyLiveTrades.setReconComment(PortrecConstants.LEGAL_ID_NULL);
					}
					else if( legalID != 0 && wfLegalidList.contains(Integer.toString(legalID)) )
					{
						currCptyLiveTrades.setReconEligible(PortrecConstants.N);
						currCptyLiveTrades.setReconComment(PortrecConstants.WELLS_LEGAL_ID);
						
					}
					else
					{
						if(party1lei.contains(":"))
						    party1lei = StringUtils.substringAfter(party1lei, ":");						
						
						if(party2lei.contains(":"))
						   party2lei = StringUtils.substringAfter(party2lei, ":");
						
						if(null != party1lei && StringUtils.upperCase(party1lei).startsWith(PortrecConstants.LEI_STARTS_WITH_DTCC))						
							party1lei = StringUtils.substring(party1lei, 4);
						
						if(null != party2lei && StringUtils.upperCase(party2lei).startsWith(PortrecConstants.LEI_STARTS_WITH_DTCC))						
							party2lei = StringUtils.substring(party2lei, 4);
						

						if (wfAffiliatesList.contains(party1lei)) 
							party1WfAffiliateFlag = true;

						if (wfAffiliatesList.contains(party2lei))
							party2WfAffiliateFlag = true;

						if (party1lei.equalsIgnoreCase(party2lei))
						{
							currCptyLiveTrades.setReconEligible(PortrecConstants.N);
							currCptyLiveTrades.setReconComment(PortrecConstants.INTERNAL_TRADE);

						}

						else if (party1WfAffiliateFlag && party2WfAffiliateFlag)
						{
							currCptyLiveTrades.setReconEligible(PortrecConstants.Y);
							currCptyLiveTrades.setReconComment(PortrecConstants.AFFILIATE_TRADE);
							currCptyLiveTrades.setReconCpty(party2lei);

						}
						else if (!party1WfAffiliateFlag && party2WfAffiliateFlag)
						{
							currCptyLiveTrades.setReconEligible(PortrecConstants.Y);
							currCptyLiveTrades.setReconCpty(party1lei);

						}
						else if (party1WfAffiliateFlag && !party2WfAffiliateFlag)
						{
							currCptyLiveTrades.setReconEligible(PortrecConstants.Y);
							currCptyLiveTrades.setReconCpty(party2lei);

						}
						else
						{
							currCptyLiveTrades.setReconEligible(PortrecConstants.N);
							currCptyLiveTrades.setReconComment(PortrecConstants.NON_AFFILIATE_TRADE);

						}

					}

					enrichedCptyList.add(currCptyLiveTrades);
					
					//reset flags
					party1WfAffiliateFlag = false;
					party2WfAffiliateFlag = false;

					if (enrichedCptyList.size() == batchSize)
					{
						//logger.info("before updating records in LiveTrade table");
						regRepPrLiveTradeDaoImpl.batchUpdatePrLiveTrades(enrichedCptyList);
						enrichedCptyList.clear();

					}

				}

				regRepPrLiveTradeDaoImpl.batchUpdatePrLiveTrades(enrichedCptyList);
				enrichedCptyList.clear();

			}

		}
		
		logger.info("finished RegRepLiveTradeEnricherSvc :enrichLiveTradeData successfully" );

	}
}
