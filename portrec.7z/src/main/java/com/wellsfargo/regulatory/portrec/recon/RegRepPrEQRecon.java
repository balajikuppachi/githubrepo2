package com.wellsfargo.regulatory.portrec.recon;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrEqPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrIrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrEqPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
public class RegRepPrEQRecon {

	@Autowired
	RegRepPrEqPositionReportRepository repPrEqPositionReportRepository;
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	private static Logger logger = Logger.getLogger(RegRepPrEQRecon.class);
	
	@Autowired
	RegRepPrReconHelper regRepPrReconHelper;
	
	@Value("${portrec.recon.file.Location}")
	String portrecReconFileLoc;
	
	public void doEQRecon(List<RegRepPrJobExecutionDetail> jobDetail, Date asOfdate) {
		int eqLiveTradeCount = 0;
		int dtccPosCount =0;
		int dtccNotMatchingPos = 0;
		
		logger.info("Starting EQ Recon ");
		List<RegRepPrLiveTrade> liveTrades = regRepPrLiveTradeRepository.findTradesBasedonAssetClass(PortrecConstants.ASSETCLASS_EQ);
			eqLiveTradeCount = liveTrades.size();
		Map<String,RegRepPrEqPositionReport> dtccUSIMap = new HashMap<String, RegRepPrEqPositionReport>();
		Map<String, RegRepPrLiveTrade> regrepUSIMap = new HashMap<String, RegRepPrLiveTrade>();
			
		logger.info("Size of LiveTrades for EQ Trades "	+	eqLiveTradeCount);
		
		List<RegRepPrEqPositionReport> dtccUSIList = new ArrayList<RegRepPrEqPositionReport>();
		
		if(null != jobDetail)
		{
			long startTime = System.currentTimeMillis();
			for(RegRepPrJobExecutionDetail job : jobDetail) {
				dtccUSIList.addAll(repPrEqPositionReportRepository.findPositionsByDate(job));
			}
			long endTime = System.currentTimeMillis();
			logger.info("Total Time Taken to get EQ Position Counts " + (endTime - startTime));
		}
		if(null != dtccUSIList) 
		{
			dtccPosCount = dtccUSIList.size();
			logger.info("Size of EQ Positions "	+	dtccPosCount);
				for(RegRepPrEqPositionReport dtccUSI : dtccUSIList)
				{
					String usi = dtccUSI.getUsi();
					String submittedFor = dtccUSI.getSubmittedFor();
					String tradeParty1 = dtccUSI.getParty1();
					String tradeParty2 = dtccUSI.getParty2();
			
						if(null != usi && !submittedFor.contains("F226TOH6YD6XJB17KS62") 
								&& !tradeParty2.contains("F226TOH6YD6XJB17KS62") && !tradeParty1.contains("F226TOH6YD6XJB17KS62")) 
						{
							dtccUSIMap.put(usi, dtccUSI);
						}
				}	
		
				
				for(RegRepPrLiveTrade liveTrade : liveTrades){
					String usi = liveTrade.getUsi();
					String reconCpty = liveTrade.getReconCpty();
					if(dtccUSIMap.containsKey(usi)){
						/*removeLiveTradesList.add(liveTrade);*/
						dtccUSIMap.remove(usi);
					} else if(!reconCpty.contains("F226TOH6YD6XJB17KS62")){
						regrepUSIMap.put(liveTrade.getUsi(), liveTrade);
					}
				}
				
				dtccNotMatchingPos = dtccUSIMap.size();
				eqLiveTradeCount = regrepUSIMap.size();
				logger.info("Size of EQ Positions Not matching : "	+	dtccNotMatchingPos + " And Live Trades : " + eqLiveTradeCount);
				
				if(eqLiveTradeCount>0){
					regRepPrReconHelper.generateliveTradeFile(PortrecConstants.ASSETCLASS_EQ, regrepUSIMap, asOfdate);
				}
				if(dtccNotMatchingPos>0){
					generateEQDtccPosFile(PortrecConstants.ASSETCLASS_EQ,dtccUSIMap, asOfdate);
				}
		}
	}
	
	private void generateEQDtccPosFile(String assetClass, Map<String, RegRepPrEqPositionReport> dtccUSIMap, Date asOfdate) {
		
		DateFormat formatter ; 
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reconFileName = "DTCC_Recon_"+assetClass+"_"+ formatter.format(asOfdate) +".xls";
		
		List<String> liveTrades1 = regRepPrLiveTradeRepository.findTradesonAssetClassandQN(assetClass);
		Map<String, String> usiLiveMapN = new HashMap<String, String>();
		
		for(String liveTrade : liveTrades1){
			usiLiveMapN.put(liveTrade, assetClass);
		}
		
		File dtccFolder = new File(portrecReconFileLoc+File.separator+ asOfdate);
	   	 File irFile;
	   	 if (dtccFolder.isDirectory()) {
		   	 	 irFile = new File(dtccFolder +File.separator+reconFileName);
		 }
	   	 else {
	   		dtccFolder.mkdirs();
	   		irFile = new File(dtccFolder +File.separator+reconFileName);
	   	 }
	   	FileWriter fw = null;
		try {
			fw = new FileWriter(irFile);
			fw.append("USI").append("\t").append("SubmittedFor").append("\t").append("OrigTradeID").append("\t").append("TradeParty1").append("\t").append("TradeParty2")
			.append("\t").append("Comment").append('\n');
			for (Map.Entry<String, RegRepPrEqPositionReport> entry : dtccUSIMap.entrySet()) {
				String usi = entry.getKey();
				String comment = "";
								
				if(usiLiveMapN.containsKey(usi))
				{
					comment = "Trade Qualifier is Set as N in Live Trade Table";
				}
					fw.append(usi).append("\t")
					.append(entry.getValue().getSubmittedFor()).append("\t")
					.append(entry.getValue().getOrigTradeId()).append("\t")
					.append(entry.getValue().getParty1()).append("\t")
					.append(entry.getValue().getParty2()).append("\t")
					.append(comment)
					.append('\n');
			}
			fw.close();
			
		} catch (Exception ex){
			logger.error("Error Creating DTCC IR Recon report");
		}
		logger.info("Recon report has been generated: " +  irFile.getAbsolutePath());
		
	}

}
