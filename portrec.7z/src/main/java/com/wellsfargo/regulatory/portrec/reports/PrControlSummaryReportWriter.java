package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.mailer.CptyMisMailerSmtpService;
import com.wellsfargo.regulatory.portrec.mailer.PrEmailAddressValidation;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCidRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCptyReconFreqRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrDaReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Service
public class PrControlSummaryReportWriter {

	private final Logger logger = Logger
			.getLogger(PrControlSummaryReportWriter.class);
	@Value("${file.mis.outputFolder}")
	String outputFolderName;

	
	
	protected String legalNameValue = null;
	protected String legalIdValue = null;
	protected String emailAddressValue = null;
	protected String reconTypeValue = null;
	protected String portfolioSizeValue = null;
	protected String cptyTypeValue = null;
	protected String reconFreq = null;
	protected String assetClass=null;
	protected Date todayDate = null;
	protected Date cobDate =null;
	protected  String reconFreqHeading = null;
	protected  String valAttached=null;
	protected  String algoCAName=null;
	protected String jsFlag=null;
	long currJobExecutionId = 0;
	@Autowired
	RegRepPrCptyReconFreqRepository regRepPrCptyReconFreqRepository;
	@Autowired
	RegRepPrDaReportRepository regRepPrDaReportRepository;
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	@Autowired
	RegRepPrCidRepository regRepPrCidRepository;

	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;

	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;
	@Autowired
	CalendarService calendarService;
	
	@Autowired
	PrEmailAddressValidation prEmailAddressValidation;
	
	@Autowired
	CptyMisMailerSmtpService cptyMisMailerSmtpService;
 	
	public void misControlSummaryFileGeneration(Message<?> message) throws PortrecException {
		long timeStart = System.currentTimeMillis();
		logger.info("Start misControlReportGeneration - ");

		Object ipMessage = null;
		String errorString = null;
		
		String jobAsOfDate = null;
		Date asOfDate = null;
		String jobReconDate = null;
		Date reconDate = null;

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = null;
		
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);

		if (null == message) {
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("misControlReportGeneration-1",ExceptionSeverityEnum.ERROR,ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		
		ipMessage = message.getPayload();
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE))
		{
			jobAsOfDate = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();
		}

		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_RECON_DATE)) 
		{
			jobReconDate = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_RECON_DATE).toString();
		}

		if (null != jobAsOfDate) {
			logger.info(" recon process running for asOfDate received from fileName " + jobAsOfDate);
			try 
			{
				asOfDate = reconDateFormat.parse(jobAsOfDate);
			} catch (ParseException e) {
				logger.error("########## " + e.getMessage());
			}
		} 
		if (null != jobReconDate)
		{
			logger.info(" recon process running for asOfDate received from fileName " + jobReconDate);
			try
			{
				reconDate = reconDateFormat.parse(jobReconDate);
			}
			catch (ParseException e)
			{
				errorString = "exception occured while inserting a record in JobExecutionDetails table";
				logger.error("########## " + errorString);
				throw new PortrecException("misControlReportGeneration-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
			}
		}

		if (ipMessage instanceof RegRepPrJobExecutionDetail)
		{
			regRepPrJobExecutionDetail = (RegRepPrJobExecutionDetail) message.getPayload();
		}

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while getting Job Execution detail from DUC process";
			logger.error("########## " + errorString);
			throw new PortrecException("misControlReportGeneration-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);

		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		
		logger.info("jobExecution id for current run of Control Summary Report :  " + currJobExecutionId);

		try {
			
			List<RegRepPrReconCalendar> reconCalList = regRepPrReconCalendarRepository.findByDate(reconDate);

			for (RegRepPrReconCalendar reconCalItem : reconCalList) {
				
				reconFreq = reconCalItem.getReconFreq();
				cobDate = reconCalItem.getAsOfDate();
				String mailCobDate=cobDate.toString();
				cptyMisMailerSmtpService.sendEmail(mailCobDate,reconFreq,"Pre Run");
				logger.info("Building the control summary report of "+reconFreq);
				File PrCtrlSumFolder = new File(outputFolderName);
	
				File PrCtrlSumFile;
				if (PrCtrlSumFolder.exists() && PrCtrlSumFolder.isDirectory()) {
					// create preRun file here
					PrCtrlSumFile = new File(PrCtrlSumFolder + File.separator
							+ PortrecConstants.PR_CONTROL_FILE_NAME+ PortrecConstants.UNDERSCORE
							+ reconFreq.toLowerCase() + PortrecConstants.UNDERSCORE
							+ PortRecUtil.convertDateToString_Mmddyyyy(cobDate)+".xls");
				} else {
					PrCtrlSumFolder.mkdirs();
					PrCtrlSumFile = new File(PrCtrlSumFolder + File.separator
							+ PortrecConstants.PR_CONTROL_FILE_NAME+ PortrecConstants.UNDERSCORE
							+ reconFreq.toLowerCase() + PortrecConstants.UNDERSCORE
							+ PortRecUtil.convertDateToString_Mmddyyyy(cobDate)+".xls");
				}
				
				
				generateCsvFile(PrCtrlSumFile,regRepPrJobExecutionDetail,cobDate);
				cptyMisMailerSmtpService.sendEmail(mailCobDate,reconFreq,"Control Summary");
				
				
			}
			logger.info("Folder where file created is " + outputFolderName);
		} catch (Exception ex) {

			logger.error("Error in misControlReportGeneration Process : "
					+ ex.getMessage());
			try {
				regRepPrJobExecutionDetail
						.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository
						.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				RegRepPrException regRepPrException = new RegRepPrException();
				regRepPrException.setExceptionSource("PrControlSummaryReportWriter");
				regRepPrException.setJobExecutionId(currJobExecutionId);
				regRepPrException.setExceptionDesc(errorString);
				regRepPrException
						.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR
								.toString());
				regRepPrException.setExceptionTrace(ExceptionUtils
						.getStackTrace(ex));
				regRepPrException.setCreateDatetime(new Date());
				portrecExceptionLogger.logExceptionToDB(regRepPrException);
				logger.error("Exception occurred inside misControlReportGeneration for jobId #"
						+ currJobExecutionId
						+ "exception message "
						+ errorString);
			} catch (Exception e) {
				logger.error("exception while logging exception to DB "
						+ ExceptionUtils.getStackTrace(e));
			}
		}

		regRepPrJobExecutionDetail
				.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository
				.save(regRepPrJobExecutionDetail);

		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in misControlReportGeneration Process : "
				+ PortRecUtil.printTimeTaken(timeEnd - timeStart));
	}
	
	private void prepareSummaryHeader(Workbook wb, Row row, short column,
			String displayText) {
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = wb.createCellStyle();

		Font xSSFFont = wb.createFont();
		xSSFFont.setFontName(HSSFFont.FONT_ARIAL);
		xSSFFont.setFontHeightInPoints((short) 12);
		xSSFFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		xSSFFont.setColor(HSSFColor.BLACK.index);
		cellStyle.setFont(xSSFFont);

		cell.setCellStyle(cellStyle);

	}

	private void generateCsvFile(File PrCtrlSumFile,RegRepPrJobExecutionDetail prevRegRepPrJobExecutionDetail,Date asOfDate) throws ParseException {
		try {
			
			reconFreqHeading=calendarService.reconFrequency(cobDate, reconFreq);
			FileOutputStream fileOut = new FileOutputStream(PrCtrlSumFile);
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			currJobExecutionId = prevRegRepPrJobExecutionDetail.getJobExecutionId();
			Sheet worksheet1 = workbook.createSheet("Summary");
			Sheet worksheet2 = workbook.createSheet("Counterparty Details");
			Row row1 = worksheet1.createRow((short) 2);
			prepareSummaryHeader(workbook, row1, (short) 0,
					PortrecConstants.CONTROL_REPORT_HEADING);

			if (null != reconFreqHeading) {
				prepareSummaryHeader(workbook, row1, (short) 1,
						reconFreqHeading);
			}
			
			Row row2 = worksheet1.createRow((short) 3);
			prepareSummaryHeader(workbook, row2, (short) 1,
					PortrecConstants.DATA_COB
					+ PortrecConstants.SPACE
					+ PortRecUtil.convertDateToString_Mmddyy(cobDate));
			

			Row row3 = worksheet1.createRow((short) 6);
			prepareSummaryHeader(workbook, row3, (short) 0,
					PortrecConstants.CATEGORY);
			prepareSummaryHeader(workbook, row3, (short) 1,
					PortrecConstants.COUNT);

			Row row4 = worksheet1.createRow((short) 7);
			Cell cellA6 = row4.createCell((short) 0);
			cellA6.setCellValue(PortrecConstants.TOTAL_CP_ELIGIBLE_FOR_NOTICE);
			Cell cellA7 = row4.createCell((short) 1);
			if(null!=regRepPrCptyReconFreqRepository
					.findTotalCpEligibleForNotice(reconFreq))
			cellA7.setCellValue(regRepPrCptyReconFreqRepository
					.findTotalCpEligibleForNotice(reconFreq));

			Row row5 = worksheet1.createRow((short) 8);
			Cell cellA8 = row5.createCell((short) 0);
			cellA8.setCellValue(PortrecConstants.SWAP_DEALER_MSP);
			Cell cellA9 = row5.createCell((short) 1);
			if(null!=regRepPrCptyReconFreqRepository
					.findSwapDealerAndMsp(reconFreq))
			cellA9.setCellValue(regRepPrCptyReconFreqRepository
					.findSwapDealerAndMsp(reconFreq));

			Row row6 = worksheet1.createRow((short) 9);
			Cell cellA10 = row6.createCell((short) 0);
			cellA10.setCellValue(PortrecConstants.NON_SWAP_DEALER_MSP);
			Cell cellA11 = row6.createCell((short) 1);
			if(null!=regRepPrCptyReconFreqRepository
					.findNonSwapDealerAndMsp(reconFreq))
			cellA11.setCellValue(regRepPrCptyReconFreqRepository.findNonSwapDealerAndMsp(reconFreq));


			Row row7 = worksheet1.createRow((short) 10);
			Cell cellA12 = row7.createCell((short) 0);
			cellA12.setCellValue(PortrecConstants.TOTAL_CP_SUBMITTED_TO_DA);
			Cell cellA13 = row7.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalCptyProcessedToDA(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA13.setCellValue(regRepPrDaReportRepository
					.totalCptyProcessedToDA(reconFreq,prevRegRepPrJobExecutionDetail));

			

			Row row9 = worksheet1.createRow((short) 11);
			Cell cellA16 = row9.createCell((short) 0);
			cellA16.setCellValue(PortrecConstants.TOTAL_MATERIAL_TERM_FILE);
			Cell cellA17 = row9.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalMaterialTermFileCtrl(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA17.setCellValue(regRepPrDaReportRepository
					.totalMaterialTermFileCtrl(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row10 = worksheet1.createRow((short) 12);
			Cell cellA18 = row10.createCell((short) 0);
			cellA18.setCellValue(PortrecConstants.TOTAL_VALUATION_FILE);
			Cell cellA19 = row10.createCell((short) 1);
			if(null!=regRepPrDaReportRepository
					.totalValuationFileCtrl(reconFreq,prevRegRepPrJobExecutionDetail))
			cellA19.setCellValue(regRepPrDaReportRepository
					.totalValuationFileCtrl(reconFreq,prevRegRepPrJobExecutionDetail));

			Row row11 = worksheet1.createRow((short) 14);
			Cell cellA20 = row11.createCell((short) 0);
			cellA20.setCellValue(PortrecConstants.TOTAL_TRADES_ELIGIBLE_FOR_NOTICE);
			Cell cellA21 = row11.createCell((short) 1);
			
			Long totalPortfolioSizeByFreq = null; 
			totalPortfolioSizeByFreq =	regRepPrCptyReconFreqRepository.totalTradesEligibleForNoticeQuartely(reconFreq);
			
			if (null != totalPortfolioSizeByFreq)
			{
				cellA21.setCellValue(totalPortfolioSizeByFreq);
			} else {
				cellA21.setCellValue(0);
			}	

			Row row12 = worksheet1.createRow((short) 15);
			Cell cellA22 = row12.createCell((short) 0);
			cellA22.setCellValue(PortrecConstants.TRDAES_WITH_SD_MSP);
			Cell cellA23 = row12.createCell((short) 1);
			if(null!=regRepPrCptyReconFreqRepository
					.tradeSDMspQuartely(reconFreq))
			cellA23.setCellValue(regRepPrCptyReconFreqRepository
					.tradeSDMspQuartely(reconFreq));
			else
				cellA23.setCellValue(0);

			Row row13 = worksheet1.createRow((short) 16);
			Cell cellA24 = row13.createCell((short) 0);
			cellA24.setCellValue(PortrecConstants.TRDAES_WITH_NON_SD_MSP);
			Cell cellA25 = row13.createCell((short) 1);
			if(null!=regRepPrCptyReconFreqRepository
					.tradeNonSDMspQuartely(reconFreq))
			cellA25.setCellValue(regRepPrCptyReconFreqRepository.tradeNonSDMspQuartely(reconFreq));
			else
				cellA25.setCellValue(0);

			Date as_of_date_collateralized=asOfDate;
			
			Long numOfCollateralizedTrades=null;
			if(null != as_of_date_collateralized){
				numOfCollateralizedTrades = regRepPrLiveTradeRepository
						.totalCollateralizedTrade(reconFreq,as_of_date_collateralized) ;
			}
			Row row15 = worksheet1.createRow((short) 17);
			Cell cellA28 = row15.createCell((short) 0);
			cellA28.setCellValue(PortrecConstants.TOTAL_COLLATERALIZED_TRADE);
			Cell cellA29 = row15.createCell((short) 1);
			if(null!=numOfCollateralizedTrades)
			cellA29.setCellValue(numOfCollateralizedTrades);
			
			Long totalNonCollateralizedTrade=null;
			if (null != totalPortfolioSizeByFreq && null!=numOfCollateralizedTrades
					&& totalPortfolioSizeByFreq.compareTo(numOfCollateralizedTrades)>0)
			{
			totalNonCollateralizedTrade=totalPortfolioSizeByFreq-numOfCollateralizedTrades;
			}
			Row row16 = worksheet1.createRow((short) 18);
			Cell cellA30 = row16.createCell((short) 0);
			cellA30.setCellValue(PortrecConstants.TOTAL_NON_COLLATERALIZED_TRADE);
			Cell cellA31 = row16.createCell((short) 1);
			if(null!=totalNonCollateralizedTrade)
			cellA31.setCellValue(totalNonCollateralizedTrade);
			else
				cellA31.setCellValue(0);
			
			

			Row row17 = worksheet2.createRow((short) 0);
			prepareSummaryHeader(workbook, row17, (short) 0,
					PortrecConstants.lEGAL_NAME);
			prepareSummaryHeader(workbook, row17, (short) 1,
					PortrecConstants.lEGAL_ID);
			prepareSummaryHeader(workbook, row17, (short) 2,
					PortrecConstants.CTRL_EMAIL_ADDRESS);
			prepareSummaryHeader(workbook, row17, (short) 3,
					PortrecConstants.CFTC_REG);
			prepareSummaryHeader(workbook, row17, (short) 4,
					PortrecConstants.PORTFOLIO_SIZE);
			prepareSummaryHeader(workbook, row17, (short) 5,
					PortrecConstants.RECON_PERIOD);
			prepareSummaryHeader(workbook, row17, (short) 6,
					PortrecConstants.MT_ASSET_CLASS);
			prepareSummaryHeader(workbook, row17, (short) 7,
					PortrecConstants.VAL_ATTACHED);
			prepareSummaryHeader(workbook, row17, (short) 8,
					PortrecConstants.JS_INDICATOR);
		
			
			List<Object[]> list = regRepPrCidRepository.leicptyDetails(reconFreq,prevRegRepPrJobExecutionDetail);
			List <CptyMisCtrlDetails> ctrldetailslist=new ArrayList<CptyMisCtrlDetails>();
			
			for(Object[] Object: list)
			{
				CptyMisCtrlDetails CptyMisCtrlDetails = new CptyMisCtrlDetails();
				CptyMisCtrlDetails.setCidCptyId(null!=Object[0]?(Integer)Object[0]:null);
				CptyMisCtrlDetails.setFullLegalName(null!=Object[1]?String.valueOf(Object[1]):null);
				CptyMisCtrlDetails.setCptyType(null!=Object[2]?String.valueOf(Object[2]):null);
				CptyMisCtrlDetails.setPortfolioSize(null!=Object[3]?String.valueOf(Object[3]):null);
				CptyMisCtrlDetails.setReconFreq(null!=Object[4]?String.valueOf(Object[4]):null);
				CptyMisCtrlDetails.setAssetClass(null!=Object[5]?String.valueOf(Object[5]):null);
				CptyMisCtrlDetails.setValAttached(null!=Object[6]?String.valueOf(Object[6]):null);
				CptyMisCtrlDetails.setEmailAddress(null!=Object[7]?String.valueOf(Object[7]):null);
				CptyMisCtrlDetails.setJsFlag(null!=Object[8]?(Integer)Object[8]:null);
				ctrldetailslist.add(CptyMisCtrlDetails);
			}
			
			//int size = list.size();
			int noOfrows = 1;
			for(CptyMisCtrlDetails cptyMisCtrlDetails:ctrldetailslist){
				Row row = worksheet2.createRow((short) noOfrows);
				Cell cellA38 = row.createCell((short) 0);
				if (cptyMisCtrlDetails.getFullLegalName() != null) {
					legalNameValue = cptyMisCtrlDetails.getFullLegalName();
				} 
				else
					{
					legalNameValue=PortrecConstants.EMPTY;
					}
				cellA38.setCellValue(legalNameValue);

				Cell cellA39 = row.createCell((short) 1);
				if (cptyMisCtrlDetails.getCidCptyId()!= null) {
					legalIdValue = cptyMisCtrlDetails.getCidCptyId().toString();
				} 
				else
				{
					legalIdValue=PortrecConstants.EMPTY;
				}
				cellA39.setCellValue(legalIdValue);

				Cell cellA40 = row.createCell((short) 2);
				if (cptyMisCtrlDetails.getEmailAddress() != null) {
					emailAddressValue = cptyMisCtrlDetails.getEmailAddress();
				} 
				else
				{
					emailAddressValue=PortrecConstants.EMPTY;
				}
				cellA40.setCellValue(emailAddressValue);

				Cell cellA41 = row.createCell((short) 3);
				if (cptyMisCtrlDetails.getCptyType() != null) {
					cptyTypeValue = cptyMisCtrlDetails.getCptyType();
				} 
				else
				{
					cptyTypeValue=PortrecConstants.EMPTY;
				}
				cellA41.setCellValue(cptyTypeValue);
				Cell cellA42 = row.createCell((short) 4);
				if (cptyMisCtrlDetails.getPortfolioSize() != null) {
					portfolioSizeValue =cptyMisCtrlDetails.getPortfolioSize();
				} 
				else
				{
					portfolioSizeValue=PortrecConstants.EMPTY;
				}
				cellA42.setCellValue(portfolioSizeValue);
				Cell cellA43 = row.createCell((short) 5);
				if (cptyMisCtrlDetails.getReconFreq() != null) {
					reconTypeValue = cptyMisCtrlDetails.getReconFreq();
				} 
				else
				{
					reconTypeValue=PortrecConstants.EMPTY;
				}
				cellA43.setCellValue(reconTypeValue);
				Cell cellA44 = row.createCell((short) 6);
				if (cptyMisCtrlDetails.getAssetClass() != null) {
					assetClass = cptyMisCtrlDetails.getAssetClass();
				} 
				else
				{
					assetClass=PortrecConstants.EMPTY;
				}
				cellA44.setCellValue(assetClass);
				Cell cellA45 = row.createCell((short) 7);
				if (cptyMisCtrlDetails.getValAttached() != null) {
					if ((cptyMisCtrlDetails.getValAttached()).equals("VAL"))
						valAttached = "YES";
					else
						valAttached = "NO";
				} else
					valAttached = PortrecConstants.EMPTY;
				cellA45.setCellValue(valAttached);
				
				Cell cellA46 = row.createCell((short) 8);
				if (cptyMisCtrlDetails.getJsFlag() != null && cptyMisCtrlDetails.getJsFlag().toString().equals("1")) {
					jsFlag = "Y";

				} else
					jsFlag = "N";
				cellA46.setCellValue(jsFlag);
				noOfrows++;
			}
			
			workbook.write(fileOut);
			workbook.dispose();
			fileOut.flush();
			fileOut.close();

		} catch (Exception e) {
			String errorMsg = "exception while generating control summary mis file ";
			portrecExceptionLogger.logExceptionScenario("PrControlSummaryReportWriter",errorMsg, e, currJobExecutionId,null);
		}
	}

}
