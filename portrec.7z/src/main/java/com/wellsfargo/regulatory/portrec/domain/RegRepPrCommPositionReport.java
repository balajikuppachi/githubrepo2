package com.wellsfargo.regulatory.portrec.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy 
 * The persistent class for the REG_REP_PR_COMM_POSITION_REPORT database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_COMM_POSITION_REPORT")
public class RegRepPrCommPositionReport extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "comm_position_report_id")
	private Long commPositionReportId;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "asset_class")
	private String assetClass;

	private String book;

	private String buyer;

	@Column(name = "buyer_fin_ent")
	private String buyerFinEnt;

	@Column(name = "buyer_lei")
	private String buyerLei;

	@Column(name = "buyer_pay_index")
	private String buyerPayIndex;

	@Column(name = "buyer_payindex_avg_method")
	private String buyerPayindexAvgMethod;

	@Column(name = "buyer_us_ent")
	private String buyerUsEnt;

	@Column(name = "buyer_us_reg_desg")
	private String buyerUsRegDesg;

	@Column(name = "cftc_product_id")
	private String cftcProductId;

	private String collaterlized;

	@Column(name = "contract_type")
	private String contractType;

	@Column(name = "days_of_week")
	private String daysOfWeek;

	@Temporal(TemporalType.DATE)
	@Column(name = "end_date")
	private Date endDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "exec_date")
	private Date execDate;

	@Column(name = "execution_venue")
	private String executionVenue;

	private String grade;

	@Column(name = "hr_from_thr")
	private String hrFromThr;

	@Column(name = "hr_from_thr_timezone")
	private String hrFromThrTimezone;

	@Column(name = "int_product_id")
	private String intProductId;

	@Column(name = "last_update")
	private Date lastUpdate;

	@Column(name = "load_type")
	private String loadType;

	@Column(name = "mac_pri_asset_class")
	private String macPriAssetClass;

	@Column(name = "mac_sec_asset_class")
	private String macSecAssetClass;

	@Column(name = "maturity_date")
	private Date maturityDate;

	@Column(name = "mixed_swap")
	private String mixedSwap;

	@Column(name = "mixed_swap_report_sdr")
	private String mixedSwapReportSdr;

	@Column(name = "mult_asset_class_swap")
	private String multAssetClassSwap;

	@Column(name = "non_rep_fin")
	private String nonRepFin;

	@Column(name = "non_rep_msp")
	private String nonRepMsp;

	@Column(name = "non_rep_us")
	private String nonRepUs;

	@Column(name = "non_report_id")
	private String nonReportId;

	@Column(name = "non_report_lei")
	private String nonReportLei;

	@Column(name = "non_rept_sd")
	private String nonReptSd;

	@Column(name = "notional_amount_cpty")
	private BigDecimal notionalAmountCpty;

	@Column(name = "notional_amount_party")
	private BigDecimal notionalAmountParty;

	@Column(name = "notional_currency_cpty")
	private String notionalCurrencyCpty;

	@Column(name = "notional_currency_party")
	private String notionalCurrencyParty;

	@Column(name = "option_premium")
	private String optionPremium;

	@Column(name = "option_style")
	private String optionStyle;

	@Column(name = "option_type")
	private String optionType;

	private String price;

	@Column(name = "price_curr")
	private String priceCurr;

	@Column(name = "price_unit")
	private String priceUnit;

	@Column(name = "product_id")
	private String productId;

	@Column(name = "product_id1")
	private String productId1;

	@Column(name = "product_id2")
	private String productId2;

	@Column(name = "product_type")
	private String productType;

	private String qantity;

	@Column(name = "qantity_freq")
	private String qantityFreq;

	@Column(name = "qantity_unit")
	private String qantityUnit;

	@Column(name = "report_date")
	private Date reportDate;

	@Column(name = "report_fin")
	private String reportFin;

	@Column(name = "report_msp")
	private String reportMsp;

	@Column(name = "report_prty_lei")
	private String reportPrtyLei;

	@Column(name = "report_sd")
	private String reportSd;

	@Column(name = "report_us")
	private String reportUs;

	@Column(name = "reporting_entity_pet_data")
	private String reportingEntityPetData;

	@Column(name = "reporting_party")
	private String reportingParty;

	private String seller;

	@Column(name = "seller_fin_ent")
	private String sellerFinEnt;

	@Column(name = "seller_lei")
	private String sellerLei;

	@Column(name = "seller_pay_index")
	private String sellerPayIndex;

	@Column(name = "seller_payindex_avg_method")
	private String sellerPayindexAvgMethod;

	@Column(name = "seller_us_ent")
	private String sellerUsEnt;

	@Column(name = "seller_us_reg_desg")
	private String sellerUsRegDesg;

	@Column(name = "settlement_method")
	private String settlementMethod;

	@Column(name = "src_trade_id")
	private String srcTradeId;

	@Temporal(TemporalType.DATE)
	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "submitted_onbehalf_party_id_value")
	private String submittedOnbehalfPartyIdValue;

	@Column(name = "total_freq")
	private String totalFreq;

	@Column(name = "trade_date")
	private Date tradeDate;

	@Column(name = "trade_party1")
	private String tradeParty1;

	@Column(name = "trade_party1_name")
	private String tradeParty1Name;

	@Column(name = "trade_party1_reference_number")
	private String tradeParty1ReferenceNumber;

	@Column(name = "trade_party2")
	private String tradeParty2;

	@Column(name = "trade_party2_name")
	private String tradeParty2Name;

	@Column(name = "tv_prod_id")
	private String tvProdId;

	@Column(name = "usi_namespace")
	private String usiNamespace;

	@Column(name = "usi_value")
	private String usiValue;

	@Column(name = "verification_status")
	private String verificationStatus;

	public RegRepPrCommPositionReport()
	{
	}

	public Long getCommPositionReportId()
	{
		return this.commPositionReportId;
	}

	public void setCommPositionReportId(Long commPositionReportId)
	{
		this.commPositionReportId = commPositionReportId;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getAssetClass()
	{
		return this.assetClass;
	}

	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}

	public String getBook()
	{
		return this.book;
	}

	public void setBook(String book)
	{
		this.book = book;
	}

	public String getBuyer()
	{
		return this.buyer;
	}

	public void setBuyer(String buyer)
	{
		this.buyer = buyer;
	}

	public String getBuyerFinEnt()
	{
		return this.buyerFinEnt;
	}

	public void setBuyerFinEnt(String buyerFinEnt)
	{
		this.buyerFinEnt = buyerFinEnt;
	}

	public String getBuyerLei()
	{
		return this.buyerLei;
	}

	public void setBuyerLei(String buyerLei)
	{
		this.buyerLei = buyerLei;
	}

	public String getBuyerPayIndex()
	{
		return this.buyerPayIndex;
	}

	public void setBuyerPayIndex(String buyerPayIndex)
	{
		this.buyerPayIndex = buyerPayIndex;
	}

	public String getBuyerPayindexAvgMethod()
	{
		return this.buyerPayindexAvgMethod;
	}

	public void setBuyerPayindexAvgMethod(String buyerPayindexAvgMethod)
	{
		this.buyerPayindexAvgMethod = buyerPayindexAvgMethod;
	}

	public String getBuyerUsEnt()
	{
		return this.buyerUsEnt;
	}

	public void setBuyerUsEnt(String buyerUsEnt)
	{
		this.buyerUsEnt = buyerUsEnt;
	}

	public String getBuyerUsRegDesg()
	{
		return this.buyerUsRegDesg;
	}

	public void setBuyerUsRegDesg(String buyerUsRegDesg)
	{
		this.buyerUsRegDesg = buyerUsRegDesg;
	}

	public String getCftcProductId()
	{
		return this.cftcProductId;
	}

	public void setCftcProductId(String cftcProductId)
	{
		this.cftcProductId = cftcProductId;
	}

	public String getCollaterlized()
	{
		return this.collaterlized;
	}

	public void setCollaterlized(String collaterlized)
	{
		this.collaterlized = collaterlized;
	}

	public String getContractType()
	{
		return this.contractType;
	}

	public void setContractType(String contractType)
	{
		this.contractType = contractType;
	}

	public String getDaysOfWeek()
	{
		return this.daysOfWeek;
	}

	public void setDaysOfWeek(String daysOfWeek)
	{
		this.daysOfWeek = daysOfWeek;
	}

	public Date getEndDate()
	{
		return this.endDate;
	}

	public void setEndDate(Date endDate)
	{
		this.endDate = endDate;
	}

	public Date getExecDate()
	{
		return this.execDate;
	}

	public void setExecDate(Date execDate)
	{
		this.execDate = execDate;
	}

	public String getExecutionVenue()
	{
		return this.executionVenue;
	}

	public void setExecutionVenue(String executionVenue)
	{
		this.executionVenue = executionVenue;
	}

	public String getGrade()
	{
		return this.grade;
	}

	public void setGrade(String grade)
	{
		this.grade = grade;
	}

	public String getHrFromThr()
	{
		return this.hrFromThr;
	}

	public void setHrFromThr(String hrFromThr)
	{
		this.hrFromThr = hrFromThr;
	}

	public String getHrFromThrTimezone()
	{
		return this.hrFromThrTimezone;
	}

	public void setHrFromThrTimezone(String hrFromThrTimezone)
	{
		this.hrFromThrTimezone = hrFromThrTimezone;
	}

	public String getIntProductId()
	{
		return this.intProductId;
	}

	public void setIntProductId(String intProductId)
	{
		this.intProductId = intProductId;
	}

	public Date getLastUpdate()
	{
		return this.lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate)
	{
		this.lastUpdate = lastUpdate;
	}

	public String getLoadType()
	{
		return this.loadType;
	}

	public void setLoadType(String loadType)
	{
		this.loadType = loadType;
	}

	public String getMacPriAssetClass()
	{
		return this.macPriAssetClass;
	}

	public void setMacPriAssetClass(String macPriAssetClass)
	{
		this.macPriAssetClass = macPriAssetClass;
	}

	public String getMacSecAssetClass()
	{
		return this.macSecAssetClass;
	}

	public void setMacSecAssetClass(String macSecAssetClass)
	{
		this.macSecAssetClass = macSecAssetClass;
	}

	public Date getMaturityDate()
	{
		return this.maturityDate;
	}

	public void setMaturityDate(Timestamp maturityDate)
	{
		this.maturityDate = maturityDate;
	}

	public String getMixedSwap()
	{
		return this.mixedSwap;
	}

	public void setMixedSwap(String mixedSwap)
	{
		this.mixedSwap = mixedSwap;
	}

	public String getMixedSwapReportSdr()
	{
		return this.mixedSwapReportSdr;
	}

	public void setMixedSwapReportSdr(String mixedSwapReportSdr)
	{
		this.mixedSwapReportSdr = mixedSwapReportSdr;
	}

	public String getMultAssetClassSwap()
	{
		return this.multAssetClassSwap;
	}

	public void setMultAssetClassSwap(String multAssetClassSwap)
	{
		this.multAssetClassSwap = multAssetClassSwap;
	}

	public String getNonRepFin()
	{
		return this.nonRepFin;
	}

	public void setNonRepFin(String nonRepFin)
	{
		this.nonRepFin = nonRepFin;
	}

	public String getNonRepMsp()
	{
		return this.nonRepMsp;
	}

	public void setNonRepMsp(String nonRepMsp)
	{
		this.nonRepMsp = nonRepMsp;
	}

	public String getNonRepUs()
	{
		return this.nonRepUs;
	}

	public void setNonRepUs(String nonRepUs)
	{
		this.nonRepUs = nonRepUs;
	}

	public String getNonReportId()
	{
		return this.nonReportId;
	}

	public void setNonReportId(String nonReportId)
	{
		this.nonReportId = nonReportId;
	}

	public String getNonReportLei()
	{
		return this.nonReportLei;
	}

	public void setNonReportLei(String nonReportLei)
	{
		this.nonReportLei = nonReportLei;
	}

	public String getNonReptSd()
	{
		return this.nonReptSd;
	}

	public void setNonReptSd(String nonReptSd)
	{
		this.nonReptSd = nonReptSd;
	}

	public BigDecimal getNotionalAmountCpty()
	{
		return this.notionalAmountCpty;
	}

	public void setNotionalAmountCpty(BigDecimal notionalAmountCpty)
	{
		this.notionalAmountCpty = notionalAmountCpty;
	}

	public BigDecimal getNotionalAmountParty()
	{
		return this.notionalAmountParty;
	}

	public void setNotionalAmountParty(BigDecimal notionalAmountParty)
	{
		this.notionalAmountParty = notionalAmountParty;
	}

	public String getNotionalCurrencyCpty()
	{
		return this.notionalCurrencyCpty;
	}

	public void setNotionalCurrencyCpty(String notionalCurrencyCpty)
	{
		this.notionalCurrencyCpty = notionalCurrencyCpty;
	}

	public String getNotionalCurrencyParty()
	{
		return this.notionalCurrencyParty;
	}

	public void setNotionalCurrencyParty(String notionalCurrencyParty)
	{
		this.notionalCurrencyParty = notionalCurrencyParty;
	}

	public String getOptionPremium()
	{
		return this.optionPremium;
	}

	public void setOptionPremium(String optionPremium)
	{
		this.optionPremium = optionPremium;
	}

	public String getOptionStyle()
	{
		return this.optionStyle;
	}

	public void setOptionStyle(String optionStyle)
	{
		this.optionStyle = optionStyle;
	}

	public String getOptionType()
	{
		return this.optionType;
	}

	public void setOptionType(String optionType)
	{
		this.optionType = optionType;
	}

	public String getPrice()
	{
		return this.price;
	}

	public void setPrice(String price)
	{
		this.price = price;
	}

	public String getPriceCurr()
	{
		return this.priceCurr;
	}

	public void setPriceCurr(String priceCurr)
	{
		this.priceCurr = priceCurr;
	}

	public String getPriceUnit()
	{
		return this.priceUnit;
	}

	public void setPriceUnit(String priceUnit)
	{
		this.priceUnit = priceUnit;
	}

	public String getProductId()
	{
		return this.productId;
	}

	public void setProductId(String productId)
	{
		this.productId = productId;
	}

	public String getProductId1()
	{
		return this.productId1;
	}

	public void setProductId1(String productId1)
	{
		this.productId1 = productId1;
	}

	public String getProductId2()
	{
		return this.productId2;
	}

	public void setProductId2(String productId2)
	{
		this.productId2 = productId2;
	}

	public String getProductType()
	{
		return this.productType;
	}

	public void setProductType(String productType)
	{
		this.productType = productType;
	}

	public String getQantity()
	{
		return this.qantity;
	}

	public void setQantity(String qantity)
	{
		this.qantity = qantity;
	}

	public String getQantityFreq()
	{
		return this.qantityFreq;
	}

	public void setQantityFreq(String qantityFreq)
	{
		this.qantityFreq = qantityFreq;
	}

	public String getQantityUnit()
	{
		return this.qantityUnit;
	}

	public void setQantityUnit(String qantityUnit)
	{
		this.qantityUnit = qantityUnit;
	}

	public Date getReportDate()
	{
		return this.reportDate;
	}

	public void setReportDate(Timestamp reportDate)
	{
		this.reportDate = reportDate;
	}

	public String getReportFin()
	{
		return this.reportFin;
	}

	public void setReportFin(String reportFin)
	{
		this.reportFin = reportFin;
	}

	public String getReportMsp()
	{
		return this.reportMsp;
	}

	public void setReportMsp(String reportMsp)
	{
		this.reportMsp = reportMsp;
	}

	public String getReportPrtyLei()
	{
		return this.reportPrtyLei;
	}

	public void setReportPrtyLei(String reportPrtyLei)
	{
		this.reportPrtyLei = reportPrtyLei;
	}

	public String getReportSd()
	{
		return this.reportSd;
	}

	public void setReportSd(String reportSd)
	{
		this.reportSd = reportSd;
	}

	public String getReportUs()
	{
		return this.reportUs;
	}

	public void setReportUs(String reportUs)
	{
		this.reportUs = reportUs;
	}

	public String getReportingEntityPetData()
	{
		return this.reportingEntityPetData;
	}

	public void setReportingEntityPetData(String reportingEntityPetData)
	{
		this.reportingEntityPetData = reportingEntityPetData;
	}

	public String getReportingParty()
	{
		return this.reportingParty;
	}

	public void setReportingParty(String reportingParty)
	{
		this.reportingParty = reportingParty;
	}

	public String getSeller()
	{
		return this.seller;
	}

	public void setSeller(String seller)
	{
		this.seller = seller;
	}

	public String getSellerFinEnt()
	{
		return this.sellerFinEnt;
	}

	public void setSellerFinEnt(String sellerFinEnt)
	{
		this.sellerFinEnt = sellerFinEnt;
	}

	public String getSellerLei()
	{
		return this.sellerLei;
	}

	public void setSellerLei(String sellerLei)
	{
		this.sellerLei = sellerLei;
	}

	public String getSellerPayIndex()
	{
		return this.sellerPayIndex;
	}

	public void setSellerPayIndex(String sellerPayIndex)
	{
		this.sellerPayIndex = sellerPayIndex;
	}

	public String getSellerPayindexAvgMethod()
	{
		return this.sellerPayindexAvgMethod;
	}

	public void setSellerPayindexAvgMethod(String sellerPayindexAvgMethod)
	{
		this.sellerPayindexAvgMethod = sellerPayindexAvgMethod;
	}

	public String getSellerUsEnt()
	{
		return this.sellerUsEnt;
	}

	public void setSellerUsEnt(String sellerUsEnt)
	{
		this.sellerUsEnt = sellerUsEnt;
	}

	public String getSellerUsRegDesg()
	{
		return this.sellerUsRegDesg;
	}

	public void setSellerUsRegDesg(String sellerUsRegDesg)
	{
		this.sellerUsRegDesg = sellerUsRegDesg;
	}

	public String getSettlementMethod()
	{
		return this.settlementMethod;
	}

	public void setSettlementMethod(String settlementMethod)
	{
		this.settlementMethod = settlementMethod;
	}

	public String getSrcTradeId()
	{
		return this.srcTradeId;
	}

	public void setSrcTradeId(String srcTradeId)
	{
		this.srcTradeId = srcTradeId;
	}

	public Date getStartDate()
	{
		return this.startDate;
	}

	public void setStartDate(Date startDate)
	{
		this.startDate = startDate;
	}

	public String getSubmittedOnbehalfPartyIdValue()
	{
		return this.submittedOnbehalfPartyIdValue;
	}

	public void setSubmittedOnbehalfPartyIdValue(String submittedOnbehalfPartyIdValue)
	{
		this.submittedOnbehalfPartyIdValue = submittedOnbehalfPartyIdValue;
	}

	public String getTotalFreq()
	{
		return this.totalFreq;
	}

	public void setTotalFreq(String totalFreq)
	{
		this.totalFreq = totalFreq;
	}

	public Date getTradeDate()
	{
		return this.tradeDate;
	}

	public void setTradeDate(Timestamp tradeDate)
	{
		this.tradeDate = tradeDate;
	}

	public String getTradeParty1()
	{
		return this.tradeParty1;
	}

	public void setTradeParty1(String tradeParty1)
	{
		this.tradeParty1 = tradeParty1;
	}

	public String getTradeParty1Name()
	{
		return this.tradeParty1Name;
	}

	public void setTradeParty1Name(String tradeParty1Name)
	{
		this.tradeParty1Name = tradeParty1Name;
	}

	public String getTradeParty1ReferenceNumber()
	{
		return this.tradeParty1ReferenceNumber;
	}

	public void setTradeParty1ReferenceNumber(String tradeParty1ReferenceNumber)
	{
		this.tradeParty1ReferenceNumber = tradeParty1ReferenceNumber;
	}

	public String getTradeParty2()
	{
		return this.tradeParty2;
	}

	public void setTradeParty2(String tradeParty2)
	{
		this.tradeParty2 = tradeParty2;
	}

	public String getTradeParty2Name()
	{
		return this.tradeParty2Name;
	}

	public void setTradeParty2Name(String tradeParty2Name)
	{
		this.tradeParty2Name = tradeParty2Name;
	}

	public String getTvProdId()
	{
		return this.tvProdId;
	}

	public void setTvProdId(String tvProdId)
	{
		this.tvProdId = tvProdId;
	}

	public String getUsiNamespace()
	{
		return this.usiNamespace;
	}

	public void setUsiNamespace(String usiNamespace)
	{
		this.usiNamespace = usiNamespace;
	}

	public String getUsiValue()
	{
		return this.usiValue;
	}

	public void setUsiValue(String usiValue)
	{
		this.usiValue = usiValue;
	}

	public String getVerificationStatus()
	{
		return this.verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus)
	{
		this.verificationStatus = verificationStatus;
	}

}