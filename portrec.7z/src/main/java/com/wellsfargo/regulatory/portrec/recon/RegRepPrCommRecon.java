package com.wellsfargo.regulatory.portrec.recon;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCommPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrFxPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrLiveTrade;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCommPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
public class RegRepPrCommRecon {

	@Autowired
	RegRepPrCommPositionReportRepository regRepPrCommPositionReportRepository;
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	@Autowired
	RegRepPrReconHelper regRepPrReconHelper;
	
	@Value("${portrec.recon.file.Location}")
	String portrecReconFileLoc;
	
	private static Logger logger = Logger.getLogger(RegRepPrCommRecon.class);
	
	public void doCommRecon(List<RegRepPrJobExecutionDetail> jobDetail, Date asOfdate) {
		int commLiveTradeCount = 0;
		int dtccPosCount =0;
		int dtccNotMatchingPos = 0;
		
		logger.info("Starting Comm Recon ");
		List<RegRepPrLiveTrade> liveTrades = regRepPrLiveTradeRepository.findTradesBasedonAssetClass(PortrecConstants.ASSETCLASS_COMM);
			commLiveTradeCount = liveTrades.size();
		Map<String,RegRepPrCommPositionReport> dtccUSIMap = new HashMap<String, RegRepPrCommPositionReport>();
		Map<String, RegRepPrLiveTrade> regrepUSIMap = new HashMap<String, RegRepPrLiveTrade>();
			
		logger.info("Size of LiveTrades for Comm Trades "	+	commLiveTradeCount);
		
		List<RegRepPrCommPositionReport> dtccUSIList = new ArrayList<RegRepPrCommPositionReport>();;
		
		if(null != jobDetail)
		{
			long startTime = System.currentTimeMillis();
			for(RegRepPrJobExecutionDetail job : jobDetail) {
				dtccUSIList.addAll(regRepPrCommPositionReportRepository.findPositionsByDate(job));
			}
			long endTime = System.currentTimeMillis();
			logger.info("Total Time Taken to get Comm Position Counts " + (endTime - startTime));
		}
		if(null != dtccUSIList) 
		{
			dtccPosCount = dtccUSIList.size();
			logger.info("Size of Comm Positions "	+	dtccPosCount);
				for(RegRepPrCommPositionReport dtccUSI : dtccUSIList)
				{
					String usi = dtccUSI.getUsiValue();
					String submittedFor = dtccUSI.getSubmittedOnbehalfPartyIdValue();
					String tradeParty1 = dtccUSI.getBuyerLei();
					String tradeParty2 = dtccUSI.getSellerLei();
			
						if(null != usi && !submittedFor.contains("F226TOH6YD6XJB17KS62") 
								&& !tradeParty2.contains("F226TOH6YD6XJB17KS62") && !tradeParty1.contains("F226TOH6YD6XJB17KS62")) 
						{
							dtccUSIMap.put(usi, dtccUSI);
						}
				}	
		
				
				for(RegRepPrLiveTrade liveTrade : liveTrades){
					String reconCpty = liveTrade.getReconCpty();
					String usi = liveTrade.getUsi();
					if(dtccUSIMap.containsKey(usi)){
						/*removeLiveTradesList.add(liveTrade);*/
						dtccUSIMap.remove(usi);
					} else if(!reconCpty.contains("F226TOH6YD6XJB17KS62")){
						regrepUSIMap.put(liveTrade.getUsi(), liveTrade);
					}
				}
				
				dtccNotMatchingPos = dtccUSIMap.size();
				commLiveTradeCount = regrepUSIMap.size();
				logger.info("Size of Comm Positions Not matching : "	+	dtccNotMatchingPos + " And Live Trades : " + commLiveTradeCount);
				
				if(commLiveTradeCount>0){
					regRepPrReconHelper.generateliveTradeFile(PortrecConstants.ASSETCLASS_COMM, regrepUSIMap, asOfdate);
				}
				if(dtccNotMatchingPos>0){
					generateCommDtccPosFile(PortrecConstants.ASSETCLASS_COMM,dtccUSIMap, asOfdate);
				}
		}
	}
	
	private void generateCommDtccPosFile(String assetClass, Map<String, RegRepPrCommPositionReport> dtccUSIMap, Date asOfdate) {
		
		DateFormat formatter ; 
		formatter = new SimpleDateFormat("yyyyMMdd");
		String reconFileName = "DTCC_Recon_"+assetClass+"_"+ formatter.format(asOfdate) +".xls";
		
		List<String> liveTrades1 = regRepPrLiveTradeRepository.findTradesonAssetClassandQN(assetClass);
		Map<String, String> usiLiveMapN = new HashMap<String, String>();
		
		for(String liveTrade : liveTrades1){
			usiLiveMapN.put(liveTrade, assetClass);
		}
		
		File dtccFolder = new File(portrecReconFileLoc+File.separator+ asOfdate);
	   	 File irFile;
	   	 if (dtccFolder.isDirectory()) {
		   	 	 irFile = new File(dtccFolder +File.separator+reconFileName);
		 }
	   	 else {
	   		dtccFolder.mkdirs();
	   		irFile = new File(dtccFolder +File.separator+reconFileName);
	   	 }
	   	FileWriter fw = null;
		try {
			fw = new FileWriter(irFile);
			fw.append("USI").append("\t").append("SubmittedOnBehalf").append("\t").append("TradeParty1").append("\t").append("TradeParty2").append("\t").append("Comment").append('\n');
			for (Map.Entry<String, RegRepPrCommPositionReport> entry : dtccUSIMap.entrySet()) {
				String usi = entry.getKey();
				String comment = "";
								
				if(usiLiveMapN.containsKey(usi))
				{
					comment = "Trade Qualifier is Set as N in Live Trade Table";
				}
					fw.append(usi).append("\t")
					.append(entry.getValue().getSubmittedOnbehalfPartyIdValue()).append("\t")
					.append(entry.getValue().getBuyerLei()).append("\t")
					.append(entry.getValue().getSellerLei()).append("\t")
					.append(comment)
					.append('\n');
			}
			fw.close();
			
		} catch (Exception ex){
			logger.error("Error Creating DTCC IR Recon report");
		}
		logger.info("Recon report has been generated: " +  irFile.getAbsolutePath());
		
	}
}
