package com.wellsfargo.regulatory.portrec.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrUsiException;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCommPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCrPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrEqPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrFxPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrIrPositionReportRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrUsiExceptionRepository;

@Component
@ManagedResource(description = "Checking usi in position reports")
public class PrLiveTradeUtility {

	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	@Autowired
	RegRepPrIrPositionReportRepository repPrIrPositionReportRepository;
	@Autowired
	RegRepPrCrPositionReportRepository regRepPrCrPositionReportRepository;
	@Autowired
	RegRepPrEqPositionReportRepository regRepPrEqPositionReportRepository;
	@Autowired
	RegRepPrCommPositionReportRepository regRepPrCommPositionReportRepository;
	@Autowired
	RegRepPrFxPositionReportRepository regRepPrFxPositionReportRepository;

	@Autowired
	RegRepPrUsiExceptionRepository regRepPrUsiExceptionRepository;
	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	

	List<String> irUsiList = null;
	List<String> crUsiList = null;
	List<String> commUsiList = new ArrayList<String>();
	List<String> fxUsiList = null;
	List<String> eqUsiList = new ArrayList<String>();
	private final Logger logger = Logger.getLogger(PrLiveTradeUtility.class);

	RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = null;

	@ManagedOperation
	public void findLegalIDSInterestRate() {
		List<String> liveTradesUsi = new ArrayList<String>();
		List<Object[]> liveTradeDetails = regRepPrLiveTradeRepository.findUsi();

		if (!liveTradeDetails.isEmpty()) {
			for (Object[] list : liveTradeDetails) {
				String usi = (String) list[0];
				String assetClass = (String) list[1];
				liveTradesUsi.add(usi + ":" + assetClass);
			}
		}

		logger.info("Size of trades in Live trade" + liveTradesUsi.size());
		if (liveTradesUsi != null) {
			positionReportusiList(liveTradesUsi);
		}
	}

	public void positionReportusiList(List<String> liveTradesUsi) {

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailIr = regRepPrJobExecutionDetailRepository
				.findInterestRateJobExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailCr = regRepPrJobExecutionDetailRepository
				.findCreditJobExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailFx = regRepPrJobExecutionDetailRepository
				.findFxJobExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailComm = regRepPrJobExecutionDetailRepository
				.findCommodityJobExecutionIdDtcc();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailIce = regRepPrJobExecutionDetailRepository
				.findCommodityJobExecutionIdIce();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqVS = regRepPrJobExecutionDetailRepository
				.findEquityVSExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqCfd = regRepPrJobExecutionDetailRepository
				.findEquityCFDExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqEs = regRepPrJobExecutionDetailRepository
				.findEquityESExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqSp = regRepPrJobExecutionDetailRepository
				.findEquitySPExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqDs = regRepPrJobExecutionDetailRepository
				.findEquityDSExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqOp = regRepPrJobExecutionDetailRepository
				.findEquityOPTExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqFwd = regRepPrJobExecutionDetailRepository
				.findEquityFWDExecutionId();
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetailEqPo = regRepPrJobExecutionDetailRepository
 				.findEquityPOExecutionId();
		

		irUsiList = repPrIrPositionReportRepository
				.findUsiIr(regRepPrJobExecutionDetailIr);
		crUsiList = regRepPrCrPositionReportRepository
				.findUsiCr(regRepPrJobExecutionDetailCr);
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqVS));
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqCfd));
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqEs));
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqSp));
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqDs));
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqOp));
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqFwd));
		eqUsiList.addAll(regRepPrEqPositionReportRepository
				.findUsiEq(regRepPrJobExecutionDetailEqPo));
		
		commUsiList.addAll(regRepPrCommPositionReportRepository
				.findUsiComm(regRepPrJobExecutionDetailComm));
		commUsiList.addAll(regRepPrCommPositionReportRepository
				.findUsiComm(regRepPrJobExecutionDetailIce));
		fxUsiList = regRepPrFxPositionReportRepository
				.findUsiFx(regRepPrJobExecutionDetailFx);
		logger.info("Processing the records:::");
		for (String usiList : liveTradesUsi) {
			String[] parts = usiList.split(":");
			String usi = parts[0];
			String assetClass = parts[1];

			if (assetClass.equalsIgnoreCase("InterestRate")) {

				if (!irUsiList.isEmpty() && !irUsiList.contains(usi)) {
					usiException(usi, assetClass);
				}
			} else if (assetClass.equalsIgnoreCase("Credit")) {

				if (!crUsiList.isEmpty() && !crUsiList.contains(usi)) {
					usiException(usi, assetClass);
				}
			} else if (assetClass.equalsIgnoreCase("Equity")) {

				if (!eqUsiList.isEmpty() && !eqUsiList.contains(usi)) {
					usiException(usi, assetClass);
				}
			} else if (assetClass.equalsIgnoreCase("Commodity")) {

				if (!commUsiList.isEmpty() && !commUsiList.contains(usi)) {
					usiException(usi, assetClass);
				}
			} else if (assetClass.equalsIgnoreCase("ForeignExchange") || assetClass.equalsIgnoreCase("FX_INTL") ) {

				if (!fxUsiList.isEmpty() && !fxUsiList.contains(usi)) {
					usiException(usi, assetClass);
				}
			}
			
			
		}
		logger.info("Records are saved in reg_rep_pr_usi_exception table");
	}

	public void usiException(String usi, String assetClass) {
		RegRepPrUsiException regRepPrUsiException = new RegRepPrUsiException();
		regRepPrUsiException.setUsi(usi);
		regRepPrUsiException.setAssetClass(assetClass);
		regRepPrUsiException.setComments("Usi is not available");
		regRepPrUsiException.setCreateDatetime(new Date());
		regRepPrUsiExceptionRepository.save(regRepPrUsiException);
	}

}
