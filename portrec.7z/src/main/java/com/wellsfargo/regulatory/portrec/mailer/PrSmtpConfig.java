package com.wellsfargo.regulatory.portrec.mailer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

@Component
public class PrSmtpConfig extends JavaMailSenderImpl {
	
	@Value("${mail.host.portrec}") String mailHost;
	
	PrSmtpConfig(){
		super();
		setHost(mailHost);
		setPort(25);
		setUsername("");
		setPassword("");
		
		getJavaMailProperties().put("mail.transport.protocol", "smtp");
		getJavaMailProperties().put("mail.smtp.auth", true);
		getJavaMailProperties().put("mail.debug",true);
		getJavaMailProperties().put("mail.smtp.starttls.enable", true);		
		
	}
}
