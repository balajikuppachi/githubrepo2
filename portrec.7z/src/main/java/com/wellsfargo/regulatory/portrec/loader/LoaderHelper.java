package  com.wellsfargo.regulatory.portrec.loader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.common.CSVDateReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJob;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Transactional(value="portrec", propagation=Propagation.NEVER)
public abstract class LoaderHelper<T extends RegRepPrJob> {
	
	@Autowired
	RegRepPrJobDetailRepository regRepPrJobDetailRepository;
	
	@Autowired
	TransactionalLoaderService<T> transactionalLoaderService;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	CalendarService calendarService;
	
	RegRepPrJobDetail regRepPrJobDetail;

	private Logger logger = Logger.getLogger(LoaderHelper.class);
	private static int invalidTrades=0;
	
	@Value("${file.exclude.tradeparty.keywords}") String excludeKeywords;
	
	@PostConstruct
	void init() {
		List<RegRepPrJobDetail> jobDetails = regRepPrJobDetailRepository.findByjobName(getPortfolioSegmentName());
		if (jobDetails.size() != 1) {
			throw new RuntimeException("Could not initialize Portfolio Segment '" + getPortfolioSegmentName() + "'");
		}
		regRepPrJobDetail = jobDetails.get(0);
	}
	
	public abstract TradeRecordTypeEnum getRecordType();
	
	public abstract String getPortfolioSegmentName();

	public abstract DataReader<String[]> getDataReader(InputStream inputStream);
	
	public abstract T parseRecord(String[] fields, String[] excludeKeywords, Date asOfDate) throws ParseException;
	
	public abstract boolean validate(T trade);
	
	public abstract T getTableName();
	
	public abstract boolean deletePrevDayRecords();
	
	public void postLoad() {};
	
	public abstract String loadNextJob();
		
	public File read(File file) throws FileNotFoundException, IOException, ParseException, PortrecException {
		logger.info("Loading data from file: " + file);
		InputStream is = null;
		try {
			is = new FileInputStream(file);
			Date asOfDate = extractAsOfDateFromFileName(file);
			this.read(is, file.getName(), asOfDate);
		} finally {
			if (is != null) {
				is.close();
			}
		}
		
		return file;
	}
	
	public RegRepPrJobExecutionDetail read(InputStream inputStream, String fileName, Date asOfDate) throws IOException, ParseException, PortrecException{
		Boolean errors = false;
		int jobdetails = transactionalLoaderService.getPrevJobDetails(getPortfolioSegmentName(), asOfDate);
		T deletetrades = getTableName();
		if(jobdetails != 0){
			transactionalLoaderService.deleteTrades(deletetrades, asOfDate, PortrecConstants.CURRENT_DATE, jobdetails, regRepPrJobDetail.getJobDetailsId() );
		}
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = transactionalLoaderService.startLoad(fileName, regRepPrJobDetail, getRecordType(), asOfDate);
		DataReader<String[]> dataReader = getDataReader(inputStream);
		errors = loadFile(regRepPrJobExecutionDetail, dataReader, fileName, asOfDate);
		
		String src = loadNextJob();
		transactionalLoaderService.completeLoad(regRepPrJobExecutionDetail, errors, src);
		return regRepPrJobExecutionDetail;
	}
	
	boolean loadFile(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail, DataReader<String[]> reader, String fileName, Date asofDate) throws IOException, ParseException {
		
		List<T> trades = new ArrayList<T>();
		Boolean errors = false;
		
		String [] excArray = excludeKeywords.split(",");
		
		if(!deletePrevDayRecords()){
		Date prevWeekDate = calendarService.getPreviousWeekDay(new Date());
		int jobdetails = transactionalLoaderService.getPrevWeekJobDetails(getPortfolioSegmentName(), prevWeekDate);
		if (jobdetails !=0){
			T deletetrades = getTableName();
			transactionalLoaderService.deleteTrades(deletetrades, prevWeekDate, PortrecConstants.PREVIOUS_WEEK, jobdetails, regRepPrJobDetail.getJobDetailsId());
			}
		} else {
		int jobdetails = transactionalLoaderService.getPrevRunJobDetails(getPortfolioSegmentName(), new Date());
		if (jobdetails !=0){
			T deletetrades = getTableName();
			transactionalLoaderService.deleteTrades(deletetrades,  new Date(), PortrecConstants.PREVIOUS_RECORDS, jobdetails, regRepPrJobDetail.getJobDetailsId());
			}
		}		
		try {
			int i=0;
			
			String[] nextLine = null;
			String errorString = null;
			long start = System.currentTimeMillis();
			while ((nextLine = reader.readNext()) != null ) {
				if(nextLine.length > 1){
				regRepPrJobExecutionDetail.setRecordsTotal(regRepPrJobExecutionDetail.getRecordsTotal() + 1);
				try {
					T trade = parseRecord(nextLine,excArray,asofDate);
					if(validate(trade)){
						trade.setJobExecutionId(regRepPrJobExecutionDetail);
						trades.add(trade);
						regRepPrJobExecutionDetail.setRecodsLoaded(regRepPrJobExecutionDetail.getRecodsLoaded() + 1);
					}else {
						invalidTrades++;
					}
				} catch (Exception e) {
					try
					{
					errors = true;	
					errorString = "Couldn't parse record: file #" + regRepPrJobExecutionDetail.getJobExecutionId() + ", " + reader.currentLocation().asString() ;
					RegRepPrException regRepPrException = new RegRepPrException();										
					regRepPrException.setExceptionSource("LoaderHelper:1");
					regRepPrException.setJobExecutionId(regRepPrJobExecutionDetail.getJobExecutionId());
					regRepPrException.setExceptionDesc(errorString);
					regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
					regRepPrException.setExceptionTrace(ExceptionUtils.getStackTrace(e));
					regRepPrException.setCreateDatetime(new Date());
					portrecExceptionLogger.logExceptionToDB(regRepPrException);
					logger.error("Couldn't parse record: file #" + regRepPrJobExecutionDetail.getJobExecutionId() + ", " + reader.currentLocation().asString(), e);
					}
					catch(Exception ex)
					{
						logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(ex));
					}
				}
					
				if (regRepPrJobExecutionDetail.getRecodsLoaded() % 1000 == 0 && regRepPrJobExecutionDetail.getRecodsLoaded() > 0) {
					logger.info("Processed " + regRepPrJobExecutionDetail.getRecodsLoaded() + " records. Saving");
					transactionalLoaderService.saveTrades(regRepPrJobExecutionDetail, trades);
					trades.clear();
				}
			}
		}
				
			
			logger.info("Processed " + regRepPrJobExecutionDetail.getRecodsLoaded() + " records. Saving");
			transactionalLoaderService.saveTrades(regRepPrJobExecutionDetail, trades);
			long end = System.currentTimeMillis();
			logger.info("Total Time: " + (end - start));
			
			if(errors){
				logger.info("Error while Loading the file "+ regRepPrJobDetail.getJobName() +" from file: " + fileName +" as on "+new Date());
			} else {
				logger.info("Data has been Loaded for "+ regRepPrJobDetail.getJobName() +" from file: " + fileName +" as on "+new Date());
			}

		} finally {
			if (reader != null) {
				reader.close();
			}
		}
		
		postLoad();
		return errors;
	}
	
	
	Date extractAsOfDateFromFileName(File file) throws IOException {
		
		InputStream is = null;
		is = new FileInputStream(file);
		
		Date dateFormated = null;
		String fileName = file.getName();
		String datefromFIle = null;
		
		DataReader<String[]> dataReader = new CSVDateReader(is, 2);
		DataReader<String[]> dataReaderCr = new CSVDateReader(is, 1);
				
		try {
		if (fileName.startsWith(PortrecConstants.DTCC) && !fileName.contains(PortrecConstants.ICE)){
			String[] line = null;
			if(!fileName.contains(PortrecConstants.DTCC_CR))	
				line = dataReader.readNext();
			 else 
				line = dataReaderCr.readNext();
			
			if(line[0].contains(PortrecConstants.REPORT_DATE)){
				int runIndex =line[0].indexOf(PortrecConstants.REPORT_DATE);
				int runDateIndex =line[0].indexOf(PortrecConstants.REPORT_RUNDATE);
				datefromFIle=line[0].substring(runIndex, runDateIndex);
				datefromFIle=datefromFIle.replaceAll(PortrecConstants.REPORT_DATE, "").replaceAll("\\s+","").replaceAll("\"", "");
			}
		} else if (fileName.startsWith(PortrecConstants.LIVE_TRADES) || (fileName.startsWith(PortrecConstants.SRC_FX))) {
			int firstIndex = fileName.lastIndexOf("_");
			int secondIndex = fileName.indexOf(".", firstIndex + 1);
			if(secondIndex > 1){
				datefromFIle = fileName.substring(firstIndex+1, secondIndex);
			}
		} 
		else if (fileName.startsWith(PortrecConstants.ALGO_VAL)){
			int firstIndex = fileName.indexOf("_");
			int secondIndex = fileName.indexOf("_", firstIndex + 1);
			if(secondIndex > 1){
				datefromFIle = fileName.substring(firstIndex+1, secondIndex);
			}
		} else if (fileName.startsWith(PortrecConstants.DTCC_ICE)){
			int secondIndex;
			if(!fileName.contains("EOD"))
				secondIndex = fileName.indexOf(".", 17);
			else
				secondIndex = fileName.indexOf("EOD", 17);
			if(secondIndex > 1){
				datefromFIle = fileName.substring(17, secondIndex);
			}
		}
	}
		finally {
			if (dataReader != null || dataReaderCr !=null) {
				dataReader.close();
				dataReaderCr.close();
				if(datefromFIle.length()==10) {
					SimpleDateFormat sdf = new SimpleDateFormat(PortrecConstants.PORTREC_AS_OF_DATE_FORMAT);
					try {
						dateFormated = sdf.parse(datefromFIle);
						} catch (ParseException e) {
	 			logger.error("Error parsing the date " + e.getStackTrace());
	 		}
				}
				else if(datefromFIle.length()==8){
					SimpleDateFormat sdf1 = new SimpleDateFormat(PortrecConstants.PORTREC_AS_OF_DATE_FORMAT_1);
					try {
						dateFormated = sdf1.parse(datefromFIle);
						 if (fileName.startsWith(PortrecConstants.DTCC_ICE)){
							 dateFormated = calendarService.getPreviousWorkingDay(dateFormated);
						 }	
						} catch (ParseException e) {
	 			logger.error("Error parsing the date " + e.getStackTrace());
	 		}
			} else 
				dateFormated = new Date();
			
		}
		}
		logger.info("Date Loading " + dateFormated);
		return dateFormated;
		
	}
	
	public BigDecimal convertStrToBigDecimalForNotionalAmt(String notionalAmt){
		if(StringUtils.isNotBlank(notionalAmt)){
			notionalAmt=notionalAmt.trim();
			BigDecimal bDecimalValue = new BigDecimal(notionalAmt);
			bDecimalValue = bDecimalValue.stripTrailingZeros();
			int scale = bDecimalValue.scale();
			int precision = bDecimalValue.precision();    
			if (scale < 0) { // Adjust for negative scale
			    precision -= scale;
			    scale = 0;        
			}
			if(scale>4) 		return bDecimalValue.setScale(4, BigDecimal.ROUND_HALF_DOWN);
			return bDecimalValue.setScale(scale);			
		} else {
			return null;						
		}		
	}
	
	public BigDecimal stringToBigDecimal(String fixedRate){
		if(StringUtils.isNotBlank(fixedRate)){
			BigDecimal bDecimalValue = new BigDecimal(fixedRate);
			bDecimalValue = bDecimalValue.stripTrailingZeros();
			return bDecimalValue;			
		} else {
			return null;						
		}		
	}
	
	
	@Service
	@Transactional(value="portrec")
	static class TransactionalLoaderService<T extends RegRepPrJob> {
		@Autowired
		RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

		
		@PersistenceContext(unitName="Portrec")
		EntityManager entityManager;
		
		Logger logger = Logger.getLogger(getClass());
		
		public RegRepPrJobExecutionDetail startLoad(String fileName, RegRepPrJobDetail regRepPrJobDetail, TradeRecordTypeEnum recordType, Date asOfDate) {
					
			RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();
			//tradeFile.setId(new BigDecimal(10000001));
			regRepPrJobExecutionDetail.setJobDetailsId(regRepPrJobDetail);
			regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
			regRepPrJobExecutionDetail.setFileName(fileName);
			regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
			regRepPrJobExecutionDetail.setCreateDatetime( new Date());				
			
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
			
			return regRepPrJobExecutionDetail;
		}
		
		public int getPrevJobDetails(String PortfolioSegmentName, Date asofDate) {
			int jobDetail = 0;
			BigDecimal regRepPrJobExecutionDetail;
			
			try {
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.findPreviousExecutionDetail(PortfolioSegmentName, asofDate);
				if (regRepPrJobExecutionDetail != null )
					{
						jobDetail = Integer.valueOf(regRepPrJobExecutionDetail.intValue());
					}
				}
			catch (Exception ex)
			{
				logger.error("Exception getting Prev job Details " + ex.getMessage());
			}
			return jobDetail;
		}
		
		public int getPrevWeekJobDetails(String PortfolioSegmentName, Date asofDate) {
			int jobDetail = 0;
			BigDecimal regRepPrJobExecutionDetail;
			Timestamp dateTime = new Timestamp(asofDate.getTime());
			try {
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.findPreviousWeekExecutionDetail(PortfolioSegmentName, DateUtils.truncate(dateTime, Calendar.DATE));
				if (regRepPrJobExecutionDetail != null )
					{
						jobDetail = Integer.valueOf(regRepPrJobExecutionDetail.intValue());
					}
				}
			catch (Exception ex)
			{
				logger.error("Exception getting Prev job Details " + ex.getMessage());
			}
			return jobDetail;
		}
		
		public int getPrevRunJobDetails(String PortfolioSegmentName, Date asofDate) {
			int jobDetail = 0;
			BigDecimal regRepPrJobExecutionDetail;
			
			Timestamp dateTime = new Timestamp(asofDate.getTime());
	
			try {
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.findPreviousRunExecutionDetail(PortfolioSegmentName, DateUtils.truncate(dateTime, Calendar.DATE));
				if (regRepPrJobExecutionDetail != null )
					{
						jobDetail = Integer.valueOf(regRepPrJobExecutionDetail.intValue());
					}
				}
			catch (Exception ex)
			{
				logger.error("Exception getting Prev job Details " + ex.getMessage());
			}
			return jobDetail;
		}
		
		public void saveTrades(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail, Collection<T> trades) {
			for (RegRepPrJob trade : trades) {
				//tradeRepo.save(trade);
				//tradeRevisionRepo.save(trade.getTradeRevision());
				entityManager.persist(trade);
			}
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		}
		
		public void deleteTrades(T trade, Date asofDate, String value, int jobdetails, long jobdeailsID) {
			entityManager.flush();
			entityManager.clear();
						
			Class<?> clazz = trade.getClass();
			Table table = clazz.getAnnotation( Table.class );
			
			String query = null; 
			
			if(value.equals(PortrecConstants.PREVIOUS_WEEK) || value.equals(PortrecConstants.PREVIOUS_RECORDS)){
				query = "DELETE TOP 100000 FROM " + table.name() + " where job_execution_id <= :jobdetails and job_execution_id in (select "
						+ "job_execution_id from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id = :jobdeailsID)";
				logger.info("DELETING ALL RECORDS FROM " + table.name() + " TABLE BEFORE " + asofDate + " For Job Details ID : " + jobdetails);
			} else if(value.equals(PortrecConstants.CURRENT_DATE)){
				query = "DELETE TOP 100000 FROM " + table.name() + " where job_execution_id = :jobdetails and job_execution_id in (select "
						+ "job_execution_id from REG_REP_PR_JOB_EXECUTION_DETAILS where job_details_id = :jobdeailsID)";
				logger.info("DELETING ALL RECORDS FROM " + table.name() + " TABLE FOR CURRENT DATE " + asofDate + " For Job Details ID : " + jobdetails);
			}
			try{
			Query upd =  entityManager.createNativeQuery(query);
			upd.setParameter("jobdetails", jobdetails);
			upd.setParameter("jobdeailsID", jobdeailsID);
					
			int updatedCnt = 0;
			do {
				updatedCnt = upd.executeUpdate();
				logger.info("" + updatedCnt + " trades deleted");
			} while (updatedCnt>0);
			
			} catch (Exception ex)
			{
				logger.error("Exception deleting Trades " +ex.getMessage());
			}
		}
		
		public void completeLoad(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail, Boolean errors, String source) {
			regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
			
			if(regRepPrJobExecutionDetail.getRecodsLoaded() == regRepPrJobExecutionDetail.getRecordsTotal() || (!errors))
			{
				if(source!=null){
						File f = new File(source);
						try {
							f.createNewFile();
						} catch (IOException e) {
							logger.error("Exception Creating file for running CIDExtract " + e.getMessage());
						}
					}
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
				regRepPrJobExecutionDetail.getJobDetailsId();				
			}
			else
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
			}
			   
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
			logger.info(">>>>>>>>>>>>>> Excluded trades: " + invalidTrades);
		}
	}
	

	/** To Get Lei based on the - or :
	 * @param lei
	 * @return lei String
	 */
	public String getLei(String lei) {
		if (StringUtils.isNotBlank(lei)) {
			String patterns[] = { ":", "-" };
			for (int i = 0; i < patterns.length; i++) {
				if (lei.contains(patterns[i])) {
					String[] partyParts = lei.split(patterns[i]);
					if (partyParts.length == 2 && StringUtils.isNotBlank(partyParts[1]))
						lei = partyParts[1];
					else
						lei = "";
				}
			}
			return lei;
		} else
			return "";
	}
	
	}
