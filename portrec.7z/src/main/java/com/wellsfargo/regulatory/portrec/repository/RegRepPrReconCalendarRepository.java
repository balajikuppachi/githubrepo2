package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;

public interface RegRepPrReconCalendarRepository extends CrudRepository<RegRepPrReconCalendar, Long>
{
	
	@Query("select recal from RegRepPrReconCalendar recal where recal.runDate = ? and recal.reconFreq='QUARTERLY'")
	public List<RegRepPrReconCalendar>  findByRunDate(Date date);
	
	@Query("select recal from RegRepPrReconCalendar recal where recal.runDate = ?")
	public List<RegRepPrReconCalendar> findByDate(Date date);
	
	@Query("select recal from RegRepPrReconCalendar recal where recal.asOfDate = ?")
	public List<RegRepPrReconCalendar> findDate(Date date);
	
	@Query(value = "Select top 1(recal.as_of_date)  from REG_REP_PR_RECON_CALENDAR recal where recal.as_of_date < ?1 order by recal.as_of_date desc", nativeQuery = true)
	public Date findByAsOfDate(String date);
	
	@Query(value = "Select max(run_date) from REG_REP_PR_RECON_CALENDAR where run_date < ?1", nativeQuery = true)
	public Date findLastQuarterRunDate(Date todayDate);
	
	@Query(value = "Select distinct affirm_deadline_date from REG_REP_PR_RECON_CALENDAR where run_date = ?1", nativeQuery = true)
	public Date findAffirmDeadLineDate(Date affirmDeadlineDate);
	
	@Query("select recal from RegRepPrReconCalendar recal where recal.asOfDate = ? and recal.reconFreq='QUARTERLY'")
	public List<RegRepPrReconCalendar> findByAsOfDateQTR(Date date);
	

}
