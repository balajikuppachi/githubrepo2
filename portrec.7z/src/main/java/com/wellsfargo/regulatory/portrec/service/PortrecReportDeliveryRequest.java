package com.wellsfargo.regulatory.portrec.service;


import java.io.File;

import org.springframework.stereotype.Component;

public class PortrecReportDeliveryRequest {

	private String  assetClass;
	private String reportType;
	private File file;

	public PortrecReportDeliveryRequest(String assetClass,String reportType, File file) {
		this.assetClass = assetClass;
		this.reportType = reportType;
		this.file = file;
	}

	public File getFile() {
		return file;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public String getReportType() {
		return reportType;
	}
}
