package com.wellsfargo.regulatory.portrec.mailer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrExceptionDaoImpl;
import com.wellsfargo.regulatory.portrec.dao.RegRepReconReportDaoImpl;
import com.wellsfargo.regulatory.portrec.dto.PrException;
import com.wellsfargo.regulatory.portrec.dto.ReconReport;
import com.wellsfargo.regulatory.portrec.enums.CommunicationTypeEnum;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author Raji Komatreddy
 */
@Component
public class PrEmailManagerSvc
{
	@Autowired
	PrEmailTemplateService prMailingService;

	@Autowired
	PrEmailAddressValidation prEmailAddressValidation;

	@Autowired
	RegRepPrExceptionDaoImpl regRepPrExceptionDaoImpl;

	@Autowired
	RegRepReconReportDaoImpl regRepReconReportDaoImpl;

	@Value("${mail.process.flag}")
	String emailSendFlag;

	@Value("${portrec.batch.commit.size}")
	String batchSizeStr;
	
	@Value("${mail.default.email.address}")
	String defaultEmailAddress;

	List<PrException> prExceptionList = new ArrayList<PrException>();

	List<ReconReport> reconReportList = new ArrayList<ReconReport>();

	private final Logger logger = Logger.getLogger(PrEmailManagerSvc.class);

	public void sendEmailsToCptys(List<CptyReconInformation> cptyReconInformationList, Date argAsofDate, long argJobExecutionId, String argReconFreq) throws PortrecException
	{
		Date asofDate = argAsofDate;
		String reconFreq = argReconFreq;
		// RegRepPrJobExecutionDetail currJobDetails = regRepPrJobExecutionDetail;
		long jobExecutionId = argJobExecutionId;
		int legalId = 0;
		String errorString = null;
		PrException currPrException = null;
		ReconReport currReconReport = null;
		int batchSize = 0;

		if (null != batchSizeStr) batchSize = Integer.parseInt(batchSizeStr);

		else
		{
			errorString = "jobExecutionId is null inside PrEmailManagerSvc ";
			logger.error("jobExecutionId is null inside PrEmailManagerSvc ");
			throw new PortrecException("PrEmailManagerSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		if (null != cptyReconInformationList && cptyReconInformationList.size() > 0)
		{
			logger.info("insidePrEmailManagerSvc: sendEmailsToCptys method() ");

			boolean fileExceptionFlag = false;

			for (CptyReconInformation currCptyReconInformation : cptyReconInformationList)
			{
				try
				{

					legalId = currCptyReconInformation.getCidCptyId();
					currCptyReconInformation.setAsOfDate(asofDate);
					fileExceptionFlag = currCptyReconInformation.isFileExceptionFlag();
					currCptyReconInformation.setJobExecutionId(jobExecutionId);
					// Check on Frequency Type = 'Quarterly' or 'Annual'
					if (null != reconFreq && reconFreq.equalsIgnoreCase(PortrecConstants.QUARTERLY))
					{

						if (StringUtils.isBlank(currCptyReconInformation.getEmailAddress()) && StringUtils.isBlank(currCptyReconInformation.getAddressLine1()))
						{
							String errorMsg = "Quarterly Cp both email address and physical address missing";
							currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "PrEmailManagerSvc-2", errorMsg, null);
							prExceptionList.add(currPrException);

						}
						
						String validEmailAddress = prEmailAddressValidation.filterValidEmails(currCptyReconInformation.getEmailAddress());
						
						currCptyReconInformation.setEmailAddress(validEmailAddress);
						
						if (!StringUtils.isBlank(emailSendFlag) && new Boolean(emailSendFlag))
						{
							prMailingService.sendReconEmailQuarterly(currCptyReconInformation, fileExceptionFlag);
						}
						
						currCptyReconInformation.setCommunicationType(CommunicationTypeEnum.EMAIL);
					}
					else if (null != reconFreq && reconFreq.equalsIgnoreCase(PortrecConstants.ANNUAL))
					{
						
						String validEmailAddress = prEmailAddressValidation.filterValidEmails(currCptyReconInformation.getEmailAddress());
						
						currCptyReconInformation.setEmailAddress(validEmailAddress);
						
						if (!StringUtils.isBlank(currCptyReconInformation.getEmailAddress()))
						{
							if (!StringUtils.isBlank(emailSendFlag) && new Boolean(emailSendFlag))
							{
								prMailingService.sendReconEmailAnnual(currCptyReconInformation);
							}
							
							currCptyReconInformation.setCommunicationType(CommunicationTypeEnum.EMAIL);
						}
						else if (!StringUtils.isBlank(currCptyReconInformation.getAddressLine1()))
						{
							currCptyReconInformation.setCommunicationType(CommunicationTypeEnum.DUC);
						}
						else
						{
							String errorMsg = "Annual Cp email address missing or invalid. Physical address missing";
							currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "PrEmailManagerSvc-3", errorMsg, null);
							prExceptionList.add(currPrException);

							if (!StringUtils.isBlank(emailSendFlag) && new Boolean(emailSendFlag))
							{
								prMailingService.sendReconEmailAnnual(currCptyReconInformation);
							}
							
							currCptyReconInformation.setCommunicationType(CommunicationTypeEnum.EMAIL);
						}
					}

					currReconReport = preparecurrReconReport(currCptyReconInformation, jobExecutionId);
					reconReportList.add(currReconReport);

					if (reconReportList.size() > batchSize)
					{
						logger.info("before inserting records into regRepReconReport table ");
						regRepReconReportDaoImpl.batchInsertReconReport(reconReportList);
						reconReportList.clear();
					}

					if (prExceptionList.size() > batchSize)
					{
						logger.info("before inserting records into regRepPrException table ");
						regRepPrExceptionDaoImpl.batchInsertPrException(prExceptionList);
						prExceptionList.clear();
					}
				}
				catch (Exception ex)
				{
					String errorMsg = "Error occured while sending email " + ex.getMessage();
					currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "PrEmailManagerSvc-3", errorMsg, ExceptionUtils.getFullStackTrace(ex));
					prExceptionList.add(currPrException);
					continue;

				}

			}

			regRepReconReportDaoImpl.batchInsertReconReport(reconReportList);
			reconReportList.clear();

			regRepPrExceptionDaoImpl.batchInsertPrException(prExceptionList);
			prExceptionList.clear();

		}

	}

	private PrException preparePrException(long jobExecutionId, long cidId, String exceptionType, String excSource, String excDesc, String exeTrace)
	{
		PrException currPrException = new PrException();
		currPrException.setJobExecutionId(jobExecutionId);
		currPrException.setCidCptyId(cidId);
		currPrException.setExceptionType(exceptionType);
		currPrException.setExceptionSource(excSource);
		currPrException.setExceptionDesc(excDesc);
		currPrException.setExceptionTrace(exeTrace);
		currPrException.setCreateDatetime(new Date());

		return currPrException;
	}

	private ReconReport preparecurrReconReport(CptyReconInformation cptyReconInformation, long jobExecutionId)
	{
		ReconReport currReconReport = new ReconReport();
		if (null != cptyReconInformation)
		{
			currReconReport.setJobExecutionId(jobExecutionId);
			currReconReport.setCidCptyId(cptyReconInformation.getCidCptyId());
			currReconReport.setCptyType(cptyReconInformation.getCptyType());
			currReconReport.setAsOfDate(cptyReconInformation.getAsOfDate());
			currReconReport.setReconFreq(cptyReconInformation.getReconFreq());
			currReconReport.setPortfolioSize(cptyReconInformation.getPortfolioSize());
			
			//if (null != cptyReconInformation.getJsFlag()) currReconReport.setJsFlag(Integer.parseInt(cptyReconInformation.getJsFlag()));

			if(null != cptyReconInformation.getJsFlag() && cptyReconInformation.getJsFlag().equalsIgnoreCase(PortrecConstants.Y))
			{
				currReconReport.setJsFlag(1);
			}else{
				currReconReport.setJsFlag(0);
			}
			
			currReconReport.setDomInt1(cptyReconInformation.getDomIntl());
			currReconReport.setCommType(cptyReconInformation.getCommunicationType().toString());
			
			String emailAddress = cptyReconInformation.getEmailAddress();
			
			/*if(StringUtils.equalsIgnoreCase(cptyReconInformation.getReconFreq(), PortrecConstants.QUARTERLY))
			{
				if(StringUtils.isBlank(emailAddress) || !prEmailAddressValidation.validateMailPattern(emailAddress))
				{
					emailAddress = defaultEmailAddress;
				}
			}
			
			if(StringUtils.equalsIgnoreCase(cptyReconInformation.getReconFreq(), PortrecConstants.ANNUAL))
			{
				if("EMAIL".equalsIgnoreCase(cptyReconInformation.getCommunicationType().getValue())){
					
					if((StringUtils.isBlank(emailAddress) || !prEmailAddressValidation.validateMailPattern(emailAddress)))
					{
						emailAddress = defaultEmailAddress;
					}
				}
			}*/
			
			currReconReport.setEmailAddress(emailAddress);
			currReconReport.setCustomerName1(cptyReconInformation.getCustomerName1());
			currReconReport.setCustomerName2(cptyReconInformation.getCustomerName2());
			currReconReport.setAddressLine1(cptyReconInformation.getAddressLine1());
			currReconReport.setAddressLine2(cptyReconInformation.getAddressLine2());
			currReconReport.setCity(cptyReconInformation.getCity());
			currReconReport.setState(cptyReconInformation.getState());
			currReconReport.setZipCode(cptyReconInformation.getZipCode());
			currReconReport.setCountry(cptyReconInformation.getCountry());
			currReconReport.setLgleFullN(cptyReconInformation.getFullLegalName());
			currReconReport.setCreateDatetime(new Date());
		}

		return currReconReport;
	}

}
