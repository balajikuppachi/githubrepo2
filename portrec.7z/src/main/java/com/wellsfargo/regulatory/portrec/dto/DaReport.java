package com.wellsfargo.regulatory.portrec.dto;

import java.util.Date;

/**
 * @author Raji Komatreddy
 */

public class DaReport
{
	private Long daReportId;
	private long jobExecutionId;
	private long cidCptyId;
	private String cptyType;
	private Date asOfDate;
	private String reconFreq;
	private String mtValType;
	private String assetClass;
	private String fileName;
	private String affirmedFlag;
	private Date affirmDatetime;
	private String affirmComments;
	private String fileException;
	private String fileExceptionReason;
	private int portfolioSize;
	private Date createDatetime;

	public Long getDaReportId()
	{
		return daReportId;
	}

	public void setDaReportId(Long daReportId)
	{
		this.daReportId = daReportId;
	}

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public long getCidCptyId()
	{
		return cidCptyId;
	}

	public void setCidCptyId(long cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public String getCptyType()
	{
		return cptyType;
	}

	public void setCptyType(String cptyType)
	{
		this.cptyType = cptyType;
	}

	public Date getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getReconFreq()
	{
		return reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public String getMtValType()
	{
		return mtValType;
	}

	public void setMtValType(String mtValType)
	{
		this.mtValType = mtValType;
	}

	public String getAssetClass()
	{
		return assetClass;
	}

	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String getAffirmedFlag()
	{
		return affirmedFlag;
	}

	public void setAffirmedFlag(String affirmedFlag)
	{
		this.affirmedFlag = affirmedFlag;
	}

	public Date getAffirmDatetime()
	{
		return affirmDatetime;
	}

	public void setAffirmDatetime(Date affirmDatetime)
	{
		this.affirmDatetime = affirmDatetime;
	}

	public String getAffirmComments()
	{
		return affirmComments;
	}

	public void setAffirmComments(String affirmComments)
	{
		this.affirmComments = affirmComments;
	}

	public String getFileException()
	{
		return fileException;
	}

	public void setFileException(String fileException)
	{
		this.fileException = fileException;
	}

	public String getFileExceptionReason()
	{
		return fileExceptionReason;
	}

	public void setFileExceptionReason(String fileExceptionReason)
	{
		this.fileExceptionReason = fileExceptionReason;
	}

	public int getPortfolioSize()
	{
		return portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public Date getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

}
