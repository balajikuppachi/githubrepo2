package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrIrPositionReport;
import com.wellsfargo.regulatory.portrec.mailer.PrExtractsTo;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrIrPositionReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class IrCptyCsvGenerator {
	
	private final Logger logger = Logger.getLogger(IrCptyCsvGenerator.class);

	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	@Autowired
	RegRepPrIrPositionReportRepository repPrIrPositionReportRepository;
	
	@Autowired
	IrDataCsvWriter irDataCsvWriter;
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;
	
	public PrExtractsTo createFile(List<String> counterPartyLeiList, Long legalId, Date asOfDate, String frequency) throws Exception {
		
		boolean irFileFlag = false;
		PrExtractsTo reportProp = new PrExtractsTo();
		reportProp.setAssetClass(PortrecConstants.IR);
		
		boolean maskingFlag = portRecBusinessUtil.isCptyMaskingRequired(frequency);
		
		StringBuilder irMtFileNameBuffer = new StringBuilder();
		
		irMtFileNameBuffer.append(PortrecConstants.IR_MT_FILE_INITIAL).append(PortrecConstants.UNDERSCORE).append(legalId).append(PortrecConstants.UNDERSCORE).append(PortRecUtil.convertDateToString_yyyyMdd(asOfDate)).
		append(PortrecConstants.UNDERSCORE).append(frequency.toUpperCase().charAt(0)).append(PortrecConstants.EXTN_CSV);

		String irMtFileName = irMtFileNameBuffer.toString();
		
		File irMtFile  = new File(outputFolderName, irMtFileName);
		
		List<RegRepPrIrPositionReport> cptyIrPositionsByLegalId = null;
	
		for(String counterPartyLei : counterPartyLeiList){
			
			List<RegRepPrIrPositionReport> cptyIrPositionsByLei = null;
			
			if(null != counterPartyLei){
				cptyIrPositionsByLei = repPrIrPositionReportRepository.findCptyPositionsByLeiAndDate(asOfDate,counterPartyLei,counterPartyLei);
			}
			
			if(null != cptyIrPositionsByLei && cptyIrPositionsByLei.size() > 0) {
				logger.info("Number of Cpty IR Dtcc Positions :["+ cptyIrPositionsByLei.size() + "] with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
				irFileFlag = true;
				
				if(!irMtFile.exists()){
					irMtFile.mkdirs();
				}
				
				if(null == cptyIrPositionsByLegalId){
					cptyIrPositionsByLegalId = new ArrayList<RegRepPrIrPositionReport>();
				}
				cptyIrPositionsByLegalId.addAll(cptyIrPositionsByLei);
				
			}else{
				logger.info("No records found for Cpty IR Dtcc Position with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
		}
		
		if(irFileFlag)
		{
			int irCount = generateMTFile(cptyIrPositionsByLegalId, irMtFile, maskingFlag);
			reportProp.setIrCount(irCount);
			
			if(irCount > 0){
				reportProp.setIrMtFileName(irMtFileName);
				logger.info("IR MT generated at  "+ outputFolderName);	
			}
			
		}
		
		reportProp.setFlag(irFileFlag);
		
		return reportProp;
	}
	
	private int generateMTFile(List<RegRepPrIrPositionReport> cptyIrPositionsByLegalId, File irMtFile, boolean maskingFlag) throws Exception 
	{
		Map<String,RegRepPrIrPositionReport> tradeMap = new ConcurrentHashMap<String,RegRepPrIrPositionReport>();
		int count = 0;
		
		try{
			for(RegRepPrIrPositionReport irPositionReport:cptyIrPositionsByLegalId)
			{
				RegRepPrIrPositionReport trade = new RegRepPrIrPositionReport();
				BeanUtils.copyProperties(irPositionReport, trade);
				tradeMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			irDataCsvWriter.generateFile(irMtFile, tradeMap,"DTCC", maskingFlag);
		}
		catch(Exception ce){
			throw ce;
		}
		
		count = tradeMap.size();
		
		return count;
	}

}
