package com.wellsfargo.regulatory.portrec.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCid;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;

/**
 * 
 * @author Raji Komatreddy Repository to save or get data from RegRepPrCid table
 */
@Repository
public interface RegRepPrCidRepository extends
		CrudRepository<RegRepPrCid, Long> {

	@Query("Select cid from RegRepPrCid cid where cid.lgleIdC = ?1 ")
	List<RegRepPrCid> findByLegalId(int lgleIdC);
	
	@Query("Select cid from RegRepPrCid cid order by cid.systemC DESC")
	List<RegRepPrCid> findAllFromCid();
	
	@Query("Select cid from RegRepPrCid cid where cid.qualifier = 'Y' order by cid.systemC DESC")
	List<RegRepPrCid> findAllFromCidWhereQualifierY();

	/*@Query("Select DISTINCT cid.lei from RegRepPrCid cid where cid.lei != 'KB1H1DSPRFMYMCUFXT09' and cid.lei != null and cid.lgleIdC = ?1 ")
	List<String> findLeiByLegalId(int lgleIdC);*/
	
	@Query("Select DISTINCT cid.lei from RegRepPrCid cid where cid.lei != null and cid.lgleIdC = ?1 ")
	List<String> findLeiByLegalId(int lgleIdC);

	/*@Query("Select distinct(cid.lgleIdC),cid.lgleFullN,cpr.cidCptyId,cid.deliveryPortfolioDataEmail,cpr.reconFreq,cpr.portfolioSize,cpr.cptyType,cid.emailaddress from RegRepPrCid cid,RegRepPrCptyReconFreq cpr where cpr.cidCptyId=cid.lgleIdC and cpr.reconFreq =?1")
	List<Object []> leiDetails(String reconFreq);*/
	
	
	
	/*@Query(value = "Select top 1(cid.lgle_id_c),cid.lgle_full_n,cpr.cid_cpty_id,cid.deliveryPortfolioDataEmail,cpr.recon_freq,cpr.portfolio_size,cpr.cpty_type,cid.emailaddress from REG_REP_PR_CID cid,REG_REP_PR_CPTY_RECON_FREQ cpr where cpr.cid_cpty_id=cid.lgle_id_c and cpr.recon_freq =?1", nativeQuery = true)
	List<Object []> leiDetails(String reconFreq);*/
	
	/*@Query("Select distinct(cid.lgleIdC),cid.lgleFullN,regrepdr.cptyType,regrepdr.portfolioSize,regrepdr.reconFreq,regrepdr.assetClass,regrepdr.mtValType,regrep.emailAddress from RegRepPrCid cid,RegRepPrDaReport regrepdr,RegRepPrReconReport regrep where regrepdr.cidCptyId=cid.lgleIdC and regrep.cidCptyId=regrepdr.cidCptyId and regrepdr.reconFreq =?1 and regrepdr.regRepPrJobExecutionDetail=?2")
	List<Object []> leicptyDetails(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);*/
	
	@Query("Select distinct(regrepdr.cidCptyId),regrep.lgleFullN,regrepdr.cptyType,regrepdr.portfolioSize,regrepdr.reconFreq,regrepdr.assetClass,regrepdr.mtValType,regrep.emailAddress,regrep.jsFlag from RegRepPrDaReport regrepdr,RegRepPrReconReport regrep where regrepdr.cidCptyId=regrep.cidCptyId and regrepdr.reconFreq =?1 and regrepdr.regRepPrJobExecutionDetail=regrep.regRepPrJobExecutionDetail and regrep.regRepPrJobExecutionDetail=?2 and regrepdr.fileName!=''")
	List<Object []> leicptyDetails(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);
	
	/*@Query(value ="Select top 1 (cid.lgle_id_c),cid.lgle_full_n,cid.deliveryPortfolioDataEmail,regrepdr.cpty_type,regrepdr.portfolio_size,regrepdr.recon_freq,regrepdr.asset_class,regrepdr.mt_val_type,cid.emailaddress from REG_REP_PR_CID cid,REG_REP_PR_DA_REPORT regrepdr where regrepdr.cid_cpty_id=cid.lgle_id_c and regrepdr.recon_freq =?1 and regrepdr.job_execution_id=?2",nativeQuery = true)
	List<Object []> leicptyDetails(String reconFreq,RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);*/
	
	@Query("Select DISTINCT cid.busAIdC from RegRepPrCid cid")
	List<Integer> findDistinctBAID();
	
	@Query("Select DISTINCT cid.busAIdC from RegRepPrCid cid where cid.lgleIdC = ?1 ")
	List<Integer> findBAIDByLegalId(int lgleIdC);
	
}
