package com.wellsfargo.regulatory.portrec.mailer;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.mail.internet.MimeMessage;

/*import microsoft.exchange.webservices.data.property.complex.EmailAddress;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import microsoft.exchange.webservices.data.credential.WebCredentials;*/


import microsoft.exchange.webservices.data.EmailAddress;
import microsoft.exchange.webservices.data.EmailMessage;
import microsoft.exchange.webservices.data.ExchangeCredentials;
import microsoft.exchange.webservices.data.ExchangeService;
import microsoft.exchange.webservices.data.ExchangeVersion;
import microsoft.exchange.webservices.data.MessageBody;
import microsoft.exchange.webservices.data.WebCredentials;



import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;

/**
 * @author u235720
 *
 */
@Component
public class PrEmailSenderService {

	Logger logger = Logger.getLogger(PrEmailSenderService.class);

	@Autowired
	private PrSmtpConfig prSMTPConfig;

	@Autowired
	PrEmailAddressValidation emailAddressValidation;
	
	private boolean attachReqFlag = false;

	@Autowired
	private VelocityEngine velocityEngine;
	
	@Autowired
	SecureDBPwdFactory secureDBPwdFactory;

	@Value("${mail.from.portrec}")		String mailFromPortrec;
	@Value("${mail.cc.portrec}")		String mailCCPortrec;
	@Value("${mail.bcc.portrec}")		String mailBCCPortrec;
	@Value("${mail.replyto.portrec}")	String mailReplyToPortrec;

	@Value("${mail.userid.portrec}")	String userId;
	@Value("${mail.password.portrec}")	String passwd;
	@Value("${mail.domain.portrec}")	String domain;
	@Value("${mail.uri.portrec}")		String uri;
	
	public void sendEmailThroughSMTP(String subject, String toEmailAddress, Map<String, String> attachmentDetails, String template, Map<String, Object> templateDataMap) {
		sendEmailBySMTP(subject, mailFromPortrec, toEmailAddress, mailCCPortrec, mailBCCPortrec, mailReplyToPortrec,attachmentDetails, template, templateDataMap);
	}

	private void sendEmailBySMTP(String subject, String from, String to, String cc, String bcc, String replyTo,	Map<String, String> attachmentDetails, String template,	Map<String, Object> templateDataMap) {
		
		logger.info("Started sending emails using SMTP server - ");
		
		String[] toArr = null;
		String[] toCCArr = null;
		String[] toBCCArr = null;

		if (!IsNullOrBlank(to))
			toArr = to.split(",");
		if (!IsNullOrBlank(cc))
			toCCArr = cc.split(",");
		if (!IsNullOrBlank(bcc))
			toBCCArr = bcc.split(",");

		try {
			MimeMessage message = prSMTPConfig.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			String body = VelocityEngineUtils.mergeTemplateIntoString(
					velocityEngine, "template/" + template, "UTF-8",
					templateDataMap);
			helper.setSubject(subject);
			helper.setText(body, true);
			if (toArr != null)
				helper.setTo(toArr);
			if (toCCArr != null)
				helper.setCc(toCCArr);
			if (toBCCArr != null)
				helper.setBcc(toBCCArr);
			if (StringUtils.isNotBlank(replyTo))
				helper.setReplyTo(replyTo);

			if (null != attachmentDetails) {
				for (String fileName : attachmentDetails.keySet()) {
					if (!StringUtils.isBlank(fileName)) {
						String filePath = attachmentDetails.get(fileName);
						File fileToBeAttached = new File(filePath, fileName);
						FileSystemResource file = new FileSystemResource(
								fileToBeAttached);
						if (file.exists()) {
							helper.addAttachment(fileName, fileToBeAttached);
						}
					}
				}
			}

			prSMTPConfig.send(message);
			logger.info("Mail Sent :" + subject);
		} catch (Exception me) {
			logger.info("Error in Sending Mail" + me);
		}
		
		logger.info("Completed sending emails using SMTP server - ");

	}

	public static final boolean IsNullOrBlank(Object obj) {

		if (obj instanceof String) {
			return ((String) obj).trim().length() == 0;
		} else if (obj == null) {
			return true;
		} else
			return false;
	}

	public static final boolean IsListNullOrEmpty(List<?> obj) {
		return (obj == null) || (((List<?>) obj).isEmpty());
	}
	
	private ExchangeService getExchangeService() {
    	logger.info("Connecting Exchange Server... ");
    	
    	/*** Below properties are ONLY for DEBUGGING SSL Certificate HandShake ***/
    	//System.setProperty("javax.net.debug", "ssl");
		//System.setProperty("javax.net.debug", "all");
		//System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
		//System.setProperty("javax.net.debug", "ssl,handshake");
    	
    	ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
    	String decryptedPassword = secureDBPwdFactory.getPassword(passwd.trim());
		ExchangeCredentials credentials = new WebCredentials(userId.trim(), decryptedPassword, domain.trim());
		service.setCredentials(credentials);
		/*service.setTraceEnabled(Boolean.TRUE);
		service.setTraceFlags(EnumSet.allOf(TraceFlags.class));*/
		
		logger.info("Exchange Connected..");
		
		/*** DEBUG Purpose ***/
		//service.setTraceEnabled(Boolean.TRUE);
		//service.setTimeout(6000000);
		//service.setAcceptGzipEncoding(Boolean.TRUE);
		
		
		try 
		{
			service.setUrl(new URI(uri));
		} 
		catch (URISyntaxException e) 
		{
			throw new RuntimeException(e);
		} 
		catch (Exception e) 
		{
			throw new RuntimeException(e);
		}
		
		return service;
	}
	
	public void sendEmailThroughExchangeServer(String subject, String toEmailAddress,  Map<String, String> attachmentDetails, String template, Map<String, Object> templateDataMap) {
		
		sendEmailByEWS(subject, mailFromPortrec, toEmailAddress, mailCCPortrec, mailBCCPortrec, mailReplyToPortrec, attachmentDetails, template, templateDataMap);
	}

	private void sendEmailByEWS(String mailSubject, String fromEmailAddresses,String toEmailAddresses, String ccAddresses, String bccAddresses, String replyToAddresses,
			final Map<String, String> attachmentDetails, final String templateRequired, final Map<String, Object> modelMap) {
		
		logger.info("Started sending emails using exchange server - ");
		
		boolean attachFilePresentFlag = false;
		boolean sendMail = false;
		ExchangeService service = getExchangeService();
		List<EmailAddress> toAddresses = new ArrayList<EmailAddress>();
		if (service == null) {
			throw new RuntimeException("ExchangeService can not be null");
		}
		EmailMessage msg;
		try {
			msg = new EmailMessage(service);
			msg.setSubject(mailSubject);
			String body = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "template/" + templateRequired, "UTF-8",	modelMap);
			msg.setBody(new MessageBody(body));
			StringBuffer emailBodyBuffer = new StringBuffer();
			emailBodyBuffer = new StringBuffer(body);
			if (toEmailAddresses.contains(";")) {
				StringTokenizer strToEmailTokenizer = new StringTokenizer(toEmailAddresses, ";");
				while (strToEmailTokenizer.hasMoreElements()) 
				{
					String emailAddress = strToEmailTokenizer.nextToken();
					if (emailAddressValidation.validate(emailAddress)) {
						sendMail = true;
						toAddresses.add(new EmailAddress(emailAddress));
					}
				}
				Iterator<EmailAddress> toEmailAddressesItr = toAddresses.iterator();
				msg.getToRecipients().addEmailRange(toEmailAddressesItr);
			} else {
				if (emailAddressValidation.validate(toEmailAddresses)) {
					sendMail = true;
					msg.getToRecipients().add(new EmailAddress(toEmailAddresses));
				}
			}
			List<EmailAddress> ccMailAddresses = new ArrayList<EmailAddress>();
			if (StringUtils.isNotBlank(ccAddresses))
				if (ccAddresses.contains(";")) {
					StringTokenizer strToEmailTokenizer = new StringTokenizer(ccAddresses, ";");
					while (strToEmailTokenizer.hasMoreElements()) {
						String emailAddress = strToEmailTokenizer.nextToken();
						if (emailAddressValidation.validate(emailAddress)) {
							ccMailAddresses.add(new EmailAddress(emailAddress));
						}
					}

					Iterator<EmailAddress> emailAddresses = ccMailAddresses.iterator();
					msg.getCcRecipients().addEmailRange(emailAddresses);
				} else {
					if (emailAddressValidation.validate(ccAddresses)) {
						ccMailAddresses.add(new EmailAddress(ccAddresses));
						msg.getCcRecipients().add(new EmailAddress(ccAddresses));
					}
				}
			
			List<EmailAddress> replyToMailAddresses = new ArrayList<EmailAddress>();
			if(StringUtils.isNotBlank(replyToAddresses)) 
				if (replyToAddresses.contains(";")) {
					StringTokenizer strToEmailTokenizer = new StringTokenizer(replyToAddresses, ";");
					while (strToEmailTokenizer.hasMoreElements()) {
						String emailAddress = strToEmailTokenizer.nextToken();
						if (emailAddressValidation.validate(emailAddress)) {
							replyToMailAddresses.add(new EmailAddress(emailAddress));
						}
					}
					Iterator<EmailAddress> emailAddresses = replyToMailAddresses.iterator();
						msg.getReplyTo().addEmailRange(emailAddresses);
				} else {
					if (emailAddressValidation.validate(replyToAddresses)) {
						replyToMailAddresses.add(new EmailAddress(replyToAddresses));
						msg.getReplyTo().add(new EmailAddress(replyToAddresses));
					}
				}
			
			
			if (null != attachmentDetails)
				for (String fileName : attachmentDetails.keySet()) {
					if (!StringUtils.isBlank(fileName)) {
						String filePath = attachmentDetails.get(fileName);
						File fileToBeAttached = new File(filePath, fileName);
						FileSystemResource file = new FileSystemResource(fileToBeAttached);
						if (file.exists()) {
							attachFilePresentFlag = true;
							msg.getAttachments().addFileAttachment(fileName,file.getInputStream());
						}
					}
				}
			if (sendMail && (!attachReqFlag || (attachReqFlag && attachFilePresentFlag))) {
				logger.info("Sending email 1 ..  ");
				msg.sendAndSaveCopy();
				logger.info("Sending email 2 .. ");
			}
		} catch (Exception e) {
			logger.error("Error message while sending email :" + e.getMessage());
			logger.error("Error while sending email :", e);
			throw new RuntimeException(e);
		} finally {
			logger.info("Inside finally block :  ");
		}
		
		logger.info("Completed sending emails using exchange server - ");
	}

}
