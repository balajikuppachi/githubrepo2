package com.wellsfargo.regulatory.portrec.mailer;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.httpclient.util.ExceptionUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrDaReportDaoImpl;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrExceptionDaoImpl;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrPositionReconDaoImpl;
import com.wellsfargo.regulatory.portrec.dto.DaReport;
import com.wellsfargo.regulatory.portrec.dto.PositionRecon;
import com.wellsfargo.regulatory.portrec.dto.PrException;
import com.wellsfargo.regulatory.portrec.enums.FileExceptionReasonEnum;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCidRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 */
@Component
public class CptyExtractGeneratorService
{

	private final Logger logger = Logger.getLogger(CptyExtractGeneratorService.class);

	@Autowired
	CptyMaterialTermGenerator cptyMaterialTermGenerator;

	@Autowired
	CptyValuationGenerator cptyValuationGenerator;

	@Autowired
	RegRepPrCidRepository regRepPrCidRepository;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;

	@Autowired
	CptyPositionReconService cptyPositionReconService;

	@Autowired
	CptyDerivativeAccessService prCptyDerivativeAccessService;

	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;

	@Value("${exception.stamping.flag}")
	String exceptionStampingFlagStr;

	@Autowired
	RegRepPrExceptionDaoImpl regRepPrExceptionDaoImpl;

	@Autowired
	RegRepPrPositionReconDaoImpl regRepPrPositionReconDaoImpl;

	@Autowired
	RegRepPrDaReportDaoImpl regRepPrDaReportDaoImpl;

	@Value("${portrec.batch.commit.size}")
	String batchSizeStr;

	List<PrException> prExceptionList = new ArrayList<PrException>();
	List<PositionRecon> positionReconList = new ArrayList<PositionRecon>();
	List<DaReport> daReportList = new ArrayList<DaReport>();

	List<CptyReconInformation> cptyReconInformationList = new ArrayList<CptyReconInformation>();

	public List<CptyReconInformation> generateExtracts(List<CptyReconInformation> prCptyInformationList, HashMap<String, List<Integer>> leiMullLegalID, long argJobExecutionId, String argReconFreq,
	        Date argAsofDate)
	{
		logger.info("inside CptyExtractGeneratorService generateExtracts Extracts method ");
		long jobExecutionId = argJobExecutionId;
		String reconFreq = argReconFreq;
		Date asOfDate = argAsofDate;
		int batchSize = 0;
		if (null != batchSizeStr) batchSize = Integer.parseInt(batchSizeStr);

		PrException currPrException = null;

		if (null != prCptyInformationList && prCptyInformationList.size() > 0)
		{
			for (CptyReconInformation currCptyReconInformation : prCptyInformationList)
			{
				logger.info("Start generating Extracts (MT & VAL) - legal Id = [" + currCptyReconInformation.getCidCptyId() + "]");

				PrExtractsTo mtExtractsTo = new PrExtractsTo();
				PrExtractsTo valExtractsTo = new PrExtractsTo();
				boolean fileExceptionFlag = true;
				long legalId = Long.valueOf(currCptyReconInformation.getCidCptyId());

				List<Integer> listofLegalIDs = new ArrayList<Integer>();
				try
				{

					// get Lei list from live trade table based on Legal ID which are recon_eligible
					List<String> listOfLeis = regRepPrLiveTradeRepository.findReconCptyByLegalId(currCptyReconInformation.getCidCptyId());

					if (null != listOfLeis && !listOfLeis.isEmpty())
					{

						logger.info("Number of leis : " + listOfLeis.size());
						mtExtractsTo = cptyMaterialTermGenerator.generateMeterialTermFiles(listOfLeis, legalId, asOfDate, reconFreq, jobExecutionId);

					}
					else
					{
						String errorMsg = "No LEI mapped to Cp in LIVE TRADE TABLE";
						currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-1", errorMsg, null);
						prExceptionList.add(currPrException);
					}

					try
					{
						boolean exists = false;
						for (String lei : listOfLeis)
						{
							if (leiMullLegalID.containsKey(lei))
							{
								List<Integer> lglID = leiMullLegalID.get(lei);
								Iterator<Integer> itr = lglID.iterator();
								while (itr.hasNext())
								{
									Integer element = itr.next();
									listofLegalIDs.add(element);
									if (element == legalId)
									{
										exists = true;
									}
								}
							}
						}
						if (exists == false)
						{
							listofLegalIDs = null;
						}

					}
					catch (Exception exception)
					{
						String errorMsg = "Error getting List of LEI's for Valuations";
						currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-2", errorMsg, ExceptionUtils.getFullStackTrace(exception));
						prExceptionList.add(currPrException);
						continue;
					}

					valExtractsTo = cptyValuationGenerator.generateValuationFile(legalId, asOfDate, reconFreq, jobExecutionId, listofLegalIDs);

					fileExceptionFlag = validateCptyPositions(mtExtractsTo, valExtractsTo, currCptyReconInformation, jobExecutionId);
					currCptyReconInformation.setFileExceptionFlag(fileExceptionFlag);

					cptyReconInformationList.add(currCptyReconInformation);

					if (positionReconList.size() > batchSize)
					{
						logger.info("before inserting records into regRepReconReport table ");
						regRepPrPositionReconDaoImpl.batchInsertPositionRecon(positionReconList);
						positionReconList.clear();
					}

					if (daReportList.size() > batchSize)
					{
						logger.info("before inserting records into regRepReconReport table ");
						regRepPrDaReportDaoImpl.batchInsertDaReport(daReportList);
						daReportList.clear();
					}
					if (prExceptionList.size() > batchSize)
					{
						logger.info("before inserting records into regRepPrException table ");
						regRepPrExceptionDaoImpl.batchInsertPrException(prExceptionList);
						prExceptionList.clear();
					}

				}
				catch (Exception exception)
				{
					String errorMsg = "Error generating MT and VAL";
					currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-3", errorMsg, ExceptionUtils.getFullStackTrace(exception));
					prExceptionList.add(currPrException);
					continue;					
				}

			//	long timeEnd = System.currentTimeMillis();
				logger.info("End generating Extracts (MT & VAL) - ");
			//	logger.info("Total time taken in MT VAL generation Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));

			}

			try
			{
				regRepPrPositionReconDaoImpl.batchInsertPositionRecon(positionReconList);
				positionReconList.clear();

				regRepPrDaReportDaoImpl.batchInsertDaReport(daReportList);
				daReportList.clear();

				regRepPrExceptionDaoImpl.batchInsertPrException(prExceptionList);
				prExceptionList.clear();

			}
			catch (Exception excep)
			{
				logger.error("Exception occurred while saving to DB" + ExceptionUtils.getFullStackTrace(excep));

			}

		}

		return cptyReconInformationList;

	}

	private boolean validateCptyPositions(PrExtractsTo mtExtractsTo, PrExtractsTo valExtractsTo, CptyReconInformation prCptyInformation, long argjobExecutionId)
	{

		boolean fileExceptionFlag = true;
		int legalId = prCptyInformation.getCidCptyId();
		long longLegalId = Long.valueOf(legalId);
		Date asOfDate = prCptyInformation.getAsOfDate();
		String cptyType = prCptyInformation.getCptyType();
		String reconFreq = prCptyInformation.getReconFreq();
		long jobExecutionId = argjobExecutionId;
		PositionRecon currPositionRecon = null;
		PrException currPrException = null;
		DaReport currDaReport = null;

		Boolean exceptionStampingFlag = true;

		if (!StringUtils.isBlank(exceptionStampingFlagStr))
		{
			exceptionStampingFlag = new Boolean(exceptionStampingFlagStr);
		}

		try
		{
			int valCount = valExtractsTo.getValCount();
			String valFileName = valExtractsTo.getValFileName();

			int irCount = mtExtractsTo.getIrCount();
			String irMtFileName = mtExtractsTo.getIrMtFileName();

			int crCount = mtExtractsTo.getCrCount();
			String crMtFileName = mtExtractsTo.getCrMtFileName();

			int eqCount = mtExtractsTo.getEqCount();
			String eqMtFileName = mtExtractsTo.getEqMtFileName();

			int fxCount = mtExtractsTo.getFxCount();
			String fxMtFileName = mtExtractsTo.getFxMtFileName();

			int cmCount = mtExtractsTo.getComCount();
			String cmMtFileName = mtExtractsTo.getComMtFileName();

			int totalMtCount = mtExtractsTo.getTotalMtCount();

			try
			{
				// Persist into Position Table
				currPositionRecon = preparePositionRecon(legalId, asOfDate, reconFreq, totalMtCount, irCount, crCount, eqCount, fxCount, cmCount, valCount, jobExecutionId);
				positionReconList.add(currPositionRecon);

			}
			catch (Exception exception)
			{
				String errorMsg = "Error saving MT and VAL counts";

				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-3", errorMsg, ExceptionUtils.getFullStackTrace(exception));
				prExceptionList.add(currPrException);
				// portrecExceptionLogger.logExceptionScenario("CptyExtractGeneratorService-3",
				// errorMsg, exception, jobExecutionId, longLegalId);
			}

			if (prCptyInformation.getIrSize() != irCount)
			{
				String errorMsg = "IR_COUNT_MISMATCH : POSITION_RECON vs CPTY_RECON_FREQ";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-4", errorMsg, null);
				prExceptionList.add(currPrException);			
			}

			if (prCptyInformation.getCrSize() != crCount)
			{
				String errorMsg = "CR_COUNT_MISMATCH : POSITION_RECON vs CPTY_RECON_FREQ";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-5", errorMsg, null);
				prExceptionList.add(currPrException);			
			}

			if ((prCptyInformation.getFxSize() + prCptyInformation.getFxIntlSize()) != fxCount)
			{
				String errorMsg = "FX_COUNT_MISMATCH : POSITION_RECON vs CPTY_RECON_FREQ";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-6", errorMsg, null);
				prExceptionList.add(currPrException);			
			}

			if (prCptyInformation.getEquitySize() != eqCount)
			{
				String errorMsg = "EQ_COUNT_MISMATCH : POSITION_RECON vs CPTY_RECON_FREQ";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-7", errorMsg, null);
				prExceptionList.add(currPrException);			
			}

			if (prCptyInformation.getCommoditySize() != cmCount)
			{
				String errorMsg = "COMM_COUNT_MISMATCH : POSITION_RECON vs CPTY_RECON_FREQ";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-8", errorMsg, null);
				prExceptionList.add(currPrException);			
			}

			String fileException = null;
			String fileExceptionReason = null;

			if (totalMtCount == 0 && valCount == 0)
			{
				fileException = PortrecConstants.EXCEPTION;
				fileExceptionReason = FileExceptionReasonEnum.NO_MT_VAL.getValue();
				fileExceptionFlag = true;

				String errorMsg = "NO_MT_VAL";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-9", errorMsg, null);
				prExceptionList.add(currPrException);				

			}
			else if (totalMtCount > 0 && valCount == 0)
			{
				fileException = PortrecConstants.EXCEPTION;
				fileExceptionReason = FileExceptionReasonEnum.NO_VAL.getValue();
				fileExceptionFlag = true;

				String errorMsg = "NO_VAL";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-10", errorMsg, null);
				prExceptionList.add(currPrException);				

			}
			else if (totalMtCount == 0 && valCount > 0)
			{
				fileException = PortrecConstants.EXCEPTION;
				fileExceptionReason = FileExceptionReasonEnum.NO_MT.getValue();
				fileExceptionFlag = true;

				String errorMsg = "NO_MT";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-11", errorMsg, null);
				prExceptionList.add(currPrException);			

			}
			else if (totalMtCount > 0 && valCount > 0 && totalMtCount > valCount)
			{
				fileException = PortrecConstants.EXCEPTION;
				fileExceptionReason = FileExceptionReasonEnum.MT_COUNT_GREATER_THAN_VAL_COUNT.getValue();
				fileExceptionFlag = true;

				String errorMsg = "MT_COUNT_GREATER_THAN_VAL_COUNT. Total MT count is greater than VAL count";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-12", errorMsg, null);
				prExceptionList.add(currPrException);			

			}
			else if (totalMtCount > 0 && valCount > 0 && totalMtCount < valCount)
			{
				fileException = PortrecConstants.VALID;
				fileExceptionReason = PortrecConstants.BLANK;
				fileExceptionFlag = false;

				String errorMsg = "MT_VAL_COUNT_MISMATCH. TOTAL MT count is less than VAL count";
				currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-13", errorMsg, null);
				prExceptionList.add(currPrException);			

			}
			else if (totalMtCount > 0 && valCount > 0 && totalMtCount == valCount)
			{
				fileException = PortrecConstants.VALID;
				fileExceptionReason = PortrecConstants.BLANK;
				fileExceptionFlag = false;
			}

			if (!exceptionStampingFlag && StringUtils.equalsIgnoreCase(fileExceptionReason, FileExceptionReasonEnum.NO_MT_VAL.getValue()))
			{
				fileException = PortrecConstants.VALID;
				fileExceptionReason = PortrecConstants.BLANK;
				fileExceptionFlag = true;
			}
			else if (!exceptionStampingFlag)
			{
				fileException = PortrecConstants.VALID;
				fileExceptionReason = PortrecConstants.BLANK;
				fileExceptionFlag = false;
			}

			if (null != valFileName && valCount > 0)
			{
				currDaReport = prepareDaReport(asOfDate, PortrecConstants.ALL, longLegalId, valFileName, cptyType, PortrecConstants.VAL, reconFreq, fileException, fileExceptionReason, valCount,
				        jobExecutionId);
				daReportList.add(currDaReport);			
			}

			if (null != irMtFileName && irCount > 0)
			{
				currDaReport = prepareDaReport(asOfDate, PortrecConstants.IR, longLegalId, irMtFileName, cptyType, PortrecConstants.MT, reconFreq, fileException, fileExceptionReason, irCount,
				        jobExecutionId);
				daReportList.add(currDaReport);
						}

			if (null != crMtFileName && crCount > 0)
			{

				currDaReport = prepareDaReport(asOfDate, PortrecConstants.CR, longLegalId, crMtFileName, cptyType, PortrecConstants.MT, reconFreq, fileException, fileExceptionReason, crCount,
				        jobExecutionId);
				daReportList.add(currDaReport);			
			}

			if (null != fxMtFileName && fxCount > 0)
			{
				currDaReport = prepareDaReport(asOfDate, PortrecConstants.FX, longLegalId, fxMtFileName, cptyType, PortrecConstants.MT, reconFreq, fileException, fileExceptionReason, fxCount,
				        jobExecutionId);
				daReportList.add(currDaReport);				
			}

			if (null != eqMtFileName && eqCount > 0)
			{
				currDaReport = prepareDaReport(asOfDate, PortrecConstants.EQ, longLegalId, eqMtFileName, cptyType, PortrecConstants.MT, reconFreq, fileException, fileExceptionReason, eqCount,
				        jobExecutionId);
				daReportList.add(currDaReport);			
			}

			if (null != cmMtFileName && cmCount > 0)
			{
				currDaReport = prepareDaReport(asOfDate, PortrecConstants.COMM, longLegalId, cmMtFileName, cptyType, PortrecConstants.MT, reconFreq, fileException, fileExceptionReason, cmCount,
				        jobExecutionId);
				daReportList.add(currDaReport);
						}

			if (StringUtils.equalsIgnoreCase(fileException, PortrecConstants.EXCEPTION) && StringUtils.equalsIgnoreCase(fileExceptionReason, FileExceptionReasonEnum.NO_MT_VAL.getValue()))
			{
				currDaReport = prepareDaReport(asOfDate, PortrecConstants.BLANK, longLegalId, PortrecConstants.BLANK, cptyType, PortrecConstants.BLANK, reconFreq, fileException, fileExceptionReason,
				        0, jobExecutionId);
				daReportList.add(currDaReport);				
			}
		}
		catch (Exception exception)
		{
			String errorMsg = "Error saving MT and VAL DA metadata";
			currPrException = preparePrException(jobExecutionId, legalId, ExceptionTypeEnum.PORTREC_ERROR.toString(), "CptyExtractGeneratorService-13", errorMsg, ExceptionUtils.getFullStackTrace(exception));
			prExceptionList.add(currPrException);		
		}
		return fileExceptionFlag;
	}

	private PrException preparePrException(long jobExecutionId, long cidId, String exceptionType, String excSource, String excDesc, String exeTrace)
	{
		PrException currPrException = new PrException();
		currPrException.setJobExecutionId(jobExecutionId);
		currPrException.setCidCptyId(cidId);
		currPrException.setExceptionType(exceptionType);
		currPrException.setExceptionSource(excSource);
		currPrException.setExceptionDesc(excDesc);
		currPrException.setExceptionTrace(exeTrace);
		currPrException.setCreateDatetime(new Date());

		return currPrException;
	}

	private PositionRecon preparePositionRecon(int legalId, Date asOfDate, String reconFreq, int totalMtCount, int irCount, int crCount, int eqCount, int fxCount, int cmCount, int valCount,
	        long jobExecutionId)
	{
		PositionRecon currPositionRecon = new PositionRecon();
		currPositionRecon.setJobExecutionId(jobExecutionId);
		currPositionRecon.setCidCptyId(legalId);
		currPositionRecon.setAsOfDate(asOfDate);
		currPositionRecon.setReconFreq(reconFreq);
		currPositionRecon.setPortfolioSize(totalMtCount);
		currPositionRecon.setIrPositionSize(irCount);
		currPositionRecon.setCrPositionSize(crCount);
		currPositionRecon.setEqPositionSize(eqCount);
		currPositionRecon.setFxPositionSize(fxCount);
		currPositionRecon.setCommPositionSize(cmCount);
		currPositionRecon.setValuationSize(valCount);
		currPositionRecon.setCreateDatetime(new Date());

		return currPositionRecon;
	}

	private DaReport prepareDaReport(Date asOfDate, String assetClass, long legalId, String fileName, String cptyType, String mtValType, String reconFreq, String fileException,
	        String fileExceptionReason, int cnt, long jobExecutionId)
	{
		DaReport currDaReport = new DaReport();
		currDaReport.setJobExecutionId(jobExecutionId);
		currDaReport.setCidCptyId(legalId);
		currDaReport.setCptyType(cptyType);
		currDaReport.setAsOfDate(asOfDate);
		currDaReport.setReconFreq(reconFreq);
		currDaReport.setMtValType(mtValType);
		currDaReport.setAssetClass(assetClass);
		currDaReport.setFileName(fileName);
		// currDaReport.setAffirmedFlag(null);
		// currDaReport.setAffirmDatetime(affirmDatetime);
		currDaReport.setFileException(fileException);
		currDaReport.setFileExceptionReason(fileExceptionReason);
		currDaReport.setPortfolioSize(cnt);
		currDaReport.setCreateDatetime(new Date());

		return currDaReport;

	}

}
