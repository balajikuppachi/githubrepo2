package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCommPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
/**
 * 
 * @author Raji Komatreddy
 *Repository to save or get data from RegRepPrCommPositionReport table
 */
public interface RegRepPrCommPositionReportRepository extends CrudRepository<RegRepPrCommPositionReport, Long>
{

	/*@Query("select comm from RegRepPrCommPositionReport comm where comm.asOfDate=?1 and (comm.reportPrtyLei=?2 or comm.nonReportLei=?3) ")
	public List<RegRepPrCommPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);*/
	
	/*@Query("select comm from RegRepPrCommPositionReport comm where comm.asOfDate=?1 and (comm.buyerLei=?2 or comm.sellerLei=?3) ")
	public List<RegRepPrCommPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);*/
	
	@Query("select comm from RegRepPrCommPositionReport comm where comm.asOfDate=?1 and (comm.buyerLei LIKE %?2% or comm.sellerLei LIKE %?3%) ")
	public List<RegRepPrCommPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);
	
	@Query("select comm.usiValue from RegRepPrCommPositionReport comm where comm.usiValue!='' and comm.regRepPrJobExecutionDetail=?")
	List<String> findUsiComm(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);

	@Query("select comm from RegRepPrCommPositionReport comm where comm.regRepPrJobExecutionDetail=?")
	public List<RegRepPrCommPositionReport> findPositionsByDate(RegRepPrJobExecutionDetail jobDetail);
}
