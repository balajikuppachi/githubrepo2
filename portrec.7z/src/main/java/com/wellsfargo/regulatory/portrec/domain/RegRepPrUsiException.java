package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="REG_REP_PR_USI_EXCEPTION")
public class RegRepPrUsiException {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="exception_id")
	private long exceptionId; 
	
	@Column(name="usi")
	private String usi;
	
	@Column(name = "asset_class")
	private String assetClass;

	@Column(name = "comments")
	private String comments;
	
	@Column(name = "create_datetime")
	private Date createDatetime;

	public String getUsi() {
		return usi;
	}

	public void setUsi(String usi) {
		this.usi = usi;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public long getExceptionId() {
		return exceptionId;
	}

	public void setExceptionId(long exceptionId) {
		this.exceptionId = exceptionId;
	}

	public Date getCreateDatetime() {
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}
}
