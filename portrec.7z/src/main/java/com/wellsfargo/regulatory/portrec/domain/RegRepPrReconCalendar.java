package com.wellsfargo.regulatory.portrec.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * @author Raji Komatreddy
 * The persistent class for the REG_REP_PR_RECON_CALENDAR database table.
 * 
 */
@Entity
@Table(name="REG_REP_PR_RECON_CALENDAR")
public class RegRepPrReconCalendar  {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="recon_calendar_id")
	private Long reconCalendarId;

	private String comment;

	@Column(name="recon_freq")
	private String reconFreq;

	@Temporal(TemporalType.DATE)
	@Column(name="run_date")
	private Date runDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="as_of_date")
	private Date asOfDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="affirm_deadline_date")
	private Date affirmDeadlineDate;

	public RegRepPrReconCalendar() {
	}

	public long getReconCalendarId() {
		return this.reconCalendarId;
	}

	public void setReconCalendarId(long reconCalendarId) {
		this.reconCalendarId = reconCalendarId;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getReconFreq() {
		return this.reconFreq;
	}

	public void setReconFreq(String reconFreq) {
		this.reconFreq = reconFreq;
	}

	public Date getRunDate() {
		return this.runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}

	public Date getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}

	public Date getAffirmDeadlineDate() {
		return affirmDeadlineDate;
	}

	public void setAffirmDeadlineDate(Date affirmDeadlineDate) {
		this.affirmDeadlineDate = affirmDeadlineDate;
	}

}