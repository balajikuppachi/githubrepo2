package com.wellsfargo.regulatory.portrec.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_RECON_REPORT database table.
 */
@Entity
@Table(name = "REG_REP_PR_RECON_REPORT")
public class RegRepPrReconReport extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "recon_report_id")
	private Long reconReportId;

	@Column(name = "address_line1")
	private String addressLine1;

	@Column(name = "address_line2")
	private String addressLine2;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "cid_cpty_id")
	private int cidCptyId;

	@Column(name = "city")
	private String city;

	@Column(name = "comm_type")
	private String commType;

	@Column(name = "country")
	private String country;

	@Column(name = "create_datetime")
	private Timestamp createDatetime;

	@Column(name = "customer_name1")
	private String customerName1;

	@Column(name = "customer_name2")
	private String customerName2;

	@Column(name = "email_address")
	private String emailAddress;

	@Column(name = "js_flag")
	private int jsFlag;

	@Column(name = "cptyl_type")
	private String cptyType;

	@Column(name = "portfolio_size")
	private int portfolioSize;

	@Column(name = "recon_freq")
	private String reconFreq;

	@Column(name = "state")
	private String state;

	@Column(name = "zip_code")
	private String zipCode;

	@Column(name = "dom_intl")
	private String domInt1;
	
	@Column(name = "legal_name")
	private String lgleFullN;
	
	public RegRepPrReconReport()
	{
	}

	public Long getReconReportId()
	{
		return this.reconReportId;
	}

	public void setReconReportId(Long reconReportId)
	{
		this.reconReportId = reconReportId;
	}

	public String getAddressLine1()
	{
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2()
	{
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2)
	{
		this.addressLine2 = addressLine2;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public int getCidCptyId()
	{
		return this.cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public String getCity()
	{
		return this.city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getCommType()
	{
		return this.commType;
	}

	public void setCommType(String commType)
	{
		this.commType = commType;
	}

	public String getCountry()
	{
		return this.country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public Timestamp getCreateDatetime()
	{
		return this.createDatetime;
	}

	public void setCreateDatetime(Timestamp createDatetime)
	{
		this.createDatetime = createDatetime;
	}

	public String getCustomerName1()
	{
		return this.customerName1;
	}

	public void setCustomerName1(String customerName1)
	{
		this.customerName1 = customerName1;
	}

	public String getCustomerName2()
	{
		return this.customerName2;
	}

	public void setCustomerName2(String customerName2)
	{
		this.customerName2 = customerName2;
	}

	public String getEmailAddress()
	{
		return this.emailAddress;
	}

	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}

	public int getJsFlag()
	{
		return this.jsFlag;
	}

	public void setJsFlag(int jsFlag)
	{
		this.jsFlag = jsFlag;
	}

	public String getCptyType()
	{
		return cptyType;
	}

	public void setCptyType(String cptyType)
	{
		this.cptyType = cptyType;
	}

	

	public String getDomInt1() {
		return domInt1;
	}

	public void setDomInt1(String domInt1) {
		this.domInt1 = domInt1;
	}

	public int getPortfolioSize()
	{
		return this.portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public String getReconFreq()
	{
		return this.reconFreq;
	}

	public void setReconFreq(String reconFreq)
	{
		this.reconFreq = reconFreq;
	}

	public String getState()
	{
		return this.state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getZipCode()
	{
		return this.zipCode;
	}

	public void setZipCode(String zipCode)
	{
		this.zipCode = zipCode;
	}

	public String getLgleFullN() {
		return lgleFullN;
	}

	public void setLgleFullN(String lgleFullN) {
		this.lgleFullN = lgleFullN;
	}

}