package com.wellsfargo.regulatory.portrec.common;

import java.io.IOException;
import java.io.InputStream;

public class FxInternationalReader extends CsvWithHeaderReader {
	
	static int HEADER_LINES = 1;

	public FxInternationalReader(InputStream is) {
		super(is, HEADER_LINES);
	}
	
	@Override
	public String[] readNext() throws IOException {
		String[] nextLine = super.readNext();
		if (nextLine != null && nextLine.length > 0 && nextLine[0] != null && nextLine[0].startsWith("#TR#")) {
			return null;
		}
		return nextLine;
	}
	
}
