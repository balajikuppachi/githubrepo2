package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrFxIntlExtract;
/**
 * 
 * @author Raji Komatreddy
 * Repository to save or get data from RegRepPrException table  
 */
public interface RegRepPrFxIntlExtractRepository extends CrudRepository<RegRepPrFxIntlExtract, Long>
{

	@Query("select fx from RegRepPrFxIntlExtract fx where fx.asOfDate=?1 and (fx.party1Lei=?2 or fx.party2Lei=?3) ")
	public List<RegRepPrFxIntlExtract> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);
}
