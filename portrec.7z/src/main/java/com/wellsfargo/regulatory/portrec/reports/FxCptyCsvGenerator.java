package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrFxPositionReport;
import com.wellsfargo.regulatory.portrec.mailer.PrExtractsTo;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrFxPositionReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class FxCptyCsvGenerator {

	private final Logger logger = Logger.getLogger(FxCptyCsvGenerator.class);

	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	@Autowired
	RegRepPrFxPositionReportRepository repPrFxPositionReportRepository;

	@Autowired
	FxDataCsvWriter fxDataCsvWriter;
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;
	
	public PrExtractsTo createFile(List<String> counterPartyLeiList, Long legalId, Date asOfDate, String frequency) throws Exception {
		
		boolean fxFileFlag = false; 
		PrExtractsTo reportProp = new PrExtractsTo();
		reportProp.setAssetClass(PortrecConstants.FX);
		
		boolean maskingFlag = portRecBusinessUtil.isCptyMaskingRequired(frequency);
		
		StringBuilder fxMtFileNameBuffer = new StringBuilder();
		
		fxMtFileNameBuffer.append(PortrecConstants.FX_MT_FILE_INITIAL).append(PortrecConstants.UNDERSCORE).append(legalId).append(PortrecConstants.UNDERSCORE).append(PortRecUtil.convertDateToString_yyyyMdd(asOfDate)).
		append(PortrecConstants.UNDERSCORE).append(frequency.toUpperCase().charAt(0)).append(PortrecConstants.EXTN_CSV);

		String fxMtFileName = fxMtFileNameBuffer.toString();
		
		File fxMtFile  = new File(outputFolderName, fxMtFileName);
		
		List<RegRepPrFxPositionReport> cptyFxPositionsByLegalId = null;
		
		for(String counterPartyLei : counterPartyLeiList){
			List<RegRepPrFxPositionReport> cptyFxPositionsByLei = null;
			
			if(null != counterPartyLei){
				cptyFxPositionsByLei = repPrFxPositionReportRepository.findCptyPositionsByLeiAndDate(asOfDate,counterPartyLei,counterPartyLei);
			}
			
			if(null != cptyFxPositionsByLei && cptyFxPositionsByLei.size() > 0) {
				logger.info("Number of Cpty FX Dtcc Positions :["+ cptyFxPositionsByLei.size() + "] with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
				fxFileFlag = true;
				
				if(!fxMtFile.exists()){
					fxMtFile.mkdirs();
				}
				
				if(null == cptyFxPositionsByLegalId){
					cptyFxPositionsByLegalId = new ArrayList<RegRepPrFxPositionReport>();
				}
				cptyFxPositionsByLegalId.addAll(cptyFxPositionsByLei);
				
			}else{
				logger.info("No records found for Cpty FX Dtcc Position with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
		}
		
		if(fxFileFlag)
		{
			int fxCount = generateMTFile(cptyFxPositionsByLegalId,fxMtFile, maskingFlag);
			reportProp.setFxCount(fxCount);
			
			if(fxCount > 0){
				reportProp.setFxMtFileName(fxMtFileName);
				logger.info("FX MT generated at  "+ outputFolderName);	
			}
			
		}
		
		reportProp.setFlag(fxFileFlag);
		return reportProp;
	}
	
	public int generateMTFile(List<RegRepPrFxPositionReport> cptyFxPositionsByLegalId, File fxMtFile, boolean maskingFlag) throws Exception {
		
		List<RegRepPrFxPositionReport> tradeList=new ArrayList<RegRepPrFxPositionReport>();
		int count = 0;
		
		try{
			for(RegRepPrFxPositionReport fxPositionReport:cptyFxPositionsByLegalId){
				RegRepPrFxPositionReport trade = new RegRepPrFxPositionReport();
				BeanUtils.copyProperties(fxPositionReport, trade);
				tradeList.add(trade);
			}
			fxDataCsvWriter.generateFile(fxMtFile, tradeList, maskingFlag);
		}
		catch(Exception ce){
			throw ce;
		}
		
		count = tradeList.size();
		
		return count;
	}

}