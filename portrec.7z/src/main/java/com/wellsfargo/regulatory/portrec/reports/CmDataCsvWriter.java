package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCommPositionReport;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;

@Component
public class CmDataCsvWriter {

	private final Logger logger = Logger.getLogger(IrDataCsvWriter.class);
	
	static char SEPARATOR = ',';
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;

	public void generateFile(File targetFile, Map<String,RegRepPrCommPositionReport> usiTrdIdMap, boolean maskingFlag) throws Exception {
		try {
			if (targetFile.exists()) {
				targetFile.delete();
			}		
			
			FileWriter writer = new FileWriter(targetFile);

			writer.append("USI");
			writer.append(SEPARATOR);
			writer.append("Trade Id");
			writer.append(SEPARATOR);
			writer.append("Reporting prty LEI");
			writer.append(SEPARATOR);
			writer.append("Report SD");
			writer.append(SEPARATOR);
			writer.append("Report MSP");
			writer.append(SEPARATOR);
			writer.append("Report Fin");
			writer.append(SEPARATOR);
			writer.append("Report US");
			writer.append(SEPARATOR);
			writer.append("Non Report LEI");
			writer.append(SEPARATOR);
			writer.append("Non Report id");
			writer.append(SEPARATOR);
			writer.append("Non Rept SD");
			writer.append(SEPARATOR);
			writer.append("Non Rep MSP");
			writer.append(SEPARATOR);
			writer.append("Non Rep Fin");
			writer.append(SEPARATOR);
			writer.append("Non Rep US");
			writer.append(SEPARATOR);
			writer.append("Product ID");	
			writer.append(SEPARATOR);
			writer.append("CFTC Prod Id");
			writer.append(SEPARATOR);
			writer.append("Int Prod Id");
			writer.append(SEPARATOR);
			writer.append("Multi Asset");
			writer.append(SEPARATOR);
			writer.append("Pri Asset Class");
			writer.append(SEPARATOR);
			writer.append("Sec Asset Class");
			writer.append(SEPARATOR);
			writer.append("Mixed Swap");
			writer.append(SEPARATOR);
			writer.append("SDR2");
			writer.append(SEPARATOR);
			writer.append("Contract Type");
			writer.append(SEPARATOR);
			writer.append("Exec Venue");
			writer.append(SEPARATOR);
			writer.append("Start Dt");
			writer.append(SEPARATOR);
			writer.append("End Dt");
			writer.append(SEPARATOR);
			writer.append("Buyer");
			writer.append(SEPARATOR);
			writer.append("Seller");
			writer.append(SEPARATOR);
			writer.append("Qty Unit");
			writer.append(SEPARATOR);
			writer.append("Qty");
			writer.append(SEPARATOR);
			writer.append("Qty Freq");
			writer.append(SEPARATOR);
			writer.append("Total Qty");
			writer.append(SEPARATOR);
			writer.append("Settle Method");
			writer.append(SEPARATOR);
			writer.append("Price");
			writer.append(SEPARATOR);
			writer.append("Price Unit");
			writer.append(SEPARATOR);
			writer.append("Price ccy");
			writer.append(SEPARATOR);
			writer.append("Buyer Pay Ind");
			writer.append(SEPARATOR);
			writer.append("Buyer Pay avg Method");
			writer.append(SEPARATOR);
			writer.append("Seller Pay Ind");
			writer.append(SEPARATOR);
			writer.append("Seller Pay avg Method");
			writer.append(SEPARATOR);
			writer.append("Grade");
			writer.append(SEPARATOR);
			writer.append("Option Type");
			writer.append(SEPARATOR);
			writer.append("Option Style");
			writer.append(SEPARATOR);
			writer.append("Option Premium");
			writer.append(SEPARATOR);
			writer.append("Hrs Frm Thru");
			writer.append(SEPARATOR);
			writer.append("Hours Timezone");
			writer.append(SEPARATOR);
			writer.append("Day of Week");
			writer.append(SEPARATOR);
			writer.append("Load Type");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);			
			writer.append("Exec Date");
			writer.append('\n');			
			
			Iterator it = usiTrdIdMap.entrySet().iterator();
			while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		        //out.write(pairs.getKey() + " = " + pairs.getValue() + "\n");
		        RegRepPrCommPositionReport srcViewDomain = (RegRepPrCommPositionReport)pairs.getValue();
		        String usi = (String)pairs.getKey();
		        String[] parts = usi.split(":");
		        usi=parts[0];
		        srcViewDomain.setUsiValue(usi);
				writer.append((null != srcViewDomain.getUsiNamespace() ? srcViewDomain.getUsiNamespace() : "")
						+(null != srcViewDomain.getUsiValue() ? srcViewDomain.getUsiValue() : ""));
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSrcTradeId() ? srcViewDomain.getSrcTradeId() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportPrtyLei() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getReportPrtyLei(), maskingFlag) :"");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportSd() ? srcViewDomain.getReportSd() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportMsp() ? srcViewDomain.getReportMsp() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getReportFin() ? srcViewDomain.getReportFin() : "");
				writer.append(SEPARATOR);
				writer.append(null!= srcViewDomain.getReportUs() ? srcViewDomain.getReportUs() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonReportLei() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getNonReportLei(), maskingFlag) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonReportId() ? portRecBusinessUtil.maskCounterPartyDetails(srcViewDomain.getNonReportId(), maskingFlag) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonReptSd() ? srcViewDomain.getNonReptSd() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonRepMsp() ? srcViewDomain.getNonRepMsp() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonRepFin() ? srcViewDomain.getNonRepFin() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getNonRepUs() ? srcViewDomain.getNonRepUs() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getProductId() ? (srcViewDomain.getProductId().contains(",")?srcViewDomain.getProductId().replace(",", ";"):srcViewDomain.getProductId()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getCftcProductId() ? srcViewDomain.getCftcProductId() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getIntProductId() ? srcViewDomain.getIntProductId() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMultAssetClassSwap() ? srcViewDomain.getMultAssetClassSwap() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMacPriAssetClass() ? srcViewDomain.getMacPriAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMacSecAssetClass() ? srcViewDomain.getMacSecAssetClass() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMixedSwap() ? srcViewDomain.getMixedSwap() : "");		
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getMixedSwapReportSdr() ? srcViewDomain.getMixedSwapReportSdr() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getContractType() ? srcViewDomain.getContractType() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getExecutionVenue() ? srcViewDomain.getExecutionVenue() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getStartDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getStartDate()) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getEndDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getEndDate()) : "");
				writer.append(SEPARATOR);
				String buyer = "";
				String seller = "";
				if(StringUtils.isNotBlank(srcViewDomain.getBuyer()))
					buyer = srcViewDomain.getBuyer().replace(",","");
				if(StringUtils.isNotBlank(srcViewDomain.getSeller()))
					seller = srcViewDomain.getSeller().replace(",","");
				writer.append(null != buyer ? portRecBusinessUtil.maskCounterPartyName(buyer.trim(), maskingFlag) : "");
				writer.append(SEPARATOR);
				writer.append(null != seller ? portRecBusinessUtil.maskCounterPartyName(seller.trim(), maskingFlag) : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getQantityUnit() ? srcViewDomain.getQantityUnit() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getQantity() ? srcViewDomain.getQantity() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getQantityFreq() ? srcViewDomain.getQantityFreq() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getTotalFreq() ? srcViewDomain.getTotalFreq() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSettlementMethod() ? srcViewDomain.getSettlementMethod() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPrice() ? srcViewDomain.getPrice() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPriceUnit() ? srcViewDomain.getPriceUnit() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getPriceCurr() ? srcViewDomain.getPriceCurr() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getBuyerPayIndex() ? srcViewDomain.getBuyerPayIndex() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getBuyerPayindexAvgMethod() ? srcViewDomain.getBuyerPayindexAvgMethod() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSellerPayIndex() ? srcViewDomain.getSellerPayIndex() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getSellerPayindexAvgMethod() ? srcViewDomain.getSellerPayindexAvgMethod() : "");				
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getGrade() ? srcViewDomain.getGrade() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOptionType() ? srcViewDomain.getOptionType() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOptionStyle() ? srcViewDomain.getOptionStyle() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getOptionPremium() ? srcViewDomain.getOptionPremium() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getHrFromThr() ? srcViewDomain.getHrFromThr() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getHrFromThrTimezone() ? srcViewDomain.getHrFromThrTimezone() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getDaysOfWeek() ? srcViewDomain.getDaysOfWeek() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getLoadType() ? srcViewDomain.getLoadType() : "");	
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getCollaterlized() ? srcViewDomain.getCollaterlized() : "");
				writer.append(SEPARATOR);
				writer.append(null != srcViewDomain.getExecDate() ? PortRecUtil.convertDateToString_MMddyyyy(srcViewDomain.getExecDate()) : "");
				writer.append('\n');
				
			}
			writer.flush();
			writer.close();
		}
		catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
	}

	/*private String maskCounterPartyDetails(String leiValue){
		String cpVal = "";
		if(null!=leiValue){
			if(StringUtils.contains(wfLeiList, leiValue)){
				cpVal = leiValue;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}*/	
	
	/*private String maskCounterPartyName(String partyName){
		String cpVal = "";
		if(null!=partyName){
			if(StringUtils.containsIgnoreCase(partyName, "Wells Fargo")){
				cpVal = partyName;
			} else {
				cpVal = counterPartyValue;
			}
		}
		return cpVal;
	}*/
	
}