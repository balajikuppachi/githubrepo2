package com.wellsfargo.regulatory.portrec.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrFxPositionReport;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
/**
 * 
 * @author Raji Komatreddy
 * Repository to save or get data from RegRepPrException table  
 */
public interface RegRepPrFxPositionReportRepository extends CrudRepository<RegRepPrFxPositionReport, Long>
{

	@Query("select fx from RegRepPrFxPositionReport fx where fx.asOfDate=?1 and (fx.tradeParty1=?2 or fx.tradeParty2=?3) ")
	public List<RegRepPrFxPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);
	
	
	/*@Query("select fx from RegRepPrFxPositionReport fx where fx.asOfDate=?1 and (fx.tradeParty1 LIKE %?2 or fx.tradeParty2 LIKE %?3) ")
	public List<RegRepPrFxPositionReport> findCptyPositionsByLeiAndDate(Date asOfDate, String cpty1, String cpty2);*/
	
	@Query("select fx.usiValue from RegRepPrFxPositionReport fx where fx.usiValue!='' and fx.regRepPrJobExecutionDetail=?")
	List<String> findUsiFx(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail);

	@Query("select fx from RegRepPrFxPositionReport fx where  fx.regRepPrJobExecutionDetail=? ")
	public List<RegRepPrFxPositionReport> findPositionsByDate(RegRepPrJobExecutionDetail jobDetail);
	
}
