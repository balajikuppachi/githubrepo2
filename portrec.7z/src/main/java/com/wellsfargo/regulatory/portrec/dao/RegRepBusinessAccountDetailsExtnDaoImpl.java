package com.wellsfargo.regulatory.portrec.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.object.StoredProcedure;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCid;

public class RegRepBusinessAccountDetailsExtnDaoImpl {


	private Logger logger = Logger.getLogger(RegRepBusinessAccountDetailsExtnDaoImpl.class);
	protected JdbcTemplate jdbcTemplate;
	protected DataSource dataSource;
	@Value("${cid.data.loader.spname}") String spName;
	
	
	protected BusinessAccountDetailsSP businessAccountDetailsSP;
	
	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
		businessAccountDetailsSP = new BusinessAccountDetailsSP(dataSource);
	}
	
	private class BusinessAccountDetailsSP extends StoredProcedure {
		private String BUSINESS_ACCOUNT_ID = "busAcctId";
		private String BA_ID_DETAILS = "Business_Account_Details";
		/*String spName = "PORTRECON_SearchByBusAcctId";*/
		
		protected BusinessAccountDetailsSP(DataSource dataSource) {
			JdbcTemplate spJdbcTemplate = new JdbcTemplate(dataSource);
			spJdbcTemplate.setSkipUndeclaredResults(true);
			setJdbcTemplate(spJdbcTemplate);
			setSql(spName);
			declareParameter(new SqlParameter(BUSINESS_ACCOUNT_ID, Types.INTEGER));
			declareParameter(new SqlReturnResultSet(BA_ID_DETAILS,new ResultSetExtractor<List<RegRepPrCid>>() {
			Date asOfDate = new Date();	
			
				@Override
				public List<RegRepPrCid> extractData(ResultSet rs)
						throws SQLException, DataAccessException {
					List<RegRepPrCid> bADetails = new ArrayList<RegRepPrCid>();
					while(rs.next()){
						RegRepPrCid bd = new RegRepPrCid();
						bd.setBusAIdC(rs.getInt(1));
						bd.setBusAN(rs.getString(2));
						bd.setSystemC(null!=rs.getString(3)?rs.getString(3).trim():null);
						bd.setBusAExtlKeyC(rs.getString(4));
						bd.setBusAExtlN(rs.getString(5));
						bd.setRelationshipType(rs.getString(6));
						bd.setLgleIdC(rs.getInt(7));
						bd.setLgleTypeC(rs.getString(8));
						bd.setLgleFullN(rs.getString(9));
						bd.setCountry(rs.getString(10));
						bd.setRegEntitySwapDealer(rs.getString(11));
						bd.setEtSD_rates(rs.getString(12));
						bd.setEtSD_equityderivatives(rs.getString(13));
						bd.setEtSD_commodities(rs.getString(14));
						bd.setEtSD_creditderivatives(rs.getString(15));
						bd.setEtSD_FX(rs.getString(16));
						bd.setRegEntitySecBasedSwapDealer(rs.getString(17));
						bd.setEtSBSD_rates(rs.getString(18));
						bd.setEtSBSD_equityderivatives(rs.getString(19));
						bd.setEtSBSD_commodities(rs.getString(20));
						bd.setEtSBSD_creditderivatives(rs.getString(21));
						bd.setEtSBSD_FX(rs.getString(22));
						bd.setRegEntityMajorSwap(rs.getString(23));
						bd.setEtMSP_rates(rs.getString(24));
						bd.setEtMSP_equityderivatives(rs.getString(25));
						bd.setEtMSP_commodities(rs.getString(26));
						bd.setEtMSP_creditderivatives(rs.getString(27));
						bd.setEtMSP_FX(rs.getString(28));
						bd.setRegEntitySecBasedMajorSwap(rs.getString(29));
						bd.setEtSBMSP_rates(rs.getString(30));
						bd.setEtSBMSP_equityderivatives(rs.getString(31));
						bd.setEtSBMSP_commodities(rs.getString(32));
						bd.setEtSBMSP_creditderivatives(rs.getString(33));
						bd.setEtSBMSP_FX(rs.getString(34));
						bd.setRegEntityEndUser(rs.getString(35));
						bd.setDf_ETEU_EndUserType(rs.getString(36));
						bd.setIsdaRiskValuation(rs.getString(37));
						bd.setIsdaPortfolioRecon(rs.getString(38));
						bd.setPortfolioDataMethod(rs.getString(39));
						bd.setEmailAddress(rs.getString(51));	
						bd.setDeliveryPortfolioDataEmail(rs.getString(40));
				/*		if(StringUtils.isNotBlank(rs.getString(51))) {
								bd.setDeliveryPortfolioDataEmail(rs.getString(51));}
							else {
								bd.setDeliveryPortfolioDataEmail(rs.getString(40));}*/
						bd.setReconSDRData(rs.getString(41));
						bd.setQualifier("Y");
						bd.setLei(rs.getString(42));
						bd.setContactName(rs.getString(43));
						bd.setAddressLine1(rs.getString(44));
						bd.setAddressLine2(rs.getString(45));
						bd.setCity(rs.getString(47));
						bd.setState(rs.getString(48));
						bd.setZipCode(rs.getString(49));
						//bd.setDomIntl(null);
						bd.setJsFlag(rs.getString(52));
						bd.setCreateDatetime(asOfDate);
						bd.setAsOfDate(asOfDate);
											
						bADetails.add(bd);
					}
					return bADetails;
				}
			}));
			compile();
		}
		
		private List<RegRepPrCid> executeSP(Integer businessAccountId) {
			 
			 Map<String,Integer> inputParams = new HashMap<String, Integer>();
			 inputParams.put(BUSINESS_ACCOUNT_ID, businessAccountId);
	            
	         Map<String, Object> results = execute(inputParams);	            
	         List<RegRepPrCid> result = (List<RegRepPrCid>) results.get(BA_ID_DETAILS);
	         return result;    
	     }
	}
	
	public List<RegRepPrCid> findBusinessAccountDetails(int businessAccountId) throws RuntimeException{
		try {	
			List<RegRepPrCid> result = businessAccountDetailsSP.executeSP(businessAccountId);
	        return result; 			
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new RuntimeException("Query failed", e);
		}
	}
	
	


}
