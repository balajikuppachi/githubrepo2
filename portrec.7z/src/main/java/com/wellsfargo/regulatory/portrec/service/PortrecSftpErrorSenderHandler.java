package com.wellsfargo.regulatory.portrec.service;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;

import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Component;

@Component
public class PortrecSftpErrorSenderHandler {

	private final Logger logger = Logger.getLogger(PortrecSftpErrorSenderHandler.class);

		
	public void handle(Throwable exceptionToHandle) {
		String assetClass = null;
		String reportType = null;
		Throwable e = exceptionToHandle;
		File uowisFile = null;
		while (e instanceof MessagingException) {

			Message<?> message = ((MessagingException)e).getFailedMessage();
			if (message != null) {
				assetClass = (String) message.getHeaders().get("assetClass");
				reportType = (String) message.getHeaders().get("reportType");
				Object payload = message.getPayload();
				if (payload instanceof File) {
					uowisFile = (File)payload;
				}
			}
			e = e.getCause();
		}
		if (e == null) {
			e = exceptionToHandle;
		}
		
		String errMsg = "Report delivery failed for " + uowisFile.getAbsolutePath() + " (asset class = " + assetClass + ")" + " (report type = " + reportType + ")";
		logger.error(errMsg, e);
		
	}
}
