package com.wellsfargo.regulatory.portrec.mailer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.da.domain.PortRecAuditLogView;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Service
@ManagedResource(description="Update customer ACKs and NACKs")
public class DerivativesAccessUserAckProcess {
	
	private final Logger logger = Logger.getLogger(DerivativesAccessService.class);
	
	@Autowired
	DerivativesAccessService derivativesAccessService;
	
	@Autowired
	CptyDerivativeAccessService cptyDerivativeAccessService;
	
	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;
	
	@ManagedOperation(description="Update customer ACKs and NACKs")
	public void updateCpExtractsAck(Message<?> message) throws PortrecException 
	{
	
		long timeStart = System.currentTimeMillis();
		logger.info("Start DA User Ack Update Process - ");
		
		Object ipMessage = null;
		String errorString = null;
		Date reconDate = null;
		long currJobExecutionId = 0;
		String jobAsOfDate = null;
		Date asOfDate = null;

		RegRepPrJobDetail currRegRepPrJobDetail = null;
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);

		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessUserAckProcess-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		ipMessage = message.getPayload();
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)) jobAsOfDate = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();

		if (null != jobAsOfDate)
		{
			logger.info(" recon process running for asOfDate received from fileName " + jobAsOfDate);
			try
			{
				asOfDate = reconDateFormat.parse(jobAsOfDate);
				if (null != asOfDate)
				{
					reconDate = asOfDate;
				}
				else
				{
					reconDate = new Date();
				}
			}
			catch (ParseException e)
			{
				logger.error("########## " + e.getMessage());
			}
		}
		else
		{
			reconDate = new Date();
		}

		if (ipMessage instanceof RegRepPrJobDetail)
		{
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail)
		{
			errorString = "Null incoming RegRepPrJobDetail";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessUserAckProcess-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(reconDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail.getJobName());
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("DerivativesAccessUserAckProcess-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		try{
			
			Date today = new SimpleDateFormat("yyyy-MM-dd").parse(PortRecUtil.convertDateToString_yyyy_MM_dd(new Date()));
			
			Date lastQuarterRunDate = null;
					
			if(null != today){

				lastQuarterRunDate = regRepPrReconCalendarRepository.findLastQuarterRunDate(today);
				
				logger.info("Last Quarter Run Date :"+ lastQuarterRunDate);
			}
			
			Date affirmDeadlineDate = null;
			
			if(null != lastQuarterRunDate){
				
				affirmDeadlineDate = regRepPrReconCalendarRepository.findAffirmDeadLineDate(lastQuarterRunDate);
				
				logger.info("Affirm deadline date for last Quarter :"+ affirmDeadlineDate);
			}
			
			if(null != affirmDeadlineDate){
				
				if(today.compareTo(affirmDeadlineDate)>0)
				{
					logger.info("Today [" + today + "] is beyond configured affirm deadline date [" + affirmDeadlineDate + "]");
	        	}
				else if(today.compareTo(affirmDeadlineDate)<=0)
				{
					logger.info("Today is before affirm deadline date");
					
					Date prevAffirmDate = cptyDerivativeAccessService.getLatestUpdatedAffirmDateTime();
					logger.info("Prev latest updated affirm date :  "+ prevAffirmDate);
					
					List<PortRecAuditLogView> cptyAcknwledges = new LinkedList<PortRecAuditLogView>();

					if(null != prevAffirmDate){
						cptyAcknwledges = derivativesAccessService.getUserAffirmedRecords(prevAffirmDate);
					} else {
						cptyAcknwledges = derivativesAccessService.getAllPortRecAuditLogView();
					}
					
					if(null != cptyAcknwledges && !cptyAcknwledges.isEmpty()){
						
						logger.info("Number of Ack Counter Parties :::: ********************"+ cptyAcknwledges.size());
						
						for(PortRecAuditLogView portRecAuditLogView : cptyAcknwledges){
							
							if(null != portRecAuditLogView.getAffirmedFlag()){
								cptyDerivativeAccessService.updateDaReportWithUserAck(portRecAuditLogView, regRepPrJobExecutionDetail);
							}
						}
					}
	        	}
			}
				
		}
		catch (Exception ex)
		{
			logger.error("Error in DA User Ack Process : " + ex.getMessage());
			try
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				RegRepPrException regRepPrException = new RegRepPrException();
				regRepPrException.setExceptionSource("DerivativesAccessUserAckProcess");
				regRepPrException.setJobExecutionId(currJobExecutionId);
				regRepPrException.setExceptionDesc(errorString);
				regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
				regRepPrException.setExceptionTrace(ExceptionUtils.getStackTrace(ex));
				regRepPrException.setCreateDatetime(new Date());
				portrecExceptionLogger.logExceptionToDB(regRepPrException);
				logger.error("Exception occurred inside DerivativesAccessUserAckProcess for jobId #" + currJobExecutionId + "exception message " + errorString);
			}
			catch (Exception e)
			{
				logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}
		}
		
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		
		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in DA User Ack Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));
	}
}
