package com.wellsfargo.regulatory.portrec.mailer;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconReport;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class CptyReconReportService {
	
	private final Logger logger = Logger.getLogger(CptyReconReportService.class);

	@Autowired
	RegRepPrReconReportRepository regRepPrReconReportRepository ;
	
	@Value("${mail.default.email.address}")
	String defaultEmailAddress;
	
	@Autowired
	PrEmailAddressValidation prEmailAddressValidation;
	
	public void makeReconReportEntry(CptyReconInformation prCptyInformation) {		
			
		logger.info("Saving into REG_REP_PR_RECON_REPORT. Legal Id = [" + prCptyInformation.getCidCptyId() + "]");
		RegRepPrReconReport regRepPrReconReport = new RegRepPrReconReport();

		regRepPrReconReport.setCidCptyId(prCptyInformation.getCidCptyId());
		regRepPrReconReport.setCustomerName1(prCptyInformation.getCustomerName1());
		regRepPrReconReport.setCustomerName2(prCptyInformation.getCustomerName2());
		regRepPrReconReport.setAddressLine1(prCptyInformation.getAddressLine1());
		regRepPrReconReport.setAddressLine2(prCptyInformation.getAddressLine2());
		regRepPrReconReport.setCity(prCptyInformation.getCity());
		regRepPrReconReport.setState(prCptyInformation.getState());
		regRepPrReconReport.setZipCode(prCptyInformation.getZipCode());
		regRepPrReconReport.setCountry(prCptyInformation.getCountry());
		regRepPrReconReport.setLgleFullN(prCptyInformation.getFullLegalName());
		
		String emailAddress = prCptyInformation.getEmailAddress();
		String frequency = prCptyInformation.getReconFreq();
		
		if(StringUtils.equalsIgnoreCase(frequency, PortrecConstants.QUARTERLY))
		{
			if(StringUtils.isBlank(emailAddress) || !prEmailAddressValidation.validateMailPattern(emailAddress))
			{
				//String errorMsg = "Quaterly.Cp Legal Id : " + prCptyInformation.getCidCptyId() + ".Email address [" +emailAddress+ "] invalid. So update RECON TABLE with default email id";
			 	//logger.error("#### " + errorMsg);
				emailAddress = defaultEmailAddress;
			}
			
			regRepPrReconReport.setEmailAddress(emailAddress);
		}
		
		if(StringUtils.equalsIgnoreCase(frequency, PortrecConstants.ANNUAL))
		{
			if("EMAIL".equalsIgnoreCase(prCptyInformation.getCommunicationType().getValue())){
				
				if((StringUtils.isBlank(emailAddress) || !prEmailAddressValidation.validateMailPattern(emailAddress)))
				{
				 	//String errorMsg = "Annaul.Cp Legal Id : " + prCptyInformation.getCidCptyId() + ".Email address [" +emailAddress+ "] invalid. So update RECON TABLE with default email id";
				 	//logger.error("#### " + errorMsg);
					emailAddress = defaultEmailAddress;
				}
				regRepPrReconReport.setEmailAddress(emailAddress);
			}
		}
		
		if(null != prCptyInformation.getJsFlag() && prCptyInformation.getJsFlag().equalsIgnoreCase(PortrecConstants.Y)){
			regRepPrReconReport.setJsFlag(1);
		}else{
			regRepPrReconReport.setJsFlag(0);
		}
		
		regRepPrReconReport.setCptyType(prCptyInformation.getCptyType());
		regRepPrReconReport.setCommType(prCptyInformation.getCommunicationType().getValue());
		regRepPrReconReport.setAsOfDate(prCptyInformation.getAsOfDate());
		
		regRepPrReconReport.setCreateDatetime(PortRecUtil.convertDateToTimeStamp(new Date()));
		regRepPrReconReport.setPortfolioSize(prCptyInformation.getPortfolioSize());
		regRepPrReconReport.setReconFreq(frequency);
		regRepPrReconReport.setDomInt1(prCptyInformation.getDomIntl());
		
		regRepPrReconReport.setJobExecutionId(prCptyInformation.getRegRepPrJobExecutionDetail());
	
		regRepPrReconReportRepository.save(regRepPrReconReport);
		logger.info("Completed saving into REG_REP_PR_RECON_REPORT. Legal Id = [" + prCptyInformation.getCidCptyId() + "]");
	}
	
	
	public List<RegRepPrReconReport> getAllReconReport(RegRepPrJobExecutionDetail prevRegRepPrJobExecutionDetail) {		
		return regRepPrReconReportRepository.findByPrevMailingJobExecution(prevRegRepPrJobExecutionDetail);
	}
	
}
