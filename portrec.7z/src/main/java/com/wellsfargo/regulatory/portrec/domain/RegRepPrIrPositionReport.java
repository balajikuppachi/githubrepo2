package com.wellsfargo.regulatory.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_IR_POSITION_REPORT database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_IR_POSITION_REPORT")
public class RegRepPrIrPositionReport extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ir_position_report_id")
	private Long irPositionReportId;

	@Column(name = "additional_repository_1")
	private String additionalRepository1;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "asset_class")
	private String assetClass;

	private String buyer;

	private String collaterlized;

	@Column(name = "data_submitter")
	private String dataSubmitter;

	@Column(name = "day_count_fraction_leg_1")
	private String dayCountFractionLeg1;

	@Column(name = "day_count_fraction_leg_2")
	private String dayCountFractionLeg2;

	@Temporal(TemporalType.DATE)
	@Column(name = "effective_date_leg_1")
	private Date effectiveDateLeg1;

	@Temporal(TemporalType.DATE)
	@Column(name = "effective_date_leg_2")
	private Date effectiveDateLeg2;

	@Column(name = "execution_date")
	private Date executionDate;

	@Column(name = "execution_venue")
	private String executionVenue;

	@Column(name = "exotic_notional_amount_leg_1")
	private BigDecimal exoticNotionalAmountLeg1;

	@Column(name = "exotic_notional_amount_leg_2")
	private BigDecimal exoticNotionalAmountLeg2;

	@Column(name = "exotic_settlement_curr")
	private String exoticSettlementCurr;

	@Column(name = "exotic_underlying_asset")
	private String exoticUnderlyingAsset;

	@Column(name = "fixed_rate_initial_leg_1")
	private BigDecimal fixedRateInitialLeg1;

	@Column(name = "fixed_rate_initial_leg_2")
	private BigDecimal fixedRateInitialLeg2;

	@Column(name = "float_fix_cpty")
	private String floatFixCpty;

	@Column(name = "float_fix_party")
	private String floatFixParty;

	@Column(name = "floating_rate_index_leg_1")
	private String floatingRateIndexLeg1;

	@Column(name = "floating_rate_index_leg_2")
	private String floatingRateIndexLeg2;

	/*
	 * @Column(name="job_execution_id") private BigDecimal jobExecutionId;
	 */
	@Column(name = "leg_1_payer")
	private String leg1Payer;

	@Column(name = "leg_2_payer")
	private String leg2Payer;

	@Temporal(TemporalType.DATE)
	@Column(name = "maturity_date")
	private Date maturityDate;

	@Column(name = "msg_type")
	private String msgType;

	@Column(name = "notional_amount_cpty")
	private BigDecimal notionalAmountCpty;

	@Column(name = "notional_amount_party")
	private BigDecimal notionalAmountParty;

	@Column(name = "notional_currency_cpty")
	private String notionalCurrencyCpty;

	@Column(name = "notional_currency_party")
	private String notionalCurrencyParty;

	@Column(name = "option_type")
	private String optionType;

	@Column(name = "orig_trade_id")
	private String origTradeId;

	@Column(name = "payment_freq_period_leg_1")
	private String paymentFreqPeriodLeg1;

	@Column(name = "payment_freq_period_leg_2")
	private String paymentFreqPeriodLeg2;

	@Column(name = "payment_freq_period_multiplier_leg_1")
	private String paymentFreqPeriodMultiplierLeg1;

	@Column(name = "payment_freq_period_multiplier_leg_2")
	private String paymentFreqPeriodMultiplierLeg2;

	@Column(name = "product_type")
	private String productType;

	@Column(name = "reporting_jurisdiction")
	private String reportingJurisdiction;

	@Column(name = "reset_freq_period_leg_1")
	private String resetFreqPeriodLeg1;

	@Column(name = "reset_freq_period_leg_2")
	private String resetFreqPeriodLeg2;

	@Column(name = "reset_freq_period_multiplier_leg_1")
	private String resetFreqPeriodMultiplierLeg1;

	@Column(name = "reset_freq_period_multiplier_leg_2")
	private String resetFreqPeriodMultiplierLeg2;

	@Column(name = "revision_id")
	private int revisionId;

	@Column(name = "sec_asset_class")
	private String secAssetClass;

	private String seller;

	@Column(name = "submitted_for")
	private String submittedFor;

	@Temporal(TemporalType.DATE)
	@Column(name = "termination_date_leg_1")
	private Date terminationDateLeg1;

	@Temporal(TemporalType.DATE)
	@Column(name = "termination_date_leg_2")
	private Date terminationDateLeg2;

	@Temporal(TemporalType.DATE)
	@Column(name = "trade_date")
	private Date tradeDate;

	@Column(name = "trade_party_1_financial_entity")
	private String tradeParty1FinancialEntity;

	@Column(name = "trade_party_1_usperson_indicator")
	private String tradeParty1UspersonIndicator;

	@Column(name = "trade_party_2_financial_entity")
	private String tradeParty2FinancialEntity;

	@Column(name = "trade_party_2_usperson_indicator")
	private String tradeParty2UspersonIndicator;

	@Column(name = "trade_party_lei_1")
	private String tradePartyLei1;

	@Column(name = "trade_party_lei_2")
	private String tradePartyLei2;

	@Column(name = "trade_party_role_1")
	private String tradePartyRole1;

	@Column(name = "trade_party_role_2")
	private String tradePartyRole2;

	@Column(name = "trade_party1")
	private String tradeParty1;

	@Column(name = "trade_party2")
	private String tradeParty2;

	@Column(name = "trade_type_indicator")
	private String tradeTypeIndicator;

	private String usi;

	@Column(name = "usi_namespace")
	private String usiNamespace;

	@Column(name = "verification_status")
	private String verificationStatus;

	public RegRepPrIrPositionReport()
	{
	}

	public Long getIrPositionReportId()
	{
		return this.irPositionReportId;
	}

	public void setIrPositionReportId(Long irPositionReportId)
	{
		this.irPositionReportId = irPositionReportId;
	}

	public String getAdditionalRepository1()
	{
		return this.additionalRepository1;
	}

	public void setAdditionalRepository1(String additionalRepository1)
	{
		this.additionalRepository1 = additionalRepository1;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getAssetClass()
	{
		return this.assetClass;
	}

	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}

	public String getBuyer()
	{
		return this.buyer;
	}

	public void setBuyer(String buyer)
	{
		this.buyer = buyer;
	}

	public String getCollaterlized()
	{
		return this.collaterlized;
	}

	public void setCollaterlized(String collaterlized)
	{
		this.collaterlized = collaterlized;
	}

	public String getDataSubmitter()
	{
		return this.dataSubmitter;
	}

	public void setDataSubmitter(String dataSubmitter)
	{
		this.dataSubmitter = dataSubmitter;
	}

	public String getDayCountFractionLeg1()
	{
		return this.dayCountFractionLeg1;
	}

	public void setDayCountFractionLeg1(String dayCountFractionLeg1)
	{
		this.dayCountFractionLeg1 = dayCountFractionLeg1;
	}

	public String getDayCountFractionLeg2()
	{
		return this.dayCountFractionLeg2;
	}

	public void setDayCountFractionLeg2(String dayCountFractionLeg2)
	{
		this.dayCountFractionLeg2 = dayCountFractionLeg2;
	}

	public Date getEffectiveDateLeg1()
	{
		return this.effectiveDateLeg1;
	}

	public void setEffectiveDateLeg1(Date effectiveDateLeg1)
	{
		this.effectiveDateLeg1 = effectiveDateLeg1;
	}

	public Date getEffectiveDateLeg2()
	{
		return this.effectiveDateLeg2;
	}

	public void setEffectiveDateLeg2(Date effectiveDateLeg2)
	{
		this.effectiveDateLeg2 = effectiveDateLeg2;
	}

	public Date getExecutionDate()
	{
		return this.executionDate;
	}

	public void setExecutionDate(Date date)
	{
		this.executionDate = date;
	}

	public String getExecutionVenue()
	{
		return this.executionVenue;
	}

	public void setExecutionVenue(String executionVenue)
	{
		this.executionVenue = executionVenue;
	}

	public BigDecimal getExoticNotionalAmountLeg1()
	{
		return this.exoticNotionalAmountLeg1;
	}

	public void setExoticNotionalAmountLeg1(BigDecimal exoticNotionalAmountLeg1)
	{
		this.exoticNotionalAmountLeg1 = exoticNotionalAmountLeg1;
	}

	public BigDecimal getExoticNotionalAmountLeg2()
	{
		return this.exoticNotionalAmountLeg2;
	}

	public void setExoticNotionalAmountLeg2(BigDecimal exoticNotionalAmountLeg2)
	{
		this.exoticNotionalAmountLeg2 = exoticNotionalAmountLeg2;
	}

	public String getExoticSettlementCurr()
	{
		return this.exoticSettlementCurr;
	}

	public void setExoticSettlementCurr(String exoticSettlementCurr)
	{
		this.exoticSettlementCurr = exoticSettlementCurr;
	}

	public String getExoticUnderlyingAsset()
	{
		return this.exoticUnderlyingAsset;
	}

	public void setExoticUnderlyingAsset(String exoticUnderlyingAsset)
	{
		this.exoticUnderlyingAsset = exoticUnderlyingAsset;
	}

	public BigDecimal getFixedRateInitialLeg1()
	{
		return this.fixedRateInitialLeg1;
	}

	public void setFixedRateInitialLeg1(BigDecimal fixedRateInitialLeg1)
	{
		this.fixedRateInitialLeg1 = fixedRateInitialLeg1;
	}

	public BigDecimal getFixedRateInitialLeg2()
	{
		return this.fixedRateInitialLeg2;
	}

	public void setFixedRateInitialLeg2(BigDecimal fixedRateInitialLeg2)
	{
		this.fixedRateInitialLeg2 = fixedRateInitialLeg2;
	}

	public String getFloatFixCpty()
	{
		return this.floatFixCpty;
	}

	public void setFloatFixCpty(String floatFixCpty)
	{
		this.floatFixCpty = floatFixCpty;
	}

	public String getFloatFixParty()
	{
		return this.floatFixParty;
	}

	public void setFloatFixParty(String floatFixParty)
	{
		this.floatFixParty = floatFixParty;
	}

	public String getFloatingRateIndexLeg1()
	{
		return this.floatingRateIndexLeg1;
	}

	public void setFloatingRateIndexLeg1(String floatingRateIndexLeg1)
	{
		this.floatingRateIndexLeg1 = floatingRateIndexLeg1;
	}

	public String getFloatingRateIndexLeg2()
	{
		return this.floatingRateIndexLeg2;
	}

	public void setFloatingRateIndexLeg2(String floatingRateIndexLeg2)
	{
		this.floatingRateIndexLeg2 = floatingRateIndexLeg2;
	}

	/*
	 * public BigDecimal getJobExecutionId() { return this.jobExecutionId; } public void
	 * setJobExecutionId(BigDecimal jobExecutionId) { this.jobExecutionId = jobExecutionId; }
	 */

	public String getLeg1Payer()
	{
		return this.leg1Payer;
	}

	public void setLeg1Payer(String leg1Payer)
	{
		this.leg1Payer = leg1Payer;
	}

	public String getLeg2Payer()
	{
		return this.leg2Payer;
	}

	public void setLeg2Payer(String leg2Payer)
	{
		this.leg2Payer = leg2Payer;
	}

	public Date getMaturityDate()
	{
		return this.maturityDate;
	}

	public void setMaturityDate(Date maturityDate)
	{
		this.maturityDate = maturityDate;
	}

	public String getMsgType()
	{
		return this.msgType;
	}

	public void setMsgType(String msgType)
	{
		this.msgType = msgType;
	}

	public BigDecimal getNotionalAmountCpty()
	{
		return this.notionalAmountCpty;
	}

	public void setNotionalAmountCpty(BigDecimal notionalAmountCpty)
	{
		this.notionalAmountCpty = notionalAmountCpty;
	}

	public BigDecimal getNotionalAmountParty()
	{
		return this.notionalAmountParty;
	}

	public void setNotionalAmountParty(BigDecimal notionalAmountParty)
	{
		this.notionalAmountParty = notionalAmountParty;
	}

	public String getNotionalCurrencyCpty()
	{
		return this.notionalCurrencyCpty;
	}

	public void setNotionalCurrencyCpty(String notionalCurrencyCpty)
	{
		this.notionalCurrencyCpty = notionalCurrencyCpty;
	}

	public String getNotionalCurrencyParty()
	{
		return this.notionalCurrencyParty;
	}

	public void setNotionalCurrencyParty(String notionalCurrencyParty)
	{
		this.notionalCurrencyParty = notionalCurrencyParty;
	}

	public String getOptionType()
	{
		return this.optionType;
	}

	public void setOptionType(String optionType)
	{
		this.optionType = optionType;
	}

	public String getOrigTradeId()
	{
		return this.origTradeId;
	}

	public void setOrigTradeId(String origTradeId)
	{
		this.origTradeId = origTradeId;
	}

	public String getPaymentFreqPeriodLeg1()
	{
		return this.paymentFreqPeriodLeg1;
	}

	public void setPaymentFreqPeriodLeg1(String paymentFreqPeriodLeg1)
	{
		this.paymentFreqPeriodLeg1 = paymentFreqPeriodLeg1;
	}

	public String getPaymentFreqPeriodLeg2()
	{
		return this.paymentFreqPeriodLeg2;
	}

	public void setPaymentFreqPeriodLeg2(String paymentFreqPeriodLeg2)
	{
		this.paymentFreqPeriodLeg2 = paymentFreqPeriodLeg2;
	}

	public String getPaymentFreqPeriodMultiplierLeg1()
	{
		return this.paymentFreqPeriodMultiplierLeg1;
	}

	public void setPaymentFreqPeriodMultiplierLeg1(String paymentFreqPeriodMultiplierLeg1)
	{
		this.paymentFreqPeriodMultiplierLeg1 = paymentFreqPeriodMultiplierLeg1;
	}

	public String getPaymentFreqPeriodMultiplierLeg2()
	{
		return this.paymentFreqPeriodMultiplierLeg2;
	}

	public void setPaymentFreqPeriodMultiplierLeg2(String paymentFreqPeriodMultiplierLeg2)
	{
		this.paymentFreqPeriodMultiplierLeg2 = paymentFreqPeriodMultiplierLeg2;
	}

	public String getProductType()
	{
		return this.productType;
	}

	public void setProductType(String productType)
	{
		this.productType = productType;
	}

	public String getReportingJurisdiction()
	{
		return this.reportingJurisdiction;
	}

	public void setReportingJurisdiction(String reportingJurisdiction)
	{
		this.reportingJurisdiction = reportingJurisdiction;
	}

	public String getResetFreqPeriodLeg1()
	{
		return this.resetFreqPeriodLeg1;
	}

	public void setResetFreqPeriodLeg1(String resetFreqPeriodLeg1)
	{
		this.resetFreqPeriodLeg1 = resetFreqPeriodLeg1;
	}

	public String getResetFreqPeriodLeg2()
	{
		return this.resetFreqPeriodLeg2;
	}

	public void setResetFreqPeriodLeg2(String resetFreqPeriodLeg2)
	{
		this.resetFreqPeriodLeg2 = resetFreqPeriodLeg2;
	}

	public String getResetFreqPeriodMultiplierLeg1()
	{
		return this.resetFreqPeriodMultiplierLeg1;
	}

	public void setResetFreqPeriodMultiplierLeg1(String resetFreqPeriodMultiplierLeg1)
	{
		this.resetFreqPeriodMultiplierLeg1 = resetFreqPeriodMultiplierLeg1;
	}

	public String getResetFreqPeriodMultiplierLeg2()
	{
		return this.resetFreqPeriodMultiplierLeg2;
	}

	public void setResetFreqPeriodMultiplierLeg2(String resetFreqPeriodMultiplierLeg2)
	{
		this.resetFreqPeriodMultiplierLeg2 = resetFreqPeriodMultiplierLeg2;
	}

	public int getRevisionId()
	{
		return this.revisionId;
	}

	public void setRevisionId(int revisionId)
	{
		this.revisionId = revisionId;
	}

	public String getSecAssetClass()
	{
		return this.secAssetClass;
	}

	public void setSecAssetClass(String secAssetClass)
	{
		this.secAssetClass = secAssetClass;
	}

	public String getSeller()
	{
		return this.seller;
	}

	public void setSeller(String seller)
	{
		this.seller = seller;
	}

	public String getSubmittedFor()
	{
		return this.submittedFor;
	}

	public void setSubmittedFor(String submittedFor)
	{
		this.submittedFor = submittedFor;
	}

	public Date getTerminationDateLeg1()
	{
		return this.terminationDateLeg1;
	}

	public void setTerminationDateLeg1(Date terminationDateLeg1)
	{
		this.terminationDateLeg1 = terminationDateLeg1;
	}

	public Date getTerminationDateLeg2()
	{
		return this.terminationDateLeg2;
	}

	public void setTerminationDateLeg2(Date terminationDateLeg2)
	{
		this.terminationDateLeg2 = terminationDateLeg2;
	}

	public Date getTradeDate()
	{
		return this.tradeDate;
	}

	public void setTradeDate(Date tradeDate)
	{
		this.tradeDate = tradeDate;
	}

	public String getTradeParty1FinancialEntity()
	{
		return this.tradeParty1FinancialEntity;
	}

	public void setTradeParty1FinancialEntity(String tradeParty1FinancialEntity)
	{
		this.tradeParty1FinancialEntity = tradeParty1FinancialEntity;
	}

	public String getTradeParty1UspersonIndicator()
	{
		return this.tradeParty1UspersonIndicator;
	}

	public void setTradeParty1UspersonIndicator(String tradeParty1UspersonIndicator)
	{
		this.tradeParty1UspersonIndicator = tradeParty1UspersonIndicator;
	}

	public String getTradeParty2FinancialEntity()
	{
		return this.tradeParty2FinancialEntity;
	}

	public void setTradeParty2FinancialEntity(String tradeParty2FinancialEntity)
	{
		this.tradeParty2FinancialEntity = tradeParty2FinancialEntity;
	}

	public String getTradeParty2UspersonIndicator()
	{
		return this.tradeParty2UspersonIndicator;
	}

	public void setTradeParty2UspersonIndicator(String tradeParty2UspersonIndicator)
	{
		this.tradeParty2UspersonIndicator = tradeParty2UspersonIndicator;
	}

	public String getTradePartyLei1()
	{
		return this.tradePartyLei1;
	}

	public void setTradePartyLei1(String tradePartyLei1)
	{
		this.tradePartyLei1 = tradePartyLei1;
	}

	public String getTradePartyLei2()
	{
		return this.tradePartyLei2;
	}

	public void setTradePartyLei2(String tradePartyLei2)
	{
		this.tradePartyLei2 = tradePartyLei2;
	}

	public String getTradePartyRole1()
	{
		return this.tradePartyRole1;
	}

	public void setTradePartyRole1(String tradePartyRole1)
	{
		this.tradePartyRole1 = tradePartyRole1;
	}

	public String getTradePartyRole2()
	{
		return this.tradePartyRole2;
	}

	public void setTradePartyRole2(String tradePartyRole2)
	{
		this.tradePartyRole2 = tradePartyRole2;
	}

	public String getTradeParty1()
	{
		return this.tradeParty1;
	}

	public void setTradeParty1(String tradeParty1)
	{
		this.tradeParty1 = tradeParty1;
	}

	public String getTradeParty2()
	{
		return this.tradeParty2;
	}

	public void setTradeParty2(String tradeParty2)
	{
		this.tradeParty2 = tradeParty2;
	}

	public String getTradeTypeIndicator()
	{
		return this.tradeTypeIndicator;
	}

	public void setTradeTypeIndicator(String tradeTypeIndicator)
	{
		this.tradeTypeIndicator = tradeTypeIndicator;
	}

	public String getUsi()
	{
		return this.usi;
	}

	public void setUsi(String usi)
	{
		this.usi = usi;
	}

	public String getUsiNamespace()
	{
		return this.usiNamespace;
	}

	public void setUsiNamespace(String usiNamespace)
	{
		this.usiNamespace = usiNamespace;
	}

	public String getVerificationStatus()
	{
		return this.verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus)
	{
		this.verificationStatus = verificationStatus;
	}

}