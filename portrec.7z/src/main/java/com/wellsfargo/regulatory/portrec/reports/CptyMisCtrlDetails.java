package com.wellsfargo.regulatory.portrec.reports;


public class CptyMisCtrlDetails {

	private Integer cidCptyId;
	private String fullLegalName;
	private String emailAddress;
	private String assetClass;
	private String portfolioSize;
	private String valAttached;
	private String reconFreq;
	private Integer jsFlag;
	private String cptyType;
	public Integer getCidCptyId() {
		return cidCptyId;
	}
	public void setCidCptyId(Integer cidCptyId) {
		this.cidCptyId = cidCptyId;
	}
	public String getFullLegalName() {
		return fullLegalName;
	}
	public void setFullLegalName(String fullLegalName) {
		this.fullLegalName = fullLegalName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getPortfolioSize() {
		return portfolioSize;
	}
	public void setPortfolioSize(String portfolioSize) {
		this.portfolioSize = portfolioSize;
	}
	public String getValAttached() {
		return valAttached;
	}
	public void setValAttached(String valAttached) {
		this.valAttached = valAttached;
	}
	public String getReconFreq() {
		return reconFreq;
	}
	public void setReconFreq(String reconFreq) {
		this.reconFreq = reconFreq;
	}
	public Integer getJsFlag() {
		return jsFlag;
	}
	public void setJsFlag(Integer jsFlag) {
		this.jsFlag = jsFlag;
	}
	public String getCptyType() {
		return cptyType;
	}
	public void setCptyType(String cptyType) {
		this.cptyType = cptyType;
	}
	
}
