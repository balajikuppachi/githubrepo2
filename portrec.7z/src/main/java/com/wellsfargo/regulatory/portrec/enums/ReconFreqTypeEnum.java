package com.wellsfargo.regulatory.portrec.enums;

/**
 * @author Raji Komatreddy
 */

public enum ReconFreqTypeEnum
{

	DAILY("DAILY"), WEEKLY("WEEKLY"), QUARTERLY("QUARTERLY"), ANNUAL("ANNUAL"), NONE("NONE");

	private final String value;

	public String type()
	{

		return toString();
	}

	public String getValue()
	{

		return toString();
	}

	ReconFreqTypeEnum(String v)
	{

		value = v;
	}

	public static ReconFreqTypeEnum fromValue(String v)
	{

		for (ReconFreqTypeEnum c : ReconFreqTypeEnum.values())
		{

			if (c.value.equals(v))
			{
				return c;
			}
		}

		throw new IllegalArgumentException(v);
	}
}
