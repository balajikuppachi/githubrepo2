package com.wellsfargo.regulatory.portrec.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconReport;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.reports.DucDomesticCsvWriter;
import com.wellsfargo.regulatory.portrec.reports.DucInternationalCsvWriter;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconReportRepository;

@Service
@ManagedResource
public class DucGeneratorUtility {

	private final Logger logger = Logger.getLogger(DucGeneratorUtility.class);

	@Autowired
	RegRepPrReconReportRepository regRepPrReconReportRepository;
	@Autowired
	DucDomesticCsvWriter domesticCsvWriter;
	@Autowired
	DucInternationalCsvWriter internationalCsvWriter;
	
	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;

	@ManagedOperation
	public void generateDucFile(String jobReconDate_YYYY_MM_DD,String jobAsOfDate_YYYY_MM_DD,Long currJobExecutionId) throws PortrecException {
		
		long timeStart = System.currentTimeMillis();
		logger.info("Start DucGenerator Jmx- ");
		
		
		String errorString = null;
		String jobReconDate = jobReconDate_YYYY_MM_DD;
		String jobAsOfDate = jobAsOfDate_YYYY_MM_DD;
		Date asOfDate = null;
		Date reconDate = null;
		
		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = null;
		
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);


		if (null != jobAsOfDate)
		{
			logger.info(" recon process running for asOfDate received from fileName " + jobAsOfDate);
			try
			{
				asOfDate = reconDateFormat.parse(jobAsOfDate);
			}
			catch (ParseException e)
			{
				errorString = "exception occured while inserting a record in JobExecutionDetails table";
				logger.error("########## " + errorString);
				throw new PortrecException("DucGenerator-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
			}
		}
		
		if (null != jobReconDate)
		{
			logger.info(" recon process running for reconDate received from fileName " + jobReconDate);
			try
			{
				reconDate = reconDateFormat.parse(jobReconDate);
			}
			catch (ParseException e)
			{
				errorString = "exception occured while inserting a record in JobExecutionDetails table";
				logger.error("########## " + errorString);
				throw new PortrecException("DucGenerator-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
			}
		}

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.findOne(currJobExecutionId);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("DucGenerator-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);

		}

		
		logger.info("jobExecution id for current run of DucGenerator " + currJobExecutionId);
		
		try {
			// where comm_type='DUC' and domImtl = 'd'
			List<RegRepPrReconReport> regRepPrReconReportList1 = (List<RegRepPrReconReport>) regRepPrReconReportRepository
					.findByDomesticType(regRepPrJobExecutionDetail);
			if(!regRepPrReconReportList1.isEmpty())
			domesticCsvWriter.write(regRepPrJobExecutionDetail,regRepPrReconReportList1, asOfDate, reconDate);
			else
				logger.info("No data is available to write the domestic duc file ");

			// where comm_type='DUC' and domImtl = 'I'
			List<RegRepPrReconReport> regRepPrReconReportList2 = (List<RegRepPrReconReport>) regRepPrReconReportRepository
					.findByInternationalType(regRepPrJobExecutionDetail);
			if(!regRepPrReconReportList2.isEmpty())
			internationalCsvWriter.write(regRepPrJobExecutionDetail,regRepPrReconReportList2, asOfDate, reconDate);
			else
				logger.info("No data is available to write the international duc file ");


		} catch (Exception ex) {
			
			logger.error("Error in DucGenerator Process : " + ex.getMessage());
			try
			{
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				RegRepPrException regRepPrException = new RegRepPrException();
				regRepPrException.setExceptionSource("DucGenerator");
				regRepPrException.setJobExecutionId(currJobExecutionId);
				regRepPrException.setExceptionDesc(errorString);
				regRepPrException.setExceptionType(ExceptionTypeEnum.PORTREC_ERROR.toString());
				regRepPrException.setExceptionTrace(ExceptionUtils.getStackTrace(ex));
				regRepPrException.setCreateDatetime(new Date());
				portrecExceptionLogger.logExceptionToDB(regRepPrException);
				logger.error("Exception occurred inside DucGenerator for jobId #" + currJobExecutionId + "exception message " + errorString);
			}
			catch (Exception e)
			{
				logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}
		}
		
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in DucGenerator Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));
	}
}