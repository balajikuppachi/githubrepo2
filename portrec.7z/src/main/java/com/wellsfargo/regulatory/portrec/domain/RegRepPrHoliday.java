package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_HOLIDAY database table.
 */
@Entity
@Table(name = "REG_REP_PR_HOLIDAY")
public class RegRepPrHoliday
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "holiday_id")
	private Long holidayId;

	@Column(name = "code_name")
	private String codeName;

	private String comments;

	@Temporal(TemporalType.DATE)
	@Column(name = "holiday_date")
	private Date holidayDate;

	public RegRepPrHoliday()
	{
	}

	public long getHolidayId()
	{
		return this.holidayId;
	}

	public void setHolidayId(long holidayId)
	{
		this.holidayId = holidayId;
	}

	public String getCodeName()
	{
		return this.codeName;
	}

	public void setCodeName(String codeName)
	{
		this.codeName = codeName;
	}

	public String getComments()
	{
		return this.comments;
	}

	public void setComments(String comments)
	{
		this.comments = comments;
	}

	public Date getHolidayDate()
	{
		return this.holidayDate;
	}

	public void setHolidayDate(Date holidayDate)
	{
		this.holidayDate = holidayDate;
	}

}