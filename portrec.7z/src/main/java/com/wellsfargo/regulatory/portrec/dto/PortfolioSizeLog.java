package com.wellsfargo.regulatory.portrec.dto;

import java.util.Date;

public class PortfolioSizeLog
{
	private long jobExecutionId;
	private Date asOfDate;
	private int cidCptyId;
	private String legalType;
	private int portfolioSize;
	private int commSize;
	private int crSize;
	private int irSize;
	private int eqSize;
	private int fxSize;
	private int fxIntlSize;
	private String daily;
	private String weekly;
	private String quarterly;
	private String annual;
	private String reconDay;
	private String calculatedFreq;
	private String overrideFreq;
	private Date createDatetime;

	public long getJobExecutionId()
	{
		return jobExecutionId;
	}

	public void setJobExecutionId(long jobExecutionId)
	{
		this.jobExecutionId = jobExecutionId;
	}

	public Date getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public int getCidCptyId()
	{
		return cidCptyId;
	}

	public void setCidCptyId(int cidCptyId)
	{
		this.cidCptyId = cidCptyId;
	}

	public String getLegalType()
	{
		return legalType;
	}

	public void setLegalType(String legalType)
	{
		this.legalType = legalType;
	}

	public int getPortfolioSize()
	{
		return portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize)
	{
		this.portfolioSize = portfolioSize;
	}

	public int getCommSize()
	{
		return commSize;
	}

	public void setCommSize(int commSize)
	{
		this.commSize = commSize;
	}

	public int getCrSize()
	{
		return crSize;
	}

	public void setCrSize(int crSize)
	{
		this.crSize = crSize;
	}

	public int getIrSize()
	{
		return irSize;
	}

	public void setIrSize(int irSize)
	{
		this.irSize = irSize;
	}

	public int getEqSize()
	{
		return eqSize;
	}

	public void setEqSize(int eqSize)
	{
		this.eqSize = eqSize;
	}

	public int getFxSize()
	{
		return fxSize;
	}

	public void setFxSize(int fxSize)
	{
		this.fxSize = fxSize;
	}

	public int getFxIntlSize()
	{
		return fxIntlSize;
	}

	public void setFxIntlSize(int fxIntlSize)
	{
		this.fxIntlSize = fxIntlSize;
	}

	public String getDaily()
	{
		return daily;
	}

	public void setDaily(String daily)
	{
		this.daily = daily;
	}

	public String getWeekly()
	{
		return weekly;
	}

	public void setWeekly(String weekly)
	{
		this.weekly = weekly;
	}

	public String getQuarterly()
	{
		return quarterly;
	}

	public void setQuarterly(String quarterly)
	{
		this.quarterly = quarterly;
	}

	public String getAnnual()
	{
		return annual;
	}

	public void setAnnual(String annual)
	{
		this.annual = annual;
	}

	public String getReconDay()
	{
		return reconDay;
	}

	public void setReconDay(String reconDay)
	{
		this.reconDay = reconDay;
	}

	public String getCalculatedFreq()
	{
		return calculatedFreq;
	}

	public void setCalculatedFreq(String calculatedFreq)
	{
		this.calculatedFreq = calculatedFreq;
	}

	public String getOverrideFreq()
	{
		return overrideFreq;
	}

	public void setOverrideFreq(String overrideFreq)
	{
		this.overrideFreq = overrideFreq;
	}

	public Date getCreateDatetime()
	{
		return createDatetime;
	}

	public void setCreateDatetime(Date createDatetime)
	{
		this.createDatetime = createDatetime;
	}

}
