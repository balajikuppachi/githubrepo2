package com.wellsfargo.regulatory.portrec.dto;

public class PrJobDetails
{

	private String jobName;
	private String asOfDate;
	
	
	public PrJobDetails(String jobName)
	{
		this.jobName = jobName;
	}
	
	public PrJobDetails(String jobName, String asOfDate)
	{
		this.jobName = jobName;
		this.asOfDate = asOfDate;
	}
	
	public PrJobDetails()
	{
		
	}
	

	public String getJobName()
	{
		return jobName;
	}

	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}

	public String getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(String asOfDate)
	{
		this.asOfDate = asOfDate;
	}
}
