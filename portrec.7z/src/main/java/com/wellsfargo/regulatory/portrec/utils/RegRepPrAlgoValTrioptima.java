package com.wellsfargo.regulatory.portrec.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.service.PortrecReportDeliveryRequest;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrAlgoValuation;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCid;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJob;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrAlgoValuationRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;

@Service
@ManagedResource(description="Trioptima file generator ")
public class RegRepPrAlgoValTrioptima extends RegRepPrJob{
	
	private static Logger logger = Logger.getLogger(RegRepPrAlgoValTrioptima.class);
	
	@Value("${file.trioptima.val.output}") String outputFolderName;

	public static String PORTFOLIO_SEGMENT_NAME = "VAL, Trioptima";
	
	@Autowired
	RegRepPrAlgoValuationRepository regRepPrAlgoVallRepository;
	
	@Autowired
	RegRepPrJobDetailRepository regRepPrJobDetailRepository;
	
	@Autowired
	TransactionalLoaderServiceforTrioptima transactionalLoaderService;
	
	@Autowired(required=true)
	@Qualifier("portrecReportDeliveryRequestSubmitter")
	PortRecReportDeliveryRequestSubmitterService portRecReportDeliveryRequestSubmitter; 
	
	RegRepPrJobDetail regRepPrJobDetail;
	
	@ManagedOperation(description = "Trioptima file generator ")
	public void fetchTrioptimaVal() throws IOException{
	List<RegRepPrJobDetail> jobDetails = regRepPrJobDetailRepository.findByjobName(PORTFOLIO_SEGMENT_NAME);
	if (jobDetails.size() != 1) {
		throw new RuntimeException(
				"Could not initialize Portfolio Segment '"	+ PORTFOLIO_SEGMENT_NAME + "'");
	}
	regRepPrJobDetail = jobDetails.get(0);
	logger.info("Starting RegRepPrAlgoValTrioptima For "	+ regRepPrJobDetail.getJobDesc());
	RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = transactionalLoaderService.startLoad("TRIOPTIMA_VAL_LOAD", regRepPrJobDetail, new Date());	
	loadValFile(regRepPrJobExecutionDetail);
	transactionalLoaderService.completeLoad(regRepPrJobExecutionDetail);
	logger.info("RegRepPrAlgoValTrioptima Load Finished For "	+ regRepPrJobDetail.getJobDesc());
	}

	private void loadValFile(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) throws IOException {
	logger.info("Generating triOptima report");
		
	Date asofDate = regRepPrAlgoVallRepository.findMaxAsofDateNonCollateralized();
	Date cobDate = null;
	
	if (asofDate !=null){
		Iterable<RegRepPrAlgoValuation> iterator = regRepPrAlgoVallRepository.findActiveNonCollateralized(asofDate);	
		
		cobDate = transactionalLoaderService.findActiveNonCollateralizedCobDate(asofDate);
		DateFormat formatter ; 
   	    formatter = new SimpleDateFormat("yyyyMMdd");
   	    String algoFileName = "WF_non.collateralized_COB_"+formatter.format(cobDate)+".csv";
   	    logger.info("Folder where file is Created is "+outputFolderName);
   	    File algoFolder = new File(outputFolderName);
   	    File algoFile;
	   	 if (algoFolder.exists() && algoFolder.isDirectory()) {
	   	   //create algo file here
	   		 algoFile = new File(algoFolder +File.separator+ algoFileName);
	   	 }else {
	   		algoFolder.mkdirs();
	   		 algoFile = new File(algoFolder+File.separator + algoFileName);
	   	 }
		FileWriter fw = new FileWriter(algoFile);
		fw.append("Fullname,TradeID,TradeDate,MaturityDate,Not1 Ccy,Notional1,Not2 Ccy,Notional2,ProductID,Base Ccy,PV in base ccy,COB Date of PV,Effective Date,PVCcy,PV,Buy/Sell,IMargin,Put/Call,StrikePrice,Underlying Name,Book,Trader,Cpty Trade ID,Cpty Branch,Collateralized\n");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		DecimalFormat numberFormat = new DecimalFormat("#0.00#");
		try {
			for (RegRepPrAlgoValuation entry : iterator) {
				String fullName = "";
				
				if(null!=entry.getFullName()){
				 fullName = entry.getFullName().toString().replace("\"","");
				 fullName = "\""+fullName+"\"";
				}
				fw
				.append(fullName).append(',')
				.append(entry.getSourceSystem()).append(entry.getTradeId()).append(safeDateFormat(dateFormat, entry.getTradeDate())).append(',')
				.append(safeDateFormat(dateFormat, entry.getTradeDate())).append(',')
				.append(safeDateFormat(dateFormat, entry.getMaturityDate())).append(',')
				.append(safeStringFormat(entry.getNotional1Ccy())).append(',')
				.append(safeNumberFormat(numberFormat, entry.getNotional1())).append(',')
				.append(safeStringFormat(entry.getNotional2Ccy())).append(',')
				.append(safeNumberFormat(numberFormat, entry.getNotional2())).append(',')
				.append(safeStringFormat(entry.getProductId())).append(',')
				.append(safeStringFormat(entry.getPvCcy())).append(',')
				.append(safeStringFormatAsNumber(numberFormat, entry.getPv())).append(',')
				.append(safeDateFormat(dateFormat, entry.getPvCobDate())).append(',')
				.append(safeDateFormat(dateFormat, entry.getEffectiveDate())).append(',')
				.append(safeStringFormat(entry.getPvCcy())).append(',')
				.append(safeStringFormatAsNumber(numberFormat, entry.getPv())).append(',')
				.append(safeStringFormat(entry.getBuyOrSell())).append(',')
				.append(safeStringFormat(entry.getImargin())).append(',') //IMargin
				.append(safeStringFormat(entry.getPutCall())).append(',') //Put/Call
				.append(safeStringFormat(entry.getStrikePrice())).append(',') //StrikePrice
				.append(safeStringFormat(entry.getUnderlyingName())).append(',')
				.append(safeStringFormat(entry.getBook())).append(',')
				.append(safeStringFormat(entry.getTrader())).append(',')
				.append(safeStringFormat(entry.getCptyTradeId())).append(',')
				.append(safeStringFormat(entry.getCptyBranch())).append(',')
				.append(safeStringFormat(entry.getCollateralized()))
				.append('\n');
			}			
		} finally {
			fw.close();
		}
		logger.info("triOptima report has been generated: " + algoFile.getCanonicalPath());
		portRecReportDeliveryRequestSubmitter.submit(new PortrecReportDeliveryRequest("ALL", "TriOptimaValuation", algoFile));
		}
	}
	
	private String safeNumberFormat(NumberFormat format, Number value) {
		if (value == null)
			return "";
		
		try {
			return format.format(value);
		} catch (Exception e) {
			throw new RuntimeException("Couldn't format " + value + " as number");
		}
	}
	
	private String safeDateFormat(DateFormat format, Date value) {
		if (value == null)
			return "";
		
		try {
			return format.format(value);
		} catch (Exception e) {
			throw new RuntimeException("Couldn't format " + value + " as date");
		}
	}
	
	private String safeStringFormatAsNumber(NumberFormat format, String value) {
		if (value == null)
			return "";
		
		BigDecimal decimal = null;
		try {
			decimal = new BigDecimal(value);
		} catch (NumberFormatException nfe) {
			throw new RuntimeException("Couldn't format " + value + " as number");
		}
		
		return format.format(decimal);
	}

	private String safeStringFormat(String str) {
		if (str == null)
			return "";
		
		return str;
	}
	
	public static String getDateFromStrValuation(Date date) throws ParseException {
		DateFormat formatter ; 
   	    formatter = new SimpleDateFormat("yyyyMMdd");
		return formatter.format(date);
	}
	
	@Service
	@Transactional(value="portrec")
	public static class TransactionalLoaderServiceforTrioptima extends RegRepPrJob{
		@Autowired
		RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

		@PersistenceContext(unitName = "Portrec")
		EntityManager entityManager;

		Logger logger = Logger.getLogger(getClass());

		public RegRepPrJobExecutionDetail startLoad(String fileName,
				RegRepPrJobDetail regRepPrJobDetail, Date asOfDate) {

			RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();
			regRepPrJobExecutionDetail.setJobDetailsId(regRepPrJobDetail);
			regRepPrJobExecutionDetail.setAsOfDate(asOfDate);
			regRepPrJobExecutionDetail.setFileName(fileName);
			regRepPrJobExecutionDetail.setJobStatus("PROCESSING");
			regRepPrJobExecutionDetail.setCreateDatetime(new Date());

			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

			return regRepPrJobExecutionDetail;
		}

		public void saveTrades(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail, Collection<RegRepPrCid> loadCptyFreqData) {
			for (RegRepPrJob trade : loadCptyFreqData) {
				trade.setJobExecutionId(regRepPrJobExecutionDetail);
				regRepPrJobExecutionDetail.setRecodsLoaded(regRepPrJobExecutionDetail.getRecodsLoaded() + 1);
				entityManager.persist(trade);
			}
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		}

		public void completeLoad(
				RegRepPrJobExecutionDetail regRepPrJobExecutionDetail) {
			regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
			if(regRepPrJobExecutionDetail.getRecodsLoaded() == regRepPrJobExecutionDetail.getRecordsTotal())
			{
				regRepPrJobExecutionDetail.setJobStatus("SUCCESS");
			}
			else
			{
				regRepPrJobExecutionDetail.setJobStatus("ERROR");
			}
			   
			regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
		}
		
		public Date findActiveNonCollateralizedCobDate(Date date){
			String query = "select vae.pvCobDate from RegRepPrAlgoValuation vae where collateralized = 'N' and asOfDate= :date";
			return entityManager.createQuery(query, Date.class)
			.setParameter("date", date)
			.setMaxResults(1)
			.getSingleResult();
		}

	}
}


