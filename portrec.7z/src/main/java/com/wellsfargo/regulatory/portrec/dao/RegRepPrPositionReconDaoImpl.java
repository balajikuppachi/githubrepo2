package com.wellsfargo.regulatory.portrec.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dto.PositionRecon;

/**
 * @author Raji Komatreddy
 */

@Component
public class RegRepPrPositionReconDaoImpl
{
	@Autowired
	@Qualifier("portrecJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	String sql = "insert into REG_REP_PR_POSITION_RECON (job_execution_id, cid_cpty_id,"
					+ 	" as_of_date, recon_freq, portfolio_size, ir_position_size, cr_position_size,"
					+ " eq_position_size, fx_position_size,comm_position_size,valuation_size, create_datetime)"
					+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

	Logger logger = Logger.getLogger(RegRepPrPositionReconDaoImpl.class);

	public int batchInsertPositionRecon(final List<PositionRecon> positionReconList) throws PortrecException
	{

		java.util.Date currDate = new java.util.Date();
		try
		{
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{
					PositionRecon currPositionRecon = positionReconList.get(i);

					ps.setLong(1, currPositionRecon.getJobExecutionId());
					ps.setInt(2, currPositionRecon.getCidCptyId());
					if (null != currPositionRecon.getAsOfDate())
					{
						ps.setDate(3, (Date) new java.sql.Date(currPositionRecon.getAsOfDate().getTime()));
					}
					else
					{
						ps.setDate(3, null);
					}
					ps.setString(4, currPositionRecon.getReconFreq());
					ps.setInt(5, currPositionRecon.getPortfolioSize());
					ps.setInt(6, currPositionRecon.getIrPositionSize());
					ps.setInt(7, currPositionRecon.getCrPositionSize());
					ps.setInt(8, currPositionRecon.getEqPositionSize());
					ps.setInt(9, currPositionRecon.getFxPositionSize());
					ps.setInt(10, currPositionRecon.getCommPositionSize());
					ps.setInt(11, currPositionRecon.getValuationSize());
					ps.setDate(12, new java.sql.Date(currDate.getTime()));

				}

				@Override
				public int getBatchSize()
				{
					return positionReconList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrPositionReconDaoImpl :batchInsertPositionRecon method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrPositionReconDaoImpl :batchInsertPositionRecon method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrPositionReconDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);
		}

		logger.info("from batchInsertCptyReconFreq : number of records inserted" + positionReconList.size());

		return positionReconList.size();

	}

}
