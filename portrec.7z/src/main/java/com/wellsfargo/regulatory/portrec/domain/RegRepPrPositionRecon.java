package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * @author Raji Komatreddy
 * The persistent class for the REG_REP_PR_POSITION_RECON database table.
 * 
 */
@Entity
@Table(name="REG_REP_PR_POSITION_RECON")
public class RegRepPrPositionRecon extends RegRepPrJob {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="position_recon_id")
	private Long positionReconId;

	@Temporal(TemporalType.DATE)
	@Column(name="as_of_date")
	private Date asOfDate;

	@Column(name="cid_cpty_id")
	private int cidCptyId;

	@Column(name="comm_position_size")
	private int commPositionSize;

	@Column(name="cr_position_size")
	private int crPositionSize;

	@Column(name="create_datetime")
	private Date createDatetime;

	@Column(name="eq_position_size")
	private int eqPositionSize;

	@Column(name="fx_position_size")
	private int fxPositionSize;

	@Column(name="ir_position_size")
	private int irPositionSize;

	@Column(name="portfolio_size")
	private int portfolioSize;

	@Column(name="recon_freq")
	private String reconFreq;
	
	@Column(name="valuation_size")
	private int valuationSize;

	public RegRepPrPositionRecon() {
	}

	public Long getPositionReconId() {
		return this.positionReconId;
	}

	public void setPositionReconId(Long positionReconId) {
		this.positionReconId = positionReconId;
	}

	public Date getAsOfDate() {
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate) {
		this.asOfDate = asOfDate;
	}

	public int getCidCptyId() {
		return this.cidCptyId;
	}

	public void setCidCptyId(int cidCptyId) {
		this.cidCptyId = cidCptyId;
	}

	public int getCommPositionSize() {
		return this.commPositionSize;
	}

	public void setCommPositionSize(int commPositionSize) {
		this.commPositionSize = commPositionSize;
	}

	public int getCrPositionSize() {
		return this.crPositionSize;
	}

	public void setCrPositionSize(int crPositionSize) {
		this.crPositionSize = crPositionSize;
	}

	public Date getCreateDatetime() {
		return this.createDatetime;
	}

	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}

	public int getEqPositionSize() {
		return this.eqPositionSize;
	}

	public void setEqPositionSize(int eqPositionSize) {
		this.eqPositionSize = eqPositionSize;
	}

	public int getFxPositionSize() {
		return this.fxPositionSize;
	}

	public void setFxPositionSize(int fxPositionSize) {
		this.fxPositionSize = fxPositionSize;
	}

	public int getIrPositionSize() {
		return this.irPositionSize;
	}

	public void setIrPositionSize(int irPositionSize) {
		this.irPositionSize = irPositionSize;
	}

	public int getPortfolioSize() {
		return this.portfolioSize;
	}

	public void setPortfolioSize(int portfolioSize) {
		this.portfolioSize = portfolioSize;
	}

	public String getReconFreq() {
		return this.reconFreq;
	}

	public void setReconFreq(String reconFreq) {
		this.reconFreq = reconFreq;
	}

	public int getValuationSize() {
		return valuationSize;
	}

	public void setValuationSize(int valuationSize) {
		this.valuationSize = valuationSize;
	}

}