package com.wellsfargo.regulatory.portrec.mailer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCid;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCptyReconFreq;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconCalendar;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.reports.PrPreRunReportWriter;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCidRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCptyReconFreqRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobExecutionDetailRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 */
@Component
@ManagedResource(description = "Counter Party Portfolio Reconcilliation")
public class CptyReconProcess
{

	private final Logger logger = Logger.getLogger(CptyReconProcess.class);

	@Autowired
	PrEmailTemplateService prMailingService;

	@Autowired
	CptyExtractGeneratorService cptyExtractGeneratorService;

	@Autowired
	RegRepPrCptyReconFreqRepository repPrCptyReconFreqRepository;

	@Autowired
	RegRepPrCidRepository regRepPrCidRepository;

	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;

	@Autowired
	RegRepPrJobExecutionDetailRepository regRepPrJobExecutionDetailRepository;

	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;
	
	@Autowired
	CalendarService calendarService;
	
	@Autowired
	PrPreRunReportWriter prPreRunReportWriter;
	
	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;

	
	@Value("${mail.process.flag}")
	String emailSendFlag;
	
	@Value("${cpty.recon.qualifier.flag}")
	String qualifierFlagStr;
	
	@Value("${days.email.data.delivery.date}")
	int noOfDaysToDataDeliveryDate;
	
	@Value("${days.email.affirm.date}")
	int noOfDaysToAffirmDate;
	
	@Autowired
	PrEmailManagerSvc prEmailManagerSvc;

	@ManagedOperation(description = "Starting Recon Process")
	public Message<?> startCptyPortfolioRecon(Message<?> message) throws PortrecException
	{
		
		long timeStart = System.currentTimeMillis();
		logger.info("Start Recon Process - ");

		Object ipMessage = null;
		String errorString = null;
		Date reconDate = new Date();
		long currJobExecutionId = 0;
		String jobAsOfDateInString = null;
		Date asOfDate = null;
		Date jobAsOfDate = null;
		List<CptyReconInformation> cptyReconInformationList = null;
		boolean proceedToNextJob = false;
		RegRepPrJobDetail currRegRepPrJobDetail = null;
		String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
		SimpleDateFormat reconDateFormat = new SimpleDateFormat(dateFormat);
		HashMap<String, List<Integer>>  mulLegalIDMap = new HashMap<String, List<Integer>>();
		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconProcess-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		
		ipMessage = message.getPayload();
		
		if (null != message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE)) 
		{
			jobAsOfDateInString = message.getHeaders().get(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE).toString();
		}
		
		if (null != jobAsOfDateInString)
		{
			logger.info(" recon process running for asOfDate received from fileName " + jobAsOfDateInString);
			try
			{
				jobAsOfDate = reconDateFormat.parse(jobAsOfDateInString);
			}
			catch (ParseException e)
			{
				logger.error("########## " + e.getMessage());
				// e.printStackTrace();
			}
		}
		

		if (ipMessage instanceof RegRepPrJobDetail)
		{
			currRegRepPrJobDetail = (RegRepPrJobDetail) message.getPayload();
		}

		if (null == currRegRepPrJobDetail)
		{
			errorString = "Null incoming PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconProcess-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		RegRepPrJobExecutionDetail regRepPrJobExecutionDetail = new RegRepPrJobExecutionDetail();

		// tradeFile.setId(new BigDecimal(10000001));
		regRepPrJobExecutionDetail.setJobDetailsId(currRegRepPrJobDetail);
		regRepPrJobExecutionDetail.setAsOfDate(reconDate);
		regRepPrJobExecutionDetail.setFileName(currRegRepPrJobDetail.getJobName());
		regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_PROCESSING);
		regRepPrJobExecutionDetail.setCreateDatetime(new Date());

		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

		if (null == regRepPrJobExecutionDetail)
		{
			errorString = "exception occured while inserting a record in JobExecutionDetails table";
			logger.error("########## " + errorString);
			throw new PortrecException("CptyReconProcess-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);

		}

		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		logger.info("jobExecution id for current run of CptyReconProcess " + currJobExecutionId);

		try
		{
			Map<String, Map<Integer, CptyReconInformation>>  map = createCpPortfolioMap(currJobExecutionId);
			
			if(null != map && !map.isEmpty())
			{
				Set<String> freqKeys = map.keySet();
				
				if(null != freqKeys && !freqKeys.isEmpty())
				{
					logger.info("Number of recon frequency : " + freqKeys.size());
					
					prPreRunReportWriter.misPreFileGeneration(currJobExecutionId, map);				 	
					
					// Added for LEI mapping multiple legal ID issue
					List<Object[]> leisWithMulLglID = regRepPrLiveTradeRepository.findLegalIDLEIS();
					
					if(!leisWithMulLglID.isEmpty()){
						for (Object[] e : leisWithMulLglID){
						String lei = (String) e[0];
						int lglID = (int) e[1];
						if(lglID!=0){
						List<Integer> lgllist = new ArrayList<Integer>();
							lgllist.add(lglID);
							if(mulLegalIDMap.containsKey(lei)){
								List<Integer> l = mulLegalIDMap.get(lei);
									for(Integer lg : l){
											lgllist.add(lg);
									}
								}
								mulLegalIDMap.put(lei, lgllist);		
							}
						}
					} // ENDS for LEI mapping multiple legal ID issue

					for(String key : freqKeys)
					{
						Map<Integer, CptyReconInformation>  mapOfLegalIds = map.get(key);
						cptyReconInformationList = new ArrayList<CptyReconInformation>();
						
						String[] keyArray = key.split(":");
						
						String reconFrequency = null;
						
						if(null != keyArray && keyArray.length > 0){
							reconFrequency = keyArray[0];
						}
						
						if(null != mapOfLegalIds && !mapOfLegalIds.isEmpty())
						{
							Set<Integer> legalIds = mapOfLegalIds.keySet();
							
							logger.info("Number of Cp : " + legalIds.size());
							
							for(Integer legalId : legalIds)
							{
								CptyReconInformation prCptyInformation = mapOfLegalIds.get(legalId);
								asOfDate = prCptyInformation.getAsOfDate();
								reconDate = prCptyInformation.getDispatchDate();
								cptyReconInformationList.add(prCptyInformation);
							} // end for loop over eligible counter parties 
							
							cptyReconInformationList = cptyExtractGeneratorService.generateExtracts(cptyReconInformationList,mulLegalIDMap,currJobExecutionId, reconFrequency, asOfDate );
							
							if(null != prEmailManagerSvc)
							{
								prEmailManagerSvc.sendEmailsToCptys(cptyReconInformationList, asOfDate, currJobExecutionId, reconFrequency);
							}							
							
						}
						cptyReconInformationList.clear();  // clear the list before iterating for next one
						proceedToNextJob = true;
					}
				}
			}
		}
		catch (PortrecException ex)
		{
			proceedToNextJob = false;
			regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
			regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
			regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);
			
			errorString = "Failed while creating cp map." + ex.getMessage();
			logger.error("Exception-4 inside CptyReconProcess for jobId #" + currJobExecutionId + "exception message " + errorString);
			throw new PortrecException("CptyReconProcess-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);

		}
		catch (Exception ex)
		{
			logger.error("Error-5 in Recon Process : " + ex.getMessage());
			try
			{
				proceedToNextJob = false;
				regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_ERROR);
				regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
				regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);

				errorString = ex.getMessage();
				logger.error("Exception-5 inside CptyReconProcess for jobId #" + currJobExecutionId + "exception message " + errorString);
				portrecExceptionLogger.logException("CptyReconProcess-5", errorString, ExceptionUtils.getStackTrace(ex), currJobExecutionId, null);
			}
			catch (Exception e)
			{
				logger.error("exception while logging exception to DB " + ExceptionUtils.getStackTrace(e));
			}

		}

		/*regRepPrJobExecutionDetail.setJobStatus(PortrecConstants.PORTREC_JOB_SUCCESS);
		regRepPrJobExecutionDetail.setUpdateDatetime(new Date());
		regRepPrJobExecutionDetail = regRepPrJobExecutionDetailRepository.save(regRepPrJobExecutionDetail);*/
		
		if(!proceedToNextJob){
			logger.info("CALENDAR table run_date doesn't match with today's date. So Recon process would not run.");
			reconDate = null;
		}
		
		message = MessageBuilder.withPayload(regRepPrJobExecutionDetail).setHeader(PortrecConstants.PORTREC_JOB_HEADER_RECON_DATE,  
				reconDate).setHeader(PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE, asOfDate).build();		

		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in Recon Process : " + PortRecUtil.printTimeTaken(timeEnd - timeStart));
		
		return message;
		
	}
	
	
	public Map<String, Map<Integer, CptyReconInformation>> createCpPortfolioMap(long currJobExecutionId) throws PortrecException
	{
		
		logger.info("****** START : cp portfolio map creation ******");
		
		Map<String, Map<Integer, CptyReconInformation>> map = new LinkedHashMap<String, Map<Integer, CptyReconInformation>>();
		
		String key = null;
		Date asOfDate = null;
		Date firstBussDayAfterAsOfDate = null;
		List<RegRepPrReconCalendar> reconCalList = null;
		List<RegRepPrCid> allRegRepPrCidList  = null;
		Map<Integer,RegRepPrCid>  regRepPrCidMap = null;
		Map<Integer, CptyReconInformation> legalIdMap = null;
		String reconFrequency  = null;
		List<RegRepPrCptyReconFreq> allEligibleCPs = null;
		boolean qualifierFlag = false;
		
		try
		{
			Date reconDate = new SimpleDateFormat("yyyy-MM-dd").parse(PortRecUtil.convertDateToString_yyyy_MM_dd(new Date()));
			
			reconCalList = regRepPrReconCalendarRepository.findByDate(reconDate);			
			
			if(null != qualifierFlagStr && !qualifierFlagStr.equalsIgnoreCase(""))
			{
				qualifierFlag = new Boolean(qualifierFlagStr);
			}
			
			if(qualifierFlag)
			{
				allRegRepPrCidList = regRepPrCidRepository.findAllFromCidWhereQualifierY();
			}else
			{
				allRegRepPrCidList = regRepPrCidRepository.findAllFromCid();
			}
			
			regRepPrCidMap = new HashMap<Integer,RegRepPrCid>();
						
			if(null != allRegRepPrCidList)
			{
				for(RegRepPrCid currRegRepPrCid :allRegRepPrCidList )
				{
					Integer currLegalId = currRegRepPrCid.getLgleIdC();
					regRepPrCidMap.put(currLegalId, currRegRepPrCid);
				}
			}
			
		 //   legalIdMap = new LinkedHashMap<Integer, CptyReconInformation>();
			
			for (RegRepPrReconCalendar reconCalItem : reconCalList)
			{
				try 
				{
					reconFrequency = reconCalItem.getReconFreq();					
					reconDate = reconCalItem.getRunDate();					
					asOfDate = reconCalItem.getAsOfDate();
					firstBussDayAfterAsOfDate = calendarService.getNextWorkingDay(asOfDate);
					
					 legalIdMap = new LinkedHashMap<Integer, CptyReconInformation>();
					
					key = reconFrequency + ":" + asOfDate;
					
					allEligibleCPs = repPrCptyReconFreqRepository.findByReconFrequency(reconFrequency);
					
					int legalId  = 0;	
					RegRepPrCid cptyCID = null;
					//String qualifier = null;
					String emailAddress = null;
					Date deliveryDate = calendarService.dateIncrement(reconDate, noOfDaysToDataDeliveryDate);
					Date affirmDate = calendarService.dateIncrement(reconDate, noOfDaysToAffirmDate);
					
					for (RegRepPrCptyReconFreq eligibleCounterParty : allEligibleCPs)
					{
						try
						{
							legalId  = eligibleCounterParty.getCidCptyId();
		
						//	List<RegRepPrCid> cptyCidData = regRepPrCidRepository.findByLegalId(legalId);
		
						//	RegRepPrCid cptyCID = null;
							cptyCID  = regRepPrCidMap.get(legalId);		
							
							if(null == cptyCID)
							{
								String errorMsg = "No record found for given legal Id in CID map";
								portrecExceptionLogger.logExceptionScenario("CptyReconProcess-4",errorMsg, null, currJobExecutionId, Long.valueOf(legalId));
								continue;
							}
													
		
							CptyReconInformation prCptyInformation = new CptyReconInformation();
		
							prCptyInformation.setCidCptyId(legalId);
							
							prCptyInformation.setFullLegalName(cptyCID.getLgleFullN());
							
							String[] customerName = new String[2];		
							try{
								customerName = portRecBusinessUtil.getCustomerName(StringUtils.trim(cptyCID.getContactName()));
							}
							catch(Exception ae)
							{
								
								if(null != cptyCID.getContactName()){
									customerName[0] = cptyCID.getContactName().replaceAll("'", "").replaceAll(",", " ");
									customerName[1] = null;
								}
								
								String errorMsg = "Error Parsing Customer Name : "+ cptyCID.getContactName();
								portrecExceptionLogger.logExceptionScenario("CptyReconProcess-5", errorMsg, ae, currJobExecutionId, Long.valueOf(legalId));
							}
							prCptyInformation.setCustomerName1(customerName[0]);
							prCptyInformation.setCustomerName2(customerName[1]);
		
							String[] customerAddress1 = portRecBusinessUtil.getCustomerAddress(StringUtils.trim(cptyCID.getAddressLine1()));
							prCptyInformation.setAddressLine1(customerAddress1[0]);
							
							String[] customerAddress2 = portRecBusinessUtil.getCustomerAddress(StringUtils.trim(cptyCID.getAddressLine2()));
							prCptyInformation.setAddressLine2(customerAddress2[0]);
							
							 emailAddress = cptyCID.getEmailAddress();							
		
							prCptyInformation.setEmailAddress(emailAddress);
		
							prCptyInformation.setCity(StringUtils.trim(cptyCID.getCity()));
							prCptyInformation.setState(StringUtils.trim(cptyCID.getState()));
							prCptyInformation.setCountry(StringUtils.trim(cptyCID.getCountry()));
							prCptyInformation.setZipCode(StringUtils.trim(cptyCID.getZipCode()));
							
							prCptyInformation.setDomIntl(portRecBusinessUtil.isCustomerDomOrIntl(StringUtils.trim(cptyCID.getCountry())));
							prCptyInformation.setJsFlag(StringUtils.trim(cptyCID.getJsFlag()));
		
							prCptyInformation.setCptyType(eligibleCounterParty.getCptyType());
							prCptyInformation.setReconFreq(reconFrequency);
							
							prCptyInformation.setPortfolioSize(eligibleCounterParty.getPortfolioSize());
							prCptyInformation.setCommoditySize(eligibleCounterParty.getCommoditySize());
							prCptyInformation.setIrSize(eligibleCounterParty.getIrSize());
							prCptyInformation.setCrSize(eligibleCounterParty.getCrSize());
							prCptyInformation.setEquitySize(eligibleCounterParty.getEquitySize());
							prCptyInformation.setFxSize(eligibleCounterParty.getFxSize());
							prCptyInformation.setFxIntlSize(eligibleCounterParty.getFxIntlSize());
		
							// EMAIL - Notice dispatch date is the recon date
							prCptyInformation.setDispatchDate(reconDate);
							
							// EMAIL - Data Delivery date is the recon date plus 2 days
							prCptyInformation.setDataDeliveryDate(deliveryDate);
		
							// For both Email and US Mail Record Date is asOfDate.
							prCptyInformation.setRecordDate(asOfDate);
							
							// EMAIL - Affirm date is the recon date plus 4 days
							prCptyInformation.setAffirmDate(affirmDate);
							
							prCptyInformation.setAsOfDate(asOfDate);
							
							//Date firstBussDayAfterAsOfDate = calendarService.getNextWorkingDay(asOfDate);
							
							prCptyInformation.setNextBusWorkingDate(firstBussDayAfterAsOfDate);
							
							legalIdMap.put(legalId, prCptyInformation);
						
						}
						catch(Exception ex)
						{
							String errorMsg = "Error while creating cp map :" + ex.getMessage();
							portrecExceptionLogger.logExceptionScenario("CptyReconProcess-6", errorMsg, ex, currJobExecutionId, Long.valueOf(legalId));
						}
					}
					
					map.put(key, legalIdMap);
				}
				catch(Exception ex)
				{
					String errorMsg = "Error while creating cp map :" + ex.getMessage();
					portrecExceptionLogger.logExceptionScenario("CptyReconProcess-7", errorMsg, ex, currJobExecutionId, null);
				}
			}
		}
		catch(Exception ex){
			String errorMsg = "Error while creating cp map :" + ex.getMessage();
			portrecExceptionLogger.logExceptionScenario("CptyReconProcess-8", errorMsg, ex, currJobExecutionId, null);
			throw new PortrecException("CptyReconProcess-8", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorMsg, ex);
		}
		
		logger.info("****** END	: cp portfolio map creation ******");
		return map;
	}
	
}