package com.wellsfargo.regulatory.portrec.enums;

/**
 * @author u235720
 *
 */
public enum CommunicationTypeEnum
{

	EMAIL("EMAIL"), DUC("DUC");

	private final String value;

	public String type()
	{

		return toString();
	}

	public String getValue()
	{

		return toString();
	}

	CommunicationTypeEnum(String v)
	{

		value = v;
	}

	public static CommunicationTypeEnum fromValue(String v)
	{

		for (CommunicationTypeEnum c : CommunicationTypeEnum.values())
		{

			if (c.value.equals(v))
			{
				return c;
			}
		}

		throw new IllegalArgumentException(v);
	}
}
