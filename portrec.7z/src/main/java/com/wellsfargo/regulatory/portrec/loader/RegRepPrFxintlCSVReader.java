package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.common.FxInternationalReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrFxIntlExtract;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;


@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrFxintlCSVReader extends LoaderHelper<RegRepPrFxIntlExtract> {
	
	public static String PORTFOLIO_SEGMENT_NAME = "ForeignExchange, FX_INTL";
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.FX;
	}

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new FxInternationalReader(inputStream);
	}

	@Override
	public RegRepPrFxIntlExtract parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		
		RegRepPrFxIntlExtract fxIntlExtract = new RegRepPrFxIntlExtract();
		
		fxIntlExtract.setUsiValue(fields[0]);
		fxIntlExtract.setParty1Lei(fields[1]);
		fxIntlExtract.setIsParty1Sd(fields[2]);
		fxIntlExtract.setIsParty1Msp(fields[3]);
		fxIntlExtract.setIsParty1Fin(fields[4]);
		fxIntlExtract.setIsParty1UsPerson(fields[5]);
		fxIntlExtract.setAllocationIndicator(fields[6]);
		fxIntlExtract.setAgentLei(fields[7]);
		fxIntlExtract.setIsPostallocation(fields[8]);
		fxIntlExtract.setParty1AgentUsiValue(fields[9]);
		fxIntlExtract.setParty2Lei(fields[10]);
		fxIntlExtract.setParty2InternalId(fields[11]);
		fxIntlExtract.setIsParty2Sd(fields[12]);
		fxIntlExtract.setIsParty2Msp(fields[13]);
		fxIntlExtract.setIsParty2Fin(fields[14]);
		fxIntlExtract.setIsParty2UsPerson(fields[15]);
		fxIntlExtract.setProductId(fields[16]);
		fxIntlExtract.setCftcProductId(fields[17]);
		fxIntlExtract.setSdrInternalProductId(fields[18]);
		fxIntlExtract.setIsMultiassetSwap(fields[19]);
		if(StringUtils.isBlank(fields[20]))
			fxIntlExtract.setPrimaryAssetClass("FOREIGNEXCHANGE");
		else
			fxIntlExtract.setPrimaryAssetClass(fields[20]);
		fxIntlExtract.setSecondaryAssetClass(fields[21]);
		fxIntlExtract.setIsMixedSwap(fields[22]);
		fxIntlExtract.setSdr2Id(fields[23]); 
		fxIntlExtract.setContractType(fields[24]);
		fxIntlExtract.setBlockTradeIndicator(fields[25]);
		fxIntlExtract.setExecutionTimestamp(getDateFromTimeStamp(fields[26]));					
		fxIntlExtract.setExecutionVenue(fields[27]);
		fxIntlExtract.setCcy1(fields[28]); //NotionalCurrency1
		fxIntlExtract.setCcy2(fields[29]); //NotionalCurrency2
		if (StringUtils.isNotBlank(fields[30]))
			fxIntlExtract.setNotionalAmount1(convertStrToBigDecimalForNotionalAmt(fields[30]));
		if (StringUtils.isNotBlank(fields[31]))
			fxIntlExtract.setNotionalAmount2(convertStrToBigDecimalForNotionalAmt(fields[31]));
		fxIntlExtract.setExchangeRate(stringToBigDecimal(fields[32]));
		fxIntlExtract.setDeliveryType(fields[33]);
		if (StringUtils.isNotBlank(fields[34]))
			fxIntlExtract.setSettlementExpirationDate(DateUtilLoader.getDateFromString(fields[34]));
		fxIntlExtract.setSubmissionTimestamp(fields[35]);
		fxIntlExtract.setIsClearingIndicator(fields[36]);
		fxIntlExtract.setClearingVenue(fields[37]);
		fxIntlExtract.setIsClearingReqExc(fields[38]);
		fxIntlExtract.setClearingReqExcId(fields[39]);
		fxIntlExtract.setCollaterized(fields[40]);
		fxIntlExtract.setPremiumCurrency(fields[41]);	
		
		if (StringUtils.isNotBlank(fields[42]))
			fxIntlExtract.setPremiumAmount(convertStrToBigDecimalForNotionalAmt(fields[42]));
		
		if (StringUtils.isNotBlank(fields[43]))
			fxIntlExtract.setFixingDate(DateUtilLoader.getDateFromString(fields[43]));
		
		fxIntlExtract.setSettlementCcy(fields[44]);
		fxIntlExtract.setReportingParty(fields[45]);
		fxIntlExtract.setIsClearedTrade(fields[46]);
		
		if (StringUtils.isNotBlank(fields[47]))
			fxIntlExtract.setSettlementFixingDate(DateUtilLoader.getDateFromString(fields[47]));
		
		if (StringUtils.isNotBlank(fields[48]))
			fxIntlExtract.setSettlementFixingTime(DateUtilLoader.getDateFromString(fields[48]));
		
		fxIntlExtract.setSettlementFixingBusCenter(fields[49]);
		fxIntlExtract.setMtmPositionValue(fields[50]);
		
		if (StringUtils.isNotBlank(fields[51]))
			fxIntlExtract.setBusinessAccountId(convertStrToBigDecimalForNotionalAmt(fields[51]));
		
		fxIntlExtract.setAsOfDate(asofDate);
		return fxIntlExtract;
	}

	@Override
	public boolean validate(RegRepPrFxIntlExtract trade) {
		return true;
	}
	
	private String getDateFromTimeStamp(String timeStamp) {	
		String date;
		if( null != timeStamp && StringUtils.isNotBlank(timeStamp)){
			String[] tokens = timeStamp.split(" ");	
			date = tokens[0];
		}else{
			date = timeStamp;
		}
		return date;
	}

	@Override
	public RegRepPrFxIntlExtract getTableName() {
		return new RegRepPrFxIntlExtract();
	}

	@Override
	public boolean deletePrevDayRecords() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String loadNextJob() {
		return null;
	}
}
