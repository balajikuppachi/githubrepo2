package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.business.CalendarService;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobExecutionDetail;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrReconReport;
import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconCalendarRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrReconReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

@Component
public class DucDomesticCsvWriter {

	private final Logger logger = Logger.getLogger(DucDomesticCsvWriter.class);

	protected String customer_name_1 = null;
	protected String customer_name_2 = null;
	protected String address_Line1 = null;
	protected String address_Line2 = null;
	protected String city = null;
	protected String state = null;
	protected String zipCode = null;
	protected String country = null;

	/*protected Date todayDate = null;
	protected Date runDate=null;
	protected Date record_date =null;*/
	
	
	protected Integer cid_leid;
	protected String domInt;
	protected Integer js_indicator;
	//protected String customer_full_name = null;

	@Value("${file.duc.outputFolder}")
	String outputFolderName;
	@Value("${days.duc.noticeDispatchDate}")
	int no_of_days_notice_dispatch_date;
	@Value("${days.duc.dataDeliveryDate}")
	int no_of_days_data_delivery_date;
	@Value("${days.duc.affirmDate}")
	int no_of_days_affirm_date;
	
	@Autowired
	CalendarService calendarService;
	@Autowired
	RegRepPrReconReportRepository regRepPrReconReportRepository;
	@Autowired
	RegRepPrReconCalendarRepository regRepPrReconCalendarRepository;
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	static char SEPARATOR = '|';

	public void write(RegRepPrJobExecutionDetail regRepPrJobExecutionDetail,List<RegRepPrReconReport> regRepPrReconReportList, Date asOfDate, Date reconDate) throws IOException, ParseException {
		long timeStart = System.currentTimeMillis();
		logger.info("writing domestic duc file...");
		logger.info("Please wait for some time... ");
		long currJobExecutionId = 0;
		currJobExecutionId = regRepPrJobExecutionDetail.getJobExecutionId();
		File ducFolder = new File(outputFolderName);
		File ducFile;
		if (ducFolder.exists() && ducFolder.isDirectory()) {
			// create duc file here
			ducFile = new File(ducFolder + File.separator + (PortrecConstants.DUC_FILE_NAME+PortrecConstants.UNDERSCORE+PortRecUtil
					.convertDateToString_yyyyMdd(asOfDate)+ ".csv"));
		} else {
			ducFolder.mkdirs();
			ducFile = new File(ducFolder + File.separator + (PortrecConstants.DUC_FILE_NAME+PortrecConstants.UNDERSCORE+PortRecUtil
					.convertDateToString_yyyyMdd(asOfDate)+ ".csv"));
		}
		//FileWriter fw = new FileWriter(ducFile);
		generateCsvFile(ducFile,regRepPrReconReportList, asOfDate, reconDate,currJobExecutionId);
		logger.info("Folder where file created is " + outputFolderName);
		long timeEnd = System.currentTimeMillis();

		logger.info("Total time taken in duc domestic file Process : "
				+ PortRecUtil.printTimeTaken(timeEnd - timeStart));
	}

	private void generateCsvFile(File ducFileName,List<RegRepPrReconReport> regRepPrReconReportList, Date asOfDate, Date reconDate,long currJobExecutionId) {
		try {
			FileWriter writer = new FileWriter(ducFileName);
			writer.append("Customer Name 1");
			writer.append(SEPARATOR);
			writer.append("Customer Name 2");
			writer.append(SEPARATOR);
			writer.append("addressLine1");
			writer.append(SEPARATOR);
			writer.append("addressLine2");
			writer.append(SEPARATOR);

			writer.append("city");
			writer.append(SEPARATOR);
			writer.append("state");
			writer.append(SEPARATOR);
			writer.append("Zip");
			writer.append(SEPARATOR);
			writer.append("country");
			writer.append(SEPARATOR);
			writer.append("Notice Dispatch date");
			writer.append(SEPARATOR);
			writer.append("Record Date");
			writer.append(SEPARATOR);
			writer.append("Data Delivery date");
			writer.append(SEPARATOR);
			writer.append("Affirm date");
			writer.append(SEPARATOR);
			writer.append("SD-Non-SD");
			writer.append(SEPARATOR);
			writer.append("portfolio size");
			writer.append(SEPARATOR);
			writer.append("Frequency");
			writer.append(SEPARATOR);
			writer.append("BusAcct ID");
			writer.append(SEPARATOR);
			writer.append("CID LEID");
			writer.append(SEPARATOR);
			writer.append("Dom/Int");
			writer.append(SEPARATOR);
			writer.append("J&S Indicator");
			writer.append(SEPARATOR);
			writer.append("Customer full name");
			writer.append('\n');
			
			for (RegRepPrReconReport regRepPrReconReport : regRepPrReconReportList) {
				 String customer_full_name = null;
				 String customer_name_1 = null;
				 
				customer_name_1 = regRepPrReconReport.getCustomerName1();
				if (null != customer_name_1) 
				{
					customer_name_1 = replaceSpecialCharsFromStr(customer_name_1);
					writer.append(customer_name_1);
				} 
				else
				{
					customer_name_1 = regRepPrReconReport.getLgleFullN();
					if(null !=customer_name_1 )
					{
						customer_name_1 = replaceSpecialCharsFromStr(customer_name_1);
						writer.append(customer_name_1);
					}
				}
				writer.append(SEPARATOR);
				customer_name_2 = regRepPrReconReport.getCustomerName2();
				if (null != customer_name_2) {
					customer_name_2 = replaceSpecialCharsFromStr(customer_name_2);
					writer.append(customer_name_2);
				} 
				writer.append(SEPARATOR);
				//js_indicator = regRepPrReconReport.getJsFlag();
				address_Line1 = regRepPrReconReport.getAddressLine1();
				address_Line2 = regRepPrReconReport.getAddressLine2();
				
					if (null != address_Line1) {
						address_Line1 = replaceSpecialCharsFromStr(address_Line1);
						writer.append(address_Line1);
					}
					writer.append(SEPARATOR);
					if (null != address_Line2) {
						address_Line2 = replaceSpecialCharsFromStr(address_Line2);
						writer.append(address_Line2);
						
					} 
					writer.append(SEPARATOR);
				 
				city = regRepPrReconReport.getCity();
				
				if (null != city) {
					city = replaceSpecialCharsFromStr(city);
					//city=city.replaceAll(",", " ");
					
					writer.append(city);
				} 
				writer.append(SEPARATOR);
				state = regRepPrReconReport.getState();
				
				if (null != state) {
					state = replaceSpecialCharsFromStr(state);
					//state=state.replaceAll(",", " ");
					writer.append(state);
				} 
				writer.append(SEPARATOR);
				zipCode = regRepPrReconReport.getZipCode();
				
				if (null != zipCode) {
					zipCode=zipCode.replaceAll(",", " ");
					if(zipCode.length()==9){
					zipCode=zipCode.substring(0,5)+"-"+zipCode.substring(5);
					}
					else if(zipCode.length()==4)
					{
						zipCode = 0+zipCode;
					}
					writer.append(zipCode);
				} 
				writer.append(SEPARATOR);
				country = regRepPrReconReport.getCountry();
				if (null != country) {
					country = replaceSpecialCharsFromStr(country);
					//country=country.replaceAll(",", " ");
					writer.append(country);
				} 
				writer.append(SEPARATOR);
				writer.append(PortRecUtil
						.convertDateToString_yyyy_MM_dd(calendarService.dateIncrement(reconDate, no_of_days_notice_dispatch_date)));
				writer.append(SEPARATOR);
				writer.append(PortRecUtil.convertDateToString_MMddyyyy(asOfDate));
				writer.append(SEPARATOR);
				writer.append(PortRecUtil
						.convertDateToString_yyyy_MM_dd(calendarService.dateIncrement(reconDate, no_of_days_data_delivery_date)));
				writer.append(SEPARATOR);
				writer.append(PortRecUtil
						.convertDateToString_yyyy_MM_dd(calendarService.dateIncrement(reconDate, no_of_days_affirm_date)));
				writer.append(SEPARATOR);
				writer.append(PortrecConstants.PARTICIPANT);
				writer.append(SEPARATOR);
				writer.append(PortrecConstants.DUC_PORTFOLIO_SIZE);
				writer.append(SEPARATOR);
				writer.append(PortrecConstants.FREQUENCY);
				writer.append(SEPARATOR);
				writer.append("");
				writer.append(SEPARATOR);
				cid_leid = regRepPrReconReport.getCidCptyId();
				if (null != cid_leid) {
					writer.append(cid_leid.toString());
				} 
				writer.append(SEPARATOR);
				domInt = regRepPrReconReport.getDomInt1();
				if (null != domInt && domInt.equals("D")) {
					writer.append("Domestic");
				} 
				writer.append(SEPARATOR);
				js_indicator = regRepPrReconReport.getJsFlag();
				if (null != js_indicator && js_indicator==1 ) {
					writer.append("Yes");
				}
				else if(null != js_indicator && js_indicator==0){
					writer.append("No");
				}
				
				writer.append(SEPARATOR);
				if(null!=customer_name_1 && null==customer_name_2){
				customer_full_name = customer_name_1;
				}
				if(null!=customer_name_1 && null!=customer_name_2){
				customer_full_name = customer_name_1+ " " + customer_name_2;
				}
				if (null != customer_full_name) {
					writer.append(customer_full_name);
				} 
				writer.append('\n');
			}
			writer.flush();
			writer.close();
		} catch (Exception e) {
			String errorMsg = "exception while generating domestic duc file ";
			portrecExceptionLogger.logExceptionScenario("DucDomesticCsvWriter",errorMsg, e, currJobExecutionId, null);
		}
	}
	
	private static String replaceSpecialCharsFromStr(String orgString)
	{
		String updatedStr = null;
		if(null != orgString)
		{
			updatedStr=StringUtils.replace(orgString, ",", " ");
			updatedStr=StringUtils.replace(updatedStr, "*", " ");
			updatedStr=StringUtils.replace(updatedStr, "'", " ");
			updatedStr=StringUtils.replace(updatedStr, "?", " ");
			updatedStr=StringUtils.replace(updatedStr, " \" ", " ");
			updatedStr=updatedStr.replaceAll("[^a-zA-Z0-9.'&-/]+", " ");
			
		}
		
		
		return updatedStr;
	}

}
