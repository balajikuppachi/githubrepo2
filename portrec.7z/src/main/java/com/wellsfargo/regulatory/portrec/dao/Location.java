package  com.wellsfargo.regulatory.portrec.dao;

public interface Location {
	String asString();
}
