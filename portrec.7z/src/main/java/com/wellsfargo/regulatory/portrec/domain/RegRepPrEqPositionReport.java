package com.wellsfargo.regulatory.portrec.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Raji Komatreddy 
 * The persistent class for the REG_REP_PR_EQ_POSITION_REPORT database
 * table.
 */
@Entity
@Table(name = "REG_REP_PR_EQ_POSITION_REPORT")
public class RegRepPrEqPositionReport extends RegRepPrJob
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "eq_position_report_id")
	private Long eqPositionReportId;

	private String add_SDR_for_mixed_swap;

	@Column(name = "additional_repository_1")
	private String additionalRepository1;

	@Column(name = "additional_repository_2")
	private String additionalRepository2;

	@Column(name = "additional_repository_3")
	private String additionalRepository3;

	@Column(name = "are_we_reporting_party")
	private String areWeReportingParty;

	@Temporal(TemporalType.DATE)
	@Column(name = "as_of_date")
	private Date asOfDate;

	@Column(name = "asset_class")
	private String assetClass;

	private String buyer;

	private String collaterlized;

	@Column(name = "df_eteu_endusertype_cp")
	private String dfEteuEndusertypeCp;

	@Column(name = "df_eteu_endusertype_us")
	private String dfEteuEndusertypeUs;

	@Column(name = "df_etmsp_equityderivatives_cp")
	private String dfEtmspEquityderivativesCp;

	@Column(name = "df_etmsp_equityderivatives_us")
	private String dfEtmspEquityderivativesUs;

	@Column(name = "df_etsbmsp_equityderivatives_cp")
	private String dfEtsbmspEquityderivativesCp;

	@Column(name = "df_etsbmsp_equityderivatives_us")
	private String dfEtsbmspEquityderivativesUs;

	@Column(name = "df_etsbsd_equityderivatives_cp")
	private String dfEtsbsdEquityderivativesCp;

	@Column(name = "df_etsbsd_equityderivatives_us")
	private String dfEtsbsdEquityderivativesUs;

	@Column(name = "df_etsd_equityderivatives_cp")
	private String dfEtsdEquityderivativesCp;

	@Column(name = "df_etsd_equityderivatives_us")
	private String dfEtsdEquityderivativesUs;

	@Temporal(TemporalType.DATE)
	@Column(name = "eq_leg_final_valuation_date")
	private Date eqLegFinalValuationDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "eq_leg_payment_date")
	private Date eqLegPaymentDate;

	@Column(name = "eq_leg_payment_freq_period")
	private String eqLegPaymentFreqPeriod;

	@Temporal(TemporalType.DATE)
	@Column(name = "eq_leg_valuation_date")
	private Date eqLegValuationDate;

	@Column(name = "eq_leg_valuation_freq_period")
	private String eqLegValuationFreqPeriod;

	@Column(name = "eq_leg_valuation_freq_period_mult")
	private String eqLegValuationFreqPeriodMult;

	@Column(name = "equity_variance_strike_price")
	private BigDecimal equityVarianceStrikePrice;

	@Temporal(TemporalType.DATE)
	@Column(name = "execution_date")
	private Date executionDate;

	@Column(name = "execution_venue")
	private String executionVenue;

	@Column(name = "floating_leg_payment_freq_period")
	private String floatingLegPaymentFreqPeriod;

	@Column(name = "floating_leg_payment_freq_period_mult")
	private String floatingLegPaymentFreqPeriodMult;

	@Temporal(TemporalType.DATE)
	@Column(name = "flt_leg_payment_date")
	private Date fltLegPaymentDate;

	@Column(name = "flt_leg_payment_freq_period")
	private String fltLegPaymentFreqPeriod;

	@Column(name = "flt_leg_payment_freq_period_mult")
	private String fltLegPaymentFreqPeriodMult;

	@Column(name = "initial_price")
	private BigDecimal initialPrice;

	@Column(name = "is_swap_mixed")
	private String isSwapMixed;

	@Column(name = "is_swap_multi_asset")
	private String isSwapMultiAsset;

	@Column(name = "lei_cp")
	private String leiCp;

	@Column(name = "lei_us")
	private String leiUs;

	@Column(name = "maturity_date")
	private Date maturityDate;

	@Column(name = "notional_amount")
	private BigDecimal notionalAmount;

	@Column(name = "orig_trade_id")
	private String origTradeId;

	@Column(name = "party_1_role")
	private String party1Role;

	@Column(name = "party_2_role")
	private String party2Role;

	private String party1;

	@Column(name = "party1_notional_amount")
	private BigDecimal party1NotionalAmount;

	@Column(name = "party1_notional_curr")
	private String party1NotionalCurr;

	@Column(name = "party1_vega_notional_amount")
	private BigDecimal party1VegaNotionalAmount;

	private String party2;

	@Column(name = "premium_amount")
	private BigDecimal premiumAmount;

	@Column(name = "price_notation")
	private String priceNotation;

	@Column(name = "price_notation_type")
	private String priceNotationType;

	@Column(name = "product_id_value")
	private String productIdValue;

	@Column(name = "reported_currency")
	private String reportedCurrency;

	@Column(name = "reported_valuation")
	private String reportedValuation;

	@Column(name = "reporting_jurisdiction")
	private String reportingJurisdiction;

	@Column(name = "revision_id")
	private int revisionId;

	@Column(name = "sec_asset_class")
	private String secAssetClass;

	@Column(name = "submitted_for")
	private String submittedFor;

	@Temporal(TemporalType.DATE)
	@Column(name = "trade_date")
	private Date tradeDate;

	@Column(name = "trade_party_1_financial_entity")
	private String tradeParty1FinancialEntity;

	@Column(name = "trade_party_1_usperson_indicator")
	private String tradeParty1UspersonIndicator;

	@Column(name = "trade_party_2_financial_entity")
	private String tradeParty2FinancialEntity;

	@Column(name = "trade_party_2_name")
	private String tradeParty2Name;

	@Column(name = "trade_party_2_usperson_indicator")
	private String tradeParty2UspersonIndicator;

	@Column(name = "underlying_asset_identifier_type")
	private String underlyingAssetIdentifierType;

	@Column(name = "underlying_assets")
	private String underlyingAssets;

	@Column(name = "underlying_assets_notional")
	private String underlyingAssetsNotional;

	@Column(name = "underlying_assets_notional_curr")
	private String underlyingAssetsNotionalCurr;

	@Column(name = "underlying_assets_weighting")
	private String underlyingAssetsWeighting;

	@Column(name = "up_front_payment_amount")
	private BigDecimal upFrontPaymentAmount;

	private String usi;

	@Column(name = "uspersonentity_cp")
	private String uspersonentityCp;

	@Column(name = "uspersonentity_us")
	private String uspersonentityUs;

	@Temporal(TemporalType.DATE)
	@Column(name = "valuation_date")
	private Date valuationDate;

	@Column(name = "valuation_datetime")
	private String valuationDatetime;

	@Column(name = "vega_notional_curr")
	private String vegaNotionalCurr;

	@Column(name = "volatility_strike_price")
	private BigDecimal volatilityStrikePrice;

	@Column(name = "we_buy_sell")
	private String weBuySell;
	
	@Column(name = "uti")
	private String uti;
	
	public void setUti(String uti) {
		this.uti = uti;
	}

	public RegRepPrEqPositionReport()
	{
	}
	
	public String getUti() {
		return uti;
	}

	public long getEqPositionReportId()
	{
		return this.eqPositionReportId;
	}

	public void setEqPositionReportId(long eqPositionReportId)
	{
		this.eqPositionReportId = eqPositionReportId;
	}

	public String getAdd_SDR_for_mixed_swap()
	{
		return this.add_SDR_for_mixed_swap;
	}

	public void setAdd_SDR_for_mixed_swap(String add_SDR_for_mixed_swap)
	{
		this.add_SDR_for_mixed_swap = add_SDR_for_mixed_swap;
	}

	public String getAdditionalRepository1()
	{
		return this.additionalRepository1;
	}

	public void setAdditionalRepository1(String additionalRepository1)
	{
		this.additionalRepository1 = additionalRepository1;
	}

	public String getAdditionalRepository2()
	{
		return this.additionalRepository2;
	}

	public void setAdditionalRepository2(String additionalRepository2)
	{
		this.additionalRepository2 = additionalRepository2;
	}

	public String getAdditionalRepository3()
	{
		return this.additionalRepository3;
	}

	public void setAdditionalRepository3(String additionalRepository3)
	{
		this.additionalRepository3 = additionalRepository3;
	}

	public String getAreWeReportingParty()
	{
		return this.areWeReportingParty;
	}

	public void setAreWeReportingParty(String areWeReportingParty)
	{
		this.areWeReportingParty = areWeReportingParty;
	}

	public Date getAsOfDate()
	{
		return this.asOfDate;
	}

	public void setAsOfDate(Date asOfDate)
	{
		this.asOfDate = asOfDate;
	}

	public String getAssetClass()
	{
		return this.assetClass;
	}

	public void setAssetClass(String assetClass)
	{
		this.assetClass = assetClass;
	}

	public String getBuyer()
	{
		return this.buyer;
	}

	public void setBuyer(String buyer)
	{
		this.buyer = buyer;
	}

	public String getCollaterlized()
	{
		return this.collaterlized;
	}

	public void setCollaterlized(String collaterlized)
	{
		this.collaterlized = collaterlized;
	}

	public String getDfEteuEndusertypeCp()
	{
		return this.dfEteuEndusertypeCp;
	}

	public void setDfEteuEndusertypeCp(String dfEteuEndusertypeCp)
	{
		this.dfEteuEndusertypeCp = dfEteuEndusertypeCp;
	}

	public String getDfEteuEndusertypeUs()
	{
		return this.dfEteuEndusertypeUs;
	}

	public void setDfEteuEndusertypeUs(String dfEteuEndusertypeUs)
	{
		this.dfEteuEndusertypeUs = dfEteuEndusertypeUs;
	}

	public String getDfEtmspEquityderivativesCp()
	{
		return this.dfEtmspEquityderivativesCp;
	}

	public void setDfEtmspEquityderivativesCp(String dfEtmspEquityderivativesCp)
	{
		this.dfEtmspEquityderivativesCp = dfEtmspEquityderivativesCp;
	}

	public String getDfEtmspEquityderivativesUs()
	{
		return this.dfEtmspEquityderivativesUs;
	}

	public void setDfEtmspEquityderivativesUs(String dfEtmspEquityderivativesUs)
	{
		this.dfEtmspEquityderivativesUs = dfEtmspEquityderivativesUs;
	}

	public String getDfEtsbmspEquityderivativesCp()
	{
		return this.dfEtsbmspEquityderivativesCp;
	}

	public void setDfEtsbmspEquityderivativesCp(String dfEtsbmspEquityderivativesCp)
	{
		this.dfEtsbmspEquityderivativesCp = dfEtsbmspEquityderivativesCp;
	}

	public String getDfEtsbmspEquityderivativesUs()
	{
		return this.dfEtsbmspEquityderivativesUs;
	}

	public void setDfEtsbmspEquityderivativesUs(String dfEtsbmspEquityderivativesUs)
	{
		this.dfEtsbmspEquityderivativesUs = dfEtsbmspEquityderivativesUs;
	}

	public String getDfEtsbsdEquityderivativesCp()
	{
		return this.dfEtsbsdEquityderivativesCp;
	}

	public void setDfEtsbsdEquityderivativesCp(String dfEtsbsdEquityderivativesCp)
	{
		this.dfEtsbsdEquityderivativesCp = dfEtsbsdEquityderivativesCp;
	}

	public String getDfEtsbsdEquityderivativesUs()
	{
		return this.dfEtsbsdEquityderivativesUs;
	}

	public void setDfEtsbsdEquityderivativesUs(String dfEtsbsdEquityderivativesUs)
	{
		this.dfEtsbsdEquityderivativesUs = dfEtsbsdEquityderivativesUs;
	}

	public String getDfEtsdEquityderivativesCp()
	{
		return this.dfEtsdEquityderivativesCp;
	}

	public void setDfEtsdEquityderivativesCp(String dfEtsdEquityderivativesCp)
	{
		this.dfEtsdEquityderivativesCp = dfEtsdEquityderivativesCp;
	}

	public String getDfEtsdEquityderivativesUs()
	{
		return this.dfEtsdEquityderivativesUs;
	}

	public void setDfEtsdEquityderivativesUs(String dfEtsdEquityderivativesUs)
	{
		this.dfEtsdEquityderivativesUs = dfEtsdEquityderivativesUs;
	}

	public Date getEqLegFinalValuationDate()
	{
		return this.eqLegFinalValuationDate;
	}

	public void setEqLegFinalValuationDate(Date eqLegFinalValuationDate)
	{
		this.eqLegFinalValuationDate = eqLegFinalValuationDate;
	}

	public Date getEqLegPaymentDate()
	{
		return this.eqLegPaymentDate;
	}

	public void setEqLegPaymentDate(Date eqLegPaymentDate)
	{
		this.eqLegPaymentDate = eqLegPaymentDate;
	}

	public String getEqLegPaymentFreqPeriod()
	{
		return this.eqLegPaymentFreqPeriod;
	}

	public void setEqLegPaymentFreqPeriod(String eqLegPaymentFreqPeriod)
	{
		this.eqLegPaymentFreqPeriod = eqLegPaymentFreqPeriod;
	}

	public Date getEqLegValuationDate()
	{
		return this.eqLegValuationDate;
	}

	public void setEqLegValuationDate(Date eqLegValuationDate)
	{
		this.eqLegValuationDate = eqLegValuationDate;
	}

	public String getEqLegValuationFreqPeriod()
	{
		return this.eqLegValuationFreqPeriod;
	}

	public void setEqLegValuationFreqPeriod(String eqLegValuationFreqPeriod)
	{
		this.eqLegValuationFreqPeriod = eqLegValuationFreqPeriod;
	}

	public String getEqLegValuationFreqPeriodMult()
	{
		return this.eqLegValuationFreqPeriodMult;
	}

	public void setEqLegValuationFreqPeriodMult(String eqLegValuationFreqPeriodMult)
	{
		this.eqLegValuationFreqPeriodMult = eqLegValuationFreqPeriodMult;
	}

	public BigDecimal getEquityVarianceStrikePrice()
	{
		return this.equityVarianceStrikePrice;
	}

	public void setEquityVarianceStrikePrice(BigDecimal equityVarianceStrikePrice)
	{
		this.equityVarianceStrikePrice = equityVarianceStrikePrice;
	}

	public Date getExecutionDate()
	{
		return this.executionDate;
	}

	public void setExecutionDate(Date executionDate)
	{
		this.executionDate = executionDate;
	}

	public String getExecutionVenue()
	{
		return this.executionVenue;
	}

	public void setExecutionVenue(String executionVenue)
	{
		this.executionVenue = executionVenue;
	}

	public String getFloatingLegPaymentFreqPeriod()
	{
		return this.floatingLegPaymentFreqPeriod;
	}

	public void setFloatingLegPaymentFreqPeriod(String floatingLegPaymentFreqPeriod)
	{
		this.floatingLegPaymentFreqPeriod = floatingLegPaymentFreqPeriod;
	}

	public String getFloatingLegPaymentFreqPeriodMult()
	{
		return this.floatingLegPaymentFreqPeriodMult;
	}

	public void setFloatingLegPaymentFreqPeriodMult(String floatingLegPaymentFreqPeriodMult)
	{
		this.floatingLegPaymentFreqPeriodMult = floatingLegPaymentFreqPeriodMult;
	}

	public Date getFltLegPaymentDate()
	{
		return this.fltLegPaymentDate;
	}

	public void setFltLegPaymentDate(Date fltLegPaymentDate)
	{
		this.fltLegPaymentDate = fltLegPaymentDate;
	}

	public String getFltLegPaymentFreqPeriod()
	{
		return this.fltLegPaymentFreqPeriod;
	}

	public void setFltLegPaymentFreqPeriod(String fltLegPaymentFreqPeriod)
	{
		this.fltLegPaymentFreqPeriod = fltLegPaymentFreqPeriod;
	}

	public String getFltLegPaymentFreqPeriodMult()
	{
		return this.fltLegPaymentFreqPeriodMult;
	}

	public void setFltLegPaymentFreqPeriodMult(String fltLegPaymentFreqPeriodMult)
	{
		this.fltLegPaymentFreqPeriodMult = fltLegPaymentFreqPeriodMult;
	}

	public BigDecimal getInitialPrice()
	{
		return this.initialPrice;
	}

	public void setInitialPrice(BigDecimal initialPrice)
	{
		this.initialPrice = initialPrice;
	}

	public String getIsSwapMixed()
	{
		return this.isSwapMixed;
	}

	public void setIsSwapMixed(String isSwapMixed)
	{
		this.isSwapMixed = isSwapMixed;
	}

	public String getIsSwapMultiAsset()
	{
		return this.isSwapMultiAsset;
	}

	public void setIsSwapMultiAsset(String isSwapMultiAsset)
	{
		this.isSwapMultiAsset = isSwapMultiAsset;
	}

	public String getLeiCp()
	{
		return this.leiCp;
	}

	public void setLeiCp(String leiCp)
	{
		this.leiCp = leiCp;
	}

	public String getLeiUs()
	{
		return this.leiUs;
	}

	public void setLeiUs(String leiUs)
	{
		this.leiUs = leiUs;
	}

	public Date getMaturityDate()
	{
		return this.maturityDate;
	}

	public void setMaturityDate(Date maturityDate)
	{
		this.maturityDate = maturityDate;
	}

	public BigDecimal getNotionalAmount()
	{
		return this.notionalAmount;
	}

	public void setNotionalAmount(BigDecimal notionalAmount)
	{
		this.notionalAmount = notionalAmount;
	}

	public String getOrigTradeId()
	{
		return this.origTradeId;
	}

	public void setOrigTradeId(String origTradeId)
	{
		this.origTradeId = origTradeId;
	}

	public String getParty1Role()
	{
		return this.party1Role;
	}

	public void setParty1Role(String party1Role)
	{
		this.party1Role = party1Role;
	}

	public String getParty2Role()
	{
		return this.party2Role;
	}

	public void setParty2Role(String party2Role)
	{
		this.party2Role = party2Role;
	}

	public String getParty1()
	{
		return this.party1;
	}

	public void setParty1(String party1)
	{
		this.party1 = party1;
	}

	public BigDecimal getParty1NotionalAmount()
	{
		return this.party1NotionalAmount;
	}

	public void setParty1NotionalAmount(BigDecimal party1NotionalAmount)
	{
		this.party1NotionalAmount = party1NotionalAmount;
	}

	public String getParty1NotionalCurr()
	{
		return this.party1NotionalCurr;
	}

	public void setParty1NotionalCurr(String party1NotionalCurr)
	{
		this.party1NotionalCurr = party1NotionalCurr;
	}

	public BigDecimal getParty1VegaNotionalAmount()
	{
		return this.party1VegaNotionalAmount;
	}

	public void setParty1VegaNotionalAmount(BigDecimal party1VegaNotionalAmount)
	{
		this.party1VegaNotionalAmount = party1VegaNotionalAmount;
	}

	public String getParty2()
	{
		return this.party2;
	}

	public void setParty2(String party2)
	{
		this.party2 = party2;
	}

	public BigDecimal getPremiumAmount()
	{
		return this.premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount)
	{
		this.premiumAmount = premiumAmount;
	}

	public String getPriceNotation()
	{
		return this.priceNotation;
	}

	public void setPriceNotation(String priceNotation)
	{
		this.priceNotation = priceNotation;
	}

	public String getPriceNotationType()
	{
		return this.priceNotationType;
	}

	public void setPriceNotationType(String priceNotationType)
	{
		this.priceNotationType = priceNotationType;
	}

	public String getProductIdValue()
	{
		return this.productIdValue;
	}

	public void setProductIdValue(String productIdValue)
	{
		this.productIdValue = productIdValue;
	}

	public String getReportedCurrency()
	{
		return this.reportedCurrency;
	}

	public void setReportedCurrency(String reportedCurrency)
	{
		this.reportedCurrency = reportedCurrency;
	}

	public String getReportedValuation()
	{
		return this.reportedValuation;
	}

	public void setReportedValuation(String reportedValuation)
	{
		this.reportedValuation = reportedValuation;
	}

	public String getReportingJurisdiction()
	{
		return this.reportingJurisdiction;
	}

	public void setReportingJurisdiction(String reportingJurisdiction)
	{
		this.reportingJurisdiction = reportingJurisdiction;
	}

	public int getRevisionId()
	{
		return this.revisionId;
	}

	public void setRevisionId(int revisionId)
	{
		this.revisionId = revisionId;
	}

	public String getSecAssetClass()
	{
		return this.secAssetClass;
	}

	public void setSecAssetClass(String secAssetClass)
	{
		this.secAssetClass = secAssetClass;
	}

	public String getSubmittedFor()
	{
		return this.submittedFor;
	}

	public void setSubmittedFor(String submittedFor)
	{
		this.submittedFor = submittedFor;
	}

	public Date getTradeDate()
	{
		return this.tradeDate;
	}

	public void setTradeDate(Date tradeDate)
	{
		this.tradeDate = tradeDate;
	}

	public String getTradeParty1FinancialEntity()
	{
		return this.tradeParty1FinancialEntity;
	}

	public void setTradeParty1FinancialEntity(String tradeParty1FinancialEntity)
	{
		this.tradeParty1FinancialEntity = tradeParty1FinancialEntity;
	}

	public String getTradeParty1UspersonIndicator()
	{
		return this.tradeParty1UspersonIndicator;
	}

	public void setTradeParty1UspersonIndicator(String tradeParty1UspersonIndicator)
	{
		this.tradeParty1UspersonIndicator = tradeParty1UspersonIndicator;
	}

	public String getTradeParty2FinancialEntity()
	{
		return this.tradeParty2FinancialEntity;
	}

	public void setTradeParty2FinancialEntity(String tradeParty2FinancialEntity)
	{
		this.tradeParty2FinancialEntity = tradeParty2FinancialEntity;
	}

	public String getTradeParty2Name()
	{
		return this.tradeParty2Name;
	}

	public void setTradeParty2Name(String tradeParty2Name)
	{
		this.tradeParty2Name = tradeParty2Name;
	}

	public String getTradeParty2UspersonIndicator()
	{
		return this.tradeParty2UspersonIndicator;
	}

	public void setTradeParty2UspersonIndicator(String tradeParty2UspersonIndicator)
	{
		this.tradeParty2UspersonIndicator = tradeParty2UspersonIndicator;
	}

	public String getUnderlyingAssetIdentifierType()
	{
		return this.underlyingAssetIdentifierType;
	}

	public void setUnderlyingAssetIdentifierType(String underlyingAssetIdentifierType)
	{
		this.underlyingAssetIdentifierType = underlyingAssetIdentifierType;
	}

	public String getUnderlyingAssets()
	{
		return this.underlyingAssets;
	}

	public void setUnderlyingAssets(String underlyingAssets)
	{
		this.underlyingAssets = underlyingAssets;
	}

	public String getUnderlyingAssetsNotional()
	{
		return this.underlyingAssetsNotional;
	}

	public void setUnderlyingAssetsNotional(String underlyingAssetsNotional)
	{
		this.underlyingAssetsNotional = underlyingAssetsNotional;
	}

	public String getUnderlyingAssetsNotionalCurr()
	{
		return this.underlyingAssetsNotionalCurr;
	}

	public void setUnderlyingAssetsNotionalCurr(String underlyingAssetsNotionalCurr)
	{
		this.underlyingAssetsNotionalCurr = underlyingAssetsNotionalCurr;
	}

	public String getUnderlyingAssetsWeighting()
	{
		return this.underlyingAssetsWeighting;
	}

	public void setUnderlyingAssetsWeighting(String underlyingAssetsWeighting)
	{
		this.underlyingAssetsWeighting = underlyingAssetsWeighting;
	}

	public BigDecimal getUpFrontPaymentAmount()
	{
		return this.upFrontPaymentAmount;
	}

	public void setUpFrontPaymentAmount(BigDecimal upFrontPaymentAmount)
	{
		this.upFrontPaymentAmount = upFrontPaymentAmount;
	}

	public String getUsi()
	{
		return this.usi;
	}

	public void setUsi(String usi)
	{
		this.usi = usi;
	}

	public String getUspersonentityCp()
	{
		return this.uspersonentityCp;
	}

	public void setUspersonentityCp(String uspersonentityCp)
	{
		this.uspersonentityCp = uspersonentityCp;
	}

	public String getUspersonentityUs()
	{
		return this.uspersonentityUs;
	}

	public void setUspersonentityUs(String uspersonentityUs)
	{
		this.uspersonentityUs = uspersonentityUs;
	}

	public Date getValuationDate()
	{
		return this.valuationDate;
	}

	public void setValuationDate(Date valuationDate)
	{
		this.valuationDate = valuationDate;
	}

	public String getValuationDatetime()
	{
		return this.valuationDatetime;
	}

	public void setValuationDatetime(String valuationDatetime)
	{
		this.valuationDatetime = valuationDatetime;
	}

	public String getVegaNotionalCurr()
	{
		return this.vegaNotionalCurr;
	}

	public void setVegaNotionalCurr(String vegaNotionalCurr)
	{
		this.vegaNotionalCurr = vegaNotionalCurr;
	}

	public BigDecimal getVolatilityStrikePrice()
	{
		return this.volatilityStrikePrice;
	}

	public void setVolatilityStrikePrice(BigDecimal volatilityStrikePrice)
	{
		this.volatilityStrikePrice = volatilityStrikePrice;
	}

	public String getWeBuySell()
	{
		return this.weBuySell;
	}

	public void setWeBuySell(String weBuySell)
	{
		this.weBuySell = weBuySell;
	}

}