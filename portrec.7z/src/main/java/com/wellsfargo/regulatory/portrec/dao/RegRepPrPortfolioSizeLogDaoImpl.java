package com.wellsfargo.regulatory.portrec.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dto.PortfolioSizeLog;

/**
 * @author Raji Komatreddy
 */
@Component
public class RegRepPrPortfolioSizeLogDaoImpl
{
	@Autowired
	@Qualifier("portrecJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	String sql = " insert into REG_REP_PR_PORTFOLIO_SIZE_LOG (job_execution_id, cid_cpty_id, cpty_type, as_of_date, " + 
	" ir_size , cr_size, eq_size, fx_size, fx_intl_size, comm_size, portfolio_size, recon_freq, daily, weekly, quarterly,"
	        + " annual, override_freq, recon_day,  create_datetime)" + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	String deleteSql = "delete from REG_REP_PR_PORTFOLIO_SIZE_LOG where as_of_date = ?";
	
	String realtimeCobDate = "SELECT PROPERTY_VALUE FROM REGREP_PROPERTY_VALUES where PROPERTY_NAME  = ?" ;
			

	Logger logger = Logger.getLogger(RegRepPrPortfolioSizeLogDaoImpl.class);

	public int batchInsertPortfolioSize(final List<PortfolioSizeLog> portfolioSizeLogList) throws PortrecException
	{
		try
		{
			java.util.Date currDate = new java.util.Date();
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{

					PortfolioSizeLog currPortfolioSizeLog = portfolioSizeLogList.get(i);
					ps.setLong(1, currPortfolioSizeLog.getJobExecutionId());
					ps.setInt(2, currPortfolioSizeLog.getCidCptyId());
					ps.setString(3, currPortfolioSizeLog.getLegalType());
					if (null != currPortfolioSizeLog.getAsOfDate())
					{
						ps.setDate(4, (Date) new java.sql.Date(currPortfolioSizeLog.getAsOfDate().getTime()));
					}
					else
					{
						ps.setDate(4, null);
					}

					ps.setInt(5, currPortfolioSizeLog.getIrSize());
					ps.setInt(6, currPortfolioSizeLog.getCrSize());
					ps.setInt(7, currPortfolioSizeLog.getEqSize());
					ps.setInt(8, currPortfolioSizeLog.getFxSize());
					ps.setInt(9, currPortfolioSizeLog.getFxIntlSize());
					ps.setInt(10, currPortfolioSizeLog.getCommSize());
					ps.setInt(11, currPortfolioSizeLog.getPortfolioSize());
					ps.setString(12, currPortfolioSizeLog.getCalculatedFreq());
					ps.setString(13, currPortfolioSizeLog.getDaily());
					ps.setString(14, currPortfolioSizeLog.getWeekly());
					ps.setString(15, currPortfolioSizeLog.getQuarterly());
					ps.setString(16, currPortfolioSizeLog.getAnnual());
					ps.setString(17, currPortfolioSizeLog.getOverrideFreq());
					ps.setString(18, currPortfolioSizeLog.getReconDay());
					ps.setDate(19, new java.sql.Date(currDate.getTime()));

				}

				@Override
				public int getBatchSize()
				{
					return portfolioSizeLogList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrPortfolioSizeLogDaoImpl :batchInsertPortfolioSize method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrPortfolioSizeLogDaoImpl :batchInsertPortfolioSize method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrPortfolioSizeLogDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);

		}

		logger.info("from batchInsertPortfolioSize : number of records inserted : " + portfolioSizeLogList.size());

		return portfolioSizeLogList.size();
	}

	public int deleteFromPortfolioSizeLog(Date asOfDate) throws PortrecException
	{
		int numRowsDeleted = 0;
		try
		{
			Object[] params =	{ asOfDate };
			int[] types =		{ Types.DATE };
			numRowsDeleted = jdbcTemplate.update(deleteSql, params, types);
			
			return numRowsDeleted;

		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrPortfolioSizeLogDaoImpl :deleteFromPortfolioSizeLog method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrPortfolioSizeLogDaoImpl :deleteFromPortfolioSizeLog method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrPortfolioSizeLogDaoImpl:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);

		}

	}
	
	public String getCobDateFromRealTimeConfig(String propertyName)
	{
		String cobDate = null;
		try
		{
			 cobDate = jdbcTemplate.queryForObject(realtimeCobDate,  new Object[] { propertyName }, String.class);
		}
		catch(Exception ex)
		{
			logger.error("No Data for Property Name : " + propertyName);
		}
		
		return cobDate;
	}
}
