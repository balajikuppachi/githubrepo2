package com.wellsfargo.regulatory.portrec.mailer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.logging.PortrecExceptionLogger;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class PrEmailTemplateService {

	private final Logger logger = Logger.getLogger(PrEmailTemplateService.class);
	
	@Autowired
	PrEmailSenderService mailSenderService;
	
	private final String PORT_RECON_NOTICE_NONSD_WIND_ENV_DOM_ANN_TEMPLATE = "Port_Recon_Notice_NonSD_wind_env_DOM_ANN.vm";
	private final String PORT_RECON_NOTICE_NONSD_WIND_ENV_INT_ANN_TEMPLATE = "Port_Recon_Notice_NonSD_wind_env_INT_ANN.vm";
	private final String PORT_RECON_NOTICE_NONSD_WIND_ENV_DOM_INT_QTR_TEMPLATE = "Port_Recon_Notice_NonSD_wind_env_DOM_INT_QTR.vm";
	private final String PORT_RECON_NOTICE_SD_WIND_ENV_DOM_INT_QTR_TEMPLATE = "Port_Recon_Notice_SD_wind_env_DOM_INT_QTR.vm";
		
	/*List of all material terms files and Valuation file*/
	/*@Value("${file.portrec.data.extracts}") String irMaterialTermFilePath;
	@Value("${file.portrec.data.extracts}") String crMaterialTermFilePath;
	@Value("${file.portrec.data.extracts}") String fxMaterialTermFilePath;
	@Value("${file.portrec.data.extracts}") String eqMaterialTermFilePath;
	@Value("${file.portrec.data.extracts}") String commMaterialTermFilePath;
	@Value("${file.portrec.data.extracts}") String valuationFilePath;*/
	
	private final String subject = " | Portfolio Reconciliation | Wells Fargo Bank, NA – ";
	
	@Value("${mail.env.portrec}")		
	String enviroment;
	
	@Value("${mail.exchange.flag}")
	String exchangeFlag;
	
	@Value("${mail.mask.flag}")
	String mailMaskFlagStr;
	
	@Value("${mail.default.email.address}")
	String defaultEmailAddress;
	
	@Autowired
	PortrecExceptionLogger portrecExceptionLogger;
	
	@Autowired
	PrEmailAddressValidation prEmailAddressValidation;
	
	public void sendReconEmailQuarterly(CptyReconInformation prCptyInformation, boolean fileExceptionFlag) {
		
		long longLegalId = Long.valueOf(prCptyInformation.getCidCptyId());
		long jobExecutionId = prCptyInformation.getJobExecutionId();
		
		try {
			logger.info("Started sending Quarterly emails - ");
			
			Map<String, String> attachmentDetails = new HashMap<String, String>();
			Map<String,Object> templateDataMap = new HashMap<String,Object>();		
			
			templateDataMap.put("CUSTOMER_NAME_1", null != prCptyInformation.getCustomerName1() ? prCptyInformation.getCustomerName1() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_NAME_2", null != prCptyInformation.getCustomerName2() ? prCptyInformation.getCustomerName2() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_ADDRESS_1", null != prCptyInformation.getAddressLine1() ? prCptyInformation.getAddressLine1() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_ADDRESS_2", null != prCptyInformation.getAddressLine2() ? prCptyInformation.getAddressLine2() : PortrecConstants.BLANK);
			templateDataMap.put("CITY", null != prCptyInformation.getCity() ? prCptyInformation.getCity() : PortrecConstants.BLANK);
			templateDataMap.put("STATE", null != prCptyInformation.getState() ? prCptyInformation.getState() : PortrecConstants.BLANK);
			templateDataMap.put("ZIP", null != prCptyInformation.getZipCode() ? prCptyInformation.getZipCode() : PortrecConstants.BLANK);
			templateDataMap.put("COUNTRY", null != prCptyInformation.getCountry() ? prCptyInformation.getCountry() : PortrecConstants.BLANK);
			templateDataMap.put("DISPATCH_DATE", null != prCptyInformation.getDispatchDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getDispatchDate()) : PortrecConstants.BLANK);
			
			templateDataMap.put("CPTY_FREQUENCY", "once per quarter");
			templateDataMap.put("DATA_DELIVERY_DATE", null != prCptyInformation.getDataDeliveryDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getDataDeliveryDate()) : PortrecConstants.BLANK);
			templateDataMap.put("RECORD_DATE", null != prCptyInformation.getRecordDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getRecordDate()) : PortrecConstants.BLANK);
			templateDataMap.put("AFFIRM_DATE", null != prCptyInformation.getAffirmDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getAffirmDate()) : PortrecConstants.BLANK);
			templateDataMap.put("DELIVERY_METHOD", "Via TriOptima or delivery by displaying Trade Data on a secure, password-protected Wells Fargo website");
			
			templateDataMap.put("COUNTERPARTY_LEI_CODE", prCptyInformation.getCidCptyId());
			templateDataMap.put("COUNTERPARTY_LEGAL_NAME", null != prCptyInformation.getFullLegalName() ? prCptyInformation.getFullLegalName() : PortrecConstants.BLANK);
			templateDataMap.put("UUID", UUID.randomUUID());
			templateDataMap.put("SUBJECT_DNC", subject);
			templateDataMap.put("PREVIOUS_QUARTER_LAST_DAY", null != prCptyInformation.getAsOfDate() ? PortRecUtil.getEmailSubjectPrintDate(prCptyInformation.getAsOfDate()) : PortrecConstants.BLANK);
			
			// We are not attaching MT or VAL in email notices.
			//attachmentDetails.putAll(getMaterialTermsFileDetails(new Long(731000),"20141230"));

			String emailAddress = prCptyInformation.getEmailAddress();
			
			String preEmailVerificationInfoMsg = "Pre  Verification -" + enviroment + " : "+ prCptyInformation.getCidCptyId() + " : " + emailAddress;
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-1",preEmailVerificationInfoMsg, null, jobExecutionId, longLegalId);
			
			if(fileExceptionFlag)
			{
				emailAddress = defaultEmailAddress;
			}else{
				
				Boolean maskEmail = true;
				
				if(!StringUtils.isBlank(mailMaskFlagStr)){
					maskEmail = new Boolean(mailMaskFlagStr);
				}
				
				if(maskEmail){
					emailAddress = defaultEmailAddress;
				}
				
				if(StringUtils.isBlank(emailAddress))
				{
					String errorMsg = "Quarterly eligible Cpty having no valid email address";
					portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-2",errorMsg, null, jobExecutionId, longLegalId);
					emailAddress = defaultEmailAddress;
					prCptyInformation.setEmailAddress(emailAddress);
					
				} /*else if (!prEmailAddressValidation.validateMailPattern(emailAddress)){
					String errorMsg = "Quarterly eligible Cpty having invalid email address [" +emailAddress+ "]";
					portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-3",errorMsg, null, jobExecutionId, longLegalId);
					emailAddress = defaultEmailAddress;
				}*/
			}
			
			String template = null;
			
			if(prCptyInformation.getCptyType().equalsIgnoreCase(PortrecConstants.SD_CPTY_TYPE)){
				
				template = PORT_RECON_NOTICE_SD_WIND_ENV_DOM_INT_QTR_TEMPLATE;
				templateDataMap.put("CPTY_TYPE", "a Swap Dealer or Major Swap Participant");
				templateDataMap.put("PORTFOLIO_SIZE", "did not exceed 50 swaps during the year");
				
			} else if (prCptyInformation.getCptyType().equalsIgnoreCase(PortrecConstants.NON_SD_MSP_CPTY_TYPE)){
				
				template = PORT_RECON_NOTICE_NONSD_WIND_ENV_DOM_INT_QTR_TEMPLATE;
				templateDataMap.put("CPTY_TYPE", "not a Swap Dealer or Major Swap Participant");
				
				templateDataMap.put("PORTFOLIO_SIZE", "exceeded 100 swaps during "+ PortRecUtil.getQuarterlyPortfolioSize(prCptyInformation.getAsOfDate()));
			}
			
			String sub = prCptyInformation.getFullLegalName()+subject+PortRecUtil.getEmailSubjectPrintDate(prCptyInformation.getAsOfDate());
			
			if (enviroment.equals("DEV") || enviroment.equals("SIT") || enviroment.equals("UAT")) {
				sub = "DEVELOPMENT TESTING, " +prCptyInformation.getCidCptyId()+ " IGNORE - " + sub;
			}
			
			String postEmailVerificationInfoMsg = "Post Verification -" + enviroment + " : "+ prCptyInformation.getCidCptyId() + " : " + emailAddress;
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-4",postEmailVerificationInfoMsg, null, jobExecutionId, longLegalId);
			
			Boolean flag = false;
			
			if(!StringUtils.isBlank(exchangeFlag)){
				
				flag = new Boolean(exchangeFlag);
			}
			
			if(flag){
				mailSenderService.sendEmailThroughExchangeServer(sub, emailAddress, attachmentDetails, template, templateDataMap);
			}
			else{
				mailSenderService.sendEmailThroughSMTP(sub, emailAddress, attachmentDetails, template, templateDataMap);
			}
			
		}
		catch (Exception e){
			String errorMsg = "Error sending quarterly email : " + e.getMessage();
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-5",errorMsg, e, jobExecutionId, longLegalId);
		}
		
		logger.info("Completed sending Quarterly emails - ");
	}
	
	
	public void sendReconEmailAnnual(CptyReconInformation prCptyInformation) {
		
		long longLegalId = Long.valueOf(prCptyInformation.getCidCptyId());
		long jobExecutionId = prCptyInformation.getJobExecutionId();
		
		try {
			logger.info("Started sending Annual emails - ");
			
			Map<String, String> attachmentDetails = new HashMap<String, String>();
			Map<String,Object> templateDataMap = new HashMap<String,Object>();		
			
			templateDataMap.put("CUSTOMER_NAME_1", null != prCptyInformation.getCustomerName1() ? prCptyInformation.getCustomerName1() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_NAME_2", null != prCptyInformation.getCustomerName2() ? prCptyInformation.getCustomerName2() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_ADDRESS_1", null != prCptyInformation.getAddressLine1() ? prCptyInformation.getAddressLine1() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_ADDRESS_2", null != prCptyInformation.getAddressLine2() ? prCptyInformation.getAddressLine2() : PortrecConstants.BLANK);
			templateDataMap.put("CITY", null != prCptyInformation.getCity() ? prCptyInformation.getCity() : PortrecConstants.BLANK);
			templateDataMap.put("STATE", null != prCptyInformation.getState() ? prCptyInformation.getState() : PortrecConstants.BLANK);
			templateDataMap.put("ZIP", null != prCptyInformation.getZipCode() ? prCptyInformation.getZipCode() : PortrecConstants.BLANK);
			templateDataMap.put("COUNTRY", null != prCptyInformation.getCountry() ? prCptyInformation.getCountry() : PortrecConstants.BLANK);
			templateDataMap.put("DISPATCH_DATE", null != prCptyInformation.getDispatchDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getDispatchDate()) : PortrecConstants.BLANK);
			templateDataMap.put("CPTY_TYPE", null != prCptyInformation.getCptyType() ? prCptyInformation.getCptyType() : PortrecConstants.BLANK);
			templateDataMap.put("PORTFOLIO_SIZE", prCptyInformation.getPortfolioSize());
			templateDataMap.put("CPTY_FREQUENCY", null != prCptyInformation.getReconFreq() ? prCptyInformation.getReconFreq() : PortrecConstants.BLANK);
			templateDataMap.put("DATA_DELIVERY_DATE", null != prCptyInformation.getDataDeliveryDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getDataDeliveryDate()) : PortrecConstants.BLANK);
			templateDataMap.put("RECORD_DATE", null != prCptyInformation.getRecordDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getRecordDate()) : PortrecConstants.BLANK);
			templateDataMap.put("AFFIRM_DATE", null != prCptyInformation.getAffirmDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getAffirmDate()) : PortrecConstants.BLANK);
			templateDataMap.put("DELIVERY_METHOD", "delivery by displaying Trade Data on a secure, password-protected Wells Fargo website");
			
			templateDataMap.put("COUNTERPARTY_LEI_CODE", prCptyInformation.getCidCptyId());
			templateDataMap.put("COUNTERPARTY_LEGAL_NAME", null != prCptyInformation.getFullLegalName() ? prCptyInformation.getFullLegalName() : PortrecConstants.BLANK);
			templateDataMap.put("UUID", UUID.randomUUID());
			templateDataMap.put("SUBJECT_DNC", subject);
			templateDataMap.put("PREVIOUS_QUARTER_LAST_DAY", null != prCptyInformation.getAsOfDate() ? PortRecUtil.getEmailSubjectPrintDate(prCptyInformation.getAsOfDate()) : PortrecConstants.BLANK);
			
			// We are not attaching MT or VAL in email notices.
			// attachmentDetails.putAll(getMaterialTermsFileDetails(new Long(731000),"20141230"));

			String emailAddress = prCptyInformation.getEmailAddress();
			
			String preEmailVerificationInfoMsg = "Pre  Verification -" + enviroment + " : "+ prCptyInformation.getCidCptyId() + " : " + emailAddress;
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-6",preEmailVerificationInfoMsg, null, jobExecutionId, longLegalId);

			Boolean maskEmail = true;
			
			if(!StringUtils.isBlank(mailMaskFlagStr)){
				maskEmail = new Boolean(mailMaskFlagStr);
			}
			
			if(maskEmail){
				emailAddress = defaultEmailAddress;
			}
			
			if(StringUtils.isBlank(emailAddress))
			{
				emailAddress = defaultEmailAddress;
				prCptyInformation.setEmailAddress(emailAddress);
				String errorMsg = "Annual eligible Cpty having no email address";
				portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-7",errorMsg, null, jobExecutionId, longLegalId);
	
			} /*else if (!prEmailAddressValidation.validateMailPattern(emailAddress)){
				emailAddress = defaultEmailAddress;
				String errorMsg = "Annual eligible Cpty having invalid email address [" +emailAddress+ "]";
				portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-8",errorMsg, null, jobExecutionId, longLegalId);
			}*/
			
			String template = null;
			
			if(prCptyInformation.getDomIntl().equalsIgnoreCase(PortrecConstants.DOMESTIC)){
				
				template = PORT_RECON_NOTICE_NONSD_WIND_ENV_DOM_ANN_TEMPLATE;
				
			} else if (prCptyInformation.getDomIntl().equalsIgnoreCase(PortrecConstants.INTERNATIONAL)){
				
				template = PORT_RECON_NOTICE_NONSD_WIND_ENV_INT_ANN_TEMPLATE;
				
			}
			
			String sub = prCptyInformation.getFullLegalName()+subject+PortRecUtil.getEmailSubjectPrintDate(prCptyInformation.getAsOfDate());
			
			if (enviroment.equals("DEV") || enviroment.equals("SIT") || enviroment.equals("UAT")) {
				sub = "DEVELOPMENT TESTING, " +prCptyInformation.getCidCptyId()+ " IGNORE - " + sub;
			}
			
			String postEmailVerificationInfoMsg = "Post Verification -" + enviroment + " : "+ prCptyInformation.getCidCptyId() + " : " + emailAddress;
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-9",postEmailVerificationInfoMsg, null, jobExecutionId, longLegalId);
			
			Boolean flag = false;
			
			if(!StringUtils.isBlank(exchangeFlag)){
				
				flag = new Boolean(exchangeFlag);
			}
			
			if(flag){
				mailSenderService.sendEmailThroughExchangeServer(sub, emailAddress, attachmentDetails, template, templateDataMap);
			}
			else{
				mailSenderService.sendEmailThroughSMTP(sub, emailAddress, attachmentDetails, template, templateDataMap);
			}
			
		}
		catch (Exception e){
			String errorMsg = "Error sending annual email : " + e.getMessage();
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-10", errorMsg, e, jobExecutionId, longLegalId);
		}
		
		logger.info("Completed sending Annual emails - ");
	}
	
	
	public void sendReconEmailQuarterly(CptyReconInformation prCptyInformation) {
		
		long longLegalId = Long.valueOf(prCptyInformation.getCidCptyId());
		long jobExecutionId = prCptyInformation.getJobExecutionId();
		
		try {
			logger.info("Started sending Quarterly emails - ");
			
			Map<String, String> attachmentDetails = new HashMap<String, String>();
			Map<String,Object> templateDataMap = new HashMap<String,Object>();		
			
			templateDataMap.put("CUSTOMER_NAME_1", null != prCptyInformation.getCustomerName1() ? prCptyInformation.getCustomerName1() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_NAME_2", null != prCptyInformation.getCustomerName2() ? prCptyInformation.getCustomerName2() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_ADDRESS_1", null != prCptyInformation.getAddressLine1() ? prCptyInformation.getAddressLine1() : PortrecConstants.BLANK);
			templateDataMap.put("CUSTOMER_ADDRESS_2", null != prCptyInformation.getAddressLine2() ? prCptyInformation.getAddressLine2() : PortrecConstants.BLANK);
			templateDataMap.put("CITY", null != prCptyInformation.getCity() ? prCptyInformation.getCity() : PortrecConstants.BLANK);
			templateDataMap.put("STATE", null != prCptyInformation.getState() ? prCptyInformation.getState() : PortrecConstants.BLANK);
			templateDataMap.put("ZIP", null != prCptyInformation.getZipCode() ? prCptyInformation.getZipCode() : PortrecConstants.BLANK);
			templateDataMap.put("COUNTRY", null != prCptyInformation.getCountry() ? prCptyInformation.getCountry() : PortrecConstants.BLANK);
			templateDataMap.put("DISPATCH_DATE", null != prCptyInformation.getDispatchDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getDispatchDate()) : PortrecConstants.BLANK);
			
			templateDataMap.put("CPTY_FREQUENCY", "once per quarter");
			templateDataMap.put("DATA_DELIVERY_DATE", null != prCptyInformation.getDataDeliveryDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getDataDeliveryDate()) : PortrecConstants.BLANK);
			templateDataMap.put("RECORD_DATE", null != prCptyInformation.getRecordDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getRecordDate()) : PortrecConstants.BLANK);
			templateDataMap.put("AFFIRM_DATE", null != prCptyInformation.getAffirmDate() ? PortRecUtil.getEmailDispatchDate(prCptyInformation.getAffirmDate()) : PortrecConstants.BLANK);
			templateDataMap.put("DELIVERY_METHOD", "Via TriOptima or delivery by displaying Trade Data on a secure, password-protected Wells Fargo website");
			
			templateDataMap.put("COUNTERPARTY_LEI_CODE", prCptyInformation.getCidCptyId());
			templateDataMap.put("COUNTERPARTY_LEGAL_NAME", null != prCptyInformation.getFullLegalName() ? prCptyInformation.getFullLegalName() : PortrecConstants.BLANK);
			templateDataMap.put("UUID", UUID.randomUUID());
			templateDataMap.put("SUBJECT_DNC", subject);
			templateDataMap.put("PREVIOUS_QUARTER_LAST_DAY", null != prCptyInformation.getAsOfDate() ? PortRecUtil.getEmailSubjectPrintDate(prCptyInformation.getAsOfDate()) : PortrecConstants.BLANK);
			
			// We are not attaching MT or VAL in email notices.
			//attachmentDetails.putAll(getMaterialTermsFileDetails(new Long(731000),"20141230"));

			String emailAddress = prCptyInformation.getEmailAddress();
			
			String preEmailVerificationInfoMsg = "Pre Verification -" + enviroment + " : "+ prCptyInformation.getCidCptyId() + " : " + emailAddress;
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-1",preEmailVerificationInfoMsg, null, jobExecutionId, longLegalId);
			
			Boolean maskEmail = true;
			
			if(!StringUtils.isBlank(mailMaskFlagStr)){
				maskEmail = new Boolean(mailMaskFlagStr);
			}
			
			if(maskEmail){
				emailAddress = defaultEmailAddress;
			}
			
			if(StringUtils.isBlank(emailAddress))
			{
				String errorMsg = "Quarterly eligible Cpty having no email address";
				portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-2",errorMsg, null, jobExecutionId, longLegalId);
				emailAddress = defaultEmailAddress;
	
			} else if (!prEmailAddressValidation.validateMailPattern(emailAddress))
			{
				String errorMsg = "Quarterly eligible Cpty having invalid email address [" +emailAddress+ "]";
				portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-3",errorMsg, null, jobExecutionId, longLegalId);
				emailAddress = defaultEmailAddress;
			}
			
			String template = null;
			
			if(prCptyInformation.getCptyType().equalsIgnoreCase(PortrecConstants.SD_CPTY_TYPE))
			{
				template = PORT_RECON_NOTICE_SD_WIND_ENV_DOM_INT_QTR_TEMPLATE;
				templateDataMap.put("CPTY_TYPE", "a Swap Dealer or Major Swap Participant");
				templateDataMap.put("PORTFOLIO_SIZE", "did not exceed 50 swaps during the year");
				
			} else if (prCptyInformation.getCptyType().equalsIgnoreCase(PortrecConstants.NON_SD_MSP_CPTY_TYPE))
			{
				template = PORT_RECON_NOTICE_NONSD_WIND_ENV_DOM_INT_QTR_TEMPLATE;
				templateDataMap.put("CPTY_TYPE", "not a Swap Dealer or Major Swap Participant");
				
				templateDataMap.put("PORTFOLIO_SIZE", "exceeded 100 swaps during "+ PortRecUtil.getQuarterlyPortfolioSize(prCptyInformation.getAsOfDate()));
			}
			
			String sub = prCptyInformation.getFullLegalName()+subject+PortRecUtil.getEmailSubjectPrintDate(prCptyInformation.getAsOfDate());
			
			if (enviroment.equals("DEV") || enviroment.equals("SIT") || enviroment.equals("UAT")) {
				sub = "DEVELOPMENT TESTING, " +prCptyInformation.getCidCptyId()+ " IGNORE - " + sub;
			}
			
			String postEmailVerificationInfoMsg = "Post Verification -" + enviroment + " : "+ prCptyInformation.getCidCptyId() + " : " + emailAddress;
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-4",postEmailVerificationInfoMsg, null, jobExecutionId, longLegalId);
			
			Boolean flag = false;
			
			if(!StringUtils.isBlank(exchangeFlag)){
				
				flag = new Boolean(exchangeFlag);
			}
			
			if(flag){
				mailSenderService.sendEmailThroughExchangeServer(sub, emailAddress, attachmentDetails, template, templateDataMap);
			}
			else{
				mailSenderService.sendEmailThroughSMTP(sub, emailAddress, attachmentDetails, template, templateDataMap);
			}
			
		}
		catch (Exception e){
			String errorMsg = "Error sending quarterly email : " + e.getMessage();
			portrecExceptionLogger.logExceptionScenario("PrEmailTemplateService-5",errorMsg, e, jobExecutionId, longLegalId);
		}
		
		logger.info("Completed sending Quarterly emails - ");
	}
	
}
