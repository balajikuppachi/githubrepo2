package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.AlgoCSVwithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrAlgoValuation;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrAlgoValuationLoad extends LoaderHelper<RegRepPrAlgoValuation> {
	
	public static String PORTFOLIO_SEGMENT_NAME = "VAL, ALGO";
	
	@Value("${file.algoval.epr.header}") int headerRows;
	
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.ALGO_LOAD;
	}

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new AlgoCSVwithHeaderReader(inputStream, headerRows);
	}

	@Override
	public RegRepPrAlgoValuation parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {

		RegRepPrAlgoValuation valuationEntry = new RegRepPrAlgoValuation();
		valuationEntry.setSourceSystem((String) fields[0]);
		String collatAgreementID = (String) fields[1];
		if(null!=collatAgreementID && (!collatAgreementID.equals(""))){
			valuationEntry.setCollatAgreementId(collatAgreementID);
			valuationEntry.setCollateralized("Y");
		}else {
			valuationEntry.setCollatAgreementId("");
			valuationEntry.setCollateralized("N");
		}
		
		valuationEntry.setTradeId((String) fields[2]);
		if (StringUtils.isNotBlank((String) fields[3]))
			valuationEntry.setTradeDate(DateUtilLoader.getDateFromStringForValuation((String) fields[3]));		
		if (StringUtils.isNotBlank((String) fields[4]))
			valuationEntry.setMaturityDate(DateUtilLoader.getDateFromStringForValuation((String) fields[4]));
		
		valuationEntry.setPv((fields[5]).toString());
		valuationEntry.setPvBaseCcy((String) fields[6]); // same as PVCcy
		valuationEntry.setPvCcy(fields[6].toString());
		if(null!=fields[7])
			if (StringUtils.isNotBlank((String) fields[7]))
			valuationEntry.setImargin(fields[7].toString());
		if(null!=fields[8])
			if (StringUtils.isNotBlank((String) fields[8]))
			valuationEntry.setPutCall((String) fields[8]);
		if(null!=fields[9])
			if (StringUtils.isNotBlank((String) fields[9]))
			valuationEntry.setStrikePrice((fields[9]).toString());
		if(null!=fields[10])
			if (StringUtils.isNotBlank((String) fields[10]))
				valuationEntry.setEffectiveDate(DateUtilLoader.getDateFromStringForValuation((String) fields[10])); // The Only Date Format, it accepts is "DD-MM-YYYY / MM/dd/yyyy"
		if(null!=fields[11])
			if (StringUtils.isNotBlank((String) fields[11]))
				valuationEntry.setPvCobDate(DateUtilLoader.getDateFromStringForValuation((String) fields[11])); // The Only Date Format, it accepts is "DD-MM-YYYY / MM/dd/yyyy "
		if(null!=fields[12])
			if (StringUtils.isNotBlank((String) fields[12]))
			valuationEntry.setTrader(((String) fields[12]).trim());
		if(null!=fields[13])
			if (StringUtils.isNotBlank((String) fields[13]))
			valuationEntry.setBuyOrSell(((String) fields[13]).trim());
		if(null!=fields[14])
			if (StringUtils.isNotBlank((String) fields[14]))
			valuationEntry.setBook((String) fields[14]);
		if(null!=fields[15])
			if (StringUtils.isNotBlank((String) fields[15]))
			valuationEntry.setProductId((String) fields[15]);
		
		if(null!=fields[16]) {
			String notional = fields[16];
			BigDecimal bigdec = new BigDecimal(notional.replaceAll(",", ""));
			valuationEntry.setNotional1(bigdec.abs());
		}
		
		if(null!=fields[17])
			if (StringUtils.isNotBlank((String) fields[17]))
			valuationEntry.setNotional1Ccy((String) fields[17]);
		if(null!=fields[18]){
			String notional = fields[18];
			BigDecimal bigdec = new BigDecimal(notional.replaceAll(",", ""));
			valuationEntry.setNotional2(bigdec.abs());	
		}
		if(null!=fields[19])		
			if (StringUtils.isNotBlank((String) fields[19]))
			valuationEntry.setNotional2Ccy((String) fields[19]);
		if(null!=fields[20])
			if (StringUtils.isNotBlank((String) fields[20]))
			valuationEntry.setProdType((String) fields[20]);
		if(null!=fields[21]) {
			String legalID = (String) fields[21];
			if (StringUtils.isNotBlank(legalID))
				valuationEntry.setLegalId(new BigInteger(legalID));
		}		
		if(null!=fields[22])
			if (StringUtils.isNotBlank((String) fields[22]))
			valuationEntry.setFullName((String) fields[22]);
		if(null!=fields[23])
			if (StringUtils.isNotBlank((String) fields[23]))
			valuationEntry.setExtPrincipal((String) fields[23]);
		if(null!=fields[24])
			if (StringUtils.isNotBlank((String) fields[24]))
			valuationEntry.setParentLegalId((String) fields[24]);
		if(null!=fields[25])
			if (StringUtils.isNotBlank((String) fields[25]))
			valuationEntry.setParentLegalName((String) fields[25]);
		valuationEntry.setCptyBranch("");
		valuationEntry.setCptyTradeId("");
		valuationEntry.setAsOfDate(asofDate);
		
		return valuationEntry;
	
	}

	@Override
	public boolean validate(RegRepPrAlgoValuation trade) {
		return true;
	}

	@Override
	public RegRepPrAlgoValuation getTableName() {
			return new RegRepPrAlgoValuation() ;
	}

	@Override
	public boolean deletePrevDayRecords() {
		return false;
	}

	@Override
	public String loadNextJob() {
		return null;
	}

}
