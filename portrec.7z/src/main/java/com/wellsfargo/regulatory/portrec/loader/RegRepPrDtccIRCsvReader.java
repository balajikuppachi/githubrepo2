package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrIrPositionReport;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrDtccIRCsvReader extends LoaderHelper<RegRepPrIrPositionReport>
{	
	public static String PORTFOLIO_SEGMENT_NAME = "Interest Rate, DTCC";
	@Value("${file.dtccir.epr.header}")
	int headerRows;

	@Override
	public TradeRecordTypeEnum getRecordType()
	{
		return TradeRecordTypeEnum.IR;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream)
	{
		return new CsvWithHeaderReader(inputStream, headerRows);
	}

	@Override
	public String getPortfolioSegmentName()
	{
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public boolean validate(RegRepPrIrPositionReport trade)
	{
		boolean canLoad = false;
		String repJur = trade.getReportingJurisdiction();
		if(repJur.contains("CFTC") || repJur.isEmpty() || (repJur==null)){
			canLoad = true;
		}	
		
		return canLoad;
	}

	@Override
	public RegRepPrIrPositionReport parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException
	{

		RegRepPrIrPositionReport irTrade = new RegRepPrIrPositionReport();

		// IRTradeUnfilterd irTrade = new IRTradeUnfilterd();
		irTrade.setOrigTradeId("NA");
		irTrade.setSubmittedFor(fields[0]);
		irTrade.setTradeTypeIndicator(fields[2]);
		irTrade.setVerificationStatus(fields[3]);
		irTrade.setTradePartyLei1(fields[6]);
		irTrade.setTradePartyLei2(fields[8]);
		irTrade.setMsgType(fields[14]);
		irTrade.setUsiNamespace(fields[17]);

		String usi = fields[18];
		if (usi.contains(","))
		{
			usi = usi.split(",")[0];
		}
		irTrade.setUsi(irTrade.getUsiNamespace() + usi);
		irTrade.setAssetClass(fields[19]);
		irTrade.setSecAssetClass(fields[20]);
		irTrade.setProductType(fields[23]);
		irTrade.setTradePartyRole1(fields[24]);
		irTrade.setTradePartyRole2(fields[31]);

		String[] tradeParty = tradeParty(fields, exclude);
		irTrade.setTradeParty1(tradeParty[0]);
		irTrade.setTradeParty2(tradeParty[1]);
		irTrade.setDataSubmitter(fields[40]);

		if (StringUtils.isNotBlank(fields[46])) irTrade.setExecutionDate(DateUtilLoader.getDateTimeStampFromStrCR(fields[46]));

		irTrade.setExecutionVenue(fields[48]);
		irTrade.setCollaterlized(fields[56]);

		if (StringUtils.isNotBlank(fields[61])) irTrade.setTradeDate(DateUtilLoader.getDateFromString(fields[61]));

		irTrade.setReportingJurisdiction(fields[67]);
		irTrade.setAdditionalRepository1(fields[73]);
		irTrade.setBuyer(fields[78]);
		irTrade.setSeller(fields[79]);
		irTrade.setLeg1Payer(fields[81]);
		irTrade.setLeg2Payer(fields[82]);

		if (StringUtils.isNotBlank(fields[83])) irTrade.setEffectiveDateLeg1(DateUtilLoader.getDateFromString(fields[83]));

		if (StringUtils.isNotBlank(fields[84])) irTrade.setMaturityDate(DateUtilLoader.getDateFromString(fields[84]));

		if (StringUtils.isNotBlank(fields[85])) irTrade.setEffectiveDateLeg2(DateUtilLoader.getDateFromString(fields[85]));

		if (StringUtils.isNotBlank(fields[84])) irTrade.setTerminationDateLeg1(DateUtilLoader.getDateFromString(fields[84]));

		if (StringUtils.isNotBlank(fields[86])) irTrade.setTerminationDateLeg2(DateUtilLoader.getDateFromString(fields[86]));

		irTrade.setPaymentFreqPeriodLeg1(fields[87]);
		irTrade.setPaymentFreqPeriodMultiplierLeg1(fields[88]);
		irTrade.setPaymentFreqPeriodLeg2(fields[89]);
		irTrade.setPaymentFreqPeriodMultiplierLeg2(fields[90]);
		irTrade.setResetFreqPeriodLeg1(fields[91]);
		irTrade.setResetFreqPeriodMultiplierLeg1(fields[92]);
		irTrade.setResetFreqPeriodLeg2(fields[93]);
		irTrade.setResetFreqPeriodMultiplierLeg2(fields[94]);

		if (StringUtils.equalsIgnoreCase("InterestRate:Exotic", irTrade.getProductType()))
		{  // Leg 2 - cpty : Leg 1 - Party
			if (StringUtils.isNotBlank(fields[156])) irTrade.setNotionalAmountCpty(convertStrToBigDecimalForNotionalAmt(fields[156]));
			irTrade.setNotionalCurrencyCpty(fields[157]);

			if (StringUtils.isNotBlank(fields[154])) irTrade.setNotionalAmountParty(convertStrToBigDecimalForNotionalAmt(fields[154]));
			irTrade.setNotionalCurrencyParty(fields[155]);
		}
		else
		{
			if (StringUtils.isNotBlank(fields[107])) irTrade.setNotionalAmountCpty(convertStrToBigDecimalForNotionalAmt(fields[107]));
			irTrade.setNotionalCurrencyCpty(fields[106]);

			if (StringUtils.isNotBlank(fields[96])) irTrade.setNotionalAmountParty(convertStrToBigDecimalForNotionalAmt(fields[96]));
			irTrade.setNotionalCurrencyParty(fields[95]);
		}

		if (StringUtils.isNotBlank(fields[97])) irTrade.setFixedRateInitialLeg1(stringToBigDecimal(fields[97]));

		irTrade.setFloatingRateIndexLeg1(fields[98]);
		irTrade.setDayCountFractionLeg1(fields[103]);

		if (StringUtils.isNotBlank(fields[108])) irTrade.setFixedRateInitialLeg2(stringToBigDecimal(fields[108]));

		irTrade.setFloatingRateIndexLeg2(fields[109]);
		irTrade.setDayCountFractionLeg2(fields[114]);
		irTrade.setOptionType(fields[143]);

		if (StringUtils.isNotBlank(fields[154])) irTrade.setExoticNotionalAmountLeg1(convertStrToBigDecimalForNotionalAmt(fields[154]));

		if (StringUtils.isNotBlank(fields[156])) irTrade.setExoticNotionalAmountLeg2(convertStrToBigDecimalForNotionalAmt(fields[156]));

		irTrade.setExoticSettlementCurr(fields[157]);
		irTrade.setExoticUnderlyingAsset(fields[158]);
		irTrade.setTradeParty1UspersonIndicator(fields[163]);
		irTrade.setTradeParty1FinancialEntity(fields[164]);
		irTrade.setTradeParty2UspersonIndicator(fields[165]);
		irTrade.setTradeParty2FinancialEntity(fields[166]);

		irTrade.setAsOfDate(asofDate);
		return irTrade;

	}

	private String[] tradeParty(String[] fields, String[] exclude)
	{
		String[] tradeParty = new String[2];
		String tradeParty1 = "";
		String tradeParty2 = "";
		if (StringUtils.isNotBlank(fields[6]))
		{
			tradeParty1 = fields[6];
		}
		else
		{
			tradeParty1 = fields[26];
		}
		if (StringUtils.isNotBlank(fields[8]))
		{
			tradeParty2 = fields[8];
		}
		else
		{
			tradeParty2 = fields[33];
		}
		if (tradeParty1.contains("%")) tradeParty1 = tradeParty1.replace("%", "");
		if (tradeParty2.contains("%")) tradeParty2 = tradeParty2.replace("%", "");
		
		for (String s : exclude){
		if (tradeParty1.contains(s)) tradeParty1 = tradeParty1.replace(s, "");
		if (tradeParty2.contains(s)) tradeParty2 = tradeParty2.replace(s, "");
		}
		tradeParty[0] = tradeParty1;
		tradeParty[1] = tradeParty2;
		return tradeParty;
	}

	@Override
	public RegRepPrIrPositionReport getTableName() {
		return new RegRepPrIrPositionReport();
	}

	@Override
	public boolean deletePrevDayRecords() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String loadNextJob() {
		// TODO Auto-generated method stub
		return null;
	}
}