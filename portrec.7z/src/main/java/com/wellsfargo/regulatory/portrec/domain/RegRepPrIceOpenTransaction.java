package com.wellsfargo.regulatory.portrec.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="REG_REP_ICE_OPEN_TRANSACTION")
public class RegRepPrIceOpenTransaction {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private long id;
	@Column(name="job_execution_id")
	private long jobExecutionId;
	@Column (name="jurisidiction")
	private String jurisidiction;
	@Column(name="batch_id")
	private long batchId;
	@Column(name="tv_product_name")
	private String tvProductName;
	@Column(name="tv_product_id")
	private String tvProductId;
	@Column(name="usi_uti")
	private String usiUti;
	@Column(name="buyer")
	private String buyer;
	@Column(name="seller")
	private String seller;
	@Column(name="trade_date")
	private String tradeDate;
	@Column(name="start_date")
	private String startDate;
	@Column(name="end_date")
	private String endDate;
	@Column(name="price")
	private String price;
	@Column(name="price_unit")
	private String priceUnit;
	@Column(name="price_currency")
	private String priceCurrency;
	@Column(name="buyer_lei")
	private String buyerLei;
	@Column (name="buyerUSRegulatoryDesignation")
	private String buyerUsregulatoryDesignation;
	@Column (name="buyer_parent")
	private String buyerParent;
	@Column(name="buyer_region")
	private String buyerRegion;
	@Column(name="seller_lei")
	private String sellerLei;
	@Column(name="sellarPayIndex")
	private String sellarPayIndex;
	@Column(name="sellerUSRegulatoryDesignation")
	private String sellerUsregulatoryDesignation;
	@Column(name="seller_parent")
	private String sellerParent;
	@Column(name="seller_region")
	private String sellerRegion;
	@Column(name="sellerSenderTradeRefId")
	private String sellerSenderTradeRefId;
	@Column(name="notional_amount")
	private String notionalAmount;
	@Column(name="contract_type")
	private String contractType;
	@Column(name="first_reported_sdr")
	private String firstReportedSdr;
	@Column(name="trade_status")
	private String tradeStatus;
	@Column(name="life_cycle_event_status")
	private String lifeCycleEventStatus;
	@Column(name="execution_venue")
	private String executionVenue;
	@Column(name="execution_time")
	private String executionTime;
	@Column(name="quantity")
	private String quantity;
	@Column(name="quantity_unit")
	private String quantityUnit;
	@Column(name="total_quantity")
	private String totalQuantity;
	@Column(name="quantity_frequency")
	private String quantityFrequency;
	@Column(name="buyer_pay_index")
	private String buyerPayIndex;
	@Column(name="buyer_pay_index_averaging_method")
	private String buyerPayIndexAveragingMethod;
	@Column(name="seller_pay_index_averaging_method")
	private String sellerPayIndexAveragingMethod;
	@Column(name="hours_from_thru_timezone")
	private String hoursFromThruTimezone;
	@Column(name="option_type")
	private String optionType;
	@Column(name="option_style")
	private String optionStyle;
	@Column(name="hours_from_thru")
	private String hoursFromThru;
	@Column(name="option_premium")
	private String optionPremium;
	@Column(name="buyer_EUTR")
	private String buyerEutr;
	@Column(name="buyer_sender_tradeRefId")
	private String buyerSenderTradeRefId;
	@Column(name="seller_eutr")
	private String sellerEutr;
	@Column(name="load_type")
	private String loadType;
	@Column(name="days_of_week")
	private String daysOfWeek;
	@Column(name="settlement_method")
	private String settlementMethod;
	@Column(name="original_confirmation_time")
	private String originalConfirmationTime;
	@Column(name="us_reporting_entity_petData")
	private String usReportingEntityPetData;
	@Column(name="us_reporting_entity_continuationData")
	private String usReportingEntityContinuationData;
	@Column(name="us_reporting_entity_valuationFrequency")
	private String usReportingEntityValuationFrequency;
	@Column(name="independent_amount_payer")
	private String independentAmountPayer;
	@Column(name="agent_lei")
	private String agentLei;
	@Column(name="macs_primary_asset_class")
	private String macsPrimaryAssetClass;
	@Column(name="macs_secondary_asset_class")
	private String macsSecondaryAssetClass;
	@Column(name="lifecycleEvent_timestamp")
	private String lifecycleEventTimestamp;
	@Column(name="quantity_tolerance_percentage")
	private String quantityTolerancePercentage;
	@Column(name="multi_asset_class_swap")
	private String multiAssetClassSwap;
	@Column(name="mixed_swap")
	private String mixedSwap;
	@Column(name="create_datetime")
	private Date createDatetime;
	@Column(name="run_date")
	private Date runDate;
	@Column(name="mixedSwapReportSdr")
	private String mixedSwapReportSdr;
	@Column(name="buyerFinEnt")
	private String buyerFinEnt;
	@Column(name="buyerUsEnt")
	private String buyerUsEnt;
	@Column(name="collaterlized")
	private String collaterlized;
	@Column(name="sellerFinEnt")
	private String sellerFinEnt;
	@Column(name="sellerUsEnt")
	private String sellerUsEnt;
	@Column(name="grade")
	private String grade;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getJobExecutionId() {
		return jobExecutionId;
	}
	public void setJobExecutionId(long jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}
	public String getJurisidiction() {
		return jurisidiction;
	}
	public void setJurisidiction(String jurisidiction) {
		this.jurisidiction = jurisidiction;
	}
	public long getBatchId() {
		return batchId;
	}
	public void setBatchId(long batchId) {
		this.batchId = batchId;
	}
	public String getTvProductName() {
		return tvProductName;
	}
	public void setTvProductName(String tvProductName) {
		this.tvProductName = tvProductName;
	}
	public String getTvProductId() {
		return tvProductId;
	}
	public void setTvProductId(String tvProductId) {
		this.tvProductId = tvProductId;
	}
	public String getUsiUti() {
		return usiUti;
	}
	public void setUsiUti(String usiUti) {
		this.usiUti = usiUti;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPriceUnit() {
		return priceUnit;
	}
	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}
	public String getPriceCurrency() {
		return priceCurrency;
	}
	public void setPriceCurrency(String priceCurrency) {
		this.priceCurrency = priceCurrency;
	}
	public String getBuyerLei() {
		return buyerLei;
	}
	public void setBuyerLei(String buyerLei) {
		this.buyerLei = buyerLei;
	}
	public String getBuyerUsregulatoryDesignation() {
		return buyerUsregulatoryDesignation;
	}
	public void setBuyerUsregulatoryDesignation(String buyerUsregulatoryDesignation) {
		this.buyerUsregulatoryDesignation = buyerUsregulatoryDesignation;
	}
	public String getBuyerParent() {
		return buyerParent;
	}
	public void setBuyerParent(String buyerParent) {
		this.buyerParent = buyerParent;
	}
	public String getBuyerRegion() {
		return buyerRegion;
	}
	public void setBuyerRegion(String buyerRegion) {
		this.buyerRegion = buyerRegion;
	}
	public String getSellerLei() {
		return sellerLei;
	}
	public void setSellerLei(String sellerLei) {
		this.sellerLei = sellerLei;
	}
	public String getSellarPayIndex() {
		return sellarPayIndex;
	}
	public void setSellarPayIndex(String sellarPayIndex) {
		this.sellarPayIndex = sellarPayIndex;
	}
	public String getSellerUsregulatoryDesignation() {
		return sellerUsregulatoryDesignation;
	}
	public void setSellerUsregulatoryDesignation(
			String sellerUsregulatoryDesignation) {
		this.sellerUsregulatoryDesignation = sellerUsregulatoryDesignation;
	}
	public String getSellerParent() {
		return sellerParent;
	}
	public void setSellerParent(String sellerParent) {
		this.sellerParent = sellerParent;
	}
	public String getSellerRegion() {
		return sellerRegion;
	}
	public void setSellerRegion(String sellerRegion) {
		this.sellerRegion = sellerRegion;
	}
	public String getSellerSenderTradeRefId() {
		return sellerSenderTradeRefId;
	}
	public void setSellerSenderTradeRefId(String sellerSenderTradeRefId) {
		this.sellerSenderTradeRefId = sellerSenderTradeRefId;
	}
	public String getNotionalAmount() {
		return notionalAmount;
	}
	public void setNotionalAmount(String notionalAmount) {
		this.notionalAmount = notionalAmount;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getFirstReportedSdr() {
		return firstReportedSdr;
	}
	public void setFirstReportedSdr(String firstReportedSdr) {
		this.firstReportedSdr = firstReportedSdr;
	}
	public String getTradeStatus() {
		return tradeStatus;
	}
	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}
	public String getLifeCycleEventStatus() {
		return lifeCycleEventStatus;
	}
	public void setLifeCycleEventStatus(String lifeCycleEventStatus) {
		this.lifeCycleEventStatus = lifeCycleEventStatus;
	}
	public String getExecutionVenue() {
		return executionVenue;
	}
	public void setExecutionVenue(String executionVenue) {
		this.executionVenue = executionVenue;
	}
	public String getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(String executionTime) {
		this.executionTime = executionTime;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getQuantityUnit() {
		return quantityUnit;
	}
	public void setQuantityUnit(String quantityUnit) {
		this.quantityUnit = quantityUnit;
	}
	public String getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(String totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public String getQuantityFrequency() {
		return quantityFrequency;
	}
	public void setQuantityFrequency(String quantityFrequency) {
		this.quantityFrequency = quantityFrequency;
	}
	public String getBuyerPayIndex() {
		return buyerPayIndex;
	}
	public void setBuyerPayIndex(String buyerPayIndex) {
		this.buyerPayIndex = buyerPayIndex;
	}
	public String getBuyerPayIndexAveragingMethod() {
		return buyerPayIndexAveragingMethod;
	}
	public void setBuyerPayIndexAveragingMethod(String buyerPayIndexAveragingMethod) {
		this.buyerPayIndexAveragingMethod = buyerPayIndexAveragingMethod;
	}
	public String getSellerPayIndexAveragingMethod() {
		return sellerPayIndexAveragingMethod;
	}
	public void setSellerPayIndexAveragingMethod(
			String sellerPayIndexAveragingMethod) {
		this.sellerPayIndexAveragingMethod = sellerPayIndexAveragingMethod;
	}
	public String getHoursFromThruTimezone() {
		return hoursFromThruTimezone;
	}
	public void setHoursFromThruTimezone(String hoursFromThruTimezone) {
		this.hoursFromThruTimezone = hoursFromThruTimezone;
	}
	public String getOptionType() {
		return optionType;
	}
	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}
	public String getOptionStyle() {
		return optionStyle;
	}
	public void setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
	}
	public String getHoursFromThru() {
		return hoursFromThru;
	}
	public void setHoursFromThru(String hoursFromThru) {
		this.hoursFromThru = hoursFromThru;
	}
	public String getOptionPremium() {
		return optionPremium;
	}
	public void setOptionPremium(String optionPremium) {
		this.optionPremium = optionPremium;
	}
	public String getBuyerEutr() {
		return buyerEutr;
	}
	public void setBuyerEutr(String buyerEutr) {
		this.buyerEutr = buyerEutr;
	}
	public String getBuyerSenderTradeRefId() {
		return buyerSenderTradeRefId;
	}
	public void setBuyerSenderTradeRefId(String buyerSenderTradeRefId) {
		this.buyerSenderTradeRefId = buyerSenderTradeRefId;
	}
	public String getSellerEutr() {
		return sellerEutr;
	}
	public void setSellerEutr(String sellerEutr) {
		this.sellerEutr = sellerEutr;
	}
	public String getLoadType() {
		return loadType;
	}
	public void setLoadType(String loadType) {
		this.loadType = loadType;
	}
	public String getDaysOfWeek() {
		return daysOfWeek;
	}
	public void setDaysOfWeek(String daysOfWeek) {
		this.daysOfWeek = daysOfWeek;
	}
	public String getSettlementMethod() {
		return settlementMethod;
	}
	public void setSettlementMethod(String settlementMethod) {
		this.settlementMethod = settlementMethod;
	}
	public String getOriginalConfirmationTime() {
		return originalConfirmationTime;
	}
	public void setOriginalConfirmationTime(String originalConfirmationTime) {
		this.originalConfirmationTime = originalConfirmationTime;
	}
	public String getUsReportingEntityPetData() {
		return usReportingEntityPetData;
	}
	public void setUsReportingEntityPetData(String usReportingEntityPetData) {
		this.usReportingEntityPetData = usReportingEntityPetData;
	}
	public String getUsReportingEntityContinuationData() {
		return usReportingEntityContinuationData;
	}
	public void setUsReportingEntityContinuationData(
			String usReportingEntityContinuationData) {
		this.usReportingEntityContinuationData = usReportingEntityContinuationData;
	}
	public String getUsReportingEntityValuationFrequency() {
		return usReportingEntityValuationFrequency;
	}
	public void setUsReportingEntityValuationFrequency(
			String usReportingEntityValuationFrequency) {
		this.usReportingEntityValuationFrequency = usReportingEntityValuationFrequency;
	}
	public String getIndependentAmountPayer() {
		return independentAmountPayer;
	}
	public void setIndependentAmountPayer(String independentAmountPayer) {
		this.independentAmountPayer = independentAmountPayer;
	}
	public String getAgentLei() {
		return agentLei;
	}
	public void setAgentLei(String agentLei) {
		this.agentLei = agentLei;
	}
	public String getMacsPrimaryAssetClass() {
		return macsPrimaryAssetClass;
	}
	public void setMacsPrimaryAssetClass(String macsPrimaryAssetClass) {
		this.macsPrimaryAssetClass = macsPrimaryAssetClass;
	}
	public String getMacsSecondaryAssetClass() {
		return macsSecondaryAssetClass;
	}
	public void setMacsSecondaryAssetClass(String macsSecondaryAssetClass) {
		this.macsSecondaryAssetClass = macsSecondaryAssetClass;
	}
	public String getLifecycleEventTimestamp() {
		return lifecycleEventTimestamp;
	}
	public void setLifecycleEventTimestamp(String lifecycleEventTimestamp) {
		this.lifecycleEventTimestamp = lifecycleEventTimestamp;
	}
	public String getQuantityTolerancePercentage() {
		return quantityTolerancePercentage;
	}
	public void setQuantityTolerancePercentage(String quantityTolerancePercentage) {
		this.quantityTolerancePercentage = quantityTolerancePercentage;
	}
	public String getMultiAssetClassSwap() {
		return multiAssetClassSwap;
	}
	public void setMultiAssetClassSwap(String multiAssetClassSwap) {
		this.multiAssetClassSwap = multiAssetClassSwap;
	}
	public String getMixedSwap() {
		return mixedSwap;
	}
	public void setMixedSwap(String mixedSwap) {
		this.mixedSwap = mixedSwap;
	}
	public Date getCreateDatetime() {
		return createDatetime;
	}
	public void setCreateDatetime(Date createDatetime) {
		this.createDatetime = createDatetime;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public String getMixedSwapReportSdr() {
		return mixedSwapReportSdr;
	}
	public void setMixedSwapReportSdr(String mixedSwapReportSdr) {
		this.mixedSwapReportSdr = mixedSwapReportSdr;
	}
	public String getBuyerFinEnt() {
		return buyerFinEnt;
	}
	public void setBuyerFinEnt(String buyerFinEnt) {
		this.buyerFinEnt = buyerFinEnt;
	}
	public String getBuyerUsEnt() {
		return buyerUsEnt;
	}
	public void setBuyerUsEnt(String buyerUsEnt) {
		this.buyerUsEnt = buyerUsEnt;
	}
	public String getCollaterlized() {
		return collaterlized;
	}
	public void setCollaterlized(String collaterlized) {
		this.collaterlized = collaterlized;
	}
	public String getSellerFinEnt() {
		return sellerFinEnt;
	}
	public void setSellerFinEnt(String sellerFinEnt) {
		this.sellerFinEnt = sellerFinEnt;
	}
	public String getSellerUsEnt() {
		return sellerUsEnt;
	}
	public void setSellerUsEnt(String sellerUsEnt) {
		this.sellerUsEnt = sellerUsEnt;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}


	
	
}
