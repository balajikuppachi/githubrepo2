package com.wellsfargo.regulatory.portrec.repository;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrAlgoValuation;
/**
 * 
 * @author Raji Komatreddy
 * Repository to save or get data from RegRepPrAlgoValuation table
 *
 */
public interface RegRepPrAlgoValuationRepository extends CrudRepository<RegRepPrAlgoValuation, Long>
{
	
	@Query("select vae from RegRepPrAlgoValuation vae where vae.legalId = ?1 and vae.asOfDate = ?2")
	public List<RegRepPrAlgoValuation> findAlgoValuationByLegalIdAndCobDate(BigInteger legalId, Date asOfDate);
	
	@Query("select vae from RegRepPrAlgoValuation vae where collateralized = 'N' and asOfDate=?" )
	public Iterable<RegRepPrAlgoValuation> findActiveNonCollateralized(Date date);
	
	@Query("select max(vae.asOfDate) from RegRepPrAlgoValuation vae where collateralized = 'N'" )
	public Date findMaxAsofDateNonCollateralized();
	
	@Query("select vae from RegRepPrAlgoValuation vae where vae.tradeId = ?1 and vae.asOfDate = ?2")
	public List<RegRepPrAlgoValuation> findAlgoValuationByTradeIdAndAsOfDate(String tradeId, Date asOfDate);
	
	
}
