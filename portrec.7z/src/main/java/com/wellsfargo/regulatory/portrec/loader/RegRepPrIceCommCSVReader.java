package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrCommPositionReport;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;


@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrIceCommCSVReader extends LoaderHelper<RegRepPrCommPositionReport> {

	public static String PORTFOLIO_SEGMENT_NAME = "Commodity, ICE";
	@Value("${file.icecomm.epr.header}") int headerRows;
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.COM_ICE;
	}

	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}

	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new CsvWithHeaderReader(inputStream, headerRows);
	}

	@Override
	public RegRepPrCommPositionReport parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrCommPositionReport commTradeUnfiltered = new RegRepPrCommPositionReport();
		commTradeUnfiltered.setProductId(fields[2]);
		commTradeUnfiltered.setCftcProductId(fields[2]);
		commTradeUnfiltered.setIntProductId(fields[2]);
		commTradeUnfiltered.setTvProdId(fields[2]);
		commTradeUnfiltered.setMultAssetClassSwap(fields[229]);//previously fields[224]
		commTradeUnfiltered.setMacPriAssetClass(fields[230]); //previously fields[225]
		commTradeUnfiltered.setMacSecAssetClass(fields[231]); //previously fields[226]
		commTradeUnfiltered.setMixedSwap(fields[232]); //previously fields[227]
		commTradeUnfiltered.setMixedSwapReportSdr(fields[233]); //previously fields[228]
		commTradeUnfiltered.setContractType(fields[5]);
		commTradeUnfiltered.setExecutionVenue(fields[16]);
		if (StringUtils.isNotBlank(fields[22])) //previously fields[20]
			commTradeUnfiltered.setStartDate(DateUtilLoader.getDateFromStrComm(fields[22])); //previously fields[20]
		if (StringUtils.isNotBlank(fields[23])) //previously fields[21]
			commTradeUnfiltered.setEndDate(DateUtilLoader.getDateFromStrComm(fields[23])); //previously fields[21]
		commTradeUnfiltered.setBuyer(fields[14]);
		commTradeUnfiltered.setSeller(fields[15]);
		commTradeUnfiltered.setQantityUnit(fields[33]); //previously fields[30]
		commTradeUnfiltered.setQantity(fields[30]); //previously fields[27]
		commTradeUnfiltered.setQantityFreq(fields[32]); //previously fields[29]
		commTradeUnfiltered.setTotalFreq(fields[31]); //previously fields[28]
		commTradeUnfiltered.setSettlementMethod(fields[62]); //previously fields[59]
		commTradeUnfiltered.setPrice(fields[24]); //previously fields[22]
		commTradeUnfiltered.setPriceUnit(fields[26]); //previously fields[23]
		commTradeUnfiltered.setPriceCurr(fields[27]); //previously fields[24]
		commTradeUnfiltered.setBuyerPayIndex(fields[34]); //previously fields[31]
		commTradeUnfiltered.setBuyerPayindexAvgMethod(fields[35]); //previously fields[32]
		commTradeUnfiltered.setSellerPayIndex(fields[38]); //previously fields[35]
		commTradeUnfiltered.setSellerPayindexAvgMethod(fields[39]); //previously fields[36]
		commTradeUnfiltered.setGrade(fields[211]); //previously fields[206]
		commTradeUnfiltered.setOptionType(fields[46]); //previously fields[43]
		commTradeUnfiltered.setOptionStyle(fields[47]); //previously fields[44]
		commTradeUnfiltered.setOptionPremium(fields[48]); //previously fields[45]
		commTradeUnfiltered.setHrFromThr(fields[42]); //previously fields[39]
		commTradeUnfiltered.setHrFromThrTimezone(fields[43]); //previously fields[40]
		commTradeUnfiltered.setDaysOfWeek(fields[45]); //previously fields[42]
		commTradeUnfiltered.setLoadType(fields[44]); //previously fields[41]
		commTradeUnfiltered.setCollaterlized(fields[153]); //previously fields[149]

		commTradeUnfiltered.setUsiValue(fields[8]);
		String wfbna = "Wells Fargo Bank, N.A.";
		
		if(StringUtils.equalsIgnoreCase(fields[14],wfbna)){
			commTradeUnfiltered.setSrcTradeId(fields[97]); //previously fields[93]
		}else if(StringUtils.equalsIgnoreCase(fields[15],wfbna)){
			commTradeUnfiltered.setSrcTradeId(fields[106]); //previously fields[102]
		}else{
			commTradeUnfiltered.setSrcTradeId("");
		}
		String buyerLEI = fields[89];
		String sellerLEI = fields[98];
		if (null!= buyerLEI && buyerLEI.contains("OL:C:")) buyerLEI = buyerLEI.replace("OL:C:", "");
		if (null!= buyerLEI && buyerLEI.contains("UK:C:")) buyerLEI = buyerLEI.replace("UK:C:", "");
		if (null!= sellerLEI && sellerLEI.contains("OL:C:")) sellerLEI = sellerLEI.replace("OL:C:", "");
		if (null!= sellerLEI && sellerLEI.contains("UK:C:")) sellerLEI = sellerLEI.replace("UK:C:", "");

		//commTradeUnfiltered.setBuyerLei(fields[87]); //previously fields[85]
		//commTradeUnfiltered.setSellerLei(fields[96]); //previously fields[94]
		commTradeUnfiltered.setBuyerLei(fields[89]); //previously fields[85]
		commTradeUnfiltered.setSellerLei(sellerLEI); //previously fields[94]
		commTradeUnfiltered.setBuyerUsRegDesg(fields[90]); //previously fields[86]
		commTradeUnfiltered.setSellerUsRegDesg(fields[99]); //previously fields[95]
		commTradeUnfiltered.setBuyerUsEnt(fields[95]); //previously fields[91]
		commTradeUnfiltered.setSellerUsEnt(fields[104]); //previously fields[100]
		commTradeUnfiltered.setBuyerFinEnt(fields[93]); //previously fields[89]
		commTradeUnfiltered.setSellerFinEnt(fields[102]); //previously fields[98]
		
		if(StringUtils.equalsIgnoreCase(fields[14],fields[84])){ //previously fields[80]
			commTradeUnfiltered.setReportPrtyLei(commTradeUnfiltered.getBuyerLei());
			commTradeUnfiltered.setNonReportLei(commTradeUnfiltered.getSellerLei());
			commTradeUnfiltered.setTradeParty1Name(fields[89]); //previously fields[85]
			commTradeUnfiltered.setTradeParty2Name(fields[98]); //previously fields[94]
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setReportSd("Y");
				commTradeUnfiltered.setReportMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("Y");
			}else{
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("N");
			}
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("Y");
				commTradeUnfiltered.setNonRepMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("Y");
			}else{
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("N");
			}
			
			commTradeUnfiltered.setReportFin(commTradeUnfiltered.getBuyerFinEnt());
			commTradeUnfiltered.setReportUs(commTradeUnfiltered.getBuyerUsEnt());
			commTradeUnfiltered.setNonReportId(commTradeUnfiltered.getSellerLei());
			commTradeUnfiltered.setNonRepFin(commTradeUnfiltered.getSellerFinEnt());
			commTradeUnfiltered.setNonRepUs(commTradeUnfiltered.getSellerUsEnt());
	//	}else if((StringUtils.equalsIgnoreCase(fields[15],fields[81]))){
		} else {
			commTradeUnfiltered.setReportPrtyLei(commTradeUnfiltered.getSellerLei());
			commTradeUnfiltered.setTradeParty1Name(fields[98]); //previously fields[94]
			commTradeUnfiltered.setTradeParty2Name(fields[89]); //previously fields[85]
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setReportSd("Y");
				commTradeUnfiltered.setReportMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getSellerUsRegDesg())){
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("Y");
			}else{
				commTradeUnfiltered.setReportSd("N");
				commTradeUnfiltered.setReportMsp("N");
			}
			
			if(StringUtils.equalsIgnoreCase("SD",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("Y");
				commTradeUnfiltered.setNonRepMsp("N");
			}else if(StringUtils.contains("MSP",commTradeUnfiltered.getBuyerUsRegDesg())){
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("Y");
			}else{
				commTradeUnfiltered.setNonReptSd("N");
				commTradeUnfiltered.setNonRepMsp("N");
			}
			
			/*commTrade.setReportSd(commTrade.getSellerUsLeiDesg());
			commTrade.setReportMsp(commTrade.getSellerUsLeiDesg());*/
			commTradeUnfiltered.setReportFin(commTradeUnfiltered.getSellerFinEnt());
			commTradeUnfiltered.setReportUs(commTradeUnfiltered.getSellerUsEnt());
			commTradeUnfiltered.setNonReportLei(commTradeUnfiltered.getBuyerLei());
			commTradeUnfiltered.setNonReportId(commTradeUnfiltered.getBuyerLei());
			/*commTrade.setNonReptSd(commTrade.getBuyerUsLeiDesg());
			commTrade.setNonRepMsp(commTrade.getBuyerUsLeiDesg());
			*/commTradeUnfiltered.setNonRepFin(commTradeUnfiltered.getBuyerFinEnt());
			commTradeUnfiltered.setNonRepUs(commTradeUnfiltered.getBuyerUsEnt());
			}
		commTradeUnfiltered.setAsOfDate(asofDate);
		return commTradeUnfiltered;
	}

	@Override
	public boolean validate(RegRepPrCommPositionReport trade) {
		boolean canLoad = true;
		return canLoad;
	}

	@Override
	public RegRepPrCommPositionReport getTableName() {
		return new RegRepPrCommPositionReport();
	}

	@Override
	public boolean deletePrevDayRecords() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String loadNextJob() {
		// TODO Auto-generated method stub
		return null;
	}

}
