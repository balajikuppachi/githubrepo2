package com.wellsfargo.regulatory.portrec.reports;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrCrPositionReport;
import com.wellsfargo.regulatory.portrec.mailer.PrExtractsTo;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCrPositionReportRepository;
import com.wellsfargo.regulatory.portrec.utils.PortRecBusinessUtil;
import com.wellsfargo.regulatory.portrec.utils.PortRecUtil;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * @author u235720
 *
 */
@Component
public class CrCptyCsvGenerator {
	
	private final Logger logger = Logger.getLogger(IrCptyCsvGenerator.class);

	@Value("${file.portrec.data.extracts}") String outputFolderName;
	
	@Autowired
	RegRepPrCrPositionReportRepository repPrCrPositionReportRepository;
	
	@Autowired
	CrDataCsvWriter crDataCsvWriter;

	@Autowired
	PortRecBusinessUtil portRecBusinessUtil;
	
	public PrExtractsTo createFile(List<String> counterPartyLeiList, Long legalId, Date asOfDate, String frequency) throws Exception {
		
		boolean crFileFlag = false;
		PrExtractsTo reportProp = new PrExtractsTo();
		reportProp.setAssetClass(PortrecConstants.CR);
		
		boolean maskingFlag = portRecBusinessUtil.isCptyMaskingRequired(frequency);
		
		StringBuilder crMtFileNameBuffer = new StringBuilder();
		
		crMtFileNameBuffer.append(PortrecConstants.CR_MT_FILE_INITIAL).append(PortrecConstants.UNDERSCORE).append(legalId).append(PortrecConstants.UNDERSCORE).append(PortRecUtil.convertDateToString_yyyyMdd(asOfDate)).
		append(PortrecConstants.UNDERSCORE).append(frequency.toUpperCase().charAt(0)).append(PortrecConstants.EXTN_CSV);

		String crMtFileName = crMtFileNameBuffer.toString();
		
		File crMtFile  = new File(outputFolderName, crMtFileName);
		
		List<RegRepPrCrPositionReport> cptyCrPositionsByLegalId = null;
		
		for(String counterPartyLei : counterPartyLeiList){
			
			List<RegRepPrCrPositionReport> cptyCrPositionsByLei = null;
			
			if(null != counterPartyLei){
				cptyCrPositionsByLei = repPrCrPositionReportRepository.findCptyPositionsByLeiAndDate(asOfDate,counterPartyLei,counterPartyLei);
			}
			
			if(null != cptyCrPositionsByLei && cptyCrPositionsByLei.size() > 0) {
				logger.info("Number of Cpty CR Dtcc Positions :["+ cptyCrPositionsByLei.size() + "] with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
				crFileFlag = true;
				
				if(!crMtFile.exists()){
					crMtFile.mkdirs();
				}
				
				if(null == cptyCrPositionsByLegalId){
					cptyCrPositionsByLegalId = new ArrayList<RegRepPrCrPositionReport>();
				}
				cptyCrPositionsByLegalId.addAll(cptyCrPositionsByLei);
				
			}else{
				logger.info("No records found for Cpty CR Dtcc Position with Legal Id =["+ legalId + "] and LEI =["+counterPartyLei+"]");
			}
		}
		
		if(crFileFlag)
		{
			int crCount = generateMTFile(cptyCrPositionsByLegalId,crMtFile, maskingFlag);
			reportProp.setCrCount(crCount);
			
			if(crCount > 0){
				reportProp.setCrMtFileName(crMtFileName);
				logger.info("CR MT generated at  "+ outputFolderName);	
			}
			
		}
		reportProp.setFlag(crFileFlag);
		
		return reportProp;
	}
	
	private int generateMTFile(List<RegRepPrCrPositionReport> cptyCrPositionsByLegalId, File crMtFile, boolean maskingFlag) throws Exception 
	{
		Map<String,RegRepPrCrPositionReport> tradeMap = new ConcurrentHashMap<String,RegRepPrCrPositionReport>();
		int count = 0;
		
		try{
			for(RegRepPrCrPositionReport crPositionReport :cptyCrPositionsByLegalId){
				RegRepPrCrPositionReport trade=new RegRepPrCrPositionReport();
				BeanUtils.copyProperties(crPositionReport, trade);
				tradeMap.put(trade.getUsi()+":"+trade.getOrigTradeId(), trade);
			}
			crDataCsvWriter.generateFile(crMtFile, tradeMap, maskingFlag);
		}
		catch(Exception ce){
			throw ce;
		}
		
		count = tradeMap.size();
		
		return count;
	}
	
}
