package com.wellsfargo.regulatory.portrec.loader;

import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.portrec.common.CsvWithHeaderReader;
import com.wellsfargo.regulatory.portrec.common.DataReader;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrEqPositionReport;
import com.wellsfargo.regulatory.portrec.domain.TradeRecordTypeEnum;

@Service
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class RegRepPrDtccEQDSCSVReader extends LoaderHelper<RegRepPrEqPositionReport> {
	public static String PORTFOLIO_SEGMENT_NAME = "Equity_DS, DTCC";
	public static String ASSETCLASS = "Equity";
	@Value("${file.dtcceqds.epr.header}") int headerRows;
	@Override
	public TradeRecordTypeEnum getRecordType() {
		return TradeRecordTypeEnum.EQ_DS;
	}
	@Override
	public String getPortfolioSegmentName() {
		return PORTFOLIO_SEGMENT_NAME;
	}
	@Override
	public DataReader<String[]> getDataReader(InputStream inputStream) {
		return new CsvWithHeaderReader(inputStream, headerRows);
	}
	@Override
	public RegRepPrEqPositionReport parseRecord(String[] fields, String[] exclude, Date asofDate) throws ParseException {
		RegRepPrEqPositionReport dtccTrade = new RegRepPrEqPositionReport();
		
		dtccTrade.setUti(fields[1]);
		//dtccTrade.setAssetClass(fields[2]);
		dtccTrade.setAssetClass(ASSETCLASS);
		dtccTrade.setSecAssetClass(fields[3]);
		dtccTrade.setUsi(fields[4] + fields[5]); //USI Prefix + USI Value


		//113 is party 1 lei  if 113 is empty then pick from 14 and 114 is party 2 lei  if 114 is empty then pick from 17
		
		String tradeParty1 = "";
		String tradeParty2 = "";
		
		if(StringUtils.isBlank(fields[113]))
			tradeParty1 = fields[14];
		else
			tradeParty1 = getLei(fields[113]);
		
		if(StringUtils.isBlank(fields[114]))
			tradeParty2 = fields[17];	
		else
			tradeParty2 = getLei(fields[114]);
		
		for (String s : exclude){
			if (tradeParty1.contains(s)) tradeParty1 = tradeParty1.replace(s, "");
			if (tradeParty2.contains(s)) tradeParty2 = tradeParty2.replace(s, "");
			}
		
		dtccTrade.setParty1(tradeParty1); //Party 1 Value
		dtccTrade.setParty2(tradeParty2); //Party 2 Value
		dtccTrade.setLeiCp(tradeParty1);
		dtccTrade.setLeiUs(tradeParty2);
		
		if(StringUtils.isNotBlank(fields[23]))
			dtccTrade.setParty1NotionalAmount(convertStrToBigDecimalForNotionalAmt(fields[23]));
		
		if(StringUtils.isNotBlank(fields[18]))
			dtccTrade.setTradeParty2Name(fields[18]);
		
		dtccTrade.setParty1NotionalCurr(fields[24]);
		dtccTrade.setExecutionVenue(fields[36]);
		dtccTrade.setCollaterlized(fields[72]);
		dtccTrade.setAdditionalRepository1(fields[79]);
		dtccTrade.setReportedValuation(fields[91]);
		dtccTrade.setTradeParty1UspersonIndicator(fields[99]);
		dtccTrade.setTradeParty1UspersonIndicator(fields[100]);
		dtccTrade.setTradeParty1FinancialEntity(fields[101]);
		dtccTrade.setTradeParty2FinancialEntity(fields[102]);
		dtccTrade.setUnderlyingAssetIdentifierType(fields[266]); //previously (fields[133])
		dtccTrade.setSubmittedFor(fields[11]);
		dtccTrade.setAsOfDate(asofDate);
		return dtccTrade;
	}
	@Override
	public boolean validate(RegRepPrEqPositionReport trade) {
		boolean canLoad = false;
		String repJur = trade.getReportingJurisdiction();
		if(repJur.contains("CFTC") || repJur.isEmpty() || (repJur==null)){
			canLoad = true;
		}	
		
		return canLoad;
	
	}
	@Override
	public RegRepPrEqPositionReport getTableName() {
		return new RegRepPrEqPositionReport();
	}
	@Override
	public boolean deletePrevDayRecords() {
		return false;
	}
	@Override
	public String loadNextJob() {
		// TODO Auto-generated method stub
		return null;
	}	
}
