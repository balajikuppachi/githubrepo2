package com.wellsfargo.regulatory.portrec.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dto.CptyReconFreq;

/**
 * @author Raji Komatreddy
 */
@Component
public class RegRepPrCptyReconFreqDaoImpl
{
	@Autowired
	@Qualifier("portrecJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	String sql = "insert into REG_REP_PR_CPTY_RECON_FREQ (cid_cpty_id, " + "cpty_type, recon_freq, "
	        + " ir_size , cr_size, eq_size, fx_size, fx_intl_size, comm_size, portfolio_size,  update_datetime)" + "	values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	String deleteSql = "delete from REG_REP_PR_CPTY_RECON_FREQ";

	Logger logger = Logger.getLogger(RegRepPrCptyReconFreqDaoImpl.class);

	public int batchInsertCptyReconFreq(final List<CptyReconFreq> cptyReconFreqList) throws PortrecException
	{

		java.util.Date currDate = new java.util.Date();
		try
		{
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{

					CptyReconFreq currCptyReconFreq = cptyReconFreqList.get(i);
					ps.setInt(1, currCptyReconFreq.getCidCptyId());
					ps.setString(2, currCptyReconFreq.getLegalType());
					ps.setString(3, currCptyReconFreq.getReconFreq());

					ps.setInt(4, currCptyReconFreq.getIrSize());
					ps.setInt(5, currCptyReconFreq.getCrSize());
					ps.setInt(6, currCptyReconFreq.getEqSize());
					ps.setInt(7, currCptyReconFreq.getFxSize());
					ps.setInt(8, currCptyReconFreq.getFxIntlSize());
					ps.setInt(9, currCptyReconFreq.getCommSize());
					ps.setInt(10, currCptyReconFreq.getPortfolioSize());
					ps.setDate(11, new java.sql.Date(currDate.getTime()));

				}

				@Override
				public int getBatchSize()
				{
					return cptyReconFreqList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrCptyReconFreqDaoImpl :batchInsertCptyReconFreq method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrCptyReconFreqDaoImpl :batchInsertPortfolibatchInsertCptyReconFreqoSize method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrCptyReconFreqDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);
		}

		logger.info("from batchInsertCptyReconFreq : number of records inserted" + cptyReconFreqList.size());

		return cptyReconFreqList.size();

	}

	public void deleteFromCptyReconFreq()
	{
		jdbcTemplate.update(deleteSql);
	}

}
