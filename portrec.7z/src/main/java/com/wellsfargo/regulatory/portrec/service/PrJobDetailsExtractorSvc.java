package com.wellsfargo.regulatory.portrec.service;

import java.io.File;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.domain.RegRepPrJobDetail;
import com.wellsfargo.regulatory.portrec.dto.PrJobDetails;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrJobDetailRepository;
import com.wellsfargo.regulatory.portrec.utils.PortrecConstants;

/**
 * 
 * @author Raji Komatreddy
 * This class extracts PrJobDetails object from DB depending on incoming job request
 * hands over this object to actual process to persist in PR_JOB_EXECTION_DTLS table
 *
 */
@Transactional(value = "portrec", propagation = Propagation.NEVER)
public class PrJobDetailsExtractorSvc
{

	Logger logger = Logger.getLogger(PrJobDetailsExtractorSvc.class);

	@Autowired
	RegRepPrJobDetailRepository regRepPrJobDetailRepository;

	@Transformer
	public Message<RegRepPrJobDetail> extractJobDetails(Message<?> message) throws PortrecException
	{
		logger.info("inside PrJobDetailsExtractorSvc extractJobDetails method");

		Object ipMessage = null;
		String errorString = null;
		PrJobDetails inPrJobDetails = null;
		Message<RegRepPrJobDetail> regRepPrJobDetailMessage = null;
		String jobName = null;
		String asOfDate = null;
		RegRepPrJobDetail currRegRepPrJobDetail = new RegRepPrJobDetail();

		if (null == message)
		{
			errorString = "Null incoming message PrJobDetails";
			logger.error("########## " + errorString);
			throw new PortrecException("PrJobDetailsExtractorSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		if (ipMessage instanceof PrJobDetails)
		{
			inPrJobDetails = (PrJobDetails) ipMessage;
			jobName = inPrJobDetails.getJobName();
			asOfDate = inPrJobDetails.getAsOfDate();
		}
		else if (ipMessage instanceof File)
		{

			logger.info("onDemand job started by file watcher, jobName and asOfDate will be taken from file name or taken from config file");
			try
			{
				String onDemandFileName = null;
				String[] fileParams = null;

				int numParams = 0;
				File inFile = (File) ipMessage;
				if (null != inFile)
				{   
					onDemandFileName = inFile.getName();
					onDemandFileName = StringUtils.substringBefore(onDemandFileName, ".");
					fileParams = onDemandFileName.split("_");
					numParams = fileParams.length;
					if (numParams >= 2)
					{
						jobName = fileParams[0];
						asOfDate = fileParams[1];
					}
					else
					{
						jobName = fileParams[0];
					}
					inFile.delete();
				}

			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating RegRepPrJobDetail  " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new PortrecException("PrJobDetailsExtractorSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, e.getMessage());

			}
			

		}
	//	Date currDate = new Date();
	//	String dateFormat = PortrecConstants.PORTREC_AS_OF_DATE_FORMAT;
	//	SimpleDateFormat cobDateFormat = new SimpleDateFormat(dateFormat);
	//	Date currAsOfDate = null;

		List<RegRepPrJobDetail> jobDetails = regRepPrJobDetailRepository.findByjobName(jobName);

		if (jobDetails.size() != 1)
		{
			errorString = "Could not find job in PR_JOB_DETAILS table";
			throw new PortrecException("PrJobDetailsExtractorSvc-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}
		
		currRegRepPrJobDetail = jobDetails.get(0);

		regRepPrJobDetailMessage = MessageBuilder.withPayload(currRegRepPrJobDetail).setHeader(PortrecConstants.PORTREC_JOB_NAME,  
				jobName).setHeader(	PortrecConstants.PORTREC_JOB_HEADER_AS_OF_DATE, asOfDate).build();		
	
		//clear jobName and asOfDate for next run	
		jobName = null;
			asOfDate = null;
			
	

		return regRepPrJobDetailMessage;
	}
}
