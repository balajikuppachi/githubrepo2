package com.wellsfargo.regulatory.portrec.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;

/**
 * @author Raji Komatreddy The persistent class for the REG_REP_PR_JOB_DETAILS database table.
 */
@Entity
@Table(name = "REG_REP_PR_JOB_DETAILS")
public class RegRepPrJobDetail
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "job_details_id")
	private long jobDetailsId;

	@Column(name = "create_datetime")
	private Timestamp createDatetime;

	@Column(name = "job_desc")
	private String jobDesc;

	@Column(name = "job_freq")
	private String jobFreq;

	@Column(name = "job_name")
	private String jobName;

	@Column(name = "job_type")
	private String jobType;

	public RegRepPrJobDetail()
	{
	}

	public long getJobDetailsId()
	{
		return this.jobDetailsId;
	}

	public void setJobDetailsId(long jobDetailsId)
	{
		this.jobDetailsId = jobDetailsId;
	}

	public Timestamp getCreateDatetime()
	{
		return this.createDatetime;
	}

	public void setCreateDatetime(Timestamp createDatetime)
	{
		this.createDatetime = createDatetime;
	}

	public String getJobDesc()
	{
		return this.jobDesc;
	}

	public void setJobDesc(String jobDesc)
	{
		this.jobDesc = jobDesc;
	}

	public String getJobFreq()
	{
		return this.jobFreq;
	}

	public void setJobFreq(String jobFreq)
	{
		this.jobFreq = jobFreq;
	}

	public String getJobName()
	{
		return this.jobName;
	}

	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}

	public String getJobType()
	{
		return this.jobType;
	}

	public void setJobType(String jobType)
	{
		this.jobType = jobType;
	}

}