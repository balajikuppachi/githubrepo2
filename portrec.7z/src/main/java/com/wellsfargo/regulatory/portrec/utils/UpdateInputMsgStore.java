package com.wellsfargo.regulatory.portrec.utils;

import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.dao.RegRepPrLiveTradeDaoImpl;

@Component
public class UpdateInputMsgStore
{

	@Autowired
	RegRepPrLiveTradeDaoImpl regRepPrLiveTradeDaoImpl;

	@Value("${file.livetrades.processedFolder}")
	String outPutDir;

	@Value("${portrec.livetrades.wellsfargo.affiliates}")
	String wfAffiliates;

	private static final Logger logger = Logger.getLogger(UpdateInputMsgStore.class);

	private static String INTERNAL = "INTERNAL";
	private static String ZERO = "0";
	private static String NULL = "null";
	List<String> wfAffiliatesList = new ArrayList<String>();
	

	public void getBusAcctIDs(Message<?> message)
	{
		logger.info("inside UpdateInputMsgStore : getBusAcctIDs method ");
		String updateInputMsgstoreFile = null;
		String noBusAcctIdFile = null;
		String baExistsNoChangeInBaId = null;
		String baExistsButChangeInBaid = null;
		String baIdNullBeforeUpdatedNow = null;
		String baIdNullFailedToMapBaid = null;
		String wellsCpReportinThem = null;
		String party2ContainsInternal = null;
		String commodityBaids = null;

		try
		{
			updateInputMsgstoreFile = outPutDir + "/updateInputMsg.txt";
			noBusAcctIdFile = outPutDir + "/noBusAcctIdFile.txt";

			baExistsNoChangeInBaId = outPutDir + "/baExistsNoChangeInBaId.txt";
			baExistsButChangeInBaid = outPutDir + "/baExistsButChangeInBaid.txt";
			baIdNullBeforeUpdatedNow = outPutDir + "/baIdNullBeforeUpdatedNow.txt";
			baIdNullFailedToMapBaid = outPutDir + "/baIdNullFailedToMapBaid.txt";
			wellsCpReportinThem = outPutDir + "/wellsCpReportinThem.txt";
			party2ContainsInternal = outPutDir + "/party2ContainsInternal.txt";
			commodityBaids = outPutDir + "/commodityBaids.txt";

			String[] wfAffiliateArray = null;
			
			Path noBusAcctIdFilePath = Paths.get(noBusAcctIdFile);

			Path baExistsNoChangeInBaIdPath = Paths.get(baExistsNoChangeInBaId);
			Path baExistsButChangeInBaidPath = Paths.get(baExistsButChangeInBaid);
			Path baIdNullBeforeUpdatedNowPath = Paths.get(baIdNullBeforeUpdatedNow);
			Path baIdNullFailedToMapBaidPath = Paths.get(baIdNullFailedToMapBaid);
			Path wellsCpReportinThemPath = Paths.get(wellsCpReportinThem);
			Path party2ContainsInternalPath = Paths.get(party2ContainsInternal);
			Path commodityBaidsPath = Paths.get(commodityBaids);

			BufferedWriter noBusAcctIdFileWriter = Files.newBufferedWriter(noBusAcctIdFilePath, Charset.defaultCharset());

			BufferedWriter baExistsNoChangeInBaIdWriter = Files.newBufferedWriter(baExistsNoChangeInBaIdPath, Charset.defaultCharset());
			BufferedWriter baExistsButChangeInBaidWriter = Files.newBufferedWriter(baExistsButChangeInBaidPath, Charset.defaultCharset());
			BufferedWriter baIdNullBeforeUpdatedNowWriter = Files.newBufferedWriter(baIdNullBeforeUpdatedNowPath, Charset.defaultCharset());
			BufferedWriter baIdNullFailedToMapBaidWriter = Files.newBufferedWriter(baIdNullFailedToMapBaidPath, Charset.defaultCharset());
			BufferedWriter wellsCpReportinThemWriter = Files.newBufferedWriter(wellsCpReportinThemPath, Charset.defaultCharset());
			BufferedWriter party2ContainsInternalWriter = Files.newBufferedWriter(party2ContainsInternalPath, Charset.defaultCharset());
			BufferedWriter commodityBaidsWriter = Files.newBufferedWriter(commodityBaidsPath, Charset.defaultCharset());

			try
			{
				if (null != regRepPrLiveTradeDaoImpl)
				{

					if (null != wfAffiliates)
					{
						wfAffiliateArray = wfAffiliates.split(":");

						for (String currwfAffiliate : wfAffiliateArray)
						{
							wfAffiliatesList.add(currwfAffiliate);

						}
					}

					

					SqlRowSet sendIdList = regRepPrLiveTradeDaoImpl.getsendIdsFromTempOpen();

					{
						int cntofRecords = 0;
						if (null != sendIdList)
						{
							while (sendIdList.next())
							{
								cntofRecords ++;
								int temPOpenSendId = sendIdList.getInt("send_id");
								SqlRowSet bufferresults = regRepPrLiveTradeDaoImpl.getInputMsgBuffer(temPOpenSendId);
								System.gc();

								if (null != bufferresults)
								{
									while (bufferresults.next())
									{
										String tradeID = bufferresults.getString("src_trade_id");
										int send_id = bufferresults.getInt("send_id");
										String bufferData = bufferresults.getString("buffer_data");
										String sysName = bufferresults.getString("src_asset_class");
										String srcCptyName = bufferresults.getString("src_cparty_name");
										String party2LEI = bufferresults.getString("party2_lei");
										String party1LEI = bufferresults.getString("party1_lei");
										String existBaId = bufferresults.getString("bus_acc_id");
										String reportingParty = bufferresults.getString("rep_party");
										String baidFromParty2 = null;
										String derivedBaId = null;

										// check if party2_lei contains INTERNAL

										if (null != party2LEI && party2LEI.contains(INTERNAL))
										{
											logger.info("LEI_CP contains INTERNAL in lei its value is  " + party2LEI);
											baidFromParty2 = StringUtils.substringAfterLast(party2LEI, ":");

										}

										if ( null != party1LEI && party1LEI.contains(":")) 
											party1LEI = StringUtils.substringAfter(party1LEI, ":");

										if ( null != party2LEI &&  party2LEI.contains(":")) 
											party2LEI = StringUtils.substringAfter(party2LEI, ":");

										if (sysName.contains("InterestRate") || sysName.contains("Credit") || sysName.contains("Equity"))
										{
											int beginIndex = bufferData.indexOf("BusinessAccountId}=");
											int endIndex = bufferData.indexOf("{", beginIndex);
											String buffer_bus_acct_ID = null;

											if (endIndex > 0)
											{
												buffer_bus_acct_ID = bufferData.substring(beginIndex + 19, endIndex);
												if (!(buffer_bus_acct_ID == null) && (buffer_bus_acct_ID.length() > 1) && (buffer_bus_acct_ID.length() < 20))
												{
													// valid buffer_bus_acct_ID
													buffer_bus_acct_ID = buffer_bus_acct_ID.trim();
													logger.info("Buffer STV contains Bussiness Account ID  " + buffer_bus_acct_ID);
												}
												else
												{
													// no business acount exist in STV file or not a
													// valid
													// business account ID
													buffer_bus_acct_ID = null;
												}

											}

											if (null != party2LEI && wfAffiliatesList.contains(party2LEI))
											{
												if (null != existBaId)
												{
													String leiFromMappingBussAcc = regRepPrLiveTradeDaoImpl.getLeiFromMappingBussinessLei(existBaId);

													if (null != leiFromMappingBussAcc && leiFromMappingBussAcc.contains(":")) 
														leiFromMappingBussAcc = StringUtils.substringAfter(leiFromMappingBussAcc,  ":");

													if (wfAffiliatesList.contains(leiFromMappingBussAcc))
													{
														// LEC_CP = Wells and reporting aprty = them
														// in this
														// case business account id should be of
														// cpty
														derivedBaId = regRepPrLiveTradeDaoImpl.getBaIdFromMappingBussinessLei(party1LEI);
														if(null != derivedBaId)
															 derivedBaId.trim();
														logger.info("LEI_CP is Wells hence taking CP BA account as final Baid: existing BaId: " + existBaId + "send id is " + send_id);

														String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='"
														        + tradeID + "'" + " and src_asset_class ='" + sysName + "'" + " and bus_acc_id='" + existBaId + "'";
														wellsCpReportinThemWriter.append(query);
														wellsCpReportinThemWriter.newLine();

													}
												}
												else
												{
													derivedBaId = regRepPrLiveTradeDaoImpl.getBaIdFromMappingBussinessLei(party1LEI);
													if(null != derivedBaId)
														derivedBaId.trim();
													logger.info("LEI_CP is Wells and existing BaId is null hence taking CP BA account as final Baid " + "send id is " + send_id);

													String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='" + tradeID
													        + "'" + " and src_asset_class ='" + sysName + "'";
													wellsCpReportinThemWriter.append(query);
													wellsCpReportinThemWriter.newLine();

												}
											}

											if (null != baidFromParty2 && null == derivedBaId)
											{
												// check baidFromParty2 and buffer_bus_acct_ID are
												// same if same
												// use buffer_bus_acct_ID value else go to mapping
												// business
												// account table to find cpty lei (not wellsfargo
												// lei)
												if (null != buffer_bus_acct_ID && baidFromParty2.equalsIgnoreCase(buffer_bus_acct_ID))
												{
													derivedBaId = buffer_bus_acct_ID;
													if(null != derivedBaId)
														 derivedBaId.trim();
													logger.info("LEI_CP contains INTERNAL in lei and baid from STV and  lei part both are same hence using buffer Baid " + "send id is " + send_id);
													String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='" + tradeID
													        + "'" + " and src_asset_class ='" + sysName + "'";
													party2ContainsInternalWriter.append(query);
													party2ContainsInternalWriter.newLine();

												}
												else if (null != buffer_bus_acct_ID && !baidFromParty2.equalsIgnoreCase(buffer_bus_acct_ID))
												{
													String leiFromMappingBussAcc = regRepPrLiveTradeDaoImpl.getLeiFromMappingBussinessLei(buffer_bus_acct_ID);
													if (null != leiFromMappingBussAcc && leiFromMappingBussAcc.contains(":"))
														leiFromMappingBussAcc = StringUtils.substringAfter(leiFromMappingBussAcc, ":");

													if (null != leiFromMappingBussAcc && wfAffiliatesList.contains(leiFromMappingBussAcc))
													{
														derivedBaId = baidFromParty2;
														if(null != derivedBaId)
															 derivedBaId.trim();
														logger.info("LEI_CP contains INTERNAL in lei and existing baid is of wellsfargo hence taking Baid from part2Lei " + "send id is " + send_id);
														String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='"
														        + tradeID + "'" + " and src_asset_class ='" + sysName + "'";
														party2ContainsInternalWriter.append(query);
														party2ContainsInternalWriter.newLine();

													}
													else
													{
														derivedBaId = buffer_bus_acct_ID;
														if(null != derivedBaId)
															 derivedBaId.trim();
														logger.info("LEI_CP contains INTERNAL in lei and existing baid is not wellsfargo hence taking Baid from part2Lei " + "send id is " + send_id);
														String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='"
														        + tradeID + "'" + " and src_asset_class ='" + sysName + "'";
														party2ContainsInternalWriter.append(query);
														party2ContainsInternalWriter.newLine();

													}
												}
												else
												{
													derivedBaId = baidFromParty2;
													if(null != derivedBaId)
														 derivedBaId.trim();
													logger.info("LEI_CP contains INTERNAL in lei and Baid in STV is null hence using BaId from party2Lei " + "send id is " + send_id);
													String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='" + tradeID
													        + "'" + " and src_asset_class ='" + sysName + "'";
													party2ContainsInternalWriter.append(query);
													party2ContainsInternalWriter.newLine();

												}

											}
											else
											{
												if (null != existBaId && null != buffer_bus_acct_ID && null == derivedBaId)
												{
													if (existBaId.equalsIgnoreCase(buffer_bus_acct_ID ))
													{
														derivedBaId =  getUpdatedBaId(party1LEI, party2LEI, buffer_bus_acct_ID);
														if(null != derivedBaId)
															 derivedBaId.trim();
														logger.info("Baid already exists in input_msg_store, it also matched with Buffer STV BaId " + "send id is " + send_id);
														String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='"
														        + tradeID + "'" + " and src_asset_class ='" + sysName + "'" + " and bus_acc_id='" + existBaId + "'";
														baExistsNoChangeInBaIdWriter.append(query);
														baExistsNoChangeInBaIdWriter.newLine();

													}
													else
													{
														derivedBaId =  getUpdatedBaId(party1LEI, party2LEI, buffer_bus_acct_ID);
														if(null != derivedBaId)
															 derivedBaId.trim();
														logger.info("Baid already exists but does not match with input_msg_store, taking Baid existing in Buffer STV BaId " + "send id is " + send_id);
														logger.info("Baid existing in input_msg_store " + existBaId + " :baid from stv buffer: " + buffer_bus_acct_ID);

														String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='"
														        + tradeID + "'" + " and src_asset_class ='" + sysName + "'";
														baExistsButChangeInBaidWriter.append(query);
														baExistsButChangeInBaidWriter.newLine();

													}
												}
												else if (null == existBaId && null != buffer_bus_acct_ID && null == derivedBaId)
												{
													derivedBaId =  getUpdatedBaId(party1LEI, party2LEI, buffer_bus_acct_ID);
													if(null != derivedBaId)
														 derivedBaId.trim();
													logger.info("Baid not exists in input_msg_store, exists in STV, hence taking it from STV " + "send id is " + send_id);

													String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='" + tradeID
													        + "'" + " and src_asset_class ='" + sysName + "'";
													baIdNullBeforeUpdatedNowWriter.append(query);
													baIdNullBeforeUpdatedNowWriter.newLine();
												}
												else if (null != existBaId && null == buffer_bus_acct_ID && null == derivedBaId)
												{
													derivedBaId =  getUpdatedBaId(party1LEI, party2LEI, existBaId); 
													if(null != derivedBaId)
														 derivedBaId.trim();
													logger.info("Baid  exists in input_msg_store, not exists in STV, hence taking it from STV " + "send id is " + send_id);

													String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='" + tradeID
													        + "'" + " and src_asset_class ='" + sysName + "'";
													baExistsNoChangeInBaIdWriter.append(query);
													baExistsNoChangeInBaIdWriter.newLine();
												}
												else if (null == existBaId && null == buffer_bus_acct_ID && null == derivedBaId)
												{
													 derivedBaId = null;
													derivedBaId = regRepPrLiveTradeDaoImpl.getBaIdFromMappingBussinessLei(party2LEI);
													if (null != derivedBaId)
													{
														derivedBaId = derivedBaId.trim();
														String leiFromMappingBussAcc = regRepPrLiveTradeDaoImpl.getLeiFromMappingBussinessLei(derivedBaId);

														if (null != leiFromMappingBussAcc && leiFromMappingBussAcc.contains(":")) 
															leiFromMappingBussAcc = StringUtils.substringAfter(leiFromMappingBussAcc,  ":");
														
														if (wfAffiliatesList.contains(leiFromMappingBussAcc))
														{
															derivedBaId = regRepPrLiveTradeDaoImpl.getBaIdFromMappingBussinessLei(party1LEI);
														}
														
													}
													else
													{
														derivedBaId = regRepPrLiveTradeDaoImpl.getBaIdFromMappingBussinessLei(party1LEI);
													}
													if(null != derivedBaId)
														derivedBaId = derivedBaId.trim();

													logger.info("Baid  neither exists in input_msg nor in buffer STV  getting baid corresponding to party2LEI" + "send id is " + send_id);

													String query = " update input_msg_store set bus_acc_id='" + derivedBaId + "' where send_id =" + send_id + " and src_trade_id='" + tradeID + "'"
													        + " and src_asset_class ='" + sysName + "'";
													noBusAcctIdFileWriter.append(query);
													noBusAcctIdFileWriter.newLine();

												}

											}

											// reset the values we calulated in this iteration
											baidFromParty2 = null;
											derivedBaId = null;

										}
										else if (sysName.contains("Commodity"))
										{
											
											int beginIndex = bufferData.indexOf("<LECIDId>");
											int endIndex = bufferData.indexOf("</LECIDId>", beginIndex);
											if (endIndex > 0)
											{
												String bus_acct_ID = bufferData.substring(beginIndex + 9, endIndex);
												if (!(bus_acct_ID == null) && (bus_acct_ID.length() > 1) && (bus_acct_ID.length() < 20))
												{
													cntofRecords ++;
													bus_acct_ID = bus_acct_ID.trim().replace("\n", "").replace("\r", "");
													String query = " update input_msg_store set bus_acc_id='" + bus_acct_ID + "'" + " where send_id =" + send_id + " and src_trade_id='" + tradeID
													        + "'" + " and src_asset_class ='" + sysName + "'";
													
													logger.info("commodity assetclass " + "send id is " + send_id);
													
													commodityBaidsWriter.append(query);
													commodityBaidsWriter.newLine();


												}
												else
												{
													cntofRecords ++;
													noBusAcctIdFileWriter.append("BusinessAcctID is null for :" + tradeID);
													noBusAcctIdFileWriter.newLine();
													System.out.println("BusinessAcctID is null for :" + tradeID);
												}
											}
										}

									}

								}

							}
							// write to files after every 100 rows
							if(cntofRecords == 100 )
							{
								noBusAcctIdFileWriter.flush();							
								baExistsNoChangeInBaIdWriter.flush();						
								baExistsButChangeInBaidWriter.flush();
								baIdNullBeforeUpdatedNowWriter.flush();					
								baIdNullFailedToMapBaidWriter.flush();
								wellsCpReportinThemWriter.flush();
							   party2ContainsInternalWriter.flush();
							   commodityBaidsWriter.flush();
							   cntofRecords = 0; // reset count
							  
								
								
							}
						}
					}		

				}

				// out.close();
			}
			catch (Exception ex)
			{
				
				logger.error("exception occurred inside updateInputMsgStore " + ExceptionUtils.getFullStackTrace(ex));
				// ex.printStackTrace();
			}
			finally
			{
				noBusAcctIdFileWriter.flush();
				noBusAcctIdFileWriter.close();

				baExistsNoChangeInBaIdWriter.flush();
				baExistsNoChangeInBaIdWriter.close();

				baExistsButChangeInBaidWriter.flush();
				baExistsButChangeInBaidWriter.close();

				baIdNullBeforeUpdatedNowWriter.flush();
				baIdNullBeforeUpdatedNowWriter.close();

				baIdNullFailedToMapBaidWriter.flush();
				baIdNullFailedToMapBaidWriter.close();

				wellsCpReportinThemWriter.flush();
				wellsCpReportinThemWriter.close();

				party2ContainsInternalWriter.flush();
				party2ContainsInternalWriter.close();
				
				commodityBaidsWriter.flush();
				commodityBaidsWriter.close();

				
			}

			logger.info("successfully finished the process  RegRepPrLiveTradeDaoImpl");

		}
		catch (Exception ex)
		{
			logger.error("exception occurred inside UpdateInputMsgStore" + ExceptionUtils.getFullStackTrace(ex));
			// ex.printStackTrace();
		}

	}
	
	private String getUpdatedBaId(String party1Lei, String party2Lei, String extBusinessActId)
	{
		String updatedBaid = null;
		String leiFromMappingBussAcc = null;
		
		if(null != extBusinessActId && !extBusinessActId.equalsIgnoreCase(ZERO) && !extBusinessActId.equalsIgnoreCase(NULL))
		{
			leiFromMappingBussAcc = regRepPrLiveTradeDaoImpl.getLeiFromMappingBussinessLei(extBusinessActId);
			if (null != leiFromMappingBussAcc && leiFromMappingBussAcc.contains(":"))
				leiFromMappingBussAcc = StringUtils.substringAfter(leiFromMappingBussAcc, ":");
		}
		

		if ( (null != leiFromMappingBussAcc && wfAffiliatesList.contains(leiFromMappingBussAcc)) || extBusinessActId.equalsIgnoreCase(ZERO) || extBusinessActId.equalsIgnoreCase(NULL))
		{
			if(wfAffiliatesList.contains(party1Lei))
			{
				updatedBaid = regRepPrLiveTradeDaoImpl.getBaIdFromMappingBussinessLei(party2Lei);
			}
			else
			{
				updatedBaid = regRepPrLiveTradeDaoImpl.getBaIdFromMappingBussinessLei(party1Lei);
			}
		}
		else
		{
			updatedBaid = extBusinessActId;
			
		}
		
		
		return updatedBaid;
	}

}
