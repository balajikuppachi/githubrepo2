package com.wellsfargo.regulatory.portrec.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.PortrecException;
import com.wellsfargo.regulatory.portrec.dto.DaReport;

/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class RegRepPrDaReportDaoImpl
{

	@Autowired
	@Qualifier("portrecJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	String sql = "insert into REG_REP_PR_DA_REPORT (job_execution_id, cid_cpty_id, cpty_type, as_of_date," 
					+ " recon_freq, mt_val_type, asset_class, file_name, affirmed_flag, affirm_datetime,"
					+ " affirm_comments, file_exception, file_exception_reason, portfolio_size, create_datetime)"
					+ "  values (?, ?, ?, ?, ? , ?, ?, ?, ? ,? ,?, ?, ?, ?, ?)";

	Logger logger = Logger.getLogger(RegRepPrDaReportDaoImpl.class);

	public int batchInsertDaReport(final List<DaReport> DaReportList) throws PortrecException
	{

		java.util.Date currDate = new java.util.Date();
		try
		{
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter()
			{

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException
				{
					DaReport currDaReport = DaReportList.get(i);

					ps.setLong(1, currDaReport.getJobExecutionId());
					ps.setLong(2, currDaReport.getCidCptyId());
					ps.setString(3, currDaReport.getCptyType());
					if (null != currDaReport.getAsOfDate())
					{
						ps.setDate(4, (Date) new java.sql.Date(currDaReport.getAsOfDate().getTime()));
					}
					else
					{
						ps.setDate(4, null);
					}
					ps.setString(5, currDaReport.getReconFreq());
					ps.setString(6, currDaReport.getMtValType());
					ps.setString(7, currDaReport.getAssetClass());
					ps.setString(8, currDaReport.getFileName());
					ps.setString(9, currDaReport.getAffirmedFlag());
					if (null != currDaReport.getAffirmDatetime())
					{
						ps.setDate(10, (Date) new java.sql.Date(currDaReport.getAffirmDatetime().getTime()));
					}
					else
					{
						ps.setDate(10, null);
					}
					ps.setString(11, currDaReport.getAffirmComments());
					ps.setString(12, currDaReport.getFileException());
					ps.setString(13, currDaReport.getFileExceptionReason());
					ps.setInt(14, currDaReport.getPortfolioSize());
					
					ps.setDate(15, new java.sql.Date(currDate.getTime()));

				}

				@Override
				public int getBatchSize()
				{
					return DaReportList.size();
				}

			});
		}
		catch (Exception ex)
		{
			String errorStr = "exception occurred inside RegRepPrDaReportDaoImpl :batchInsertDaReport method" + ex.getMessage();
			logger.error("exception occurred inside RegRepPrDaReportDaoImpl :batchInsertDaReport method" + ExceptionUtils.getStackTrace(ex));

			throw new PortrecException("RegRepPrDaReportDaoImpl:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorStr, ex);
		}

		logger.info("from batchInsertDaReport : number of records inserted" + DaReportList.size());

		return DaReportList.size();

	}

}
