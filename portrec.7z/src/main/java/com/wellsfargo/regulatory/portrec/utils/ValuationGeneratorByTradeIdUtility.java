package com.wellsfargo.regulatory.portrec.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.portrec.domain.RegRepPrAlgoValuation;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrAlgoValuationRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrCidRepository;
import com.wellsfargo.regulatory.portrec.repository.RegRepPrLiveTradeRepository;

/**
 * @author u235720
 */
@Component
@ManagedResource(description = "Valuation Generation by Trade ID")
public class ValuationGeneratorByTradeIdUtility
{

	private final Logger logger = Logger.getLogger(ValuationGeneratorByTradeIdUtility.class);

	@Autowired
	RegRepPrCidRepository regRepPrCidRepository;

	@Autowired
	RegRepPrLiveTradeRepository regRepPrLiveTradeRepository;
	
	@Value("${file.portrec.data.extracts}") String valuationFilePath;
	
	@Value("${file.utility.inputFolder}") String utilityExcelPath;
		
	@Autowired
	RegRepPrAlgoValuationRepository regRepPrAlgoValuationRepository;


	@ManagedOperation(description = "Start genarating valuation by trade id")
	public void generateValuation(String asOfDate, String frequency) throws Exception
	{
		
		logger.info("Start valuation process- ");
		
		List<Object[]> tradeIds = excelReader();
		
		Date convertedAsOfDate = null;
		
		SimpleDateFormat reconDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		try
		{
			convertedAsOfDate = reconDateFormat.parse(asOfDate);
		}
		catch (ParseException e)
		{
			throw e;
		}
		
		for(Object[] counterParty : tradeIds){

			generateValuationFile(counterParty, convertedAsOfDate, frequency);
		}
		
		logger.info("End valuation process- ");
	}
	
	
	public void generateValuationFile(Object[] counterParty, Date asOfDate, String frequency) throws Exception {
		
		logger.info("Start generating VAL - ");
		
		String tradeId = null; 
		Integer legalId = null;
		
		if(null != counterParty){
			
			if(null != counterParty[0]){
				tradeId = String.valueOf(counterParty[0]);
			}
			
			
			if(null != counterParty[1]){
				legalId =  Integer.valueOf((String)counterParty[1]);
			}
			
		}
		
		if(null != tradeId && null != legalId && null != asOfDate){
			
			String valuationFileName = "CPPortfolio-LegalId-" + legalId + PortrecConstants.HYPHEN + PortRecUtil.convertDateToString_yyyyMdd(asOfDate) + PortrecConstants.HYPHEN + frequency.toUpperCase().charAt(0) + ".csv";
			List<RegRepPrAlgoValuation> entries= new ArrayList<RegRepPrAlgoValuation>();
			try {
				
				List<RegRepPrAlgoValuation> entriesperLegalID = regRepPrAlgoValuationRepository.findAlgoValuationByTradeIdAndAsOfDate(tradeId,asOfDate);
				entries.addAll(entriesperLegalID);
				
				if(null != entries && entries.size() >0){
					
					File file  = new File(valuationFilePath, valuationFileName);
					FileWriter fw = new FileWriter(file);
					fw.append("TradeID,ProductID,TradeDate,EndDate,MaturityDate,Notional1,Not. Ccy,PV,PVCcy\n");
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
					DecimalFormat numberFormat = new DecimalFormat("#0.00#");
					try {
						
						for (RegRepPrAlgoValuation entry : entries) {
							fw
							.append(entry.getSourceSystem().concat(entry.getTradeId()).concat(PortRecUtil.convertDateToString_yyyyMdd(entry.getTradeDate()))).append(',')			
							.append(entry.getProductId()).append(',')
							.append(PortRecUtil.safeDateFormat(dateFormat, entry.getTradeDate())).append(',')
							.append("").append(',')
							.append(PortRecUtil.safeDateFormat(dateFormat, entry.getMaturityDate())).append(',')
							.append(PortRecUtil.safeNumberFormat(numberFormat, entry.getNotional1())).append(',')
							.append(entry.getNotional1Ccy()).append(',')	
							.append(PortRecUtil.safeStringFormatAsNumberforPV(numberFormat, entry.getPv())).append(',')
							.append(entry.getPvCcy()).append(',')
							.append('\n');
						}
						
					} catch(Exception ae) {
						throw ae;
					} finally {
						fw.close();
					}
					
					logger.info("VAL For Counterparty '" + legalId + "' has been generated: " + file.getCanonicalPath());
				}
			
			} catch(Exception ae) {
				throw ae;
			}
		}

		logger.info("End generating VAL - Trade Id :[" + tradeId + "], asOfDate :["+ asOfDate +"]");
		
	}
	
	
	public static void main(String[] args) throws Exception {

		ValuationGeneratorByTradeIdUtility excelReader = new ValuationGeneratorByTradeIdUtility();
		
		//List<Object[]> list = excelReader.excelReader();
		
		/*for(Object[] obj : list){
			System.out.println(""+obj[0]+" : "+obj[1]);
		}*/
		
		excelReader.generateValuation("2015-06-26", "ANNUAL");
		
	}

	public List<Object[]> excelReader() throws IOException {

		List<Object[]> list = new ArrayList<Object[]>();
				
		try {
			File file = new File(utilityExcelPath + File.separator + "ValuationInput.xlsx");
			
			if(file.exists()){
				
				InputStream ExcelFileToRead = new FileInputStream(file);
				XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
				XSSFSheet sheet = wb.getSheetAt(0);
				XSSFRow row;
				XSSFCell cell;
				Iterator rows = sheet.rowIterator();
				while (rows.hasNext()) {
					row = (XSSFRow) rows.next();
					Iterator cells = row.cellIterator();
					Object[] objArr = new Object[2];
					int index =0;
					while (cells.hasNext()) {
						cell = (XSSFCell) cells.next();
						objArr[index] = cell.getRawValue();
						index ++;
					}
					list.add(objArr);
				}
			}
		} catch (IOException e) {
			throw e;
		}
		return list;
	}
	
	
}