package  com.wellsfargo.regulatory.portrec.loader;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author u250429
 * 
 */
public class DateUtilLoader {
	static Logger logger = LoggerFactory.getLogger(DateUtilLoader.class);
	public static Date getDateFromString(String dateStr) {
		String patterns[] = { "MM/dd/yyyy", "yyyy-MM-dd", "yyyyMMdd HHmmss", "yyyyMMdd", "d.MM.yyyy", "dd-MMM-yy", "MM/dd/yyyy HH:mm", "M/DD/yyyy HH:mm"};
		Date output = new Date();
			for (int i = 0; i < patterns.length; i++) {
				output = doPrintMonth(patterns[i], dateStr);
				if(output!=null) break;
			}
			return output;
	}
	
	/**
	 *  getDateFromStringForValuation  : These patterns are for Valuation Files.
	 *  
	 * @param dateStr
	 * @return
	 */
	public static Date getDateFromStringForValuation(String dateStr) {
		String patterns[] = { "dd-MM-yyyy","dd/MM/yyyy","dd-MMM-yy"};
		Date output = new Date();
			for (int i = 0; i < patterns.length; i++) {
				output = doPrintMonth(patterns[i], dateStr);
				if(output!=null) break;
			}
			return output;
	}
	

	private static Date doPrintMonth(String pattern, String input) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(pattern);
			Date output = sdf.parse(input);
			return output;
		} catch (Exception e) {
		}
		return null;
	}
	
	public static Date getCurrentDate() {
		Calendar cal = Calendar.getInstance();
		return cal.getTime();
	}

	public static Date getDateFromStrComm(String dateStr) throws ParseException {
		String patterns[] = { "MM/dd/yy", "MM/dd/yyyy"};
		Date output = new Date();
			for (int i = 0; i < patterns.length; i++) {
				output = doPrintMonth(patterns[i], dateStr);
				if(output!=null) break;
			}
			return output;
	}

	public static Date getDateFromStr(String dateStr) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date convertedDate = dateFormat.parse(dateStr);
		return convertedDate;
	}


	public static Date getDateFromStrCR(String dateStr) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date convertedDate = dateFormat.parse(dateStr);
		return convertedDate;
	}

	public static Date getDateFromStrTS(Timestamp dateStr) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		String convertedDate = dateFormat.format((java.util.Date) dateStr);
		return getDateFromStr(convertedDate);
	}
	
	public static String getDateFromStrValuation(Date date) throws ParseException {
		DateFormat formatter ; 
   	    formatter = new SimpleDateFormat("MMddyyyy");
		return formatter.format(date);
	}
	
	public static Date getDateTimeStampFromStrCR(String dateStr) throws ParseException {
		
		Date convertedDate = null;
		try{
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss'Z'");
			convertedDate = dateFormat.parse(dateStr);
		}
		catch(Exception ae){
			logger.info("ERROR in parsing " + dateStr );
			logger.info("StackTrace " + ae.getMessage() );
		}
		
		return convertedDate;
	}
	
	public static Date getDateTimeStampFromStrRT(String dateStr) throws ParseException {
			
			Date convertedDate = null;
			try{
				SimpleDateFormat dateFormat = new SimpleDateFormat("MM/DD/yyyy hh:mm");
				convertedDate = dateFormat.parse(dateStr);
			}
			catch(Exception ae){
				logger.info("ERROR in parsing " + dateStr );
				logger.info("StackTrace " + ae.getMessage() );
			}
			
			return convertedDate;
		}
	
	public static String getStrDate(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		return dateFormat.format(date);
	}
	
	public static String getExecTimestampAsString(Date date){		
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return dateFormat.format(date);
	}
	
	public static String getFileDateExtension(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(date);
	}
	
	public static Date dateValueReturn(String strDate) {
		Date date = null;
		try {
			if (StringUtils.isNotBlank(strDate))
				date = DateUtilLoader.getDateFromString(strDate);
			else
				date = new SimpleDateFormat("MM/dd/yyyy").parse("12/31/9999");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
