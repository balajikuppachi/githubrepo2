package com.wellsfargo.regulatory.portrec.utils;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;
import com.wellsfargo.regulatory.portrec.dao.RegRepPrLiveTradeDaoImpl;
import com.wellsfargo.regulatory.portrec.dto.CptyLiveTrades;

public class TestRegRepPrLiveTradeDaoImpl
{


	private static final Logger logger = Logger.getLogger(TestRegRepPrLiveTradeDaoImpl.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/portrec-appContext.xml";

	public static void main(String[] args)
	{
		try
		{
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("PORTREC_HOME", sdrHomePath);

			ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
			logger.info("Before calling CptyReconFreqCalculatorSvc");
			RegulatoryBeanFactory.setContext(applicationContext);
			
			RegRepPrLiveTradeDaoImpl regRepPrLiveTradeDaoImpl = (RegRepPrLiveTradeDaoImpl)RegulatoryBeanFactory.getBean("regRepPrLiveTradeDaoImpl");
			
			List<CptyLiveTrades> liveTrades = regRepPrLiveTradeDaoImpl.getCptyLiveTrades();

			
			
			logger.info("size of live trades " + liveTrades.size());

		}
		catch (Exception e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}



}
