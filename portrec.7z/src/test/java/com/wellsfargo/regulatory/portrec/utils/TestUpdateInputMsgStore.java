package com.wellsfargo.regulatory.portrec.utils;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;

public class TestUpdateInputMsgStore
{

	private static final Logger logger = Logger.getLogger(UpdateInputMsgStore.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/portrec-appContext.xml";

	public static void main(String[] args)
	{
		logger.info("inside UpdateInputMsgStore : main method ");

		try
		{

			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("PORTREC_HOME", sdrHomePath);

			ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
			logger.info("Before getting RegRepPrLiveTradeDaoImpl");
			RegulatoryBeanFactory.setContext(applicationContext);

			UpdateInputMsgStore updateInputMsgStore = (UpdateInputMsgStore) RegulatoryBeanFactory.getBean("updateInputMsgStore");

			try
			{
				if (null != updateInputMsgStore)
				{
					//updateInputMsgStore.getBusAcctIDs();
				}

				// out.close();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}

			logger.info("successfully finished the process  RegRepPrLiveTradeDaoImpl");

		}
		catch (Exception ex)
		{
			logger.error("exception occurred inside UpdateInputMsgStore" + ex.getMessage());
			ex.printStackTrace();
		}

	}

}
