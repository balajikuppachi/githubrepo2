package com.wellsfargo.regulatory.portrec.utils;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;

public class TeatPortRecUtils 
{

	private static final Logger logger = Logger.getLogger(TeatPortRecUtils.class);
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/portrec-appContext.xml";

	public static void main(String[] args)
	{
		try
        {
			String userDirPath = System.getProperty("user.dir");
			String sdrHomePath = System.getProperty("REG_REP_HOME");
			File sdrHome;
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("PORTREC_HOME", sdrHomePath);
			
			ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
			logger.info("Before calling ReconReportGeneratorSvc");
			RegulatoryBeanFactory.setContext(applicationContext);
			
			PortRecUtil portRecUtil = (PortRecUtil)RegulatoryBeanFactory.getBean("portRecUtil");
			portRecUtil.getUtilString();

        }
        catch (Exception e1)
        {
	        // TODO Auto-generated catch block
	        e1.printStackTrace();
        }
		
	}


}
