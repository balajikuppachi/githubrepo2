package com.bala.vm.producer.services;

/**
 * The Class VmDomBuilderException.
 */
public class VmDomBuilderException extends Exception {

    private static final long serialVersionUID = 7880111411330910306L;

    /**
     * Instantiates a new vm dom builder exception.
     *
     * @param message the message
     * @param cause the cause
     */
    public VmDomBuilderException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Instantiates a new vm dom builder exception.
     *
     * @param message the message
     */
    public VmDomBuilderException(String message) {
        super(message);
    }
}