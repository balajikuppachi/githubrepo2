package com.bala.vm.producer.services;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * The Class VTLIndentationGlobber.
 */
public class VTLIndentationGlobber extends FilterInputStream {
    
	private String buffer = "";

    private int bufpos = 0;

    /**
     * The Enum State.
     */
    protected enum State {
        defstate, hash, comment, directive, schmoo, eol, eof
    }

    private  State state = State.defstate;

    /**
     * Instantiates a new VTL indentation globber.
     *
     * @param is the is
     */
    public VTLIndentationGlobber(InputStream is) {
        super(is);
    }

    /**
     * Reads the next byte of data from this input stream. The value
     * byte is returned as an <code>int</code> in the range
     * <code>0</code> to <code>255</code>. If no byte is available
     * because the end of the stream has been reached, the value
     * <code>-1</code> is returned. This method blocks until input data
     * is available, the end of the stream is detected, or an exception
     * is thrown.
     * <p>
     * This method
     * simply performs <code>in.read()</code> and returns the result.
     *
     * @return     the next byte of data, or <code>-1</code> if the end of the
     *             stream is reached.
     * @exception  IOException  if an I/O error occurs.
     * @see        java.io.FilterInputStream#in
     */
    
    public int read() throws IOException {                  // NOSONAR
        while (true) {
            switch (state) {
                case defstate: {
                    int ch = in.read();
                    switch (ch) {
                        case (int) '#':
                            state = State.hash;
                            buffer = "";
                            bufpos = 0;
                            return ch;
                        case (int) ' ':
                        case (int) '\t':
                            buffer += (char) ch;
                            break;
                        case -1:
                            state = State.eof;
                            break;
                        default:
                            buffer += (char) ch;
                            state = State.schmoo;
                            break;
                    }
                    break;
                }
                case eol:
                    if (bufpos < buffer.length()) {
                        return (int) buffer.charAt(bufpos++);
                    }
                    else {
                        state = State.defstate;
                        buffer = "";
                        bufpos = 0;
                        return '\n';
                    }
                case eof:
                    if (bufpos < buffer.length()) {
                        return (int) buffer.charAt(bufpos++);
                    }
                    else {
                        return -1;
                    } 
                case hash: {
                    int ch = (int) in.read();
                    switch (ch) {
                        case (int) '#':
                            state = State.directive;
                            return ch;
                        case -1:
                            state = State.eof;
                            return -1;
                        default:
                            state = State.directive;
                           // buffer = "##";
                            return ch;
                    }
                }
                case directive: {
                    int ch = (int) in.read();
                    if (ch == (int) '\n') {
                        state = State.eol;
                        break;
                    } else if (ch == -1) {
                        state = State.eof;
                        break;
                    } else {
                        return ch;
                    }
                }
                case schmoo: {
                    int ch = (int) in.read();
                    if (ch == (int) '\n') {
                        state = State.eol;
                        break;
                    } else if (ch == -1) {
                        state = State.eof;
                        break;
                    } else {
                        buffer += (char) ch;
                        return (int) buffer.charAt(bufpos++);
                    }
                }
                
                default:
                	break;
            }
        }
    }

    /**
     * Reads up to <code>len</code> bytes of data from this input stream
     * into an array of bytes. If <code>len</code> is not zero, the method
     * blocks until some input is available; otherwise, no
     * bytes are read and <code>0</code> is returned.
     * <p>
     * This method simply performs <code>in.read(b, off, len)</code>
     * and returns the result.
     *
     * @param      b     the buffer into which the data is read.
     * @param      off   the start offset in the destination array <code>b</code>
     * @param      len   the maximum number of bytes read.
     * @return     the total number of bytes read into the buffer, or
     *             <code>-1</code> if there is no more data because the end of
     *             the stream has been reached.
     * @exception  NullPointerException If <code>b</code> is <code>null</code>.
     * @exception  IndexOutOfBoundsException If <code>off</code> is negative,
     * <code>len</code> is negative, or <code>len</code> is greater than
     * <code>b.length - off</code>
     * @exception  IOException  if an I/O error occurs.
     * @see        java.io.FilterInputStream#in
     */
    public int read(byte[] b, int off, int len) throws IOException {
        int i;
        int ok = 0;
        while (len-- > 0) {
            i = read();
            if (i == -1) {
                return (ok == 0) ? -1 : ok;
            }
            b[off++] = (byte) i;
            ok++;
        }
        return ok;
    }

    /**
     * Reads up to <code>byte.length</code> bytes of data from this
     * input stream into an array of bytes. This method blocks until some
     * input is available.
     * <p>
     * This method simply performs the call
     * <code>read(b, 0, b.length)</code> and returns
     * the  result. It is important that it does
     * <i>not</i> do <code>in.read(b)</code> instead;
     * certain subclasses of  <code>FilterInputStream</code>
     * depend on the implementation strategy actually
     * used.
     *
     * @param      b   the buffer into which the data is read.
     * @return     the total number of bytes read into the buffer, or
     *             <code>-1</code> if there is no more data because the end of
     *             the stream has been reached.
     * @exception  IOException  if an I/O error occurs.
     * @see        java.io.FilterInputStream#read(byte[], int, int)
     */
    
    public int read(byte[] b) throws IOException {
        return read(b, 0, b.length);
    }

    /**
     * Tests if this input stream supports the <code>mark</code>
     * and <code>reset</code> methods.
     * This method
     * simply performs <code>in.markSupported()</code>.
     *
     * @return  <code>true</code> if this stream type supports the
     *          <code>mark</code> and <code>reset</code> method;
     *          <code>false</code> otherwise.
     * @see     java.io.FilterInputStream#in
     * @see     java.io.InputStream#mark(int)
     * @see     java.io.InputStream#reset()
     */
    
    public boolean markSupported() {
        return false;
    }
}