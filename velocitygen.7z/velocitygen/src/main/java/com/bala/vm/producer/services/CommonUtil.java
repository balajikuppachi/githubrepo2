package com.bala.vm.producer.services;

import java.lang.reflect.Method;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;

public class CommonUtil {
	
	public static String getLastElement(String temp) {
		int i = temp.lastIndexOf("/");
		String lastValue = temp.substring(i+1);
		
		if(StringUtils.isNotBlank(lastValue) && lastValue.equalsIgnoreCase("value")){
			lastValue="";
		}
		return lastValue;
	}
	public static String getKeyword(String xpath){
		String formatterdXpath = xpath;
		if(StringUtils.contains(formatterdXpath, "|")){		 
			formatterdXpath = formatterdXpath.replaceAll("\\|", "");
		}
		if(StringUtils.contains(xpath, "'")){		 
			formatterdXpath = formatterdXpath.split("'")[1];
		}		
		return formatterdXpath;
	}
	
	/**
	 * @param xpath
	 * @return
	 */
	public static String replaceSlaceWithDot(FPMLXpath xpath) {
		return StringUtils.replace(xpath.getSourceXpath(), "/", ".");
	}


	/**
	 * @param xpath
	 * @return
	 */
	public static  boolean isDate(FPMLXpath xpath) {
		return StringUtils.contains(xpath.getDataFormat(), "XMLGregorianCalendar");
	}

	public static boolean isNumber(FPMLXpath xpath) {
		return StringUtils.contains(xpath.getDataFormat(), "java.math");
	}

	public static String concatedValue(String condition){
		ArrayList<String> allValue = new ArrayList<String>();
		String firstCondition = condition.split("\\|")[0];
		String secondCondition = condition.split("\\|")[1];
		if(StringUtils.contains(firstCondition, ":")){
			allValue.add(appendSingleQuote(firstCondition.split(":")[0]));
			allValue.add(appendSingleQuote(firstCondition.split(":")[1]));
		}
		if(StringUtils.contains(secondCondition, ":")){
			allValue.add(appendSingleQuote(secondCondition.split(":")[0]));
			allValue.add(appendSingleQuote(secondCondition.split(":")[1]));
		}
		
		return StringUtils.join(allValue, ",");
	}
	public static String getConditionalValueMap(String condition){
		String finalString = "#set ($mymap = {})";
			if(StringUtils.contains(condition, "|")){
				String[] individualCond = condition.split("\\|");				
				for(String enrichValue : individualCond){
					finalString = prepareMap(finalString, enrichValue);
				}				
			}else{
				finalString = prepareMap(finalString, condition);
			}
		return finalString;
	}
	/**
	 * @param finalString
	 * @param enrichValue
	 * @return
	 */
	public static String prepareMap(String finalString, String enrichValue) {
		finalString = finalString +"\n #set ($mymap =$mymap.put('"+enrichValue.split(":")[0]+"', '"+enrichValue.split(":")[1]+"'))";
		return finalString;
	}
	

		public static String appendSingleQuote(String input){
			return "'" + input + "'";
		}
		
		public static final String DOLLAR_SIGN="$";
		public static final String ROOT_CONTEXT_OBJ="reportingContext";
		public static final String SDR_CONTEXT_OBJ="reportingContext.sdrRequest";
		public static final String DOT=".";
		
		public static String appendSourceWithDtoObj(String xpath){
			if(StringUtils.isBlank(xpath)){
				return null;
			}
			if(xpath.startsWith("trade")){
				return getSdrContextWithDot()+xpath;	
			}else{
				return getRootContextWithDot()+xpath;
			}
				
		}
		
		public static String appendXpathWithDtoObjWithoutDot(String xpath){
			if(StringUtils.isBlank(xpath)){
				return null;
			}
			if(xpath.startsWith(".trade")){
				return getSdrContextWithoutDot()+xpath;	
			}else{
				return getRootContextWithoutDot()+xpath;
			}
		}
		
		public static String getSdrContextWithoutDot(){
			return DOLLAR_SIGN+SDR_CONTEXT_OBJ;
		}
		
		public static String getSdrContextWithDot(){
			return DOLLAR_SIGN+SDR_CONTEXT_OBJ+DOT;
		}
		
		public static String getRootContextWithoutDot(){
			return DOLLAR_SIGN+ROOT_CONTEXT_OBJ;
		}
		
		public static String getRootContextWithDot(){
			return DOLLAR_SIGN+ROOT_CONTEXT_OBJ+DOT;
		}

	    public static boolean isAttribute(String tagname) {
	        return tagname.startsWith("@");
	    }
	    
	    public static String extractEnumValue(String value, String dataType){
			Class<?> clss;
			
			try {
				clss = Class.forName(dataType.trim());
				
				if (dataType.contains("Enum"))
				{
					Object enumObj = getEnumValue(value, clss);					
					return enumObj.toString();
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			return value;
		}
	    
	    public static Object getEnumValue(Object value, Class<?> clss)
		{
			try 
			{
				Method method = clss.getDeclaredMethod("fromValue", String.class);
				value = method.invoke(null, value.toString());
				
			} 
			catch (Exception e) 
			{
				    Enum<?>[] enumValues = (Enum<?>[])clss.getEnumConstants();
					for (Enum<?> enuTocheck : enumValues) 
					{
						if(value!=null && enuTocheck!=null && enuTocheck.name().equalsIgnoreCase(value.toString()))
							return enuTocheck;
					}
			}
			

			return value;
		}
	    
	    public static boolean isEnum(String dataType){
			if (dataType.contains("Enum"))
			{						
				return true;
			}
					
			return false;
		}

	    
}
