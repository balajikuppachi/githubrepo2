package com.bala.vm.producer.services;

import java.io.PrintStream;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;


/**
 * The Class TemplatePrinter.
 */

public class TemplatePrinter {

    /**
     * Prints the.
     *
     * @param node the node
     * @param ps the ps
     * @param index the index
     */
    public void print(XNode node, PrintStream ps, int index) {
    	
        String indent = StringUtils.repeat(" ", index);
        if(node.getPreDirective()!=null && node.getPreDirective().size()>0) {
           
            for(String str : node.getPreDirective()) {
                ps.print(indent);
                ps.println(str);
            }
        }

        String nodeName = trimeBracke(node.getName());
        
        if(node.getValue() != null) {
            ps.print(indent);
            ps.print("<"+nodeName);
            printAttr(node, ps, indent);    
            ps.print(">");
            ps.print(String.valueOf(node.getValue()).trim());
            ps.println("</"+nodeName+">");
            
        } else if(node.getChild().isEmpty()) {
            if(node.getAttributes().isEmpty()) {
                if(node.isEmptyAllowed()) {
                    ps.print(indent);
                    ps.print("<"+nodeName);
                    ps.println("/>");
                }    
            } else {
                ps.print(indent);
                ps.print("<"+nodeName);
                printAttr(node, ps, indent);
                ps.println("/>");
            }
        } else {
            ps.print(indent);
            ps.print("<"+nodeName);
            printAttr(node, ps, indent);
            ps.println(">");
            for (XNode child : node.getChild()) {
                print(child, ps, index+5);
            }
            ps.print(indent);
            ps.println("</"+nodeName+">");
        }
        if(node.getPostDirective()!=null && node.getPostDirective().size()>0) {
         
            for(String str : node.getPostDirective()) {
                ps.print(indent);
                ps.println(str);
            }
        }
    }

    /**
     * Trime bracke.
     *
     * @param name the name
     * @return the string
     */
    private String trimeBracke(String name) {
        int index = name.indexOf("[");
        if(index == -1) {
        	return name;
        }
        return name.substring(0, index);
    }


    /**
     * Prints the attr.
     *
     * @param node the node
     * @param ps the ps
     * @param indent the indent
     */
    private void printAttr(XNode node, PrintStream ps, String indent) {
        for(Entry<String, Object> atr : node.getAttributes().entrySet()) {
            ps.print(" ");
            String pre = node.getPreDirectiveForAttr(atr.getKey());
            String post = node.getPostDirectiveForAttr(atr.getKey());

            if(StringUtils.isNotBlank(pre)) {
                ps.println(" ");
                ps.print(indent);
                ps.println(pre);
                ps.print(indent);
            } else {
                ps.print(" ");
            }
            
            ps.print(trimeBracke(String.valueOf(atr.getKey()).trim()));
            ps.print("=");
            ps.print("\"");
            ps.print(String.valueOf(atr.getValue()).trim());
            ps.print("\"");
            
            if(StringUtils.isNotBlank(post)) {
                ps.println();
                ps.println(post);
                ps.print(indent);
                
            }
        }
    }
}
