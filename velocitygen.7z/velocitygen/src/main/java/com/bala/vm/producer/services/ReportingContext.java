package com.bala.vm.producer.services;

import java.util.Date;

public class ReportingContext {
	
	private String messageId;
	private String sendBy;
	private String sendTo;
	private Date creationTimeStamp;
	private String expiryTimeStamp;
	private ImplementationSpecification implementationSpecification;
	
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public String getSendBy() {
		return sendBy;
	}
	public void setSendBy(String sendBy) {
		this.sendBy = sendBy;
	}
	public String getSendTo() {
		return sendTo;
	}
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}
	public Date getCreationTimeStamp() {
		return creationTimeStamp;
	}
	public void setCreationTimeStamp(Date creationTimeStamp) {
		this.creationTimeStamp = creationTimeStamp;
	}
	public String getExpiryTimeStamp() {
		return expiryTimeStamp;
	}
	public void setExpiryTimeStamp(String expiryTimeStamp) {
		this.expiryTimeStamp = expiryTimeStamp;
	}
	public ImplementationSpecification getImplementationSpecification() {
		return implementationSpecification;
	}
	public void setImplementationSpecification(ImplementationSpecification implementationSpecification) {
		this.implementationSpecification = implementationSpecification;
	}
	public ReportingContext(String messageId, String sendBy, String sendTo, Date creationTimeStamp,
			String expiryTimeStamp, ImplementationSpecification implementationSpecification) {
		super();
		this.messageId = messageId;
		this.sendBy = sendBy;
		this.sendTo = sendTo;
		this.creationTimeStamp = creationTimeStamp;
		this.expiryTimeStamp = expiryTimeStamp;
		this.implementationSpecification = implementationSpecification;
	}
	

	
}
