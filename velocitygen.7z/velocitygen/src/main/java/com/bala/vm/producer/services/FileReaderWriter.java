package com.bala.vm.producer.services;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.apache.velocity.runtime.RuntimeServices;
import org.apache.velocity.runtime.RuntimeSingleton;
import org.apache.velocity.runtime.parser.ParseException;
import org.apache.velocity.runtime.parser.node.SimpleNode;
import org.xml.sax.SAXException;

public class FileReaderWriter {

	public static void main(String[] args) throws Exception{
    

    TemplateDomBuilder domBuilder = new TemplateDomBuilder();
    // Generate DOM
    
	try {
		ExcelReader excelReader = new ExcelReader();
		
		ArrayList<FPMLXpath> headerXpathList = excelReader.getFPMLXpathFromExcel("Header.xls");
		ArrayList<FPMLXpath> bodyXpathList = excelReader.getFPMLXpathFromExcel(args[0]);
		//ArrayList<FPMLXpath> footerXpathList = excelReader.getFPMLXpathFromExcel("Footer.xls");
		
	    //Here first identify the root element like nonpublicexection,nonpublicexeption like waise 
		//and then based on append that rootelement at start of each xpath so there will be single child of one xml
		// like evertying should inside one element 
        
		ArrayList<FPMLXpath> allXpathList = new ArrayList<FPMLXpath>();
		allXpathList.addAll(headerXpathList);
		allXpathList.addAll(bodyXpathList);
		
		InputStream inputStream = writeToInputStream(domBuilder, allXpathList);
		
		String outFileName = "C:\\Users\\U478181\\WorkSpace\\RegRep\\regulatory_dev\\reg-reporting\\regulatory\\core\\"+args[1];
		writeToOutputFile(inputStream, outFileName);
		    
		    
	} catch (SAXException | IOException | ParserConfigurationException | VmDomBuilderException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
    
   
    
    
}


	/**
	 * @param inputStream
	 * @param outFileName
	 */
	public static void writeToOutputFile(InputStream inputStream, String outFileName) {
		File outputFile = new File(outFileName);
		System.out.println("Generating output : " + outputFile);
		try(FileOutputStream output = new FileOutputStream(outputFile)) { 
		    IOUtils.copy(inputStream, output);
		} catch(IOException | RuntimeException e1) {
		   
		}
	}


	/**
	 * @param domBuilder
	 * @param allXpathList
	 * @return
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws VmDomBuilderException
	 */
	public static InputStream writeToInputStream(TemplateDomBuilder domBuilder, ArrayList<FPMLXpath> allXpathList)
			throws SAXException, IOException, ParserConfigurationException, VmDomBuilderException {
		XNode node = domBuilder.generateDocumentFromXpath(allXpathList);
		 List<XNode> child2 = node.getChild();
		    
		    if(child2 == null ) {
		        System.out.println("Error while building dom. Getting No of element. ");           
		        
		    }
		    if(child2.size() > 1) {
		        System.out.println("Error while building dom. Getting lots of element. ");            
		    }
		    
		    XNode child = child2.get(0);
		    
		    InputStream inputStream = print(child);		    
		    inputStream = new VTLIndentationGlobber(inputStream);
		return inputStream;
	}

	 
    private static InputStream print(XNode child){
        ByteArrayOutputStream bytesStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(bytesStream);
        TemplatePrinter templatePrinter = new TemplatePrinter();
        printStream.println("#parse(\"macroVelocity.vm\")");
        printStream.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        templatePrinter.print(child, printStream, 0);
        InputStream inputStream = new ByteArrayInputStream(bytesStream.toByteArray());
        return inputStream;
    }
}
