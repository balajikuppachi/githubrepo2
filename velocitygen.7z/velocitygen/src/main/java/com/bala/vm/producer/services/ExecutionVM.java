package com.bala.vm.producer.services;

import java.io.StringWriter;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.tools.generic.MathTool;




public class ExecutionVM {



	public static void main(String[] args) throws Exception {




		/*STEP 1 :Create a VelocityTemplate Engine Object*/

		VelocityEngine velocityEngine = new VelocityEngine();

		/*STEP 2 :Initialise VelocityTemplate Engine */

		velocityEngine.init();

		Template template = velocityEngine.getTemplate("text.vm");


		ImplementationSpecification impl = new ImplementationSpecification();
		impl.setDate("12/12/12");
		impl.setName("RECEIVE");
		ReportingContext reportingContext = new ReportingContext("123444", "Hiten", "Bris", new Date(), "Today", impl);
		
		VelocityContext context = new VelocityContext();
		context.put("StringUtils", StringUtils.class);
		context.put("reportingContext", reportingContext);
		context.put("CommonUtil",CommonUtil.class);
		context.put("math",new MathTool());

		StringWriter writer = new StringWriter();

		/*STEP 5: Process the template and write the o/p to stream*/

		template.merge(context, writer);

		/*STEP 6: Show the output */

		System.out.println(writer);

	}

}
