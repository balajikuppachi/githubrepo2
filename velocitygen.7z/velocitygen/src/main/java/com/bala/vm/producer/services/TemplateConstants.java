package com.bala.vm.producer.services;

public class TemplateConstants {
    
    public static final String CANEMPTY = "CANEMPTY";

    public static final String NODIR = "NODIR";
}
