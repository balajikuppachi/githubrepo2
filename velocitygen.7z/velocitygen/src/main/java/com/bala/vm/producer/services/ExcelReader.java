package com.bala.vm.producer.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelReader {

private int counter=0;
private ArrayList<FPMLXpath> xpathList = new ArrayList<FPMLXpath>();

	public ArrayList<FPMLXpath> getFPMLXpathFromExcel(String filename) throws Exception {

		//String filename = "PET.xls";
		FileInputStream fis = null;

		try {

			fis = new FileInputStream(filename);
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			workbook.setMissingCellPolicy(HSSFRow.RETURN_NULL_AND_BLANK);
			getSheetBasedFPMLXpath(workbook,0);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		return xpathList;
	}
	
	public ArrayList<FPMLXpath> getFPMLXpathFromExcel(File file) throws Exception {

		//String filename = "PET.xls";
		FileInputStream fis = null;

		try {

			fis = new FileInputStream(file);
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			workbook.setMissingCellPolicy(HSSFRow.RETURN_NULL_AND_BLANK);
			for (int i=0; i<workbook.getNumberOfSheets(); i++) {
				getSheetBasedFPMLXpath(workbook,i);
			}			

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		return xpathList;
	}

	/**
	 * @param workbook
	 * @return 
	 */
	public ArrayList<FPMLXpath> getSheetBasedFPMLXpath(HSSFWorkbook workbook,int sheetId) {
		HSSFSheet sheet = workbook.getSheetAt(sheetId);
		Iterator rowIter = sheet.rowIterator(); 
		
		//int maxNumOfCells = sheet.getRow(0).get(); // The the maximum number of columns
		int maxNumOfCells = 13;
		Iterator rows = sheet.rowIterator();
		List<List<String>> sheetData = new ArrayList<List<String>>();
		int count = 0;
		    while (rows.hasNext()) {	            	
		        HSSFRow row = (HSSFRow) rows.next();
		        if(count==0){
		        	count++;
		        	continue;
		        }
		        Iterator cells = row.cellIterator();

		        List<String> data = new ArrayList<String>();
		        boolean atLeastOneNotNull = false;
		        for( int cellCounter = 0
		                ; cellCounter < maxNumOfCells
		                ; cellCounter ++){ // Loop through cells

		            HSSFCell cell;

		            if( row.getCell(cellCounter ) == null ){
		                cell = row.createCell(cellCounter);
		            } else {
		                cell = row.getCell(cellCounter);
		                if(skipRow(cell.getStringCellValue(),cell.getStringCellValue())){
		                	break;
		                }else if (StringUtils.isNotBlank(cell.getStringCellValue())){
		                	atLeastOneNotNull = true;
		                }
		            }
		            data.add(cell.getStringCellValue());
		        }
		        if(atLeastOneNotNull){
		        	sheetData.add(data);
		        }
		    }

		    xpathList = populateFPMLXpathWithExcelData(sheetData);
		    return xpathList;
	}
	
	public static ArrayList<FPMLXpath> populateFPMLXpathWithExcelData(List<List<String>> sheetData) {

        // LinkedHashMap<String, String> tableFields = new LinkedHashMap();
		ArrayList<FPMLXpath> fpmlList = new ArrayList<FPMLXpath>();
        for (int i = 0; i < sheetData.size(); i++) {
            List<String> list = sheetData.get(i);
            FPMLXpath fpmlXpath = new FPMLXpath();
			
            String strInFPMLSample = list.get(0);
            String strIsMapped = list.get(1);
            String strFPMLPath = list.get(2);
            String strSourcePath = list.get(4);
            String strIsHardCoded = list.get(5);
            String dataFormat = list.get(6);            
            String strCondition = list.get(7);
            String rootCondition = list.get(11);
            String preCondition = list.get(12);
            
            fpmlXpath.setFpmlXpath(getFormattedFpmlPath(strFPMLPath));
			fpmlXpath.setDataFormat(dataFormat);
			fpmlXpath.setRootCondition(rootCondition);
			fpmlXpath.setPreCondition(preCondition);
			fpmlXpath.setActualSourceXpath(strSourcePath);
			if(!skipRow(strInFPMLSample, strIsMapped)){
			
				if(StringUtils.isNotBlank(strIsHardCoded) && strIsHardCoded.equalsIgnoreCase("Y")){
					fpmlXpath.setConstant(true);	
				}else{
					fpmlXpath.setConstant(false);
				}				
				
				if(isArray(strSourcePath)){
					fpmlXpath.setArray(true);
					fpmlXpath.setSourceXpath(getKeyword(strSourcePath));
					fpmlXpath.setActualCondition(strCondition);
					fpmlXpath.setCondition(getFirstPath(strSourcePath,strCondition));					
				}else{
					fpmlXpath.setSourceXpath(getKeyword(strSourcePath));		
					fpmlXpath.setActualCondition(strCondition);
					fpmlXpath.setCondition(strCondition);
				}
				fpmlList.add(fpmlXpath);
			
			}
			
        }
        return fpmlList;
    }

	/**
	 * @param strInFPMLSample
	 * @param strIsMapped
	 * @return
	 */
	public static boolean skipRow(String strInFPMLSample, String strIsMapped) {
		return (strInFPMLSample!=null && strInFPMLSample.equalsIgnoreCase("A"))
				|| (strInFPMLSample!=null && strInFPMLSample.equalsIgnoreCase("AF"))
					|| (strIsMapped!=null && strIsMapped.equalsIgnoreCase("NM"));
	}
	
	public static boolean isArray(String xpath){
		if(xpath.contains("[name") && xpath.contains("]")){
			return true;
		}
		return false;
	}
	public static String getFirstPath(String xpath,String defaultCond){
		if(StringUtils.contains(xpath, "[")){
			String firstPath = xpath.split("\\[")[0];		
			
			if(firstPath.startsWith("/")){
				firstPath = firstPath.substring(1);
			}
			String enrichedFirstPath = firstPath.replace("/", ".");
			return enrichedFirstPath;
		}
		return defaultCond;
	}
	public static String getKeyword(String xpath){
		String formatterdXpath = xpath;
		if(StringUtils.contains(formatterdXpath, "|")){		 
			formatterdXpath = formatterdXpath.replaceAll("\\|", "");
		}
		if(StringUtils.contains(xpath, "'")){		 
			formatterdXpath = formatterdXpath.split("'")[1];
		}		
		if(StringUtils.contains(formatterdXpath, "leg[")){
			formatterdXpath = reduceOnePos(formatterdXpath);
		  }
		return formatterdXpath;
	}
	public static String getFormattedFpmlPath(String xpath){
		if(StringUtils.endsWith(xpath, "/value") && !StringUtils.contains(xpath, "quote/value")){		 // this is patch for quote value as in that case value is element inside quote
			xpath =  xpath.split("/value")[0];
		}
		return "/$rootObject"+StringUtils.replace(xpath, "/trade/product/", "/trade/$fpmlProductType/");
	}
	private static String reduceOnePos(String arr){	  
	  String unmodifiedString = arr.split("leg\\[")[1];
	  	int i = Integer.valueOf(unmodifiedString.split("\\]")[0]);
	  	if(i > 0 ){
	  		String firstString = arr.split("leg\\[")[0];
	  		String modifiedString = "leg[" + --i + "]";
	  		String lastString =unmodifiedString.split("\\]")[1];
		  	return firstString+modifiedString+lastString;
	  	}		  	
	  return arr;
}
	/*public static void main(String args[]){
		
		String temp = "/trade/tradeDetail/tradeParties/party[partyAttributes/attribute[name='ProcessingOrg']]/designation";
		temp = "/trade/tradeDetail/product/keywords/keyword[name='wfPartySchema']/value";
		
		String lastElement = getLastElement(temp);
		String comparisionValue = getKeyword(temp);		
		
		String[] arr = StringUtils.split(temp,"\\[");
		ArrayList<String> xpath = new ArrayList<>();
		int count=0;
		String temp1 = "$reportingContext";
		String firstElement = null;
		for(String x : arr){
			if(!x.contains("'")){
				if(count==0){
					firstElement = temp1+StringUtils.replace(x,"/",".");
				}
				count++;
				String varname = "Obj"+count;	
				if(x.startsWith("/")){
					x = x.substring(1);
				}				
				String test = "#foreach ($"+varname + " in "+ firstElement+ ")";
				temp1 = varname;
				xpath.add(test);
			}
		}
		String finalString = StringUtils.join(xpath,"\n");
		finalString = finalString + "#if($"+temp1+".name=='"+comparisionValue+"')";
		finalString = finalString + "#set($setObj = $"+temp1+".value)";
		String finalObject = null;
		if(xpath.size()>1){
			String tempobj = firstElement+"[$setObj]"+"."+lastElement;
			finalObject = "#set($setFinalObj ="+tempobj+")"; 	
		}else{
			finalObject = "#set($setFinalObj = $setObj)";
		}
		
		finalString = finalString + "#end";
		finalString = finalString + "#end";
		System.out.println(finalString);
		System.out.println(finalObject);
	}*/

	/**
	 * @param temp
	 */
	public static String getLastElement(String temp) {
		int i = temp.lastIndexOf("/");
		String lastValue = temp.substring(i+1);
		
		if(StringUtils.isNotBlank(lastValue) && lastValue.equalsIgnoreCase("value")){
			lastValue="";
		}
		return lastValue;
	}
}

