package com.bala.vm.producer.services;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.StringUtils;
import org.xml.sax.SAXException;

/**
 * This class will build Velocity template DOM.
 * 
 * @author Hitendra Chopra
 */

public class TemplateDomBuilder {


	/**
	 * Generate DOM by given list of xpath.
	 *
	 * @param map the map
	 * @return the x node
	 * @throws SAXException the SAX exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ParserConfigurationException the parser configuration exception
	 * @throws VmDomBuilderException the vm dom builder exception
	 */

	public XNode generateDocumentFromXpath(ArrayList<FPMLXpath> map) throws SAXException, IOException, ParserConfigurationException, VmDomBuilderException {

		XNode documentNode = new XNode("root");
		generateDocumentFromXpath(map, documentNode);
		return documentNode;
	}


	private void generateDocumentFromXpath(ArrayList<FPMLXpath> listOfXpath, XNode documentNode) throws VmDomBuilderException {    // NOSONAR
		for (FPMLXpath xpath : listOfXpath) {
			
			String key = xpath.getActualSourceXpath();
			if(StringUtils.isBlank(key)){
				continue;
			}	
			
			Object[] result = documentNode.getXNode(xpath);
			
			XNode lastNodeOfXpath = (XNode) result[0];
			Boolean isAttribute = (Boolean) result[1];

			if (isAttribute) {
				setXnodeForAttribute(xpath, result, lastNodeOfXpath);
			}else{
				setElementXnode(xpath, lastNodeOfXpath);				
			}

		}

	}


	/**
	 * @param xpath
	 * @param lastNodeOfXpath
	 */
	public void setElementXnode(FPMLXpath xpath, XNode lastNodeOfXpath) {
		if(xpath.isConstant()){
			lastNodeOfXpath.setValue(xpath.getSourceXpath());	
		}else if (xpath.isArray()) {   
					
			setXNodeForArray(xpath,lastNodeOfXpath);			
		 
		}else{
			if(CommonUtil.isDate(xpath)){
				setValueForDateObj(xpath, lastNodeOfXpath);
			}else if(CommonUtil.isNumber(xpath)){
				String modObj = getReplacedDotValue(xpath);
				setPrePostDirForNotNullCheck(modObj,lastNodeOfXpath);
				lastNodeOfXpath.setValue("$math.abs("+modObj+")");
			}else if(StringUtils.contains(xpath.getCondition(), ":")){
				String concatedValue = CommonUtil.getConditionalValueMap(xpath.getCondition());
				
				String setVariable = "#set ($tempObj = " + getReplacedDotValue(xpath)+")";
				String finalPredirective = getMacroFunction("$tempObj",xpath);
				
				lastNodeOfXpath.setPreDirective(setVariable);
				lastNodeOfXpath.setPreDirective(concatedValue);
				setPrePostDirForNotNullCheck("$tempObj",lastNodeOfXpath);
				lastNodeOfXpath.setValue(finalPredirective);
			}else{
				String modObj = getReplacedDotValue(xpath);
				setPrePostDirForNotNullCheck(modObj,lastNodeOfXpath);
				lastNodeOfXpath.setValue(getEnumAppendedObj(modObj,xpath));
			}
		}
	}

	public void setPrePostDirForNotNullCheck(String objValue, XNode lastNodeOfXpath) {
		lastNodeOfXpath.setPreDirective("#if("+objValue+")");
		lastNodeOfXpath.setPostDirective("#end");
	}
	/**
	 * @param xpath
	 * @param lastNodeOfXpath
	 */
	public void setValueForDateObj(FPMLXpath xpath, XNode lastNodeOfXpath) {
		String defaultDateFormat = xpath.getCondition();
		String modObj = getReplacedDotValue(xpath);
		setPrePostDirForNotNullCheck(modObj,lastNodeOfXpath);
		if(StringUtils.isNotBlank(defaultDateFormat)){
			lastNodeOfXpath.setValue("$CalendarUtils.xmlGregCalToCustomFormat("+modObj+",\""+defaultDateFormat+"\")");
		}else{
			lastNodeOfXpath.setValue("$CalendarUtils.xmlGregCalToCustomFormat("+modObj+",null)");
		}
	}


	/**
	 * @param xpath
	 * @return
	 */
	private String getReplacedDotValue(FPMLXpath xpath) {
		return CommonUtil.appendXpathWithDtoObjWithoutDot(CommonUtil.replaceSlaceWithDot(xpath));
	}


	/**
	 * @param concatedValue
	 * @return
	 */
	public String getMacroFunction(String inputObj,FPMLXpath xpath) {		
		
		inputObj = getEnumAppendedObj(inputObj, xpath);			
		return "$StringUtils.trim(\"#condOp("+inputObj+",$mymap)\")";
	}


	/**
	 * @param inputObj
	 * @param xpath
	 * @return
	 */
	public String getEnumAppendedObj(String inputObj, FPMLXpath xpath) {
		if(CommonUtil.isEnum(xpath.getDataFormat())){
			return "$GeneralUtils.extractEnumValue("+inputObj+",'"+xpath.getDataFormat()+"')";
		}
		return inputObj;
	}

	public String setXNodeForArray(FPMLXpath fpmlXpath,XNode lastNodeOfXpath){
		String sourceXpath  = fpmlXpath.getActualSourceXpath();
		String lastElement = CommonUtil.getLastElement(sourceXpath);
		String comparisionValue = CommonUtil.getKeyword(sourceXpath);	
		
		String[] arr = StringUtils.split(sourceXpath,"\\[");
		ArrayList<String> xpath = new ArrayList<>(); 
		int count=0;
		String context = CommonUtil.getSdrContextWithDot();
		String firstElement = null;
		String rootObj  = null;
		for(String x : arr){
			if(!x.contains("'")){
				if(x.startsWith("/")){
					x = x.substring(1);
				}
				count++;
				String varname = "Obj"+count;
				if(count==1){
					firstElement = context+StringUtils.replace(x,"/",".");
					rootObj =varname; 
				}
					
							
				String test = "#foreach ($"+varname + " in "+ context+StringUtils.replace(x,"/",".")+ ")";
				context = "$"+varname+".";
				xpath.add(test);
			}
		}
		String finalString = StringUtils.join(xpath,"\n");
		lastNodeOfXpath.setPreDirective(finalString);
		
		String strSetObj = "$setObj"+comparisionValue+lastElement;
		lastNodeOfXpath.setPreDirective("#if($"+context+"name=='"+comparisionValue+"')");
		
		String finalObject = null;
		String strSetFinalObj =null;
		
		
		
		if(xpath.size()>1){
			strSetFinalObj = "$"+rootObj+"."+lastElement;
			//strVal = strVal+lastElement;			
			lastNodeOfXpath.setPostDirective("#end");
		}else{
			strSetFinalObj = "$setFinalObj"+comparisionValue+lastElement;			
			lastNodeOfXpath.setPreDirective("#set("+strSetObj+"= "+context+"value)");
			finalObject = "#set("+strSetFinalObj+" = "+strSetObj+")";
			lastNodeOfXpath.setPreDirective(finalObject);
		}
		
		setPrePostDirForNotNullCheck(strSetFinalObj,lastNodeOfXpath);
		
		if(StringUtils.isNotBlank(fpmlXpath.getActualCondition())){
			String concatedValue = CommonUtil.getConditionalValueMap(fpmlXpath.getActualCondition());
			strSetFinalObj = getMacroFunction(strSetFinalObj,fpmlXpath);
			lastNodeOfXpath.setPreDirective(concatedValue);
		}
		
		lastNodeOfXpath.setValue(strSetFinalObj);	
		lastNodeOfXpath.setPostDirective("#end");		    
		lastNodeOfXpath.setPostDirective("#end");	    
	    
		return finalString;
	}

	
	
	/**
	 * @param xpath
	 * @param result
	 * @param lastNodeOfXpath
	 */
	public void setXnodeForAttribute(FPMLXpath xpath, Object[] result, XNode lastNodeOfXpath) {
		String name = (String) result[2];
		if(xpath.isConstant()){//here in else there should not be any value or it should be some dynamic value
			lastNodeOfXpath.putAttribute(name, xpath.getSourceXpath());	
		}else if (xpath.isArray()) {                    
		    String varName = "arrKeyObj";
		    lastNodeOfXpath.setPreDirective("#foreach ($"
		            + varName
		            + " in "
		            + CommonUtil.appendSourceWithDtoObj(xpath.getCondition())
		            + ")");
		    
		    lastNodeOfXpath.setPreDirective("#if($arrKeyObj.name=='"+xpath.getSourceXpath()+"')");		    
		    String setVariable = "#set ($arrObj = $arrKeyObj.value)";					
			lastNodeOfXpath.setPreDirective(setVariable);		
			lastNodeOfXpath.putAttribute(name, "$arrObj");	    
		    lastNodeOfXpath.setPostDirective("#end");		    
		    lastNodeOfXpath.setPostDirective("#end");
		    
		}else if(StringUtils.isNotBlank(xpath.getCondition())){
			//String includeFIle = "#parse(\"macroVelocity.vm\")";
			String setVariable = "#set ($tempObj = " + getReplacedDotValue(xpath)+")";
			String concatedValue = CommonUtil.getConditionalValueMap(xpath.getCondition());
			String finalPredirective = getMacroFunction("$tempObj",xpath);
			
			//lastNodeOfXpath.setPreDirective(includeFIle);
			lastNodeOfXpath.setPreDirective(setVariable);
			lastNodeOfXpath.setPreDirective(concatedValue);
			lastNodeOfXpath.putAttribute(name,finalPredirective);
		}
		else if(StringUtils.isNotBlank(xpath.getSourceXpath()) && !xpath.getSourceXpath().equals("/")){
			lastNodeOfXpath.putAttribute(name, getReplacedDotValue(xpath));
		}
	}
	
	
	/**
	 * Generate DOM in context of given documentNode.
	 *
	 * @param listOfXpath the list of xpath
	 * @param documentNode the document node
	 * @throws VmDomBuilderException the vm dom builder exception
	 */
	


}
