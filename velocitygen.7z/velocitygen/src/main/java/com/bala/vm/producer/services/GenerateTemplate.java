package com.bala.vm.producer.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;

public class GenerateTemplate {
	
	private static String outputFolder = "C:\\Users\\U478181\\WorkSpace\\Spring4\\regulatory_spring4_dev\\regulatory\\core\\outputVM\\";
	//private static String xlsFileLocation = "C:\\Users\\U478181\\WorkSpace\\RegRep\\regulatory_dev\\reg-reporting\\regulatory\\core\\src\\main\\resources\\com\\balaji\\regulatory\\fpml\\mappers";
	private static String xlsFileLocation = "C:\\Users\\U478181\\WorkSpace\\Spring4\\regulatory_spring4_dev\\regulatory\\velocitygen\\excel\\ForeignExchange\\FxSingleLeg\\";
	
	@Value("${regRep.request.vmfile.path}")
	private static String outputFileFolder;
	
	public String outputFilePath;
	
	
	
    public String getOutputFilePath() {
		return outputFilePath;
	}

	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}

	public static void main(String[] args) {
    	
		System.out.println(new GenerateTemplate().getOutputFilePath());
        File dir = new File(xlsFileLocation);
        listFileNamesWithDirectory(dir);
    }

    private static void listFileNamesWithDirectory(File parentDirectory) {
        /*if(foundFolder) {
            return;
        }*/
        File[] files = parentDirectory.listFiles();
        String parentDirName = parentDirectory.getName();
        ExcelReader excelReader = new ExcelReader();
        ArrayList<FPMLXpath> headerXpathList = null;
		try {
			headerXpathList = excelReader.getFPMLXpathFromExcel(new File("Header.xls"));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        for (File file : files) {
        	
            if (file.isFile()) {
        		
        		try {

					FileInputStream fis = null;					
					try {

						fis = new FileInputStream(file);
						HSSFWorkbook workbook = new HSSFWorkbook(fis);
						workbook.setMissingCellPolicy(HSSFRow.RETURN_NULL_AND_BLANK);
						for (int i=0; i<workbook.getNumberOfSheets(); i++) {
							
							ArrayList<FPMLXpath> allXpathList = new ArrayList<FPMLXpath>();
							ArrayList<FPMLXpath> bodyXpathList = new ArrayList<FPMLXpath>();
							bodyXpathList = excelReader.getSheetBasedFPMLXpath(workbook,i);
							
							allXpathList.addAll(headerXpathList);
							allXpathList.addAll(bodyXpathList);
							
							TemplateDomBuilder domBuilder = new TemplateDomBuilder();
							InputStream inputStream = FileReaderWriter.writeToInputStream(domBuilder, allXpathList);
							
							
							String outFileName = outputFolder +parentDirName + "_" + FilenameUtils.removeExtension(file.getName()) + "_" + workbook.getSheetName(i)+".vm";
							System.out.println(outFileName);
							FileReaderWriter.writeToOutputFile(inputStream, outFileName);
							
						}			

					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						if (fis != null) {
							fis.close();
						}
					}
					
					//DomTest.writeToInputStream(domBuilder, allXpathList);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }           
            if(file.isDirectory()) {
            	listFileNamesWithDirectory(file);
            }
        }
    }


}
