package com.bala.vm.producer.services;

public class FPMLXpath {

	private String fpmlXpath;
	private boolean isConstant;
	private String sourceXpath;
	private String dataFormat;
	private boolean isArray;
	private String condition;
	private String rootCondition;
	private String preCondition;
	private String actualSourceXpath;
	private String actualCondition;

	public String getFpmlXpath() {
		return fpmlXpath;
	}
	public void setFpmlXpath(String fpmlXpath) {
		this.fpmlXpath = fpmlXpath;
	}
	public boolean isConstant() {
		return isConstant;
	}
	public void setConstant(boolean isConstant) {
		this.isConstant = isConstant;
	}
	public String getSourceXpath() {
		return sourceXpath;
	}
	public void setSourceXpath(String sourceXpath) {
		this.sourceXpath = sourceXpath;
	}
	public String getDataFormat() {
		return dataFormat;
	}
	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}
	public boolean isArray() {
		return isArray;
	}
	public void setArray(boolean isArray) {
		this.isArray = isArray;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getRootCondition() {
		return rootCondition;
	}
	public void setRootCondition(String rootCondition) {
		this.rootCondition = rootCondition;
	}
	public String getPreCondition() {
		return preCondition;
	}
	public void setPreCondition(String preCondition) {
		this.preCondition = preCondition;
	}
	public String getActualSourceXpath() {
		return actualSourceXpath;
	}
	public void setActualSourceXpath(String actualSourceXpath) {
		this.actualSourceXpath = actualSourceXpath;
	}
	public String getActualCondition() {
		return actualCondition;
	}
	public void setActualCondition(String actualCondition) {
		this.actualCondition = actualCondition;
	}
	
	
	
}
