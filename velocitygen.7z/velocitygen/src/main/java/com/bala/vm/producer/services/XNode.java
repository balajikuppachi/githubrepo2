package com.bala.vm.producer.services;

import static com.bala.vm.producer.services.TemplateConstants.CANEMPTY;
import static com.bala.vm.producer.services.TemplateConstants.NODIR;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

/**
 * Simple XML Node meant to generate JSP or Velocity template.
 * 
 * @author Hitendra Chopra
 *
 */
public class XNode {
	
    private static final boolean ISEMPTYALLOWED = true;

    /** 
     * Name of this element
     */
    private String name;

    /**
     * Value of this element. This can be null;
     */
    private Object value;

    /**
     * Parent Node. If this is the root node then it will null;
     */
    private XNode parent;

    /**
     * Attributes for this element
     */
    private HashMap<String, Object> attribute = new HashMap<String, Object>();

    /**
     * Children of this node
     */
    private ArrayList<XNode> child = new ArrayList<XNode>();

    /**
     * Precondition before this element. Generally used to start any programming block for loop or branch.
     */
    private List<String> preDirective = new ArrayList<String>();

    /**
     * Post condition before this element.  Generally used to end any programming block.
     */
    private List<String> postDirective = new ArrayList<String>();;

    /**
     * Pre condition for various attributes. Generally used to start any programming block for loop or branch.
     */
    private HashMap<String, String> atrributePreCondition = new HashMap<String, String>();

    /**
     * Post condition for various attribute. Generally used to end any programming block.
     */
    private HashMap<String, String> attributePostCondition = new HashMap<String, String>();

    /**
     * Instantiates a new x node.
     *
     * @param tagname the tagname
     */
    public XNode(String tagname) {
        this.name = tagname;
    }

    /**
     * Is empty element without any attribute and value should allowed
     * 
     * @return true if condition satisfy
     */
    public boolean isEmptyAllowed() {
        return ISEMPTYALLOWED;
    }
    
    /**
     * Gets the post directive.
     *
     * @return the post directive
     */
    public List<String> getPostDirective() {
        return postDirective;
    }

    /**
     * Gets the pre directive.
     *
     * @return the pre directive
     */
    public List<String> getPreDirective() {
        return preDirective;
    }

    /**
     * Will not set post directive if this already non blank directive is exist.
     *
     * @param postDirective the new post directive
     */
    public void setPostDirective(String postDirective) {
        if(isInvalidDirective(postDirective)) {
            return;
        }
        this.postDirective.add(postDirective);
    }

    /**
     * Will not set post directive if this already non blank directive is exist.
     *
     * @param preDirective the new pre directive
     */
    public void setPreDirective(String preDirective) {
        if(isInvalidDirective(preDirective)) {
            return;
        }
        this.preDirective.add(preDirective);
    }

    /**
     * Overwrite existing post directing if exist.
     *
     * @param name2 the name2
     * @param postDirective the post directive
     */
    public void putPost(String name2, String postDirective) {
        if(isInvalidDirective(postDirective)) {
            return;
        }

        
        attributePostCondition.put(name2, postDirective);
    }

    /**
     * Overwrite existing pre directing if exist.
     *
     * @param name2 the name2
     * @param preDirective the pre directive
     */
    public void putPre(String name2, String preDirective) {
        if(isInvalidDirective(preDirective)) {
            return;
        }

        atrributePreCondition.put(name2, preDirective);
    }

    /**
     * Checks if is invalid directive.
     *
     * @param postDirective the post directive
     * @return true, if is invalid directive
     */
    private boolean isInvalidDirective(String postDirective) {
        return StringUtils.isBlank(postDirective) || NODIR.equals(postDirective) || CANEMPTY.equals(postDirective);
    }

    /**
     * Get child at given index.
     *
     * @param index the index
     * @return the x node
     */
    public XNode get(int index) {
        return child.get(index);
    }
    
    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Object getValue() {
        return value;
    }
    
    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Object value) {
        this.value = value;
    }
    
    /**
     * Gets the parent.
     *
     * @return the parent
     */
    public XNode getParent() {
        return parent;
    }

    /**
     * Size.
     *
     * @return the int
     */
    public int size() {
        return child.size();
    }

    /**
     * check if any node exist with given name.
     *
     * @param name the name
     * @return the x node
     */
    public XNode contains(String name) {
        if (child == null || child.isEmpty()) {
            return null;
        }
        for (XNode iterableElement : child) {
            if (iterableElement.name.equals(name)) {
                return iterableElement;
            }
        }
        return null;
    }

    /**
     * Put attribute.
     *
     * @param tagname the tagname
     * @param value2 the value2
     */
    public void putAttribute(String tagname, Object value2) {
        attribute.put(tagname, value2);
    }

    /**
     * Add child node.
     *
     * @param contains the contains
     */
    public void add(XNode contains) {
        contains.parent = this;
        child.add(contains);
    }

    /**
     * Get pre-directive for given attribute name.
     *
     * @param key the key
     * @return the pre directive for attr
     */
    public String getPreDirectiveForAttr(String key) {
        return atrributePreCondition.get(key);
    }

    /**
     * Get post directive for given attribute name.
     *
     * @param key the key
     * @return the post directive for attr
     */
    public String getPostDirectiveForAttr(String key) {
        return attributePostCondition.get(key);
    }

    /**
     * Retrieve all children.
     *
     * @return the child
     */
    public List<XNode> getChild() {
        return child;
    }

    /**
     * Retrieve all attributes.
     *
     * @return the attributes
     */
    public HashMap<String, Object> getAttributes() {
        return attribute;
    }
    
    /**
     * Search last node for given xpath in context of this node.
     *
     * @param xpath the xpath
     * @return Array[], 1: Last node of xpath, 2: xpath for attribute, 3: if attribute or element name of last node.
     */
    public Object[] getXNode(FPMLXpath xpath) {
    	String key = xpath.getFpmlXpath();
        String[] xpathElements = StringUtils.split(key, '/');
        String rootCondition = xpath.getRootCondition();
        String currentElementName = xpathElements[0].trim();
        XNode currentNode = contains(currentElementName);
        if (currentNode == null) {
            currentNode = new XNode(currentElementName);
            add(currentNode);
        }
        boolean currentXpath = true;
        boolean isAttribute = false;
        for (int i = 1; i < xpathElements.length; i++) {
            currentElementName = xpathElements[i].trim();
            if (CommonUtil.isAttribute(currentElementName)) {
                currentElementName = currentElementName.substring(1);
                isAttribute = true;
                break;
            } else {
                XNode foundNode = currentNode.contains(currentElementName);
                if (foundNode == null) {
                	
                    foundNode = new XNode(currentElementName);
                    if(StringUtils.isNotBlank(rootCondition) && currentXpath){
                    	if(ExcelReader.isArray(rootCondition)){
	                    	String varName = "Obj";
	                    	foundNode.setPreDirective("#foreach ($"
	                                + varName
	                                + " in "
	                                + CommonUtil.appendXpathWithDtoObjWithoutDot(StringUtils.replace(ExcelReader.getFirstPath(rootCondition,null), "/", "."))
	                                + ")");
	                        
	                    	foundNode.setPreDirective("#if($Obj.name=='"+ExcelReader.getKeyword(rootCondition)+"')");
	                    	foundNode.setPreDirective("if($Obj.value)");
	                    	surrondPreCondition(xpath, foundNode,"$Obj.value");
	                    	foundNode.setPostDirective("#end");
	                    	foundNode.setPostDirective("#end");
                    	}else{
                    			surrondPreCondition(xpath, foundNode,CommonUtil.appendXpathWithDtoObjWithoutDot(StringUtils.replace(xpath.getRootCondition(), "/", "."))); 
                    	}
                    	//foundNode.setPostDirective("#end");
                    	currentXpath = false;
                    }
                    currentNode.add(foundNode);
                }
                currentNode = foundNode;
            }
        }
        return new Object[] {currentNode, isAttribute, currentElementName};
    }

	private void surrondPreCondition(FPMLXpath xpath, XNode foundNode,String objValue) {
		if(StringUtils.isNotEmpty(xpath.getPreCondition())){
			String concatedValue = concatedPreCondValue(xpath.getPreCondition());
			String varName = "#set($arr = ["+concatedValue+"])";
			foundNode.setPreDirective(varName);
			foundNode.setPreDirective("#if($arr.size() > 0)");
			foundNode.setPreDirective("#foreach($arrObj in $arr)");
			foundNode.setPreDirective("#if("+objValue+" == $arrObj)");
			foundNode.setPostDirective("#end");
			foundNode.setPostDirective("#end");
			foundNode.setPostDirective("#end");
		}else{
			foundNode.setPreDirective("#if("+objValue+")");
			foundNode.setPostDirective("#end");
		}
	}
    
    private String concatedPreCondValue(String condition){		
		if(StringUtils.contains(condition, ":")){
	    	String firstCondition = condition.split(":")[0];
			ArrayList<String> strObjList = new ArrayList<String>();
			if(StringUtils.contains(firstCondition, ",")){
				String[] str = StringUtils.split(firstCondition,",");			
				for(String obj : str){
					strObjList.add(CommonUtil.appendSingleQuote(obj));	
				}
			}
			return StringUtils.join(strObjList, ",");
		}
		return condition;		
    }   
    
   
   
}