package com.bala.vm.producer.services;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelReader_back {

private int counter=0;
private ArrayList<FPMLXpath> xpathList = new ArrayList<FPMLXpath>();

	public ArrayList<FPMLXpath> getFPMLXpathFromExcel() throws Exception {

		String filename = "PET.xls";
		FileInputStream fis = null;

		try {

			fis = new FileInputStream(filename);
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			workbook.setMissingCellPolicy(HSSFRow.RETURN_NULL_AND_BLANK);
			HSSFSheet sheet = workbook.getSheetAt(0);
			
			Iterator rowIter = sheet.rowIterator(); 
			
			int maxNumOfCells = sheet.getRow(0).getLastCellNum(); // The the maximum number of columns
            Iterator rows = sheet.rowIterator();
            List<List<String>> sheetData = new ArrayList<List<String>>();
	            while (rows.hasNext()) {
	                HSSFRow row = (HSSFRow) rows.next();
	                Iterator cells = row.cellIterator();
	
	                List<String> data = new ArrayList<String>();
	                for( int cellCounter = 0
	                        ; cellCounter < maxNumOfCells
	                        ; cellCounter ++){ // Loop through cells
	
	                    HSSFCell cell;
	
	                    if( row.getCell(cellCounter ) == null ){
	                        cell = row.createCell(cellCounter);
	                    } else {
	                        cell = row.getCell(cellCounter);
	                    }
	
	                    data.add(cell.getStringCellValue());
	
	                }
	                sheetData.add(data);
	            }

	            xpathList = populateFPMLXpathWithExcelData(sheetData);

			/*while(rowIter.hasNext()){
				HSSFRow myRow = (HSSFRow) rowIter.next();
				Iterator cellIter = myRow.cellIterator();
				Vector<String> cellStoreVector=new Vector<String>();
				while(cellIter.hasNext()){
					HSSFCell myCell = (HSSFCell) cellIter.next();
					String cellvalue = myCell.getStringCellValue();
					cellStoreVector.addElement(cellvalue);
				}
				

				int i = 0;
				String firstcolumnValue = cellStoreVector.get(i).toString();
				String secondColumnValue = cellStoreVector.get(i+1).toString();
				String thirdcolumnValue = cellStoreVector.get(i+2).toString();
				String fourthcolumnValue = cellStoreVector.get(i+3).toString();
			
								
				FPMLXpath fpmlXpath = new FPMLXpath();
				fpmlXpath.setFpmlXpath(firstcolumnValue);
				fpmlXpath.setSourceXpath(secondColumnValue);
				if(StringUtils.isNotBlank(thirdcolumnValue) && thirdcolumnValue.equalsIgnoreCase("Y")){
					fpmlXpath.setConstant(true);	
				}else{
					fpmlXpath.setConstant(false);
				}				
				fpmlXpath.setDataFormat(fourthcolumnValue);
				
				counter++;
				xpathList.add(fpmlXpath);
				System.out.println(counter + "." + firstcolumnValue);
				
				
			}*/
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		return xpathList;
	}
	
	public static ArrayList<FPMLXpath> populateFPMLXpathWithExcelData(List<List<String>> sheetData) {

        // LinkedHashMap<String, String> tableFields = new LinkedHashMap();
		ArrayList<FPMLXpath> fpmlList = new ArrayList<FPMLXpath>();
        for (int i = 0; i < sheetData.size(); i++) {
            List<String> list = sheetData.get(i);
            FPMLXpath fpmlXpath = new FPMLXpath();
			
            fpmlXpath.setFpmlXpath(list.get(0));
				
			String thirdcolumnValue = list.get(2);
			String dataFormat = list.get(3);
			fpmlXpath.setDataFormat(dataFormat);
			
			
			if(StringUtils.isNotBlank(thirdcolumnValue) && thirdcolumnValue.equalsIgnoreCase("Y")){
				fpmlXpath.setConstant(true);	
			}else{
				fpmlXpath.setConstant(false);
			}				
			
			if(dataFormat.equalsIgnoreCase("java.lang.Array")){
				fpmlXpath.setArray(true);
				fpmlXpath.setSourceXpath(getKeyword(list.get(1)));
				fpmlXpath.setCondition(getFirstPath(list.get(1),list.get(4)));
			}else{
				fpmlXpath.setSourceXpath(list.get(1));		
				fpmlXpath.setCondition(list.get(4));
			}
			fpmlList.add(fpmlXpath);
			
			
        }
        return fpmlList;
    }
	
	private static String getFirstPath(String xpath,String defaultCond){
		if(StringUtils.contains(xpath, "[")){
			String firstPath = xpath.split("\\[")[0];		
			
			if(firstPath.startsWith("/")){
				firstPath = firstPath.substring(1);
			}
			String enrichedFirstPath = firstPath.replace("/", ".");
			return enrichedFirstPath;
		}
		return defaultCond;
	}
	private static String getKeyword(String xpath){
		if(StringUtils.contains(xpath, "'")){		 
			return xpath.split("'")[1];
		}
		return xpath;
	}
}

