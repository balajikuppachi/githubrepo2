package com.keylesson.hello;

import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.xembly.Directives;
import org.xembly.Xembler;
public class XemblyExample {
  public static void main(String[] args) throws Exception {
   /* String[] names = new String[] {
      "Jeffrey Lebowski",
      "Walter Sobchak",
      "Theodore Donald 'Donny' Kerabatsos",
    };
    Directives directives = new Directives().add("actors");
    for (String name : names) {
      directives.add("actor").set(name).up();
    }
    System.out.println(new Xembler(directives).xml());*/
    
    /*String xml = new Xembler(
    		   new Directives().add("employees").xpath("/employees").add("employee").up().addIf("name")
    		 ).xml();
    System.out.println(xml);
    
    String[] xpaths = new String[]{"/header/messageId/@messageIdScheme",
    								"/header/messageId/value",
    								"/header/sentBy/@messageAddressScheme",
    								"/header/sentBy/value",
    								"/header/sendTo/value",
    								"/header/creationTimestamp",
    								"/header/implementationSpecification/version/@implementationSpecificationVersionScheme",    								
    								"/header/implementationSpecification/version/value"};

    Directives directives = new Directives().add("root");
    for (String xpath : xpaths) {
      directives.add("actor").set(xpath).up();
    }
    System.out.println(new Xembler(directives).xml());*/
	 /* String src = "|/trade/tradeDetail/product/leg[2]/notional|";
	  System.out.println(StringUtils.replace("/trade/product/primaryAssetClass/@assetClassScheme", "/trade/product/", "/$fpmlProductType/"));
	  String firstCondition = "test:babu".split(":")[0];
	  System.out.println(concatedPreCondValue("Block Trade,New Allocated:true"));
	  String s = "FxSingleLeg";
	  System.out.println(s.substring(0, 1).toLowerCase() + s.substring(1));*/
	  
	  String obj = "|/trade/tradeDetail/product/leg[1]/notional|";
	  if(StringUtils.contains(obj, "leg[")){
		  System.out.println(reduceOnePos(obj));
	  }
	  
	  
  }
  
  private static String reduceOnePos(String arr){
	  
	  
		  String firstString = arr.split("leg\\[")[0];
		  String lastString = arr.split("leg\\[")[1];
		  	int i = Integer.valueOf(lastString.split("\\]")[0]);
		  	if(i > 0 ){
			  	String restString =lastString.split("\\]")[1]; 
			  	String modifiedString = "leg[" + --i + "]";
			  	return firstString+modifiedString+restString;
		  	}		  	
	  return arr;
  }
  
  private static  String concatedPreCondValue(String condition){		
		if(StringUtils.contains(condition, ":")){
	    	String firstCondition = condition.split(":")[0];
			ArrayList<String> strObjList = new ArrayList<String>();
			if(StringUtils.contains(firstCondition, ",")){
				String[] str = StringUtils.split(firstCondition,",");			
				for(String obj : str){
					strObjList.add("'"+obj+"'");	
				}
			}
			return StringUtils.join(strObjList, ",");
		}
		return condition;		
}  
  private static String getKeyword(String xpath){
		String formatterdXpath = xpath;
		if(StringUtils.contains(formatterdXpath, "|")){		 
			formatterdXpath = formatterdXpath.replaceAll("\\|", "");
		}
		if(StringUtils.contains(xpath, "'")){		 
			formatterdXpath = formatterdXpath.split("'")[1];
		}		
		return formatterdXpath;
	}
}
