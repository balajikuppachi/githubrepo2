alter table REG_REP_ICE_OPEN_TRANSACTION add grade varchar(20) NULL

alter table REG_REP_ICE_OPEN_TRANSACTION add buyerFinEnt varchar(20) NULL

alter table REG_REP_ICE_OPEN_TRANSACTION add buyerUsEnt varchar(20) NULL

alter table REG_REP_ICE_OPEN_TRANSACTION add collaterlized varchar(50) NULL

alter table REG_REP_ICE_OPEN_TRANSACTION add sellerFinEnt varchar(20) NULL

alter table REG_REP_ICE_OPEN_TRANSACTION add sellerUsEnt varchar(20) NULL

alter table REG_REP_ICE_OPEN_TRANSACTION add mixedSwapReportSdr varchar(20) NULL
