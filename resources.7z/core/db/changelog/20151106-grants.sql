GRANT SELECT ON dbo.REGREP_PROPERTY_VALUES TO readonly
GO
Grant Insert on dbo.REGREP_PROPERTY_VALUES to readwrite 
GO
Grant Delete on dbo.REGREP_PROPERTY_VALUES to readwrite 
GO
Grant Select on dbo.REGREP_PROPERTY_VALUES to readwrite 
GO
Grant Update on dbo.REGREP_PROPERTY_VALUES to readwrite 
GO

GRANT SELECT ON dbo.REGREP_REFRESH_TABLES TO readonly
GO
Grant Insert on dbo.REGREP_REFRESH_TABLES to readwrite 
GO
Grant Delete on dbo.REGREP_REFRESH_TABLES to readwrite 
GO
Grant Select on dbo.REGREP_REFRESH_TABLES to readwrite 
GO
Grant Update on dbo.REGREP_REFRESH_TABLES to readwrite 
GO
