INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('ACTION_TYPE_SS','InterestRate_New_Block Trade','InterestRate_New_Block Trade','N','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('ACTION_TYPE_SS','Credit_New_Block Trade','Credit_New_Block Trade','N','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('ACTION_TYPE_SS','ForeignExchange_New_Block Trade','ForeignExchange_New_Block Trade','N','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('ACTION_TYPE_SS','Credit_New_Cancel - Allocation','Credit_New_Cancel - Allocation','C','Cancel - Allocation',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('ACTION_TYPE_SS','ForeignExchange_New_Cancel - Allocation','ForeignExchange_New_Cancel - Allocation','C','Cancel - Allocation',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('ACTION_TYPE_SS','Credit_New_New Allocated','Credit_New_New Allocated','N','New Allocated',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DTCC_LCE','InterestRate_New_Block Trade','InterestRate_New_Block Trade','Trade','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DTCC_LCE','Credit_New_Block Trade','Credit_New_Block Trade','Trade','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DTCC_LCE','ForeignExchange_New_Block Trade','ForeignExchange_New_Block Trade','Trade','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DTCC_LCE','Credit_New_Cancel - Allocation','Credit_New_Cancel - Allocation','Cancel','Cancel - Allocation',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DTCC_LCE','ForeignExchange_New_Cancel - Allocation','ForeignExchange_New_Cancel - Allocation','Cancel','Cancel - Allocation',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DTCC_LCE','Credit_New_New Allocated','Credit_New_New Allocated','Trade','New Allocated',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('TRANSACTION_TYPE_SS','InterestRate_New_Block Trade','InterestRate_New_Block Trade','Trade','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('TRANSACTION_TYPE_SS','Credit_New_Block Trade','Credit_New_Block Trade','Trade','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('TRANSACTION_TYPE_SS','ForeignExchange_New_Block Trade','ForeignExchange_New_Block Trade','Trade','Block Trade',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('TRANSACTION_TYPE_SS','Credit_New_Cancel - Allocation','Credit_New_Cancel - Allocation','Exit','Cancel - Allocation',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('TRANSACTION_TYPE_SS','ForeignExchange_New_Cancel - Allocation','ForeignExchange_New_Cancel - Allocation','Exit','Cancel - Allocation',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('TRANSACTION_TYPE_SS','Credit_New_New Allocated','Credit_New_New Allocated','Trade','New Allocated',getdate())
GO


