SELECT COUNT(*) FROM REG_REP_DOMAIN_MAPPING
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACT/ACT29','ACT/ACT29','ACT/ACT.ICMA','ACT/ACT.ICMA',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACTB/ACTB','ACTB/ACTB','ACT/ACT.ICMA','ACT/ACT.ICMA',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','30/360','30/360','30/360','"When used in conjunction with a Definitions Type of ISDA2000, ""30/360"" refers to the Annex to the 2000 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (e), and therefore equates to any of ""30/360"", ""360/360"" or ""Bond Basis"". When used in conjunction with a Definitions Type of ISDA2006, ""30/360"" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (f), and therefore equates to any of ""30/360"", ""360/360"" or ""Bond Basis"". When used in conjunction with a Definitions Type of DRV, ""30/360"" refers to ""360/360""."',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','30E*/360','30E*/360','30E/360','"When used in conjunction with a Definitions Type of ISDA2000 ""30E/360"" refers to the Annex to the 2000 ISDA Definitions (June 2000 Version), Section 4.16. Day Count Fraction, paragraph (f), and therefore equates to ""30E/360 or ""Eurobond Basis"".When used in conjunction with a Definitions Type of ISDA2006 """"30E/360"""" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (g), and therefore equates to """"30E/360"""" or ""Eurobond basis"""".Generally not defined in the DRV. Using this value in conjunction with a Definitions Type of """"DRV"""", where it is not defined, means using the meaning described in the 2006 ISDA Definitions."""',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','30E+/360','30E+/360','30E/360','"When used in conjunction with a Definitions Type of ISDA2000 ""30E/360"" refers to the Annex to the 2000 ISDA Definitions (June 2000 Version), Section 4.16. Day Count Fraction, paragraph (f), and therefore equates to ""30E/360 or ""Eurobond Basis"".When used in conjunction with a Definitions Type of ISDA2006 """"30E/360"""" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (g), and therefore equates to """"30E/360"""" or ""Eurobond basis"""".Generally not defined in the DRV. Using this value in conjunction with a Definitions Type of """"DRV"""", where it is not defined, means using the meaning described in the 2006 ISDA Definitions."""',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','30E/360','30E/360','30E/360','"When used in conjunction with a Definitions Type of ISDA2000 ""30E/360"" refers to the Annex to the 2000 ISDA Definitions (June 2000 Version), Section 4.16. Day Count Fraction, paragraph (f), and therefore equates to ""30E/360 or ""Eurobond Basis"".When used in conjunction with a Definitions Type of ISDA2006 """"30E/360"""" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (g), and therefore equates to """"30E/360"""" or ""Eurobond basis"""".Generally not defined in the DRV. Using this value in conjunction with a Definitions Type of """"DRV"""", where it is not defined, means using the meaning described in the 2006 ISDA Definitions."""',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACT+1/360','ACT+1/360','ACT/360','"When used in conjunction with a Definitions Type of ISDA2000, ""ACT/360"" refers to the Annex to the 2000 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (d) and therefore equates to any of ""Actual/360"", ""Act/360"" or ""A/360"". When used in conjunction with a Definitions Type of ISDA2006, ""ACT/360"" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (e) and therefore equates to any of ""Actual/360"", ""Act/360"" or ""A/360"".When used in conjunction with a Definitions Type of DRV, ""Actual/360"" refers to ""365/360""."',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACT+1/365','ACT+1/365','ACT/365L','"Per 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (i).if ACT/365L"" is specified, the actual number of days in the Calculation Period or Compounding Period in respect of which payment is being made divided by 365 (or, if the later Period End Date of the Calculation Period or Compounding Period falls in a leap year, divided by 366)."""',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACT/360','ACT/360','ACT/360','"When used in conjunction with a Definitions Type of ISDA2000, ""ACT/360"" refers to the Annex to the 2000 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (d) and therefore equates to any of ""Actual/360"", ""Act/360"" or ""A/360"". When used in conjunction with a Definitions Type of ISDA2006, ""ACT/360"" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (e) and therefore equates to any of ""Actual/360"", ""Act/360"" or ""A/360"".When used in conjunction with a Definitions Type of DRV, ""Actual/360"" refers to ""365/360""."',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACT/365','ACT/365','ACT/365.Fixed','"When used in conjunction with a Definitions Type of ISDA2000, ""ACT/ACT.ISDA"" refers to the Annex to the 2000 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (b), and therefore equates to any of ""Actual/365"", ""Act/365"", ""A/365"", ""Actual/Actual"" or ""Act/Act"".When used in conjunction with a Definitions Type of ISDA2006, ""ACT/ACT.ISDA"" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (b), and therefore equates to any of ""Actual/Actual"", ""Actual/Actual (ISDA)"", ""Act/Act"" or ""Act/Act (ISDA)"".When used in conjunction with a Definitions Type of DRV, ACT/ACT.ISDA refers to 365/365 act/act ISDA."',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACT/365I','ACT/365I','ACT/365L','"Per 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (i).if ""ACT/365L"" is specified, the actual number of days in the Calculation Period or Compounding Period in respect of which payment is being made divided by 365 (or, if the later Period End Date of the Calculation Period or Compounding Period falls in a leap year, divided by 366)."',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('DCF','ACT/ACT','ACT/ACT','ACT/ACT.ISDA','"When used in conjunction with a Definitions Type of ISDA2000, ""ACT/ACT.ISDA"" refers to the Annex to the 2000 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (b), and therefore equates to any of ""Actual/365"", ""Act/365"", ""A/365"", ""Actual/Actual"" or ""Act/Act"".When used in conjunction with a Definitions Type of ISDA2006, ""ACT/ACT.ISDA"" refers to the 2006 ISDA Definitions, Section 4.16. Day Count Fraction, paragraph (b), and therefore equates to any of ""Actual/Actual"", ""Actual/Actual (ISDA)"", ""Act/Act"" or ""Act/Act (ISDA)"".When used in conjunction with a Definitions Type of DRV, ACT/ACT.ISDA refers to 365/365 act/act ISDA."',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:ParameterReturnVariance:SingleName','UPI Value','Equity-VS','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:ParameterReturnVariance:SingleIndex','UPI Value','Equity-VS','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Forward:PriceReturnBasicPerformance:SingleName','UPI Value','Equity-FWD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Forward:PriceReturnBasicPerformance:SingleIndex','UPI Value','Equity-FWD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:PriceReturnBasicPerformance:SingleName','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:PriceReturnBasicPerformance:SingleIndex','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:PriceReturnBasicPerformance:Basket','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:PortfolioSwap:PriceReturnBasicPerformance:SingleName','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:PortfolioSwap:PriceReturnBasicPerformance:SingleIndex','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:PortfolioSwap:PriceReturnBasicPerformance:Basket','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:ContractForDifference:PriceReturnBasicPerformance:SingleName','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:ContractForDifference:PriceReturnBasicPerformance:SingleIndex','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:ContractForDifference:PriceReturnBasicPerformance:Basket','UPI Value','Equity-ES_PSA_CFD','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnVariance:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnVolatility:SingleName','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:PriceReturnBasicPerformance:SingleName','UPI Value','Equity-OPT','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:PriceReturnBasicPerformance:SingleIndex','UPI Value','Equity-OPT','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnVolatility:SingleIndex','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnVolatility:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:ParameterReturnVariance:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:ParameterReturnVolatility:SingleName','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:ParameterReturnVolatility:SingleIndex','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:ParameterReturnVolatility:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Swap:ParameterReturnDividend:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Forward:PriceReturnBasicPerformance:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Other','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:PriceReturnBasicPerformance:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnDividend:SingleName','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnDividend:SingleIndex','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnDividend:Basket','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnVariance:SingleName','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ('EquityUpiTemplate','Equity:Option:ParameterReturnVariance:SingleIndex','UPI Value','Equity-StructuredProduct','Template Name',getdate())
GO


SELECT COUNT(*) FROM REG_REP_DOMAIN_MAPPING
GO
