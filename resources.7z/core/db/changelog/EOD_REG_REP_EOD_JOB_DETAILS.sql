
truncate table REG_REP_EOD_JOB_DETAILS
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('dataLoad','ExternalValuationDataLoaderSvc','Loads valuation data from CDBO and Galaxy','daily',getdate(),'NONE','NONE','NONE')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('dataLoad','CollateralDataExtractorService','Loads collateral data from ALGO','daily',getdate(),'NONE','NONE','NONE')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportRefresh','EodReportRefreshSvc','Refreshes SS and Val reports','on demand',getdate(),'NONE','NONE','NONE')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','EodSnapShotSubmitOnDemand','submits snapshots on Demand for given trades','on demand',getdate(),'NONE','NONE','NONE')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','EsmaCollateralValueGenSvc','generates eod CollateralValue report','daily',getdate(),'NONE','NONE','NONE')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('dataLoad','ExternalEquityDataExtractorSvc','Loads Galaxy price load','daily',getdate(),'NONE','NONE','NONE') 
GO

--CFTC SS Full
--INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates InterestRate eod Snapshot for CFTC','daily',getdate(),'Snapshot','CFTC','InterestRate')
--GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates Credit eod Snapshot for CFTC','daily',getdate(),'Snapshot','CFTC','Credit')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates Equity eod Snapshot for CFTC','daily',getdate(),'Snapshot','CFTC','Equity')
GO

--CFTC VAL
INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates InterestRate eod Valuation for CFTC','daily',getdate(),'Valuation','CFTC','InterestRate')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates Credit eod Valuation for CFTC','daily',getdate(),'Valuation','CFTC','Credit')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates Equity eod Valuation for CFTC','daily',getdate(),'Valuation','CFTC','Equity')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates ForeignExchange eod Valuation for CFTC','daily',getdate(),'Valuation','CFTC','ForeignExchange')
GO

--Delata CFTC
INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','DeltaReportGenSvc','generates ForeignExchange eod delta Snapshot for CFTC','daily',getdate(),'Snapshot','CFTC','ForeignExchange')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','DeltaReportGenSvc','generates InterestRate eod delta Snapshot for CFTC','daily',getdate(),'Snapshot','CFTC','InterestRate')
GO


--Combined CAD ss
INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','CombinedReportGenSvc','generates InterestRate eod combined snapshot CAD','daily',getdate(),'Snapshot','CAD','InterestRate')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','CombinedReportGenSvc','generates Credit eod combined snapshot CAD','daily',getdate(),'Snapshot','CAD','Credit')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','CombinedReportGenSvc','generates Equity eod combined snapshot CAD','daily',getdate(),'Snapshot','CAD','Equity')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','DeltaReportGenSvc','generates ForeignExchange delta eod combined snapshot CAD','daily',getdate(),'Snapshot','CAD','ForeignExchange')
GO

--CAD VAL
INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates InterestRate eod Valuation for CAD','daily',getdate(),'Valuation','CAD','InterestRate')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates Credit eod Valuation for CAD','daily',getdate(),'Valuation','CAD','Credit')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates Equity eod Valuation for CAD','daily',getdate(),'Valuation','CAD','Equity')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates ForeignExchange eod Valuation for CAD','daily',getdate(),'Valuation','CAD','ForeignExchange')
GO

---Delta ESMA SS
INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','DeltaReportGenSvc','generates eod delate snapshot for ESMA','daily',getdate(),'Snapshot','ESMA','InterestRate')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','DeltaReportGenSvc','generates eod delate snapshot for ESMA','daily',getdate(),'Snapshot','ESMA','ForeignExchange')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates InterestRate eod Valuation for ESMA','daily',getdate(),'Valuation','ESMA','InterestRate')
GO

INSERT INTO REG_REP_EOD_JOB_DETAILS (job_type,job_name,job_desc,job_freq,create_datetime,report_type,jurisdiction,asset_class) VALUES ('reportgeneration','FullReportGenSvc','generates ForeignExchange eod Valuation for ESMA','daily',getdate(),'Valuation','ESMA','ForeignExchange')
GO

