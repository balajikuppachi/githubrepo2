
---- ACTION_TYPE_SS , TRANSACTION_TYPE_SS , DTCC_LCE -  Bilateral - Cleared - Event type for InterestRate
INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'InterestRate_New_Bilateral - Cleared','InterestRate_New_Bilateral - Cleared','C','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'InterestRate_Cancel_Bilateral - Cleared','InterestRate_Cancel_Bilateral - Cleared','C','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'InterestRate_New_Bilateral - Cleared','InterestRate_New_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'InterestRate_Cancel_Bilateral - Cleared','InterestRate_Cancel_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'DTCC_LCE', 'InterestRate_New_Bilateral - Cleared','InterestRate_New_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate() )
GO
 	
INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES  ( 'DTCC_LCE', 'InterestRate_Cancel_Bilateral - Cleared','InterestRate_Cancel_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate())

---- ACTION_TYPE_SS , TRANSACTION_TYPE_SS , DTCC_LCE -  Bilateral - Cleared - Event type for Credit
INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'Credit_New_Bilateral - Cleared','Credit_New_Bilateral - Cleared','C','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'Credit_Cancel_Bilateral - Cleared','Credit_Cancel_Bilateral - Cleared','C','Bilateral - Cleared', getDate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'Credit_New_Bilateral - Cleared','Credit_New_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'Credit_Cancel_Bilateral - Cleared','Credit_Cancel_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'DTCC_LCE', 'Credit_New_Bilateral - Cleared','Credit_New_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'DTCC_LCE', 'Credit_Cancel_Bilateral - Cleared','Credit_Cancel_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate())

---- ACTION_TYPE_SS , TRANSACTION_TYPE_SS , DTCC_LCE -  Bilateral - Cleared - Event type for ForeignExchange
INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'ForeignExchange_New_Bilateral - Cleared','ForeignExchange_New_Bilateral - Cleared','C','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'ForeignExchange_Cancel_Bilateral - Cleared','ForeignExchange_Cancel_Bilateral - Cleared','C','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'ForeignExchange_New_Bilateral - Cleared','ForeignExchange_New_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'ForeignExchange_Cancel_Bilateral - Cleared','ForeignExchange_Cancel_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'DTCC_LCE', 'ForeignExchange_New_Bilateral - Cleared','ForeignExchange_New_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'DTCC_LCE', 'ForeignExchange_Cancel_Bilateral - Cleared','ForeignExchange_Cancel_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate())
GO

---- ACTION_TYPE_SS , TRANSACTION_TYPE_SS , DTCC_LCE -  Bilateral - Cleared - Event type for Equity
INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'Equity_New_Bilateral - Cleared - Cleared','Equity_New_Bilateral - Cleared','C','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'ACTION_TYPE_SS', 'Equity_Cancel_Bilateral - Cleared','Equity_Cancel_Bilateral - Cleared','C','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'Equity_New_Bilateral - Cleared - Cleared','Equity_New_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'TRANSACTION_TYPE_SS', 'Equity_Cancel_Bilateral - Cleared','Equity_Cancel_Bilateral - Cleared','Exit','Bilateral - Cleared', getDate())
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'DTCC_LCE', 'Equity_New_Bilateral - Cleared - Cleared','Equity_New_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate() )
GO

INSERT INTO REG_REP_DOMAIN_MAPPING (DOMAIN_NAME,SRC_CODE,SRC_DESC,DTCC_CODE,DTCC_DESC,CREATE_DATETIME) VALUES ( 'DTCC_LCE', 'Equity_Cancel_Bilateral - Cleared','Equity_Cancel_Bilateral - Cleared','Cancel','Bilateral - Cleared', getDate())
GO
