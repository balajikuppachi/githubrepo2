package com.wellsfargo.regulatory.log4j.filter;

/******************************************************************************
 * Filename    : ExceptionThresholdFilter.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.ThrowableInformation;

@SuppressWarnings("rawtypes")
public class ExceptionThresholdFilter extends Filter
{	
	private Map classThresholdMap;
	private int thresholdNumber = 10;
  
	public ExceptionThresholdFilter()
	{
		this.classThresholdMap = new HashMap();
	}
  
	public int decide(LoggingEvent event)
	{
		if ((event == null) || (event.getMessage() == null)) 
		{
			return -1;
		}
		
		Throwable exception = null;
		ThrowableInformation info = event.getThrowableInformation();
		if (info != null)
		{
			exception = info.getThrowable();
		}
		else
		{
			
			Object msg = event.getMessage();
			if (Throwable.class.isAssignableFrom(msg.getClass())) 
			{
				exception = (Throwable)msg;
			}
		}
		
		if (exception == null) 
		{
			return -1;
		}
		
		Class exceptionClass = exception.getClass();
		return performThresholding(exceptionClass);
	}
  
	protected int performThresholding(Class exClass)
	{
		if (exClass == null) 
		{
			return -1;
		}
		
		int retCode = -1;
		if (this.classThresholdMap.containsKey(exClass))
		{
			retCode = performClassThresholding(exClass);
		}
		else
		{
			Set keySet = this.classThresholdMap.keySet();
			Iterator iter = keySet.iterator();
			while (iter.hasNext())
			{
				Class claz = (Class)iter.next();
				if (claz.isAssignableFrom(exClass)) 
				{
					retCode = performClassThresholding(claz);
				}
			}
		}
		
		return retCode;
	}
  
	protected int performClassThresholding(Class clz)
	{
		int retCode = -1;
		if (clz == null) 
		{
			return retCode;
		}
		
		Integer counter = (Integer)this.classThresholdMap.get(clz);
		if (counter == null) 
		{
			return retCode;
		}
		
		int newCount = counter.intValue();
		newCount++;
		if (newCount >= this.thresholdNumber)
		{
			newCount = 0;
			retCode = 1;
		}
		
		counter = new Integer(newCount);
		this.classThresholdMap.put(clz, counter);
    
		return retCode;
	}
  
	public void setThresholdNumber(int number)
	{
		this.thresholdNumber = number;
	}
  
	public int getThresholdNumber()
	{
		return this.thresholdNumber;
	}
  
	public void setException(String className)
	{
		if (className == null) 
		{
			return;
		}
		
		try
		{
			Class clz = Class.forName(className);
			if (!this.classThresholdMap.containsKey(clz)) 
			{
				this.classThresholdMap.put(clz, new Integer(0));
			}
		}
		catch (ClassNotFoundException cnfe) {}
	}
}


