package com.wellsfargo.regulatory.log4j.filter;

/******************************************************************************
 * Filename    : ExceptionFilter.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.ThrowableInformation;

@SuppressWarnings("rawtypes")
public class ExceptionFilter extends Filter
{	
	private Map classThresholdMap;
	private boolean useRootException = false;
	private boolean accept = true;
	private boolean acceptWithoutException = false;
  
	public ExceptionFilter()
	{
		this.classThresholdMap = new HashMap();
	}
  
	public int decide(LoggingEvent event)
	{
		if ((event == null) || (event.getMessage() == null)) 
		{
			return -1;
		}
		
		Throwable exception = null;
		ThrowableInformation info = event.getThrowableInformation();
		
		if (info != null)
		{
			exception = info.getThrowable();
		}
		else
		{
			Object msg = event.getMessage();
			if (Throwable.class.isAssignableFrom(msg.getClass())) 
			{
				exception = (Throwable)msg;
			}
		}
		
		if (exception == null)
		{
			if (this.acceptWithoutException) 
			{
				return 1;
			}
			
			return -1;
		}
		Class exceptionClass = exception.getClass();
		return performFiltering(exceptionClass);
	}
  
	protected int performFiltering(Class exClass)
	{
		if (exClass == null) 
		{
			return -1;
		}
		
		int retCode = -1;
		if (this.classThresholdMap.containsKey(exClass))
		{
			if (this.accept) 
			{
				return 1;
			}
			return -1;
		}
		
		Set keySet = this.classThresholdMap.keySet();
		Iterator iter = keySet.iterator();
		while (iter.hasNext())
		{
			Class claz = (Class)iter.next();
			if (claz.isAssignableFrom(exClass))
			{
				if (this.accept) 
				{
					return 1;
				}
				return -1;
			}
		}
		
		return retCode;
	}
  
	public void setException(String className)
	{
		if (className == null) 
		{
			return;
		}
		
		try
		{
			Class clz = Class.forName(className);
			if (!this.classThresholdMap.containsKey(clz)) 
			{
				this.classThresholdMap.put(clz, new Integer(0));
			}
		}
		catch (ClassNotFoundException cnfe) {}
	}
  
	public boolean getUseRootException()
	{
		return this.useRootException;
	}
  
	public void setUseRootException(boolean useRootException)
	{
		this.useRootException = useRootException;
	}
  
	public boolean getAccept()
	{
		return this.accept;
	}
  
	public void setAccept(boolean accept)
	{
		this.accept = accept;
	}
  
	public boolean getAcceptWithoutException()
	{
		return this.acceptWithoutException;
	}
  
	public void setAcceptWithoutException(boolean acceptWithoutException)
	{
		this.acceptWithoutException = acceptWithoutException;
	}
}
