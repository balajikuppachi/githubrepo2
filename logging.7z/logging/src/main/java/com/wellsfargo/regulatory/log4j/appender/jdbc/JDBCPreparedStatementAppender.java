package com.wellsfargo.regulatory.log4j.appender.jdbc;

/******************************************************************************
 * Filename    : JDBCPreparedStatementAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

import com.wellsfargo.regulatory.log4j.layout.RegulatoryLayout;

public class JDBCPreparedStatementAppender extends JDBCAppender
{
	protected Properties paramMap;
	protected List variableList;
  
	public JDBCPreparedStatementAppender()
	{
		this.paramMap = new Properties();
		this.variableList = new ArrayList();
	}
  
	protected Connection getConnection() throws SQLException
	{
		if (!DriverManager.getDrivers().hasMoreElements()) 
		{
			setDriver("com.sybase.jdbc4.jdbc.SybDriver");
		}
		
		if (this.connection == null) 
		{
			this.connection = DriverManager.getConnection(this.databaseURL, this.paramMap);
		}
		
		return this.connection;
	}
  
	protected void execute(String sql, LoggingEvent event) throws SQLException
	{
		Connection con = null;
		PreparedStatement stmt = null;
		
		try
		{
			con = getConnection();
			if (con == null) 
			{
				LogLog.warn("Could not execute sql : " + sql + " - connection is null");
			}
			stmt = con.prepareStatement(sql);
			
			for (int i = 0; i < this.variableList.size(); i++)
			{
				RegulatoryLayout next = (RegulatoryLayout)this.variableList.get(i);
				String value = next.format(event);
				stmt.setString(i + 1, value);
			}
			
			stmt.executeUpdate();
			con.commit(); 
			return;
		}
		catch (SQLException e)
		{
			LogLog.error("Exception encountered executing statement: " + sql, e);
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered executing statement: " + sql, t);
		}
		finally
		{
			try
			{
				if (stmt != null) 
				{
					stmt.close();
				}
			}
			catch (Throwable t)
			{
				LogLog.error("Could not close statement", t);
			}
			try
			{
				closeConnection(con);
			}
			catch (Throwable t)
			{
				LogLog.error("Could not close connection", t);
			}
		}
	}
  
	public void setParameter(String param)
	{
		if (param == null) 
		{
			return;
		}
		
		try
		{
			StringTokenizer tokens = new StringTokenizer(param, "||");
			if (tokens.countTokens() < 2) 
			{
				return;
			}
			
			String key = tokens.nextElement().toString();
			String value = tokens.nextElement().toString();
      
			this.paramMap.put(key, value);
		}
		catch (Throwable t)
		{
			LogLog.warn("Could not set variable: " + param + " expected in format of key||value", t);
		}
	}
  
	public void setVariable(String variable)
	{
		if (variable == null) 
		{
			return;
		}
		
		try
		{
			RegulatoryLayout layout = new RegulatoryLayout(variable);
			this.variableList.add(layout);
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered resolving variable: " + variable, t);
		}
	}
  
	public void setUser(String user)
	{
		this.databaseUser = user;
		
		this.paramMap.put("user", user);
	}
  
	public void setPassword(String password)
	{
		this.databasePassword = password;
    
		this.paramMap.put("password", password);
	}
  
	public void flushBuffer()
	{
		try
		{
			this.removes.ensureCapacity(this.buffer.size());
			
			for (Iterator i = this.buffer.iterator(); i.hasNext();) 
			{
				try
				{
					LoggingEvent logEvent = (LoggingEvent)i.next();
          
					execute(getSql(), logEvent);
					this.removes.add(logEvent);
				}
				catch (SQLException e)
				{
					this.errorHandler.error("Failed to excute sql", e, 2);
				}
			}
		}
		catch (Throwable t)
		{
			Iterator i;
			LogLog.warn("Exception encountered", t);
		}
		finally
		{
			this.buffer.removeAll(this.removes);
			this.removes.clear();
		}
	}
}

