package com.wellsfargo.regulatory.log4j.appender.sender;

/******************************************************************************
 * Filename    : NCSAAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.zip.CRC32;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.ErrorHandler;
import org.apache.log4j.spi.LoggingEvent;

public class NCSAAppender extends AppenderSkeleton
{
	private String hostName;
	private String monitorHostName;
	private String port;
	private String serviceName;
	private int nscaVersion = 3;
	private int nagiosCode = 3;
	private boolean encrypt = false;
	private String encryptionKey = "";
	private static final int TRANSMITTED_IV_SIZE = 128;
	private static final int CODE_ERROR = 2;
	private static final int CODE_OK = 0;
  
	protected void append(LoggingEvent event)
	{
		try
		{
			Level level = event.getLevel();
			int code = 0;
			
			if (level != null) 
			{
				if ((level.equals(Level.DEBUG)) || (level.equals(Level.INFO))) 
				{
					code = 0;
				} 
				else if ((level.equals(Level.ERROR)) || (level.equals(Level.FATAL))) 
				{
					code = 2;
				} 
				else if (level.equals(Level.WARN)) 
				{
					code = 2;
				}
			}
			
			sendNscaMessage(event, code);
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered sending logging event", t);
		}
	}
  
  public void close() {}
  
  	public boolean requiresLayout()
  	{
  		return false;
  	}
  
  	protected void sendNscaMessage(LoggingEvent event, int returnCode)
  	{
  		if (event == null)
  		{
  			LogLog.warn("Cannot send a null event");
  			return;
  		}
  		
  		Socket s = null;
        String errorMsg;
  		try
  		{
  			s = new Socket(getMonitorHostName(), new Integer(getPort()).intValue());
      
  			OutputStream out = s.getOutputStream();
  			DataInputStream in = new DataInputStream(s.getInputStream());
  			byte[] receivedIv = new byte[''];
  			in.readFully(receivedIv, 0, 128);
      
  			int time = in.readInt();
            byte[] alert = buildMessage(event, returnCode, time);
            if (this.encrypt) 
            {
            	encryptBuffer(alert, receivedIv);
            }
            
            out.write(alert, 0, alert.length);
            out.flush();
            out.close();
            in.close();
            s.close();
            return;
  		}
  		catch (IOException ioe)
  		{
  			errorMsg = "NagiosAppender::sendNcsaMessage(), Exception thrown trying to deliver log4j record to Nagios: nagios server= " + getMonitorHostName() + ", nagios port = " + getPort();
  			LogLog.warn("Exception encountered sending Nagios alert: " + errorMsg, ioe);
  		}
  		catch (Throwable t)
  		{
  			LogLog.warn("Exception encountered sending Nagios alert", t);
  		}
  		
  		finally
  		{
  			if (s != null) 
  			{
  				try
  				{
  					s.close();
  				}
  				catch (Throwable t)
  				{
  					LogLog.warn("Exception encountered closing stream", t);
  				}
  			}
  		}
  	}
  
  	protected byte[] buildMessage(LoggingEvent event, int returnCode, int time)
  	{
  		byte[] hostName = new byte[64];
  		
  		for (int i = 0; i < hostName.length; i++) 
  		{
  			hostName[i] = 0;
  		}
  		
  		String temp = getHostName();
  		if ((temp == null) || (temp.length() == 0))
  		{
  			temp = getLocalHostName();
  			if ((temp == null) || (temp.length() == 0)) 
  			{
  				temp = "NOT_SET";
  			}
  		}
  		System.arraycopy(temp.getBytes(), 0, hostName, 0, temp.getBytes().length);

  		byte[] serviceName = new byte[''];
  		for (int i = 0; i < serviceName.length; i++) 
  		{
  			serviceName[i] = 0;
  		}
  		
  		temp = getServiceName();
  		if ((null == temp) || (temp.length() == 0))
  		{
  			String errorMsg = "servicename was not set in log4j config file";
  			Exception e = new Exception(errorMsg);
  			getErrorHandler().error(errorMsg, e, 0);
  			temp = "NOT_SET";
  		}
  		
  		System.arraycopy(temp.getBytes(), 0, serviceName, 0, temp.getBytes().length);

  		byte[] pluginOutput = new byte[512];
  		
  		for (int i = 0; i < pluginOutput.length; i++) 
  		{
  			pluginOutput[i] = 0;
  		}
  		
  		String renderedMsg = event.getRenderedMessage();
  		if (getLayout() != null) 
  		{
  			renderedMsg = getLayout().format(event);
  		}
  		
  		temp = "" + renderedMsg;
  		if (temp.getBytes().length <= 512) 
  		{
  			System.arraycopy(temp.getBytes(), 0, pluginOutput, 0, temp.getBytes().length);
  		} 
  		else 
  		{
  			System.arraycopy(temp.getBytes(), 0, pluginOutput, 0, pluginOutput.length);
  		}
  		
  		int alertSize = 16 + hostName.length + serviceName.length + pluginOutput.length;
    
  		byte[] alert = new byte[alertSize];
  		for (int i = 0; i < alertSize; i++) 
  		{
  			alert[i] = 0;
  		}
  		
  		alert[0] = ((byte)(this.nscaVersion >> 8 & 0xFF));
  		alert[1] = ((byte)(this.nscaVersion & 0xFF));
  		alert[4] = 0;
  		alert[5] = 0;
  		alert[6] = 0;
  		alert[7] = 0;
  		alert[8] = ((byte)(time >> 24 & 0xFF));
  		alert[9] = ((byte)(time >> 16 & 0xFF));
  		alert[10] = ((byte)(time >> 8 & 0xFF));
  		alert[11] = ((byte)(time & 0xFF));
  		alert[12] = ((byte)(returnCode >> 8 & 0xFF));
  		alert[13] = ((byte)(returnCode & 0xFF));
  		
  		int offset = 14;
    
  		System.arraycopy(hostName, 0, alert, offset, hostName.length);
  		offset += hostName.length;
        System.arraycopy(serviceName, 0, alert, offset, serviceName.length);
        offset += serviceName.length;
        System.arraycopy(pluginOutput, 0, alert, offset, pluginOutput.length);
        offset += pluginOutput.length;

        CRC32 crc = new CRC32();
        crc.update(alert);
        long crcValue = crc.getValue();
    
	    alert[4] = ((byte)(int)(crcValue >> 24 & 0xFF));
	    alert[5] = ((byte)(int)(crcValue >> 16 & 0xFF));
	    alert[6] = ((byte)(int)(crcValue >> 8 & 0xFF));
	    alert[7] = ((byte)(int)(crcValue & 0xFF));
    
	    return alert;
  	}
  
  	protected byte[] encryptBuffer(byte[] buffer, byte[] iv)
  	{
  		if (!this.encrypt) 
  		{
  			return buffer;
  		}
  		
  		int y = 0;
  		for (int x = 0; y < buffer.length; x++)
  		{
  			if (x >= 128) 
  			{
  				x = 0;
  			}
  			
  			int tmp33_32 = y; byte[] tmp33_31 = buffer;tmp33_31[tmp33_32] = ((byte)(tmp33_31[tmp33_32] ^ iv[x]));y++;
  		}
  		
  		if (this.encryptionKey != null)
  		{
  			byte[] password = this.encryptionKey.getBytes();
      
  			int y1 = 0;
  			for (int x = 0; y1 < buffer.length; x++)
  			{
  				if (x >= password.length) 
  				{
  					x = 0;
  				}
  				
  				int tmp92_90 = y1; byte[] tmp92_89 = buffer;tmp92_89[tmp92_90] = ((byte)(tmp92_89[tmp92_90] ^ password[x]));y1++;
  			}
  		}
  		
  		return buffer;
  	}
  
  	public String getHostName()
  	{
  		return this.hostName;
  	}
  
  	public void setHostName(String hostName)
  	{
  		this.hostName = hostName;
  	}
  
  	public String getMonitorHostName()
  	{
  		return this.monitorHostName;
  	}
  
  	public void setMonitorHostName(String monitorHostName)
  	{
  		this.monitorHostName = monitorHostName;
  	}
  
  	public String getPort()
  	{
  		return this.port;
  	}
  
  	public void setPort(String port)
  	{
  		this.port = port;
  	}
  
  	public String getServiceName()
  	{
  		return this.serviceName;
  	}
  
  	public void setServiceName(String serviceName)
  	{
  		this.serviceName = serviceName;
  	}
  
  	public int getNagiosCode()
  	{
  		return this.nagiosCode;
  	}
  
  	public void setNagiosCode(int nagiosCode)
  	{
  		this.nagiosCode = nagiosCode;
  	}
  
  	private String getLocalHostName()
  	{
  		try
  		{
  			InetAddress address = InetAddress.getLocalHost();
  			return address.getHostName();
  		}
  		catch (UnknownHostException uhe) {}
  		return "NOT_SET";
  	}
  
  	public boolean isEncrypt()
  	{
  		return this.encrypt;
  	}
  
  	public void setEncrypt(boolean encrypt)
  	{
  		this.encrypt = encrypt;
  	}
  
  	public String getEncryptionKey()
  	{
  		return this.encryptionKey;
  	}
  
  	public void setEncryptionKey(String encryptionKey)
  	{
  		this.encryptionKey = encryptionKey;
  	}
  	
}
