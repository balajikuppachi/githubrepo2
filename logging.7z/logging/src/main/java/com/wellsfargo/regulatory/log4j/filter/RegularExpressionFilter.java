package com.wellsfargo.regulatory.log4j.filter;

/******************************************************************************
 * Filename    : RegularExpressionFilter.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;

public class RegularExpressionFilter extends Filter
{
	@SuppressWarnings("rawtypes")
	private List regularExpressions;
	private boolean acceptOnMatch = true;
	private boolean lastFilter = false;
  
	@SuppressWarnings("rawtypes")
	public RegularExpressionFilter()
	{
		this.regularExpressions = new ArrayList();
	}
  
	public int decide(LoggingEvent event)
	{
		String msg = event.getRenderedMessage();
		if (msg == null) 
		{
			return -1;
		}
		
		for (int i = 0; i < this.regularExpressions.size(); i++)
		{
			Pattern next = null;
			try
			{
				next = (Pattern)this.regularExpressions.get(i);
				if (next != null)
				{
					Matcher matcher = next.matcher(msg);
					boolean decision = matcher.matches();
					if (decision)
					{
						if (this.acceptOnMatch) 
						{
							return 1;
						}
						return -1;
					}
				}
			}
			catch (Throwable t)
			{
				LogLog.error("Exception encountered matching pattern: " + next, t);
			}
		}
		
		if (this.lastFilter) 
		{
			return -1;
		}
		
		return 0;
	}
  
	@SuppressWarnings("unchecked")
	public void setRegularExpression(String filter)
	{
		if ((this.regularExpressions != null) && (filter != null)) 
		{
			try
			{
				this.regularExpressions.add(Pattern.compile(filter));
			}
			catch (Throwable t)
			{
				LogLog.error("Exception compiling regular expression: " + filter, t);
			}
		}
	}
  
	@SuppressWarnings("rawtypes")
	public List getRegularExpressions()
	{
		return this.regularExpressions;
	}
  
	public boolean getAcceptOnMatch()
	{
		return this.acceptOnMatch;
	}
  
	public void setAcceptOnMatch(boolean acceptOnMatch)
	{
		this.acceptOnMatch = acceptOnMatch;
	}
  
	public boolean getLastFilter()
	{
		return this.lastFilter;
	}
  
	public void setLastFilter(boolean lastFilter)
	{
		this.lastFilter = lastFilter;
	}
}
