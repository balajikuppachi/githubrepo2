package com.wellsfargo.regulatory.log4j.config;

/******************************************************************************
 * Filename    : RegulatoryConfigurator.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.xml.DOMConfigurator;

public class RegulatoryConfigurator extends DOMConfigurator
{
	protected static final String SYSTEM_PROPERTY_FILE = "log4j.regulatory.propertyFile";
  
	public RegulatoryConfigurator()
	{
		String propFileName = System.getProperty("log4j.regulatory.propertyFile");
		if ((propFileName != null) && (propFileName.length() > 0)) 
		{
			loadSystemProperties(propFileName);
		}
	}
  
	protected void loadSystemProperties(String fileName)
	{
		if (fileName == null) 
		{
			return;
		}
		
		try
		{
			Properties props = new Properties();
			InputStream is = ClassLoader.getSystemResourceAsStream(fileName);
			if (is != null)
			{
				props.load(is);
				Enumeration e = props.keys();
				
				while (e.hasMoreElements())
				{
					String key = (String)e.nextElement();
					System.setProperty(key, props.getProperty(key));
				}
			}
			else
			{
				LogLog.warn("File: " + fileName + " could not be found on classpath.  " + "No system properties will be set");
			}
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered parsing properties file: " + fileName, t);
			LogLog.warn("Log4J will continue to process, but without setting system properties");
		}
	}
}
