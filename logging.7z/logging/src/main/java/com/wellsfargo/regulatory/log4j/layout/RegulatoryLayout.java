package com.wellsfargo.regulatory.log4j.layout;

/******************************************************************************
 * Filename    : RegulatoryLayout.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import org.apache.log4j.PatternLayout;
import org.apache.log4j.helpers.PatternParser;
import org.apache.log4j.spi.LoggingEvent;

import com.wellsfargo.regulatory.log4j.pattern.RegulatoryPatternParser;

public class RegulatoryLayout extends PatternLayout
{
	private String defaultMessage = "";
  
	public RegulatoryLayout() {}
  
	public RegulatoryLayout(String pattern)
	{
		super(pattern);
	}
  
	protected PatternParser createPatternParser(String pattern)
	{
		return new RegulatoryPatternParser(pattern);
	}
  
	public String getDefaultMessage()
	{
		return this.defaultMessage;
	}
  
	public void setDefaultMessage(String defaultMessage)
	{
		this.defaultMessage = defaultMessage;
	}
  
	public String format(LoggingEvent event)
	{
		StringBuffer out = new StringBuffer();
    
		out.append(getDefaultMessage());
		out.append(super.format(event));
    
		return out.toString();
	}
	
}
