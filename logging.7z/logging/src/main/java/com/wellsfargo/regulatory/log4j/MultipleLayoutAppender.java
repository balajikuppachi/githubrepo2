package com.wellsfargo.regulatory.log4j;

/******************************************************************************
 * Filename    : MultipleLayoutAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.apache.log4j.Appender;
import org.apache.log4j.Layout;
import org.apache.log4j.LogManager;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.ThrowableInformation;

public class MultipleLayoutAppender extends AppenderAttachableSkeleton 
{
	@SuppressWarnings("rawtypes")
	protected List layoutList = new ArrayList();

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void setLayout(Layout next) 
	{
		if (next == null) 
		{
			return;
		}
		
		if (this.layoutList == null) 
		{
			this.layoutList = new ArrayList();
		}
		
		this.layoutList.add(next);
	}

	public Layout getLayout() 
	{
		if ((this.layoutList == null) || (this.layoutList.isEmpty())) 
		{
			return null;
		}
		
		return (Layout) this.layoutList.get(0);
	}

	@SuppressWarnings("rawtypes")
	public List getLayoutList() 
	{
		if (this.layoutList == null) 
		{
			return new ArrayList();
		}
		
		return this.layoutList;
	}

	@SuppressWarnings("rawtypes")
	protected void sendToAppenders(LoggingEvent event) 
	{
		if (event == null) 
		{
			return;
		}
		
		List layouts = getLayoutList();
		if (layouts == null) 
		{
			try 
			{
				super.sendToAppenders(event);
			}
			catch (Throwable t) 
			{
				LogLog.warn("Exception encountered sending logging event to appenders", t);
			}
			return;
		}
		
		try 
		{
			for (int i = 0; i < layouts.size(); i++) 
			{
				Layout next = (Layout) layouts.get(i);
				String message = next.format(event);
				Throwable ex = null;
				if ((event.getThrowableInformation() != null) && (event.getThrowableInformation().getThrowable() != null)) 
				{
					ex = event.getThrowableInformation().getThrowable();
				}
				
				event = new LoggingEvent(event.fqnOfCategoryClass, LogManager.getLogger(event.getLoggerName()), event.getLevel(), message, ex);
			}
			
			super.sendToAppenders(event);
			
		} 
		catch (Throwable t) 
		{
			LogLog.warn("Exception encountered sending logging event to appenders", t);
		}
	}

	@SuppressWarnings("rawtypes")
	public void close() 
	{
		Enumeration enumerator = getAllAppenders();
		if (enumerator == null) 
		{
			return;
		}
		
		try 
		{
			while (enumerator.hasMoreElements()) 
			{
				Appender appender = (Appender) enumerator.nextElement();
				if (appender != null) 
				{
					appender.close();
				}
			}
		} 
		catch (Throwable t) 
		{
			LogLog.warn("Exception encountered closing appenders", t);
		}
	}

	public boolean requiresLayout() 
	{
		return true;
	}
}
