package com.wellsfargo.regulatory.log4j.appender.trigger;


/******************************************************************************
 * Filename    : TimerAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.Enumeration;

import org.apache.log4j.Appender;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.helpers.AppenderAttachableImpl;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.AppenderAttachable;
import org.apache.log4j.spi.LoggingEvent;

public class TimerAppender extends AppenderSkeleton implements AppenderAttachable
{
	private long interval = 600000L;
	private Timer timer;
	private Logger parentLogger;
	private String defaultMessage = "Timer event has fired";
	private AppenderAttachableImpl appenders;
	private boolean timerContinue = true;
	private boolean initFlag = true;
  
	public TimerAppender()
	{
		this.parentLogger = LogManager.getLogger(TimerAppender.class);
		this.appenders = new AppenderAttachableImpl();
		this.timer = new Timer();
		this.timer.start();
    
		addShutdownHook();
	}
  
	protected void addShutdownHook()
	{
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
			public void run()
			{
				TimerAppender.this.timerContinue = false;
			}
		});
	}
  
	protected void append(LoggingEvent event) {}
  
	public void addAppender(Appender newAppender)
	{
		if (newAppender == null) 
		{
			return;
		}
		
		this.appenders.addAppender(newAppender);
	}
  
	public Enumeration getAllAppenders()
	{
		return this.appenders.getAllAppenders();
	}
  
	public Appender getAppender(String name)
	{
		return this.appenders.getAppender(name);
	}
  
	public boolean isAttached(Appender appender)
	{
		return this.appenders.isAttached(appender);
	}
  
	public void removeAllAppenders()
	{
		this.appenders.removeAllAppenders();
	}
  
	public void removeAppender(Appender appender)
	{
		this.appenders.removeAppender(appender);
	}
  
	public void removeAppender(String name)
	{
		this.appenders.removeAppender(name);
	}
  
	public String getDefaultMessage()
	{
		return this.defaultMessage;
	}
  
	public void setDefaultMessage(String message)
	{
		this.defaultMessage = message;
	}
  
	public String getInterval()
	{
		return String.valueOf(this.interval);
	}
  
	public void setInterval(String interval)
	{
		if (interval == null) 
		{
			return;
		}
    
		try
		{
			this.interval = (Integer.parseInt(interval) * 60000);
		}
		catch (NumberFormatException nfe)
		{
			getErrorHandler().error("Number Format Exception encountered parsing interval: " + interval);
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered parsing interval: " + interval, t);
		}
	}
  
	protected void sendToAppenders(LoggingEvent event)
	{
		if (event == null) 
		{
			return;
		}
		
		Enumeration enumerator = getAllAppenders();
		if (enumerator == null) 
		{
			return;
		}
		
		try
		{
			while (enumerator.hasMoreElements())
			{
				Appender appender = (Appender)enumerator.nextElement();
				if (appender != null) 
				{
					appender.doAppend(event);
				}
			}
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered sending to appenders", t);
		}
	}
  
	private class Timer extends Thread
	{
		private Timer() {}
    
		public void run()
		{
			while (TimerAppender.this.timerContinue)
			{
				try
				{
					sleep(TimerAppender.this.interval);
				}
				catch (Throwable t)
				{
					TimerAppender.this.getErrorHandler().error("Exception encountered sleeping: " + t.getClass().getName() + " Message: " + t.getMessage());
				}
				
				if (!TimerAppender.this.initFlag) 
				{
					try
					{
						TimerAppender.this.sendToAppenders(new LoggingEvent(TimerAppender.class.getName(), TimerAppender.this.parentLogger, Level.ALL, TimerAppender.this.getDefaultMessage(), null));
					}
					catch (Throwable t)
					{
						LogLog.error("Exception encountered logging event", t);
					}
				} else {
					TimerAppender.this.initFlag = false;
				}
			}
		}
	}
  
	public void close()
	{
		Enumeration enumerator = getAllAppenders();
		if (enumerator == null) 
		{
			return;
		}
		
		try
		{
			while (enumerator.hasMoreElements())
			{
				Appender appender = (Appender)enumerator.nextElement();
				if (appender != null) 
				{
					appender.close();
				}
			}
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered closing loggers", t);
		}
		
		this.timerContinue = false;
	}
  
	public boolean requiresLayout()
	{
		return false;
	}
	
}
