package com.wellsfargo.regulatory.log4j.layout;

/******************************************************************************
 * Filename    : SNMPLayout.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.log4j.Layout;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.ThrowableInformation;

public class SNMPLayout extends Layout
{
	public static final String FORMAT_TYPE_EXCEPTION = "exception";
	public static final String FORMAT_TYPE_MESSAGE = "message";
	
	protected Map messageMap;
	protected Map exceptionMap;
	protected String formatType = "message";
	protected String defaultOid = "1.3.6.1.2.1.1.1.0";
  
	public SNMPLayout()
	{
		this.messageMap = new HashMap();
		this.exceptionMap = new HashMap();
	}
  
	public void activateOptions() {}
  
	public String format(LoggingEvent event)
	{
		if (event == null) 
		{
			return this.defaultOid;
		}
		
		try
		{
			if (this.formatType.equals("exception"))
			{
				Throwable ex = getExceptionFromEvent(event);
				if (ex == null) 
				{
					return this.defaultOid;
				}
				
				return formatExceptionMessage(ex.getClass());
			}
			
			if (this.formatType.equals("message")) 
			{
				return formatStringMessage(event.getRenderedMessage());
			}
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered", t);
		}
		
		return this.defaultOid;
	}
  
	protected Throwable getExceptionFromEvent(LoggingEvent event)
	{
		if (event == null) 
		{
			return null;
		}
		
		Throwable exception = null;
		ThrowableInformation info = event.getThrowableInformation();
		if (info != null)
		{
			exception = info.getThrowable();
		}
		else
		{
			Object msg = event.getMessage();
			
			if (Throwable.class.isAssignableFrom(msg.getClass())) 
			{
				exception = (Throwable)msg;
			}
		}
		
		return exception;
	}
  
	protected String formatStringMessage(String message)
	{
		if (message == null) {
			return this.defaultOid;
		}
		
		if (this.messageMap.containsKey(message)) 
		{
			return this.messageMap.get(message).toString();
		}
		
		Set keySet = this.messageMap.keySet();
		Iterator iter = keySet.iterator();
		while (iter.hasNext())
		{
			String content = (String)iter.next();
			if (message.indexOf(content) != -1) 
			{
				return this.messageMap.get(content).toString();
			}
		}
		
		return this.defaultOid;
	}
  
	protected String formatExceptionMessage(Class exceptionClass)
	{
		if (exceptionClass == null) 
		{
			return this.defaultOid;
		}
		
		if (this.exceptionMap.containsKey(exceptionClass)) 
		{
			return this.exceptionMap.get(exceptionClass).toString();
		}
		
		Set keySet = this.exceptionMap.keySet();
		Iterator iter = keySet.iterator();
		while (iter.hasNext())
		{
			Class claz = (Class)iter.next();
			if (claz.isAssignableFrom(exceptionClass)) 
			{
				return this.exceptionMap.get(claz).toString();
			}
		}
		
		return this.defaultOid;
	}
  
	public boolean ignoresThrowable()
	{
		return false;
	}
  
	public void setFormatType(String type)
	{
		if (type == null) 
		{
			return;
		}
		
		if (type.equalsIgnoreCase("exception")) 
		{
			this.formatType = "exception";
		}
		
		if (type.equalsIgnoreCase("message")) 
		{
			this.formatType = "message";
		}
	}
  
	public void setOidMapping(String mapping)
	{
		if (mapping == null) 
		{
			return;
		}
		
		if (mapping.indexOf("|") == -1) 
		{
			return;
		}
		
		StringTokenizer tokens = new StringTokenizer(mapping, "|");
		Object content = tokens.nextElement();
		Object oid = tokens.nextElement();
		if ((content == null) || (oid == null)) 
		{
			return;
		}
		
		if (this.formatType.equals("exception")) 
		{
			setExceptionMap(content.toString(), oid.toString());
		} 
		else 
		{
			setMessageMap(content.toString(), oid.toString());
		}
	}
  
	protected void setMessageMap(String mapping, String oid)
	{
		this.messageMap.put(mapping, oid);
	}
  
	protected void setExceptionMap(String mapping, String oid)
	{
		try
		{
			Class exClass = Class.forName(mapping);
			this.exceptionMap.put(exClass, oid);
		}
		catch (Throwable t) {}
	}
  
	public String getDefaultOid()
	{
		return this.defaultOid;
	}
  
	public void setDefaultOid(String defaultOid)
	{
		this.defaultOid = defaultOid;
	}
}


