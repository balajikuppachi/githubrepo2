package com.wellsfargo.regulatory.log4j.pattern;

/******************************************************************************
 * Filename    : RegulatoryPatternParser.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.helpers.PatternParser;

public class RegulatoryPatternParser extends PatternParser
{
	  private static final char MEMORY_USED = 'u';
	  private static final char MEMORY_FREE = 'f';
	  private static final char NUM_ACTIVE_THREADS = 'a';
	  private static final char JVM_UPTIME = 'v';
	  private static final char SYSTEM_HOST_NAME = 'h';
	  private static final char SYSTEM_MEMORY_UTILIZATION = 'U';
	  private static final char SYSTEM_CPU_UTILIZATION = 'z';
	  private static final char SYSTEM_CLASSPATH = 's';
	  private static final char BOOT_CLASSPATH = 'S';
	  private static final char EXCEPTION_STACKTRACE = 'T';
	  private static final char EXCEPTION_CLASS = 'e';
	  private static final char MAXIMUM_MEMORY = 'y';
	  private static final char DISK_SPACE_USED = 'D';
	  private static final char DISK_SPACE_FREE = 'N';
	  private static final char JMX_MBEAN_VALUE = 'A';
	  private static final char DATE_FORMAT = 'd';
	  private static final char EXCEPTION_MESSAGE = 'E';
	  private static final char ROOT_EXCEPTION_MESSAGE = 'B';
	  private static final char ROOT_EXCEPTION_CLASS = 'b';
	  private static final char ROOT_EXCEPTION_STACKTRACE = 'o';
	  
	  @SuppressWarnings("rawtypes")
	  private List regOptionList;
  
	  @SuppressWarnings("rawtypes")
	  public RegulatoryPatternParser(String pattern)
	  {
		  super(pattern);
		  this.regOptionList = new ArrayList();
		  populateOptionList();
	  }
  
	  @SuppressWarnings({ "rawtypes", "unchecked" })
	  protected void populateOptionList()
	  {
		  if (this.regOptionList == null) 
		  {
			  this.regOptionList = new ArrayList();
		  }
	  
		  this.regOptionList.add(Character.valueOf(MEMORY_USED));
		  this.regOptionList.add(Character.valueOf(MEMORY_FREE));
		  this.regOptionList.add(Character.valueOf(NUM_ACTIVE_THREADS));
		  this.regOptionList.add(Character.valueOf(JVM_UPTIME));
		  this.regOptionList.add(Character.valueOf(SYSTEM_HOST_NAME));
		  this.regOptionList.add(Character.valueOf(SYSTEM_MEMORY_UTILIZATION));
		  this.regOptionList.add(Character.valueOf(SYSTEM_CPU_UTILIZATION));
		  this.regOptionList.add(Character.valueOf(SYSTEM_CLASSPATH));
		  this.regOptionList.add(Character.valueOf(BOOT_CLASSPATH));
		  this.regOptionList.add(Character.valueOf(EXCEPTION_STACKTRACE));
		  this.regOptionList.add(Character.valueOf(EXCEPTION_CLASS));
		  this.regOptionList.add(Character.valueOf(MAXIMUM_MEMORY));
		  this.regOptionList.add(Character.valueOf(DISK_SPACE_USED));
		  this.regOptionList.add(Character.valueOf(DISK_SPACE_FREE));
		  this.regOptionList.add(Character.valueOf(JMX_MBEAN_VALUE));
		  this.regOptionList.add(Character.valueOf(DATE_FORMAT));
		  this.regOptionList.add(Character.valueOf(EXCEPTION_MESSAGE));
		  this.regOptionList.add(Character.valueOf(ROOT_EXCEPTION_MESSAGE));
		  this.regOptionList.add(Character.valueOf(ROOT_EXCEPTION_CLASS));
		  this.regOptionList.add(Character.valueOf(ROOT_EXCEPTION_STACKTRACE));
	  }
  
  protected void finalizeConverter(char c)
  {
	  if (this.regOptionList.contains(Character.valueOf(c)))
	  {
		  
		  RegulatoryPatternConverter next = new RegulatoryPatternConverter(c);
		  
		  if ((c == DISK_SPACE_USED) || (c == DISK_SPACE_FREE) || (c == JMX_MBEAN_VALUE) || (c == DATE_FORMAT)) 
		  {
			  next.setOption(extractOption());
		  }
		  
		  addConverter(next);
	  }
	  else
	  {
		  super.finalizeConverter(c);
	  }
  }
  
}
