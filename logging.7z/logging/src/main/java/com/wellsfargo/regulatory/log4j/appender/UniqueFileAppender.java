package com.wellsfargo.regulatory.log4j.appender;

/******************************************************************************
 * Filename    : UniqueFileAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.io.IOException;

import org.apache.log4j.FileAppender;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

import com.wellsfargo.regulatory.log4j.layout.RegulatoryLayout;

public class UniqueFileAppender extends FileAppender
{
	private String fileNamePattern = "/thread_%t_%d{dd.MMM.yyyy.HH.mm.ss.SSS}.log";
  
	public void append(LoggingEvent event)
	{
		try
		{
			RegulatoryLayout layout = new RegulatoryLayout();
			layout.setConversionPattern(getFileNamePattern());
			String fileName = layout.format(event);
      
			super.closeFile();
			super.setFile(fileName, this.fileAppend, this.bufferedIO, this.bufferSize);
			super.append(event);
		}
		catch (IOException ioe)
		{
			this.errorHandler.error("setFile(" + this.fileName + "," + this.fileAppend + ") call failed.", ioe, 4);
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered logging unique file message", t);
		}
	}
  
	public String getFileNamePattern()
	{
		return this.fileNamePattern;
	}
  
	public void setFileNamePattern(String fileNamePattern)
	{
		this.fileNamePattern = fileNamePattern;
	}
  
	public void activateOptions()
	{
		if (this.fileName != null) 
		{
			try
			{
				setFile(this.fileName, this.fileAppend, this.bufferedIO, this.bufferSize);
			}
			catch (IOException e)
			{
				this.errorHandler.error("setFile(" + this.fileName + "," + this.fileAppend + ") call failed.", e, 4);
			}
		}
	}
}


