package com.wellsfargo.regulatory.log4j.appender.jdbc;

/******************************************************************************
 * Filename    : JDBCAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.ErrorHandler;
import org.apache.log4j.spi.LoggingEvent;

public class JDBCAppender extends org.apache.log4j.jdbc.JDBCAppender
{
	private String jndiName;
	private DataSource dataSource;
	private Context ctx;
  
	public String getJndiName()
	{
		return this.jndiName;
	}
  
	public void setJndiName(String jndiName)
	{
		this.jndiName = jndiName;
	}
  
	protected Connection getConnection() throws SQLException
	{
		if (this.jndiName != null)
		{
			if (this.connection != null) 
			{
				return this.connection;
			}
			
			try
			{
				if (this.ctx == null) 
				{
					this.ctx = new InitialContext();
				}
				if (this.dataSource == null) 
				{
					this.dataSource = ((DataSource)this.ctx.lookup(getJndiName()));
				}
				this.connection = this.dataSource.getConnection(getUser(), getPassword());
				return this.connection;
			}
			catch (NamingException ne)
			{
				LogLog.error("JNDI context not initialized correctly", ne);
				throw new SQLException("Could not setup JNDI context");
			}
			catch (Throwable t)
			{
				LogLog.error("JNDI context not initialized correctly", t);
			}
		}
		
		try
		{
			return super.getConnection();
		}
		catch (Throwable t)
		{
			LogLog.error("Could not connect to the database", t);
		}
		
		return null;
	}
  
	protected void closeConnection(Connection con)
	{
		if (con == null) 
		{
			return;
		}
		
		if ((this.jndiName == null) || (this.dataSource == null)) 
		{
			return;
		}
		
		try
		{
			if (!con.isClosed())
			{
				con.close();
				this.connection = null;
			}
		}
		catch (SQLException sqle)
		{
			LogLog.warn("Problem returning connection to the pool", sqle);
		}
		catch (Throwable t)
		{
			LogLog.warn("Problem returning connection to the pool", t);
		}
	}
  
	protected void execute(String sql) throws SQLException
	{
		Connection con = null;
		Statement stmt = null;
		
		try
		{
			con = getConnection();
			if (con == null) 
			{
				LogLog.warn("Could not execute sql : " + sql + " - connection is null");
			}
			
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			con.commit(); return;
		}
		catch (SQLException e)
		{
			LogLog.error("Exception encountered executing statement: " + sql, e);
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered executing statement: " + sql, t);
		}
		finally
		{
			try
			{
				if (stmt != null) 
				{
					stmt.close();
				}
			}
			catch (Throwable t)
			{
				LogLog.error("Could not close statement", t);
			}
			try
			{
				closeConnection(con);
			}
			catch (Throwable t)
			{
				LogLog.error("Could not close connection", t);
			}
		}	
	}
  
	public void setDriver(String driverClass)
	{
		try
		{
			Class.forName(driverClass);
		}
		catch (Throwable t)
		{
			LogLog.warn("Failed to load driver " + driverClass, t);
		}
	}
  
	public void flushBuffer()
	{
		try
		{
			this.removes.ensureCapacity(this.buffer.size());
			for (Iterator i = this.buffer.iterator(); i.hasNext();) 
			{
				try
				{
					LoggingEvent logEvent = (LoggingEvent)i.next();
					String sql = getLogStatement(logEvent);
					execute(sql);
					this.removes.add(logEvent);
				}
				catch (SQLException e)
				{
					this.errorHandler.error("Failed to excute sql", e, 2);
				}
			}
		}
		catch (Throwable t)
		{
			Iterator i;
			LogLog.warn("Exception encountered", t);
		}
		finally
		{
			this.buffer.removeAll(this.removes);
			this.removes.clear();
		}
	}
}


