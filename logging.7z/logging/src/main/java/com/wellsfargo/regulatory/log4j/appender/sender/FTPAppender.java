package com.wellsfargo.regulatory.log4j.appender.sender;

/******************************************************************************
 * Filename    : FTPAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.spi.ErrorHandler;
import org.apache.log4j.spi.LoggingEvent;

import com.wellsfargo.regulatory.log4j.pattern.RegulatoryPatternParser;

public class FTPAppender extends AppenderSkeleton
{
	private String hostName;
	private String remoteDirectory;
	private String localDirectory;
	private String fileName;
	private String password;
	private String userName;
	private String remoteFileName;
  
	protected void append(LoggingEvent event)
	{
		if (event == null) 
		{
			return;
		}
		
		if ((this.hostName == null) || (this.password == null) || (this.userName == null)) 
		{
			return;
		}
		
		FTPClient client = null;
		InputStream inputStream = null;
		
		try
		{
			String fileName = getFileName();
			fileName = convertContent(fileName, event);
			String remoteFileName = getRemoteFileName();
			
			if ((remoteFileName != null) && (remoteFileName.length() > 0)) 
			{
				remoteFileName = convertContent(remoteFileName, event);
			}
			
			if ((getLocalDirectory() != null) && (getLocalDirectory().length() > 0))
			{
				String localDir = convertContent(getLocalDirectory(), event);
				inputStream = new FileInputStream(new File(localDir, fileName));
			}
			else
			{
				String msg = event.getRenderedMessage();
				inputStream = new ByteArrayInputStream(msg.getBytes());
			}
			
			client = new FTPClient();
			client.connect(this.hostName);
      
			checkReplyCode(client, "connect");
			
			if (getUserName() != null) 
			{        
				client.login(getUserName(), getPassword());
			}
			
			checkReplyCode(client, "login");
      
			client.setFileType(2);
			
			if (getRemoteDirectory() != null) 
			{
				client.changeWorkingDirectory(getRemoteDirectory());
			}
			
			checkReplyCode(client, "change directory");
			
			if ((remoteFileName != null) && (remoteFileName.length() > 0)) 
			{
				fileName = remoteFileName;
			}
			
			client.storeFile(fileName, inputStream);
		}
		catch (IOException ioe)
		{
			getErrorHandler().error("IOException encountered processing ftp for host:" + this.hostName + " message: " + ioe.getMessage());
		}
		catch (Throwable t)
		{
			LogLog.warn("Could not process ftp send", t);
		}
		finally
		{
			if ((client != null) && (client.isConnected())) 
			{
				try
				{
					client.disconnect();
				}
				catch (IOException ioe)
				{
					getErrorHandler().error("IOException encountered processing ftp for host:" + this.hostName + " message: " + ioe.getMessage());
				}
				catch (Throwable t)
				{
					LogLog.warn("Could not disconnect from client", t);
				}
			}
			if (inputStream != null) 
			{
				try
				{
					inputStream.close();
				}
				catch (IOException ioe)
				{
					getErrorHandler().error("IOException encountered processing ftp for host:" + this.hostName + " message: " + ioe.getMessage());
				}
				catch (Throwable t)
				{
					LogLog.warn("Could not close input stream", t);
				}
			}
		}
	}
  
	protected String convertContent(String string, LoggingEvent le)
	{
		if ((string == null) || (le == null)) 
		{
			return string;
		}
    
		StringBuffer out = new StringBuffer();
		RegulatoryPatternParser parser = new RegulatoryPatternParser(string);
		PatternConverter pc = parser.parse();
		
		while (pc != null)
		{
			pc.format(out, le);
			pc = pc.next;
		}
		
		return out.toString();
	}
  
	public void close() {}
  
	public boolean requiresLayout()
	{
		return false;
	}
  
	private void checkReplyCode(FTPClient client, String operation)
	{
		int replyCode = client.getReplyCode();
		if (!FTPReply.isPositiveCompletion(replyCode)) 
		{
			getErrorHandler().error("Negative reply code: " + replyCode + " received from FTP host while performing: " + operation);
		}
	}
  
	public String getHostName()
	{
		return this.hostName;
	}
  
	public void setHostName(String hostName)
	{
		this.hostName = hostName;
	}
  
	public String getLocalDirectory()
	{
		return this.localDirectory;
	}
  
	public void setLocalDirectory(String localDirectory)
	{
		this.localDirectory = localDirectory;
	}
  
	public String getFileName()
	{
		return this.fileName;
	}
  
	public void setFileName(String localFileName)
	{
		this.fileName = localFileName;
	}
  
	public String getPassword()
	{
		return this.password;
	}
  
	public void setPassword(String password)
	{
		this.password = password;
	}
  
	public String getRemoteDirectory()
	{
		return this.remoteDirectory;
	}
  
	public void setRemoteDirectory(String remoteDirectory)
	{
		this.remoteDirectory = remoteDirectory;
	}
  
	public String getUserName()
	{
		return this.userName;
	}
  
	public void setUserName(String userName)
	{
		this.userName = userName;
	}
  
	public String getRemoteFileName()
	{
		return this.remoteFileName;
	}
  
	public void setRemoteFileName(String remoteFileName)
	{
		this.remoteFileName = remoteFileName;
	}
}

