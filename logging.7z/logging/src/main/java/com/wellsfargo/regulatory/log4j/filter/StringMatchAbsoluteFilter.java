package com.wellsfargo.regulatory.log4j.filter;

/******************************************************************************
 * Filename    : StringMatchAbsoluteFilter.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.varia.StringMatchFilter;

public class StringMatchAbsoluteFilter extends StringMatchFilter
{
	@SuppressWarnings("rawtypes")
	private List filterStrings;
	private boolean lastFilter = false;
  
	@SuppressWarnings("rawtypes")
	public StringMatchAbsoluteFilter()
	{
		this.filterStrings = new ArrayList();
	}
  
	public int decide(LoggingEvent event)
	{
		String msg = event.getRenderedMessage();
		if (msg == null) 
		{
			return -1;
		}
		
		if (getStringToMatch() != null) 
		{
			return decideString(getStringToMatch(), msg);
		}
		
		for (int i = 0; i < this.filterStrings.size(); i++)
		{
			int interimDecision = decideFromStrings(this.filterStrings.get(i).toString(), msg);
			if (interimDecision != 0) 
			{
				return interimDecision;
			}
		}
		
		if (this.lastFilter) 
		{
			return -1;
		}
		
		return 0;
	}
  
	protected int decideFromStrings(String toDecide, String msg)
	{
		if (msg.indexOf(toDecide) == -1) 
		{
			return 0;
		}
		
		return decideString(toDecide, msg);
	}
  
	protected int decideString(String toDecide, String msg)
	{
		if (msg.indexOf(toDecide) == -1) 
		{
			return -1;
		}
		
		if (getAcceptOnMatch()) 
		{
			return 1;
		}
		
		return -1;
	}
  
	@SuppressWarnings("unchecked")
	public void setFilterString(String filter)
	{
		if ((this.filterStrings != null) && (filter != null)) 
		{
			this.filterStrings.add(filter);
		}
	}
  
	@SuppressWarnings("rawtypes")
	public List getFilterStrings()
	{
		return this.filterStrings;
	}
  
	public boolean getLastFilter()
	{
		return this.lastFilter;
	}
  
	public void setLastFilter(boolean lastFilter)
	{
		this.lastFilter = lastFilter;
	}
}
