package com.wellsfargo.regulatory.log4j.appender.config;

/******************************************************************************
 * Filename    : ConfigurationAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.Enumeration;
import java.util.Properties;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

public abstract class ConfigurationAppender extends AppenderSkeleton
{
	protected void append(LoggingEvent event) {}
  
	public void close() {}
  
	public boolean requiresLayout()
	{
		return false;
	}
  
	protected void setupSystemProperties(Properties props)
	{
		if (props == null) 
		{
			return;
		}
		
		try
		{
			Enumeration e = props.keys();
			while (e.hasMoreElements())
			{
				String key = (String)e.nextElement();
				System.setProperty(key, props.getProperty(key));
			}
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered setting system props", t);
		}
	}
}


