package com.wellsfargo.regulatory.log4j.appender.trigger;

/******************************************************************************
 * Filename    : ThresholdAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Appender;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.helpers.AppenderAttachableImpl;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.AppenderAttachable;
import org.apache.log4j.spi.ErrorHandler;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.ThrowableInformation;

@SuppressWarnings("rawtypes")
public class ThresholdAppender extends AppenderSkeleton implements AppenderAttachable
{
	private Map stringThresholdMap;
	private Map classThresholdMap;
	private int thresholdNumber = 10;
	private AppenderAttachableImpl appenders;
  
	public ThresholdAppender()
	{
		this.stringThresholdMap = new HashMap();
		this.classThresholdMap = new HashMap();
		this.appenders = new AppenderAttachableImpl();
	}
  
	protected void append(LoggingEvent event)
	{
		if (event == null) 
		{
			return;
		}
		
		try
		{
			boolean exceptionResult = false;
      
			ThrowableInformation info = event.getThrowableInformation();
			if (info != null)
			{
				Throwable t = info.getThrowable();
				if (t != null) 
				{
					exceptionResult = handleExceptionThreshold(t, event);
				}
			}
			
			Object obj = event.getMessage();
			if (obj == null) 
			{
				return;
			}
			
			if (!exceptionResult) 
			{
				if (Throwable.class.isAssignableFrom(obj.getClass())) 
				{
					exceptionResult = handleExceptionThreshold((Throwable)obj, event);
				}
			}
      
			if (!exceptionResult) 
			{
				handleStringThreshold(obj.toString(), event);
			}
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered logging event", t);
		}
	}
  
	protected void handleStringThreshold(String id, LoggingEvent event)
	{
		if ((id == null) || (event == null)) 
		{
			return;
		}
		
		if (checkThreshold(id, this.stringThresholdMap)) 
		{
			sendToAppenders(event);
		}
	}
  
	protected boolean handleExceptionThreshold(Throwable t, LoggingEvent event)
	{
		if ((t == null) || (event == null)) 
		{
			return false;
		}
		
		if (this.classThresholdMap.containsKey(t.getClass()))
		{
			if (checkThreshold(t.getClass(), this.classThresholdMap)) 
			{
				sendToAppenders(event);
			}
			
			return true;
		}
		
		Set keySet = this.classThresholdMap.keySet();
		Iterator iter = keySet.iterator();
		while (iter.hasNext())
		{
			Class claz = (Class)iter.next();
			if (claz.isAssignableFrom(t.getClass()))
			{
				if (checkThreshold(claz, this.classThresholdMap)) 
				{
					sendToAppenders(event);
				}
				return true;
			}
		}
		return false;
	}
  
	protected void sendToAppenders(LoggingEvent event)
	{
		if (event == null) 
		{
			return;
		}
		
		try
		{
			Enumeration enumerator = getAllAppenders();
			if (enumerator == null) 
			{
				return;
			}
			
			while (enumerator.hasMoreElements())
			{
				Appender appender = (Appender)enumerator.nextElement();
				if (appender != null) 
				{
					appender.doAppend(event);
				}
			}
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered sending to appenders", t);
		}
	}
  
	protected boolean checkThreshold(Object key, Map thresholdMap)
	{
		if ((key == null) || (thresholdMap == null)) 
		{
			return false;
		}
		
		if (thresholdMap.isEmpty()) 
		{
			return false;
		}
		
		Integer currentThreshold = new Integer(0);
		if (thresholdMap.containsKey(key))
		{
			currentThreshold = (Integer)thresholdMap.get(key);
			currentThreshold = new Integer(currentThreshold.intValue() + 1);
			thresholdMap.put(key, currentThreshold);
			
			if (currentThreshold.intValue() >= this.thresholdNumber)
			{
				currentThreshold = new Integer(0);
				thresholdMap.put(key, currentThreshold);
				return true;
			}
		}
		
		return false;
	}
  
	public void close()
	{
		Enumeration enumerator = getAllAppenders();
		if (enumerator == null) 
		{
			return;
		}
		
		try
		{
			while (enumerator.hasMoreElements())
			{
				Appender appender = (Appender)enumerator.nextElement();
				if (appender != null) 
				{
					appender.close();
				}
			}
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered closing appender", t);
		}
	}
  
	public boolean requiresLayout()
	{
		return false;
	}
  
	public void addAppender(Appender newAppender)
	{
		if (newAppender == null) 
		{
			return;
		}
		this.appenders.addAppender(newAppender);
	}
  
	public Enumeration getAllAppenders()
	{
		return this.appenders.getAllAppenders();
	}
  
	public Appender getAppender(String name)
	{
		return this.appenders.getAppender(name);
	}
  
	public boolean isAttached(Appender appender)
	{
		return this.appenders.isAttached(appender);
	}
  
	public void removeAllAppenders()
	{
		this.appenders.removeAllAppenders();
	}
  
	public void removeAppender(Appender appender)
	{
		this.appenders.removeAppender(appender);
	}
  
	public void removeAppender(String name)
	{
		this.appenders.removeAppender(name);
	}
  
	public void setStringFilter(String filter)
	{
		this.stringThresholdMap.put(filter, new Integer(0));
	}
  
	public void setClassFilter(String clazz)
	{
		try
		{
			Class theClass = Class.forName(clazz);
			this.classThresholdMap.put(theClass, new Integer(0));
		}
		catch (Throwable t)
		{
			super.getErrorHandler().error("Could not obtain class for: " + clazz + ".  Exception encountered: " + t.getClass().getName() + " Exception message: " + t.getMessage());
		}
	}
  
	public void setThresholdAmount(String amount)
	{
		if (amount == null) 
		{
			return;
		}
		
		if (amount.length() == 0) 
		{
			return;
		}
		
		try
		{
			this.thresholdNumber = Integer.parseInt(amount);
		}
		catch (NumberFormatException nfe)
		{
			getErrorHandler().error("Invalid configuration for threshold amount: " + amount + " is not an integer!");
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered parsing number threshold: " + amount, t);
		}
	}
}

