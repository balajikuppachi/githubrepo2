package com.wellsfargo.regulatory.log4j.layout;

/******************************************************************************
 * Filename    : SystemInformationLayout.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.lang.management.ClassLoadingMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.OperatingSystemMXBean;
import java.lang.management.RuntimeMXBean;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.net.InetAddress;
import java.net.UnknownHostException;
import org.apache.log4j.Layout;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

public class SystemInformationLayout extends Layout
{
	public void activateOptions() {}
  
	public String format(LoggingEvent event)
	{
		if (event == null) 
		{
			return "";
		}
		
		StringBuffer out = new StringBuffer();
		try
		{
			if (event.getMessage() != null)
			{
				String msg = event.getMessage().toString();
				if (msg.length() > 0) 
				{
					out.append("[Message] " + msg);
				}
			}
			
			out.append(getSystemInformation());
			out.append(getMemoryUsageInformation());
			out.append(getClassLoaderInformation());
			out.append(getRuntimeInformation());
			out.append(getThreadInformation());
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered formatting event", t);
		}
		
		return out.toString();
	}
  
	private String getThreadInformation()
	{
		StringBuffer out = new StringBuffer();
    
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
    
		out.append(" [ThreadInformation] ");
		out.append(" [ActiveThreadCount] " + bean.getThreadCount());
		out.append(" [TotalThreadCount] " + bean.getTotalStartedThreadCount());
    
		long[] pids = bean.getAllThreadIds();
		for (int i = 0; i < pids.length; i++)
		{
			long pid = pids[i];
			ThreadInfo info = bean.getThreadInfo(pid, 50);
			out.append(" [ThreadId] " + pid);
			out.append(" [ThreadName] " + info.getThreadName());
			out.append(" [CPU Time] " + bean.getThreadCpuTime(pid));
			out.append(" [Total Time] " + bean.getThreadUserTime(pid));
			out.append(" [Stack Trace] " + info.getStackTrace());
		}
		
		long[] deadlockedthreads = bean.findMonitorDeadlockedThreads();
		if (deadlockedthreads == null) 
		{
			deadlockedthreads = new long[0];
		}
		
		for (int i = 0; i < deadlockedthreads.length; i++) 
		{
			out.append("[DeadlockedThread] " + deadlockedthreads[i]);
		}
		
		return out.toString();
	}
  
	private String getRuntimeInformation()
	{
		StringBuffer out = new StringBuffer();
		RuntimeMXBean bean = ManagementFactory.getRuntimeMXBean();

		out.append(" [Boot Classpath] " + bean.getBootClassPath());
		out.append(" [Classpath] " + bean.getClassPath());
		out.append(" [Library Path] " + bean.getLibraryPath());
		out.append(" [Start Time] " + bean.getStartTime());
		out.append(" [Uptime] " + bean.getUptime());
		out.append(" [VM Name] " + bean.getVmName());
		out.append(" [VM Vendor] " + bean.getVmVendor());
		out.append(" [VM Version] " + bean.getVmVersion());
		out.append(" [System Properties] " + bean.getSystemProperties());

		return out.toString();
	}
  
	private String getClassLoaderInformation()
	{
		StringBuffer out = new StringBuffer();
    
		ClassLoadingMXBean bean = ManagementFactory.getClassLoadingMXBean();
		out.append(" [Loaded Class Count] " + bean.getLoadedClassCount());
		out.append(" [Total Loaded Class Count] " + bean.getTotalLoadedClassCount());
    
		return out.toString();
	}
  
	private String getMemoryUsageInformation()
	{
		StringBuffer out = new StringBuffer();
		MemoryMXBean bean = ManagementFactory.getMemoryMXBean();
    
		out.append(" [Heap Memory Used] " + bean.getHeapMemoryUsage());
		out.append(" [NonHeap Memory Used] " + bean.getNonHeapMemoryUsage());
    
		Runtime localRuntime = Runtime.getRuntime();
		out.append(" [Free Memory]" + localRuntime.freeMemory());
		out.append(" [Max Memory]" + localRuntime.maxMemory());
		out.append(" [Total Memory]" + localRuntime.totalMemory());
    
		return out.toString();
	}
  
	private String getSystemInformation()
	{
		StringBuffer out = new StringBuffer();
		OperatingSystemMXBean bean = ManagementFactory.getOperatingSystemMXBean();
    
		out.append(" [Available Processors] " + bean.getAvailableProcessors());
		out.append(" [OS Architecture] " + bean.getArch());
		out.append(" [OS Name] " + bean.getName());
		out.append(" [OS Version] " + bean.getVersion());
		
		try
		{
			InetAddress address = InetAddress.getLocalHost();
			out.append(" [Host Name] " + address.getHostName());
			out.append(" [Host Address] " + address.getHostAddress());
		}
		catch (UnknownHostException uhe) {}
		return out.toString();
	}
  
	public boolean ignoresThrowable()
	{
		return true;
	}
}


