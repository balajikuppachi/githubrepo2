package com.wellsfargo.regulatory.log4j.filter;

/******************************************************************************
 * Filename    : NumberThresholdFilter.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.text.NumberFormat;
import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;

public class NumberThresholdFilter extends Filter
{
	public static final String FILTER_ACCEPT = "accept";
	public static final String FILTER_REJECT = "reject";
	protected long startRange = -2147483648L;
	protected long endRange = 2147483647L;
	protected String action = "accept";
  
	public int decide(LoggingEvent event)
	{
		if ((event == null) || (event.getMessage() == null)) 
		{
			return -1;
		}
		
		String msg = event.getRenderedMessage();
		if (msg == null) 
		{
			return -1;
		}
		
		if (msg.length() == 0) 
		{
			return -1;
		}
		
		try
		{
			NumberFormat format = NumberFormat.getInstance();
			Number n = format.parse(msg);
			long content = n.longValue();
			
			return performThresholding(content);
		}
		catch (Throwable t) {}
		
		return -1;
	}
	
	protected int performThresholding(long content)
	{
		boolean accept = false;
		if (this.action.equals("accept")) 
		{
			accept = true;
		}
		
		if (content < this.startRange)
		{
			if (accept) 
			{
				return -1;
			}
			
			return 1;
		}
		
		if (content > this.endRange)
		{
			if (accept) 
			{
				return -1;
			}
			
			return 1;
		}
		
		if (accept) 
		{
			return 1;
		}
		
		return -1;
	}
  
	public void setAction(String action)
	{
		if (action == null) 
		{
			return;
		}
		
		if (action.equalsIgnoreCase("accept")) 
		{
			this.action = "accept";
		} 
		else if (action.equalsIgnoreCase("reject")) 
		{
			this.action = "reject";
		}
	}
  
	public void setStartRange(long range)
	{
		this.startRange = range;
	}
  
	public void setEndRange(long range)
	{
		this.endRange = range;
	}
}
