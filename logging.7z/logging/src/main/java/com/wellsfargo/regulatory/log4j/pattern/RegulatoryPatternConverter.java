package com.wellsfargo.regulatory.log4j.pattern;

/******************************************************************************
 * Filename    : RegulatoryPatternConverter.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    :
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved.
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.management.ThreadMXBean;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;

import org.apache.commons.io.FileSystemUtils;
import org.apache.log4j.helpers.AbsoluteTimeDateFormat;
import org.apache.log4j.helpers.DateTimeDateFormat;
import org.apache.log4j.helpers.ISO8601DateFormat;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.helpers.OptionConverter;
import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.ThrowableInformation;


public class RegulatoryPatternConverter extends PatternConverter
{
	private static final char MEMORY_USED = 'u';
	private static final char MEMORY_FREE = 'f';
	private static final char NUM_ACTIVE_THREADS = 'a';
	private static final char JVM_UPTIME = 'v';
	private static final char SYSTEM_HOST_NAME = 'h';
	private static final char SYSTEM_MEMORY_UTILIZATION = 'U';
	private static final char SYSTEM_CPU_UTILIZATION = 'z';
	private static final char SYSTEM_CLASSPATH = 's';
	private static final char BOOT_CLASSPATH = 'S';
	private static final char EXCEPTION_STACKTRACE = 'T';
	private static final char EXCEPTION_CLASS = 'e';
	private static final char MAXIMUM_MEMORY = 'y';
	private static final char DISK_SPACE_USED = 'D';
	private static final char DISK_SPACE_FREE = 'N';
	private static final char JMX_MBEAN_VALUE = 'A';
	private static final char DATE_FORMAT = 'd';
	private static final char EXCEPTION_MESSAGE = 'E';
	private static final char ROOT_EXCEPTION_MESSAGE = 'B';
	private static final char ROOT_EXCEPTION_CLASS = 'b';
	private static final char ROOT_EXCEPTION_STACKTRACE = 'o';

	private char patternInfo;
	private String option;

	public RegulatoryPatternConverter(char patternInfo)
	{
		this.patternInfo = patternInfo;
	}

	@SuppressWarnings("deprecation")
	protected String convert(LoggingEvent event)
	{
		try
		{
			Runtime localRuntime = Runtime.getRuntime();
			String osName = System.getProperty("os.name");
			MBeanServer server = getMBeanServer();

			if (this.patternInfo == MEMORY_USED)
			{
				return String.valueOf(localRuntime.totalMemory() - localRuntime.freeMemory());
			}

			if (this.patternInfo == MEMORY_FREE)
			{
				return String.valueOf(localRuntime.freeMemory());
			}

			if (this.patternInfo == NUM_ACTIVE_THREADS)
			{
				ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
				return String.valueOf(threadBean.getThreadCount());
			}

			if (this.patternInfo == JVM_UPTIME)
			{
				RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
				return String.valueOf(runtimeBean.getUptime());
			}

			if (this.patternInfo == SYSTEM_HOST_NAME)
			{
				return getHostName();
			}

			if (this.patternInfo == SYSTEM_MEMORY_UTILIZATION)
			{
				double usedMem = localRuntime.totalMemory() - localRuntime.freeMemory();
				double totalMem = localRuntime.totalMemory();
				double memUtil = usedMem / totalMem * 100.0D;
				return String.valueOf(memUtil);
			}

			if (this.patternInfo == SYSTEM_CPU_UTILIZATION)
			{
				return String.valueOf(getCPUUtilization());
			}

			if (this.patternInfo == SYSTEM_CLASSPATH)
			{
				RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
				return runtimeBean.getClassPath();
			}

			if (this.patternInfo == BOOT_CLASSPATH)
			{
				RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
				return runtimeBean.getBootClassPath();
			}

			if (this.patternInfo == EXCEPTION_STACKTRACE)
			{
				Throwable t = getThrowable(event);
				if (t == null)
				{
					LogLog.warn("No exception encountered for logging event");
					return "";
				}
				return getStackTrace(t);
			}

			if (this.patternInfo == EXCEPTION_CLASS)
			{
				Throwable t = getThrowable(event);
				if (t == null)
				{
					LogLog.warn("No exception encountered for logging event");
					return "";
				}
				return t.getClass().getName();
			}

			if (this.patternInfo == MAXIMUM_MEMORY)
			{
				return String.valueOf(localRuntime.totalMemory());
			}

			if (this.patternInfo == DISK_SPACE_FREE)
			{
				if ((getOption() == null) || (getOption().length() == 0))
				{
					LogLog.warn("Requires option to be set: %N{directory}");
					return "";
				}
				try
				{
					return String.valueOf(FileSystemUtils.freeSpace(getOption()));
				}
				catch (IOException ioe)
				{
					LogLog.warn("IOException encountered obtaining free space of directory", ioe);

					return "";
				}
			}

			if (this.patternInfo == DISK_SPACE_USED)
			{
				if ((getOption() == null) || (getOption().length() == 0))
				{
					LogLog.warn("Requires option to be set: %D{directory}");
					return "";
				}
				if (osName.startsWith("Windows"))
				{
					return getWindowsDiskSpaceUsed(getOption());
				}
				return getUnixDiskSpaceUsed(getOption());
			}

			if (this.patternInfo == JMX_MBEAN_VALUE)
			{
				if ((getOption() == null) || (getOption().length() == 0))
				{
					LogLog.warn("Requires option to be set: %A{mbeanName|attribute}");
					return "";
				}

				String option = getOption();
				StringTokenizer tokens = new StringTokenizer(option, "|");
				if (tokens.countTokens() != 2)
				{
					LogLog.warn("Check configuration of JMX Mbean option, expected option is mbeanName|attribute");
					return "";
				}

				Object mBeanNameObj = tokens.nextElement();
				if (mBeanNameObj == null)
				{
					LogLog.warn("Null JMX mbean name");
					return "";
				}

				Object attributeObj = tokens.nextElement();
				if (attributeObj == null)
				{
					LogLog.warn("Null JMX mbean attribute");
					return "";
				}

				try
				{
					if (server == null)
					{
						LogLog.warn("Could not obtain MBean Server, returning empty value");
						return "";
					}
					return String.valueOf(server.getAttribute(new ObjectName(mBeanNameObj.toString()), attributeObj.toString()));
				}
				catch (Throwable t)
				{
					LogLog.warn("Exception encountered obtaining JMX attribute value", t);
				}
			}
			else
			{
				if (this.patternInfo == DATE_FORMAT)
				{
					Date date = new Date();
					date.setTime(event.timeStamp);
					DateFormat format = getDateFormat();
					return format.format(date);
				}

				if (this.patternInfo == EXCEPTION_MESSAGE)
				{
					Throwable t = getThrowable(event);
					if (t == null)
					{
						LogLog.warn("No exception encountered for logging event");
						return "";
					}
					return t.getMessage();
				}

				if (this.patternInfo == ROOT_EXCEPTION_STACKTRACE)
				{
					Throwable t = getRootThrowable(getThrowable(event));
					if (t == null)
					{
						LogLog.warn("No exception encountered for logging event");
						return "";
					}
					return getStackTrace(t);
				}

				if (this.patternInfo == ROOT_EXCEPTION_CLASS)
				{
					Throwable t = getRootThrowable(getThrowable(event));
					if (t == null)
					{
						LogLog.warn("No exception encountered for logging event");
						return "";
					}
					return t.getClass().getName();
				}

				if (this.patternInfo == ROOT_EXCEPTION_MESSAGE)
				{
					Throwable t = getRootThrowable(getThrowable(event));
					if (t == null)
					{
						LogLog.warn("No exception encountered for logging event");
						return "";
					}
					return t.getMessage();
				}
			}
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered translating character ", t);
		}
		return "";
	}

	protected DateFormat getDateFormat()
	{
		String dateFormatStr = "ISO8601";
		if (this.option != null)
		{
			dateFormatStr = this.option;
		}

		DateFormat format;
		if (dateFormatStr.equalsIgnoreCase("ISO8601"))
		{
			format = new ISO8601DateFormat();
		}
		else
		{
			if (dateFormatStr.equalsIgnoreCase("ABSOLUTE"))
			{
				format = new AbsoluteTimeDateFormat();
			}
			else
			{
				if (dateFormatStr.equalsIgnoreCase("DATE"))
				{
					format = new DateTimeDateFormat();
				}
				else
				{
					try
					{
						format = new SimpleDateFormat(dateFormatStr);
					}
					catch (IllegalArgumentException e)
					{
						LogLog.error("Could not instantiate SimpleDateFormat with " + dateFormatStr, e);

						format = (DateFormat)OptionConverter.instantiateByClassName("org.apache.log4j.helpers.ISO8601DateFormat", DateFormat.class, null);
					}
				}
			}
		}
		return format;
	}

	protected MBeanServer getMBeanServer()
	{
		try
		{
			List l = MBeanServerFactory.findMBeanServer(null);
			if ((l != null) && (l.size() > 0))
			{
				return (MBeanServer)l.get(0);
			}
			return MBeanServerFactory.createMBeanServer();
		}
		catch (Throwable t)
		{
			LogLog.warn("Could not create management factory", t);
			try
			{
				return ManagementFactory.getPlatformMBeanServer();
			}
			catch (Throwable t1)
			{
				LogLog.warn("Could not obtain management factory, initializing!", t1);
			}
		}
		return null;
	}


	protected String getUnixDiskSpaceUsed(String directory)
	{
		BufferedReader reader = null;
		Process process = null;
		try
		{
			Runtime runtime = Runtime.getRuntime();
			process = runtime.exec("du -s " + directory);
			if (process == null) {
				return "-1";
			}
			reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

			String nextLine = null;
			int startIdx;
			while ((nextLine = reader.readLine()) != null)
			{
				if (nextLine.endsWith(directory))
				{
					nextLine = nextLine.trim();
					startIdx = nextLine.indexOf(directory);
					String str2;
					if (startIdx == -1)
					{
						return "-1";
					}
					nextLine = nextLine.substring(0, startIdx);
					nextLine = nextLine.trim();
					return nextLine;
				}
			}
			return "-1";
		}
		catch (Throwable t)
		{
			String nextLine;
			return "-1";
		}
		finally
		{
			if (reader != null) {
				try
				{
					reader.close();
				}
				catch (IOException ioe) {}
			}
			if (process != null)
			{
				process.destroy();
			}
		}
	}

	protected String getWindowsDiskSpaceUsed(String directory)
	{
		BufferedReader reader = null;
		Process process = null;
		try
		{
			Runtime runtime = Runtime.getRuntime();
			process = runtime.exec("cmd.exe /c dir " + directory);
			if (process == null)
			{
				return "-1";
			}
			reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

			String nextLine = null;
			int startIdx;
			while ((nextLine = reader.readLine()) != null)
			{
				if (nextLine.indexOf("bytes") != -1)
				{
					nextLine = nextLine.trim();

					startIdx = nextLine.indexOf("(s)") + 3;
					int endIdx = nextLine.indexOf("bytes");
					String str2;
					if ((startIdx == -1) || (endIdx == -1) || (startIdx > endIdx))
					{
						return "-1";
					}
					nextLine = nextLine.substring(startIdx, endIdx);
					nextLine = nextLine.replaceAll(",", "");
					nextLine = nextLine.trim();

					return nextLine;
				}
			}
			return "-1";
		}
		catch (Throwable t)
		{
			String nextLine;
			return "-1";
		}
		finally
		{
			if (reader != null) {
				try
				{
					reader.close();
				}
				catch (IOException ioe) {}
			}
			if (process != null)
			{
				process.destroy();
			}
		}
	}

	protected double getCPUUtilization()
	{
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
		if (bean == null)
		{
			return -1.0D;
		}

		ThreadGroup group = Thread.currentThread().getThreadGroup();
		Thread[] threads = new Thread[group.activeCount()];
		group.enumerate(threads);

		double cpuUtil = 0.0D;
		for (int i = 0; i < threads.length; i++)
		{
			cpuUtil += bean.getThreadCpuTime(threads[i].getId());
		}

		RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();

		cpuUtil /= 1000000.0D;

		double startTime = runtime.getUptime();

		double percent = cpuUtil / startTime * 100.0D;
		if (percent > 100.0D)
		{
			return 100.0D;
		}

		return percent;
	}

	private String getHostName()
	{
		try
		{
			InetAddress address = InetAddress.getLocalHost();

			return address.getHostName();
		}
		catch (UnknownHostException uhe) {}

		return "Unkown Host Name";
	}

	private String getStackTrace(Throwable t)
	{
		if (t == null)
		{
			return "";
		}

		StringWriter stringWriter = new StringWriter();
		PrintWriter writer = new PrintWriter(stringWriter);
		t.printStackTrace(writer);

		StringBuffer out = new StringBuffer();

		out.append(t.getMessage());
		out.append(stringWriter.toString());

		return out.toString();
	}

	private Throwable getThrowable(LoggingEvent event)
	{
		Throwable exception = null;
		ThrowableInformation info = event.getThrowableInformation();

		if (info != null)
		{
			exception = info.getThrowable();
		}
		else
		{
			Object msg = event.getMessage();
			if (Throwable.class.isAssignableFrom(msg.getClass()))
			{
				exception = (Throwable)msg;
			}
		}
		return exception;
	}

	private Throwable getRootThrowable(Throwable t)
	{
		Throwable out = null;
		if (t == null)
		{
			return out;
		}

		Throwable nextException = t.getCause();
		while (nextException != null)
		{
			out = nextException;
			nextException = nextException.getCause();
		}

		if (out == null)
		{
			out = t;
		}

		return out;
	}

	public String getOption()
	{
		return this.option;
	}

	public void setOption(String option)
	{
		this.option = option;
	}

}

