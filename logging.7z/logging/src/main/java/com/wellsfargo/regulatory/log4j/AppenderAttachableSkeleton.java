package com.wellsfargo.regulatory.log4j;

/******************************************************************************
 * Filename    : AppenderAttachableSkeleton.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.Enumeration;
import org.apache.log4j.Appender;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.helpers.AppenderAttachableImpl;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.AppenderAttachable;
import org.apache.log4j.spi.LoggingEvent;

public abstract class AppenderAttachableSkeleton extends AppenderSkeleton implements AppenderAttachable 
{
	private AppenderAttachableImpl appenders;

	public AppenderAttachableSkeleton() 
	{
		this.appenders = new AppenderAttachableImpl();
	}

	protected void append(LoggingEvent event) 
	{
		if (event == null) {
			return;
		}
		
		try 
		{
			sendToAppenders(event);
		} 
		catch (Throwable t) 
		{
			LogLog.warn("Exception encountered processing logging event", t);
		}
	}

	public void addAppender(Appender newAppender) 
	{
		if (newAppender == null) 
		{
			return;
		}
		
		this.appenders.addAppender(newAppender);
	}

	public Enumeration getAllAppenders() {
		return this.appenders.getAllAppenders();
	}

	public Appender getAppender(String name) {
		return this.appenders.getAppender(name);
	}

	public boolean isAttached(Appender appender) {
		return this.appenders.isAttached(appender);
	}

	public void removeAllAppenders() {
		this.appenders.removeAllAppenders();
	}

	public void removeAppender(Appender appender) {
		this.appenders.removeAppender(appender);
	}

	public void removeAppender(String name) {
		this.appenders.removeAppender(name);
	}

	protected void sendToAppenders(LoggingEvent event) {
		if (event == null) {
			return;
		}
		try {
			Enumeration enumerator = getAllAppenders();
			if (enumerator == null) {
				return;
			}
			while (enumerator.hasMoreElements()) {
				Appender appender = (Appender) enumerator.nextElement();
				if (appender != null) {
					appender.doAppend(event);
				}
			}
		} catch (Throwable t) {
			LogLog.warn("Exception encountered sending appender event", t);
		}
	}

	public void close() {
		Enumeration enumerator = getAllAppenders();
		if (enumerator == null) {
			return;
		}
		try {
			while (enumerator.hasMoreElements()) {
				Appender appender = (Appender) enumerator.nextElement();
				if (appender != null) {
					appender.close();
				}
			}
		} catch (Throwable t) {
			LogLog.warn("Exception encountered closing appender", t);
		}
	}
}
