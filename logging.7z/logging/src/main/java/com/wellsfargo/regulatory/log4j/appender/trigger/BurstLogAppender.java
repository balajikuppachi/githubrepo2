package com.wellsfargo.regulatory.log4j.appender.trigger;

/******************************************************************************
 * Filename    : BurstLogAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.Hashtable;
import java.util.Map;
import java.util.Stack;

import org.apache.log4j.Level;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

import com.wellsfargo.regulatory.log4j.AppenderAttachableSkeleton;

public class BurstLogAppender extends AppenderAttachableSkeleton
{
	private static Map threadMap;
	private int maxSize = 30;
	private Level triggerPriority = Level.ERROR;
  
	public BurstLogAppender()
	{
		threadMap = new Hashtable();
	}
  
	public boolean requiresLayout()
	{
		return false;
	}
  
	protected void append(LoggingEvent event)
	{
		if (event == null) 
		{
			return;
		}
		
		try
		{
			addMessageToStack(event.getThreadName(), event);
			if (event.getLevel().isGreaterOrEqual(this.triggerPriority)) 
			{
				triggerStack(event);
			}
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered logging event", t);
		}
	}
  
	protected void addMessageToStack(String threadName, LoggingEvent event)
	{
		if ((threadName == null) || (event == null)) 
		{
			return;
		}
		
		try
		{
			Stack stack = null;
			if (threadMap.containsKey(threadName)) 
			{
				stack = (Stack)threadMap.get(threadName);
			} 
			else 
			{
				stack = new Stack();
			}
			
			if (stack.size() >= this.maxSize) 
			{
				stack.removeElementAt(0);
			}
			
			stack.push(event);
			threadMap.put(threadName, stack);
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered logging event", t);
		}
	}
  
	protected void triggerStack(LoggingEvent event)
	{
		if (event == null) 
		{
			return;
		}
		
		try
		{
			Stack stack = (Stack)threadMap.remove(event.getThreadName());
			if ((stack == null) || (stack.isEmpty())) 
			{
				return;
			}
			
			for (int i = 0; i < stack.size(); i++)
			{
				Object obj = stack.get(i);
				if (obj != null) 
				{
					sendToAppenders((LoggingEvent)obj);
				}
			}
		}
		catch (Throwable t)
		{
			LogLog.error("Exception encountered loggnig event", t);
		}
	}
  
	public int getMaxSize()
	{
		return this.maxSize;
	}
  
	public void setMaxSize(int maxSize)
	{
		this.maxSize = maxSize;
	}
  
	public String getTriggerPriority()
	{
		return this.triggerPriority.toString();
	}	
  
	public void setTriggerPriority(String triggerPriority)
	{
		this.triggerPriority = Level.toLevel(triggerPriority);
	}
}
