package com.wellsfargo.regulatory.log4j.appender.collector;

/******************************************************************************
 * Filename    : InstrumentationAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.Hashtable;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

import com.wellsfargo.regulatory.log4j.AppenderAttachableSkeleton;

public class InstrumentationAppender extends AppenderAttachableSkeleton 
{
	protected static Map threadMap;
	protected String startFilter;
	protected String endFilter;

	public InstrumentationAppender() 
	{
		if (threadMap == null) 
		{
			threadMap = new Hashtable();
		}
	}

	protected void sendToAppenders(LoggingEvent event) 
	{
		if (event == null) 
		{
			return;
		}
		
		try 
		{
			String msg = event.getRenderedMessage();
			if (msg == null) 
			{
				return;
			}
			
			if ((this.startFilter != null) && (msg.contains(this.startFilter))) 
			{
				threadMap.put(event.getThreadName(), new Timer(event.timeStamp));
				return;
			}
			
			if ((this.endFilter != null) && (msg.contains(this.endFilter))) 
			{
				Timer timer = (Timer) threadMap.remove(event.getThreadName());
				if (timer == null) 
				{
					return;
				}
				
				String message = String.valueOf(event.timeStamp - timer.startTime);
				event = new LoggingEvent(event.fqnOfCategoryClass, LogManager.getLogger(event.getLoggerName()), event.getLevel(), message, null);
				
				if (getLayout() != null) 
				{
					event = new LoggingEvent(event.fqnOfCategoryClass, LogManager.getLogger(event.getLoggerName()), event.getLevel(), getLayout().format(event), null);
				}
				super.sendToAppenders(event);
			}
		} 
		catch (Throwable t) 
		{
			LogLog.warn( "Exception encountered sending logging event to appenders", t);
		}
	}

	protected class Timer 
	{
		protected long startTime;

		public Timer(long time) 
		{
			this.startTime = time;
		}
	}

	public boolean requiresLayout() 
	{
		return false;
	}

	public void setStartFilter(String filter) 
	{
		this.startFilter = filter;
	}

	public void setEndFilter(String filter) 
	{
		this.endFilter = filter;
	}
}
