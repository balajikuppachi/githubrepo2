package com.wellsfargo.regulatory.log4j.filter;

/******************************************************************************
 * Filename    : TimeThresholdFilter.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;

public class TimeThresholdFilter extends Filter
{
	private long waitTime = 600000L;
	private long maxNumberOfMessages = 50L;
	private long lastMessageTimestamp = System.currentTimeMillis();
	private long counter = 0L;
  
	public int decide(LoggingEvent event)
	{
		if ((event == null) || (event.getMessage() == null)) 
		{
			return -1;
		}
		
		String msg = event.getRenderedMessage();
		if (msg == null) 
		{
			return -1;
		}
		
		if (this.counter >= this.maxNumberOfMessages) 
		{
			if (System.currentTimeMillis() - this.lastMessageTimestamp > this.waitTime) 
			{
				this.counter = 0L;
			} 
			else 
			{
				return -1;
			}
		}
		
		this.counter += 1L;
		this.lastMessageTimestamp = System.currentTimeMillis();
    
		return 1;
	}
  
	public long getMaxNumberOfMessages()
	{
		return this.maxNumberOfMessages;
	}
  
	public void setMaxNumberOfMessages(long maxNumberOfMessages)
	{
		this.maxNumberOfMessages = maxNumberOfMessages;
	}
  
	public long getWaitTime()
	{
		return this.waitTime;
	}
  
	public void setWaitTime(long waitTime)
	{
		this.waitTime = (waitTime * 60000L);
	}
}

