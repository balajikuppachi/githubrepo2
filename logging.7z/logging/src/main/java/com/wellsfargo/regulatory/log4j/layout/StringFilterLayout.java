package com.wellsfargo.regulatory.log4j.layout;

/******************************************************************************
 * Filename    : StringFilterLayout.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Layout;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

public class StringFilterLayout extends Layout
{
	public static final String OPERATION_REMOVE = "remove";
	public static final String OPERATION_APPEND = "append";
	public static final String OPERATION_PREPEND = "prepend";
	protected List filterList;
	protected String operation = "remove";
  
	public StringFilterLayout()
	{
		this.filterList = new ArrayList();
	}
  
	public void activateOptions() {}
  
	public String format(LoggingEvent event)
	{
		if (event == null) 
		{
			return "";
		}
		
		String msg = event.getRenderedMessage();
		try
		{
			if (msg == null) 
			{
				msg = "";
			}
			
			if ((this.filterList == null) || (this.filterList.isEmpty())) 
			{
				return msg;
			}
			
			if (this.operation == null) 
			{
				return msg;
			}
			
			for (int i = 0; i < this.filterList.size(); i++)
			{
				String filter = this.filterList.get(i).toString();
				if (this.operation.equalsIgnoreCase("append")) 
				{
					msg = appendFilter(filter, msg);
				} 
				else if (this.operation.equalsIgnoreCase("prepend")) 
				{
					msg = prependFilter(filter, msg);
				} 
				else if (this.operation.equalsIgnoreCase("remove")) 
				{
					msg = removeFilter(filter, msg);
				}
			}
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered", t);
		}
		
		return msg;
	}
  
	protected String removeFilter(String filter, String message)
	{
		if (filter == null) 
		{
			return message;
		}
		
		if (message == null) 
		{
			return "";
		}
		
		while (message.indexOf(filter) != -1)
		{
			int startIdx = message.indexOf(filter);
			int endIdx = filter.length() + startIdx;
			if (startIdx == 0)
			{
				message = message.substring(endIdx, message.length());
			}
			else if (endIdx > message.length())
			{
				message = message.substring(startIdx, message.length());
			}
			else
			{
				StringBuffer out = new StringBuffer();
				out.append(message.substring(0, startIdx));
				out.append(message.substring(endIdx, message.length()));
				message = out.toString();
			}
		}
		
		return message;
	}
  
	protected String prependFilter(String filter, String message)
	{
		if (filter == null) 
		{
			return message;
		}
		if (message == null) 
		{
			return filter;
		}
		
		if (!message.startsWith(filter)) 
		{
			return filter + message;
		}
		
		return message;
	}
  
	protected String appendFilter(String filter, String message)
	{
		if (filter == null) 
		{
			return message;
		}
		
		if (message == null) 
		{
			return filter;
		}
		
		if (!message.endsWith(filter)) 
		{
			return message + filter;
		}
		
		return message;
	}
  
	public boolean ignoresThrowable()
	{
		return false;
	}
  
	public void setFilter(String filter)
	{
		if (filter != null) 
		{
			this.filterList.add(filter);
		}
	}
  
	public void setOperation(String operation)
	{
		if (operation == null) 
		{
			return;
		}
		
		if (operation.length() == 0) 
		{
			return;
		}
		
		if (operation.equalsIgnoreCase("prepend")) 
		{
			this.operation = "prepend";
		} 
		else if (operation.equalsIgnoreCase("append")) 
		{
			this.operation = "append";
		}
	}
}

