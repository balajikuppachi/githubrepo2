package com.wellsfargo.regulatory.log4j.appender.trigger;

/******************************************************************************
 * Filename    : ApplicationTerminationAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

import sun.misc.Signal;
import sun.misc.SignalHandler;

import com.wellsfargo.regulatory.log4j.AppenderAttachableSkeleton;

@SuppressWarnings("restriction")
public class ApplicationTerminationAppender extends AppenderAttachableSkeleton implements SignalHandler
{
	private Logger parentLogger;
	private SignalHandler oldHandler;
	private Signal catchSig;
  
	public ApplicationTerminationAppender()
	{
		this.parentLogger = LogManager.getLogger(ApplicationTerminationAppender.class);
		
		try
		{
			String osName = System.getProperty("os.name");
			if (osName.startsWith("Windows"))
			{
				this.catchSig = new Signal("INT");
				this.oldHandler = Signal.handle(this.catchSig, this);
			}
			else if (osName.startsWith("Solaris"))
			{
				this.catchSig = new Signal("USR1");
				this.oldHandler = Signal.handle(this.catchSig, this);
			}
			else if (osName.startsWith("Linux"))
			{
				this.catchSig = new Signal("USR1");
				this.oldHandler = Signal.handle(this.catchSig, this);
			}
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered initializing ApplicationTerminationAppender", t);
		}
	}
  
	public boolean requiresLayout()
	{
		return false;
	}
  
	public void handle(Signal signal)
	{
		if (signal == null) 
		{
			return;
		}
		
		try
		{
			LoggingEvent event = new LoggingEvent(ApplicationTerminationAppender.class.getName(), this.parentLogger, Level.ALL, signal.toString(), null);
			if (getLayout() != null)
			{
				String msg = signal.toString();
				msg = getLayout().format(event);
				event = new LoggingEvent(ApplicationTerminationAppender.class.getName(), this.parentLogger, Level.ALL, msg, null);
			}
			
			sendToAppenders(event);
			
			if ((this.oldHandler != null) && (!this.catchSig.getName().equals("INT"))) 
			{
				this.oldHandler.handle(signal);
			}
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered sending logging event", t);
		}
	}
  
	protected void append(LoggingEvent event) {}
}


