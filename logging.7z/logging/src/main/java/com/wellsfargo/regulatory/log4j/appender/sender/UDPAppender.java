package com.wellsfargo.regulatory.log4j.appender.sender;

/******************************************************************************
 * Filename    : UDPAppender.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

public class UDPAppender extends AppenderSkeleton
{
	private String host;
	private String port;
  
	protected void append(LoggingEvent event)
	{
		if (event == null) 
		{
			return;
		}
		
		if ((getHost() == null) || (getHost().length() == 0) || (getPort() == null) || (getPort().length() == 0)) 
		{
			return;
		}
		
		DatagramSocket socket = null;
		try
		{
			InetAddress address = InetAddress.getByName(getHost());
			socket = new DatagramSocket();
			String msg = event.getRenderedMessage();
			
			if (getLayout() != null) 
			{
				msg = getLayout().format(event);
			}
			DatagramPacket packet = new DatagramPacket(msg.getBytes(), msg.getBytes().length, address, Integer.parseInt(getPort()));
      
			socket.send(packet); return;
		}
		catch (IOException ioe)
		{
			getErrorHandler().error("Exception encountered sending message across datagram port", ioe, 10001);
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered sending UDP trap", t);
		}
		finally
		{
			try
			{
				if (socket != null) 
				{
					socket.close();
				}
			}
			catch (Throwable t)
			{
				LogLog.warn("Exception encountered sending UDP trap", t);
			}
		}
	}
  
	public void close() {}
  
	public boolean requiresLayout()
	{
		return false;
	}
  
	public String getHost()
	{
		return this.host;
	}
  
	public void setHost(String host)
	{
		this.host = host;
	}
  
	public String getPort()
	{
		return this.port;
	}
  
	public void setPort(String port)
	{
		this.port = port;
	}
}


