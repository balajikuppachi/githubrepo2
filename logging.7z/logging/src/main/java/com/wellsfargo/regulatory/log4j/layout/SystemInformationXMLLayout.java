package com.wellsfargo.regulatory.log4j.layout;

/******************************************************************************
 * Filename    : SystemInformationXMLLayout.java
 * Author      : Rama Nuti
 * Date Created: 2014-08-11
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

import java.lang.management.ClassLoadingMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.OperatingSystemMXBean;
import java.lang.management.RuntimeMXBean;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.net.InetAddress;
import java.net.UnknownHostException;
import org.apache.log4j.Layout;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

public class SystemInformationXMLLayout extends Layout
{
	public void activateOptions() {}
  
	public String format(LoggingEvent event)
	{
		if (event == null) 
		{
			return "";
		}
			
		StringBuffer out = new StringBuffer();
		try
		{
			if (event.getMessage() != null)
			{
				String msg = event.getMessage().toString();
				if (msg.length() > 0) {
					out.append("<Message>" + msg + "</Message>");
				}
			}
			
			out.append("<Data>");
			out.append(getSystemInformation());
			out.append(getMemoryUsageInformation());
			out.append(getClassLoaderInformation());
			out.append(getRuntimeInformation());
			out.append(getThreadInformation());
			out.append("</Data>");
		}
		catch (Throwable t)
		{
			LogLog.warn("Exception encountered formatting event", t);
		}
		
		return out.toString();
	}
  
	private String getThreadInformation()
	{
		StringBuffer out = new StringBuffer();
    
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
    
		out.append("<ThreadInformation>");
		out.append("<ActiveThreadCount>" + bean.getThreadCount() + "</ActiveThreadCount>");
		out.append("<TotalThreadCount>" + bean.getTotalStartedThreadCount() + "</TotalThreadCount>");
    
		long[] pids = bean.getAllThreadIds();
		out.append("<Threads>");
		for (int i = 0; i < pids.length; i++)
		{
			long pid = pids[i];
			ThreadInfo info = bean.getThreadInfo(pid, 50);
			out.append("<Thread>");
			out.append("<ThreadId>" + pid + "</ThreadId>");
			out.append("<ThreadName>" + info.getThreadName() + "</ThreadName>");
			out.append("<CPUTime>" + bean.getThreadCpuTime(pid) + "</CPUTime>");
			out.append("<TotalTime>" + bean.getThreadUserTime(pid) + "</TotalTime>");
			out.append("<StackTrace>");
			
			StackTraceElement[] trace = info.getStackTrace();
			for (int j = 0; j < trace.length; j++)
			{
				StackTraceElement next = trace[j];
				out.append("<StackTraceElement>");
				out.append("<Class>" + next.getClassName() + "</Class>");
				out.append("<FileName>" + next.getFileName() + "</FileName>");
				out.append("<MethodName>" + next.getMethodName() + "</MethodName>");
				out.append("<LineNumber>" + next.getLineNumber() + "</LineNumber>");
				out.append("</StackTraceElement>");
			}
			out.append("</StackTrace>");
      
			out.append("<ThreadState>" + info.getThreadState().toString() + "</ThreadState>");
      
			out.append("</Thread>");
		}
		out.append("</Threads>");
		long[] deadlockedthreads = bean.findMonitorDeadlockedThreads();
		if (deadlockedthreads == null) 
		{
			deadlockedthreads = new long[0];
		}
		out.append("<deadlockedThreads>");
		for (int i = 0; i < deadlockedthreads.length; i++) 
		{
			out.append("<ThreadId>" + deadlockedthreads[i] + "</ThreadId>");
		}
		out.append("</deadlockedThreads>");
		out.append("</ThreadInformation>");
    
		return out.toString();
	}
  
	private String getRuntimeInformation()
	{
		StringBuffer out = new StringBuffer();
		RuntimeMXBean bean = ManagementFactory.getRuntimeMXBean();
    
		out.append("<RuntimeInformation>");
		out.append("<BootClasspath>" + bean.getBootClassPath() + "</BootClasspath>");
		out.append("<Classpath>" + bean.getClassPath() + "</Classpath>");
		out.append("<LibraryPath>" + bean.getLibraryPath() + "</LibraryPath>");
		out.append("<StartTime>" + bean.getStartTime() + "</StartTime>");
		out.append("<Uptime>" + bean.getUptime() + "</Uptime>");
		out.append("<VMName>" + bean.getVmName() + "</VMName>");
		out.append("<VMVendor>" + bean.getVmVendor() + "</VMVendor>");
		out.append("<VMVersion>" + bean.getVmVersion() + "</VMVersion>");
		out.append("<SystemProperties>" + bean.getSystemProperties() + "</SystemProperties>");
		out.append("</RuntimeInformation>");
    
		return out.toString();
	}
  
	private String getClassLoaderInformation()
	{
		StringBuffer out = new StringBuffer();
    
		ClassLoadingMXBean bean = ManagementFactory.getClassLoadingMXBean();
    
		out.append("<ClassLoaderInformation>");
		out.append("<LoadedClassCount>" + bean.getLoadedClassCount() + "</LoadedClassCount>");
		out.append("<TotalLoadedClassCount>" + bean.getTotalLoadedClassCount() + "</TotalLoadedClassCount>");
		out.append("<ClassLoader>" + getClass().getClassLoader().getClass().getName() + "</ClassLoader>");
		out.append("</ClassLoaderInformation>");
    
		return out.toString();
	}
  
	private String getMemoryUsageInformation()
	{
		StringBuffer out = new StringBuffer();
		MemoryMXBean bean = ManagementFactory.getMemoryMXBean();
    
		out.append("<MemoryInformation>");
		out.append("<HeapMemoryUsed>" + bean.getHeapMemoryUsage() + "</HeapMemoryUsed>");
		out.append("<NonHeapMemoryUsed>" + bean.getNonHeapMemoryUsage() + "</NonHeapMemoryUsed>");
		
		Runtime localRuntime = Runtime.getRuntime();
		out.append("<FreeMemory>" + localRuntime.freeMemory() + "</FreeMemory>");
		out.append("<MaxMemory>" + localRuntime.maxMemory() + "</MaxMemory>");
		out.append("<TotalMemory>" + localRuntime.totalMemory() + "</TotalMemory>");
		out.append("</MemoryInformation>");
    
		return out.toString();
	}
  
	private String getSystemInformation()
	{
		StringBuffer out = new StringBuffer();
		OperatingSystemMXBean bean = ManagementFactory.getOperatingSystemMXBean();
    
		out.append("<OperatingSystemInformation>");
		out.append("<AvailableProcessors>" + bean.getAvailableProcessors() + "</AvailableProcessors>");
		out.append("<OSArchitecture>" + bean.getArch() + "</OSArchitecture>");
		out.append("<OSName>" + bean.getName() + "</OSName>");
		out.append("<OSVersion>" + bean.getVersion() + "</OSVersion>");
		
		try
		{
			InetAddress address = InetAddress.getLocalHost();
			out.append("<HostName>" + address.getHostName() + "</HostName>");
			out.append("<HostAddress>" + address.getHostAddress() + "</HostAddress>");
		}
		catch (UnknownHostException uhe) {}
		out.append("</OperatingSystemInformation>");
    
		return out.toString();
	}
  
	public boolean ignoresThrowable()
	{
		return true;
	}
}

