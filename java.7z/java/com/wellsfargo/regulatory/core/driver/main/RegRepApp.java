package com.wellsfargo.regulatory.core.driver.main;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;

/**
 * @author 	Amit Rana
 * @date 	08/23/2014
 * @version 1.0
 *
 */

public class RegRepApp 
{
	private static final Logger logger = Logger.getLogger(RegRepApp.class);


	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/spring/applicationContext.xml";

	public static void main(String[] args) throws IOException	
	{
		// Testing the log4j - Workflow-Id / COMPONENT
		//MDC.put(GatewayConstants.ID, GUIDGenerator.getGUID(false));
		//MDC.put(GatewayConstants.COMPONENT, "REGULATORY-APP");
		
		//AbstractDriver.addThreadInformation(GatewayConstants.ID, GUIDGenerator.getGUID(true));
		//AbstractDriver.addThreadInformation(GatewayConstants.COMPONENT, "REGULATORY-APP");
		
		logger.info("[Bootstrap] Starting Regulatory-Reporting Main Class");
			
		initApp();
			
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		applicationContext.start();
		applicationContext.registerShutdownHook();
		
		 RegulatoryBeanFactory.setContext(applicationContext);
		 
		logger.info("[Bootstrap] App Context Started successfully");

	}
	
	private static void initApp() throws IOException
	{
		String userDirPath = System.getProperty("user.dir");
		String sdrHomePath = System.getProperty("REG_REP_HOME");
		File sdrHome;
		
		if (sdrHomePath == null) 
		{
			
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("REG_REP_HOME", sdrHomePath);
		} 
		else 
		{
			sdrHome = new File(sdrHomePath);
		}
		
		logger.info("REG_REP_HOME set as --> "+sdrHomePath);
		
		return;
	}
}
