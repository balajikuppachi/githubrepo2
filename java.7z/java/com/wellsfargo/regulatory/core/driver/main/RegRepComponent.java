/**
 *
 */
package com.wellsfargo.regulatory.core.driver.main;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * @author u337814
 *
 */


public abstract class RegRepComponent 
{
	private MessageChannel errorChannel;

	private static Logger logger = Logger.getLogger(RegRepComponent.class.getName());

	protected void dispatchException(Message<?> message, String sdrMessageId, String errorString, String errorCode, ExceptionSeverityEnum severity, String tradeId) 
	{
		logger.debug("Entering dispatchException for : "+errorString);

		MessagingException currMessageException;
		Message<MessagingException> excWrapper;

		currMessageException	= new MessagingException(errorCode, severity, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, tradeId);
		excWrapper 				= MessageBuilder.withPayload(currMessageException).copyHeaders(message.getHeaders()).build();

		errorChannel.send(excWrapper);

		logger.debug("Exiting dispatchException for : "+errorString);
	}

	protected void dispatchException(Message<?> message, String sdrMessageId, String errorString, String errorCode, ExceptionSeverityEnum severity, ExceptionTypeEnum excType, String tradeId) 
	{
		logger.debug("Entering dispatchException for : "+errorString);

		MessagingException currMessageException;
		Message<MessagingException> excWrapper;

		currMessageException	= new MessagingException(errorCode, severity, excType, errorString, sdrMessageId, tradeId);
		excWrapper 				= MessageBuilder.withPayload(currMessageException).copyHeaders(message.getHeaders()).build();

		errorChannel.send(excWrapper);

		logger.debug("Exiting dispatchException for : "+errorString);
	}

	public void setErrorChannel(MessageChannel errorChannel) 
	{
		this.errorChannel = errorChannel;
	}

}
