package com.wellsfargo.regulatory.core.driver.main;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
//import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

/*** Base test class to provide static initialisation.*/

@SuppressWarnings("deprecation")
public abstract class AbstractRegulatorySpringTestCase 
//extends AbstractDependencyInjectionSpringContextTests 
{
//	private static final Logger LOG = Logger.getLogger(AbstractRegulatorySpringTestCase.class);
//
//	static 
//	{
//		String log4jCfg = System.getProperty("log4j.configuration");
//		boolean hasLog4jCfg = (log4jCfg != null && log4jCfg.length() > 0);
//		
//		if (!hasLog4jCfg) 
//		{
//			BasicConfigurator.configure();
//			LOG.info("log4j configured from BasicConfigurator");
//		} 
//		else 
//		{
//			LOG.info("log4j configured from " + log4jCfg);
//		}
//	}

}
