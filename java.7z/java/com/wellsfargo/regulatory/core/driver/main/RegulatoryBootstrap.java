package com.wellsfargo.regulatory.core.driver.main;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.TimeZone;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.apache.log4j.xml.DOMConfigurator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wellsfargo.regulatory.commons.beans.RegRepMQConnectionFactoryBean;
import com.wellsfargo.regulatory.commons.factory.FactoryException;
import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;
import com.wellsfargo.regulatory.persister.RegRepDomainMapDaoImpl;

public class RegulatoryBootstrap
{
	private static Logger LOG = null;

	/*** The default name of architecture configuration file. */
	public static final String INIT_CONFIGURATION_FILE = "classpath:META-INF/spring/applicationContext.xml";
	protected static Thread shutdownHook = null;
	// protected static ContextClassPathXmlApplicationContext applicationContext = null;
	protected static ApplicationContext applicationContext = null;
	private static final String MDC_COMPONENT_KEY = "component";
	private static String component;
	private static String release_code;
	
	/*** Hidden constructor so it can never be instantiated */
	private RegulatoryBootstrap()
	{
	}

	static
	{
		System.setProperty("user.timezone", "America/New_York");
		TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
		LOG = Logger.getLogger(RegulatoryBootstrap.class);
		
		String configFilename = System.getProperty("log4j.configuration");
		DOMConfigurator.configureAndWatch(configFilename);
	}

	public static void main(String args[]) throws IOException
	{
		release_code = System.getProperty("release");
		if(null == release_code) release_code = "v1.1.0.RELEASE";
		
		LOG.info("====================================================================================");

		// LOG.info(" ++++++++   ++++++++++ ++++++++++++ +           + +                   +      +++++++++++++++ +++++++++++ ++++++++  +       +    			");
		// LOG.info(" +      +   +          +          + +           + +                 +   +    +      +      + +         + +      +   +     +    			");
		// LOG.info(" +      +   +          +            +           + +                +     +   +      +      + +         + +      +    +   +    			");
		// LOG.info(" +      +   +          +            +           + +               +       +         +        +         + +      +     + +    				");
		// LOG.info(" +++++++    +++++++    +  +++++++++ +           + +              + +++++++ +        +        +         + +++++++       +    				");
		// LOG.info(" +      +   +          +          + +           + +             +           +       +        +         + +       +     +    				");
		// LOG.info(" +       +  +          +          + +           + +            +             +      +        +         + +        +    +    				");
		// LOG.info(" +        + ++++++++++ ++++++++++++ (+++++++++++) ++++++++++++ +             +     +++       +++++++++++ +         +   +  [WELLS FARGO]	");

		//LOG.info(" ########  ######## #########  #        # #              #      ########### ######## ######## #     # 			");
		//LOG.info(" #      #  #        #          #        # #            #   #    #    #    # #      # #      #  #   #				");
		//LOG.info(" #      #  #        #          #        # #           #     #        #      #      # #      #   # #				");
		//LOG.info(" #######   #####    #  ####### #        # #          # ##### #       #      #      # #######     #				");
		//LOG.info(" #      #  #        #        # #        # #         #         #      #      #      # #      #    #				");
		//LOG.info(" #       # ######## ########## (########) ######## #           #    ###     ######## #       #   #  [WELLS FARGO] ");

		LOG.info("====================================================================================");
		LOG.info("#######  ####### #######  #      # #          #    ######### ####### ####### #     #");
		LOG.info("#     #  #       #        #      # #        #   #  #   #   # #     # #     #   # #");
		LOG.info("######   ####    #  ##### #      # #       # ### #     #     #     # ######     #");
		LOG.info("#     #  #       #      # #      # #      #       #    #     #     # #     #    #");
		LOG.info("#      # ####### ######## (######) ###### #       #   ###    ####### #      #   #");
		LOG.info("====================================================================================");
		LOG.info("  :: WFSREG :: Regulatory Platform Boot :: (WFSREG-" + release_code + ")");
		LOG.info("====================================================================================\n");

		LOG.info("[Bootstrap] Starting Regulatory-Reporting Main Class");

		String fileName = args[0];
		component = System.getProperty("component");

		MDC.put(MDC_COMPONENT_KEY, component);

		initApp();

		if (fileName == null)
		{
			fileName = INIT_CONFIGURATION_FILE;
		}

		bootstrapApplication(fileName);
		pauseWorker();
	}

	private static void pauseWorker()
	{
		while (true)
		{
			try
			{
				Thread.sleep(15000L);
			}
			catch (Throwable t)
			{
				/*** do nothing ***/
			}
		}
	}

	private static void initApp() throws IOException
	{
		String java_vm_name = System.getProperty("java.vm.name");

		String userDirPath 	= System.getProperty("user.dir");
		String tempDirPath 	= System.getProperty("java.io.tmpdir");
		String sdrHomePath 	= System.getProperty("REG_REP_HOME");
		File sdrHome;

		if (sdrHomePath == null)
		{
			sdrHome 	= new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			
			System.setProperty("REG_REP_HOME", sdrHomePath);
		}
		else
		{
			sdrHome = new File(sdrHomePath);
		}

		String processId = retrievePid();

		LOG.info("================= Starting RegulatoryApp ===================");
		LOG.info("Java VM Name = " + java_vm_name);
		LOG.info("REG_REP_HOME set as --> " + sdrHomePath);
		LOG.info("PID = " + processId);
		LOG.info("user.dir = " + userDirPath);
		LOG.info("java.io.tmpdir = " + new File(tempDirPath).getCanonicalPath());
		LOG.info("======================================================");

		return;
	}

	private static String retrievePid()
	{
		RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
		String name = runtime.getName();
		int index = name.indexOf("@");
		String processId = name.substring(0, index);

		return processId;
	}

	private static void bootstrapApplication(String configLocation) throws IOException
	{
		try
		{
			LOG.info((new StringBuilder()).append("bootstrapApplication from: ").append(configLocation).toString());
			LOG.info("Application is Initializing Components ...... Please Wait! ");

			applicationContext = new ClassPathXmlApplicationContext(configLocation);
			RegulatoryBeanFactory.setContext(applicationContext);

			printDatabaseProperties();
			//printHikariDatabaseProperties();
			printMQProperties();
			
			if(null != RegulatoryBeanFactory.loadXSLCleanerFileInputStream())
				LOG.info("Loaded the XSL Cleaner file");
			
			printRegRepDomainMappingCount();
		}
		catch (Throwable e)
		{
			LOG.error(ExceptionUtils.getFullStackTrace(e));
			throw new IOException("##### Exception encountered bootstrapping : " + e);
		}
		
		LOG.info("[Bootstrap] App Context Started successfully");
		LOG.info("[Component] : " + component);
	}

	private static void printRegRepDomainMappingCount() throws FactoryException, Exception 
	{
		RegRepDomainMapDaoImpl regRepDomainMapDao = (RegRepDomainMapDaoImpl)RegulatoryBeanFactory.getBean("regRepDomainMapDao");
		
		if(null != regRepDomainMapDao.getDomainMappings())
			LOG.info("[STATIC-DATA RegRepDomainMapDao Count] : " + regRepDomainMapDao.getDomainMappings().size());
		
		if(null != regRepDomainMapDao.getRealtimeConfigData())
			LOG.info("[STATIC-DATA RealtimeConfigData Count] : " + regRepDomainMapDao.getRealtimeConfigData().size());

	}

	private static void printMQProperties() throws FactoryException 
	{
		RegRepMQConnectionFactoryBean mqConnectionBean = (RegRepMQConnectionFactoryBean)RegulatoryBeanFactory.getBean("regMQConnectionFactory");
		LOG.info("MQ-Host: " + mqConnectionBean.getHostName()+":"+mqConnectionBean.getPort());
		LOG.info("MQ-QMgr: " + mqConnectionBean.getQueueManager()+" :: Channel : "+mqConnectionBean.getChannel());
	}
	
	/*
	private static void printHikariDatabaseProperties() throws FactoryException 
	{
		HikariDataSource dataSource = (HikariDataSource)RegulatoryBeanFactory.getBean("dataSource");
		StringBuffer sb = new StringBuffer();
		sb.append("-------- Connected to Database (DataSource : dataSource) --------");
		sb.append("\n====================================================");
		sb.append("\nDB URL: " + dataSource.getJdbcUrl());
		sb.append("\nDB UserName: " + dataSource.getUsername());
		sb.append("\nDB PoolName: " + dataSource.getPoolName());
		sb.append("\nDB LIVE: " + !(dataSource.isClosed()));
		
		sb.append("\n====================================================");
		LOG.info(sb.toString());
	}
	*/
	
	
	private static void printDatabaseProperties() throws FactoryException 
	{
		org.apache.commons.dbcp.BasicDataSource dataSource = (org.apache.commons.dbcp.BasicDataSource)RegulatoryBeanFactory.getBean("dataSource"); // dataSourceForSpring --> dataSource
		StringBuffer sb = new StringBuffer();
		sb.append("-------- Connected to Database (DataSource : dataSource) --------");
		sb.append("\n====================================================");
		sb.append("\nDB URL: " + dataSource.getUrl());
		sb.append("\nDB UserName: " + dataSource.getUsername());
		sb.append("\nDB NumActive: " + dataSource.getNumActive());
		sb.append("\nDB NumIdle: " + dataSource.getNumIdle());
		sb.append("\n====================================================");
		LOG.info(sb.toString());
	}
	
	
	/**
	 * Returns component configured name.
	 * 
	 * @return application
	 */
	public static String getComponent()
	{
		return component;
	}

}
