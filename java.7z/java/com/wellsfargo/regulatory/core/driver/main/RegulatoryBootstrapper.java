package com.wellsfargo.regulatory.core.driver.main;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.LogManager;
import org.apache.log4j.MDC;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Filename		: RegulatoryAppBootstrapper.java
 * Author		: Rama K Nuti
 * DateCreated	: Aug 11 2014
 * Contents		: Bootstraps application components
 *
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class RegulatoryBootstrapper 
{
    private static final Log LOG = LogFactory.getLog(RegulatoryBootstrapper.class);
    private static AbstractApplicationContext applicationContext;

    private static final String MDC_COMPONENT_KEY = "component";

    private static String component;

    /*** Hidding constructor so it can never be instantiated */
    private RegulatoryBootstrapper() 
    {
    }

    /**
     * Returns component configured name.
     *
     * @return application
     */
    public static String getComponent() 
    {
        return component;
    }


    /**
     * The default name of architecture configuration file.
     */
    public static final String ARCHITECTURE_CONFIG_FILE_NAME = "applicationContext.xml";
    
    /**
     * Bootstraps architecture by starting Spring factory.
     *
     * @param appName - appName
     * @param appFeed - appFeed
     */
    public static synchronized void bootstrapApplication(String component) 
    {
    	RegulatoryBootstrapper.component = component;

        if (component != null) 
        {
            MDC.put(MDC_COMPONENT_KEY, component);
        }
        
        String componentPrefix = "";
        if (component != null) 
        {
        	componentPrefix = component + "/";
        }
        
        if (applicationContext == null) 
        {
            applicationContext = new ClassPathXmlApplicationContext(componentPrefix + ARCHITECTURE_CONFIG_FILE_NAME);
            applicationContext.registerShutdownHook();
        }

        LOG.info("Regulatory Application Bootstrapped");
        LOG.info("Component: " + component);
    }
    
    /**
     * Shutdowns architecture bootstrapper by closing underlying application context.
     */
    public static synchronized void shutdown() 
    {
        applicationContext.close();
        LogManager.shutdown();
    }
    
    /**
     * Returns the application context components
     * @return - application context
     */
    public static ApplicationContext getContext() 
    {
    	return applicationContext;
    }
    
}