/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.HYPHEN;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRADINGEVENT_AGREEMENTDATE;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

/**
 * @author 	-	Jayshri V.
 * date		-	10/08/2015
 *
 */

@Component
public class TradeAgreementDateEnricher 
{
	private static Logger logger = Logger.getLogger(TradeAgreementDateEnricher.class.getName());
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering TradeAgreementDateEnricher() method");
		
		ReportingContext context 				= null;
		StringBuilder asOfDate 					= null;
		StringBuilder asOfTime 					= null;
		XMLGregorianCalendar postEveTransDate 	= null;
		RegulatoryType regulatory 				= null;
		TradeHeaderType tradeHeader 			= null;
		LifeCycleType lifecycle 				= null;
		StringBuilder tradingeventAgreementDate = null;
		
		if(null == message) return message;

		try
		{
			if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
			{
				logger.error("############################# Incoming payload is not of Reporting type. " + "Returning.######################");
				return message;
			}

			context 		= (ReportingContext) message.getPayload();
			
			//AbstractDriver.setMDCInfo(context, AbstractDriver.TradeAgreementDateEnricher);

			tradeHeader 	= context.getSdrRequest().getTrade().getTradeHeader();
			regulatory 		= context.getSdrRequest().getTrade().getRegulatory();
			lifecycle		= tradeHeader.getLifeCycle();
			
			if ( null != lifecycle.getPostEventTransactionDate() ) 
			{
				postEveTransDate 			= lifecycle.getPostEventTransactionDate();
				
				tradingeventAgreementDate 	= new StringBuilder();
				tradingeventAgreementDate.append(postEveTransDate.getYear()).append(HYPHEN).append(postEveTransDate.getMonth()).append(HYPHEN).append(postEveTransDate.getDay());
				//asOfDate.append(date.getYear()).append(HYPHEN).append(date.getMonth()).append(HYPHEN).append(date.getDay());
				//asOfTime.append(date.getHour()).append(COLON).append(date.getMinute()).append(COLON).append(date.getSecond());
									
				ReportingDataUtils.addKeyword(regulatory, TRADINGEVENT_AGREEMENTDATE, tradingeventAgreementDate.toString());					
				//ReportingDataUtils.addKeyword(regulatory, AS_OF_TIME, asOfTime.toString());
			}
			
		}
		catch(Exception e)
		{
			logger.error("######## Exception occured while calculating as of TradeAgreementDateEnricher : ", e);
		}
		
		logger.debug("Leaving TradeAgreementDateEnricher() method");
		return message;
	}	

}
