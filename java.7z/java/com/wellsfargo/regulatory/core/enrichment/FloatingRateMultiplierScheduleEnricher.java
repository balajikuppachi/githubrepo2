package com.wellsfargo.regulatory.core.enrichment;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class FloatingRateMultiplierScheduleEnricher {
	
	private static Logger logger = Logger.getLogger(FloatingRateMultiplierScheduleEnricher.class.getName());
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.info("Entering FloatingRateMultiplierScheduleEnricher() method");

		List<LegType> 		legList 				= null;
		ReportingContext 	context 				= null;
		String 				leg1IndexFactor		 	= null;
		String 				leg2IndexFactor		 	= null;
		SdrRequest 			request 				= null;
		RegulatoryType 		regulatory 				= null;
		LegType				legType1				= null;
		LegType				legType2				= null;
		String 				productType			 	= null;
		List<ProductType> 	productTypeList 		= null;
		ProductType			productType1			= null;
		
		if(null == message) return message;

		try
		{
			context 					= 	(ReportingContext) message.getPayload();
			legList 					= 	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getLeg();
			request 					= 	context.getSdrRequest();
			regulatory 					= 	request.getTrade().getRegulatory();
			
			productType					=	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductType();
			
			if(Constants.PRODUCT_TYPE_SWAPTION.equalsIgnoreCase(productType))
			{
				productTypeList			= 	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProduct();
				
				if(null != productTypeList  && !productTypeList.isEmpty()){
					productType1 = productTypeList.get(0);
					
					if(null != productType1){
						legList = productType1.getLeg();
					}
				}
			}
		
			if(null != legList && !legList.isEmpty()){
				
				legType1 = legList.get(0);
				
				if(null != legType1){
					
					FixedFloatEnum fixedFloat = legType1.getFixedFloat();
					
					if (null != fixedFloat && fixedFloat.compareTo(FixedFloatEnum.FLOAT) == 0){
						
						BigDecimal indexFactor = legType1.getIndexFactor();
						
						if(null != indexFactor && (indexFactor.floatValue() < 1 || indexFactor.floatValue() > 1)){
							leg1IndexFactor = Constants.TRUE; 
						} else{
							leg1IndexFactor = Constants.FALSE;
						}
					}
					else{
						leg1IndexFactor = Constants.FALSE;
					}
				}
				
				if(legList.size() > 1){
					
					legType2 = legList.get(1);
					
					if(null != legType2){
						
						FixedFloatEnum fixedFloat = legType2.getFixedFloat();
						
						if (null != fixedFloat && fixedFloat.compareTo(FixedFloatEnum.FLOAT) == 0){
							
							BigDecimal indexFactor = legType2.getIndexFactor();
														
							if(null != indexFactor && (indexFactor.floatValue() < 1 || indexFactor.floatValue() > 1)){
								leg2IndexFactor = Constants.TRUE; 
							} else{
								leg2IndexFactor = Constants.FALSE;
							}
						}
						else{
							leg2IndexFactor = Constants.FALSE;
						}
					}
				}
			}
				
			
			ReportingDataUtils.addKeyword(regulatory, Constants.LEG_INDEX_FACTOR1, leg1IndexFactor);
			ReportingDataUtils.addKeyword(regulatory, Constants.LEG_INDEX_FACTOR2, leg2IndexFactor);

		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while enriching floatingRate Multiplier Schedule keyword : ", e);
		}

		logger.debug("Leaving FloatingRateMultiplierScheduleEnricher() method");

		return message;

	}

}
