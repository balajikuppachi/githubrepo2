package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.SEND_BY;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class SendByEnricher
{
	private static Logger logger = Logger.getLogger(SendByEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichSendBy() method");

		RegulatoryType regulatory 	= null;
		ReportingContext context 	= null;
		String errorString 			= null;
		String wfLei				= null;
		TradeHeaderType trdHeader 	= null;
		String wfPartyLei			= null;

		if(null == message)
			return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			regulatory 	= context.getSdrRequest().getTrade().getRegulatory();
			trdHeader 	= context.getSdrRequest().getTrade().getTradeHeader();
		
			if (trdHeader.getProcessingOrgLEIValue() != null){
				wfLei = trdHeader.getProcessingOrgLEIValue();
			} else {
				wfPartyLei = context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEI();
				if (wfPartyLei.indexOf(":") >= 0){
				wfLei = wfPartyLei.substring( wfPartyLei.indexOf(":")+1,wfPartyLei.length());
				}
			}
			if (trdHeader != null )
			ReportingDataUtils.addKeyword(regulatory, SEND_BY, wfLei);

		}
		catch (Exception e)
		{
			errorString = "Error while poplulating sendBy keyword" + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("sndBy:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving enrichSendBy() method");

		return message;
	}

}
