package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class JurisdictionEnricher {
	private static Logger logger = Logger.getLogger(JurisdictionEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering JurisdictionEnricher() method");

		ReportingContext 	context 	= null;
		RegulatoryType 		regulatory 	= null;
		
		if(null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			regulatory  = context.getSdrRequest().getTrade().getRegulatory();
			
			if (context.isEsmaReportable())
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.JURISDICTION, Constants.JURISDICTION_ESMA);
			}
			else
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.JURISDICTION, Constants.JURISDICTION_CFTC);
			}
			
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while getting jurisdiction : ", e);
		}

		logger.debug("Leaving JurisdictionEnricher() method");

		return message;

	}
}
