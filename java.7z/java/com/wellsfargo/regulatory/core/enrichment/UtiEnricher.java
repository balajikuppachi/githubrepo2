package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.CFTC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.COLON;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FALSE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.GTRCREATE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.IS_GTR_USI;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRUE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.USI;
import static com.wellsfargo.regulatory.commons.keywords.Constants.USI_PREFIX;
import static com.wellsfargo.regulatory.commons.keywords.Constants.USI_VALUE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.WELLS;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepUniqueIdentifierMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMappingId;

@Component
public class UtiEnricher
{
	private static Logger logger = Logger.getLogger(UtiEnricher.class.getName());

	@Value("${regRep.usiPrefixOverride}") String usiPrefixOverride;
	@Value("${regRep.wf.affiliate.leis}")  String wfAffiliateLeis;
	  
	//private static String usiPrefixOverride;
	//private static String wfUSIPrefix;

	@Autowired
	private RegRepUniqueIdentifierMappingDao regRepUniqueIdentifierDao;

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichUti() method");

		String 			usiValue 				= null;
		String 			usiPrefix 				= null;		
	//	String 			wfLei 					= null;		
		String 			errorString 			= null;
	//	String 			tradeId 				= null;
		String 			usi 					= null;
		String 			uti 					= null;
		RegulatoryType 	regulatory 				= null;
		String			reportingJurisdiction	= null;
		String			delegationReporting		= null;
	//	boolean 		isDefaultDtccId 		= false;
	//	boolean 		isAffiliatedTrade 		= false;
		boolean			isDelegatedReporting	= false;
	//	boolean 		usiUpdated 				= false;
	//	boolean 		isEsmaTrade				= false;
		
		String			usi_uti_string			=	null;

		if(null == message)
			return message;

		ReportingContext context 	= (ReportingContext) message.getPayload();
		SdrRequest request 			= context.getSdrRequest();

		// START : Setting the MDC from the Context
		AbstractDriver.setMDCInfo(context, AbstractDriver.UtiEnricher);
		// END : Setting the MDC from the Context

		try	
		{
			
			//usi 				= ReportingDataUtils.computeUSI(request);
			regulatory 				= 	request.getTrade().getRegulatory();
			reportingJurisdiction 	= 	regulatory.getReportingEligibility().get(0).getReportingJurisdiction().toString();	
			delegationReporting		=	regulatory.getReportingEligibility().get(0).getDelegatedReporting();
			uti						=	request.getTrade().getTradeDetail().getProduct().getProductKeys().getUTI();
			
					
				ReportingDataUtils.addKeyword(regulatory, IS_GTR_USI, FALSE);
				
				usi_uti_string = uti;
				
				if (uti == null) {
				
					if (JurisdictionEnum.CFTC.value().equalsIgnoreCase(reportingJurisdiction) &&  com.wellsfargo.regulatory.commons.keywords.Constants.EMIR.equalsIgnoreCase(delegationReporting) ) {
						usi 				= ReportingDataUtils.computeUSI(context);
						usi_uti_string		= usi;
					}  else {
				
						errorString = "Error while poplulating ESMA trade - UTI - value keywords, UTI is null " ;
						logger.error("########## " + errorString);

						throw new MessagingException("sndTo:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), context.getSwapTradeId());
				}
				}
				
				
				
				if(usi_uti_string.length() > 9)
				{
					usiPrefix = usi_uti_string.substring(0, 10);
				}
				else
				{
					usiPrefix = usi_uti_string.substring(0, usi_uti_string.length()-1);
				}
				if(usi_uti_string.length() > 10)
				{
					usiValue = usi_uti_string.substring(10);
				}
				else
				{
					usiValue = usi_uti_string.substring(usi_uti_string.length() - 1);
				}
				logger.debug("---- usiValue :"+usiValue);
				logger.debug("---- usiPrefix :"+usiPrefix);

				ReportingDataUtils.addKeyword(regulatory, USI_VALUE, usiValue);
				ReportingDataUtils.addKeyword(regulatory, USI_PREFIX, usiPrefix);
				
				
		
				logger.debug("Leaving enrichUti() method");
				
				return message;
				}
		catch (Exception e)
		{
			errorString = "Error while poplulating USIPrefix and/ USI - ESMA UTI - value keywords : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("sndTo:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

	}

	public void setRegRepUniqueIdentifierDao(RegRepUniqueIdentifierMappingDao regRepUniqueIdentifierDao) 
	{
		this.regRepUniqueIdentifierDao = regRepUniqueIdentifierDao;
	}


}
