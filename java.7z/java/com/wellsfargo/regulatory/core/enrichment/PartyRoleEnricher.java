package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.IS_GTR_USI;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRUE;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClassificationEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.PartyAttributesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class PartyRoleEnricher
{

	private static Logger logger = Logger.getLogger(PartyRoleEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichPartyRole() method");

		List<TradePartyType> tradeParties 	= null;
		TradePartyType tradeParty 			= null;
		PartyAttributesType.Attribute partyAttribute = null;
		String processingOrgLei 			= null;
		String counterPartyLei 				= null;
		SdrRequest request 					= null;
		ReportingContext context 			= null;
		String sdrMessageId 				= null;
		PartyAttributesType attrType 		= null;
		String partyLei 					= null;
		RegulatoryType regulatory 			= null;
		String cptyClassification			= null;
		boolean isInterAffiliate 			= false;
		boolean endUserException			= false;
		

		if(null == message)
			return message;

		try
		{
			sdrMessageId 	= (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			context 		= (ReportingContext) message.getPayload();
			request 		= context.getSdrRequest();
			regulatory 		= request.getTrade().getRegulatory();
			tradeParties 	= request.getTrade().getTradeDetail().getTradeParties().getParty();

			if (null == tradeParties)
			{
				logger.debug("########## TradeParties not found, TradeParties is null. Aborting Party Role Enricher");
				return message;
			}

			processingOrgLei 	= (request.getTrade().getTradeHeader().getProcessingOrgLEIValue() != null ) ? request.getTrade().getTradeHeader().getProcessingOrgLEIValue() :request.getTrade().getTradeHeader().getProcessingOrgLEI() ;
			counterPartyLei 	= (request.getTrade().getTradeHeader().getCounterpartyLEIValue() !=  null ) ? request.getTrade().getTradeHeader().getCounterpartyLEIValue() : request.getTrade().getTradeHeader().getCounterpartyLEI();

			if (null == processingOrgLei)
				logger.debug("########## ProcessingOrgLEI is null");

			if (null == counterPartyLei)
				logger.debug("########## CounterPartyLEI is null");

			for (int i = 0; i < tradeParties.size(); i++)
			{
				tradeParty = tradeParties.get(i);

				if(null == tradeParty) continue;

				partyAttribute 	= new PartyAttributesType.Attribute();
				attrType 		= tradeParty.getPartyAttributes();

				partyLei = (tradeParty.getLEIValue()!= null ) ? tradeParty.getLEIValue() :tradeParty.getLEI() ;
				
				if(null == attrType)
				{
					attrType = new PartyAttributesType();
					tradeParty.setPartyAttributes(attrType);
				}


				if (null != processingOrgLei && processingOrgLei.equals(partyLei))
				{
					partyAttribute.setName(Constants.WELLSFARGO_ROLE_TYPE);
					partyAttribute.setValue(Constants.APP_TRUE);
					attrType.getAttribute().add(partyAttribute);
					
					if (tradeParty.isFinancialEntity() !=null )
					{
						if (tradeParty.isFinancialEntity())
							ReportingDataUtils.addKeyword(regulatory, Constants.CFTC_FINANCIAL_ENTITY + "1", Constants.FINANCIAL);
						else
							ReportingDataUtils.addKeyword(regulatory, Constants.CFTC_FINANCIAL_ENTITY + "1", Constants.NON_FINANCIAL);
					}
					if (tradeParty.isEmirFinancialEntity() != null)
					{
						if (tradeParty.isEmirFinancialEntity())
							ReportingDataUtils.addKeyword(regulatory, Constants.ESMA_FINANCIAL_ENTITY + "1", Constants.FINANCIAL );
						else
							ReportingDataUtils.addKeyword(regulatory, Constants.ESMA_FINANCIAL_ENTITY + "1", Constants.NON_FINANCIAL );
					}	
					
					if(tradeParty.isUsPerson() !=null){
						
					if(tradeParty.isUsPerson())
						ReportingDataUtils.addKeyword(regulatory, Constants.WELLSFARGO_CTRY_TYPE , Constants.USA );
					else
						ReportingDataUtils.addKeyword(regulatory, Constants.WELLSFARGO_CTRY_TYPE , Constants.NON_USA );
					}
				}

				if (null != counterPartyLei && counterPartyLei.equals(partyLei))
				{
					partyAttribute.setName(Constants.COUNTERPARTY_ROLE_TYPE);
					partyAttribute.setValue(Constants.APP_TRUE);
					attrType.getAttribute().add(partyAttribute);
					if (tradeParty.isFinancialEntity() !=null )
					{
						if (tradeParty.isFinancialEntity())
							ReportingDataUtils.addKeyword(regulatory, Constants.CFTC_FINANCIAL_ENTITY + "2", Constants.FINANCIAL);
						else
							ReportingDataUtils.addKeyword(regulatory, Constants.CFTC_FINANCIAL_ENTITY + "2", Constants.NON_FINANCIAL);
					}
					if (tradeParty.isEmirFinancialEntity() != null)
					{
						if (tradeParty.isEmirFinancialEntity())
							ReportingDataUtils.addKeyword(regulatory, Constants.ESMA_FINANCIAL_ENTITY + "2", Constants.FINANCIAL );
						else
							ReportingDataUtils.addKeyword(regulatory, Constants.ESMA_FINANCIAL_ENTITY + "2", Constants.NON_FINANCIAL );
					}	
					
					// To find if the message is Inter Affiliate or not.
					
					if (tradeParty.getClassification() !=null){
						cptyClassification =tradeParty.getClassification().value();
						if (ClassificationEnum.INTER_AFFILIATE.equals(tradeParty.getClassification())){
							isInterAffiliate = true;
						}
					}
					ReportingDataUtils.addKeyword(regulatory, Constants.INTER_AFFILIATE , "" + isInterAffiliate );
					
					if (tradeParty.getClassification() != null){
						if (ClassificationEnum.EXTERNAL.equals(tradeParty.getClassification()) && tradeParty.getEndUserException()){
							endUserException = true;
						}
					}
					ReportingDataUtils.addKeyword(regulatory, Constants.END_USER_EXCEPTION, "" + endUserException);
					
					if(tradeParty.isUsPerson()!=null){
						
					if(tradeParty.isUsPerson()==true)
					ReportingDataUtils.addKeyword(regulatory, Constants.COUNTERPARTY_CTRY_TYPE , Constants.USA );
				else 
					ReportingDataUtils.addKeyword(regulatory, Constants.COUNTERPARTY_CTRY_TYPE , Constants.NON_USA );
					
					}
				}
			}
		}
		catch (Exception e)
		{
			throw new MessagingException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR,
					"Error while populating party role", sdrMessageId, e, context.getSwapTradeId());
		}

		logger.debug("Leaving addPartyRole() method");

		return message;

	}

}
