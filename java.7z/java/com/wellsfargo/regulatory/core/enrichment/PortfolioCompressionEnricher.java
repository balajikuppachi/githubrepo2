package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;

@Component
public class PortfolioCompressionEnricher
{
	private static Logger logger = Logger.getLogger(PortfolioCompressionEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		TradeHeaderType trdHeader 	= null;
		ReportingContext context 	= null;
		String portfolioCompression = null;

		logger.debug("Entering checkPortfolioCompression() method");

		try
		{
			context 				= (ReportingContext) message.getPayload();
			trdHeader 				= context.getSdrRequest().getTrade().getTradeHeader();
			portfolioCompression 	= trdHeader.getLifeCycle().getPortfolioCompression();

			/*
			 * Portfolio compression is required for message generation rules.
			 */
			if (portfolioCompression == null)
			{
				trdHeader.getLifeCycle().setPortfolioCompression(Constants.RULES_APP_NA);
			}

		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while setting portfolio compression : ", e);
		}

		logger.debug("Leaving checkPortfolioCompression() method");

		return message;

	}

}
