package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCCCAD;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCCGTR;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCCUS;
import static com.wellsfargo.regulatory.commons.keywords.Constants.JURISDICTION_CANADA_SHORT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.JURISDICTION_CFTC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.SEND_TO;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class SendToEnricher
{
	private static Logger logger = Logger.getLogger(SendToEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichSendTo() method");

		RegulatoryType regulatory 	= null;
		String sdr 					= null;
		String sendToString 		= null;
		String jurisdiction 		= null;
		ReportingContext context 	= null;
		SdrRequest request 			= null;
		String errorString 			= null;

		if(null == message)
			return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();

			// START : Setting the MDC from the Context
			AbstractDriver.setMDCInfo(context, AbstractDriver.SendToEnricher);
			// END : Setting the MDC from the Context

			request 		= context.getSdrRequest();
			regulatory 		= request.getTrade().getRegulatory();
			jurisdiction 	= regulatory.getReportingEligibility().get(0).getReportingJurisdiction().value();
			sdr 			= context.getRegulatories().keySet().iterator().next().split(UNDERSCORE)[1];

			if (DTCC.equals(sdr))
			{
				if (JURISDICTION_CFTC.equals(jurisdiction))
				{
					sendToString = DTCCUS;
				}
				//else if (null != jurisdiction && jurisdiction.contains(JURISDICTION_CANADA_SHORT))
				//{
				//	sendToString = DTCCCAD;
				//}
				else
				{
					/*** Default value ***/
					sendToString = DTCCUS;
				}
			}
			else
			{
				sendToString = DTCCGTR;
			}

			//logger.info("---- Regulatory :"+regulatory);
			logger.debug("---- SendToString :"+sendToString);

			ReportingDataUtils.addKeyword(regulatory, SEND_TO, sendToString);

		}
		catch (Exception e)
		{
			errorString = "Error while poplulating sendTo keyword : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("sndTo:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving enrichSendTo() method");

		return message;

	}

}
