/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashFlowType.CashFlow;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CashSettlementType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CdsTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.EquityUnderlyingAssetType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeInfoType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReferenceInformationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReferenceObligationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author u337814
 *
 */

@Component
public class CurrencyTypeEnricher 
{
	private static Logger logger = Logger.getLogger(CurrencyTypeEnricher.class.getName());

	private static Map<String, String> currencyCache;
	private static final String CURRENCY_DOMAIN = "ISOCurrencyException";

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		ReportingContext 				context 		= null;
		ProductType						product			= null;
		TradeDetailType					trdDetail		= null;
		String							assetClass		= null;
		List<ProductType>   			subProducts		= null;
		List<LegType> 					legs			= null;
		CashFlowType					cashFlowType	= null;
		List<CashFlow> 					cashFlows		= null;
		CdsTermsType					cdsTerms		= null;
		ReferenceInformationType		refInfo			= null;
		ReferenceObligationType			refOblgtn		= null;
		ExerciseProvisionType			exercisePrv		= null;
		CashSettlementType				cashStlmnt		= null;
		EquityTermsType					equityTerms		= null;
		List<EquityUnderlyingAssetType>	undrLyngAsts	= null;
		FeeInfoType						feeInfo			= null;
		List<FeeType> 					fees			= null;

		logger.debug("Entering CurrencyTypeEnricher() method");

		if(null == message) return message;

		try
		{
			if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
			{
				logger.error("############################# Incoming payload is not of Reporting type. Returning.######################");
				return message;
			}

			context 	= (ReportingContext) message.getPayload();
			assetClass	= context.getAssetClass();

			if(null == assetClass)
			{
				logger.error("############################# Failed to get asset class from the context. Returning.######################");
				return message;
			}

			try
			{
				trdDetail 	= context.getSdrRequest().getTrade().getTradeDetail();
				product		= trdDetail.getProduct();
			}
			catch(Exception e)
			{
				logger.error("############################# Failed to get tradeDetail/Product from the context. Returning.################");
				return message;
			}

			subProducts	= product.getProduct();

			/*** Temporarily adding product so that it's legs also get processed in the loop ***/
			if(null == subProducts)
			{
				subProducts = new ArrayList<ProductType>(2);
			}
			subProducts.add(subProducts.size(), product);

			/*
			 * For now not iterating more than level deep in the product hierarchy
			 * TODO : Iterate through deeper levels
			 */

			for(ProductType subProduct : subProducts)
			{
				if(null == subProduct) continue;

				legs = subProduct.getLeg();

				if(null == legs) continue;

				for(LegType leg : legs)
				{
					if(null == leg) continue;

					/*** Currency under Leg ***/
					leg.setCurrency(getDtccCurrency(leg.getCurrency()));

					/*** NotionalCurrency under leg ***/
					leg.setNotionalCurrency(getDtccCurrency(leg.getNotionalCurrency()));

					/*** Price Currency under leg ***/
					leg.setPriceCurrency(getDtccCurrency(leg.getPriceCurrency()));

					/*** Settlement Currency under leg ***/
					leg.setSettlementCurrency(getDtccCurrency(leg.getSettlementCurrency()));

					/*** Index currency under leg ***/
					leg.setIndexCurrency(getDtccCurrency(leg.getIndexCurrency()));

					/*** cashFlowCurrency under leg/casFlow ***/
					cashFlowType = leg.getCashFlowSet();

					if(null != cashFlowType)
					{
						cashFlows = cashFlowType.getCashFlow();

						if(null != cashFlows)
						{
							for(CashFlow cashFlow : cashFlows)
							{
								if(null == cashFlow) continue;
								cashFlow.setCashflowCurrency(getDtccCurrency(cashFlow.getCashflowCurrency()));
							}
						}
					}

				}

				/*** Currency under product/cdsTerms/referenceInformation/refernceObligation ***/
				if(Constants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass))
				{
					cdsTerms = subProduct.getCdsTerms();

					if(null != cdsTerms)
					{
						refInfo  = cdsTerms.getReferenceInformation();

						if(null != refInfo)
						{
							refOblgtn= refInfo.getReferenceObligation();

							if(null != refOblgtn)
								refOblgtn.setCurrency(getDtccCurrency(refOblgtn.getCurrency()));
						}
					}
				}

				/*** NotionalCurrency under product/equityTerms/underlyingAsset ***/
				if(Constants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass))
				{
					equityTerms  = subProduct.getEquityTerms();

					if(null != equityTerms)
					{
						undrLyngAsts = equityTerms.getUnderlyingAsset();

						if(null != undrLyngAsts)
						{
							for(EquityUnderlyingAssetType underlyingAsset : undrLyngAsts)
							{
								if(null == underlyingAsset) continue;
									underlyingAsset.setNotionalCurrency(getDtccCurrency(underlyingAsset.getNotionalCurrency()));
							}
						}
					}
				}


				/*** Currency under product/exerciseProvision/cashSettlement ***/
				{
					exercisePrv = subProduct.getExerciseProvision();

					if(null != exercisePrv)
					{
						cashStlmnt  = exercisePrv.getCashSettlement();

						if(null != cashStlmnt)
							cashStlmnt.setCurrency(getDtccCurrency(cashStlmnt.getCurrency()));
					}
				}

			}

			/*** Removing the parent product, which was temporarily added ***/
			subProducts.remove(subProducts.size() - 1);

			/*** Currency under FeeInfo/Fee[] ***/
			{
				feeInfo = trdDetail.getFeeInfo();

				if(null != feeInfo)
				{
					fees 	= feeInfo.getFee();

					if(null != fees)
					{
						for(FeeType fee : fees)
						{
							if(null == fee) continue;
								fee.setCurrency(getDtccCurrency(fee.getCurrency()));
						}
					}
				}
			}



		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while converting currency type : ", e);
		}

		logger.debug("Leaving CurrencyTypeEnricher() method");

		return message;

	}

	/**
	 * @param currency
	 * @return
	 */
	private String getDtccCurrency(String currency) 
	{
		String dtccCurrency;

		if(null == currencyCache)
			loadCurrencyCache();

		String val = currencyCache.get(currency);

		dtccCurrency = val == null ? currency : val;

		return dtccCurrency;
	}

	private void loadCurrencyCache()
	{
		String key;
		String srcCurr;
		String dttcCurr;

		DomainMappingCache domainCache = DomainMappingCache.getInstance();

		currencyCache 		= new HashMap<String, String>(5);

		Set<String> keys 	= domainCache.getKeys();

		if(null != keys)
		{
			Iterator<String> itr = keys.iterator();

			while(itr.hasNext())
			{
				key = itr.next();

				if(null == key) continue;

				if(key.contains(CURRENCY_DOMAIN))
				{
					srcCurr = key.split(Constants.UNDERSCORE)[1];
					dttcCurr= domainCache.getValue(key);

					currencyCache.put(srcCurr, dttcCurr);
				}
			}
		}
	}

}
