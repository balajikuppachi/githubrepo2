/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;


/**
 * @author Jayshri Vispute
 * @date 09/03/2015
 * @version 1.0
 */

@Component
public class MarketActionTypeEnricher 
{
	private static Logger logger = Logger.getLogger(MarketActionTypeEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering MarketActionTypeEnricher() method");

		TradeHeaderType 	trdHeader 				= null;
		ReportingContext 	context 				= null;
		String 				actionType 				= null;
		String				eventType				= null;
		String 				assetClass				= null;
		String 				action_type_domain_key 	= null;
		String 				domain_action_type 		= null;
		DomainMappingCache  cache 					= null;
		SdrRequest 			request 				= null;
		RegulatoryType 		regulatory 				= null;
		LifeCycleType		lifecycle				= null;
		String				eventSubType			= null;
		String              trade_type_value        = null; 
		KeywordsType 		keywordsType            = null;
		String				sdrAction               = null;
		String 				tradeAction             = null;
		
		if(null == message) return message;

		try
		{
			context 	= 	(ReportingContext) message.getPayload();
			trdHeader 	= 	context.getSdrRequest().getTrade().getTradeHeader();
			lifecycle	= 	trdHeader.getLifeCycle();
			//	eventType	= 	context.getLifeCycleEvent();
			eventType 	=   lifecycle.getEventType();
			actionType 	= 	trdHeader.getAction();
			assetClass	=	context.getAssetClass();
			request 	= context.getSdrRequest();
			regulatory 	= request.getTrade().getRegulatory();
			eventSubType =   lifecycle.getEventSubType();
			trade_type_value 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);
			tradeAction =  context.getSdrRequest().getTrade().getTradeHeader().getTradeAction();
			cache = DomainMappingCache.getInstance();
			
			//unlock USI scenario  - to send exit message
			keywordsType = context.getSdrRequest().getTrade().getRegulatory().getKeywords();
			sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);

			if(StringUtils.equalsIgnoreCase(sdrAction, Constants.SDR_ACTION_EXIT))
			{
				action_type_domain_key=StringUtils.join(new String[]{Constants.ACTION_TYPE_SS,Constants.SDR_ACTION_EXIT},  Constants.UNDERSCORE);
			}
			else if(StringUtils.equalsIgnoreCase(sdrAction, Constants.SDR_ACTION_NEW))
			{
				action_type_domain_key=StringUtils.join(new String[]{Constants.ACTION_TYPE_SS,Constants.SDR_ACTION_NEW},  Constants.UNDERSCORE);
			}
			else if(GeneralUtils.IsNullOrBlank(eventSubType))
				action_type_domain_key=StringUtils.join(new String[]{Constants.ACTION_TYPE_SS,assetClass,actionType,eventType},  Constants.UNDERSCORE);
			else
				action_type_domain_key=StringUtils.join(new String[]{Constants.ACTION_TYPE_SS,assetClass,actionType,eventType,eventSubType},  Constants.UNDERSCORE);
			
			domain_action_type = cache.getValue(action_type_domain_key);
			
			
			/**In case of novations - check 123 & 456 trade */
			if(!GeneralUtils.IsNullOrBlank(domain_action_type) &&  !StringUtils.equalsIgnoreCase(Constants.N_A,domain_action_type) &&  StringUtils.contains(domain_action_type,Constants.BACKSLASH) )
			{
				String[] actionTypes=StringUtils.split(domain_action_type,Constants.BACKSLASH);
				if(StringUtils.equalsIgnoreCase(Constants.Reportable456,trade_type_value))
				{	
					domain_action_type = actionTypes[0];
				}
				else
				{	
					domain_action_type = actionTypes[1];
				}
					
			}
			
			/**Where TradeAction is one of the Re-send Keywords & action type is N then make action type as M **/
			if(ArrayUtils.contains(Constants.NO_REALTIME_REPORTS_REQD, tradeAction) && Constants.ACTION_TYPE_NEW.equals(domain_action_type) && !ArrayUtils.contains(Constants.NO_REALTIME_REPORTS_REQD, sdrAction))
			{
				domain_action_type=Constants.ACTION_TYPE_MODIFY;
			}
			
			ReportingDataUtils.addKeyword(regulatory, Constants.MARKET_ACTION_TYPE_DOMAIN_VALUE, domain_action_type);

		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while converting action type : ", e);
		}

		logger.debug("Leaving MarketActionTypeEnricher() method");

		return message;

	}
	
	
}
