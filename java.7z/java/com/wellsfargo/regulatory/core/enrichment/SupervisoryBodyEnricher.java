package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.EMIR;
import static com.wellsfargo.regulatory.commons.keywords.Constants.SUPERVISORY_BODY;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.JURISDICTION_CANADA_SHORT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRUE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.COLON;
import static com.wellsfargo.regulatory.commons.keywords.Constants.CAD_ADDITIONAL_REPOSITORY;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class SupervisoryBodyEnricher
{
	private static Logger logger = Logger.getLogger(SupervisoryBodyEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichSupervisoryBody() method");

		RegulatoryType 		regulatory 	= null;
		ReportingContext 	context 	= null;
		SdrRequest 			request 	= null;
		String 				errorString = null;		
		String				isCadReportable = "isCadReportable";
		StringBuffer 		cadAdditionalRepository  = null;
		List<String> 		regulatories = null;
		short				marker		= 1;
		String 				currentJur	= null;
		String 				delegateReporting 		= null;

		if(null == message)
			return message;

		try
		{
			context 		= (ReportingContext) message.getPayload();
			request 		= context.getSdrRequest();
			regulatory 		= request.getTrade().getRegulatory();
			regulatories 	= context.getCurrJurisdiction();
			
			for(String jur : regulatories)
			{
				if(null == jur) continue;
				
				if(marker == 1){
					ReportingDataUtils.addKeyword(regulatory, SUPERVISORY_BODY, jur);
					currentJur = jur;
				}
				else
					ReportingDataUtils.addKeyword(regulatory, SUPERVISORY_BODY+UNDERSCORE+(marker), jur);
				
				marker++;
			}
			
			// New keywords for OnBehalfOf and EOD reporting Regime population for the support of EOD Delegate submissions
			
			List<ReportingEligibilityType> reportingList = regulatory.getReportingEligibility();
			for (ReportingEligibilityType reporting : reportingList)
			{
				delegateReporting = reporting.getDelegatedReporting();
				
				if (EMIR.equals(delegateReporting))
				{
					if 	(Constants.JURISDICTION_ESMA.equals(reporting.getReportingJurisdiction().name())){
						ReportingDataUtils.addKeyword(regulatory, Constants.ONBEHALF_OF_PARTY + "1", Constants.PARTY1);
						ReportingDataUtils.addKeyword(regulatory, Constants.ONBEHALF_OF_PARTY + "2", Constants.PARTY2);
						ReportingDataUtils.addKeyword(regulatory, Constants.REPORTING_OBLIGATION +"1", Constants.JURISDICTION_ESMA);
						ReportingDataUtils.addKeyword(regulatory, Constants.REPORTING_OBLIGATION +"2", Constants.JURISDICTION_ESMA);
						ReportingDataUtils.addKeyword(regulatory, Constants.SUBMITTER_OBLIGATION, Constants.JURISDICTION_ESMA);
					} else if (Constants.JURISDICTION_CFTC.equals(reporting.getReportingJurisdiction().name())){
						// It can be either CFTC or ESMA side reporting.
						if (Constants.JURISDICTION_ESMA.equals(currentJur)){
						ReportingDataUtils.addKeyword(regulatory, Constants.ONBEHALF_OF_PARTY + "2", Constants.PARTY2);
						ReportingDataUtils.addKeyword(regulatory, Constants.REPORTING_OBLIGATION +"2", Constants.JURISDICTION_ESMA);
						ReportingDataUtils.addKeyword(regulatory, Constants.SUBMITTER_OBLIGATION, Constants.JURISDICTION_ESMA);
						} else { 
							ReportingDataUtils.addKeyword(regulatory, Constants.ONBEHALF_OF_PARTY + "1", Constants.PARTY1);
							ReportingDataUtils.addKeyword(regulatory, Constants.REPORTING_OBLIGATION +"1", Constants.JURISDICTION_CFTC);
							ReportingDataUtils.addKeyword(regulatory, Constants.SUBMITTER_OBLIGATION, Constants.JURISDICTION_CFTC);
						}
					}
						
				}else{
					ReportingDataUtils.addKeyword(regulatory, Constants.REPORTING_OBLIGATION +"1",currentJur);
					ReportingDataUtils.addKeyword(regulatory, Constants.SUBMITTER_OBLIGATION, currentJur);
				}
			}
			
			if(context.getCurrJurisdiction().contains(JurisdictionEnum.CA_MB_MSC.value())
				    ||context.getCurrJurisdiction().contains(JurisdictionEnum.CA_ON_OSC.value())
				    ||context.getCurrJurisdiction().contains(JurisdictionEnum.CA_QC_AMF.value()))
			{			
				ReportingDataUtils.addKeyword(regulatory, isCadReportable, TRUE);
				
				cadAdditionalRepository = new StringBuffer("NRP:");
				
				for(String jur : regulatories)
				{
					if(null == jur) continue;
					
					cadAdditionalRepository.append(jur);	
					cadAdditionalRepository.append(COLON);
				}
				
				if(cadAdditionalRepository.length() > 0)
					cadAdditionalRepository.delete(cadAdditionalRepository.length()-1, cadAdditionalRepository.length());
				
				ReportingDataUtils.addKeyword(regulatory, CAD_ADDITIONAL_REPOSITORY, cadAdditionalRepository.toString());
			}
		}
		catch (Exception e)
		{
			errorString = "Error while poplulating Supervisory Body keyword" + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("sndTo:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving enrichSupervisoryBody() method");

		return message;

	}
}
