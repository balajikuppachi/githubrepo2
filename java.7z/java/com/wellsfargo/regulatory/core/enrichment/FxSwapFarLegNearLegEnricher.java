/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.ASSET_CLASS_FOREX;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FX;
import static com.wellsfargo.regulatory.commons.keywords.Constants.HYPHEN;
import static com.wellsfargo.regulatory.commons.keywords.Constants.PRODUCT_TYPE_FXSWAP;
import static com.wellsfargo.regulatory.commons.keywords.Constants.PRODUCT_TYPE_FXForward;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FX_SWAP_FAR_LEG;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FX_SWAP_NEAR_LEG;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRADINGEVENT_AGREEMENTDATE;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

/**
 * @author u235720
 *
 */
@Component
public class FxSwapFarLegNearLegEnricher 
{
	private static Logger logger = Logger.getLogger(FxSwapFarLegNearLegEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.info("Entering FxSwapFarLegNearLegEnricher() method");

		
		ReportingContext 	context 				= null;
		SdrRequest 			request 				= null;
		List<LegType> 		legList 				= null;
		String 				productType			 	= null;
		String 				assetClass 				= null;
		LegType				legType1				= null;
		LegType				legType5				= null;
		String				tradeId					= null;
		
		if(null == message) return message;

		try
		{
			context 					= 	(ReportingContext) message.getPayload();
			request 					= 	context.getSdrRequest();
			legList 					= 	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getLeg();
			productType					=	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductType();
			assetClass 					=  	context.getAssetClass();
			tradeId						= 	context.getSdrRequest().getTrade().getTradeHeader().getTradeId();
			
			if(ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass) || FX.equalsIgnoreCase(assetClass))
			{
				if(PRODUCT_TYPE_FXSWAP.equalsIgnoreCase(productType))
				{
					
					if(StringUtils.contains(tradeId, FX_SWAP_NEAR_LEG)){
					
						if(null != legList && !legList.isEmpty()){
							
							legType1 = legList.get(0);
							
							if(null != legType1){
								
								mapFxValueDate(legType1, request);
							}
							
						}
					}
					else if(StringUtils.contains(tradeId, FX_SWAP_FAR_LEG)){
						
						 if(null != legList && !legList.isEmpty()){
							
							 // Temporary Fix : Logic needs to be changed once we finalize on number and sequence of legs in case of Fx Swap from 1STR side.
							 // Currently 1STR populates Far Leg end date in 5th and 6th leg of sdrRequest xml.
							 if(legList.size() > 4){

								 legType5 = legList.get(4);
									
									if(null != legType5){
										
										mapFxValueDate(legType5, request);
									}
							 }
							
						}
						
					}
					
				} else if (PRODUCT_TYPE_FXForward.equalsIgnoreCase(productType)){
					
					if(null != legList && !legList.isEmpty()){
						
						legType1 = legList.get(0);
						
						if(null != legType1){
							
							mapFxValueDate(legType1, request);
						}
						
					}
				}
			}
			
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while enriching ForeignExchange ValueDate keyword : ", e);
		}

		logger.debug("Leaving FxSwapFarLegNearLegEnricher() method");

		return message;

	}

	private void mapFxValueDate(LegType legType, SdrRequest request) {
		
		StringBuilder 			fxValueDate				= new StringBuilder();
		XMLGregorianCalendar 	maturityDate			= legType.getEndDate();
		RegulatoryType 			regulatory 				= request.getTrade().getRegulatory();

		if(null != maturityDate){
			fxValueDate.append(maturityDate.getYear()).append(HYPHEN).append(maturityDate.getMonth()).append(HYPHEN).append(maturityDate.getDay());	
		}
	
		ReportingDataUtils.addKeyword(regulatory, Constants.FX_VALUE_DATE, fxValueDate.toString());	
		
	}

}
