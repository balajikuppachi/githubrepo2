package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRUE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FALSE;

@Component
public class ClearingStatusEnricher {
	private static Logger logger = Logger.getLogger(ClearingStatusEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering ClearingStatusEnricher() method");

		TradeHeaderType 	trdHeader 				= null;
		ReportingContext 	context 				= null;
		SdrRequest 			request 				= null;
		RegulatoryType 		regulatory 				= null;
		LifeCycleType		lifecycle				= null;
		ClearingType 		clearing 				= null;
		
		if(null == message) return message;

		try
		{
			context 	= 	(ReportingContext) message.getPayload();
			trdHeader 	= 	context.getSdrRequest().getTrade().getTradeHeader();
			lifecycle	= 	trdHeader.getLifeCycle();
			clearing	= 	lifecycle.getClearing();
			request 	= 	context.getSdrRequest();
			regulatory 	= 	request.getTrade().getRegulatory();
			
			if (clearing != null && clearing.isClearedTrade() != null && clearing.isClearedTrade())
			{
				
				ReportingDataUtils.addKeyword(regulatory, Constants.CLEARING_STATUS_KEYWORD, TRUE);
			}
			else
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.CLEARING_STATUS_KEYWORD, FALSE);
			}
			
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while getting clearing status: ", e);
		}


		logger.debug("Leaving ClearingStatusEnricher() method");

		return message;

	}
}
