/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.AS_OF_DATE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.AS_OF_TIME;
import static com.wellsfargo.regulatory.commons.keywords.Constants.COLON;
import static com.wellsfargo.regulatory.commons.keywords.Constants.HYPHEN;

import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

/**
 * @author Amit Rana
 *
 */

@Component
public class AsOfDateTimeEnricher 
{
	private static Logger logger = Logger.getLogger(CurrencyTypeEnricher.class.getName());
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering AsOfDateTimeEnricher() method");
		
		ReportingContext 		context 	= null;
		StringBuilder			asOfDate	= null;
		StringBuilder			asOfTime	= null;
		XMLGregorianCalendar	date		= null;
		RegulatoryType 			regulatory 	= null;

		if(null == message) return message;

		try
		{
			if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
			{
				logger.error("############################# Incoming payload is not of Reporting type. " + "Returning.######################");
				return message;
			}

			context 	= (ReportingContext) message.getPayload();
			regulatory 	= context.getSdrRequest().getTrade().getRegulatory();
						
			date = CalendarUtils.toXMLGregorianCalendar(new Date());
			
			if(null != date)
			{
				asOfDate = new StringBuilder();
				asOfTime = new StringBuilder();		
			
				asOfDate.append(date.getYear()).append(HYPHEN).append(date.getMonth()).append(HYPHEN).append(date.getDay());
				asOfTime.append(date.getHour()).append(COLON).append(date.getMinute()).append(COLON).append(date.getSecond());
									
				ReportingDataUtils.addKeyword(regulatory, AS_OF_DATE, asOfDate.toString());					
				ReportingDataUtils.addKeyword(regulatory, AS_OF_TIME, asOfTime.toString());
			}
			
		}
		catch(Exception e)
		{
			logger.error("######## Exception occured while calculating as of dateTime : ", e);
		}
		
		logger.debug("Leaving AsOfDateTimeEnricher() method");
		return message;
	}	

}
