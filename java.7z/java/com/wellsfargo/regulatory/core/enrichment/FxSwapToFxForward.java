/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.ASSET_CLASS_FOREX;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FOREX_FORWARD;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FX;
import static com.wellsfargo.regulatory.commons.keywords.Constants.PRODUCT_TYPE_FOREX_SWAP_SINGLE_LEG;
import static com.wellsfargo.regulatory.commons.keywords.Constants.PRODUCT_TYPE_FXSWAP;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * @author u337814
 *
 */
@Component
public class FxSwapToFxForward 
{
	private static Logger logger = Logger.getLogger(FxSwapToFxForward.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		TradeDetailType 	trdDetail 	= null;
		ReportingContext 	context 	= null;
		String 				assetClass 	= null;
		String				prdType		= null;

		logger.debug("Entering FxSwapToFxForward() method");

		if(null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			trdDetail 	= context.getSdrRequest().getTrade().getTradeDetail();
			assetClass 	= context.getAssetClass();
			prdType		= context.getProductType();
			
			/*** Modify and convert product FXSwap to FXForward, FpML product as FxSingleLeg  ***/
			if(ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass) || FX.equalsIgnoreCase(assetClass))
			{
				if(PRODUCT_TYPE_FXSWAP.equalsIgnoreCase(prdType))
				{
					context.setProductType(FOREX_FORWARD);
					context.setFpmlProductType(PRODUCT_TYPE_FOREX_SWAP_SINGLE_LEG);
					trdDetail.getProduct().setProductType(PRODUCT_TYPE_FOREX_SWAP_SINGLE_LEG);
				}
			}
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while converting Fx swap product type : ", e);
		}

		logger.debug("Leaving FxSwapToFxForward() method");

		return message;

	}

}
