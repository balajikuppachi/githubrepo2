/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;


/**
 * @author Jayshri Vispute
 * @date 09/03/2015
 * @version 1.0
 */

@Component
public class MarketTransActionTypeEnricher 
{
	private static Logger logger = Logger.getLogger(MarketTransActionTypeEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering MarketTransActionTypeEnricher() method");

		TradeHeaderType trdHeader 			= null;
		ReportingContext context 			= null;
		String actionType 					= null;
		String eventType 					= null;
		String assetClass 					= null;
		String domain_transaction_type 		= null;
		String transaction_type_domain_key 	= null;
		DomainMappingCache cache 			= null;
		SdrRequest request 					= null;
		RegulatoryType regulatory 			= null;
		LifeCycleType lifecycle 			= null;
		String eventSubType				    = null;
		KeywordsType keywordsType                   = null;
		String sdrAction                            = null;
				
		if(null == message) return message;

		try
		{
			context 			= 	(ReportingContext) message.getPayload();
			trdHeader 			= 	context.getSdrRequest().getTrade().getTradeHeader();
			actionType 			= 	trdHeader.getAction();
			lifecycle			= 	trdHeader.getLifeCycle();
			eventType 			=   lifecycle.getEventType();
			assetClass			=	context.getAssetClass();
			request 			= 	context.getSdrRequest();
			regulatory 			= 	request.getTrade().getRegulatory();
			eventSubType        =   lifecycle.getEventSubType();
			
			cache = DomainMappingCache.getInstance();
			
			//transaction_type_domain_key	= Constants.TRANSACTION_TYPE_SS + Constants.UNDERSCORE + assetClass + Constants.UNDERSCORE + actionType + Constants.UNDERSCORE + eventType;
		
			//unlock USI scenario  - to send exit message
			keywordsType = context.getSdrRequest().getTrade().getRegulatory().getKeywords();
			sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);

			if(StringUtils.equalsIgnoreCase(sdrAction, Constants.SDR_ACTION_EXIT))
			{
				transaction_type_domain_key	= StringUtils.join(new String[] { Constants.TRANSACTION_TYPE_SS, Constants.SDR_ACTION_EXIT}, Constants.UNDERSCORE);	
			}
			/*** Join all Strings in the Array into a Single String, separated by _ ***/
			else if(GeneralUtils.IsNullOrBlank(eventSubType))
				transaction_type_domain_key	= StringUtils.join(new String[] { Constants.TRANSACTION_TYPE_SS, assetClass, actionType, eventType }, Constants.UNDERSCORE);
			else
				transaction_type_domain_key	= StringUtils.join(new String[] { Constants.TRANSACTION_TYPE_SS, assetClass, actionType, eventType,eventSubType }, Constants.UNDERSCORE);
			
			domain_transaction_type 	= cache.getValue(transaction_type_domain_key);
			
			String trade_type_value 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);
			
			/*** VERY IMPORTANT : Below scenario is only all calypso trades when Novation-RP/Novation-OR event comes and the trade type is non reportable then treating the Trade life-cycle as Exit. ***/
			if(Constants.Trade_Exit.equalsIgnoreCase(domain_transaction_type) )
			{
				if(ArrayUtils.contains(Constants.EXIT_NOVATION_RP_LEVEL_2,trade_type_value))
				{
					domain_transaction_type = Constants.Exit;
				}else
				{
					domain_transaction_type = Constants.Trade;
				}
			}
			
			ReportingDataUtils.addKeyword(regulatory, Constants.MARKET_TRANSACTION_TYPE_DOMAIN_VALUE, domain_transaction_type);
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while converting market transaction type : ", e);
		}

		logger.debug("Leaving MarketTransActionTypeEnricher() method");

		return message;

	}
	
	
}
