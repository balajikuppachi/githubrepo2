package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class CounterPartySchemaEnricher 
{
	private static Logger logger = Logger.getLogger(CounterPartySchemaEnricher.class.getName());
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichCounterPartySchema() method");
		
		ProductType product 		= null;
		ReportingContext context 	= null;
		String errorString 			= null;
		String cpPartyLei  			= null;
		String cpPartyLeiPrefix 		= null;
		String ctrPartySchema 		= null;

		if(null == message)
			return message;

		try
		{
			context = (ReportingContext) message.getPayload();
			product = context.getSdrRequest().getTrade().getTradeDetail().getProduct();
			
			if ( null != context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEIPrefix() )
			{
				cpPartyLeiPrefix = context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEIPrefix();
			}	
			
			if( null == cpPartyLeiPrefix && null != context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEI() )
			{
				cpPartyLei = context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEI();
				if (cpPartyLei.indexOf(":") >= 0)
				cpPartyLeiPrefix = cpPartyLei.substring(0, cpPartyLei.indexOf(":"));
			}
				
			if (cpPartyLeiPrefix == null)
			{
				logger.error("############################# ctrPartySchema:1 : Counter party Lei prefix is null. Returning.######################");
				return message;
			}
			
			ctrPartySchema = ReportingDataUtils.getPartySchema(cpPartyLeiPrefix);
			
			if (ctrPartySchema != null)
				ReportingDataUtils.addKeyword(product, Constants.COUNTERPARTY_SCHEMA, ctrPartySchema);

		}
		catch (Exception e)
		{
			errorString = "Error while poplulating counterPartySchema keyword" + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("ctrPartySchema:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving CounterPartySchemaEnricher() method");

		return message;
	}
 
}
