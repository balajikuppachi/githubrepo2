package com.wellsfargo.regulatory.core.enrichment;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;

@Component
public class EmirTaxonomyEnricher {
	private static Logger logger = Logger.getLogger(EmirTaxonomyEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		List<TradePartyType> 	tradeParties 	= null;
		TradePartyType 			tradeParty 		= null;
		ReportingContext 		context			= null;
		
		logger.debug("Entering EmirTaxonomy enricher");

		if(null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			tradeParties 	= context.getSdrRequest().getTrade().getTradeDetail().getTradeParties().getParty();

			if (null == tradeParties)
			{
				logger.debug("########## TradeParties not found, TradeParties is null. Aborting Emir Taxonomy Enricher");
				return message;
			}
			for (int i = 0; i < tradeParties.size(); i++)
			{
				tradeParty = tradeParties.get(i);
				if (tradeParty.getEmirTaxonomy()!= null &&  Constants.N_A.equals(tradeParty.getEmirTaxonomy())){
					
					tradeParty.setEmirTaxonomy(null);
				}

			}
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while enriching emirTaxonomy : ", e);
		}

		logger.debug("Leaving EmirTaxonomyEnricher()");

		return message;

	}
}
