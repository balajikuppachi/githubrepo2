package com.wellsfargo.regulatory.core.enrichment;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class ReferenceEntityIndexNameEnricher {

	private static Logger logger = Logger.getLogger(ReferenceEntityIndexNameEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering ReferenceEntityIndexNameEnricher() method");

		ReportingContext 	context 					= null;
		String 				assetClass					= null;
		SdrRequest 			request 					= null;
		RegulatoryType 		regulatory 					= null;
		LegType				leg1						= null;
		BigDecimal 			quoteValue1					= null;
		BigDecimal 			quoteValue2					= null;
		String				quoteUnits1					= null;
		String				quoteUnits2					= null;
		String				measureType1				= null;
		String				measureType2				= null;
		String 				productType			 		= null;
		boolean 			isCDXIndexHY				= false;
		
		
		if(null == message) return message;

		try
		{
			context 			= 	(ReportingContext) message.getPayload();
			assetClass			=	context.getAssetClass();
			request 			= 	context.getSdrRequest();
			regulatory 			= 	request.getTrade().getRegulatory();
			productType			=	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductType();
			leg1				= 	request.getTrade().getTradeDetail().getProduct().getLeg().get(0);
						
			
			if (Constants.ASSET_CLASS_CREDIT.equals(assetClass))
			{
				if (Constants.PRODUCT_TYPE_CDSIndex.equals(productType))
				{
					
					if(null != context.getSdrRequest().getTrade().getTradeDetail().getProduct().getCdsTerms()
							 && null != context.getSdrRequest().getTrade().getTradeDetail().getProduct().getCdsTerms().getIndexInformation()
							 && null != context.getSdrRequest().getTrade().getTradeDetail().getProduct().getCdsTerms().getIndexInformation().getIndexName())
					{
						
						if(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getCdsTerms().getIndexInformation().getIndexName().contains(Constants.CDX_HY_INDEX)){
							isCDXIndexHY = true;
						} 
					} 					
				}
				
				if(isCDXIndexHY){
					
					if(null != leg1 && null != leg1.getPrice()){
						quoteValue2 = leg1.getPrice();
					}
					measureType2 = Constants.PRICENOTATION;
					quoteUnits2 = Constants.PRICE;
					
				} else {
				
					if(null != leg1 && null != leg1.getSpread()){
						quoteValue1 = leg1.getSpread();	
					}
					
					measureType1 = Constants.PRICENOTATION;
					quoteUnits1 = Constants.BASISPOINTS;
					
					if(null != leg1 && null != leg1.getPrice()){
						quoteValue2 = leg1.getPrice();
					}
					measureType2 = Constants.ADDITIONALPRICENOTATION;
					quoteUnits2 = Constants.PRICE;
				}
				
				
				if (quoteValue1 != null)
				{
					//quoteValue1= ConversionUtils.parseBigDecimal(ConversionUtils.formatDecimal8(quoteValue1));
					ReportingDataUtils.addKeyword(regulatory, Constants.RefEntityQuoteValue1, quoteValue1.toString());
				}
				
				ReportingDataUtils.addKeyword(regulatory, Constants.RefEntityMeasureType1, measureType1);
				ReportingDataUtils.addKeyword(regulatory, Constants.RefEntityQuoteUnit1, quoteUnits1);
				
				if (quoteValue2 != null)
				{
					ReportingDataUtils.addKeyword(regulatory, Constants.RefEntityQuoteValue2, quoteValue2.toString());
				}
				
				ReportingDataUtils.addKeyword(regulatory, Constants.RefEntityMeasureType2, measureType2);
				ReportingDataUtils.addKeyword(regulatory, Constants.RefEntityQuoteUnit2, quoteUnits2);				
				
			}
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while populating Reference enitity quote fields : ", e);
		}


		logger.debug("Leaving ReferenceEntityIndexNameEnricher() method");

		return message;

	}
}
