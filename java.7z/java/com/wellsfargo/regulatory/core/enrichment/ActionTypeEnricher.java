/**
 *
 */
package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.Cancel;
import static com.wellsfargo.regulatory.commons.keywords.Constants.EVENT_TYPE_NEW;
import static com.wellsfargo.regulatory.commons.keywords.Constants.Modify;
import static com.wellsfargo.regulatory.commons.keywords.Constants.New;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author u337814
 *
 *	This is a temporary enricher, which is converting all modify
 *
 */
@Component
public class ActionTypeEnricher 
{
	private static Logger logger = Logger.getLogger(ActionTypeEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering ActionTypeEnricher() method");

		TradeHeaderType 	trdHeader 	= null;
		ReportingContext 	context 	= null;
		String 				actionType 	= null;
		String				eventType	= null;
		LifeCycleType		lifecycle	= null;

		if(null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			trdHeader 	= context.getSdrRequest().getTrade().getTradeHeader();
			actionType 	= trdHeader.getAction();
			lifecycle	= trdHeader.getLifeCycle();
			eventType	= lifecycle.getEventType();

			if(ArrayUtils.contains(Constants.UNDO_LCE_LIST, eventType))
			{
				context.getSdrRequest().getTrade().getTradeHeader().setAction(Cancel);
			}
			else if(Modify.equalsIgnoreCase(actionType))
			{
				/*** For all the event types update the actionType to New ***/
				if(null != lifecycle && !EVENT_TYPE_NEW.equalsIgnoreCase(lifecycle.getEventType()))
					context.getSdrRequest().getTrade().getTradeHeader().setAction(New);
			}

		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while converting action type : ", e);
		}

		logger.debug("Leaving ActionTypeEnricher() method");

		return message;

	}

}
