package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.TRADE_STATUS_TRADER_REVIEW;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRADE_STATUS_TRADER_REV;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

@Component
public class TradeStatusEnricher 
{
	private static Logger logger = Logger.getLogger(TradeStatusEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		TradeHeaderType 	trdHeader 	= null;
		ReportingContext 	context 	= null;
		String 				status 		= null;

		logger.debug("Entering TradeStatusEnricher() method");

		if(null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			trdHeader 	= context.getSdrRequest().getTrade().getTradeHeader();
			status 		= trdHeader.getStatus();
			
			/*if (StringUtils.equalsIgnoreCase(TRADE_STATUS_TRADER_REV, status)){
				context.getSdrRequest().getTrade().getTradeHeader().setStatus(TRADE_STATUS_TRADER_REVIEW);
			} else*/ 	
			
			if(status != null && status.equals("DAY_TRADER_REV"))
			{
				context.getSdrRequest().getTrade().getTradeHeader().setStatus("DAY_TRADER_REVIEW");
			}
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while converting status : ", e);
		}

		logger.debug("Leaving TradeStatusEnricher() method");

		return message;

	}
}
