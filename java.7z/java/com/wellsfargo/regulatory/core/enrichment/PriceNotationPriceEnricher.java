package com.wellsfargo.regulatory.core.enrichment;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class PriceNotationPriceEnricher {

	private static Logger logger = Logger.getLogger(PriceNotationPriceEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering PriceNotationPriceEnricher() method");

		ReportingContext 	context 					= null;
		String 				assetClass					= null;
		SdrRequest 			request 					= null;
		RegulatoryType 		regulatory 					= null;
		String 				fpmlProductType				= null;
		LegType				leg1						= null;
		LegType				leg2						= null;
		BigDecimal			priceNotationPrice			= null;	
		String				priceNotationPriceType		= null;
		
		if(null == message) return message;

		try
		{
			context 			= 	(ReportingContext) message.getPayload();
			assetClass			=	context.getAssetClass();
			request 			= 	context.getSdrRequest();
			regulatory 			= 	request.getTrade().getRegulatory();
			fpmlProductType 	= 	context.getFpmlProductType();
			leg1				= 	request.getTrade().getTradeDetail().getProduct().getLeg().get(0);
						
			if (request.getTrade().getTradeDetail().getProduct().getLeg().size() > 1 )
			{
				leg2 = request.getTrade().getTradeDetail().getProduct().getLeg().get(1);
			}
			
			if (Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
			{
				if (Constants.PRODUCT_TYPE_SWAP.equals(fpmlProductType) || Constants.PRODUCT_TYPE_FRA.equals(fpmlProductType))
				{
					if (leg1.getFixedRate() != null)
					{
						priceNotationPrice = ConversionUtils.getPercentile(leg1.getFixedRate());
						priceNotationPriceType = "Percentage";
					}
					else if (leg2 != null && leg2.getFixedRate() != null)
					{
						priceNotationPrice = ConversionUtils.getPercentile(leg2.getFixedRate());
						priceNotationPriceType = "Percentage";
					}
					else if (leg1.getSpread() != null)
					{
						priceNotationPrice = ConversionUtils.getPercentile(ConversionUtils.getPercentile(leg1.getSpread()));
						priceNotationPriceType = "BasisPoints";
					}
					else if (leg2.getSpread() != null)
					{
						priceNotationPrice = ConversionUtils.getPercentile(ConversionUtils.getPercentile(leg2.getSpread()));
						priceNotationPriceType = "BasisPoints";
					}
				} 
				else if (Constants.PRODUCT_TYPE_SWAPTION.equals(fpmlProductType))
				{
					if (leg1.getOptionStrike() != null)
					priceNotationPrice = ConversionUtils.getPercentile(leg1.getOptionStrike());
				}
				else if (Constants.PRODUCT_TYPE_CAPFLOOR.equals(fpmlProductType))
				{
					if (leg1.getCapStrike() != null)
					priceNotationPrice = ConversionUtils.getPercentile(leg1.getCapStrike());
					
					else if (leg1.getFloorStrike() != null)
					priceNotationPrice = ConversionUtils.getPercentile(leg1.getFloorStrike());
				}
				else if (Constants.PRODUCT_TYPE_GENERIC.equals(fpmlProductType))
				{
					if ("bps".equals(leg1.getPriceUnit()) )
					{
						priceNotationPrice = leg1.getPrice();
						priceNotationPriceType = "BasisPoints";
					} 
					else if ("Percent".equals(leg1.getPriceUnit()))
					{
						priceNotationPrice = leg1.getPrice();
						priceNotationPriceType = "Percentage";
					}
				}
				
				if (priceNotationPrice != null)
				{
					priceNotationPrice= ConversionUtils.parseBigDecimal(ConversionUtils.formatDecimal8(priceNotationPrice));
					ReportingDataUtils.addKeyword(regulatory, Constants.PRICE_NOTATION_PRICE, priceNotationPrice.toString());
				}
				if (priceNotationPriceType != null)
				{
					ReportingDataUtils.addKeyword(regulatory, Constants.PRICE_NOTATION_PRICE_TYPE, priceNotationPriceType);
				}
			}
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while populating price notation fields : ", e);
		}


		logger.debug("Leaving PriceNotationPriceEnricher() method");

		return message;

	}
}
