package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

/**
 * @author 		-	JV - U377103
 * Created on	-	20151116
 * Description	-	If the ClearingHouseLEI in the input XML is None or NULL then populate false else populate true.
 */

@Component
public class IntentToClearEnricher {
	private static Logger logger = Logger.getLogger(IntentToClearEnricher.class.getName());
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering IntentToClearEnricher() method");

		ReportingContext 	context 				= null;
		String 				intent_to_clear		 	= null;
		SdrRequest 			request 				= null;
		RegulatoryType 		regulatory 				= null;
	
		
		if(null == message) return message;

		try
		{
			context 					= 	(ReportingContext) message.getPayload();
			
			/**STR 428:Real Time Messages missing Clearing indicator  
			 * 
			 * Changed the logic from CC_ClearingHouse to KW.CCP.
			 * When there is a value in the {KW.CCP} tag, send "True" for Intent to Clear. In no value is present in the {KW.CCP} tag {KW.CCP} tag, send "False"
			 * 
			 * */
			String kwCcp 			= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeHeader().getKeywords(),Constants.KW_CCP);	
		
				
		
			context.getAssetClass();
			request 	= context.getSdrRequest();
			regulatory 	= request.getTrade().getRegulatory();
			
			if(	GeneralUtils.IsNullOrBlank(kwCcp) || Constants.NONE.equalsIgnoreCase(kwCcp))
				intent_to_clear=Constants.FALSE;
			else
				intent_to_clear=Constants.TRUE;
			
			ReportingDataUtils.addKeyword(regulatory, Constants.INTENT_TO_CLEAR, intent_to_clear);

		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while enriching intent to clear keyword : ", e);
		}

		logger.debug("Leaving IntentToClearEnricher() method");

		return message;

	}

}
