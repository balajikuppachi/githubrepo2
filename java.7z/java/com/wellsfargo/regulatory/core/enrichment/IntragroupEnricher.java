package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class IntragroupEnricher {
	private static Logger logger = Logger.getLogger(IntragroupEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering IntragroupEnricher() method");

		ReportingContext 	context 	= null;
		RegulatoryType 		regulatory 	= null;
		SdrRequest 			request 	= null;
		TradeHeaderType 	trdHeader 	= null;
		String 				assetClass	= null;
		
		if(null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			regulatory  = context.getSdrRequest().getTrade().getRegulatory();
			request 	= context.getSdrRequest();
			trdHeader 	= request.getTrade().getTradeHeader();
			assetClass	= request.getAssetClass();
			
			String leiUsValue = trdHeader.getProcessingOrgLEIValue();
			String leiCpValue = trdHeader.getCounterpartyLEIValue();
			
			
			if (context.isEsmaReportable())
			{
				
				if (Constants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass))
				{
					if (Constants.wf_lei.equals(leiCpValue) && "SX0CI4F7GVW5530ZMN03".equals(leiUsValue))
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.INTRAGROUP, Constants.TRUE);
					}
					else
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.INTRAGROUP, Constants.FALSE);
					}
						
				}
				else if (Constants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(assetClass))
				{
					if (Constants.wf_lei.equals(leiCpValue) && "BWS7DNS2Z4NPKPNYKL75".equals(leiUsValue))
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.INTRAGROUP, Constants.TRUE);
					}
					else
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.INTRAGROUP, Constants.FALSE);
					}
				}
				
			}
			
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while Intragroup info : ", e);
		}

		logger.debug("Leaving IntragroupEnricher() method");

		return message;

	}
}
