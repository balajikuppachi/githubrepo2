package com.wellsfargo.regulatory.core.enrichment;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class PartialTermAmountEnricher 
{
	private static Logger logger = Logger.getLogger(PartialTermAmountEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichPartialTermAmount() method");
		
		if(null == message)
			return message;
		
		RegulatoryType regulatory 	= null;
		ReportingContext context 	= null;
		String errorString 			= null;
		String assetClass 			= null;
		LifeCycleType lifecycle 	= null;
		LegType leg 				= null;
		BigDecimal termAmount 		= null;

		try
		{
		
			// START : Setting the MDC from the Context
			AbstractDriver.setMDCInfo(context, AbstractDriver.PartialTermAmountEnricher);
			// END : Setting the MDC from the Context
			
			context 		= (ReportingContext) message.getPayload();
			regulatory 		= context.getSdrRequest().getTrade().getRegulatory();
			assetClass 		= context.getSdrRequest().getAssetClass();
			lifecycle 		= context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle();
			String eventType = lifecycle.getEventType();
			
			
			if (!Constants.ASSET_CLASS_EQUITY.equals(assetClass) && Constants.Partial_Term_Voluntary.equals(eventType))
			{
				leg 		= context.getSdrRequest().getTrade().getTradeDetail().getProduct().getLeg().get(0);
				termAmount 	= GeneralUtils.subtract(lifecycle.getOriginalNotional(), leg.getNotional());
			} 
			else 
			{
				leg 		= context.getSdrRequest().getTrade().getTradeDetail().getProduct().getLeg().get(0);
				termAmount 	=  leg.getNotional();
			}

			if ( null != termAmount)
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.PARTIAL_TERMINATION_AMOUNT, "" + termAmount.abs());
			}
			
		}
		catch(Exception e)
		{
			errorString = "Error while poplulating Partial Termination amount" + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("partialTermAmt:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}
		
		logger.debug("Leaving enrichPartialTermAmount() method");

		return message;
	}
}
