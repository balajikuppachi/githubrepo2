package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class WellsFargoNonAffiliatePartySchemaEnricher {
private static Logger logger = Logger.getLogger(WellsFargoNonAffiliatePartySchemaEnricher.class.getName());
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering WellsFargoNonAffiliatePartySchemaEnricher() method");
		
		ProductType product 			= null;
		ReportingContext context 		= null;
		String errorString 				= null;
		String wfPartyLei  				= null;
		String wfPartyLeiPrefix 		= null;
		String wfProcessingOrgLeiValue 	= null;
		String wfPartySchema 			= null;
		if(null == message)
			return message;

		try
		{
			context = (ReportingContext) message.getPayload();
			product = context.getSdrRequest().getTrade().getTradeDetail().getProduct();
						
				if ( null != context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEIPrefix() )
				{
					wfPartyLeiPrefix = context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEIPrefix();
				}	
				
				if( null == wfPartyLeiPrefix && null != context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEI() )
				{
					wfPartyLei = context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEI();
					if (wfPartyLei.indexOf(":") >= 0){
						wfPartyLeiPrefix = wfPartyLei.substring(0, wfPartyLei.indexOf(":"));
						// Set the processingOrgLEIValue if it is missing in the input request. This is to fix the valuation reports missing sentBy tag
						wfProcessingOrgLeiValue = wfPartyLei.substring( wfPartyLei.indexOf(":")+1,wfPartyLei.length());
						context.getSdrRequest().getTrade().getTradeHeader().setProcessingOrgLEIValue(wfProcessingOrgLeiValue);
					}
				}
				
				if (wfPartyLeiPrefix == null)
				{
					logger.error("############################# wfPartySchema1:1 : WF party Lei prefix is null. Returning ..######################");
					return message;
				}
			
				wfPartySchema = ReportingDataUtils.getPartySchema(wfPartyLeiPrefix);
			
			if (wfPartySchema != null)
				ReportingDataUtils.addKeyword(product, Constants.WF_PARTY_SCHEMA1, wfPartySchema);
			
		}
		catch (Exception e)
		{
			errorString = "Error while poplulating WFPartySchema(Party1)1 keyword" + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("wfPartySchema1:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving WellsFargoNonAffiliatePartySchemaEnricher() method");

		return message;
	}
 
}
