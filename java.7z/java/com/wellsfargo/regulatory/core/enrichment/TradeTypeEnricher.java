package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class TradeTypeEnricher 
{
	private static Logger logger = Logger.getLogger(TradeTypeEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering TradeTypeEnricher() method");
		
		if(null == message) return message;
		
		ReportingContext context 	= (ReportingContext) message.getPayload();
		
		//AbstractDriver.setMDCInfo(context, AbstractDriver.TradeTypeEnricher);

		String assetClass 			= context.getAssetClass();
		TradeHeaderType trdHeader 	= context.getSdrRequest().getTrade().getTradeHeader();
		LifeCycleType lifecycle 	= trdHeader.getLifeCycle();
		String eventType 			= lifecycle.getEventType();
		String transferFrom 		= lifecycle.getTransferFrom();
		String transferTo 			= lifecycle.getTransferTo();
		RegulatoryType regulatory 	= context.getSdrRequest().getTrade().getRegulatory();
		String novationAction 		= null;
		String usiCurrent 			= context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().getUSI();
		String usiParent 			= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeHeader().getKeywords(),Constants.Parent_KW_USI_CURRENT);
		String ctrPartyLei 			= trdHeader.getCounterpartyLEI();
		String ctrPatyParentLei 	= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeHeader().getKeywords(), Constants.Parent_KW_LEI_CP);
		String utiParent 			= ReportingDataUtils.getKeyWordContents(context.getSdrRequest().getTrade().getTradeHeader().getKeywords(), Constants.Parent_KW_UTI_CURRENT);
		String utiCurrent 			= context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().getUTI();
		String newNovationTradeId 	= null;
		String tradeId 				= trdHeader.getTradeId();

		try
		{
			
			if (ReportingDataUtils.isSwapWireTrade(trdHeader))
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable123);
			}
			/**This block handles Credit novation cases*/
			else if (Constants.ASSET_CLASS_CREDIT.equals(assetClass) && eventType.contains(Constants.Novation))
			{
				novationAction = lifecycle.getNovation().getNovationAction();
				
				newNovationTradeId = lifecycle.getNovation().getNewNovationTradeId();
				
				if (!GeneralUtils.IsNullOrBlank(novationAction) && !GeneralUtils.IsNullOrBlank(newNovationTradeId))
				{
					if (Constants.Credit_Novation_RP.equals(eventType) && !newNovationTradeId.equals(tradeId))
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.NonReportable123);
					}
					else if ((Constants.Credit_Novation_OR.equals(eventType) || Constants.Credit_Partial_Novation_OR.equals(eventType)) && !GeneralUtils.IsNullOrBlank(novationAction) && Constants.Cancel.equalsIgnoreCase(novationAction))
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable123);
					}
					else if (Constants.Credit_Novation_EE.equals(eventType))
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable123);
					}
					else
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.NonReportable123);
					}
				}
				else if(GeneralUtils.IsNullOrBlank(novationAction) && !GeneralUtils.IsNullOrBlank(newNovationTradeId))
				{
					if(newNovationTradeId.equals(tradeId) && ((!GeneralUtils.IsNullOrBlank(usiCurrent) && !usiCurrent.equalsIgnoreCase(usiParent)) || (!GeneralUtils.IsNullOrBlank(utiCurrent) && !utiCurrent.equalsIgnoreCase(utiParent))))
					{
						/**If the USI/UTI & LEI is changed for  novation RP*/
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable456);
					}
					else
					{
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.NonReportable456);
					}
				}
			}
			 /**This block handles Non Credit novation cases*/
			else if (GeneralUtils.IsNullOrBlank(transferFrom) && GeneralUtils.IsNullOrBlank(transferTo))
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable123);
			}
			else if (!GeneralUtils.IsNullOrBlank(transferTo) && GeneralUtils.IsNullOrBlank(transferFrom))
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.NonReportable123);	
			}
			else if (!GeneralUtils.IsNullOrBlank(transferFrom) && GeneralUtils.IsNullOrBlank(transferTo))
			{
				if (Constants.PartialNovation_RP.equalsIgnoreCase(eventType) || Constants.PartialNovation.equalsIgnoreCase(eventType))
				{
					
					if (((!GeneralUtils.IsNullOrBlank(usiCurrent) && usiCurrent.equals(usiParent)) || (!GeneralUtils.IsNullOrBlank(utiCurrent) && utiCurrent.equals(utiParent))) && !GeneralUtils.IsNullOrBlank(ctrPartyLei) && ctrPartyLei.equals(ctrPatyParentLei))
					{
						/**If the USI/UTI & LEI is not changed for partial novation (PartialNovation)*/
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable123);
					}
					else if (((!GeneralUtils.IsNullOrBlank(usiCurrent) && !usiCurrent.equals(usiParent)) || (!GeneralUtils.IsNullOrBlank(utiCurrent) && !utiCurrent.equals(utiParent))) && !GeneralUtils.IsNullOrBlank(ctrPartyLei) && !ctrPartyLei.equals(ctrPatyParentLei))
					{
						/**If the USI/UTI & LEI is changed for partial novation (PartialNovation - RP)*/
						ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable456);
					}
					
				} else
				{
					ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable456);	
				}
			}
			else if (!GeneralUtils.IsNullOrBlank(transferFrom) && !GeneralUtils.IsNullOrBlank(transferTo))
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.NonReportable456);
				
			}else
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.TRADE_TYPE, Constants.Reportable123);
			}

		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while calculating Trade type : ", e);
		}

		logger.debug("Leaving TradeTypeEnricher() method");

		return message;

	}

}
