package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.CFTC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.COLON;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FALSE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.GTRCREATE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.IS_GTR_USI;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRUE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.USI;
import static com.wellsfargo.regulatory.commons.keywords.Constants.USI_PREFIX;
import static com.wellsfargo.regulatory.commons.keywords.Constants.USI_VALUE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.WELLS;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepUniqueIdentifierMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMappingId;

@Component
public class UsiEnricher
{
	private static Logger logger = Logger.getLogger(UsiEnricher.class.getName());

	@Value("${regRep.usiPrefixOverride}") String usiPrefixOverride;
	@Value("${regRep.wf.affiliate.leis}")  String wfAffiliateLeis;
	  
	//private static String usiPrefixOverride;
	//private static String wfUSIPrefix;

	@Autowired
	private RegRepUniqueIdentifierMappingDao regRepUniqueIdentifierDao;

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichUsi() method");

		String 			usiValue 			= null;
		String 			usiPrefix 			= null;		
		String 			wfLei 				= null;		
		String 			errorString 		= null;
		String 			tradeId 			= null;
		String 			usi 				= null;
		boolean 		isDefaultDtccId 	= false;
		boolean 		isAffiliatedTrade 	= false;
		boolean 		usiUpdated 			= false;
		RegulatoryType 	regulatory 			= null;

		if(null == message)
			return message;

		ReportingContext context 	= (ReportingContext) message.getPayload();
		SdrRequest request 			= context.getSdrRequest();

		// START : Setting the MDC from the Context
		AbstractDriver.setMDCInfo(context, AbstractDriver.UsiEnricher);
		// END : Setting the MDC from the Context

		try	
		{
			
			usi 				= ReportingDataUtils.computeUSI(context);
			regulatory 			= request.getTrade().getRegulatory();
			
			
			
			wfLei 				= (request.getTrade().getTradeHeader().getProcessingOrgLEIValue() != null ) ? request.getTrade().getTradeHeader().getProcessingOrgLEIValue() : request.getTrade().getTradeHeader().getProcessingOrgLEI();
			
			if (wfLei != null && wfLei.indexOf(":")>=0)
				wfLei = wfLei.substring( wfLei.indexOf(":")+1,wfLei.length());
			
			isAffiliatedTrade 	= StringUtils.contains(wfAffiliateLeis, wfLei);
			tradeId 			= context.getSdrRequest().getTrade().getTradeHeader().getTradeId();

			if (isAffiliatedTrade)
			{
				String affiliatedUsi = null;
				RegRepUniqueIdentifierMappingId id = new RegRepUniqueIdentifierMappingId();

				id.setIdentifierType(USI);
				id.setJurisdiction(CFTC);
				id.setRepository(DTCC);
				id.setTradeId(tradeId);

				// Get the affiliated USI from database REG_REP_UNIQUE_IDENTIFIER_MAPPING-->
				/*** CURRENT-VALUE ***/
				RegRepUniqueIdentifierMapping rruim = regRepUniqueIdentifierDao.findByPrimaryKey(id);

				if (rruim != null) 
					affiliatedUsi = rruim.getCurrentValue();

				// if null;
				if (GeneralUtils.IsNullOrBlank(affiliatedUsi)) 
					isDefaultDtccId = true;
				else 
				{
					usi = affiliatedUsi;
					if (context.getSdrRequest().getTrade().getTradeDetail() != null)
						context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().setUSI(usi);
				}
				ReportingDataUtils.addKeyword(regulatory, IS_GTR_USI, TRUE);
			}
			else
			{
				ReportingDataUtils.addKeyword(regulatory, IS_GTR_USI, FALSE);
			}

			if (isDefaultDtccId) 
			{
				usiPrefix 	= GTRCREATE;
				usiValue 	= GTRCREATE;
				usiUpdated 	= true;

			}
			else
			{
				
				if (!StringUtils.isBlank(usiPrefixOverride))
				{
					usiPrefix 	= usiPrefixOverride;
					usiUpdated 	= true;
				}
				else if (usi == null)
				{
					usiPrefix = WELLS;
					usiUpdated = true;
				}
				else if (usi.startsWith(DTCC))
				{
					usiPrefix = usi.substring(0, 4);
				}
				else
				{
					/*** Check put in to handle USI with length less than 10 ***/
					if(usi.length() > 9)
					{
						usiPrefix = usi.substring(0, 10);
					}
					else
					{
						usiPrefix = usi.substring(0, usi.length()-1);
					}
				}
				
				if (usi != null)
				{
					if (usi.startsWith(DTCC)) 
						usiValue = usi.substring(4);
					else
					{
						/*** Check put in place to handle USI length < 10 ***/  
						if(usi.length() > 10)
						{
							usiValue = usi.substring(10);
						}
						else
						{
							// since in this case (USI < 10) : all the digits are put in usi prefix
							// putting " ", so that usiValue doesn't stay null and hence wipes out both prefix and value  in the upcoming check.
							usiValue = usi.substring(usi.length() - 1);
						}
					}

					/*** In case USI is from DTCC, then there will a colon coming from unique identifier mapping table ***/
					if(StringUtils.startsWith(usiValue,COLON))
						usiValue = usi.substring(11);
				}
			}
			
			
			/*
			 * Fix for WELLS:null
			 */
			if(null == usi && (null == usiValue || null == usiPrefix))
			{
				usiUpdated 	= false;
				usiValue 	= "";
				usiPrefix 	= "";
			}

			if (usiUpdated) 
				updateUsi(request, usi, usiPrefix, usiValue);

			//logger.info("---- Regulatory :"+regulatory.getReportingEligibility());
			logger.debug("---- usiValue :"+usiValue);
			logger.debug("---- usiPrefix :"+usiPrefix);

			ReportingDataUtils.addKeyword(regulatory, USI_VALUE, usiValue);
			ReportingDataUtils.addKeyword(regulatory, USI_PREFIX, usiPrefix);
		}
		catch (Exception e)
		{
			errorString = "Error while poplulating USIPrefix and/ USI value keywords : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("sndTo:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving enrichUsi() method");

		return message;
	}

	private void updateUsi(SdrRequest request, String prevUsi, String usiPrefix, String usiValue) throws MessagingException 
	{
		ProductKeysType prdKeys = null;

		try	
		{
			prdKeys = request.getTrade().getTradeDetail().getProduct().getProductKeys();
			prdKeys.setPrevUSI(prevUsi);
			prdKeys.setUSI(usiPrefix + COLON + usiValue);
			
			if(COLON.equals(prdKeys.getUSI()))
					prdKeys.setUSI("");
		}
		catch (Exception e)
		{
			throw new MessagingException("updUsi:1", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage());
		}
	}

	public void setRegRepUniqueIdentifierDao(RegRepUniqueIdentifierMappingDao regRepUniqueIdentifierDao) 
	{
		this.regRepUniqueIdentifierDao = regRepUniqueIdentifierDao;
	}

/*	public static void setUsiPrefixOverride(String usiPrefixOverride)
	{
		UsiEnricher.usiPrefixOverride = usiPrefixOverride;
	}

	public static void setWfUSIPrefix(String wfUSIPrefix)
	{
		UsiEnricher.wfUSIPrefix = wfUSIPrefix;
	}*/

}
