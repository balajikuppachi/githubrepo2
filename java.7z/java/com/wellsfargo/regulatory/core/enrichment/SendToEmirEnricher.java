package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCCEU;
import static com.wellsfargo.regulatory.commons.keywords.Constants.EMIR;
import static com.wellsfargo.regulatory.commons.keywords.Constants.SEND_TO;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class SendToEmirEnricher {
	private static Logger logger = Logger.getLogger(SendToEmirEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering sendToEmirEnricher() method");

		RegulatoryType regulatory 	= null;
		String sendToString 		= null;
		String jurisdiction 		= null;
		ReportingContext context 	= null;
		SdrRequest request 			= null;
		String errorString 			= null;
		String repository			= null;
		String delegateReporting 	= null;
		
		if(null == message)
			return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			request		= context.getSdrRequest();
			regulatory 	= request.getTrade().getRegulatory();
			
			// START : Setting the MDC from the Context
			AbstractDriver.setMDCInfo(context, AbstractDriver.SendToEnricher);
			// END : Setting the MDC from the Context

			List<ReportingEligibilityType> reportingList = request.getTrade().getRegulatory().getReportingEligibility();

			for (ReportingEligibilityType reporting : reportingList)
			{

				repository = reporting.getRepository().value();
				jurisdiction = reporting.getReportingJurisdiction().name();
				delegateReporting = reporting.getDelegatedReporting();
				
				
				if (EMIR.equals(repository) || Constants.JURISDICTION_ESMA.equals(jurisdiction) ||
						EMIR.equals(delegateReporting))
				{
					sendToString = DTCCEU;
					break;
				}
			}
			
			if (sendToString != null)
			logger.debug("---- SendToEmirString :"+sendToString);

			ReportingDataUtils.addKeyword(regulatory, SEND_TO, sendToString);

		}
		catch (Exception e)
		{
			errorString = "Error while poplulating sendToEmir keyword : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("sndToEmir:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving sendToEmirEnricher() method");

		return message;

	}

}
