package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.EMIR;
import static com.wellsfargo.regulatory.commons.keywords.Constants.EMIR_DELEGATE_REPORT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRUE;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class EmirDelegateRptEnricher {
	private static Logger logger = Logger.getLogger(EmirDelegateRptEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering sendToEmirEnricher() method");

		RegulatoryType regulatory 	= null;
		ReportingContext context 	= null;
		SdrRequest request 			= null;
		String errorString 			= null;
		String delegateReporting 	= null;
		
		if(null == message)
			return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			request		= context.getSdrRequest();
			regulatory 	= request.getTrade().getRegulatory();
			
			// START : Setting the MDC from the Context
			AbstractDriver.setMDCInfo(context, AbstractDriver.EmirDelegateRptEnricher);
			// END : Setting the MDC from the Context

			List<ReportingEligibilityType> reportingList = request.getTrade().getRegulatory().getReportingEligibility();

			for (ReportingEligibilityType reporting : reportingList)
			{

				delegateReporting = reporting.getDelegatedReporting();
				
				if (EMIR.equals(delegateReporting))
				{
					ReportingDataUtils.addKeyword(regulatory, EMIR_DELEGATE_REPORT, TRUE);
					
					break;
				}
			}
			
		}
		catch (Exception e)
		{
			errorString = "Error while poplulating isEmirDelegateRpt keyword : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("emirDelRpt:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving EmirDelegateRptEnricher() method");

		return message;

	}
}
