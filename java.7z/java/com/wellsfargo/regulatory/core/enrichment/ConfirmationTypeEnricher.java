package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ConfirmationMethodEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class ConfirmationTypeEnricher
{
	private static Logger logger = Logger.getLogger(ConfirmationTypeEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichConfirmationType() method");

		RegulatoryType regulatory 	= null;
		ReportingContext context 	= null;
		SdrRequest request 			= null;
		String errorString 			= null;
		String confirmationMethod 	= null;

		if(null == message)
			return message;

		try
		{
			context = (ReportingContext) message.getPayload();

			// START : Setting the MDC from the Context
			AbstractDriver.setMDCInfo(context, AbstractDriver.ConfirmationTypeEnricher);
			// END : Setting the MDC from the Context

			request 	= context.getSdrRequest();
			regulatory 	= request.getTrade().getRegulatory();
			
			if ( !Constants.ASSET_CLASS_CREDIT.equals(request.getAssetClass()))
			{
				return message;
			}
			
			if (request.getTrade().getTradeHeader().getConfirmationMethod() != null)
			{
				confirmationMethod = request.getTrade().getTradeHeader().getConfirmationMethod().value();
			}
			
			if (confirmationMethod == null)
			{
				confirmationMethod = ConfirmationMethodEnum.NOT_CONFIRMED.value();
			}
			
			logger.debug("---- ConfirmationType :"+confirmationMethod);

			ReportingDataUtils.addKeyword(regulatory, Constants.CREDIT_CONFIRMATION_TYPE, confirmationMethod);

		}
		catch (Exception e)
		{
			errorString = "Error while poplulating ConfirmationType keyword : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("confType:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving enrichConfirmationType() method");

		return message;

	}

}
