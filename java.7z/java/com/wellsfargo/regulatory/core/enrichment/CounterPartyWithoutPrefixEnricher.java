package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class CounterPartyWithoutPrefixEnricher 
{
	private static Logger logger = Logger.getLogger(CounterPartyWithoutPrefixEnricher.class.getName());
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichSendBy() method");
		
		RegulatoryType regulatory 	= null;
		ReportingContext context 	= null;
		String errorString 			= null;
		String cpPartyLei  			= null;
		String partyLeiWithoutColon = null;
		String tempstring[] 		= null;

		if(null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			regulatory 	= context.getSdrRequest().getTrade().getRegulatory();
			
			if (null != context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEIValue())
			{
				partyLeiWithoutColon = context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEIValue();
			}
			else if ( null != context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEI() )
			{
				cpPartyLei 				= context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEI();
				partyLeiWithoutColon 	= cpPartyLei;
					
				if  ( cpPartyLei!=null && cpPartyLei.contains(":") ) 
				{
					tempstring = cpPartyLei.split(":");					
				
					if ( null != tempstring && tempstring.length > 1)
					{
						partyLeiWithoutColon = tempstring[1];
					} 
				}
			}	
			
			if ( null != partyLeiWithoutColon)
				ReportingDataUtils.addKeyword(regulatory, Constants.COUNTERPARTY_WITHOUT_PREFIX, partyLeiWithoutColon);
		}
		catch (Exception e)
		{
			errorString = "Error while poplulating partyLeiWithoutColon keyword" + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("partyLeiWithoutColon:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving PartyLeiWithoutColonEnricher() method");

		return message;
	}
 
}
