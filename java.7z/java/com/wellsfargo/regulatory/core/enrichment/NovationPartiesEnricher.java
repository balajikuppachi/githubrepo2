package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.NovationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class NovationPartiesEnricher
{
	private static Logger logger = Logger.getLogger(NovationPartiesEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichNovationParties() method");
		
		RegulatoryType regulatory 	= null;
		ReportingContext context 	= null;
		String errorString 			= null;
		String eventType 			= null;
		String ourLei 				= null;
		String cpLei 				= null;
		String transferorLEI 		= null;
		String transfereeLEI 		= null;
		String remPartyLEI 			= null;
		NovationType novation 		= null;
		String transfereeParty 		= null;
		String transferorParty 		= null;
		String remParty 			= null;

		if (null == message) return message;

		try
		{
			context 	= (ReportingContext) message.getPayload();
			regulatory 	= context.getSdrRequest().getTrade().getRegulatory();
			eventType 	= context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();
			ourLei 		= (context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEIValue() != null ) ?
								context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEIValue() :context.getSdrRequest().getTrade().getTradeHeader().getProcessingOrgLEI();
			cpLei 		= (context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEIValue() != null) ? 
								context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEIValue() : context.getSdrRequest().getTrade().getTradeHeader().getCounterpartyLEI();
			novation 	= context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getNovation();

			if (eventType != null && !eventType.contains("Novation")) 
				return message;
			
			if (novation == null)
			{
				return message;
			}

			if (cpLei == null || ourLei == null)
			{
				return message;
			}
			
			transferorLEI	= (novation.getTransferorLEIValue() != null) ? novation.getTransferorLEIValue() : novation.getTransferorLEI();
			transfereeLEI 	= (novation.getTransfereeLEIValue() != null) ? novation.getTransfereeLEIValue() : novation.getTransfereeLEI();
			remPartyLEI 	= (novation.getRemainingPartyLEIValue() != null ) ? novation.getRemainingPartyLEIValue() : novation.getRemainingPartyLEI();

			if (eventType != null && eventType.contains("Novation - OR"))
			{
				if (ourLei.equals(transferorLEI) || cpLei.equals(remPartyLEI))
				{
					transferorParty = Constants.PARTY1;
					remParty 		= Constants.PARTY2;
				}
				else if (cpLei.equals(transferorLEI) || ourLei.equals(remPartyLEI))
				{
					transferorParty = Constants.PARTY2;
					remParty 		= Constants.PARTY1;
				}
			}
			else if (null != eventType && eventType.contains("Novation - RP"))
			{
				if (ourLei.equals(remPartyLEI) || cpLei.equals(transferorLEI))
				{
					transferorParty = Constants.PARTY2;
					remParty 		= Constants.PARTY1;
				}
				else if (cpLei.equals(remPartyLEI) || ourLei.equals(transferorLEI))
				{
					transferorParty = Constants.PARTY1;
					remParty 		= Constants.PARTY2;
				}
			}
			else if (null != eventType && eventType.contains("Novation - EE"))
			{
				if (ourLei.equals(transfereeLEI) || cpLei.equals(remPartyLEI))
				{
					transfereeParty = Constants.PARTY1;
					remParty 		= Constants.PARTY2;
				}
				else if (cpLei.equals(transfereeLEI) || ourLei.equals(remPartyLEI))
				{
					transfereeParty = Constants.PARTY2;
					remParty 		= Constants.PARTY1;
				}
			}

			if (!GeneralUtils.IsNullOrBlank(transferorParty))
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.TRANSFEROR_PARTY, transferorParty);
			}

			if (!GeneralUtils.IsNullOrBlank(transfereeParty))
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.TRANSFEREE_PARTY, transfereeParty);
			}

			if (!GeneralUtils.IsNullOrBlank(remParty))
			{
				ReportingDataUtils.addKeyword(regulatory, Constants.REMAINING_PARTY, remParty);
			}

		}
		catch (Exception e)
		{
			errorString = "Error while poplulating NovationParties keywords" + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("novationParties:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		logger.debug("Leaving enrichNovationParties() method");
		
		return message;
	}
}
