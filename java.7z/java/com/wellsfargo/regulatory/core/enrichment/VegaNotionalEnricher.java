package com.wellsfargo.regulatory.core.enrichment;

import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepEquityTermsDao;
import com.wellsfargo.regulatory.persister.dto.RegRepEquityTerms;

/**
 * @author Raji Komatreddy
 * 
 * For Equity products, vegaNotional comes in EquityTerms
 * if This Trade (checked by USI) already exists - get VegaNotional amount for that trade
 * if incoming event type is Increment add existing and incoming vegaNotional
 * If it is Termination subtract incoming vegaNotional from existing one
 */

@Component
public class VegaNotionalEnricher
{

	private static Logger logger = Logger.getLogger(ActionTypeEnricher.class.getName());

	        @Autowired
	private RegRepEquityTermsDao regRepEquityTermsDao;

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering VegaNotionalEnricher() method");

		double vegaNotional = 0;
		double changeInVegaNotional = 0;
		double netVegaNotional = 0;
		String eventType = null;
		String usi = null;
		TradeHeaderType trdHeader = null;
		ReportingContext context = null;
		LifeCycleType lifecycle = null;
		SdrRequest request = null;
		ProductType product = null;
		DomainMappingCache cache = null;
		String dtccTxnType = null;
		String key = null;
		RegulatoryType 	regulatory 			= null;
		String assetClass = null;

		if (null == message) 
			return message;

		try
		{
			context = (ReportingContext) message.getPayload();
			request = context.getSdrRequest();
			trdHeader = context.getSdrRequest().getTrade().getTradeHeader();
			product = request.getTrade().getTradeDetail().getProduct();
			lifecycle = trdHeader.getLifeCycle();
			eventType = lifecycle.getEventType();
			usi =        ReportingDataUtils.computeUSI(context);
			regulatory 	= request.getTrade().getRegulatory();
			assetClass = context.getAssetClass();
			
			//continue only for Equity assetclass
			if(!StringUtils.equalsIgnoreCase(assetClass, Constants.ASSET_CLASS_EQUITY))
			{
				return message;
			}

			
			if (StringUtils.isNotBlank(eventType))

			{
				key = Constants.ASSET_CLASS_EQUITY + Constants.UNDERSCORE + eventType;
				cache = DomainMappingCache.getInstance();
				dtccTxnType = cache.getValue(key);
				
				if (null != product.getEquityTerms() && null != product.getEquityTerms().getVegaNotional()) 
					  vegaNotional = (product.getEquityTerms().getVegaNotional()).doubleValue();
				else 
					return message;
			}

			if (Constants.Increase.equalsIgnoreCase(dtccTxnType) && null != product.getEquityTerms())
			{
				netVegaNotional = getTotalVegaNotional(vegaNotional, usi, "add");				
				changeInVegaNotional = vegaNotional;
			}
				  
			else if (Constants.Termination.equalsIgnoreCase(dtccTxnType))
			{
				netVegaNotional = getTotalVegaNotional(vegaNotional, usi, "diff");
				 changeInVegaNotional = vegaNotional;				
			}
			else
			{
				//Assuming for all other types we are getting total notional
				changeInVegaNotional = getTotalVegaNotional(vegaNotional, usi, "diff");
			}
				
			
			if(netVegaNotional > 0)			
				ReportingDataUtils.addKeyword(regulatory, Constants.VEGA_NOTIONAL, ConversionUtils.formatDecimalDEC(netVegaNotional));
			
			if(changeInVegaNotional > 0)			
				ReportingDataUtils.addKeyword(regulatory, Constants.CHANGE_IN_VEGA_NOTIONAL, ConversionUtils.formatDecimalDEC(changeInVegaNotional));
		
			
		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while calculating vegaNotional : ", e);
		}
		logger.debug("leaving VegaNotionalEnricher() method");
	
		return message;

	}

	private double getTotalVegaNotional(double current, String usi, String operation)
	{	
		Double total = 0.0;
		Double original = 0.0;
		
		try
		{
			List<RegRepEquityTerms> regRepEquityTermsList = regRepEquityTermsDao.loadRegRepEuqityTermsByUsi(usi);
			
			original=Optional.ofNullable(IntStream.range(0, regRepEquityTermsList.size())
					 .filter(n->n==1)
					 .mapToObj(regRepEquityTermsList::get)
					 .findAny()
					 .get()
					 .getVegaNotional()).orElse(0.0);
			
			if(StringUtils.equalsIgnoreCase(operation, "add"))
				
			    total =  Double.sum(original , current );
			else
				total =  original - current ;

		}
		catch (Exception ee)
		{
			logger.info("Total Notional Failed, Returning the value as is.", ee);
		}
		return Math.abs(total);

	}

	

}
