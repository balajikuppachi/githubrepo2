package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.JURISDICTION_CANADA_SHORT;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DocumentationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * @author u337814
 *
 */

@Component
public class MasterAgreementEnricher 
{
	private static Logger logger = Logger.getLogger(NovationPartiesEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		ReportingContext	context 		= null;
		Set<String>			regulatories	= null;
		TradeDetailType		trdDetail		= null;
		DocumentationType	documentation	= null;
		String				masterAggType	= null;
		String				masterAggVer	= null;
		boolean				cadReportable	= false;
		
		logger.debug("Entering MasterAgreementEnricher() method");
		
		if(null == message) return message;

		try
		{
			if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
			{
				logger.error("############################# Incoming payload is not of Reporting type. Returning.######################");
				return message;
			}

			context 		= (ReportingContext) message.getPayload();
			regulatories 	= context.getRegulatories().keySet();
			
			if(null == regulatories || regulatories.size() < 1)
			{
				logger.error("############################# Failed to get regulatories from the context. Returning.################");
				return message;
			}
						
			for(String reg : regulatories)
			{
				if(null != reg && reg.contains(JURISDICTION_CANADA_SHORT))
				{
					cadReportable = true;
					break;
				}
			}
			
			if(!cadReportable)
			{
				logger.debug("Message not Reportable under CAD. Returning from Master Doc Enricher");
				return message;
			}
		
			/**
			 * STR-444: No Default values for CAD master agreement fields.
			 */
		
			/*	try
			{
				trdDetail 		= context.getSdrRequest().getTrade().getTradeDetail();
				documentation	= trdDetail.getDocumentation();
			}
			catch(Exception e)
			{
				logger.error("############################# Failed to get tradeDetail/Documentation from the context. Returning.################");
				return message;
			}
			
			masterAggType = documentation.getMasterAgreementType();
			masterAggVer  = documentation.getMasterAgreementVersion();
			
			if(null == masterAggVer)
			{
				masterAggVer = STRING_TO_REMOVE;
				documentation.setMasterAgreementVersion(masterAggVer);
			}
						
			if(null == masterAggType)
			{
				masterAggType = ISDA;
				documentation.setMasterAgreementType(masterAggType);
			}			
			*/
		}
		catch(Exception e)
		{
			logger.error("######## Exception occured while calculating Master Agreement Type action type : ", e);
		}
		
		logger.debug("Leaving MasterAgreementEnricher() method");
		
		return message;
	}

}
