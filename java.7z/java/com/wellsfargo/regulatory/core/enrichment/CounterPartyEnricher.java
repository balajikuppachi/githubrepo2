package com.wellsfargo.regulatory.core.enrichment;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class CounterPartyEnricher 
{
	private static Logger logger = Logger.getLogger(CounterPartyEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		RegulatoryType 		regulatory 	= null;
		ReportingContext 	context 	= null;
		String 				errorString = null;		
		String				cpLei		= null;
		SdrRequest			request		= null;
		String				uCpLei		= null;
		String 				sdrMsgId 	= null;
		
		
		logger.debug("Entering CounterPartyEnricher() method");

		if (null == message) return message;

		try
		{
			context = (ReportingContext) message.getPayload();
			request	= context.getSdrRequest();
			
			cpLei 	= request.getTrade().getTradeHeader().getCounterpartyLEI();	
			uCpLei 	= cpLei;
			
			for(TradePartyType party : request.getTrade().getTradeDetail().getTradeParties().getParty())
			{
				if(null == party || null == party.getLEI()) continue;
				
				if(party.getLEI().equals(cpLei))
				{
					uCpLei = party.getUltimateCptyBusAccountId();
					
					if(!GeneralUtils.IsNullOrBlank(uCpLei))
					{						
						// Name and Id are already mapped in excel, so only changing props here, 
						// so that same mapping may be used
						request.getTrade().getTradeHeader().setCounterpartyLEI(uCpLei);	
						party.setPartyName(party.getUltimateCptyName());						
					}
					
					break;
				}
			}			
			
			ReportingDataUtils.addKeyword(regulatory, Constants.FINAL_COUNTERPARTY, uCpLei);
		}
		catch (Exception e)
		{
			errorString = "Error while poplulating counterparty keywords" + e.getMessage();
			logger.error("########## " + errorString);	
			
			throw new MessagingException("134", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while populating counterparty keyword", sdrMsgId, e, context.getSwapTradeId());
		}

		logger.debug("Leaving CounterPartyEnricher() method");
		
		return message;
	}


}
