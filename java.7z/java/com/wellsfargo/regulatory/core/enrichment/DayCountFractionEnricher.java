package com.wellsfargo.regulatory.core.enrichment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class DayCountFractionEnricher {
	private static Logger logger = Logger.getLogger(DayCountFractionEnricher.class.getName());

	private static Map<String, String> dayCountCache;
	private static final String DAY_COUNT_DOMAIN = "DCF";
	
	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering DayCountFractionEnricher() method");
		List<LegType> 		legList 				= null;
		ReportingContext 	context 				= null;
		SdrRequest 			request 				= null;
		ProductType 		productKeywords			= null;
		LegType				legType1				= null;
		LegType				legType2				= null;
		String 				dayCount1				= null;
		String 				dayCount2				= null;
		String 				productType			 	= null;
		List<ProductType> 	productTypeList 		= null;
		ProductType			productType1			= null;
				
		if(null == message) return message;
		
		context 					= 	(ReportingContext) message.getPayload();
		legList 					= 	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getLeg();
		request 					= 	context.getSdrRequest();
		productKeywords				= 	request.getTrade().getTradeDetail().getProduct();
		
		productType					=	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductType();
		
		if(Constants.PRODUCT_TYPE_SWAPTION.equalsIgnoreCase(productType))
		{
			productTypeList			= 	context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProduct();
			
			if(null != productTypeList  && !productTypeList.isEmpty()){
				productType1 = productTypeList.get(0);
				
				if(null != productType1){
					legList = productType1.getLeg();
				}
			}
		}
		
		if(null != legList && !legList.isEmpty()){
			
			legType1 = legList.get(0);
			
			if(null != legType1){
				dayCount1 = legType1.getDayCountFraction();
				
				dayCount1 = getDtccDayCount(dayCount1);
			}
			
			if(legList.size() > 1){
				
				legType2 = legList.get(1);
				
				if(null != legType2){
					dayCount2 = legType2.getDayCountFraction();
					
					dayCount2 = getDtccDayCount(dayCount2);
				}
				
			}
		}
		
		
		ReportingDataUtils.addKeyword(productKeywords, Constants.DAY_COUNT+"1", dayCount1);
		ReportingDataUtils.addKeyword(productKeywords, Constants.DAY_COUNT+"2", dayCount2);
		
		logger.debug("Leaving DayCountFractionEnricher() method");

		return message;

	}
	
	private String getDtccDayCount(String dayCount) 
	{
		String dtccDayCount;

		if(null == dayCountCache)
			loadDayCountCache();

		String val = dayCountCache.get(dayCount);

		dtccDayCount = val == null ? dayCount : val;

		return dtccDayCount;
	}
	
	private void loadDayCountCache()
	{
		String key;
		String srcDayCount;
		String dtccDayCount;

		DomainMappingCache domainCache = DomainMappingCache.getInstance();

		dayCountCache 		= new HashMap<String, String>(12);

		Set<String> keys 	= domainCache.getKeys();

		if(null != keys)
		{
			Iterator<String> itr = keys.iterator();

			while(itr.hasNext())
			{
				key = itr.next();

				if(null == key) continue;

				if(key.contains(DAY_COUNT_DOMAIN))
				{
					srcDayCount = key.split(Constants.UNDERSCORE)[1];
					dtccDayCount= domainCache.getValue(key);

					dayCountCache.put(srcDayCount, dtccDayCount);
				}
			}
		}
	}


}
