package com.wellsfargo.regulatory.core.enrichment;

import static com.wellsfargo.regulatory.commons.keywords.Constants.COLON;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC_PRD_ID;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.cache.ProductMappingCache;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class ProductIdEnricher
{
	private static Logger logger = Logger.getLogger(ProductIdEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichProductId() method");

		SdrRequest request 				= null;
		ReportingContext context 		= null;
		ProductMappingCache prdCache 	= null;
		StringBuilder prdId 			= null;
		String srcAssetClass 			= null;
		String key 						= null;
		String originalKey 				= null;
		ProductType prdType 			= null;
		String srcPrdType 				= null;
		String srcSubPrdType 			= null;
		String mappingType 				= null;
		List<String> values 			= null;
		String dtccAssetClass 			= null;
		String dtccPrdType 				= null;
		String dtccSubPrdType 			= null;
		String leg1Type 				= null;
		String leg2Type 				= null;
		String fpmlProductType 			= null;
		String ALL 						= "ALL";
		boolean found 					= false;
		String repository 				= null;
		String errorString 				= null;
		String equityUnderlyerType 		= null;

		if(null == message)
			return message;

		try
		{
			context 		= (ReportingContext) message.getPayload();
			request 		= context.getSdrRequest();
			prdCache 		= ProductMappingCache.getInstance();
			srcAssetClass 	= request.getAssetClass();
			srcSubPrdType 	= request.getTrade().getTradeDetail().getProduct().getProductSubType();
			repository 		= context.getRegulatories().keySet().iterator().next().split(UNDERSCORE)[1];

			if (Constants.ASSET_CLASS_EQUITY.equals(srcAssetClass))
			{
				srcPrdType 	= request.getTrade().getTradeDetail().getProduct().getProductKeys().getUPI();
				mappingType = Constants.ISDA;

				/*** Equity - PRODUCT_MAPPING doesn't require subProdType to derive the product Id, hence force to empty string ****/
				srcSubPrdType	= "";

				if (srcPrdType.lastIndexOf(":") != -1)
				{
					equityUnderlyerType = srcPrdType.substring(srcPrdType.lastIndexOf(":") + 1, srcPrdType.length());
					prdType 			= request.getTrade().getTradeDetail().getProduct();
					
					ReportingDataUtils.addKeyword(prdType, Constants.EQUITY_SWAP_UNDERLYER_TYPE, equityUnderlyerType.toString());
				}
			}
			else
			{
				srcPrdType 	= request.getTrade().getTradeDetail().getProduct().getProductType();
				mappingType = repository;
			}

			/*
			 * type of mapping
			 */
			originalKey = getProductIdKey(srcAssetClass, srcPrdType, srcSubPrdType, mappingType);

			while (!found)
			{
				key 	= getProductIdKey(srcAssetClass, srcPrdType, srcSubPrdType, mappingType);
				values 	= prdCache.getValues(key);

				if (null != values)
				{
					found = true;
					break;
				}

				if (!ALL.equals(srcSubPrdType))
				{
					srcSubPrdType = ALL;
					continue;
				}
				else if (!ALL.equals(srcPrdType))
				{
					srcPrdType = ALL;
					continue;
				}
				else if (!ALL.equals(srcAssetClass))
				{
					srcAssetClass = ALL;
				}
				else
				{
					break;
				}
			}

			if (!found)
			{
				errorString = "No ProductMappingCache entry for " + originalKey;
				logger.error("########## " + errorString);

				throw new MessagingException("prdId:0", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), context.getSwapTradeId());
			}

			prdId 			= new StringBuilder();
			dtccAssetClass 	= values.get(0);
			dtccPrdType 	= values.get(1).trim();
			dtccSubPrdType 	= values.get(2).trim();
			fpmlProductType = values.get(4).trim();

			String upi 		= null;
			if (null != request.getTrade().getTradeDetail().getProduct().getProductKeys().getUPI())
					upi = request.getTrade().getTradeDetail().getProduct().getProductKeys().getUPI();
			
			if ( upi != null && upi.startsWith(Constants.ISDA+Constants.COLON))
					upi = upi.substring(5, upi.length());
			
			prdId.append(upi);

			
			if ( GeneralUtils.IsNullOrBlank(prdId.toString()) ) 
			{
				prdId.append(dtccAssetClass);
				prdId.append(COLON);
				prdId.append(dtccPrdType);

				if (! GeneralUtils.IsNullOrBlank(dtccSubPrdType))
				{
					prdId.append(COLON);
					prdId.append(dtccSubPrdType);
				}
				else if ("XccySwap".equalsIgnoreCase(srcPrdType))
				{
					leg1Type = request.getTrade().getTradeDetail().getProduct().getLeg().get(0).getFixedFloat().value();
					leg2Type = request.getTrade().getTradeDetail().getProduct().getLeg().get(1).getFixedFloat().value();

					if (leg1Type.equals(leg2Type) && "Float".equals(leg1Type))
					{
						dtccSubPrdType = "Basis";
					}
					else
					{
						dtccSubPrdType = leg1Type + leg2Type;
					}

					prdId.append(COLON);
					prdId.append(dtccSubPrdType);
				}
			}

			if (null == request.getTrade().getTradeDetail().getProduct().getKeywords())
			{
				request.getTrade().getTradeDetail().getProduct().setKeywords(new KeywordsType());
			}

			prdType = request.getTrade().getTradeDetail().getProduct();

			ReportingDataUtils.addKeyword(prdType, DTCC_PRD_ID, prdId.toString());

		}
		catch (Exception e)
		{
			errorString = "Error while poplulating Product Id keyword: " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("prdId:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), e, context.getSwapTradeId());
		}

		context.setFpmlProductType(fpmlProductType);
		logger.debug("Leaving addProductId() method");

		return message;
	}

	private String getProductIdKey(String assetClass, String prdType, String subPrdType, String mapingType)
	{
		logger.debug("Entering getProductIdKey() method");

		StringBuilder key = null;

		key = new StringBuilder();

		key.append(assetClass);
		key.append(Constants.UNDERSCORE);
		key.append(prdType);
		key.append(Constants.UNDERSCORE);
		if (null != subPrdType) key.append(subPrdType);
		key.append(Constants.UNDERSCORE);
		key.append(mapingType);

		logger.debug("Leaving getProductIdKey() method");

		return key.toString();
	}

}
