package com.wellsfargo.regulatory.core.enrichment;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class EodLifecycleEventEnricher {


	private static Logger logger = Logger.getLogger(EodLifecycleEventEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		logger.debug("Entering EodLifecycleEventEnricher() method");

		TradeHeaderType 	trdHeader 					= null;
		ReportingContext 	context 					= null;
		String 				actionType 					= null;
		String				eventType					= null;
		String 				assetClass					= null;
		String				dtcc_lce					= null;
		String 				lce_domain_key = null;
		DomainMappingCache  cache 						= null;
		SdrRequest 			request 					= null;
		RegulatoryType 		regulatory 					= null;
		LifeCycleType		lifecycle					= null;
		String				eventSubType				= null;
		KeywordsType keywordsType                       = null;
		String sdrAction                                = null;
		
		if(null == message) return message;

		try
		{
			context 	= 	(ReportingContext) message.getPayload();
			trdHeader 	= 	context.getSdrRequest().getTrade().getTradeHeader();
			actionType 	= 	trdHeader.getAction();
			lifecycle	= 	trdHeader.getLifeCycle();
			eventType 	=   lifecycle.getEventType();
			assetClass	=	context.getAssetClass();
			request 	= 	context.getSdrRequest();
			regulatory 	= 	request.getTrade().getRegulatory();
			eventSubType =   lifecycle.getEventSubType();
			
			cache = DomainMappingCache.getInstance();
			
			//unlock USI scenario  - to send exit message
			keywordsType = context.getSdrRequest().getTrade().getRegulatory().getKeywords();
			sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);
			
			if(StringUtils.equalsIgnoreCase(sdrAction, Constants.SDR_ACTION_EXIT))
			{
				lce_domain_key=StringUtils.join(new String[]{Constants.DTCC_LCE,Constants.SDR_ACTION_EXIT},  Constants.UNDERSCORE);
			}
			else if(GeneralUtils.IsNullOrBlank(eventSubType))
				lce_domain_key=StringUtils.join(new String[]{Constants.DTCC_LCE,assetClass,actionType,eventType},  Constants.UNDERSCORE);
			else
				lce_domain_key=StringUtils.join(new String[]{Constants.DTCC_LCE,assetClass,actionType,eventType,eventSubType},  Constants.UNDERSCORE);
			//lce_domain_key=Constants.DTCC_LCE + Constants.UNDERSCORE + assetClass + Constants.UNDERSCORE + actionType + Constants.UNDERSCORE + eventType;
			dtcc_lce = cache.getValue(lce_domain_key);
			ReportingDataUtils.addKeyword(regulatory, Constants.LIFE_CYCLE_EVENT, dtcc_lce);

		}
		catch (Exception e)
		{
			logger.error("######## Exception occured while populating DTCC lifecycle event : ", e);
		}


		logger.debug("Leaving EodLifecycleEventEnricher() method");

		return message;

	}
}
