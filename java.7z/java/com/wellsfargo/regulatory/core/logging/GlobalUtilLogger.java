package com.wellsfargo.regulatory.core.logging;

import java.sql.Timestamp;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import  org.springframework.messaging.support.ChannelInterceptor;

import com.wellsfargo.regulatory.commons.beans.MessageStatusLog;
import com.wellsfargo.regulatory.commons.exceptions.ReportingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;
import com.wellsfargo.regulatory.persister.dto.logging.MessageStatusLogDao;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class GlobalUtilLogger implements ChannelInterceptor 
{
	private static Logger logger = Logger.getLogger(GlobalUtilLogger.class.getName());
	
	@Autowired
	private MessageStatusLogDao messageLogDao;

	//protected JmsTemplate jmsTopicTemplate;


	public void setMessageLogDao(MessageStatusLogDao messageLogDao) {
		this.messageLogDao = messageLogDao;
	}

//	public void setJmsTopicTemplate(JmsTemplate jmsTopicTemplate) {
//		this.jmsTopicTemplate = jmsTopicTemplate;
//	}

	private MessageStatusLog getLogMessageObject(Message<?> message, MessageChannel channel) 
	{
		logger.debug("Entering getLogMessageObject() method");

		String sdrMessageId = null;
		Throwable exception = null;

		MessageStatusLog messageLogObject = new MessageStatusLog();

		if ("inputXMLChannel".equalsIgnoreCase(channel.toString())) 
		{
			sdrMessageId = "IP-Channel-No-ID";
		}
		else if ("resInputXMLChannel".equalsIgnoreCase(channel.toString()) || "resInputFileChannel".equalsIgnoreCase(channel.toString())) 
		{
			sdrMessageId = "Res-IP-Channel-No-ID";
		} 
		else if ("errorChannel".equalsIgnoreCase(channel.toString())) 
		{
			exception = (Throwable) message.getPayload();

			while (null != exception && !(exception instanceof ReportingException)) 
			{
				exception = exception.getCause();
			}

			if ((exception instanceof ReportingException)) 
			{
				sdrMessageId = ((ReportingException) exception).getSdrMessageId();
			} 
			else 
			{
				// TODO : returning null for now.
				// FIXME : fix it later

				return null;
			}

			sdrMessageId = ((ReportingException) exception).getSdrMessageId();

		} 
		else if ("inputFileChannel".equalsIgnoreCase(channel.toString())) 
		{
			sdrMessageId = "File-IP-Channel-No-ID";
		} 
		else if ("customBackloadNoResponseLoggerChannel".equalsIgnoreCase(channel.toString())) 
		{
			logger.info("No response required to the FO [CustomBackloaded trade]");
		} 
		else 
		{
			try
			{
				sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			}
			catch(Exception e)
			{
				logger.error("*********************************************** Error Here "+e.getMessage());
			}
		}

		messageLogObject.setSdrMessageId(sdrMessageId);
		messageLogObject.setChannelName(channel.toString());
		messageLogObject.setReferenceQuery(identifyQuery(channel.toString()));
		messageLogObject.setTimeStamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));

		logger.debug("Leaving getLogMessageObject() method");

		return messageLogObject;
	}

	private void logMessageObject(MessageStatusLog messageLogObject) {
		// messageLogDao.insertMessageStatus(messageLogObject);
	}

	public Message<?> postReceive(Message<?> message, MessageChannel channel) {
		return message;
	}

	public void postSend(Message<?> message, MessageChannel channel,
			boolean success) {
	}

	public boolean preReceive(MessageChannel channel) {
		return true;
	}

	public Message<?> preSend(Message<?> message, MessageChannel channel) 
	{
		// START : Setting the MDC from the Context
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.GlobalUtilLogger);
		// END : Setting the MDC from the Context

		logger.debug("Entering preSend() method for channel : " + channel);

		MessageStatusLog messageLogObject = getLogMessageObject(message, channel);

		if (null == messageLogObject) 
		{
			logger.debug("Failed to publish object to Global Util logger, since log object created was null");
			return message;
		}

		// logMessageObject(messageLogObject);

		try 
		{
			//publishMessageLogObject(messageLogObject);
		} 
		catch (Exception e) 
		{
			logger.error("Unable to publish event to the UI " + e.getMessage());
		}

		logger.debug("Leaving preSend() method for channel : " + channel);

		return message;
	}

	private String identifyQuery(String channelName) 
	{
		String refQuery = null;

		if (StringUtils.isBlank(channelName)) {
			return refQuery;
		}

		if ("inputXMLChannel".equalsIgnoreCase(channelName)) 
		{
			refQuery = QueryMaster.RAW_MESSAGE;
		} 
		else 
		{
			refQuery = QueryMaster.PARSED_MESSAGE;
		}

		return refQuery;
	}

	@Override
	public void afterSendCompletion(Message<?> message, MessageChannel channel,
			boolean sent, Exception ex) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterReceiveCompletion(Message<?> message,
			MessageChannel channel, Exception ex) {
		// TODO Auto-generated method stub
		
	}

//	public void publishMessageLogObject(final MessageStatusLog data) throws Exception 
//	{
//		logger.debug("Entering publishMessageLogObject() method");
//
//		jmsTopicTemplate.send(new MessageCreator() 
//		{
//			public javax.jms.Message createMessage(Session session) throws JMSException 
//			{
//				ObjectMessage message = session.createObjectMessage(data);
//
//				return message;
//			}
//		});
//
//		logger.debug("Leaving publishMessageLogObject() method");
//	}

}
