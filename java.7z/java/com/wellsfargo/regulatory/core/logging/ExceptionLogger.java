package com.wellsfargo.regulatory.core.logging;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.integration.annotation.ServiceActivator;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse.Reason;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.RegRepMessageTypeEum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.exceptions.ReportingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepExceptionDao;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepTradeDao;
import com.wellsfargo.regulatory.persister.dto.RegRepException;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;
import com.wellsfargo.regulatory.persister.etd.dao.EtdExceptionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdException;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdExceptionMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepExceptionMapper;
import com.wellsfargo.regulatory.persister.helper.mapper.RegRepMessageMapper;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */
public class ExceptionLogger
{

	@Autowired
	private RegRepMessageDao regRepMessageDao;
	@Autowired
	private RegRepExceptionDao regRepExceptionDao;
	@Autowired
	private RegRepTradeDao regRepTradeDao;
	@Autowired
	private RegRepExceptionMapper exceptionMapper;
	@Autowired
	private RegRepMessageMapper messageMapper;
	@Autowired
	private EtdExceptionMapper etdExceptionMapper;
	@Autowired
	private EtdExceptionDao etdExceptionDao;

	private File logFile 						= null;
	private static boolean fileLoggingenabled 	= false;
	private static boolean dbLoggingenabled 	= false;
	private static final String fileName 		= "Reg_Rep_Exceptions.log";

	private static Logger logger = Logger.getLogger(ExceptionLogger.class.getName());

	public void setRegRepMessageDao(RegRepMessageDao regRepMessageDao)
	{
		this.regRepMessageDao = regRepMessageDao;
	}

	public void setRegRepExceptionDao(RegRepExceptionDao regRepExceptionDao)
	{
		this.regRepExceptionDao = regRepExceptionDao;
	}

	public void setExceptionMapper(RegRepExceptionMapper exceptionMapper)
	{
		this.exceptionMapper = exceptionMapper;
	}

	public void setMessageMapper(RegRepMessageMapper messageMapper)
	{
		this.messageMapper = messageMapper;
	}

	public ExceptionLogger(String logFilePath, String fileLogenabled, String dbLogenabled)
	{

		logFile = getFile(logFilePath);

		if (ConversionUtils.stringToBoolean(fileLogenabled) && null != logFile) ExceptionLogger.fileLoggingenabled = true;

		if (ConversionUtils.stringToBoolean(dbLogenabled)) ExceptionLogger.dbLoggingenabled = true;
	}

	@ServiceActivator
	public void logExceptions(Message<MessageHandlingException> message) throws MessagingException
	{

		String sdrMessageId = null;
		Reason reason = null;

		reason = prepareLogObject(message);

		// Problem location value getting using to transport messageId
		sdrMessageId = reason.ProblemLocationValue;

		// In case the message has not been generated yet in the flow
		// if(null == sdrMessageId)
		// sdrMessageId = ReportingDataUtils.generateMessageId();

		// Log it to the file
		if (fileLoggingenabled) logToFile(reason, sdrMessageId);

		// Log it to the DB
		if (dbLoggingenabled) logToDB(reason, sdrMessageId);
	}

	// Checks weather the log file is a valid one
	private File getFile(String filePath)
	{
		File logFile = null;

		if (StringUtils.isBlank(filePath)) return logFile;

		File directory = new File(filePath);
		if (!directory.exists())
		{
			directory.mkdirs();
		}

		if (directory.exists() && directory.isDirectory())
		{
			logFile = new File(filePath + File.separatorChar + ExceptionLogger.fileName);
		}

		return logFile;
	}

	private boolean logToDB(Reason reason, String sdrMessageId)
	{
		boolean success 					= false;
		RegRepException exception 			= null;
		RegRepMessage dbMessage 			= null;
		Set<RegRepException> exceptionSet 	= null;
		EtdException etdException 			= null;
		RegRepTrade trade 					= null;

		if (ExceptionTypeEnum.ETD_ERROR.compareTo(reason.type) == 0)
		{
			try
			{
				etdException = etdExceptionMapper.populateEtdException(reason);
				etdExceptionDao.save(etdException);
				success = true;
			}
			catch (Exception e)
			{
				logger.error("Failed to persist etd exception to DB ", e);
			}

		}
		else if (ExceptionTypeEnum.COLLATERAL_RES_ERROR.compareTo(reason.type) == 0)
		{
			try
			{
				// TODO : Need to confirm				
				if(reason.ProblemLocationValue == null){
					reason.ProblemLocationValue = ReportingDataUtils.generateMessageId();
				}
				etdException = etdExceptionMapper.populateEtdException(reason);
				etdExceptionDao.save(etdException);
				success = true;
			}
			catch (Exception e)
			{
				logger.error("Failed to persist collateral response exception to DB ", e);
			}

		}
		else
		{	
			/*** TradeId is stored in context only after sdrRequest is persisted after parsing ***/
			if(null == reason.tradeId)
			{
				dbMessage = regRepMessageDao.findByPrimaryKeyNS(sdrMessageId);
				
				if(null != dbMessage)
				{
					if(null != dbMessage.getSwapTradeId())
					{
						trade = regRepTradeDao.findByPrimaryKeyNS(dbMessage.getSwapTradeId());
						dbMessage.setRegRepTrade(trade);
					}
					else
						dbMessage.setRegRepTrade(null);
				}
			}
			else
			{
				dbMessage = regRepMessageDao.findMsgAndTradeByPrimaryKeyNS(sdrMessageId);
			}
				
			if (null == dbMessage)
			{
				dbMessage = messageMapper.createDefaultRegRepMessage(sdrMessageId, RegRepMessageTypeEum.SDR_EXCEPTION);
			}

			try
			{
//				if(null == dbMessage.getRegRepTrade() 
//						|| null == dbMessage.getRegRepTrade().getSwapTradeId())
//					dbMessage.setRegRepTrade(null);
				
				exception 		= exceptionMapper.createRegRepException(dbMessage, reason);
				exceptionSet 	= new HashSet<RegRepException>(1);
				
				if(null != exception) 
					exceptionSet.add(exception);
				
				if(null != dbMessage && null != exceptionSet)
					dbMessage.setRegRepExceptions(exceptionSet);
				
				if(null != exception)
				{
					regRepExceptionDao.saveOrUpdate(exception);
					success = true;
				}
			}
			catch (Exception e)
			{
				logger.error("Failed to persist exception to DB ", e);
			}
		}

		return success;
	}

	private Reason prepareLogObject(Message<MessageHandlingException> message)
	{
		String exceptionCode 					= null;
		ExceptionSeverityEnum exceptionSeverity = null;
		ExceptionTypeEnum exceptionType 		= null;
		String sdrMessageId 					= null;
		ReportingException exception 			= null;
		String tradeId 							= null;
		Reason reason 							= new Reason();
		Throwable exceptionParent 				= message.getPayload();
		String exceptionString 					= exceptionParent.getMessage();
		
		String stackTrace 						= org.apache.commons.lang.exception.ExceptionUtils.getFullStackTrace(exceptionParent);

		while ((null != exceptionParent) && !(exceptionParent instanceof ReportingException))
		{
			exceptionParent = exceptionParent.getCause();
		}

		if ((null != exceptionParent) && (exceptionParent instanceof ReportingException))
		{
			reason 				= new Reason();
			exception 			= (ReportingException) exceptionParent;
			exceptionCode 		= exception.getExceptionCode();
			exceptionSeverity 	= exception.getExceptionSeverity();
			exceptionType 		= exception.getExceptionType();
			sdrMessageId 		= exception.getSdrMessageId();
			tradeId		 		= exception.getSwapTradeId();

			reason.description 	= exceptionString;
			reason.reasonCode 	= exceptionCode;
			reason.type 		= exceptionType;
			reason.severity 	= exceptionSeverity;
			reason.tradeId 		= tradeId;

			/*** - Using this value to store messageId deliberately ***/
			reason.ProblemLocationValue = sdrMessageId;

			if (null == reason.type) reason.type 			= ExceptionTypeEnum.REG_REP_ERROR;
			if (null == reason.severity) reason.severity 	= ExceptionSeverityEnum.ERROR;
		}
		/*
		 * In case exception is not thrown appropriately
		 */
		else
		{
			logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Error stack trace " + stackTrace);

			reason.description 	= exceptionString;
			reason.reasonCode 	= "UNCGHT:1";
			reason.type 		= ExceptionTypeEnum.REG_REP_ERROR;
			reason.severity 	= ExceptionSeverityEnum.ERROR;
			reason.ProblemLocationValue = ReportingDataUtils.generateMessageId() + ":UNCGHT";
		}

		return reason;
	}

	private void logToFile(Reason exceptionObject, String sdrMessageId) throws MessagingException
	{
		try
		{
			FileWriter writer = new FileWriter(logFile, true);
			writer.write(sdrMessageId + " " + Constants.COLON);
			writer.write(exceptionObject.toString());
			writer.close();
		}
		catch (IOException e)
		{
			//throw new MessagingException("345", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, "Error while logging exception to the file", sdrMessageId, e, exceptionObject.tradeId);
			logger.error("logToFile: Error while logging exception to the file"+ sdrMessageId );
		}

	}

	public void setEtdExceptionMapper(EtdExceptionMapper etdExceptionMapper)
	{
		this.etdExceptionMapper = etdExceptionMapper;
	}

	public void setEtdExceptionDao(EtdExceptionDao etdExceptionDao)
	{
		this.etdExceptionDao = etdExceptionDao;
	}
	
	public void setRegRepTradeDao(RegRepTradeDao regRepTradeDao)
	{
		this.regRepTradeDao = regRepTradeDao;
	}
	
}
