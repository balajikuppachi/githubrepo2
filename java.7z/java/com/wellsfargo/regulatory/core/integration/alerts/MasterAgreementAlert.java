package com.wellsfargo.regulatory.core.integration.alerts;

import static com.wellsfargo.regulatory.commons.keywords.Constants.JURISDICTION_CANADA_SHORT;

import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DocumentationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;

@Component
public class MasterAgreementAlert  extends FilterRulesContextMgr{
	private static Logger logger = Logger.getLogger(MasterAgreementAlert.class.getName());

	public Message<?> alert(Message<?> message) throws MessagingException
	{
		ReportingContext	context 		= null;
		Set<String>			regulatories	= null;
		TradeDetailType		trdDetail		= null;
		DocumentationType	documentation	= null;
		String				masterAggType	= null;
		String				masterAggVer	= null;
		boolean				cadReportable	= false;
		String 				description		= null;
		
		logger.debug("Entering MasterAgreementAlert() method");
		
		if(null == message) return message;

		try
		{
			if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
			{
				logger.error("############################# Incoming payload is not of Reporting type. Returning.######################");
				return message;
			}

			context 		= (ReportingContext) message.getPayload();
			regulatories 	= context.getRegulatories().keySet();
			
			if(null == regulatories || regulatories.size() < 1)
			{
				logger.error("############################# Failed to get regulatories from the context. Returning.################");
				return message;
			}
						
			for(String reg : regulatories)
			{
				if(null != reg && reg.contains(JURISDICTION_CANADA_SHORT))
				{
					cadReportable = true;
					break;
				}
			}
			
			if(!cadReportable)
			{
				logger.debug("Message not Reportable under CAD. Returning from Master Doc Enricher");
				return message;
			}
		
			/**
			 * STR-444: No Default values for CAD master agreement fields. add alerts in case of missing master agreement fields.
			 */
		
			try
			{
				trdDetail 		= context.getSdrRequest().getTrade().getTradeDetail();
				documentation	= trdDetail.getDocumentation();
			}
			catch(Exception e)
			{
				logger.error("############################# Failed to get tradeDetail/Documentation from the context. Returning.################");
				return message;
			}
			
			if (documentation!= null){
				masterAggType = documentation.getMasterAgreementType();
				masterAggVer  = documentation.getMasterAgreementVersion();
			}
			if(null == masterAggVer)
			{
				description = "Missing master agreement version for the tradeId:" + context.getSwapTradeId(); 
				addAlertValidationResult(context, "CAD_MSTR_AGRMNT_VSN", "CAD_MSTR_AGRMNT_VRSN_FILTER", description, "VALIDATION");
			}
			if(null == masterAggType)
			{
				description = "Missing master agreement type for the tradeId:" + context.getSwapTradeId(); 
				addAlertValidationResult(context, "CAD_MSTR_AGRMNT_TYPE", "CAD_MSTR_AGRMNT_TYPE_FILTER", description, "VALIDATION");
			}
			
		}
		catch(Exception e)
		{
			logger.error("######## Exception occured in Master Agreement Alert function : ", e);
		}
		
		logger.debug("Leaving MasterAgreementAlert() method");
		
		return message;
	}

}
