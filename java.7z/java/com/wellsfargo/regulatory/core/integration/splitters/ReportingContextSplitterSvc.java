package com.wellsfargo.regulatory.core.integration.splitters;

import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartiesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.bo.sdrResponse.ResponseCodeEnum;
import com.wellsfargo.regulatory.commons.cache.dao.impl.RegRegTradeValidationDaoImpl;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.core.data.cache.RegRepTradeValidationCache;
import com.wellsfargo.regulatory.core.services.enrichers.RegRepContextManager;
import com.wellsfargo.regulatory.persister.dto.RegRepParty;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepCounterPartyDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodReportDaoImpl;

/**
 * @author Raji Komatreddy 
 * I. Check if the trade is SDR_ACTION="USI Change" if yes then split the
 * context else add original to list 1. Exit Message Context for Cancel USI 2. New Message Context
 * for New USI II. Handle GTR create scenario. III. Check if USI is available in system or not. IV.
 * If usi changes update this new usi value in REG_REP_TRADE_VALIDATION V. If USI is not changed, if
 * get a USI Cancel, then NACK & don't report the trade. If existing CptyLEI is different from
 * incoming CptyLEi, then check LEI prefix if existing LEI prefix is LEI - then send exit message an
 * existing CptyLEI and new message with incoming LEI
 */

@Component
public class ReportingContextSplitterSvc extends RegRepContextManager
{

	@Autowired
	RegRepTradeValidationCache regRepTradeValidationCache;

	@Autowired
	RegRegTradeValidationDaoImpl regRegTradeValidationDaoImpl;

	@Autowired
	RegRepCounterPartyDaoImpl regRepCounterPartyDaoImpl;

	@Autowired
	RegRepEodReportDaoImpl regRepEodReportDaoImpl;

	private static Logger logger = Logger.getLogger(ReportingContextSplitterSvc.class.getName());

	public List<Message<?>> splitContext(Message<?> message) throws MessagingException
	{
		String errorString = null;
		Object ipMessage = null;
		ReportingContext reportingContext = null;
		KeywordsType keywordsType = null;
		TradeType trade = null;
		List<Message<?>> messageList = new ArrayList<Message<?>>();
		String sdrAction = null;
		Message<ReportingContext> exitMessage = null;
		ReportingContext exitReportingContext = null;
		Message<ReportingContext> newMessage = null;
		ReportingContext newReportingContext = null;
		RegulatoryType exitRegulatoryType = null;
		RegulatoryType newRegulatoryType = null;
		String oldUsi = null;
		String newUsi = null;
		String existingUsi = null;
		String tradeId = null;
		SdrRequest request = null;
		String oldUti = null;
		String newUti = null;
		String existingUti = null;
		String cptyLei = null;
		String cpLeiPrefix = null;
		String cpLeiWithPrefix = null;
		String existingCptyLei = null;
		String existingCptyPrefix = null;
		String existingCptyLeiWithPrefix = null;
		boolean cptyMissMatch = false;
		RegRepParty cptyRegRepParty = null;
		List<RegRepParty> cptyRegRepPartyList = null;		
		boolean isSefOrSwapWireTrade = false;
		List<String> tradeList = null;
		List<String> todayStradeList = null;

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);
		}
		ipMessage = message.getPayload();

		if (ipMessage instanceof ReportingContext)
		{
			/** Read the reporting context */
			reportingContext = (ReportingContext) ipMessage;
			request = reportingContext.getSdrRequest();

			try
			{

				trade = reportingContext.getSdrRequest().getTrade();
				if (null == trade)
				{
					logger.info("########## " + "could be confirm message payload");
					messageList.add(message);
					return messageList;
				}

				tradeId = trade.getTradeHeader().getTradeId();
				RegRepTradeValidation currRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);

				if (null != currRegRepTradeValidation)
				{
					existingUsi = currRegRepTradeValidation.getUsi();
					existingUti = currRegRepTradeValidation.getUti();

					existingCptyLeiWithPrefix = currRegRepTradeValidation.getCounterpartyLei();
					existingCptyPrefix = StringUtils.substringBefore(existingCptyLeiWithPrefix, ":");
					existingCptyLei = StringUtils.substringAfter(existingCptyLeiWithPrefix, ":");
				}

				keywordsType = reportingContext.getSdrRequest().getTrade().getTradeHeader().getKeywords();
				sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION);

				isSefOrSwapWireTrade = ReportingDataUtils.isSefOrSwapWireTrade(reportingContext);

				if (null != sdrAction && sdrAction.equalsIgnoreCase(Constants.USI_CHANGE))
				{

					oldUsi = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.USI_CANCEL);

					if (null == oldUsi) 
						oldUti = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.UTI_CANCEL);

					if (null != oldUsi && null != existingUsi && StringUtils.equalsIgnoreCase(oldUsi.trim(), existingUsi.trim()))
					{
						newUsi = request.getTrade().getTradeDetail().getProduct().getProductKeys().getUSI();

						// update REG_REP_TRADE_VALIDATION table and cache with new USI for the
						// trade

						if (null != newUsi)
						{
							currRegRepTradeValidation.setUsi(newUsi.trim());

							regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);
						}

						// if marketwire/swapwire trade generate only New snapshot message with New
						// USI if USI_Change comes on same day
						// if USI_Change comes on nextday of New Deal generate Exit (old USI) and
						// New snapshot messages (New USI)
						if (isSefOrSwapWireTrade)
						{
							tradeList = regRepEodReportDaoImpl.getPreviousActiveSnapshots(tradeId);
							if (null != tradeList && tradeList.size() > 0)
							{
								exitReportingContext = prepareExitMessage(reportingContext);
								exitReportingContext.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().setUSI(oldUsi);
								exitMessage = MessageBuilder.withPayload(exitReportingContext).build();

								/*** Getting a new context exclusively for this flow. ***/
								newReportingContext = prepareNewMessage(reportingContext);
								newMessage = MessageBuilder.withPayload(newReportingContext).build();

								messageList.add(exitMessage);
								messageList.add(newMessage);

							}
							else
							{
								messageList.add(message);

							}

						}
						else
						{
							exitReportingContext = prepareExitMessage(reportingContext);
							exitReportingContext.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().setUSI(oldUsi);
							exitMessage = MessageBuilder.withPayload(exitReportingContext).build();

							/*** Getting a new context exclusively for this flow. ***/
							newReportingContext = prepareNewMessage(reportingContext);
							newMessage = MessageBuilder.withPayload(newReportingContext).build();

							messageList.add(exitMessage);
							messageList.add(newMessage);

						}

					}
					// this is where we submit for ESMA - we don not generate RT and PET hence Exit
					// message is not required on day1
					else if (null == existingUsi && null != oldUti && null != existingUti && StringUtils.equalsIgnoreCase(oldUti.trim(), existingUti.trim()))
					{
						newUti = request.getTrade().getTradeDetail().getProduct().getProductKeys().getUTI();

						// Update REG_REP_TRADE_VALIDATION table and cache with new UTI for the
						// trade
						if (null != newUti)
						{
							currRegRepTradeValidation.setUti(newUti.trim());

							regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);
						}

						tradeList = regRepEodReportDaoImpl.getPreviousActiveSnapshots(tradeId);
						todayStradeList = regRepEodReportDaoImpl.getTodaysSnapshots(tradeId);
						// day2 scenario - active snapshot exists on this trade, need to exit
						// previous snapshot and submit new snapshot with new UTI
						if ((null != tradeList && tradeList.size() > 0) || (null != todayStradeList && todayStradeList.size() > 0))
						{
							exitReportingContext = prepareExitMessage(reportingContext);
							exitReportingContext.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().setUTI(oldUti);
							exitMessage = MessageBuilder.withPayload(exitReportingContext).build();

							newReportingContext = prepareNewMessage(reportingContext);
							newMessage = MessageBuilder.withPayload(newReportingContext).build();

							messageList.add(exitMessage);
							messageList.add(newMessage);

						}
						else
						{
							messageList.add(message);
						}

					}
					else
					{

						// Old USI came with trade does not match with previous USI existing on this
						// trade
						messageList.add(message);

						/*** send alert message to FO ***/
						addAlertValidationResult(reportingContext, "REP_CTXT_SPLITTER_FILTER", "FILTER_RPCTXT_01", "USI Change scenario: existing USI/UTI for this trade " + existingUsi + existingUti
						        + "  Usi Change came for : " + oldUsi + oldUti + " for tradeId: " + tradeId, "VALIDATION");
					}

				}
				else if (null != sdrAction && sdrAction.equalsIgnoreCase(Constants.LEI_CHANGE))
				{
					/***
					 * Form one message for exiting trade with old LEI and old counter party details
					 * one for new message with new counterParty details
					 ***/
					cpLeiWithPrefix = request.getTrade().getTradeHeader().getCounterpartyLEI();

					if (null == cpLeiWithPrefix)
					{
						cptyLei = request.getTrade().getTradeHeader().getCounterpartyLEIValue();
						cpLeiPrefix = request.getTrade().getTradeHeader().getCounterpartyLEIPrefix();

						if (null != cptyLei && null != cpLeiPrefix) cpLeiWithPrefix = cptyLei.trim() + ":" + cpLeiPrefix.trim();
					}
					else
					{
						cpLeiPrefix = StringUtils.substringBefore(cpLeiWithPrefix, ":");
						cptyLei = StringUtils.substringAfter(cpLeiWithPrefix, ":");
					}

					/*** Cpty changed -- updated TradeValidation table and Cache accordingly ***/
					if (null != cpLeiWithPrefix && null != existingCptyLeiWithPrefix && !StringUtils.equalsIgnoreCase(cpLeiWithPrefix, existingCptyLeiWithPrefix))
					{
						currRegRepTradeValidation.setCounterpartyLei(cpLeiWithPrefix);
						regRepTradeValidationCache.updateTradeValCacheForCPtyLeiChange(currRegRepTradeValidation);

						/***
						 * send exit message only if the existing Cpty is having LEI or CICI as
						 * prefix
						 ***/
						if (StringUtils.equalsIgnoreCase(existingCptyPrefix, Constants.PREFIX_LEI) || StringUtils.equalsIgnoreCase(existingCptyPrefix, Constants.PREFIX_CICI)) cptyMissMatch = true;

						if (cptyMissMatch)
						{
							cptyRegRepPartyList = regRepCounterPartyDaoImpl.getCptyInfo(tradeId, existingCptyLeiWithPrefix);

							if (null != cptyRegRepPartyList && cptyRegRepPartyList.size() > 0) cptyRegRepParty = cptyRegRepPartyList.get(0);

							if (null != cptyRegRepParty)
							{
								// if marketwire/swapwire trade generate only New snapshot message
								// with New USI if USI_Change comes on same day
								// if USI_Change comes on nextday of New Deal generate Exit (old
								// USI) and New snapshot messages (New USI)
								if (isSefOrSwapWireTrade)
								{
									tradeList = regRepEodReportDaoImpl.getPreviousActiveSnapshots(tradeId);
									if (null != tradeList && tradeList.size() > 0)
									{
										exitReportingContext = prepareExitMessageForCPChange(reportingContext, existingCptyLeiWithPrefix, cpLeiWithPrefix, cptyRegRepParty);
										exitMessage = MessageBuilder.withPayload(exitReportingContext).build();

										/*** Getting a new context exclusively for this flow. ***/
										newReportingContext = prepareNewMessage(reportingContext);
										newMessage = MessageBuilder.withPayload(newReportingContext).build();

										messageList.add(exitMessage);
										messageList.add(newMessage);

									}
									else
									{
										messageList.add(message);

									}

								}
								else
								{
									/*** Getting a new context exclusively for this flow. ***/
									exitReportingContext = prepareExitMessageForCPChange(reportingContext, existingCptyLeiWithPrefix, cpLeiWithPrefix, cptyRegRepParty);

									exitMessage = MessageBuilder.withPayload(exitReportingContext).build();

									newReportingContext = prepareNewMessage(reportingContext);

									newMessage = MessageBuilder.withPayload(newReportingContext).build();
									messageList.add(exitMessage);
									messageList.add(newMessage);

								}

							}
							else
							{
								errorString = "counter information does not exist in regrep message table";
								logger.error("########## " + errorString);
								messageList.add(message);
							}

						}
						else
						{
							logger.info("########## " + "counter Lei changed but no need to submit exit message as The prefix of existing cptyLei is not LEI ");
							messageList.add(message);
						}
					}

					else
					{

						// Old USI came with trade does not match with previous USI existing on this
						// trade
						messageList.add(message);

						/*** send alert message to FO ***/
						addAlertValidationResult(reportingContext, "REP_CTXT_SPLITTER_FILTER", "FILTER_RPCTXT_01", "Cp LEI Change scenario: existing CP LEI for this trade "
						        + existingCptyLeiWithPrefix + " and new CP LEI sent by FO: " + cpLeiWithPrefix + " for tradeId: " + tradeId, "VALIDATION");
					}

				}
				else
				{
					messageList.add(message);

				}

			}
			catch (Exception exp)
			{
				errorString = "Error inside ReportingContextSplitterSvc : " + exp.getMessage();
				logger.error("########## " + errorString);

				throw new MessagingException("RpCxtSplitterSvc_01", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, reportingContext.getMessageId(), exp,
				        reportingContext.getSwapTradeId());

			}
		}

		return messageList;
	}

	/**
	 * prepare exit message
	 * 
	 * @param reportingContext
	 * @param oldUsi
	 * @return
	 */
	private ReportingContext prepareExitMessage(ReportingContext reportingContext)
	{
		ReportingContext exitReportingContext;
		RegulatoryType exitRegulatoryType;
		/*** Getting a new context exclusively for this flow. ***/
		exitReportingContext = getNewContext(reportingContext, reportingContext.getMessageId(), NULL, true);
		exitReportingContext.getSdrRequest().getTrade().getTradeHeader().setAction(Constants.New);

		exitRegulatoryType = exitReportingContext.getSdrRequest().getTrade().getRegulatory();
		ReportingDataUtils.addKeyword(exitRegulatoryType, Constants.SDR_ACTION_DERIVED_EVENT, Constants.SDR_ACTION_EXIT);
		return exitReportingContext;
	}

	private ReportingContext prepareNewMessage(ReportingContext reportingContext)
	{
		ReportingContext newReportingContext;
		RegulatoryType newRegulatoryType;
		/*** Getting a new context exclusively for this flow. ***/
		newReportingContext = getNewContext(reportingContext, reportingContext.getMessageId(), NULL, true);
		newRegulatoryType = newReportingContext.getSdrRequest().getTrade().getRegulatory();
		ReportingDataUtils.addKeyword(newRegulatoryType, Constants.SDR_ACTION_DERIVED_EVENT, Constants.SDR_ACTION_NEW);

		return newReportingContext;
	}

	private ReportingContext prepareExitMessageForCPChange(ReportingContext reportingContext, String existingCptyLeiWithPrefix, String cpLeiWithPrefix, RegRepParty cptyRegRepParty)
	{
		ReportingContext exitReportingContext;
		RegulatoryType exitRegulatoryType;
		List<TradePartyType> tradePartyTypeList = null;
		String existingCptyLei = null;
		String cptyLei = null;

		existingCptyLei = StringUtils.substringAfter(existingCptyLeiWithPrefix, ":");
		cptyLei = StringUtils.substringAfter(cpLeiWithPrefix, ":");

		/*** Getting a new context exclusively for this flow. ***/
		exitReportingContext = getNewContext(reportingContext, reportingContext.getMessageId(), NULL, true);

		exitRegulatoryType = exitReportingContext.getSdrRequest().getTrade().getRegulatory();
		ReportingDataUtils.addKeyword(exitRegulatoryType, Constants.SDR_ACTION_DERIVED_EVENT, Constants.SDR_ACTION_EXIT);

		/***
		 * Enrich exitReportingContext with exit event Type and action as Cancel and updated with
		 * Old counter party details
		 */
		// TODO populate old counter party in context
		exitReportingContext.getSdrRequest().getTrade().getTradeHeader().setAction(Constants.New);
		exitReportingContext.getSdrRequest().getTrade().getTradeHeader().setCounterpartyLEI(existingCptyLeiWithPrefix);
		exitReportingContext.getSdrRequest().getTrade().getTradeHeader().setCounterpartyLEIValue(existingCptyLei);

		tradePartyTypeList = exitReportingContext.getSdrRequest().getTrade().getTradeDetail().getTradeParties().getParty();
		TradePartyType updateCounterParty = new TradePartyType();

		for (TradePartyType tradePartyType : tradePartyTypeList)
		{
			if (StringUtils.equalsIgnoreCase(tradePartyType.getLEIValue(), cptyLei) || StringUtils.equalsIgnoreCase(tradePartyType.getLEI(), cpLeiWithPrefix))
			{
				/***
				 * Remove new counterparty details to send exit message with old counter party
				 * details
				 ***/
				tradePartyTypeList.remove(tradePartyType);

				updateCounterParty.setAddress1(cptyRegRepParty.getAddress1());
				updateCounterParty.setAddress2(cptyRegRepParty.getAddress2());
				updateCounterParty.setPartyName(cptyRegRepParty.getPartyName());
				updateCounterParty.setCity(cptyRegRepParty.getCity());
				updateCounterParty.setState(cptyRegRepParty.getState());
				updateCounterParty.setZip(cptyRegRepParty.getZip());
				updateCounterParty.setCountry(cptyRegRepParty.getCountry());
				updateCounterParty.setLEI(cptyRegRepParty.getLei());
				updateCounterParty.setLEIPrefix(cptyRegRepParty.getLeiPrefix());
				updateCounterParty.setLEIValue(cptyRegRepParty.getLeiValue());
				updateCounterParty.setEmirTaxonomy(cptyRegRepParty.getEmirTaxanomy());
				// tradePartyType.setDesignation(cptyRegRepParty.getDesignation());
				updateCounterParty.setUsPerson(ConversionUtils.stringToBoolean(cptyRegRepParty.getUsPerson()));

			}

		}

		/*** add old counter party details to ***/
		tradePartyTypeList.add(updateCounterParty);

		TradePartiesType currTradePartiesType = new TradePartiesType();
		for (TradePartyType tradePartyType : tradePartyTypeList)
		{
			currTradePartiesType.getParty().add(tradePartyType);
		}

		exitReportingContext.getSdrRequest().getTrade().getTradeDetail().setTradeParties(currTradePartiesType);
		/*** add keyword in tradeheader to inform this is an exit message ***/

		exitRegulatoryType = exitReportingContext.getSdrRequest().getTrade().getRegulatory();
		ReportingDataUtils.addKeyword(exitRegulatoryType, Constants.SDR_ACTION_DERIVED_EVENT, Constants.SDR_ACTION_EXIT);
		return exitReportingContext;
	}

	private void addAlertValidationResult(ReportingContext inReportingContext, String fieldName, String errorCode, String errorDesc, String validationType)
	{
		logger.debug("Inside ReportingContextSplitterSvc: addAlertValidationResult method");

		RulesResultsContext rulesResultsContext = inReportingContext.getRulesResultsContext();

		if (null == rulesResultsContext)
		{
			rulesResultsContext = new RulesResultsContext();
			rulesResultsContext.setResultsSource("SDR_REQ");
		}

		ValidationResult validationResult = new ValidationResult();

		validationResult.setFieldName(fieldName);

		if (null != validationType)
		{
			if ("VALIDATION".equals(validationType))
			{
				validationResult.setCode(ResponseCodeEnum.VALIDATION_ERROR.value());
			}
		}

		validationResult.setErrorDesc(errorDesc);
		validationResult.setValidationType(validationType);

		rulesResultsContext.addAlertValidationResult(validationResult);

		inReportingContext.setRulesResultsContext(rulesResultsContext);

	}

}
