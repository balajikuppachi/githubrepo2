package com.wellsfargo.regulatory.core.integration.listeners;

import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.log4j.Logger;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class IpMessageReceiver implements MessageListener
{

	private static Logger logger = Logger.getLogger(IpMessageReceiver.class.getName());

	public void onMessage(Message msg)
	{
		// TextMessage message = (TextMessage)msg;

		try
		{
			// System.out.println(message.getText());
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}

}
