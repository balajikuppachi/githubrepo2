package com.wellsfargo.regulatory.core.integration.validators;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.core.data.cache.RegRepLcEventHierarchyCache;
import com.wellsfargo.regulatory.core.data.cache.RegRepTradeValidationCache;
import com.wellsfargo.regulatory.commons.cache.dao.impl.RegRegTradeValidationDaoImpl;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepValidationException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepValidationExceptionDaoImpl;

/**
 * @author Raji Komatreddy
 */
@Component
public class LifecycleEventValidator extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(LifecycleEventValidator.class.getName());

	@Autowired
	RegRepTradeValidationCache regRepTradeValidationCache;

	@Autowired
	RegRepLcEventHierarchyCache regRepLcEventHierarchyCache;

	@Autowired
	RegRepValidationExceptionDaoImpl regRepValidationExceptionDaoImpl;

	@Autowired
	RegRegTradeValidationDaoImpl regRegTradeValidationDaoImpl;

	public Message<?> validate(Message<?> message) throws MessagingException
	{

		logger.debug("Executing " + this.getClass().getName() + " Validator");

		String errorString = null;

		if (null == message) return message;

		ReportingContext context = (ReportingContext) message.getPayload();

		if (null != context && !context.isConfirmationAlert())
		{

			try
			{
				SdrRequest request = context.getSdrRequest();
				// AbstractDriver.setMDCInfo(context, AbstractDriver.UsiFilter);

				String eventName = null;
				String tradeId = null;
				String existingEventName = null;
				String sdrMessageId = null;
				List<String> parentEventsList = null;
				String description = null;
			//	boolean sdrLive = false;
				String action = null;

				if (null != request.getTrade().getTradeHeader().getLifeCycle()) 
					eventName = request.getTrade().getTradeHeader().getLifeCycle().getEventType();

				if (null != request.getTrade().getTradeHeader()) 
					action = request.getTrade().getTradeHeader().getAction();

				sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);

				tradeId = request.getTrade().getTradeHeader().getTradeId();

				//if (null != request.getTrade().getCustomBackload() && null != request.getTrade().getCustomBackload().isIsSdrLive())
				//	sdrLive = request.getTrade().getCustomBackload().isIsSdrLive();

				RegRepTradeValidation currRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);

				if (null != currRegRepTradeValidation) 
					existingEventName = currRegRepTradeValidation.getLifecycleEventType();

				if (null != eventName )
				{
					parentEventsList = regRepLcEventHierarchyCache.getParentEvents(eventName);

					if (null != parentEventsList && parentEventsList.size() == 0)
					{
						description = "Lifecycle event Validation failed for the TradeId: " + tradeId + " Lifecycle event type: " + eventName + " on the incoming trade " + " is not a valid event";

						logger.info(">>>>>>>>> " + description);

						RegRepValidationException currException = new RegRepValidationException();
						currException.setMessageId(sdrMessageId);
						currException.setTradeid(tradeId);
						currException.setExceptionCode("ADDITIONAL_VALIDATOR_01");
						currException.setExceptionType(ExceptionTypeEnum.INPUT_DATA_ERROR.toString());
						currException.setDescription(description);

						regRepValidationExceptionDaoImpl.insert(currException);

						// addFilterValidationResult(context, "Lifecycle Event Validator", "ADDITIONAL_VALIDATOR_01", description, "FILTER");
						
						addAlertValidationResult(context, "Lifecycle Event Validator", "ADDITIONAL_VALIDATOR_01", description, "FILTER");
						// context.setInvalid(true);

						logger.info(">>>>>>>>> Invalidated due to Lifecycle Event Validator: " + description);

					}

					// if we receive same LifeCycle event which we got before (other than Undo
					// events),
					// check the action on incoming trade,
					// if action type is New change it to Modify and update the context
				/*	else if (null != parentEventsList && (parentEventsList.contains(existingEventName) && !eventName.startsWith("Undo")))
					{
						if (null != action && action.equalsIgnoreCase(Constants.New))
						{
							action = Constants.Modify;
							context.getSdrRequest().getTrade().getTradeHeader().setAction(action);
						}

					}*/

					// New Deal is different for different asset classes
					else if (null != parentEventsList && !(parentEventsList.contains(existingEventName) || (parentEventsList.contains(Constants.NULL_STRING) && existingEventName == null)))
					{

						description = "Lifecycle event Validation failed for the tradeId "
						        + tradeId
						        + ". Lifecycle event on the incoming trade is "
						        + eventName
						        + ". "
						        + (existingEventName != null ? "Lifecycle event on the last incoming trade event was " + existingEventName : "No previous event trade drop was found")
						        + "."
						        + (!parentEventsList.contains(Constants.NULL_STRING) ? eventName + " is allowed after following events --> " + parentEventsList : eventName
						                + "should be the first trade drop");

						logger.info(">>>>>>>>> " + description);

						RegRepValidationException currException = new RegRepValidationException();
						currException.setMessageId(sdrMessageId);
						currException.setTradeid(tradeId);
						currException.setExceptionCode("ADDITIONAL_VALIDATOR_01");
						currException.setExceptionType(ExceptionTypeEnum.INPUT_DATA_ERROR.toString());
						currException.setDescription(description);

						regRepValidationExceptionDaoImpl.insert(currException);

						// context.setInvalid(true);

						logger.info(">>>>>>>>> Invalidated due to Lifecycle Event Validator: " + description);

					}

				}

			}
			catch (Exception exp)
			{
				errorString = "Error while executing lifecycle Validation rule : " + exp.getMessage();
				logger.error("########## " + errorString);

				throw new MessagingException("ADDITIONAL_VALIDATOR_01", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp,
				        context.getSwapTradeId());

			}
		}

		logger.debug("Completed " + this.getClass().getName() + " validator");
		return message;

	}

}
