package com.wellsfargo.regulatory.core.integration.validators;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.core.data.cache.RegRepTradeValidationCache;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepValidationException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepValidationExceptionDaoImpl;

/**
 * @author Raji Komatreddy
 */
@Component
public class EntityLeiValidator extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(EntityLeiValidator.class.getName());

	@Autowired
	RegRepTradeValidationCache regRepTradeValidationCache;

	@Autowired
	RegRepValidationExceptionDaoImpl regRepValidationExceptionDaoImpl;

	public Message<?> validate(Message<?> message) throws MessagingException
	{

		logger.debug("Executing " + this.getClass().getName() + " Validator");

		String errorString = null;

		if (null == message) return message;

		ReportingContext context = (ReportingContext) message.getPayload();

		if (null != context && !context.isConfirmationAlert())
		{
			try
			{
				SdrRequest request = context.getSdrRequest();
				// AbstractDriver.setMDCInfo(context, AbstractDriver.EntityLeiValidation);

				String entityLei = null;
				String entityLeiPrefix = null;
				String entityLeiWithPrefix = null;
				String tradeId = null;
				String existingEntityLei = null;			
				String existingEntityLeiPrefix = null;
				String existingEntityLeiWithPrefix = null;
				String sdrMessageId = null;
				String description = null;
				boolean entityLeiMismatch = false;
		

				sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);

				tradeId = request.getTrade().getTradeHeader().getTradeId();
				
				entityLeiWithPrefix = request.getTrade().getTradeHeader().getProcessingOrgLEI();
				if (null == entityLeiWithPrefix)
				{
					entityLei = request.getTrade().getTradeHeader().getProcessingOrgLEIValue();
					entityLeiPrefix = request.getTrade().getTradeHeader().getProcessingOrgLEIPrefix();

					if (null != entityLei && null != entityLeiPrefix) 
						entityLeiWithPrefix = entityLei.trim() + ":" + entityLeiPrefix.trim();
				}
				else
				{					
					entityLeiPrefix = StringUtils.substringBefore(entityLeiWithPrefix, ":");
					entityLei = StringUtils.substringAfter(entityLeiWithPrefix, ":");
				}
				
				if (null != entityLei && entityLei.contains(":"))
				{
					entityLei = StringUtils.substringAfter(entityLei, ":");
				}

				RegRepTradeValidation currRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);

				if (null != currRegRepTradeValidation) 
				{
					existingEntityLeiWithPrefix = currRegRepTradeValidation.getEntityLei();
					existingEntityLeiPrefix = StringUtils.substringBefore(existingEntityLeiWithPrefix, ":");
					existingEntityLei = StringUtils.substringAfter(existingEntityLeiWithPrefix, ":");
					
				}
				

				// if both existing and incoming entityLei contains prefix with in it compare whole string
				if (null != existingEntityLeiWithPrefix && null != entityLeiWithPrefix)
				{
					//if prefix are same but lei values are different then raise exception
					if(null != existingEntityLeiPrefix && null != entityLeiPrefix && existingEntityLeiPrefix.equalsIgnoreCase(entityLeiPrefix) && 
							 !existingEntityLei.equalsIgnoreCase(entityLei) && !entityLeiPrefix.equalsIgnoreCase(Constants.INTERNAL_LEI_PREFIX))							
					 {
						entityLeiMismatch = true;
					 } //existing LEI contains INTERNAL - don't compare with new LEI value, if new LEI prefix changes to INTERNAL then raise exception
					 else if(null != existingEntityLeiPrefix && null != entityLeiPrefix && !existingEntityLeiPrefix.equalsIgnoreCase(entityLeiPrefix) )
					 {
						if(existingEntityLeiPrefix.equalsIgnoreCase(Constants.INTERNAL_LEI_PREFIX) )
						{
							entityLeiMismatch = false;
						}
						else if( entityLeiPrefix.equalsIgnoreCase(Constants.INTERNAL_LEI_PREFIX))
						{
							entityLeiMismatch = true;
						}
						else if(null != existingEntityLei && null != entityLei &&  !existingEntityLei.equalsIgnoreCase(entityLei))
						{
							entityLeiMismatch = true;
						}
					 }					
				}
					
	
					if (entityLeiMismatch)
					{
						description = "for the tradeId " + tradeId + ". Entity LEI: " + existingEntityLei + " with Prefix  " + existingEntityLeiPrefix + " changed to " +
								" Entity LEI: " + entityLei + " with Prefix " + entityLeiPrefix ;					
						

						logger.info(">>>>>>>>> Entity Lei Validation failed " + description);

						RegRepValidationException currException = new RegRepValidationException();
						currException.setMessageId(sdrMessageId);
						currException.setTradeid(tradeId);
						currException.setExceptionCode("ADDITIONAL_VALIDATOR_04");
						currException.setExceptionType(ExceptionTypeEnum.INPUT_DATA_ERROR.toString());
						currException.setDescription(description);

						regRepValidationExceptionDaoImpl.insert(currException);

						addAlertValidationResult(context, "ENTITYLEI_VALIDATE_FILTER", "FILTER_12", description , "VALIDATION");
						//context.setInvalid(true);
						
						//addFilterValidationResult(context, "ENTITYLEI_VALIDATE_FILTER", "FILTER_12", "Entity LEI is Changed Existing: "+existingEntityLeiWithPrefix +" Current: "+entityLeiWithPrefix , "VALIDATION");
						//context.setFiltered(true);
						logger.info(">>>>>>>>> Filtered due to Entity LEI Change: " + description);

					}
				

			}
			catch (Exception exp)
			{
				errorString = "Error while executing EntityLeiValidator rule : " + exp.getMessage();
				logger.error("########## " + errorString);

				throw new MessagingException("Validator02", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp, context.getSwapTradeId());

			}
		}

		logger.debug("Completed " + this.getClass().getName() + " Validator");
		return message;

	}

}
