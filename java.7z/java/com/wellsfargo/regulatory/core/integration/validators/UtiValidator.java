package com.wellsfargo.regulatory.core.integration.validators;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.core.data.cache.RegRepTradeValidationCache;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepValidationException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;
import com.wellsfargo.regulatory.core.integration.filters.UsiFilter;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepValidationExceptionDaoImpl;

/**
 * @author Raji Komatreddy
 */
@Component
public class UtiValidator extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(UsiFilter.class.getName());

	@Autowired
	RegRepTradeValidationCache regRepTradeValidationCache;

	@Autowired
	RegRepValidationExceptionDaoImpl regRepValidationExceptionDaoImpl;

	public Message<?> validate(Message<?> message) throws MessagingException
	{

		logger.debug("Executing " + this.getClass().getName() + " Validator");

		String errorString = null;

		if (null == message) return message;

		ReportingContext context = (ReportingContext) message.getPayload();

		if (null != context && !context.isConfirmationAlert())
		{
			try
			{
				SdrRequest request = context.getSdrRequest();
				// AbstractDriver.setMDCInfo(context, AbstractDriver.UtiValidator);

				String utiValue = null;
				ProductKeysType productKeysType = null;
				ProductType productType = null;
				String tradeId = null;
				String existingUti = null;
				String sdrMessageId = null;
				String description = null;
				KeywordsType keywordsType = null;
				String sdrAction = null;

				sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);

				productType = request.getTrade().getTradeDetail().getProduct();
				tradeId = request.getTrade().getTradeHeader().getTradeId();

				if (null != productType)
				{
					productKeysType = productType.getProductKeys();
					if (null != productKeysType) utiValue = productKeysType.getUTI();
				}

				RegRepTradeValidation currRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);
				
				keywordsType = context.getSdrRequest().getTrade().getTradeHeader().getKeywords();
				sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION);

				if (null != currRegRepTradeValidation) 
					existingUti = currRegRepTradeValidation.getUti();

				if (null != existingUti && !existingUti.equalsIgnoreCase(utiValue))
				{					
						description = "for the tradeId " + tradeId + " UTI on the incoming trade is: " + utiValue + " UTI on the last incoming trade event was " + existingUti;

						logger.info(">>>>>>>>> Filtered due to UTI change " + description);

						RegRepValidationException currException = new RegRepValidationException();
						currException.setMessageId(sdrMessageId);
						currException.setTradeid(tradeId);
						currException.setExceptionCode("ADDITIONAL_VALIDATOR_03");
						currException.setExceptionType(ExceptionTypeEnum.INPUT_DATA_ERROR.toString());
						currException.setDescription(description);

						regRepValidationExceptionDaoImpl.insert(currException);

						addAlertValidationResult(context, "UTI_VALIDATE_FILTER", "FILTER_10", description , "VALIDATION");
						
					 if ( StringUtils.isBlank(sdrAction) || (StringUtils.isNotBlank(sdrAction) && !sdrAction.equalsIgnoreCase(Constants.USI_CHANGE) ))
						{
							currRegRepTradeValidation.setUsi(utiValue.trim());
							regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);							
						}
						//context.setInvalid(true);
						
						//addFilterValidationResult(context, "UTI_VALIDATE_FILTER", "FILTER_10", "Uti is Changed Existing: "+existingUti +" Current: "+utiValue , "VALIDATION");
						//context.setFiltered(true);
						
						logger.info(">>>>>>>>> Filtered due to UTI change" + description);					
				}

			}
			catch (Exception exp)
			{
				errorString = "Error while executing UtiValidator rule : " + exp.getMessage();
				logger.error("########## " + errorString);

				throw new MessagingException("Validator04", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp, context.getSwapTradeId());

			}
		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;

	}

}
