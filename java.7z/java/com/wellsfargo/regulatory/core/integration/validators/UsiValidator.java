package com.wellsfargo.regulatory.core.integration.validators;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.cache.dao.impl.RegRegTradeValidationDaoImpl;
import com.wellsfargo.regulatory.core.data.cache.RegRepTradeValidationCache;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepValidationException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;
import com.wellsfargo.regulatory.core.integration.filters.UsiFilter;
import com.wellsfargo.regulatory.eod.data.cache.RegRepUniqueIdentifierMappingCache;
import com.wellsfargo.regulatory.persister.dao.RegRepUniqueIdentifierMappingDao;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepValidationExceptionDaoImpl;

/**
 * @author Raji Komatreddy
 */
@Component
public class UsiValidator extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(UsiFilter.class.getName());

	@Autowired
	RegRepTradeValidationCache regRepTradeValidationCache;

	@Autowired
	RegRepValidationExceptionDaoImpl regRepValidationExceptionDaoImpl;

	@Autowired
	RegRepUniqueIdentifierMappingCache regRepUniqueIdentifierMappingCache;

	@Autowired
	RegRegTradeValidationDaoImpl regRegTradeValidationDaoImpl;

	public Message<?> validate(Message<?> message) throws MessagingException
	{

		logger.debug("Executing " + this.getClass().getName() + " Validator");

		String errorString = null;

		if (null == message) return message;

		ReportingContext context = (ReportingContext) message.getPayload();

		if (null != context && !context.isConfirmationAlert())
		{
			try
			{
				SdrRequest request = context.getSdrRequest();
				// AbstractDriver.setMDCInfo(context, AbstractDriver.UsiFilter);

				String usiValue = null;
				String tradeId = null;
				String existingUsi = null;
				String sdrMessageId = null;
				String description = null;
				ProductType productType = null;
				ProductKeysType productKeysType = null;
				String gtrCreatedUsi = null;
				boolean misMatchFlag = false;
				String assetClass = null;
				String eventType  = null;
				KeywordsType keywordsType = null;
				String sdrAction = null;


				sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);

				productType = request.getTrade().getTradeDetail().getProduct();
				tradeId = request.getTrade().getTradeHeader().getTradeId();
				assetClass = context.getAssetClass();
				eventType = request.getTrade().getTradeHeader().getLifeCycle().getEventType();

				if (null != productType)
				{
					productKeysType = productType.getProductKeys();
					
					if (null != productKeysType) 
						usiValue = productKeysType.getUSI();
				}
				
				keywordsType = context.getSdrRequest().getTrade().getTradeHeader().getKeywords();
				sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION);

				RegRepTradeValidation currRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);

				if (null != currRegRepTradeValidation) 
					existingUsi = currRegRepTradeValidation.getUsi();				
			
				if (null != existingUsi && !existingUsi.equalsIgnoreCase(usiValue))
				{
					misMatchFlag = true;
					gtrCreatedUsi = regRepUniqueIdentifierMappingCache.getTradeUsiMapping(tradeId);
					// for affiliate trades usi will be created by DTCC
					if (StringUtils.isNotBlank(gtrCreatedUsi) && StringUtils.equalsIgnoreCase(usiValue, gtrCreatedUsi))
					{
						misMatchFlag = false;
						logger.info(">>>>>>>>> before the USI was GTRCREATE : now updating with usi received from DTCC  " + gtrCreatedUsi + "for tradeID " + tradeId);
						currRegRepTradeValidation.setUsi(gtrCreatedUsi);
						regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);
					}
					else if (StringUtils.isNotBlank(gtrCreatedUsi) && !StringUtils.equalsIgnoreCase(gtrCreatedUsi, existingUsi))
					{
						misMatchFlag = true;
						logger.info(">>>>>>>>> before the USI was GTRCREATE : now updating with usi received from DTCC  " + gtrCreatedUsi + "for tradeID " + tradeId);
						currRegRepTradeValidation.setUsi(gtrCreatedUsi);
						regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);

					}
					// Galaxy sends USI Change as life cycle event when ever there is an change in USI
					else if(StringUtils.equalsIgnoreCase(assetClass, Constants.ASSET_CLASS_EQUITY)
							&& StringUtils.equalsIgnoreCase(eventType, Constants.EVENT_TYPE_USI_CHANGE))
					{
						misMatchFlag = false;
						logger.info(">>>>>>>>> before the USI was: " + existingUsi + " : now updating with usi received from Galaxy system  " + usiValue + "for tradeID " + tradeId);
						currRegRepTradeValidation.setUsi(usiValue);
						regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);
						
					}
					else if ( StringUtils.isBlank(sdrAction) || (StringUtils.isNotBlank(sdrAction) && !sdrAction.equalsIgnoreCase(Constants.USI_CHANGE) ))
					{
						currRegRepTradeValidation.setUsi(usiValue.trim());
						regRepTradeValidationCache.updateTradeValCache(currRegRepTradeValidation);
						
					}

					if (misMatchFlag)
					{

						description = "for the tradeId " + tradeId + ". USI on the incoming trade is: " + usiValue + " USI on the last incoming trade event was " + existingUsi;

						logger.info(">>>>>>>>>  Filtered due to USI Change" + description);

						RegRepValidationException currException = new RegRepValidationException();
						currException.setMessageId(sdrMessageId);
						currException.setTradeid(tradeId);
						currException.setExceptionCode("ADDITIONAL_VALIDATOR_02");
						currException.setExceptionType(ExceptionTypeEnum.INPUT_DATA_ERROR.toString());
						currException.setDescription(description);

						regRepValidationExceptionDaoImpl.insert(currException);

						addAlertValidationResult(context, "USI_VALIDATE_FILTER", "FILTER_11", description, "VALIDATION");
						//context.setInvalid(true);

						logger.info(">>>>>>>>> Filtered due to USI Change" + description);

					}

				}

			}
			catch (Exception exp)
			{
				errorString = "Error while executing UsiValidation rule : " + exp.getMessage();
				logger.error("########## " + errorString);

				throw new MessagingException("ADDITIONAL_VALIDATOR_02", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp,
				        context.getSwapTradeId());

			}
		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;

	}

}
