package com.wellsfargo.regulatory.core.integration.validators;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.core.data.cache.RegRepTradeValidationCache;
import com.wellsfargo.regulatory.commons.cache.dao.impl.RegRegTradeValidationDaoImpl;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepValidationException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepValidationExceptionDaoImpl;

/**
 * @author Raji Komatreddy
 */
@Component
public class CptyLeiValidator extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(EntityLeiValidator.class.getName());

	@Autowired
	RegRepTradeValidationCache regRepTradeValidationCache;

	@Autowired
	RegRepValidationExceptionDaoImpl regRepValidationExceptionDaoImpl;

	@Autowired
	RegRegTradeValidationDaoImpl regRegTradeValidationDaoImpl;

	public Message<?> validate(Message<?> message) throws MessagingException
	{

		logger.debug("Executing " + this.getClass().getName() + " Validator");

		String errorString = null;

		if (null == message) return message;

		ReportingContext context = (ReportingContext) message.getPayload();

		if (null != context && !context.isConfirmationAlert())
		{
			try
			{
				SdrRequest request = context.getSdrRequest();
				// AbstractDriver.setMDCInfo(context, AbstractDriver.CptyLeiValidation);

				String cptyLei = null;
				String cpLeiPrefix = null;
				String cpLeiWithPrefix = null;
				String tradeId = null;
				String sdrMessageId = null;
				String description = null;
				String entityLei = null;
				String entityLeiPrefix = null;
				String entityLeiWithPrefix = null;
				String usiValue = null;
				String utiValue = null;
				ProductKeysType productKeysType = null;
				ProductType productType = null;
				String eventName = null;
				String existingCptyLei = null;
				String existingCptyPrefix = null;
				String existingCptyLeiWithPrefix = null;
				boolean cpLeiMismatch = false;
				KeywordsType keywordsType = null;
				String sdrAction = null;

				productType = request.getTrade().getTradeDetail().getProduct();

				if (null != productType)
				{
					productKeysType = productType.getProductKeys();
					if (null != productKeysType)
					{
						utiValue = productKeysType.getUTI();
						usiValue = request.getTrade().getTradeDetail().getProduct().getProductKeys().getUSI();
					}
				}

				entityLeiWithPrefix = request.getTrade().getTradeHeader().getProcessingOrgLEI();
				if (null == entityLeiWithPrefix)
				{
					entityLei = request.getTrade().getTradeHeader().getProcessingOrgLEIValue();
					entityLeiPrefix = request.getTrade().getTradeHeader().getProcessingOrgLEIPrefix();

					if (null != entityLei && null != entityLeiPrefix) 
						entityLeiWithPrefix = entityLei.trim() + ":" + entityLeiPrefix.trim();
				}

				cpLeiWithPrefix = request.getTrade().getTradeHeader().getCounterpartyLEI();
				if (null == cpLeiWithPrefix)
				{
					cptyLei = request.getTrade().getTradeHeader().getCounterpartyLEIValue();
					cpLeiPrefix = request.getTrade().getTradeHeader().getCounterpartyLEIPrefix();

					if (null != cptyLei && null != cpLeiPrefix) 
						cpLeiWithPrefix = cptyLei.trim() + ":" + cpLeiPrefix.trim();
				}
				else
				{					
					cpLeiPrefix = StringUtils.substringBefore(cpLeiWithPrefix, ":");
					cptyLei =StringUtils.substringAfter(cpLeiWithPrefix, ":");
				}

				sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);

				tradeId = request.getTrade().getTradeHeader().getTradeId();

				if (null != request.getTrade().getTradeHeader().getLifeCycle())
					eventName = request.getTrade().getTradeHeader().getLifeCycle().getEventType();

				if (null == cpLeiPrefix && null != request.getTrade().getTradeHeader().getCounterpartyLEIPrefix()) 
					cpLeiPrefix = request.getTrade().getTradeHeader().getCounterpartyLEIPrefix();

				RegRepTradeValidation currRegRepTradeValidation = regRepTradeValidationCache.getTradeValidationDtls(tradeId);

				if (null != currRegRepTradeValidation) 
				{
					existingCptyLeiWithPrefix = currRegRepTradeValidation.getCounterpartyLei();
					existingCptyPrefix = StringUtils.substringBefore(existingCptyLeiWithPrefix, ":");
					existingCptyLei= StringUtils.substringAfter(existingCptyLeiWithPrefix, ":");
				}
				
				keywordsType = context.getSdrRequest().getTrade().getTradeHeader().getKeywords();
				sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION);
					

				// if both existing and incoming cptyLei contains prefix with in it compare whole
				// string
				if (null != existingCptyLeiWithPrefix && null != cpLeiWithPrefix &&
					 ( StringUtils.isBlank(sdrAction)||	(StringUtils.isNotBlank(sdrAction) && !sdrAction.equalsIgnoreCase(Constants.LEI_CHANGE) )))
				{
					//if prefix are same but lei values are different then raise exception
					if(null != existingCptyPrefix && null != cpLeiPrefix && existingCptyPrefix.equalsIgnoreCase(cpLeiPrefix) && 
							 !existingCptyLei.equalsIgnoreCase(cptyLei) && !existingCptyPrefix.equalsIgnoreCase(Constants.INTERNAL_LEI_PREFIX) )							
					 {
						 cpLeiMismatch = true;
					 } //existing LEI contains INTERNAL - don't compare with new LEI value, if new LEI prefix changes to INTERNAL then raise exception
					 else if(null != existingCptyPrefix && null != cpLeiPrefix && !existingCptyPrefix.equalsIgnoreCase(cpLeiPrefix) )
					 {
						if(existingCptyPrefix.equalsIgnoreCase(Constants.INTERNAL_LEI_PREFIX) )
						{
							cpLeiMismatch = false;
						}
						else if( cpLeiPrefix.equalsIgnoreCase(Constants.INTERNAL_LEI_PREFIX))
						{
							cpLeiMismatch = true;
						}
						else if(null != existingCptyLei && null != cptyLei &&  !existingCptyLei.equalsIgnoreCase(cptyLei))
						{
							cpLeiMismatch = true;
						}
					 }	
					if(StringUtils.isNotBlank(existingCptyPrefix) && StringUtils.isNotBlank(cpLeiWithPrefix) && !existingCptyLei.equalsIgnoreCase(cptyLei))
					{
						currRegRepTradeValidation.setCounterpartyLei(cpLeiWithPrefix);
						regRepTradeValidationCache.updateTradeValCacheForCPtyLeiChange(currRegRepTradeValidation);
					}
				}

				if (cpLeiMismatch)
				{

					description = "for the TradeId " + tradeId + ". Counterparty LEI: " + existingCptyLei + " with Prefix " + existingCptyPrefix + " changed to " +
							" Counterparty LEI: " + cptyLei + " with Prefix " + cpLeiPrefix ;

					logger.info(">>>>>>>>>  Filtered due to counterparty Lei Change " + description);

					RegRepValidationException currException = new RegRepValidationException();
					currException.setMessageId(sdrMessageId);
					currException.setTradeid(tradeId);
					currException.setExceptionCode("ADDITIONAL_VALIDATOR_05");
					currException.setExceptionType(ExceptionTypeEnum.INPUT_DATA_ERROR.toString());
					currException.setDescription(description);

					regRepValidationExceptionDaoImpl.insert(currException);
					addAlertValidationResult(context, "CTRPTYLEI_FILTER", "FILTER_12", description, "VALIDATION");
					//context.setInvalid(true);
					
					//addFilterValidationResult(context, "CTRPTYLEI_FILTER", "FILTER_12", "CounterParty LEI is Invalid Existing: " + existingCptyPrefix + " Current: " + cpLeiWithPrefix, "VALIDATION");
					//context.setFiltered(true);
					
					logger.info(">>>>>>>>> Filtered due to counterparty Lei Change " + description);

				}

				// insert incoming trade details into RegRepTradeValidation table only if trade not exists
				// in TradeValidation table and it is not a filter trade
				if (!context.isInvalid() && null == currRegRepTradeValidation)
				{
					currRegRepTradeValidation = new RegRepTradeValidation();
					currRegRepTradeValidation.setCounterpartyLei(cpLeiWithPrefix);
					currRegRepTradeValidation.setLifecycleEventType(eventName);
					currRegRepTradeValidation.setEntityLei(entityLeiWithPrefix);
					currRegRepTradeValidation.setTradeid(tradeId);
					currRegRepTradeValidation.setUsi(usiValue);
					currRegRepTradeValidation.setUti(utiValue);

					regRegTradeValidationDaoImpl.insertTradeVal(currRegRepTradeValidation);			
				}
				
				//set invalid flag to false to continue with further processing of trade
				//context.setInvalid(false);

			}
			catch (Exception exp)
			{
				errorString = "Error while executing CptyLeiValidator rule : " + exp.getMessage();
				logger.error("########## " + errorString);

				throw new MessagingException("ADDITIONAL_VALIDATOR_05", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp,
				        context.getSwapTradeId());

			}
		}

		logger.debug("Completed " + this.getClass().getName() + " Validator");
		return message;

	}

}
