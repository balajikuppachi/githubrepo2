package com.wellsfargo.regulatory.core.integration.filters;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

@Component
public class ConfirmRequestFilter 
{
	private static Logger logger = Logger.getLogger(ConfirmRequestFilter.class);

	public boolean accept(ReportingContext context) throws MessagingException 
	{
		if (null == context) 
		{
			String msg = "ConfirmRequestFilter: null context";
			logger.error(msg);
			throw new MessagingException("CnfrmReqFltr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, msg);
		}
		
		return ! context.getConfirmationAlert();
	}	
}
