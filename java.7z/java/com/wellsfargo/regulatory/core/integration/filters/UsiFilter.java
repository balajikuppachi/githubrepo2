package com.wellsfargo.regulatory.core.integration.filters;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;

@Component
public class UsiFilter extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(UsiFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");

		String errorString = null;

		if (null == message) return message;

		ReportingContext context = (ReportingContext) message.getPayload();

		try
		{
			SdrRequest request = context.getSdrRequest();
			AbstractDriver.setMDCInfo(context, AbstractDriver.UsiFilter);

			String usiValue = null;
			RegulatoryType regulatoryType = null;
			KeywordsType keywordsType = null;
			List<Keyword> keywordList = null;

			regulatoryType = request.getTrade().getRegulatory();
			if (null != regulatoryType)
			{
				keywordsType = regulatoryType.getKeywords();
				if (null != keywordsType)
				{
					keywordList = keywordsType.getKeyword();

					for (Keyword currKeyword : keywordList)
					{
						if (Constants.USI_VALUE.equals(currKeyword.getName()))
						{
							usiValue = currKeyword.getValue();
							break;
						}
					}
				}
			}

			if (StringUtils.isBlank(usiValue))
			{
				addFilterValidationResult(context, "usi filter", "FILTER_08", "usiFilter: usi is either null or empty :  ", "FILTER");
				context.setFiltered(true);
				logger.info(">>>>>>>>> Filter due to usiFilter rule ::: USI-Value: " + usiValue);
			}
		}
		catch (Exception exp)
		{
			errorString = "Error while executing UsiFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter08", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), exp, context.getSwapTradeId());

		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}

}
