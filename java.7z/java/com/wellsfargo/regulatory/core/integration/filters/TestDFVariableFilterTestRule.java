package com.wellsfargo.regulatory.core.integration.filters;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

@Component
public class TestDFVariableFilterTestRule extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(TestDFVariableFilterTestRule.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");

		if (null == message) return message;

		String errorString = null;
		ReportingContext context = (ReportingContext) message.getPayload();

		try
		{
			SdrRequest request = context.getSdrRequest();
			AbstractDriver.setMDCInfo(context, AbstractDriver.TestDFVariableFilterTestRule);

			UsThemEnum reportingParty = null;
			JurisdictionEnum reportingJurisdiction = null;
			RegulatoryType regulatory = null;
			List<ReportingEligibilityType> reportingEligibilityList = null;

			regulatory = request.getTrade().getRegulatory();
			if (null != regulatory)
			{
				reportingEligibilityList = regulatory.getReportingEligibility();

				if (null != reportingEligibilityList)
				{
					reportingParty = reportingEligibilityList.get(0).getReportingParty();
					reportingJurisdiction = reportingEligibilityList.get(0).getReportingJurisdiction();
				}
			}

			if (null != reportingParty && null != reportingJurisdiction && (StringUtils.isBlank(reportingParty.toString()) || StringUtils.isBlank(reportingJurisdiction.toString())))
			{
				addFilterValidationResult(context, "reportingParty/reportingJurisdiction", "FILTER_05", "either reportingParty/reportingJurisdiction does not exist", "FILTER");
				context.setFiltered(true);
				logger.info(">>>>>>>>> Filtered due to dFVariableFilter rule");
			}
		}
		catch (Exception exp)
		{
			errorString = "Error while executing DFVariableFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter03", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), exp, context.getSwapTradeId());

		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}

}
