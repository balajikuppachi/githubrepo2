package com.wellsfargo.regulatory.core.integration.filters;

import static com.wellsfargo.regulatory.commons.keywords.Constants.PRODUCT_TYPE_RISK_PARTICIPATION_SWAP;

import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

@Component
public class RpsTradeFilter extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(RpsTradeFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");

		if (null == message) return message;

		String errorString = null;
		ReportingContext context = (ReportingContext) message.getPayload();

		try
		{
			SdrRequest request = context.getSdrRequest();
			AbstractDriver.setMDCInfo(context, AbstractDriver.RpsTradeFilter);

			String 			productType 	= null;
			ProductType 	product 		= null;
			Set<String> 	regulatories 	= null;

			product = request.getTrade().getTradeDetail().getProduct();
			if (null != product) productType = product.getProductType();
			
			regulatories = context.getRegulatories().keySet();
			
			if(null == regulatories){
				
				logger.error("No regulatory information found for RPS Trade Filter check.");
				return message;
			}

			if (StringUtils.equalsIgnoreCase(productType, PRODUCT_TYPE_RISK_PARTICIPATION_SWAP))			      
			{
				// RPS is reportable under CAD
				if(null != context.getCurrJurisdiction() 
						&& (context.getCurrJurisdiction().contains(JurisdictionEnum.CA_MB_MSC.value())
						    ||context.getCurrJurisdiction().contains(JurisdictionEnum.CA_ON_OSC.value())
						    ||context.getCurrJurisdiction().contains(JurisdictionEnum.CA_QC_AMF.value()))){			
					
					return message;					
				}			
				
				addFilterValidationResult(context, "rpsTradeFilterRule", "FILTER_07",
				        "rpsTradeFilterRule: trade is not eligble to report as reporting jurisdiction is other than CAD and productType is RiskParticipationSwap ", "FILTER");
				context.setFiltered(true);
				logger.info(">>>>>>>>> Filter due to rpsTradeFilterRule rule ::: Regulatory: " + regulatories + " ::: Product type:  " + productType);
			}
		}
		catch (Exception exp)
		{
			errorString = "Error while executing RpsTradeFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter07", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), exp, context.getSwapTradeId());
		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}

}
