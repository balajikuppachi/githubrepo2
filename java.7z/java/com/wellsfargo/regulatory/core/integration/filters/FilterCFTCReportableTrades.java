package com.wellsfargo.regulatory.core.integration.filters;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.core.rules.util.KieSessionFactory;

@Component
public class FilterCFTCReportableTrades
{
	private static Logger logger = Logger.getLogger(FilterCFTCReportableTrades.class.getName());

	public Message<?> filterTrades(Message<?> message) throws MessagingException
	{
		ReportingContext context	= (ReportingContext) message.getPayload();
		String messageId 			= context.getMessageId();

		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.FilterCFTCReportableTrades);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(context.getMessageId()));

		logger.debug("Entering filterNonRptTrades() method");

		try
		{
			//KieServices ks = KieServices.Factory.get();
			//KieContainer kc = ks.getKieClasspathContainer();
			//KieSession Ksession = kc.newKieSession("filterKSession");
			
			KieSession enrichKession 	= KieSessionFactory.getKieSession("enrichKS");
			FactHandle factHandle 		= enrichKession.insert(context);
			enrichKession.setGlobal("logger", logger);

			/*** All rules placed under commonAgenda will be executed first assetClassAgenda will execute after commonAgenda rules ***/
			// Ksession.insert(context);
			// Agenda agenda = Ksession.getAgenda();
			// agenda.getAgendaGroup("filterAgenda").setFocus();

			enrichKession.fireAllRules();
			enrichKession.delete(factHandle);
			enrichKession.dispose();

			/*** START : Testing purpose Only ****/
			if (context.getRulesResultsContext() != null)
			{
				List<ValidationResult> filterValidationResultList = context.getRulesResultsContext().getFilterValidationResultList();

				if (filterValidationResultList != null)
				{
					for (ValidationResult currValidationResult : filterValidationResultList)
					{
						logger.debug(">>>>>>>>> Filter validation results are: " + currValidationResult.toString());
					}
				}
			}
			/*** END : Testing purpose Only ****/
		}
		catch (Exception e)
		{
			logger.error("########## Unable to filter trades ", e);
			throw new MessagingException("80R", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage(), messageId, e, context.getSwapTradeId());
		}

		logger.debug("Leaving filterNonRptTrades() method");

		return message;
	}

}
