package com.wellsfargo.regulatory.core.integration.filters;

import static com.wellsfargo.regulatory.commons.keywords.Constants.TRADE_STATUS_EXPIRED;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRADE_STATUS_MATURED;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRADE_STATUS_SETTLED;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;

/**
 * @author 	Amit Rana
 * @date 	06/08/2015
 * @version 1.0
 */

@Component
public class TradeStatusFilter extends FilterRulesContextMgr {
	
	private static Logger logger = Logger.getLogger(TradeStatusFilter.class.getName());
	
	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");
		
		String 				errorString = null;
		String				tradeStatus	= null;
		String 				lifeCycleType =null;
		if (null == message) return message;
		
		ReportingContext 	context  = (ReportingContext) message.getPayload();
		
		try
		{	
			
			
			AbstractDriver.setMDCInfo(context, AbstractDriver.TradeStatusFilter);
			lifeCycleType 	=GeneralUtils.resolveIfNull(()->context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType(),"lifeCycleEvent");
			tradeStatus=GeneralUtils.resolveIfNull(()->context.getSdrRequest().getTrade().getTradeHeader().getStatus(),"status");
			
			if(null != lifeCycleType 	&& (Constants.MATURE.equals(lifeCycleType)	|| Constants.EXPIRED.equals(lifeCycleType)	|| Constants.SETTLED.equals(lifeCycleType))){
				
				addFilterValidationResult(context, "LifeCycleEvent_Filter", "Filter_077", "Ineligible LCE for real time msgs:"+lifeCycleType, "FILTER");
				context.setFiltered(true);
				logger.info(">>>>>>>>> Filtered due to TradeStatusFilter rule");
				return message;
			}

			
			
			if(null != tradeStatus && !context.isFiltered() && (TRADE_STATUS_MATURED.equals(tradeStatus)	|| TRADE_STATUS_SETTLED.equals(tradeStatus)	|| TRADE_STATUS_EXPIRED.equals(tradeStatus))){
				
				addFilterValidationResult(context, "Trade_Status_Filter", "Filter_077", "Ineligible Trade Status for real time msgs:"+tradeStatus, "FILTER");
				context.setFiltered(true);
				logger.info(">>>>>>>>> Filtered due to TradeStatusFilter rule");
			}
			
			
		}catch(Exception e){
			
			errorString = "Error while executing TradeStatusFilter rule : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter_077", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), e, context.getSwapTradeId());
			
		}
		
		return message;
	}

}
