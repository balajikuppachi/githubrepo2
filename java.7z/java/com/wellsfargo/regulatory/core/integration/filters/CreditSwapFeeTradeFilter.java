package com.wellsfargo.regulatory.core.integration.filters;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;

@Component
public class CreditSwapFeeTradeFilter extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(CreditSwapFeeTradeFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing "+this.getClass().getName()+" filter");

		if(null == message)
			return message;

		String errorString 			= null;
		ReportingContext context 	= (ReportingContext) message.getPayload();

		try
		{
			SdrRequest request = context.getSdrRequest();
			AbstractDriver.setMDCInfo(context, AbstractDriver.CreditSwapFeeTradeFilter);

			String assetClass 		= null;
			String productType 		= null;
			LegType leg 			= null;
			ProductType product 	= null;
			BigDecimal hundred 		= new BigDecimal(100);
			BigDecimal notional 	= null;

			assetClass 	= request.getAssetClass();
			product 	= request.getTrade().getTradeDetail().getProduct();

			if (null != product)
			{
				productType = product.getProductType();
				leg 		= product.getLeg().get(0);

				if (null != leg) notional = leg.getNotional();
			}

			if (Constants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass) == true && Constants.CREDITDEFAULTSWAP.equals(productType) == true)
			{

				if (notional.abs().compareTo(hundred) < 0 == true)
				{
					addFilterValidationResult(context, "CreditSwapFeeTradeFilter", "FILTER_02", "CreditSwapFeeTradeFilter: notional amount is less than 100 for CreditDefaultSwap notional received :  " + notional, "FILTER");
					context.setFiltered(true);
					
					logger.debug(">>>>>>>>> Filter due to isCreditSwapFeeTrade rule");
				}
			}
		}
		catch (Exception exp)
		{
			errorString = "Error while executing CreditSwapFeeTradeFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter02", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp, context.getSwapTradeId());
		}

		logger.debug("Completed "+this.getClass().getName()+" filter");
		return message;
	}

}
