package com.wellsfargo.regulatory.core.integration.filters;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class PartialTermFilter extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(PartialTermFilter.class.getName());

	/**
	 * This filter needs to be deleted when is123Trade() is implemented
	 * @param message
	 * @return
	 * @throws MessagingException
	 */
	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing "+this.getClass().getName()+" filter");

		if(null == message)
			return message;

		String errorString =            null;
		ReportingContext context = (ReportingContext) message.getPayload();

		try
		{
			SdrRequest request = context.getSdrRequest();
			AbstractDriver.setMDCInfo(context, AbstractDriver.PartialTermFilter);

			LifeCycleType lifeCycleType = null;
			String eventType 			= null;
			String assetClass 			= null;
			String termAmountStr 		= null;
			BigDecimal termAmount 		= null;
			RegulatoryType regulatory   = null;
			
			
			lifeCycleType = request.getTrade().getTradeHeader().getLifeCycle();

			regulatory = context.getSdrRequest().getTrade().getRegulatory();
			
			if (null != lifeCycleType) eventType = lifeCycleType.getEventType();

			if (!Constants.ASSET_CLASS_EQUITY.equals(assetClass) && Constants.Partial_Term_Voluntary.equals(eventType))
			{
				termAmountStr = ReportingDataUtils.getKeyWordContents(regulatory.getKeywords(), Constants.PARTIAL_TERMINATION_AMOUNT);
				
				if (termAmountStr != null)
				{
					termAmount = new BigDecimal(termAmountStr);
				
					if ( ConversionUtils.bigDecimalToDouble(termAmount) < 0) 
					{
						addFilterValidationResult(context, "PartialTermAmount", "FILTER_05", "Ineligible Partial term amount: " + eventType, "FILTER");
						context.setFiltered(true);
						
						logger.debug(">>>>>>>>> Filtered due to Negative Partial term amount rule");
					}
				}
			}
			
			
		}
		catch (Exception exp)
		{
			errorString = "Error while executing PartialTermFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter01", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(),exp, context.getSwapTradeId());
		}

		logger.debug("Completed "+this.getClass().getName()+" filter");
		return message;
	}
}
