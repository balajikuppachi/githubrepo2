package com.wellsfargo.regulatory.core.integration.filters;

import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

/**
 * RetractionFilter check whether trade is eligible for RT retraction
 * @author u236098
 *
 */
@Component
public class RetractionFilter extends FilterRulesContextMgr
{
	@Autowired
	private RegRepMessageDao msgDao;
	
	private static Logger logger = Logger.getLogger(RetractionFilter.class.getName());
	
	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing "+this.getClass().getName()+" filter");

		if(null == message)
			return message;

		ReportingContext context = (ReportingContext) message.getPayload();
		AbstractDriver.setMDCInfo(context, AbstractDriver.RetractionFilter);
		
		SdrRequest request = context.getSdrRequest();
		String lifeCycleType 	=GeneralUtils.resolveIfNull(()->request.getTrade().getTradeHeader().getLifeCycle().getEventType(),"lifeCycleEvent");
		String tradeId 			= request.getTrade().getTradeHeader().getTradeId();
		List<RegRepMessage> regRepMessageList		= null;
		String prevlifeCycleEventType	= null;
		
		/**Check if the Undoevent is not on the same day as LCE, if not raise an alert & do not send retract message.
		 * Below block checks for the event which generated RT & is eligible to retract the same
		 * */
		if(!GeneralUtils.IsNullOrBlank(lifeCycleType) && ArrayUtils.contains(Constants.UNDO_LCE_RT_RETRACT_LIST, lifeCycleType))
		{
			String undoEvent = StringUtils.split(lifeCycleType, Constants.HYPHEN)[1].trim().substring(0,4);
			regRepMessageList = msgDao.findByTradeIdAndJurisdictionNS(tradeId, context.getCurrJurisdiction().iterator().next());
			
			for (RegRepMessage regRepMessage : regRepMessageList) 
			{
				
				boolean isSameDay=DateUtils.isSameDay(regRepMessage.getRegRepMessageTimestamp(),Calendar.getInstance().getTime());
				prevlifeCycleEventType 	= regRepMessage.getLifecycleEventType();
				/**Check if the undo event & skip while lookup*/
				if(StringUtils.startsWith(prevlifeCycleEventType, Constants.Undo) )
					continue;
				
				/**Check if the event before UNDO  is eligible for retract & also undo is on the same day*/
				if(!StringUtils.startsWith(prevlifeCycleEventType, undoEvent) || !isSameDay)
				{
					addFilterValidationResult(context, "UndoEvent", "UNDOEVENT_FILTER_01", "Trade not eligible for RT retraction  : UndoEvent-" + lifeCycleType+",PreviousEvent:"+prevlifeCycleEventType+", Sameday:"+isSameDay, "FILTER");
					context.setFiltered(true);
					logger.debug(">>>>>>>>> Trade not eligible for RT retraction");
					break;
				}else
				{
					logger.debug(">>>>>>>>> Trade eligible for RT retraction");
					return message;
				}
			}
			
		}else 	if(!GeneralUtils.IsNullOrBlank(lifeCycleType) && ArrayUtils.contains(Constants.UNDO_LCE_LIST, lifeCycleType))
		{
			/**All other LCE where RT retraction is not required since we dint generate RT for the same**/
			context.setFiltered(true);
			logger.debug(">>>>>>>>> Trade not eligible for RT retraction");
		}
		return message;
	
	}
}
