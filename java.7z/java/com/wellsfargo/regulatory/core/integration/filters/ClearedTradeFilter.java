package com.wellsfargo.regulatory.core.integration.filters;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

/**
 * @author Amit Rana
 * @date 04/30/2015
 * @version 1.0
 */

@Component
public class ClearedTradeFilter extends FilterRulesContextMgr 
{
	private static Logger logger = Logger.getLogger(ClearedTradeFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");

		
		String			eventType	= null;
		
		if (null == message) return message;

		String errorString 			= null;
		ReportingContext context 	= (ReportingContext) message.getPayload();
		try
		{			
			AbstractDriver.setMDCInfo(context, AbstractDriver.ClearedTradeFilter);
				
			eventType = GeneralUtils.resolveIfNull(()->context.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType(),"lifeCycleType");
			
			
			if (Constants.Bilateral_Cleared.equalsIgnoreCase(eventType) || ReportingDataUtils.isClearedTrade(context) )
			{
				addFilterValidationResult(context, "Cleared_Trade_Filter", "FILTER_07", "Trade is cleared", "FILTER");
				context.setFiltered(true);
				logger.debug(">>>>>>>>> Filtered due to cleared trade rule");
			}
			
		}
		catch (Exception exp)
		{
			errorString = "Error while executing ClearedTradeFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter_07", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp, context.getSwapTradeId());
		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}

}
