package com.wellsfargo.regulatory.core.integration.filters;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.core.enrichment.UsiEnricher;
import com.wellsfargo.regulatory.commons.keywords.Constants;

@Component
public class CompressedPartialTermFilter extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(UsiEnricher.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing "+this.getClass().getName()+" filter");

		if(null == message)
			return message;

		String errorString 			= null;
		ReportingContext context 	= (ReportingContext) message.getPayload();

		try
		{
			SdrRequest request = context.getSdrRequest();
			AbstractDriver.setMDCInfo(context, AbstractDriver.CompressedPartialTermFilter);

			LifeCycleType lifeCycleType =  null;
			String eventType =             null;

			lifeCycleType = request.getTrade().getTradeHeader().getLifeCycle();

			if (null != lifeCycleType) eventType = lifeCycleType.getEventType();

			/*** This filter rule will add RulesResult to the context ***/
			/*** Create the Context only when it is NULL ***/
			if( null == context.getRulesResultsContext())
			    initFilterResult(context);

			if (StringUtils.equalsIgnoreCase(Constants.Compressed_PartialTerm, eventType) == true)
			{
				addFilterValidationResult(context, "MarketType/EventType", "FILTER_09", "Ineligible Market Type for real time msgs:" + eventType, "FILTER");
				context.setFiltered(true);
				
				logger.debug(">>>>>>>>> Filtered due to CompressedPartialTermFilter rule");
			}
		}
		catch (Exception exp)
		{
			errorString = "Error while executing CompressedPartialTermFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter01", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(),exp, context.getSwapTradeId());
		}

		logger.debug("Completed "+this.getClass().getName()+" filter");
		
		return message;
	}

}
