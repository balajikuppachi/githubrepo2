package com.wellsfargo.regulatory.core.integration.filters;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

@Component
public class NoContextTypeFilter {
	private static Logger logger = Logger.getLogger(NoContextTypeFilter.class);
	
	public boolean accept(ReportingContext context) throws MessagingException {
		if (null == context) {
			String msg = "NoContextTypeFilter: null context";
			logger.error(msg);
			throw new MessagingException("NoCtxtFltr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, msg);
			
		}else if(PayloadTypeEnum.REG_REP_RESPONSE.equals(context.getContextType())){
			
			String msg = "TEST:MSG --> ################################## Context Type was REG-REP response : Filtering UI event ###################################################";
			logger.error(msg);
			return false;
		}
		
		
		return null != context.getContextType();
	}

}
