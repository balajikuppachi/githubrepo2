package com.wellsfargo.regulatory.core.integration.filters;

import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

@Component
public class ReportingPartyFilter extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(ReportingPartyFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");

		if (null == message) return message;

		String errorString = null;
		ReportingContext context = (ReportingContext) message.getPayload();

		try
		{

			AbstractDriver.setMDCInfo(context, AbstractDriver.ReportingPartyFilter);
			
			boolean 	filterflag 				= false;
			String 		wfLei 					= null;		
			Set<String> reportingEligibilitySet = null;
			String[]	repInfo					= null;
			String		jurisdiction			= null;
			
			
			/*
			 * Based on the assumption that Reporting Party Filter
			 * is the last in the chain. 
			 * This rule should fire only if no other filter satisfied the rule
			 * 
			 */			
			if(null != context && null != context.getRulesResultsContext()
					&& null != context.getRulesResultsContext().getFilterValidationResultList()
					&& context.getRulesResultsContext().getFilterValidationResultList().size() > 0)
				return message;
			
			// For None flow we may avoid rest of the flow
			// Tagging reporting party based on Jurisdiction 
			if(null != context.getCurrJurisdiction()
					&& context.getCurrJurisdiction().contains(Constants.NONE)){
				
				/* This is now being taken care of by Unsupported Jurisdiction filter*/
				// filterflag = true;
				
			}else{					
				
				if(null != context.getRegulatories()){
					
					reportingEligibilitySet = context.getRegulatories().keySet();
					
					for(String reg : reportingEligibilitySet){
						
						if(null == reg) continue;
						
						repInfo = reg.split(UNDERSCORE);
						
						if(null == repInfo) continue;
						
						if(repInfo.length > 0 && null != repInfo[0]){
							
							jurisdiction = repInfo[0];
											
							if(null != context.getCurrJurisdiction() 
									&& (context.getCurrJurisdiction().contains(JurisdictionEnum.CA_MB_MSC.value())
											|| context.getCurrJurisdiction().contains(JurisdictionEnum.CA_ON_OSC.value())
											|| context.getCurrJurisdiction().contains(JurisdictionEnum.CA_QC_AMF.value()))){
								
								if(JurisdictionEnum.CA_MB_MSC.value().equals(jurisdiction)
										|| JurisdictionEnum.CA_ON_OSC.value().equals(jurisdiction)
										|| JurisdictionEnum.CA_QC_AMF.value().equals(jurisdiction)){
									
									if(UsThemEnum.THEM.value().equalsIgnoreCase(context.getRegulatories().get(reg))){
										filterflag = true;
									}
								}							
							}else if(null != context.getCurrJurisdiction() 
									&& context.getCurrJurisdiction().contains(JurisdictionEnum.CFTC.value())){
								
								if(JurisdictionEnum.CFTC.value().equals(jurisdiction)){
																		
									if(UsThemEnum.THEM.value().equalsIgnoreCase(context.getRegulatories().get(reg)) && 
											!context.isFeeTrade()){
										filterflag = true;
									}
								}							
							}else if(null != context.getCurrJurisdiction() 
									&& context.getCurrJurisdiction().contains(JurisdictionEnum.SEC.value())){
								
								if(JurisdictionEnum.SEC.value().equals(jurisdiction)){
									
									if(UsThemEnum.THEM.value().equalsIgnoreCase(context.getRegulatories().get(reg))){
										filterflag = true;
									}
								}							
							}
							
						}					
					}
				}		

			}

			if (filterflag == true 
					//&& (StringUtils.contains(wf_affiliate_leis, wfLei)||StringUtils.contains(wf_lei, wfLei))
				)
			{
				addFilterValidationResult(context, "ReportingPartyFilter", "RP-Filter", "ReportingPartyFilter: trade is not eligble to report as reporting party is THEM. "
						+ "Regulatory ::: ReportingJurisdiction: " + jurisdiction, "FILTER");
				context.setFiltered(true);
				context.setReportingParty(false);
				logger.info(">>>>>>>>> Filter due to reporting party is THEM. Regulatory ::: ReportingJurisdiction: " + jurisdiction );
			}			

		}
		catch (Exception exp)
		{
			errorString = "Error while executing ReportingPartyFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("RP-Filter", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), exp, context.getSwapTradeId());

		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}

}
