package com.wellsfargo.regulatory.core.integration.filters;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;

@Component
public class ForexFilter extends FilterRulesContextMgr
{

	private static Logger logger = Logger.getLogger(ForexFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");

		if (null == message) return message;

		String errorString = null;
		ReportingContext context = (ReportingContext) message.getPayload();

		try
		{
			SdrRequest request = context.getSdrRequest();
			AbstractDriver.setMDCInfo(context, AbstractDriver.ForexFilter);

			String productType 		= null;
			String productSubType 	= null;
			ProductType product 	= null;

			product = request.getTrade().getTradeDetail().getProduct();

			if (null != product)
			{
				productType 	= product.getProductType();
				productSubType 	= product.getProductSubType();

			}

			if (Constants.PRODUCT_TYPE_FXCASH.equalsIgnoreCase(productType) == true && Constants.FOREX_FORWARD.equalsIgnoreCase(productSubType) == true)
			{
				addFilterValidationResult(context, "isForexEligible", "FILTER_04", "Product not reportable. Incoming product is :" + productType, "FILTER");
				context.setFiltered(true);
				
				logger.debug(">>>>>>>>> Filter due to isForexEligible rule :: " + " ::: Product Type:  " + productType + " ::: Subproduct type is : " + productSubType);
			}
		}
		catch (Exception exp)
		{
			errorString = "Error while executing ForexFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter04", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp, context.getSwapTradeId());

		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}

}
