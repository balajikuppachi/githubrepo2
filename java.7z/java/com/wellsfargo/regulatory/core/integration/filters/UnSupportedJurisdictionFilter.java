package com.wellsfargo.regulatory.core.integration.filters;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

@Component
public class UnSupportedJurisdictionFilter extends FilterRulesContextMgr 
{
	private static Logger logger = Logger.getLogger(UnSupportedJurisdictionFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");
		
		boolean filterflag 			= false;
		List<String> jurisdiction 	= null;

		if (null == message) return message;

		String errorString 			= null;
		ReportingContext context 	= (ReportingContext) message.getPayload();

		try
		{
			AbstractDriver.setMDCInfo(context, AbstractDriver.UnSupportedJurisdictionFilter);
			
			jurisdiction = context.getCurrJurisdiction();
			
			if(null != jurisdiction
					&& (jurisdiction.contains(JurisdictionEnum.NONE.value())
						//||jurisdiction.contains(JurisdictionEnum.ESMA.value())    -- Started supporting ESMA 
						||jurisdiction.contains(JurisdictionEnum.SEC.value())))
			{
				/*** Check if the number of regulatories is only one. ***/
				if(null != context.getRegulatories()
						&& null != context.getRegulatories().keySet()
						&& context.getRegulatories().keySet().size() < 2)
				{
					/*** For non reporting party we should not raise unsupported jurisdiction filter ***/
					if(context.isReportingParty())				
						filterflag = true;
				}				
			}
			else
			{
				return message;
			}
			
			if (filterflag)					
			{
				addFilterValidationResult(context, "UnSupportedJurisdictionFilter", "Jur-Filter", "UnSupportedJurisdictionFilter: Trade falls under jurisdiction " + jurisdiction, "FILTER");
				context.setFiltered(true);				
				
				logger.info(">>>>>>>>> Filtered due to unsupported Jurisdiction +" + jurisdiction );
			}
			
		}
		catch (Exception exp)		
		{
			errorString = "Error while executing UnSupportedJurisdictionFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Jur-Filter", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp, context.getSwapTradeId());

		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}
	

}
