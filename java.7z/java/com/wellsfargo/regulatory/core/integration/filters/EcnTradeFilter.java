package com.wellsfargo.regulatory.core.integration.filters;

import static com.wellsfargo.regulatory.commons.keywords.Constants.ECN_BLOOMBERG;
import static com.wellsfargo.regulatory.commons.keywords.Constants.ECN_SWAPSWIRE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.ECN_TRADEWEB;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

/**
 * @author 	Amit Rana
 * @date 	04/30/2015
 * @version 1.0
 */

@Component
public class EcnTradeFilter  extends FilterRulesContextMgr 
{
	private static Logger logger = Logger.getLogger(EcnTradeFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");
		
		SdrRequest 			request 	= null;
		TradeType			trade		= null;
		TradeHeaderType		tradeHeader	= null;
		String 				errorString = null;
		ReportingContext 	context 	= null;
		String				ecnSource	= null;
		
		if (null == message) return message;
		
		try
		{	
			context = (ReportingContext) message.getPayload();
			AbstractDriver.setMDCInfo(context, AbstractDriver.EcnTradeFilter);
						
			if(null != context)
				request 	= context.getSdrRequest();
			else
				return message;
			
			if(null != request)
				trade		= request.getTrade();
			else
				return message;
			
			if(null != trade)
				tradeHeader	= trade.getTradeHeader();
			else
				return message;
			
			if(null != tradeHeader)
				ecnSource	= tradeHeader.getEcnSource();
			else
				return message;
			
			if(null != ecnSource 
					&& (ECN_SWAPSWIRE.equals(ecnSource)
							|| ECN_TRADEWEB.equals(ecnSource)
							|| ECN_BLOOMBERG.equals(ecnSource)))
			{
				addFilterValidationResult(context, "ECN_Trade_Filter", "FILTER_08", "Ineligible Trade Source for real time msgs:"+ecnSource, "FILTER");
				context.setFiltered(true);
				
				logger.debug(">>>>>>>>> Filtered due to ECN trade source rule");
			}
						
		}catch(Exception e){
			
			errorString = "Error while executing EcnTradeFilter rule : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("Filter_07", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), e, context.getSwapTradeId());
			
		}
		
		return message;
	}

}
