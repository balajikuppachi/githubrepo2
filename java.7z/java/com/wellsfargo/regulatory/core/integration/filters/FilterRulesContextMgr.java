package com.wellsfargo.regulatory.core.integration.filters;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.sdrResponse.ResponseCodeEnum;

public abstract class FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(FilterRulesContextMgr.class.getName());

	protected void initFilterResult(ReportingContext inReportingContext)
	{
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");

		inReportingContext.setRulesResultsContext(rulesResultsContext);

		logger.debug("RulesResult context initilized :");

	}

	protected void addFilterValidationResult(ReportingContext inReportingContext, String fieldName, String errorCode, String errorDesc, String validationType)
	{
		logger.debug("Inside FilterRulesContextMgr: addFilterValidationResult method");
		RulesResultsContext rulesResultsContext = inReportingContext.getRulesResultsContext();
		ValidationResult validationResult = new ValidationResult();

		validationResult.setFieldName(fieldName);

		if(null != validationType)
		{
			if("VALIDATION".equals(validationType))
			{
				validationResult.setCode(ResponseCodeEnum.VALIDATION_ERROR.value());
			}
		}

		validationResult.setErrorDesc(errorDesc);
		validationResult.setValidationType(validationType);

		if(null == rulesResultsContext)
			rulesResultsContext = new RulesResultsContext();

		rulesResultsContext.addFilterValidationResult(validationResult);

		inReportingContext.setRulesResultsContext(rulesResultsContext);

	}

	protected void addAlertValidationResult(ReportingContext inReportingContext, String fieldName, String errorCode, String errorDesc, String validationType)
	{
		logger.debug("Inside FilterRulesContextMgr: addAlertValidationResult method");
		
		RulesResultsContext rulesResultsContext = inReportingContext.getRulesResultsContext();
		ValidationResult validationResult = new ValidationResult();

		validationResult.setFieldName(fieldName);

		if(null != validationType)
		{
			if("VALIDATION".equals(validationType))
			{
				validationResult.setCode(ResponseCodeEnum.VALIDATION_ERROR.value());
			}
		}

		validationResult.setErrorDesc(errorDesc);
		validationResult.setValidationType(validationType);

		if(null == rulesResultsContext)
			rulesResultsContext = new RulesResultsContext();

		rulesResultsContext.addAlertValidationResult(validationResult);

		inReportingContext.setRulesResultsContext(rulesResultsContext);

	}

}
