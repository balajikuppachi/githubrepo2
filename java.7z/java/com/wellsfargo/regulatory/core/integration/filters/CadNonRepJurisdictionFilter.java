package com.wellsfargo.regulatory.core.integration.filters;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

/**
 * @author Raji Komatreddy
 */

@Component
public class CadNonRepJurisdictionFilter extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(CadNonRepJurisdictionFilter.class.getName());

	public Message<?> filter(Message<?> message) throws MessagingException
	{
		logger.debug("Executing " + this.getClass().getName() + " filter");

		if (null == message) return message;

		String errorString = null;
		ReportingContext context = (ReportingContext) message.getPayload();
		String inactiveProvince=StringUtils.join(context.getCurrJurisdiction(),",");

		try
		{
			AbstractDriver.setMDCInfo(context, AbstractDriver.CadNonRepJurisdictionFilter);

			addFilterValidationResult(context, "Inactive_Invalid_Province ", "FILTER_INACTIVE_CAD_1", "Inactive/Invalid Province received in the Juridictions - "
					+ inactiveProvince+ ". Reporting for active provinces ", "INACTIVE_CAD");
			context.setFiltered(true);
			logger.debug(">>>>>>>>> Filtered due to CAD Inactive/Invalid Province");

		}
		catch (Exception exp)
		{
			errorString = "Error while executing CadNonRepJurisdictionFilter rule : " + exp.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("FILTER_INACTIVE_CAD_1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, context.getMessageId(), exp, context.getSwapTradeId());

		}

		logger.debug("Completed " + this.getClass().getName() + " filter");
		return message;
	}

}
