/*package com.wellsfargo.regulatory.core.rules.services.impl;

import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.definition.KnowledgePackage;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.StatelessKnowledgeSession;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.core.integration.gateways.AbstractDriver;
import com.wellsfargo.regulatory.core.rules.services.DroolsDriver;
import com.wellsfargo.regulatory.core.services.reader.RegulatoryMessageReader;

*//**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 *//*

@Component
public class DroolsDriverImpl implements DroolsDriver
{
	private static Log LOGGER = LogFactory.getLog(DroolsDriverImpl.class);

	private KnowledgeBuilder kbuilder;
	private Collection<KnowledgePackage> pkgs;
	private KnowledgeBase kbase;
	private StatefulKnowledgeSession sFullksession;
	private StatelessKnowledgeSession sLessksession;
	private List<String> DRL_FILES;
	private ResourceType rscType;			// Should be one of the ResourceType Strings
	private String ssnType;

	public void initDrools(List<String> drlFilesString, String sessionType, ResourceType resourceType, ReportingContext context) throws Exception
	{
		// START : Setting the MDC from the Context
		AbstractDriver.setMDCInfo(context, AbstractDriver.DroolsDriverImpl);
		// END : Setting the MDC from the Context

		LOGGER.debug("Entering initDrools() method");

		DRL_FILES = drlFilesString;
		rscType = resourceType;
		ssnType = sessionType;

		kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
		kbase = KnowledgeBaseFactory.newKnowledgeBase();

		setResources();

		LOGGER.debug("Leaving initDrools() method");
	}

	private void setResources() throws Exception
	{
		LOGGER.debug("Entering setResources() method");

		// this will parse and compile in one step
		// read from file

		if (null == DRL_FILES) throw new Exception("Invalid DRL File names.");

		for (String DRL_FILE : DRL_FILES)
		{
			kbuilder.add(ResourceFactory.newClassPathResource(DRL_FILE, DroolsDriver.class), rscType);
		}

		*//**
		 * Part of POC - may come in handy some time So keeping it for now. // read second rule from
		 * String // String myRule =
		 * "import hellodrools.Message rule \"Hello World 2\" when message:Message (type==\"Test\") then System.out.println(\"Test, Drools!\"); end"
		 * ; // Resource myResource = ResourceFactory.newReaderResource((Reader) new
		 * StringReader(myRule)); // kbuilder.add(myResource, ResourceType.DRL); End of POC
		 *//*

		// Check the builder for errors
		if (kbuilder.hasErrors()) throw new Exception("Unable to compile drl --> " + kbuilder.getErrors().toString());

		// get the compiled packages (which are serializable)
		pkgs = kbuilder.getKnowledgePackages();

		// add the packages to a knowledgebase (deploy the knowledge packages).
		kbase.addKnowledgePackages(pkgs);

		returnSession();

		LOGGER.debug("Leaving setResources() method");
	}

	private void returnSession()
	{
		LOGGER.debug("Entering returnSession() method");

		if (DroolsDriver.SESSION_TYPE_STATEFULL.equals(ssnType)) sFullksession = kbase.newStatefulKnowledgeSession();
		else sLessksession = kbase.newStatelessKnowledgeSession();

		LOGGER.debug("Leaving returnSession() method");
	}

	public StatefulKnowledgeSession getStateFulKnowledgeSession()
	{
		return sFullksession;
	}

	public StatelessKnowledgeSession getStateLessKnowledgeSession()
	{
		return sLessksession;
	}

}
*/