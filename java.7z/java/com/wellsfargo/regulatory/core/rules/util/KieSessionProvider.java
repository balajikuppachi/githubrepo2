package com.wellsfargo.regulatory.core.rules.util;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

/**
 * 
 * @author Rama Nuti
 *
 */

public class KieSessionProvider 
{
	private static KieServices kServices;
	private static KieContainer kContainer;
	
	public KieSessionProvider()
	{
		kServices 	= KieServices.Factory.get();
		kContainer 	= kServices.getKieClasspathContainer();
	}
		
	public static KieSession createSession(String sessionName)
	{
		KieSession kSession = kContainer.newKieSession(sessionName);
		return kSession;
	}

	public static void disposeSession(KieSession sessionName)
	{
		if(null != sessionName)
		{
			sessionName.dispose();
		}
	}

	
}
