package com.wellsfargo.regulatory.core.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.xml.transform.StringSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class Test {

	private static final String 			ROOT_ELEMENT 	= "publicExecutionReport";
	private static final String 			XPATH_FILE_NAME	= "C:/fpmlTesting/testFraRTXpaths.xlsx";
	private static final String 			XPATH_SEPERATOR	= "/";
	private static 		 Transformer 		aTransformer  	=  null;
	private static final Logger				logger			=  Logger.getLogger(Test.class.getName());

	static{
		try{
			aTransformer = TransformerFactory.newInstance().newTransformer();
			aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
		    aTransformer.setOutputProperty(OutputKeys.METHOD, "xml");
		    aTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		}catch (Exception e) {
			logger.error(e);
		}
	}

//	public static void main(String[] args) {
//
//	    ByteArrayOutputStream 	baos 		= null;
//	    OutputStreamWriter 		osw 		= null;
//	    DocumentBuilderFactory 	domFactory 	= DocumentBuilderFactory.newInstance();
//	    Test 					test 		= new Test();
//	    List<String>			attributes	= null;
//	    short					attributeIndex	= 2;
//	    short					conditionIndex	= 3;
//	    String					attribute		= null;
//	    String 					condition		= null;
//
//		try {
//		    DocumentBuilder domBuilder = domFactory.newDocumentBuilder();
//		    Document newDoc = domBuilder.newDocument();
//
//		    // Root element
//		    Element rootElement = newDoc.createElement(ROOT_ELEMENT);
//		    newDoc.appendChild(rootElement);
//
//		    Map<String, List<String>> xPathMap = test.getXpathsFromFile();
//		    Set<String> xPaths = xPathMap.keySet();
//
//		    for(String xpath : xPaths){
//
//		    	attributes = xPathMap.get(xpath);
//		    	attribute  = attributes.get(attributeIndex - 1);			// Since first column is the key in the map
//		    	condition  = attributes.get(conditionIndex - 1);				// same as above
//
//		    	if(null != attribute){
//		    		test.appendNodes(rootElement, xpath, newDoc, attribute);
//		    	}else if(null != condition){
//
//		    		for(String xPath : xPathParser(condition, "None")){
//		    			test.appendNodes(rootElement, xPath, newDoc, null);
//		    		}
//		    	}
//
//		    }
//
//	        baos = new ByteArrayOutputStream();
//	        osw = new OutputStreamWriter(baos);
//
//	        Source src = new DOMSource(newDoc);
//	        Result result = new StreamResult(osw);
//	        aTransformer.transform(src, result);
//
//	        osw.flush();
//	        System.out.println(new String(baos.toByteArray()));
//
//		}catch (Exception e) {
//			logger.error(e);
//		}finally {
//	        try {
//	            osw.close();
//	            baos.close();
//	        } catch (Exception e) {
//	        	logger.error(e);
//	        }
//	    }
//	}

	public Element appendNodes(Element element, String path, Document newDoc, String attribute){

		String[] nodes;
		Element childElement	= null;
		boolean pathBroken 		= false;

		try{
		if(null == element || StringUtils.isBlank(path)){
			throw new RuntimeException("Invalid path/root element specified.");
		}

		nodes = path.split(XPATH_SEPERATOR);

		if(nodes.length <= 0){
			return element;
		}

		for(String node : nodes){

			if(!pathBroken)
				childElement = getDirectChild(element, node);

			if(null == childElement){
				childElement = addNode(element, node, newDoc, attribute);
				pathBroken = true;
			}

			element 	= childElement;
			childElement = null;
		}
		}catch (Exception e) {
			logger.error(e);
		}

		return element;
	}


	public Element addNode(Element parentElement, String nodeName, Document newDoc, String attributeName){

		Element childElement = null;

		if(null == parentElement || null == nodeName || null == newDoc)
			return parentElement;



		childElement = newDoc.createElement(nodeName);
		if(null != attributeName){
			childElement.setAttribute(attributeName, "testAtt");
		}
		parentElement.appendChild(childElement);

		return childElement;
	}

	public static Element getDirectChild(Element parent, String name){
	    for(Node child = parent.getFirstChild(); child != null; child = child.getNextSibling()) {
	        if(child instanceof Element && name.equals(child.getNodeName()))
	        	return (Element) child;
	    }

	    return null;
	}

	private Map<String, List<String>> getXpathsFromFile(){
		InputStream inp = null;
	    String cellValue = null;
	    Row row  = null;
	    Cell cell = null;
	    Map<String, List<String>> xPathMap = null;
	    List<String> properties = null;
	    short cellBeginIndex = 0;
	    short rowBeginIndex = 1;
	    short columnCount = 4;

        try {
            inp = new FileInputStream(XPATH_FILE_NAME);

            Workbook wb = WorkbookFactory.create(inp);
            Sheet sheet = wb.getSheetAt(0);

            int rowCount = sheet.getLastRowNum();
            logger.info("Total Number of Rows: " + (rowCount + 1));

            if(rowCount > 0){
            	xPathMap = new HashMap<String, List<String>>();
            }

            for (int rowCounter = rowBeginIndex; rowCounter <= rowCount; rowCounter++) {
                row = sheet.getRow(rowCounter);

                if(null == row)
                	continue;

                for(int cellCounter = cellBeginIndex; cellCounter < columnCount; cellCounter++){
                	cell = row.getCell(cellCounter);

                    if(null != cell){
                    	 cellValue = cell.getStringCellValue();
                    	 logger.info("[" + rowCounter + "," + cellCounter + "]=" + cellValue);
                    }

                	if(cellCounter == cellBeginIndex){
                		properties = new ArrayList<String>(4);
                		xPathMap.put(cellValue, properties);
                	}else{
                		properties.add(cellValue);
                	}

                	cellValue = null;
                }
            }

        } catch (Exception ex) {
        	logger.error(ex);
        } finally {
            try {
                inp.close();
            } catch (IOException ex) {
            	logger.error(ex);
            }
        }
		return xPathMap;
	}

	private static List<String> xPathParser(String conditionString, String value){
		List<String> xPathList = null;
		String consequence = null;
		String criteria =  null;

		if(StringUtils.isBlank(conditionString) || StringUtils.isBlank(value)){
			return xPathList;
		}

		String[] conditions = conditionString.split("|");
		for(String condition : conditions){
			criteria = condition.split(":")[0];

			if(criteria.equalsIgnoreCase(value)){
				consequence = condition.split(":")[1];
				break;
			}
		}

		if(null == consequence){
			return xPathList;
		}

		xPathList = Arrays.asList(consequence.split(","));

		return xPathList;
	}

	/*
	 * Trims generated XML of any empty tags
	 */
	public String cleanXml(String ipXml) throws FileNotFoundException
	{
		String transformedXml = null;
		StringWriter writer = null;
		TransformerFactory factory = null;
		Source xslt = null;
		Transformer transformer = null;
		Source xml = null;
		ClassLoader classloader = null;
		InputStream stream = null;

		String xslCleanerFileName = "C:\\temp\\test\\cleaner.xsl";

		if (null == ipXml || StringUtils.isBlank(xslCleanerFileName)) return ipXml;

		writer = new StringWriter();

		try
		{
			factory = TransformerFactory.newInstance();
			classloader = Thread.currentThread().getContextClassLoader();
			stream = new FileInputStream(new File(xslCleanerFileName)) ;
					//classloader.getResourceAsStream(xslCleanerFileName);
			xslt = new StreamSource(stream);

			transformer = factory.newTransformer(xslt);
			xml = new StringSource(ipXml);

			transformer.transform(xml, new StreamResult(writer));

			//System.out.println(writer.toString());
			//System.out.println("done");
		}
		catch (TransformerException e)
		{
			logger.error("######### Failed while removing empty tags from FpML ", e);
		}

		transformedXml = writer.toString();

		// logger.debug("Message after removing empty tags is --> "+transformedXml);
		return transformedXml;
	}

	public static void main(String[] args) throws IOException {


		String ipXml = new String();

		ipXml = FileUtils.readFileToString(new File("C:\\SDR\\test1.xml"));
		new Test().cleanXml(ipXml);
	}

}
