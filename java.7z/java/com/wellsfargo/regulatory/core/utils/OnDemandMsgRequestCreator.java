package com.wellsfargo.regulatory.core.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
// import com.wellsfargo.regulatory.commons.utils.FileUtils;
import com.wellsfargo.regulatory.core.services.reader.RegulatoryMessageReader;

import org.apache.commons.io.FileUtils;

/**
 * @author Raji Komatreddy
 */

@Component
public class OnDemandMsgRequestCreator
{

	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());

	public Message<?> create(Message<?> message) throws MessagingException
	{
		logger.info("inside OnDemandMsgRequestCreator ");

		String assetClass = null;
		String reportType = null;
		String jurisdiction = "CFTC_DTCC";
		Object ipMessage = null;
		File srcFile = null;
		String errorString = null;
		String origPayload = null;
		ReportingContext repContext = null;
		Message<?> messageOut = null;
		String fileName = null;
		String inAssetClass = null;

		ipMessage = message.getPayload();

		if (null == ipMessage)
		{
			errorString = "Null incoming request ";
			logger.error("########## " + errorString);
		}

		if (ipMessage instanceof File)
		{
			srcFile = ((File) ipMessage);
			fileName = srcFile.getName();

			logger.info("Submitting file to DTCC : " + fileName);
			int numParams = 0;
			String[] fileParams = fileName.split("_");
			numParams = fileParams.length;

			if (numParams < 2)
			{
				   logger.info(" *************  AssetClass, report type values are not present in filename : " + fileName  + " **************** ");
			} 

			else
			{
				inAssetClass = fileParams[0];
				reportType = fileParams[1];
				
				assetClass = StringUtils.equalsIgnoreCase(inAssetClass,"IR")? Constants.ASSET_CLASS_INTEREST_RATE:
					         StringUtils.equalsIgnoreCase(inAssetClass,"CR")?  Constants.ASSET_CLASS_CREDIT:
					         StringUtils.equalsIgnoreCase(inAssetClass,"FX")?  Constants.ASSET_CLASS_FOREX:
					         StringUtils.equalsIgnoreCase(inAssetClass,"EQ")?  Constants.ASSET_CLASS_EQUITY:null;						
	
				if(StringUtils.isBlank(assetClass))		
					logger.error("########## " + "invalid asset class in file name , valid file name should start with either IR_ CR_ FX_ EQ_");
			
			}

			try
			{
				if(StringUtils.isNotBlank(assetClass) && StringUtils.isNotBlank(assetClass) )
				{
					origPayload = FileUtils.readFileToString(srcFile);
					// - Remove the src file
					FileUtils.deleteQuietly(srcFile);
					logger.info("@@@@ report sending to dtcc : \n" + StringUtils.trimToEmpty(origPayload));

					repContext = ReportingContext.getInstance();
					repContext.setPayload(origPayload);
					repContext.setMessageId("onDemandFpMl_Submission");
					repContext.getRegulatories().put(jurisdiction, UsThemEnum.US + "");
					repContext.setAssetClass(assetClass);
					repContext.getReportTypes().add(reportType);

					SdrRequest request = new SdrRequest();
					request.setAssetClass(assetClass);
					repContext.setSdrRequest(request);

					// MessageBuilder.withPayload(origPayload).copyHeadersIfAbsent(message.getHeaders()).build();
					messageOut = MessageBuilder.withPayload(repContext).copyHeadersIfAbsent(message.getHeaders()).build();

					logger.info("@@@@ Message has been sucessfully read !");
					
				}
				else
				{
					logger.info("Asset class and report type information is not present in file name " + fileName);
				}
				

			}
			catch (IOException e)
			{
				errorString = "Failed to read the payload ";
				logger.error("########## " + errorString);
			}
		}		

		return messageOut;
	}

}
