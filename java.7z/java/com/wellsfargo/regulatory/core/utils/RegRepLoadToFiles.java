package com.wellsfargo.regulatory.core.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepReconTrioptimaDao;
import com.wellsfargo.regulatory.persister.dao.RegRepTradeDao;
import com.wellsfargo.regulatory.persister.dto.RegRepReconTrioptima;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;
import com.wellsfargo.regulatory.persister.trioptima.parser.RegRepTrioptimaParser;

@Component
public class RegRepLoadToFiles {

	private Logger logger = Logger.getLogger(RegRepLoadToFiles.class);
	
	ConversionUtils conversion;

	@Autowired
	private RegRepTradeDao regRepTradeDao;
	
	RegRepTrade tradeObject= null;
	
	@Autowired
	RegRepReconTrioptimaDao regRepReconTrioptimaDao;
	
	@Autowired 
	RegRepTrioptimaParser regRepTrioptimaParser;
	
	public void read(File file) throws FileNotFoundException, IOException{
		logger.info("Loading data from file: " + file);
		
		try {
			if(file.getName().contains("Snapshot_TOIR"))
			{
				List<RegRepReconTrioptima> regRepReconlst = readIRFile(file);
				if(null != regRepReconlst) {
					for (RegRepReconTrioptima regRepRecon : regRepReconlst) 
						{	
						if(file.getName().startsWith("D")){
							regRepRecon.setRepository("DTCC");
						} else {
							regRepRecon.setRepository("CAD");
						}
							if(null != regRepRecon) {
							regRepReconTrioptimaDao.saveOrUpdate(regRepRecon);
						}
						}
						logger.info("Finished Inserting Data for IR into REG_REP_RECON_TRIOPTIMA table");
				}
			} 
			if(file.getName().contains("Snapshot_TOCR"))
			{
				List<RegRepReconTrioptima> regRepReconlst = readCRFile(file);
				if(null != regRepReconlst) {
					for (RegRepReconTrioptima regRepRecon : regRepReconlst) 
					{	
						if(file.getName().startsWith("D")){
							regRepRecon.setRepository("DTCC");
						} else {
							regRepRecon.setRepository("CAD");
						}
						if(null != regRepRecon) {
							regRepReconTrioptimaDao.saveOrUpdate(regRepRecon);
						}
					}
					logger.info("Finished Inserting Data for CR into REG_REP_RECON_TRIOPTIMA table");
				}
			}
			if(file.getName().contains("Snapshot_TOFX"))
			{
				List<RegRepReconTrioptima> regRepReconlst = readFXFile(file);
				if(null != regRepReconlst) {
					for (RegRepReconTrioptima regRepRecon : regRepReconlst) 
					{	
						if(file.getName().startsWith("D")){
							regRepRecon.setRepository("DTCC");
						} else {
							regRepRecon.setRepository("CAD");
						}
						if(null != regRepRecon) {
							regRepReconTrioptimaDao.saveOrUpdate(regRepRecon);
						}
					}
					logger.info("Finished Inserting Data for FX into REG_REP_RECON_TRIOPTIMA table");
				}
			} 
			if(file.getName().contains("Snapshot_TO_Equity"))
			{
				List<RegRepReconTrioptima> regRepReconlst = readEQFile(file);
				if(null != regRepReconlst) {
					for (RegRepReconTrioptima regRepRecon : regRepReconlst) 
					{	
						if(file.getName().startsWith("D")){
							regRepRecon.setRepository("DTCC");
						} else {
							regRepRecon.setRepository("CAD");
						}
						if(null != regRepRecon) {
							regRepReconTrioptimaDao.saveOrUpdate(regRepRecon);
						}
					}
					logger.info("Finished Inserting Data for EQ into REG_REP_RECON_TRIOPTIMA table");
				}
			}
			
		} 
		catch (Exception ex) {
			logger.error("Error while reading the file " + ex.getMessage());
		}
		
	}
	

	public List<RegRepReconTrioptima> readIRFile(File fileName) throws IOException 
	{
		BufferedReader br = null;
		String line = "";
		String splitter = ",";
		List<RegRepReconTrioptima> listRecon = new ArrayList<RegRepReconTrioptima>();
		Date current_date = new Date();

		int i = 0;
		try {
			br = new BufferedReader(new FileReader(fileName));
			
			while ((line = br.readLine()) != null ) {
				
				RegRepReconTrioptima recon = null;
				RegRepTrioptima reconMessage = null;
				recon = new RegRepReconTrioptima();
				reconMessage = new RegRepTrioptima();
								
				tradeObject = new RegRepTrade();
				Object[]  reader = line.split(splitter);
				
				i = i+ 1;
				logger.info("Processing line : " + i);
				
				reconMessage.setPartyId((String)reader[0]);
				reconMessage.setCptyId((String)reader[1]);
				reconMessage.setTradeParty1((String)reader[2]);
				reconMessage.setTradeParty2((String)reader[3]);
				
				String tradeId = null;
				/*String messageID = null;*/
				
				tradeId = (String)reader[4];
				/*tradeObject = regRepTradeDao.findByPrimaryKeyNS(tradeId);
				if(null != tradeObject) {
					messageID = tradeObject.getLatestRegRepMessageId();
				}*/
				recon.setTradeID(tradeId);
				reconMessage.setTradeId(tradeId);
					/*if(null != messageID) 
					{
						recon.setMessageId(messageID);
					} else {*/
						recon.setMessageId("1234-4567-890");
					/*}*/
				recon.setIsActive("1");
				recon.setReportType(Constants.MESSAGE_TYPE_SNAPSHOT_TO);
				recon.setAssetClass("InterestRate");
				recon.setUsi((String)reader[5]);
				reconMessage.setProductId((String)reader[6]);
				reconMessage.setProductClass((String)reader[7]);
				reconMessage.setLeg1Payer((String)reader[8]);
				reconMessage.setNotionalAmountLeg1(convertStrtoBigDecimal((String)reader[9]));
				reconMessage.setNotionalCurrencyLeg1((String)reader[10]);
				reconMessage.setNotionalAmountLeg2(convertStrtoBigDecimal((String)reader[11]));
				reconMessage.setNotionalCurrencyLeg2((String)reader[12]);
				reconMessage.setEffectiveDate((String)reader[13]);
				reconMessage.setTradeDate((String)reader[14]);
				reconMessage.setTerminationDateLeg1((String)reader[15]);
				recon.setJurisdiction((String)reader[16]);
				reconMessage.setTradeParty2Role((String)reader[17]);
				reconMessage.setTradeParty1Role((String)reader[18]);
				reconMessage.setPaymentFreqMultiplierLeg1((String)reader[19]);
				reconMessage.setFixedRateLeg1(convertStrtoBigDecimal((String)reader[20]));
				reconMessage.setDayCountFractionLeg1((String)reader[21]);
				reconMessage.setDayCountFractionLeg2((String)reader[22]);
				reconMessage.setAdditionalRepository((String)reader[23]);
				reconMessage.setCollateralized((String)reader[24]);
				reconMessage.setExecutionVenue((String)reader[25]);
				reconMessage.setOptionalEarlyTermination((String)reader[26]);
				reconMessage.setFloatingRateTenorLeg1((String)reader[27]);
				reconMessage.setPaymentFreqLeg1((String)reader[28]);
				reconMessage.setFloatingRateIndexLeg1((String)reader[29]);
				reconMessage.setResetFreq1((String)reader[30]);
				reconMessage.setFloatingRateTenorLeg2((String)reader[31]);
				reconMessage.setPaymentFreqLeg2((String)reader[32]);
				reconMessage.setFloatingRateIndexLeg2((String)reader[33]);
				reconMessage.setResetFreq2((String)reader[34]);
				reconMessage.setSubmittor((String)reader[35]);
				reconMessage.setTradeParty2UsPersonIndicator((String)reader[36]);
				reconMessage.setTradeParty2UsPersonIndicator((String)reader[37]);
				reconMessage.setOptionType((String)reader[38]);
				reconMessage.setSecondaryAssetClass((String)reader[39]);
				if(reader.length>40 ) {
					reconMessage.setLeg2Payer((String)reader[40]);
					if(reader.length>41 ) { 
						reconMessage.setBuyer((String)reader[41]);
					if(reader.length>42 ) {
						reconMessage.setSeller((String)reader[42]);
					if(reader.length>43 ) {
						reconMessage.setEffectiveDate((String)reader[43]);
					if(reader.length>44 ) {
						reconMessage.setFixedRateLeg2(convertStrtoBigDecimal((String)reader[44]));
					if(reader.length>45 ) {
						reconMessage.setReportingParty((String)reader[45]);
									}
								}
							}
						}
					}
				}
				String outPutMessage = null;
				outPutMessage = regRepTrioptimaParser.marshallToDtccTemplateString(reconMessage);
				recon.setOutputMessage(outPutMessage);
				recon.setUpdateTimeStamp(current_date);
				recon.setInsertTimeStamp(current_date);
				listRecon.add(recon);
			}
		}
		catch (Exception ex) 
		{
			logger.error("Exception parsing records " + ex.getMessage());
		}
		
		finally {
			if (br != null) {
				br.close();
			}
		}
		
		return listRecon;
	}


	public List<RegRepReconTrioptima> readCRFile(File fileName) throws IOException 
	{
		BufferedReader br = null;
		String line = "";
		String splitter = ",";
		List<RegRepReconTrioptima> listRecon = new ArrayList<RegRepReconTrioptima>();
		Date current_date = new Date();
		
		int i =0;
		try {
			br = new BufferedReader(new FileReader(fileName));
		
			while ((line = br.readLine()) != null ) {
				RegRepReconTrioptima recon = null;
				RegRepTrioptima reconMessage = null;
				recon = new RegRepReconTrioptima();
				reconMessage = new RegRepTrioptima();
				
				Object[]  reader = line.split(splitter);
				i = i+ 1;
				logger.info("Processing line : " + i);
				reconMessage.setPartyId((String)reader[0]);
				reconMessage.setCptyId((String)reader[1]);
				reconMessage.setTradeParty1((String)reader[2]);
				reconMessage.setTradeParty2((String)reader[3]);

				String tradeId = null;
				/*String messageID = null;*/
				
				tradeId = (String)reader[4];
			/*	tradeObject = regRepTradeDao.findByPrimaryKeyNS(tradeId);
				if(null != tradeObject) {
					messageID = tradeObject.getLatestRegRepMessageId();
				}*/
				recon.setTradeID(tradeId);
				reconMessage.setTradeId(tradeId);
				/*	if(null != messageID) 
					{
						recon.setMessageId(messageID);
					} else {*/
						recon.setMessageId("1234-4567-890");
					/*}*/
				recon.setIsActive("1");
				recon.setReportType(Constants.MESSAGE_TYPE_SNAPSHOT_TO);
				recon.setAssetClass("Credit");
				recon.setUsi((String)reader[5]);
				reconMessage.setProductId((String)reader[6]);
				reconMessage.setProductClass((String)reader[7]);
				reconMessage.setBuyer((String)reader[8]);
				reconMessage.setNotionalAmountLeg1(convertStrtoBigDecimal((String)reader[9]));
				reconMessage.setNotionalCurrencyLeg1((String)reader[10]);
				reconMessage.setNotionalAmountLeg2(convertStrtoBigDecimal((String)reader[11]));
				reconMessage.setNotionalCurrencyLeg2((String)reader[12]);
				reconMessage.setEffectiveDate((String)reader[13]);
				reconMessage.setTradeDate((String)reader[14]);
				reconMessage.setTerminationDateLeg1((String)reader[15]);
				recon.setJurisdiction((String)reader[16]);
				reconMessage.setUnderlyingAsset((String)reader[17]);
				reconMessage.setTradeParty2Role((String)reader[18]);
				reconMessage.setTradeParty1Role((String)reader[19]);
				reconMessage.setPaymentFreqMultiplierLeg1((String)reader[19]);
				reconMessage.setFixedRateLeg1(convertStrtoBigDecimal((String)reader[20]));
				
				reconMessage.setAdditionalRepository((String)reader[21]);
				reconMessage.setCollateralized((String)reader[22]);
				reconMessage.setExecutionVenue((String)reader[23]);
				if(reader.length>24 ) {
					reconMessage.setSubmittor((String)reader[24]);
				if(reader.length>25 ) {
					reconMessage.setTradeParty2UsPersonIndicator((String)reader[25]);
				if(reader.length>26 ) {
					reconMessage.setTradeParty2UsPersonIndicator((String)reader[26]);
				if(reader.length>27 ) {
					reconMessage.setSecondaryAssetClass((String)reader[27]);
				if(reader.length>28 ) {
					reconMessage.setOptionStrikePrice((String)reader[28]);
				if(reader.length>29 ) {
					reconMessage.setReportingParty((String)reader[29]);
									}
								}	
							}
						}
					}
				}
				String outPutMessage = null;
				outPutMessage = regRepTrioptimaParser.marshallToDtccTemplateString(reconMessage);
				recon.setOutputMessage(outPutMessage);
				recon.setUpdateTimeStamp(current_date);
				recon.setInsertTimeStamp(current_date);
				listRecon.add(recon);
			}
		}
		catch (Exception ex) 
		{
			logger.error("Exception parsing records" + ex);
		}
		finally {
			if (br != null) {
				br.close();
			}
		}
		return listRecon;
		
	}
	
	public List<RegRepReconTrioptima> readFXFile(File fileName) throws IOException 
	{
		BufferedReader br = null;
		String line = "";
		String splitter = ",";
		
		int i = 0;
		List<RegRepReconTrioptima> listRecon = new ArrayList<RegRepReconTrioptima>();
		Date current_date = new Date();
		
		
		try {
			br = new BufferedReader(new FileReader(fileName));
			
			while ((line = br.readLine()) != null ) {
				Object[]  reader = line.split(splitter);
				{

					i = i+ 1;
					logger.info("Processing line : " + i);
					
					RegRepReconTrioptima recon = null;
					RegRepTrioptima reconMessage = null;
					recon = new RegRepReconTrioptima();
					reconMessage = new RegRepTrioptima();
					
					reconMessage.setPartyId((String)reader[0]);
					reconMessage.setCptyId((String)reader[1]);
					reconMessage.setTradeParty1((String)reader[2]);
					reconMessage.setTradeParty2((String)reader[3]);
					String tradeId = null;
					/*String messageID = null;*/
					
					tradeId = (String)reader[4];
				/*	tradeObject = regRepTradeDao.findByPrimaryKeyNS(tradeId);
					if(null != tradeObject) {
						messageID = tradeObject.getLatestRegRepMessageId();
					}*/
					recon.setTradeID(tradeId);
					reconMessage.setTradeId(tradeId);
						/*if(null != messageID) 
						{
							recon.setMessageId(messageID);
						} else {*/
							recon.setMessageId("1234-4567-890");
						/*}*/
					recon.setIsActive("1");
					recon.setReportType(Constants.MESSAGE_TYPE_SNAPSHOT_TO);
					recon.setAssetClass("ForeignExchange");
					recon.setUsi((String)reader[5]);
					reconMessage.setProductId((String)reader[6]);
					reconMessage.setProductClass((String)reader[7]);
					reconMessage.setNotionalAmountLeg1(convertStrtoBigDecimal((String)reader[8]));
					reconMessage.setNotionalCurrencyLeg1((String)reader[9]);
					reconMessage.setNotionalAmountLeg2(convertStrtoBigDecimal((String)reader[10]));
					reconMessage.setNotionalCurrencyLeg2((String)reader[10]);
					reconMessage.setEffectiveDate((String)reader[12]);
					reconMessage.setTradeDate((String)reader[13]);
					reconMessage.setTerminationDateLeg1((String)reader[14]);
					recon.setJurisdiction((String)reader[15]);
					reconMessage.setTradeParty2Role((String)reader[16]);
					reconMessage.setTradeParty1Role((String)reader[17]);
					reconMessage.setAdditionalRepository((String)reader[18]);
					reconMessage.setCollateralized((String)reader[19]);
					reconMessage.setExecutionVenue((String)reader[20]);
					reconMessage.setOptionStyle((String)reader[21]);
					reconMessage.setFinalSettlementDate((String)reader[22]);
					reconMessage.setSubmittor((String)reader[23]);
					reconMessage.setTradeParty2UsPersonIndicator((String)reader[24]);
					reconMessage.setTradeParty2UsPersonIndicator((String)reader[25]);
					reconMessage.setSecondaryAssetClass((String)reader[26]);
					reconMessage.setFxDeliveryType((String)reader[27]);
					reconMessage.setReportingParty((String)reader[28]);
					
					String outPutMessage = null;
					outPutMessage = regRepTrioptimaParser.marshallToDtccTemplateString(reconMessage);
					recon.setOutputMessage(outPutMessage);
					recon.setUpdateTimeStamp(current_date);
					recon.setInsertTimeStamp(current_date);
					listRecon.add(recon);
				}
			}
		}
		catch (Exception ex) 
		{
			logger.error("Exception parsing records" + ex);
		}
		finally {
			if (br != null) {
				br.close();
			}
		}
		return listRecon;
		
	}
	
	public List<RegRepReconTrioptima> readEQFile(File fileName) throws IOException 
	{
		BufferedReader br = null;
		String line = "";
		String splitter = ",";
		List<RegRepReconTrioptima> listRecon = new ArrayList<RegRepReconTrioptima>();
		Date current_date = new Date();
		
		int i =0;
		try {
			br = new BufferedReader(new FileReader(fileName));
		
			while ((line = br.readLine()) != null ) {
				RegRepReconTrioptima recon = null;
				RegRepTrioptima reconMessage = null;
				recon = new RegRepReconTrioptima();
				reconMessage = new RegRepTrioptima();
				
				Object[]  reader = line.split(splitter);
				i = i+ 1;
				logger.info("Processing line : " + i);
				reconMessage.setPartyId((String)reader[0]);
				reconMessage.setCptyId((String)reader[1]);
				reconMessage.setTradeParty1((String)reader[2]);
				reconMessage.setTradeParty2((String)reader[3]);

				String tradeId = null;
			/*	String messageID = null;*/
				
				tradeId = (String)reader[4];
			/*	tradeObject = regRepTradeDao.findByPrimaryKeyNS(tradeId);
				if(null != tradeObject) {
					messageID = tradeObject.getLatestRegRepMessageId();
				}*/
				recon.setTradeID(tradeId);
				reconMessage.setTradeId(tradeId);
				/*	if(null != messageID) 
					{
						recon.setMessageId(messageID);
					} else {*/
						recon.setMessageId("1234-4567-890");
					/*}*/
				recon.setIsActive("1");
				recon.setReportType(Constants.MESSAGE_TYPE_SNAPSHOT_TO);
				if(fileName.getName().contains("Equity-ES_PSA_CFD"))
				{
					recon.setEquityTemplate("Equity-ES_PSA_CFD");
				}
				if(fileName.getName().contains("Equity-SP"))
				{
					recon.setEquityTemplate("Equity-StructuredProduct");
				}
				if(fileName.getName().contains("Equity-FWD"))
				{
					recon.setEquityTemplate("Equity-FWD");
				}
				if(fileName.getName().contains("Equity-OPT"))
				{
					recon.setEquityTemplate("Equity-OPT");
				}
				if(fileName.getName().contains("Equity-VS"))
				{
					recon.setEquityTemplate("Equity-VS");
				}
				recon.setAssetClass("Equity");
				recon.setUsi((String)reader[5]);
				reconMessage.setProductId((String)reader[6]);
				reconMessage.setProductClass((String)reader[7]);
				reconMessage.setBuyer((String)reader[8]);
				reconMessage.setNotionalAmountLeg1(convertStrtoBigDecimal((String)reader[9]));
				reconMessage.setNotionalCurrencyLeg1((String)reader[10]);
				reconMessage.setEffectiveDate((String)reader[11]);
				reconMessage.setTradeDate((String)reader[12]);
				reconMessage.setTerminationDateLeg1((String)reader[13]);
				recon.setJurisdiction((String)reader[14]);
				reconMessage.setTradeParty2Role((String)reader[15]);
				reconMessage.setTradeParty1Role((String)reader[16]);
				reconMessage.setAdditionalRepository((String)reader[17]);
				reconMessage.setCollateralized((String)reader[18]);
				reconMessage.setExecutionVenue((String)reader[19]);
				reconMessage.setExercise((String)reader[20]);
				reconMessage.setReportingParty((String)reader[21]);
				reconMessage.setTradeParty2UsPersonIndicator((String)reader[22]);
				reconMessage.setTradeParty2UsPersonIndicator((String)reader[23]);
				reconMessage.setSecondaryAssetClass((String)reader[24]);
				if(reader.length > 24)
				{
					reconMessage.setUnderlyingAsset((String)reader[25]);
					if(reader.length > 25)
					{
						reconMessage.setOptionStrikePrice((String)reader[26]);
						if(reader.length > 26)
						{
							reconMessage.setUpfrontFee((String)reader[27]);
							if(reader.length > 27)
							{
								reconMessage.setUpfrontFeeCurr((String)reader[28]);
								if(reader.length > 28)
								{
									reconMessage.setUnderlyingAssetIdentifierType((String)reader[29]);
									if(fileName.getName().contains("ES_PSA_CFD"))
									{
										if(reader.length > 29)
										{
											reconMessage.setUnderlyingAssetNumberOfUnits(convertStrtoBigDecimal((String)reader[30]));
										}
										if(reader.length > 30)
										{
											reconMessage.setReportingParty((String)reader[31]);
										}
									}
									else {
										if(reader.length > 29)
										{
											reconMessage.setReportingParty((String)reader[30]);
										}
									}
								}
							}
						}
					}
				}
				
				String outPutMessage = null;
				outPutMessage = regRepTrioptimaParser.marshallToDtccTemplateString(reconMessage);
				recon.setOutputMessage(outPutMessage);
				recon.setUpdateTimeStamp(current_date);
				recon.setInsertTimeStamp(current_date);
				listRecon.add(recon);
			}
		}
		catch (Exception ex) 
		{
			logger.error("Exception parsing records" + ex);
		}
		finally {
			if (br != null) {
				br.close();
			}
		}
		return listRecon;
		
	}
	
	
	public BigDecimal convertStrtoBigDecimal(String str) throws ParseException 
	{
		if(str.length() > 0) 
		{
			return conversion.parseBigDecimal(str);
		}
		else 
			return null;
		
	}
	
	
}
