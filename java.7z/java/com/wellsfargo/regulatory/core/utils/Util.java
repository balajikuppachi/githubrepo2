package com.wellsfargo.regulatory.core.utils;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

import com.wellsfargo.regulatory.commons.keywords.Constants;

public final class Util
{
	static Logger logger = Logger.getLogger(Util.class);

	/**
	 * @param obj
	 * @return
	 */
	public static final boolean IsNullOrBlank(Object obj)
	{

		if (obj instanceof String)
		{
			return ((String) obj).trim().length() == 0;
		}
		else if (obj == null)
		{
			return true;
		}
		else return false;
	}

	public static String convertListToDelimitedString(List<String> coll, String delim)
	{
		if (CollectionUtils.isEmpty(coll))
		{
			return "";
		}
		StringBuilder sb = new StringBuilder();
		Iterator<String> it = coll.iterator();
		String value = null;
		while (it.hasNext())
		{

			value = it.next();
			if (value == null || "null".equalsIgnoreCase(value)) continue;

			sb.append(value);
			if (it.hasNext())
			{
				sb.append(delim);
			}
		}
		return sb.toString();
	}

	public static final boolean IsNullOrNone(Object obj)
	{
		String s = null;
		if (obj instanceof String)
		{
			s = (String) obj;
			if (Constants.NONE.equalsIgnoreCase(s.trim()))
			{
				return true;
			}
			else if (Constants.NOT_FOUND.equalsIgnoreCase(s.trim()))
			{
				return true;
			}
			return s.trim().length() == 0;
		}
		else if (obj == null)
		{
			return true;
		}
		else return false;
	}

	public static final boolean IsListNullOrEmpty(List<?> obj)
	{

		return (obj == null) || (((List<?>) obj).isEmpty());

	}

	public static String convertListToString(List<String> srcList)
	{
		if (Util.IsListNullOrEmpty(srcList)) return Constants.EMPTY_STRING;

		StringBuffer sb = new StringBuffer();
		for (String s : srcList)
		{
			sb.append(s);
			sb.append(Constants.COMMA);
		}
		sb.delete(sb.length() - 1, sb.length());
		return sb.toString();
	}

	public static String convertListToQuotedString(List<String> srcList)
	{
		if (Util.IsListNullOrEmpty(srcList)) return Constants.EMPTY_STRING;

		StringBuffer sb = new StringBuffer();
		for (String s : srcList)
		{
			sb.append("'" + s + "'");
			sb.append(Constants.COMMA);
		}
		sb.delete(sb.length() - 1, sb.length());
		return sb.toString();
	}

	/**
	 * <p>Checks if two dates are on the same day ignoring time.</p>
	 * 
	 * @param date1
	 * the first date, not altered, not null
	 * @param date2
	 * the second date, not altered, not null
	 * @return true if they represent the same day
	 * @throws IllegalArgumentException
	 * if either date is <code>null</code>
	 */
	public static boolean isSameDay(Date date1, Date date2)
	{
		if (date1 == null || date2 == null)
		{
			throw new IllegalArgumentException("The dates must not be null");
		}
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		return isSameDay(cal1, cal2);
	}

	/**
	 * <p>Checks if two calendars represent the same day ignoring time.</p>
	 * 
	 * @param cal1
	 * the first calendar, not altered, not null
	 * @param cal2
	 * the second calendar, not altered, not null
	 * @return true if they represent the same day
	 * @throws IllegalArgumentException
	 * if either calendar is <code>null</code>
	 */
	public static boolean isSameDay(Calendar cal1, Calendar cal2)
	{
		if (cal1 == null || cal2 == null)
		{
			throw new IllegalArgumentException("The dates must not be null");
		}
		return (cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) && cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR));
	}

	/**
	 * <p>Checks if a date is today.</p>
	 * 
	 * @param date
	 * the date, not altered, not null.
	 * @return true if the date is today.
	 * @throws IllegalArgumentException
	 * if the date is <code>null</code>
	 */
	public static boolean isToday(Date date)
	{
		return isSameDay(date, Calendar.getInstance().getTime());
	}

	/**
	 * <p>Checks if a calendar date is today.</p>
	 * 
	 * @param cal
	 * the calendar, not altered, not null
	 * @return true if cal date is today
	 * @throws IllegalArgumentException
	 * if the calendar is <code>null</code>
	 */
	public static boolean isToday(Calendar cal)
	{
		return isSameDay(cal, Calendar.getInstance());
	}

	/**
	 * yesterday
	 */
	public static Date yesterday()
	{
		Calendar c1 = Calendar.getInstance(); // today
		c1.add(Calendar.DAY_OF_YEAR, -1); // yesterday
		return c1.getTime();
	}

	public static BigDecimal subtractNumberString(String number1, String number2)
	{

		number1 = IsNullOrBlank(number1) ? "0" : number1;
		number2 = IsNullOrBlank(number2) ? "0" : number2;

		BigDecimal number1DEC = new BigDecimal(number1);
		BigDecimal number2DEC = new BigDecimal(number2);

		return number1DEC.subtract(number2DEC);

	}

	public static BigDecimal addNumberString(String number1, String number2)
	{

		number1 = IsNullOrBlank(number1) ? "0" : number1;
		number2 = IsNullOrBlank(number2) ? "0" : number2;

		BigDecimal number1DEC = new BigDecimal(number1);
		BigDecimal number2DEC = new BigDecimal(number2);

		return number1DEC.add(number2DEC);

	}

	public static boolean isNumeric(String number)
	{
		return number.matches("-?\\d+(\\.\\d+)?");
	}
}
