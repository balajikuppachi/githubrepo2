package com.wellsfargo.regulatory.core.services.persister;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.core.driver.main.RegRepComponent;
import com.wellsfargo.regulatory.persister.main.Driver;
import com.wellsfargo.regulatory.persister.main.EodDriver;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class Persister extends RegRepComponent
{
	private Driver persistenceDriver;

	@Autowired
	EodDriver driver;
	
	private static Logger logger = Logger.getLogger(Persister.class.getName());

	public Message<?> persist(Message<?> message) throws MessagingException
	{
		logger.debug("Entering persist() method");

		ReportingContext context 	= null;
		String messageId 			= null;
		String messageType 			= null;
		String errorString 			= null;
		//EodDriver driver			= null;

		if (null == message)
		{
			errorString = "Failed to persist message since incoming message was null";
			logger.error("########## " + errorString);

			return message;
			// throw new MessagingException("Prstr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		if (null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
		{
			messageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);

			errorString = "Failed to persist message since the incoming payload type was invalid or null";
			logger.error("########## " + errorString);

			throw new MessagingException("Prstr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, messageId, null);
		}

		context 	= (ReportingContext) message.getPayload();
		
		//AbstractDriver.setMDCInfo(context, AbstractDriver.Persister);
		
		if (context.isEodRefresh() || context.isEodInsertRefresh()){
			return message;
		}
		messageId 	= context.getMessageId();

		if (null != context.getContextType()) messageType = context.getContextType().type();

		try
		{
			/*
			 * Experimental
			 */
			
			//TODO :: System.gc() is effectively equivalent to Runtime.gc(). System.gc()internally calls Runtime.gc(). 
			//The only difference is System.gc() is a class method where as Runtime.gc() is an instance method. So, System.gc() is more convenient.
			//cleanUpMem(); 
			
			if(null == context.getContextType())
			{
				persistenceDriver.persistPayload(message);
			}
			else
			{		
				persistenceDriver.persist(context);
				
			}
			
			if(PayloadTypeEnum.REG_REP_RESPONSE.equals(context.getContextType()))
			{
				persistenceDriver.persistResponse(message);
			}
		}
		catch (Exception e)
		{
			errorString = "Failed to persist " + messageType + " message with id : " + messageId + " with reason " + e.getMessage();
			logger.error("########## " + errorString);

			dispatchException(message, messageId, errorString, "Prstr:3", ExceptionSeverityEnum.ERROR, context.getSwapTradeId());
			// throw new MessagingException("Prstr:3", ExceptionSeverityEnum.ERROR,
			// ExceptionTypeEnum.REG_REP_ERROR, e.getMessage(), messageId, e);
			message = null;
		}

		logger.debug("Leaving persist() method");

		logger.info("\n @@@@@@ Message with messageId=" + messageId + " has been successfully persisted.");

		return message;
	}

	public Message<?> updateLiveCount(Message<?> message) throws MessagingException
	{
		logger.debug("Entering updateLiveCount() method");
	
		ReportingContext context = null;
		SdrRequest 		 request = null;
		
		if(null == message)
			return message;
		
		context = (ReportingContext) message.getPayload();
		
		//AbstractDriver.setMDCInfo(context, AbstractDriver.Persister);

		if(null == context)
			return message;
		
		request = context.getSdrRequest();
		
		if(null == request)
			return message;
		
		// TODO - Add logging if required ....
		persistenceDriver.updatePortfolioCount(context);
		
		return message;		
	}
	
	public void persistEod(Message<?> message)
	{
		logger.debug("Entering persistEod");
		
		//EodDriver driver 			= null;
		ReportingContext context 	= null;
			
		if(null == message)
		{
			logger.error("######### Null message recieved. Quitting EOD persistence");
			return ;
		}			
		
		if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
		{
			logger.error("######### Invaid payload inside the message. Quitting EOD persistence");
			return ;
		}
		
		//driver 	= new EodDriver();
		context	= (ReportingContext)message.getPayload();
		
		//AbstractDriver.setMDCInfo(context, AbstractDriver.Persister);

		try 
		{
			driver.persist(context);
		} 
		catch (Exception e) 
		{
			logger.error("######### Failed to persist the EOD record for the messge id " + context.getSrcMessageId(), e);
		}	
		
		logger.debug("Exiting persistEod");		
	}
	
	public void persistRecon(Message<?> message) throws MessagingException
	{
		logger.debug("Entering persistTrioptima() method");
	
		ReportingContext context = null;
		SdrRequest 		 request = null;
		
		if(null != message)
		{
			context = (ReportingContext) message.getPayload();
		}
		//AbstractDriver.setMDCInfo(context, AbstractDriver.Persister);

		if(null != context)
		{
			request = context.getSdrRequest();
		}
		
		if(null != request)
		{
			persistenceDriver.updateRecon(context);
		}
		
	}
	
	public void setPersistenceDriver(Driver persistenceDriver)
	{
		this.persistenceDriver = persistenceDriver;
	}

	private void cleanUpMem()
	{

		Runtime runtime = Runtime.getRuntime();

		if (runtime.freeMemory() < runtime.totalMemory() / 100)
		{

			logger.info("Total Memory = " + runtime.totalMemory());
			logger.info("Free  Memory = " + runtime.freeMemory());

			logger.info("*******************************************************************************************");
			logger.info("---------------------- Cleaning Heap Space ------------------------------------------------");
			logger.info("*******************************************************************************************");
			runtime.gc();
		}
	}

}
