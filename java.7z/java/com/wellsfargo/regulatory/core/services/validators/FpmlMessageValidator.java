package com.wellsfargo.regulatory.core.services.validators;

import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_CONF;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_PET;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_RT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_SNAPSHOT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_VALUATION;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.exceptions.ReportingException;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.core.driver.main.RegRepComponent;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class FpmlMessageValidator extends RegRepComponent
{
	@Autowired
	private XmlSchemaValidator validator;

	private static String transparencySchemaFile;
	private static String recordkeepingSchemaFile;
	private static String validateMessage;
	private static String sendInvalidMessage;

	private static Logger logger = Logger.getLogger(FpmlMessageValidator.class.getName());

	public Message<?> validate(Message<?> message) throws ReportingException
	{
		logger.debug("Entering validate() method");

		ReportingContext context 	= null;
		String reportType 			= null;
		String schemaFile 			= null;
		String sdrMessageId 		= null;
		String payload 				= null;
		String errorString 			= null;

		if (!(ConversionUtils.stringToBoolean(validateMessage)))
		{
			errorString = "Quiting validation, since FpML validator is turned off ";
			logger.warn("########## " + errorString);

			return message;
		}

		if (null == message)
		{
			errorString = "Failed to validate the message" + " since " + "incoming message was null";
			logger.warn("########## " + errorString);

			return message;
		}

		context = (ReportingContext) message.getPayload();

		if (null == context)
		{
			sdrMessageId = (String) message.getHeaders().get("sdrMessageId");

			errorString = "Failed to validate the message with messageId --> " + sdrMessageId + " since incoming context was null";
			logger.error("########## " + errorString);

			throw new MessagingException("FpML:validtr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		reportType 		= context.getReportTypes().get(0);
		sdrMessageId 	= context.getMessageId();
		payload 		= context.getPayload();

		if (null == reportType || null == payload)
		{
			sdrMessageId = (String) message.getHeaders().get("sdrMessageId");

			errorString = "Failed to validate the message with messageId --> " + sdrMessageId + " since incoming context was null";
			logger.error("########## " + errorString);

			throw new MessagingException("FpML:validtr:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, context.getSwapTradeId());
		}

		if (MESSAGE_TYPE_RT.equals(reportType))
		{
			schemaFile = transparencySchemaFile;
		}
		else if (MESSAGE_TYPE_PET.equals(reportType) || MESSAGE_TYPE_SNAPSHOT.equals(reportType) || MESSAGE_TYPE_CONF.equals(reportType) || MESSAGE_TYPE_VALUATION.equals(reportType))
		{
			schemaFile = recordkeepingSchemaFile;
		}

		if(null == schemaFile)
		{
			logger.error("######### Failed to load schema file for validation. Quitting validation of the report");
			return message;
		}

		XmlSchemaValidator.setSchemaFile(schemaFile);

		try
		{
			validator.validate(payload, sdrMessageId);
		}
		catch (MessagingException e)
		{
			if(null != e.getMessage() && e.getMessage().contains("cvc-elt.1: Cannot find the declaration of element"))
			{
				//TODO: Temporary fix. Should be fixed in the in the schema name space.
				// For now ignoring
				//errorString = "Schema/Mapping needs to be fixed, please contact support. --> " + sdrMessageId + " for report type : " + reportType + " since " + e.getMessage();
				//logger.error("########## " + errorString);
			}
			else
			{
				errorString = "Failed to validate the fpml message with messageId --> " + sdrMessageId + " for report type : " + reportType + " since " + e.getMessage();
				logger.error("########## " + errorString, e);

				// Commented for now, not to show in UI-alerts.
				//dispatchException(message, sdrMessageId, errorString, "FpML:valdtr:4", ExceptionSeverityEnum.ERROR, context.getSwapTradeId());

				if (!(ConversionUtils.stringToBoolean(sendInvalidMessage)))
				{
					message = null;
				}
			}
		}

		logger.info("\n >>>>>> Successfully validated the report "+reportType+" for message id "+sdrMessageId);
		
		logger.debug("Leaving validate() method");

		return message;
	}

	public static void setTransparencySchemaFile(String transparencySchemaFile)
	{
		FpmlMessageValidator.transparencySchemaFile = transparencySchemaFile;
	}

	public static void setRecordkeepingSchemaFile(String recordkeepingSchemaFile)
	{
		FpmlMessageValidator.recordkeepingSchemaFile = recordkeepingSchemaFile;
	}

	public void setValidator(XmlSchemaValidator validator)
	{
		this.validator = validator;
	}

	public static void setValidateMessage(String validateMessage)
	{
		FpmlMessageValidator.validateMessage = validateMessage;
	}

	public static void setSendInvalidMessage(String sendInvalidMessage)
	{
		FpmlMessageValidator.sendInvalidMessage = sendInvalidMessage;
	}

}
