package com.wellsfargo.regulatory.core.services.validators;

import static com.wellsfargo.regulatory.commons.keywords.Constants.ASSET_CLASS_INTEREST_RATE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.Cancel;
import static com.wellsfargo.regulatory.commons.keywords.Constants.ConfirmationKey;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DRL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.KEY_SEPERATOR;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_CONF;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_RT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_SNAPSHOT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_SNAPSHOT_TO;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_VALUATION;
import static com.wellsfargo.regulatory.commons.keywords.Constants.Novation;
import static com.wellsfargo.regulatory.commons.keywords.Constants.Trade;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;


/**
 * @author 	Amit Rana
 * @date 	08/23/2014
 * @version 1.0
 */

@Component
public class Validator
{
	private static Logger logger = Logger.getLogger(Validator.class.getName());

	@Value("${regRep.esmaL2.validations.enabled}")
	String esmaL2ValidationFlag ;
	
	@Value("${regRep.esmaL2.validations.filter.enabled}")
	String esmaL2ValidationFilterFlag ;
	
	/**
	 * Validates incoming request adds all the validation failures to the Reporting context
	 *
	 * @param message
	 * @return
	 * @throws MessagingException
	 */
	public Message<?> validateSDRRequest(Message<?> message) throws MessagingException
	{
		logger.debug("Entering validateSDRRequest() method");

		if(null == message)
			return message;

		ReportingContext context 	= (ReportingContext) message.getPayload();
		String messageId 			= context.getMessageId();
		
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.Validator);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(context.getMessageId()));

		try
		{
			// KnowledgeBase populateKbase = (KnowledgeBase)
			// RegulatoryBeanFactory.getBean("reportsKBase");
			// StatefulKnowledgeSession enrichKession = populateKbase.newStatefulKnowledgeSession();
			
			//set the flag in context to filter the trades on EsmaValidation failure
			if(Constants.TRUE.equalsIgnoreCase(esmaL2ValidationFilterFlag))
				context.setEnableFilterEsmaL2(true);
			
			KieServices ks 		= KieServices.Factory.get();
			KieContainer kc 	= ks.getKieClasspathContainer();
			KieSession Ksession = kc.newKieSession("reqValidationKsession");

			Ksession.insert(context);
			Ksession.setGlobal("logger", logger);

			/*** all rules placed under commonAgenda will be executed first assetClassAgenda will execute after commonAgenda rules ***/
			Agenda agenda = Ksession.getAgenda();
			if (Constants.TRUE.equalsIgnoreCase(esmaL2ValidationFlag))
			{
				agenda.getAgendaGroup("esmal2GlobalAgenda").setFocus();
			}
			
			agenda.getAgendaGroup("assetclassAgenda").setFocus();
			agenda.getAgendaGroup("commonAgenda").setFocus();

			Ksession.fireAllRules();
			Ksession.dispose();

			/*** START : Testing purpose Only ****/
			if (context.getRulesResultsContext() != null)
			{
				List<ValidationResult> validationResultList = context.getRulesResultsContext().getAlertValidationResultList();

				if (validationResultList != null)
				{
					for (ValidationResult currValidationResult : validationResultList)
					{
						logger.debug("Validation results are: " + currValidationResult.toString());
					}
				}
			}
			/*** END : Testing purpose Only ****/

		}
		catch (Exception e)
		{
			// Tweak until enricher is fixed
			logger.error("########## Unable to validate sdr_request ", e);
			
			throw new MessagingException("vldtr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage(), messageId, e, context.getSwapTradeId());
		}

		logger.debug("Leaving validateSDRRequest() method");

		return message;
	}

	
	
	/*
	 * @SuppressWarnings("unchecked") public Message<?> decideReport(Message<?> message) throws
	 * MessagingException { logger.debug("Entering decideReport() method"); StatefulKnowledgeSession
	 * session = null; ReportingContext context = (ReportingContext)message.getPayload(); String
	 * messageId = context.getMessageId(); try { String key = getDrlKey(message,
	 * Constants.RULE_TYPE_REPORTS); List<String> drlFilesString = cache.getValues(key);
	 * drlDriver.initDrools(drlFilesString, DroolsDriver.SESSION_TYPE_STATEFULL,
	 * ResourceType.DTABLE, context); session = drlDriver.getStateFulKnowledgeSession();
	 * session.execute(CommandFactory.newInsert(context));
	 * session.execute(CommandFactory.newFireAllRules()); session.dispose(); } catch(Exception e){
	 * // Tweak until enricher is fixed
	 * logger.error("########## Unable to determine the report type/(s) ",e); throw new
	 * MessagingException("80R", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR,
	 * e.getMessage(), messageId, e); } logger.debug("Leaving decideReport() method");
	 * logger.debug("Report-Types : "+context.getReportTypes()); return message; }
	 */

	public Message<?> decideReport(Message<?> message) throws MessagingException
	{
		logger.debug("Entering decideReport() method");

		if(null == message)
			return message;

		ReportingContext 	context 		= (ReportingContext) message.getPayload();
		String 				messageId 		= context.getMessageId();
		boolean				isConfirm		= false;
		boolean				isCancel		= false;
		KieSession 			reportKsession	= null;
		KieServices 		ks 				= null;
		KieContainer 		kc				= null;
		String				confString		= null;
		SdrRequest 			request 		= null;
		String sdrAction                    = null;
		KeywordsType keywordsType           = null;
		String tradeAction                  = null;
		
		
		
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.Validator);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(context.getMessageId()));

		/*
		 * This is for refresh services. No need to generate real time messages. 
		 */
		if (context.isEodRefresh() || context.isEodInsertRefresh() || context.isEodValuationRefresh()){
			return message;
		}
		
		try
		{
			/*
			 * If it is historical backload trade no need to report real time messages
			 */
			
			request = context.getSdrRequest();
			
			if (  null!= request && !ReportingDataUtils.intradayRprtCheckForCustomBackload(request))
			{
				logger.info("************* It is custom backload trade and is not intraday reportable *****************");
				return message;
			}
			
		}
		catch (Exception e){
			logger.error("\n##################################################################################################### \nUnable to perform intraday backload check since : " + e.getMessage() + " \n#####################################################################################################");
		}
		
		
		
		/*
		 * ConfirmMessageDecorater sets flag for paper confirms
		 * in isDtccMatrixParticipant
		 *
		 * ConfirmMessageDecorater sets flag for confirms messages
		 * in comment as Confirmation_docId
		 *
		 */

		//isConfirm = context.getSdrRequest().getTrade().getTradeDetail().getDocumentation().isDtccMatrixParticipant();
		confString =  GeneralUtils.resolveIfNull(()->context.getSdrRequest().getTrade().getTradeHeader().getComment(),"isConfirmMessage");
		isConfirm  = StringUtils.contains(confString, ConfirmationKey);
		keywordsType =  GeneralUtils.resolveIfNull(()->context.getSdrRequest().getTrade().getRegulatory().getKeywords(),"keywords");
		sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);
		tradeAction =  GeneralUtils.resolveIfNull(()->context.getSdrRequest().getTrade().getTradeHeader().getTradeAction(),"tradeAction");
		isCancel  = StringUtils.equals( GeneralUtils.resolveIfNull(()->context.getSdrRequest().getTrade().getTradeHeader().getAction(),"Action"), Cancel);
		
		if( !isConfirm && isCancel )
		{
			// TODO : Formulate rules for cancel.
			// Generating RTs for now
			context.getReportTypes().clear();
			context.getReportTypes().add(MESSAGE_TYPE_RT);
			
		}else if(ArrayUtils.contains(Constants.NO_REALTIME_REPORTS_REQD,sdrAction) || ArrayUtils.contains(Constants.NO_REALTIME_REPORTS_REQD,tradeAction))
		{
			logger.info("No Real time messages for this trade since sdrAction or tradeAction is "+(GeneralUtils.IsNull(sdrAction)?sdrAction:tradeAction));
			context.getReportTypes().clear();
			
		}
		
		else {

			try
			{
				if(isConfirm)
				{

					// TODO : Formulate rules for cancel.
					// Generating confirms for now

					context.getSdrRequest().getTrade().getTradeHeader().setComment(confString.split("_")[1]);
					
					// For InterestRates the confirms need to be generated only if the transaction types are Trade or Novation-Trade
					
					if ( ASSET_CLASS_INTEREST_RATE.equals(context.getAssetClass())){
						if ( Trade.equals(context.getLifeCycleEvent()) || Novation.equals(context.getLifeCycleEvent()) ) 
						{
							context.getReportTypes().clear();
							context.getReportTypes().add(MESSAGE_TYPE_CONF);
						}
					} else {
						context.getReportTypes().clear();
						context.getReportTypes().add(MESSAGE_TYPE_CONF);
					}
					
				}else{

					ks = KieServices.Factory.get();
					kc = ks.getKieClasspathContainer();

					reportKsession = kc.newKieSession("reportsKSession");
					reportKsession.insert(context);
					reportKsession.setGlobal("logger", logger);
					reportKsession.fireAllRules();
					reportKsession.dispose();
				}

			}
			catch (Exception e)
			{
				// Tweak until enricher is fixed
				logger.error("########## Unable to determine the report type/(s) ", e);
				throw new MessagingException("80R", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR,e.getMessage(), messageId, e, context.getSwapTradeId());
			}
			finally{
				// Needed in case of debugging  
					//context.getReportTypes().clear();
					//context.getReportTypes().add(Constants.MESSAGE_TYPE_PET);
				
			}
		}

		logger.debug("Leaving decideReport() method");
		logger.debug("Report-Types : " + context.getReportTypes());

		return message;
	}

	@SuppressWarnings("unused")
	private String getDrlKey(Message<?> message, String type) throws Exception
	{
		logger.debug("Entering getDrlKey() method");

		if(null == message)
			return null;

		StringBuilder key = null;
		String jurisdiction = null;
		String repository = null;
		ReportingContext context = (ReportingContext) message.getPayload();
		String eligibilty = context.getRegulatories().get(0);

		// Assumption that by this time reporting context is set and hence
		// context will have only one regulatoryInfo
		jurisdiction = eligibilty.split("_")[0];
		repository = eligibilty.split("_")[1];

		if (StringUtils.isBlank(type) || StringUtils.isBlank(jurisdiction) || StringUtils.isBlank(repository)) throw new Exception("Unable to determine key due to invalid incoming data");

		key = new StringBuilder(DRL + KEY_SEPERATOR);
		key.append(type + KEY_SEPERATOR);
		key.append(jurisdiction.toLowerCase() + KEY_SEPERATOR);
		key.append(repository.toLowerCase());

		logger.debug("Leaving getDrlKey() method");

		return key.toString();
	}

	public Message<?> decideEsmaReport(Message<?> message) throws MessagingException{
		
		logger.debug("Entering decideEsmaReport() method");

		if(null == message)
			return message;

		ReportingContext 	context 		= (ReportingContext) message.getPayload();		
		List<String>		reportTypes		= new ArrayList<String>(4);
		SdrRequest 			request 		= null;
		
		request = context.getSdrRequest();
		
		/*
		 *If it is historical backload, trade need to report only if it is live trade (isSdrLive = true)
		 */
		if ( null != request  && !ReportingDataUtils.eodRprtCheckForCustomBackload(request)){
			logger.info("************* It is custom backload, non-live trade and is not EOD reportable *****************");
			return message;
			
		}

		
		reportTypes.add(MESSAGE_TYPE_SNAPSHOT);
		reportTypes.add(MESSAGE_TYPE_VALUATION);
		
		context.setReportTypes(reportTypes);		
		
		logger.debug("Leaving decideEsmaReport() method");
		logger.debug("Report-Types : " + context.getReportTypes());
		
		

		return message;
	}
	
	
	public Message<?> decideCadEodReport(Message<?> message) throws MessagingException{
		
		logger.debug("Entering decideCadEodReport() method");

		if(null == message)
			return message;

		ReportingContext 	context 		= (ReportingContext) message.getPayload();		
		List<String>		reportTypes		= new ArrayList<String>(4);
		SdrRequest 			request 		= null;
		
		request = context.getSdrRequest();
		
		/*
		 *If it is historical backload, trade need to report only if it is live trade (isSdrLive = true)
		 */
		if ( null != request  && !ReportingDataUtils.eodRprtCheckForCustomBackload(request)){
			logger.info("************* It is custom backload, non-live trade and is not EOD reportable *****************");
			return message;
			
		}

		
		reportTypes.add(MESSAGE_TYPE_SNAPSHOT);
		reportTypes.add(MESSAGE_TYPE_VALUATION);
		
		context.setReportTypes(reportTypes);		
		
		logger.debug("Leaving decideCadEodReport() method");
		logger.debug("Report-Types : " + context.getReportTypes());
		
		

		return message;
	}
	
	
	public Message<?> decideEodReport(Message<?> message) throws MessagingException {
		
		logger.debug("Entering decideEodReport() method");

		if(null == message)
			return message;
		
		ReportingContext 	context 		= (ReportingContext) message.getPayload();
		String 				messageId 		= context.getMessageId();
		KieSession 			reportKsession	= null;
		KieSession 			ValKsession		= null;
		KieServices 		ks 				= null;
		KieContainer 		kc				= null;
		SdrRequest 			request 		= null;
		boolean				isConfirm		= false;
		String				payload		= null;
				
		try
		{
			request = context.getSdrRequest();
			
			/**
			 * If this is confirm message no need to generate the EOD reports.
			 * 
			 */
			
			payload =  context.getPayload();
			if ( null!= payload )
			{
				isConfirm  = StringUtils.contains(payload, ConfirmationKey);
			}
			if (isConfirm)
			{
				return message;
			}
			
			/*
			 * On Demand job to insert the Valuation report for Insert valuation refresh service.
			 */
			if (context.isEodValuationRefresh())
			{
				context.getReportTypes().clear();
				context.getReportTypes().add(Constants.MESSAGE_TYPE_VALUATION);
				return message;
			}
			/*
			 *If it is historical backload, trade need to report only if it is live trade (isSdrLive = true)
			 */
			if ( null != request  && !ReportingDataUtils.eodRprtCheckForCustomBackload(request)){
				logger.info("************* It is custom backload, non-live trade and is not EOD reportable *****************");
				return message;
				
			}
			
		/*	// - This else if block is only for testing of historical data load
			else if(ReportingDataUtils.eodRprtCheckForCustomBackload(request)){
				
				context.getReportTypes().add(Constants.MESSAGE_TYPE_SNAPSHOT);
				context.getReportTypes().add(Constants.MESSAGE_TYPE_VALUATION);
				
				return message;
			}
			*/
		}
		catch (Exception e)
		{
			logger.error("\n##################################################################################################### \nUnable to EOD backload check since : "+e.getMessage() + " \n#####################################################################################################");	
		}
		
		
		
		try
		{
			
			ks = KieServices.Factory.get();
			kc = ks.getKieClasspathContainer();
			
			reportKsession = kc.newKieSession("reportsEodKSession");

			reportKsession.insert(context);
			Agenda agenda = reportKsession.getAgenda();
			agenda.getAgendaGroup("snapshotAgenda").setFocus();
			reportKsession.setGlobal("logger", logger);
			reportKsession.fireAllRules();
			reportKsession.dispose();
		
			ValKsession = kc.newKieSession("reportsEodKSession");

			ValKsession.insert(context);
			Agenda agendaVal = ValKsession.getAgenda();
			agendaVal.getAgendaGroup("valuationAgenda").setFocus();
			ValKsession.setGlobal("logger", logger);
			ValKsession.fireAllRules();
			ValKsession.dispose();
		}
		catch(Exception e)
		{
			logger.error("########## Unable to determine the EOD report type/(s) ", e);
			throw new MessagingException("90R", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					e.getMessage(), messageId, e, context.getSwapTradeId());
		}
		finally
		{
			
		}
		
/*		if (context.isEodRefresh())
		{
			if (context.getReportTypes().contains(MESSAGE_TYPE_VALUATION))
			{
				context.getReportTypes().remove(MESSAGE_TYPE_VALUATION);
			}
		}*/
		
		
		logger.debug("Leaving decideEodReport() method");
		logger.debug("Report-Types : " + context.getReportTypes());
		
		return message;
	}
	
	public Message<?> validateESML2Request(Message<?> message) throws MessagingException
		{
			logger.debug("Entering validateSDRRequest() method");

			if(null == message)
				return message;
			
			ReportingContext 	context 	= (ReportingContext) message.getPayload();
			
			/**
			 * For On Demand job to insert the Valuation report, no need to validate ESMA L2 validations
			 */
			if (context.isEodValuationRefresh())
			{
				return message;
			}
			
			if (Constants.TRUE.equalsIgnoreCase(esmaL2ValidationFlag))
			{	
	
				
				String 				messageId 	= context.getMessageId();
				AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.Validator);
				AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(context.getMessageId()));
				
				//set the flag in context to filter the trades on EsmaValidation failure
				if(Constants.TRUE.equalsIgnoreCase(esmaL2ValidationFilterFlag))
					context.setEnableFilterEsmaL2(true);
					
	
				try
				{
	
					KieServices ks = KieServices.Factory.get();
					KieContainer kc = ks.getKieClasspathContainer();
					KieSession Ksession = kc.newKieSession("esmaL2ValidationKsession");
	
					Ksession.insert(context);
					Ksession.setGlobal("logger", logger);
	
					// ESMA L2 validation rules triggering
	
					Ksession.fireAllRules();
					Ksession.dispose();
	
				}
				catch (Exception e)
				{
	
					logger.error("########## Unable to validate ESMAL2 rules ", e);
					throw new MessagingException("vldtr:esmal2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
							e.getMessage(), messageId, e, context.getSwapTradeId());
	
				}
	
				logger.debug("Leaving validateESML2Request() method");
	
				return message;
			}
			
			logger.info("EsmaL2 validations are disabled");
			
			return message;
		}
	
public Message<?> decideReconReport(Message<?> message) throws MessagingException{
		
		logger.debug("Entering decideReconReport() method");

		if(null == message)
			return message;

		ReportingContext 	context 		= (ReportingContext) message.getPayload();		
		List<String>		reportTypes		= new ArrayList<String>(1);
		SdrRequest 			request 		= null;
		
		request = context.getSdrRequest();
		
		/*
		 *If it is historical backload, trade need to report only if it is live trade (isSdrLive = true)
		 */
		if ( null != request  && !ReportingDataUtils.eodRprtCheckForCustomBackload(request)){
			logger.info("************* It is custom backload, non-live trade and is not EOD reportable *****************");
			return message;
			
		}
		
		if(!GeneralUtils.IsNull(context.getRulesResultsContext()))
		{
			RulesResultsContext rulesContext 		= context.getRulesResultsContext();
			List<ValidationResult> validationResult = rulesContext.getFilterValidationResultList();
			boolean filterBooleanCheck = false;
			
			if(!GeneralUtils.IsNull(validationResult))
			{
				for(ValidationResult filter: validationResult) 
				{
					if(filter.getFieldName().contains("UnSupportedJurisdictionFilter") 
							|| filter.getFieldName().contains("internalTrade") 
								|| filter.getFieldName().contains("reportingParty/reportingJurisdiction"))
						{
							logger.info("************* Not Eligible for Trioptima, Filter: " + filter.getFieldName() + " *****************");
							filterBooleanCheck = true;
						}
				}
				
				if(filterBooleanCheck)
					return message;
			}
		}
		
		reportTypes.add(MESSAGE_TYPE_SNAPSHOT_TO);
		
		context.setReportTypes(reportTypes);		
		
		logger.debug("Leaving decideReconReport() method");
		logger.debug("Report-Types : " + context.getReportTypes());
		return message;
	}

}
