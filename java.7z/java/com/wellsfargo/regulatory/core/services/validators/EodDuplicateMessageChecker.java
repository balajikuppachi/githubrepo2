package com.wellsfargo.regulatory.core.services.validators;

import static com.wellsfargo.regulatory.commons.keywords.Constants.ALL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.cache.IgnoreXpathCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodSubmissionsTrackerDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodPayload;
import com.wellsfargo.regulatory.persister.main.EodDriver;
import com.wellsfargo.regulatory.persister.util.dataSource.ConnectionManager;

public class EodDuplicateMessageChecker extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(EodDuplicateMessageChecker.class.getName());
	
	private static IgnoreXpathCache cache;
	
	@Autowired
	private EodDriver eodDriver;
	
	@Autowired
	private  ConnectionManager manager;
	
	@Autowired
	private RegRepEodSubmissionsTrackerDaoImpl regRepEodSubmissionsTrackerDaoImpl;
	
	static
	{
		cache = IgnoreXpathCache.getInstance();
	}

	public Message<?> checkDuplicate(Message<?> message)
	{
		ReportingContext reportContext 	= null;
		String tradeId 					= null;
		String reportType 				= null;
		List<RegRepEodPayload> eodMessage= null;
		String prevPayload 				= null;
		String prevRepID 				= null;
		String prevLifeCycle			= null;
		String currPayload 				= null;
		List<String> ignoreList 		= null;
		String errorString 				= null;
		boolean allDiffIgnorable 		= false;
		String currentAction 			= null;
		String prevAction 				= null;
		String lifeCycleEventType		= null;
		String jurisdiction 			= null;
		RegRepEodPayload eodPayloadMsg  = null;
		Date prevPayloadDate            = null;
		String status 					= null;
		String tradeType 				= null;
		String sdrAction 				= null;
		KeywordsType keywordsType 		= null;
		
		if(null == message)
			return message;
		
		
		if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
			return message;
		
		reportContext = (ReportingContext)message.getPayload();
		
		try
		{
			tradeId 			= reportContext.getSdrRequest().getTrade().getTradeHeader().getTradeId();
			lifeCycleEventType 	= reportContext.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();
			currentAction 		= reportContext.getSdrRequest().getTrade().getTradeHeader().getAction();
			jurisdiction        = StringUtils.join(reportContext.getCurrJurisdiction(),Constants.COMMA);
			jurisdiction=jurisdiction.contains(Constants.JURISDICTION_CANADA_SHORT)?Constants.JURISDICTION_CAD:jurisdiction;
			status = reportContext.getSdrRequest().getTrade().getTradeHeader().getStatus();
			tradeType = ReportingDataUtils.getKeyWordContents(reportContext.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);
			keywordsType = reportContext.getSdrRequest().getTrade().getRegulatory().getKeywords();
			sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);
			
			if(GeneralUtils.IsNull(reportContext) || GeneralUtils.IsListNullOrEmpty( reportContext.getReportTypes()))
				return message;
			
			// report always will be PET to retrieve ignore xpaths related to Snapshot
			reportType = reportContext.getReportTypes().get(0);
			

			eodMessage = eodDriver.findEodMsgByTradeIdAndReportType(tradeId, reportType, jurisdiction);
			
			Optional<RegRepEodPayload> findFirst = eodMessage.stream().filter(s->s!=null).findFirst();
			eodPayloadMsg=findFirst.isPresent()?findFirst.get():null;

			if(GeneralUtils.IsNull(eodPayloadMsg))
				return message;
			/***Take last available EOD buffer */
			prevAction 	= eodPayloadMsg.getReportType();		
			prevPayload = eodPayloadMsg.getPayload();
			prevLifeCycle = eodPayloadMsg.getLifeCycleEvent();
			prevRepID=eodPayloadMsg.getEodReportId();
			prevPayloadDate=new Date (eodPayloadMsg.getPayloadTimeStamp().getTime());
			
			currPayload = reportContext.getPayload();
			/*
			 * TO handle cancel trades. In case the only change is action type.
			 * This doesn't show in the report; so we need to make a distinction 
			 * here.
			 */
			boolean isBothLCEMatches=StringUtils.equalsIgnoreCase(prevLifeCycle, lifeCycleEventType);
			if(!StringUtils.equalsIgnoreCase(prevAction, currentAction) || !isBothLCEMatches)
			{
				return message;
			}
		
			ignoreList = getIgnoreXpathList(reportContext, reportType);
			allDiffIgnorable = DuplicateMessageChecker.assertEqualReports(prevPayload, currPayload, ignoreList);
			
			/**For Duplicate Dead LCE but some trade terms are changed **/
			if(isBothLCEMatches && !allDiffIgnorable)
				allDiffIgnorable = ReportingDataUtils.hasTradeExpired(lifeCycleEventType, status, false, tradeType, sdrAction);
			
			
			if(allDiffIgnorable )
			{
				String responseStatus=null;
				/**Since this is EOD, we are not checking Response for the Duplicate on the same day**/
				boolean isSameDay=DateUtils.isSameDay(prevPayloadDate,Calendar.getInstance().getTime());
				if(!isSameDay)
				{
					logger.info("Trade identified as duplicate, however checking for the previous response status " + tradeId );
					 responseStatus=regRepEodSubmissionsTrackerDaoImpl.getLastSubmissionStatus(prevRepID, reportType, jurisdiction);
					 isSameDay=(StringUtils.equalsIgnoreCase(Constants.DTCC_RESPONSE_ACK, responseStatus) || StringUtils.equalsIgnoreCase(Constants.MSG_STATUS_WACK, responseStatus));
					
				}
				if(isSameDay)
				{
					errorString = "EodDuplicateReportFilter: This "+reportType +" report has no change when compared to the previous submission for jurisdiction : "+jurisdiction;
					addFilterValidationResult(reportContext, "DupEODRptFilter", "FILTER_EOD_DUP", errorString, "Duplicate");
					reportContext.setFiltered(true);
					reportContext.setDuplicateReport(allDiffIgnorable);
					reportContext.setSubmissionTimestamp(null);
					logger.info(">>>>>>>>>  " + errorString );
				}
			}
		}
		catch(Exception e)
		{
			logger.error("######### Error : ",e);
		}

		return message;
	}

	
	
	private List<String> getIgnoreXpathList(ReportingContext context, String reportType)
	{
		StringBuilder keyBuilder 	= null;
		List<String> xPathList 		= null;
		List<String> xPathListTemp 	= null;
		
		if(null == context || null == context.getFpmlProductType())
			return xPathList;
		
		if(null == reportType)
			return xPathList;
			
		xPathList 	= new ArrayList<String>(10);
		keyBuilder 	= new StringBuilder();
		
		{
			keyBuilder.append(reportType.toUpperCase().trim());
			keyBuilder.append(UNDERSCORE);
			keyBuilder.append(ALL.toUpperCase());
			
			xPathListTemp = cache.getValues(keyBuilder.toString());
			
			if(null != xPathListTemp)
				xPathList.addAll(xPathListTemp);
		}
		
		keyBuilder.delete(0, keyBuilder.length());
		
		{		
		
			keyBuilder.append(reportType.toUpperCase().trim());
			keyBuilder.append(UNDERSCORE);
			keyBuilder.append(context.getFpmlProductType().toUpperCase().trim());
			
			xPathListTemp = cache.getValues(keyBuilder.toString());
			
			if(null != xPathListTemp)				
				xPathList.addAll(xPathListTemp);
		}	
		
		return xPathList;
	}
}
