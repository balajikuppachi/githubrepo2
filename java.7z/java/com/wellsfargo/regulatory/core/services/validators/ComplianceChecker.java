package com.wellsfargo.regulatory.core.services.validators;

import java.util.Date;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse;
import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.cache.ComplianceCache;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.persister.main.Driver;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

@Component
public class ComplianceChecker
{
	@Autowired
	private static Driver persistenceDriver;
	private static Logger logger = Logger.getLogger(ComplianceChecker.class.getName());

	public static void setPersister(Driver persistenceDriver)
	{
		ComplianceChecker.persistenceDriver = persistenceDriver;
	}

	public Message<?> checkComplinace(Message<?> message)
	{
		ReportingContext context 		= null;
		String complianceKey 			= null;
		Integer compIntValue			= -1;
		XMLGregorianCalendar execTime 	= null;
		XMLGregorianCalendar ackTime 	= null;
		boolean compliant 				= false;
		FpMLResponse response 			= null;
		ComplianceCache cache 			= null;
		String wellsReportId 			= null;

		if (null == message || null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
		{
			logger.error("########## Unable to evaluate compliance due to null incoming data");
			//return message;
			return message;
		}

		context 		= (ReportingContext) message.getPayload();
		
		//AbstractDriver.setMDCInfo(context, AbstractDriver.ComplianceChecker);
		
		response 		= context.getResponse();
		wellsReportId 	= context.getSrcMessageId();

		if (null == response)
		{
			logger.error("########## Unable to evaluate compliance since incoming data doesn't have response embedded");
			//return message;
			return message;
		}

		if (null == wellsReportId)
		{
			logger.error("########## Skipping compliance evaluation since incoming response is not for a Wells fargo submission (Source Message-id is NULL)");
			//return message;
			return message;
		}

		complianceKey 	= generateComplainceKey(context);
		execTime 		= getExecutionTime(context);
		ackTime 		= response.getCreationTimestamp();

		if (null == complianceKey)
		{
			logger.error("########## Unable to evaluate compliance since invalid compliance key generated as " + complianceKey);
			//return message;
			return message;
		}

		cache 			= ComplianceCache.getInstance();
		compIntValue 	= cache.getValue(complianceKey);
		compliant 		= isCompliant(ackTime, execTime, compIntValue);

		if (compliant)
		{
			updateComplianceStatus(wellsReportId);
		}

		//return message;
		return message;
	}

	private String generateComplainceKey(ReportingContext context)
	{
		String regKey 				= null;
		Set<String> regulatories 	= null;
		FpMLResponse response 		= null;

		if (null == context || null == context.getResponse())
		{
			logger.error("########## Unable to generate compliance key due to invalid incoming data");
			return regKey;
		}

		response 		= context.getResponse();
		regulatories 	= context.getRegulatories().keySet();

		if (null == regulatories || regulatories.size() < 1)
		{
			logger.error("########## Unable to generate compliance key due to invalid regulatory data");
			return regKey;
		}

		regKey = regulatories.iterator().next();
		regKey = regKey + Constants.UNDERSCORE + response.getParentreportType();

		logger.debug("Sucessfully generated compliance key as " + regKey);

		return regKey;
	}

	private XMLGregorianCalendar getExecutionTime(ReportingContext context)
	{
		XMLGregorianCalendar executionTimeStamp = null;

		if (null == context) return executionTimeStamp;

		if ("Trade".equals(context.getLifeCycleEvent()))
		{
			executionTimeStamp = context.getExecutionTimestamp();
		}
		else
		{
			// TODO: we should fetch post trade time stamp here
			// Keeping it Exceution timestamp for now
			executionTimeStamp = context.getExecutionTimestamp();
		}

		return executionTimeStamp;
	}

	private boolean isCompliant(XMLGregorianCalendar ackTime, XMLGregorianCalendar execTime, Integer timeDiff)
	{
		boolean compliant 	= false;
		Integer dateDiff 	= null;
		Date ackDate 		= null;
		Date execDate 		= null;

		if (null == ackTime || null == execTime || null == timeDiff)
		{
			logger.error("########## Unable to evaluate compliance due to invalid incoming dates or time difference");
			return compliant;
		}

		ackDate 	= CalendarUtils.toDate(ackTime);
		execDate 	= CalendarUtils.toDate(execTime);
		dateDiff 	= CalendarUtils.dateDifference(ackDate, execDate);

		if (null != dateDiff && dateDiff < timeDiff) 
			compliant = true;

		return compliant;
	}

	private void updateComplianceStatus(String regRepMessageId)
	{
		persistenceDriver.updateComplianceStatus(regRepMessageId, true);
		logger.debug("Updtaed compliance details to true");
	}
	
	/*
	public static void main(String[] args) {
		ComplianceChecker c = new ComplianceChecker();
		
		
		Date dob=null;
		Date dob1=null;
		DateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		try {
			dob=df.parse( "2015-04-28 12:05:11.913" );
			dob1=df.parse( "2015-04-28 12:05:16.0");
			GregorianCalendar cal = new GregorianCalendar();
			
			cal.setTime(dob);
			XMLGregorianCalendar xmlDate2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), dob.getHours(),dob.getMinutes(),dob.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, cal.getTimeZone().LONG).normalize();
			//XMLGregorianCalendar xmlDate3 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH),dob.getHours(),dob.getMinutes(),dob.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
			System.out.println(xmlDate2);
						
			cal.setTime(dob1);
			XMLGregorianCalendar xmlDate4 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), dob1.getHours(),dob1.getMinutes(),dob1.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, cal.getTimeZone().LONG).normalize();
			//XMLGregorianCalendar xmlDate3 = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH),dob.getHours(),dob.getMinutes(),dob.getSeconds(),DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
			System.out.println(xmlDate4);
			
			//System.out.println(xmlDate3);
			c.isCompliant(xmlDate4, xmlDate2, 100);
		} catch (ParseException | DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	*/
}
