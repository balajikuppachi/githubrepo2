package com.wellsfargo.regulatory.core.services.validators;

import java.io.IOException;
import java.net.URL;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

// import org.apache.camel.converter.jaxp.StringSource;
import org.apache.log4j.Logger;
import org.springframework.xml.transform.StringSource;
import org.xml.sax.SAXException;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class XmlSchemaValidator
{
	private static String schemaFileLocation;

	private static Logger logger = Logger.getLogger(XmlSchemaValidator.class.getName());

	/**
	 * @param schemaFile
	 * the schemaFile to set
	 */
	public static void setSchemaFile(String schemaFileLocation)
	{
		XmlSchemaValidator.schemaFileLocation = schemaFileLocation;
	}

	public boolean validate(String xml, String messageId) throws MessagingException
	{
		URL schemaFile = null;
		Schema schema = null;
		ClassLoader loader = null;
		boolean valid = false;
		SchemaFactory schemaFactory = null;
		Source xmlFile = null;
		Validator validator = null;
		String errorString = null;

		if (null == xml || null == messageId)
		{
			errorString = "Failed to validate the message with messageId --> " + messageId + " since " + "incoming " + "data was null";
			logger.error("########## " + errorString);

			throw new MessagingException("schma:validtr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, messageId, null);
		}

		try
		{
			loader = getClass().getClassLoader();

			if (loader == null)
			{
				schemaFile = ClassLoader.getSystemResource(schemaFileLocation);  // A system class.
			}
			else
			{
				schemaFile = loader.getResource(schemaFileLocation);
			}

			xmlFile = new StringSource(xml);
			schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			schema = schemaFactory.newSchema(schemaFile);
			validator = schema.newValidator();

			validator.validate(xmlFile);
			valid = true;

			logger.info("\n >>>> Message with messageId : " + messageId + " was successfully validated against schema " + schemaFileLocation);

		}
		catch (SAXException | IOException e)
		{
			errorString = "Failed to validate the message with messageId --> " + messageId + " since " + e.getMessage();
			logger.error("########## " + errorString, e);

			throw new MessagingException("schma:validtr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, messageId, e, null);
		}

		return valid;
	}

}
