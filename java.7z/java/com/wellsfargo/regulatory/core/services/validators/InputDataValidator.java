package com.wellsfargo.regulatory.core.services.validators;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.exceptions.ReportingException;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class InputDataValidator extends FilterRulesContextMgr
{
	@Autowired
	private XmlSchemaValidator validator;

	private static String schemaFile;
	private static String validateMessage;

	private static Logger logger = Logger.getLogger(InputDataValidator.class.getName());

	public void setSchemaFile(String schemaFile)
	{
		InputDataValidator.schemaFile = schemaFile;
	}

	public void setValidator(XmlSchemaValidator validator)
	{
		this.validator = validator;
	}

	public void setValidateMessage(String validateMessage)
	{
		InputDataValidator.validateMessage = validateMessage;
	}

	public Message<?> validate(Message<?> message) throws ReportingException
	{
		ReportingContext context = null;
		String payload = null;
		String msgId = null;
		String errorString = null;

		if (null == message)
		{
			errorString = "Failed to validate the message since " + "incoming " + "data was null";
			logger.error("########## " + errorString);

			return message;
			//throw new MessagingException("IP:validtr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.INPUT_DATA_ERROR, errorString);
		}

		context = (ReportingContext) message.getPayload();

		if (null == context)
		{
			msgId = (String) message.getHeaders().get("sdrMessageId");

			errorString = "Failed to validate the message with messageId --> " + msgId + " since " + "incoming " + "context was null";
			logger.error("########## " + errorString);

			throw new MessagingException("IP:validtr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.INPUT_DATA_ERROR, 
					errorString, msgId, null);
		}

		if (!(ConversionUtils.stringToBoolean(validateMessage)))
		{
			errorString = "Quiting validation, since input data validator is turned off ";
			logger.warn("########## " + errorString);
			
			setReportingStatus(context, null);			
			return message;
		}
		
		payload = context.getPayload();
		msgId = context.getMessageId();

		XmlSchemaValidator.setSchemaFile(schemaFile);

		try
		{
			validator.validate(payload, msgId);
			setReportingStatus(context, null);
		}
		catch (MessagingException e)
		{
			errorString = "Failed to validate reg rep message with messageId --> " + msgId + " since " + e;
			logger.error("########## " + errorString, e);

			setReportingStatus(context, e);
		}

		return message;
	}

	private void setReportingStatus(ReportingContext context, Exception e){

		ReportingStatus 		reportingStatus 	= null;
		RulesResultsContext		rulesResultCntxt	= null;

		if(null != e){

			addFilterValidationResult(context, "IpSchemaValid", "Invalid Schema", e.getMessage(), "VALIDATION");
		    context.setInvalid(true);

		}else{

			reportingStatus = new ReportingStatus();
			reportingStatus.setReportStatus(true);
			context.setReportingStatus(reportingStatus);

			rulesResultCntxt = new RulesResultsContext();
			rulesResultCntxt.setResultsSource("SDR_REQ");
			context.setRulesResultsContext(rulesResultCntxt);
		}

	}

}
