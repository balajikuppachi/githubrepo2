package com.wellsfargo.regulatory.core.services.validators;

import static com.wellsfargo.regulatory.commons.keywords.Constants.ALL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.XMLUnit;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.cache.IgnoreXpathCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepPayloadDao;
import com.wellsfargo.regulatory.persister.dao.RegRepResponseDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepPayload;

public class DuplicateMessageChecker extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(DuplicateMessageChecker.class.getName());
	
	private static IgnoreXpathCache cache;
	private RegRepMessageDao msgDao;
	private RegRepPayloadDao pyldDao;
	private String checkDuplicate;
	private RegRepResponseDao responseDao;
	
	static
	{
		cache = IgnoreXpathCache.getInstance();
	}

	public Message<?> checkDuplicate(Message<?> message)
	{
		ReportingContext reportContext 	= null;
		String tradeId 					= null;
		String reportType 				= null;
		RegRepMessage regRepMessage		= null;
		RegRepPayload regRepPayload 	= null;
		String currRpt 					= null;
		String prevRpt 					= null;
		List<String> ignoreList 		= null;
		String errorString 				= null;
		boolean allDiffIgnorable 		= false;
		String currentAction 			= null;
		String prevAction 				= null;
		String lifeCycleEventType		= null;
		String prevlifeCycleEventType	= null;
		String status 					= null;
		String tradeType 				= null;
		String sdrAction 				= null;
		KeywordsType keywordsType 		= null;
		Date prevPayloadDate			= null;
		
		
				
		if(null == message)
			return message;
		
		if(!ConversionUtils.stringToBoolean(checkDuplicate))
		{
			logger.info("Duplicate check turned off. Ignoring duplicates....");
			return message;
		}
		
		if(null == message.getPayload() || !(message.getPayload() instanceof ReportingContext))
			return message;
		
		reportContext = (ReportingContext)message.getPayload();
		
		//AbstractDriver.setMDCInfo(reportContext, AbstractDriver.DuplicateMessageChecker);

		try
		{
			tradeId 			= reportContext.getSdrRequest().getTrade().getTradeHeader().getTradeId();
			lifeCycleEventType 	= reportContext.getSdrRequest().getTrade().getTradeHeader().getLifeCycle().getEventType();
			currentAction 		= reportContext.getSdrRequest().getTrade().getTradeHeader().getAction();
			status = reportContext.getSdrRequest().getTrade().getTradeHeader().getStatus();
			tradeType = ReportingDataUtils.getKeyWordContents(reportContext.getSdrRequest().getTrade().getRegulatory().getKeywords(), Constants.TRADE_TYPE);
			keywordsType = reportContext.getSdrRequest().getTrade().getRegulatory().getKeywords();
			sdrAction = ReportingDataUtils.getKeyWordContents(keywordsType, Constants.SDR_ACTION_DERIVED_EVENT);
			
		}
		catch(Exception e)
		{
			logger.error(e);
			return message;
		}
		
		if(null == reportContext.getReportTypes() || reportContext.getReportTypes().size() < 1 || null == reportContext.getPayload())
			return message;
		
		reportType = reportContext.getReportTypes().get(0);
		
		if(null == reportType || null == tradeId || null == msgDao)
			return message;
						
		regRepMessage = msgDao.findByTradeIdAndReportTypeNS(tradeId, reportType,  reportContext.getCurrJurisdiction().iterator().next());
		
		if(null == regRepMessage || null == regRepMessage.getRegRepMessageId() || null == pyldDao)
			return message;
		
		prevAction 	= regRepMessage.getActionType();	
		prevlifeCycleEventType 	= regRepMessage.getLifecycleEventType();	
				
		/*
		 * TO handle cancel trades. In case the only change is action type.
		 * This doesn't show in the report; so we need to make a distinction 
		 * here. 
		 * 
		 * Check for the same LCE or not.
		 */
		boolean isBothLCEMatches=StringUtils.equalsIgnoreCase(prevlifeCycleEventType, lifeCycleEventType);
		if(!StringUtils.equalsIgnoreCase(prevAction, currentAction) || !isBothLCEMatches)
		{
			return message;
		}
		
		regRepPayload = pyldDao.findPayloadByRegRepMessageId(regRepMessage.getRegRepMessageId());
		
		if(null == regRepPayload || null == regRepPayload.getPayload())
			return message;
		
		ignoreList = getIgnoreXpathList(reportContext, reportType);
		
		prevRpt = regRepPayload.getPayload();
		currRpt = reportContext.getPayload();
		prevPayloadDate=new Date (regRepPayload.getRegRepPayloadTimestamp().getTime());

		try
		{
			allDiffIgnorable = assertEqualReports(prevRpt, currRpt, ignoreList);
			
			/**For Duplicate Dead LCE but some trade terms are changed **/
			if(isBothLCEMatches && !allDiffIgnorable)
				allDiffIgnorable = ReportingDataUtils.hasTradeExpired(lifeCycleEventType, status, false, tradeType, sdrAction);

			if(allDiffIgnorable)
			{
				boolean isSameDay=DateUtils.isSameDay(prevPayloadDate,Calendar.getInstance().getTime());
				
				if(!isSameDay)
				{
					logger.info("Trade identified as duplicate, however checking for the previous response status " + tradeId );
					String responseStatus = responseDao.getLastSubmissionStatus(regRepMessage.getRegRepMessageId());
					isSameDay=(StringUtils.equalsIgnoreCase(Constants.DTCC_RESPONSE_ACK, responseStatus) || StringUtils.equalsIgnoreCase(Constants.MSG_STATUS_WACK, responseStatus));
				}
				if(isSameDay)
				{
					errorString = "DuplicateReportFilter: This "+reportType +" report has no change when compared to the previous submission";
					addAlertValidationResult(reportContext, "DupRptFilter", "FILTER_09", errorString, "Duplicate");
					//context.setFiltered(true);
					reportContext.setDuplicateReport(allDiffIgnorable);
					
					//sdf = new SimpleDateFormat("dd/MM/yyyy");
					//context.setSubmissionTimestamp(sdf.parse("01/01/1800"));
					
					reportContext.setSubmissionTimestamp(null);
					logger.info(">>>>>>>>>  " + errorString );
				}
			}
			
		}
		catch(Exception e)
		{
			logger.error("######### Error : ",e);
		}

		return message;
	}

	public static boolean assertEqualReports(String expectedRpt, String actualRpt, List<String> ignoreList) throws Exception 
	{
		String xPath;
		boolean xPathIgnored = false;

		XMLUnit.setIgnoreWhitespace(true);
		XMLUnit.setIgnoreAttributeOrder(true);

		DetailedDiff diff = new DetailedDiff(XMLUnit.compareXML(expectedRpt, actualRpt));

		@SuppressWarnings("unchecked")
		List<Difference> allDifferences = diff.getAllDifferences();	       
		//System.out.println("Differences found: "+ diff.toString()+" : All Differences "+allDifferences.size());	        

		for(Difference difference : allDifferences )
		{
			xPath 			= difference.getControlNodeDetail().getXpathLocation();
			xPathIgnored 	= false;

			//System.out.println(xPath);

			for(String ignoreXapth : ignoreList)
			{
				if(ignoreXapth.equalsIgnoreCase(xPath))
				{
					logger.debug("Ignoring Xpath "+xPath+" for duplicate report check.");					
					xPathIgnored = true;
					break;
				}
			}
			
			if(!xPathIgnored)
				break;
		}
		
		return xPathIgnored;
	}
	
	private List<String> getIgnoreXpathList(ReportingContext context, String reportType)
	{
		StringBuilder keyBuilder 	= null;
		List<String> xPathList 		= null;
		List<String> xPathListTemp 	= null;
		
		if(null == context || null == context.getFpmlProductType())
			return xPathList;
		
		if(null == reportType)
			return xPathList;
			
		xPathList 	= new ArrayList<String>(10);
		keyBuilder 	= new StringBuilder();
		
		{
			keyBuilder.append(reportType.toUpperCase().trim());
			keyBuilder.append(UNDERSCORE);
			keyBuilder.append(ALL.toUpperCase());
			
			xPathListTemp = cache.getValues(keyBuilder.toString());
			
			if(null != xPathListTemp)
				xPathList.addAll(xPathListTemp);
		}
		
		keyBuilder.delete(0, keyBuilder.length());
		
		{		
			keyBuilder.append(reportType.toUpperCase().trim());
			keyBuilder.append(UNDERSCORE);
			keyBuilder.append(context.getFpmlProductType().toUpperCase().trim());
			
			xPathListTemp = cache.getValues(keyBuilder.toString());
			
			if(null != xPathListTemp)				
				xPathList.addAll(xPathListTemp);
		}	
		
		return xPathList;
	}
	

	public void setMsgDao(RegRepMessageDao msgDao) {
		this.msgDao = msgDao;
	}
	
	public void setPyldDao(RegRepPayloadDao pyldDao) {
		this.pyldDao = pyldDao;
	}
	
	public void setCheckDuplicate(String checkDuplicate) {
		this.checkDuplicate = checkDuplicate;
	}

	public void setResponseDao(RegRepResponseDao responseDao) {
		this.responseDao = responseDao;
	}

	
}
