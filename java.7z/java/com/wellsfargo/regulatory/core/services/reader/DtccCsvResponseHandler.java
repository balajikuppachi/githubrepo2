package com.wellsfargo.regulatory.core.services.reader;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class DtccCsvResponseHandler
{
	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());

	public void handleResponse(Message<?> inMessage) throws MessagingException
	{
		logger.info("Entering handleResponse() method ");

		Object ipMessage = null;
		ipMessage = inMessage.getPayload();

		String responseMsg = null;

		if (ipMessage instanceof String)
		{
			responseMsg = (String) ipMessage;
			logger.info("########## DTCC Response Received : \n " + StringUtils.substring(responseMsg, 0, 1000));
			logger.info("########## THIS MESSAGE IS NOT A RESPONSE TO WELLS FpML SUBMISSION PLATFORM");
		}

		logger.info("Leaving handleResponse() method ");

	}

}
