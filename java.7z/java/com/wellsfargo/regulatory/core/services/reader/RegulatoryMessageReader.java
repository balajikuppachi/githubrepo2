package com.wellsfargo.regulatory.core.services.reader;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.FileUtils;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */
@Component
public class RegulatoryMessageReader
{
	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());

	public Message<?> readMessage(Message<?> message) throws MessagingException
	{
		logger.info("Message readMessage");

		// Clear MDC
		AbstractDriver.clearContextInformation();

		Object ipMessage 		= null;
		File srcFile 			= null;
		String errorString 		= null;
		String sdrMessageId 	= null;
		String origPayload 		= null;
		ReportingContext repContext = null;
		Message<?> messageOut 	= null;
		String msgSrc 			= null;

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);

			return message;
			// throw new MessagingException("Reader-1", ExceptionSeverityEnum.ERROR,
			// ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId);
		}

		sdrMessageId 	= (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
		ipMessage 		= message.getPayload();

		if (null == ipMessage)
		{
			errorString = "Null incoming request ";
			logger.error("########## " + errorString);

			throw new MessagingException("Reader-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
		}
		else if (ipMessage instanceof File)
		{
			srcFile = ((File) ipMessage);

			try
			{
				origPayload = org.apache.commons.io.FileUtils.readFileToString(srcFile);

				// - Remove the src file
				FileUtils.deleteAFile(srcFile);
			}
			catch (IOException e)
			{
				errorString = "Failed to read the payload ";
				logger.error("########## " + errorString);

				throw new MessagingException("Reader-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
			}
		}
		else
		{
			errorString = "Failed to read invalid incoming message type";
			logger.error("########## " + errorString);

			throw new MessagingException("Reader-5", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		msgSrc = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_TYPE);

		logger.info("@@@@ Message-id :" + StringUtils.trimToEmpty(sdrMessageId));
		logger.info("@@@@ Message-source : <<<<<<<<< " + StringUtils.trimToEmpty(msgSrc) + " >>>>>>>>>");
		logger.debug("@@@@ Message-OrigPayload : \n" + StringUtils.trimToEmpty(origPayload));

		repContext = ReportingContext.getInstance();
		repContext.setPayload(origPayload);
		repContext.setMessageId(sdrMessageId);
		repContext.setMessageSource(msgSrc);
		
		// START : Setting the MDC from the Context
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.RegulatoryMessageReader);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(repContext.getMessageId()));
		//AbstractDriver.setMDCInfo(repContext, AbstractDriver.RegulatoryMessageReader);
		// END : Setting the MDC from the Context

		// messageOut =
		 //MessageBuilder.withPayload(origPayload).copyHeadersIfAbsent(message.getHeaders()).build();
		messageOut = MessageBuilder.withPayload(repContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.info("@@@@ Message has been sucessfully read !");

		return messageOut;
	}

}
