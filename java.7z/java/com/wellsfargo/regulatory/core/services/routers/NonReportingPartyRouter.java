/**
 *
 */
package com.wellsfargo.regulatory.core.services.routers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.router.AbstractMessageRouter;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;

/**
 * @author u337814
 */
@Deprecated
public class NonReportingPartyRouter extends AbstractMessageRouter
{

	private MessageChannel errorChannel;
	private MessageChannel jurisdictionEnricherChannel;
	private MessageChannel nrpflowChannel;
	private MessageChannel defaultOutputChannel;

	/*
	 * (non-Javadoc)
	 * @see
	 * org.springframework.integration.router.AbstractMessageRouter#determineTargetChannels(org.
	 * springframework.integration.Message)
	 */
	@Override
	protected Collection<MessageChannel> determineTargetChannels(Message<?> message)
	{

		String errorString;
		ReportingContext cntxt;
		List<MessageChannel> channels;
		SdrRequest request;
		RegulatoryType regulatory;
		List<ReportingEligibilityType> eligibilityList;
		UsThemEnum reportingParty;
		boolean nrp = true;

		channels = new ArrayList<MessageChannel>(1);

		if (null == message)
		{

			errorString = "Null incoming object";
			logger.error("########## " + errorString);

			channels.add(errorChannel);
			return channels;
		}

		cntxt = (ReportingContext) message.getPayload();

		if (null == cntxt)
		{

			errorString = "Null incoming context";
			logger.error("########## " + errorString);

			channels.add(errorChannel);
			return channels;
		}

		request = cntxt.getSdrRequest();

		if (null == request)
		{

			errorString = "Null incoming sdr request";
			logger.error("########## " + errorString);

			channels.add(errorChannel);
			return channels;
		}

		regulatory = request.getTrade().getRegulatory();

		if (null == regulatory)
		{

			errorString = "Null incoming Regulatory";
			logger.error("########## " + errorString);

			channels.add(errorChannel);
			return channels;
		}

		eligibilityList = regulatory.getReportingEligibility();

		if (null == eligibilityList)
		{

			errorString = "Null incoming Reporting Eligiilities";
			logger.error("########## " + errorString);

			channels.add(errorChannel);
			return channels;
		}

		for (ReportingEligibilityType eligibility : eligibilityList)
		{

			reportingParty = eligibility.getReportingParty();

			if (!UsThemEnum.THEM.equals(reportingParty))
			{

				nrp = false;
				break;
			}
		}

		if (nrp)
		{

			channels.add(nrpflowChannel);
		}
		else
		{

			channels.add(jurisdictionEnricherChannel);
		}

		return channels;
	}

	public void setErrorChannel(MessageChannel errorChannel)
	{
		this.errorChannel = errorChannel;
	}

	public void setJurisdictionEnricherChannel(MessageChannel jurisdictionEnricherChannel)
	{
		this.jurisdictionEnricherChannel = jurisdictionEnricherChannel;
	}

	public void setNrpflowChannel(MessageChannel nrpflowChannel)
	{
		this.nrpflowChannel = nrpflowChannel;
	}

	public void setDefaultOutputChannel(MessageChannel defaultOutputChannel)
	{
		this.defaultOutputChannel = defaultOutputChannel;
	}

}
