/**
 *
 */
package com.wellsfargo.regulatory.core.services;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.factory.FactoryException;
import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

/**
 * @author u337814
 */
@Component
public class DiscardSvc
{

	private static Logger logger = Logger.getLogger(DiscardSvc.class.getName());

	public void discard(Message<?> message)
	{

		// START : Setting the MDC from the Context
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.DiscardSVC);
		// END : Setting the MDC from the Context

		if(null == message)
			return;

		// Simply discarding the message.
		logger.info("<<<<<<<<< DISCARD COMPONENT : End-Of-Message flow on the current route ! >>>>>>>>> ");
		
		try 
		{
			//printDatabaseProperties();
			logStatistics();
		} 
		catch (FactoryException e) 
		{
			logger.error("<<<<<<<<< UNABLE to retrieve DB statistics >>>>>>>>> ");
		}
		
		AbstractDriver.clearContextInformation();
	}

	
	protected void logStatistics()  throws FactoryException 
	{
		org.apache.commons.dbcp.BasicDataSource ds = (org.apache.commons.dbcp.BasicDataSource)RegulatoryBeanFactory.getBean("dataSource"); // dataSourceForSpring --> dataSource

		if (logger.isInfoEnabled()) 
		{
			logger.info("\n>>>>>>> DB-STATS : DB URL: " + ds.getUrl() + ", Active: " + ds.getNumActive() + ", MaxActive: " + ds.getMaxActive() + ", Idle: " + ds.getNumIdle() + ", MaxIdle: " + ds.getMaxIdle() );
		}
	}
	
	
	/*
	protected void logStatistics()  throws FactoryException 
	{
		HikariDataSource dataSource = (HikariDataSource)RegulatoryBeanFactory.getBean("dataSource");

		if (logger.isInfoEnabled()) 
		{
			logger.info("\n>>>>>>> DB-STATS : DB URL: " + dataSource.getJdbcUrl() );
		}
	}
	*/
	
}
