package com.wellsfargo.regulatory.core.services.response;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrResponse.MessageType;
import com.wellsfargo.regulatory.commons.bo.sdrResponse.RegRepResponse;
import com.wellsfargo.regulatory.commons.bo.sdrResponse.ResponseCodeEnum;
import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;

/**
 * This process prepares Response to be sent to front office persists validation errors in
 * RegRepException table persists response payload in RegRepPayload table' passes message context to
 * publisher to send response to front office
 *
 * @author u373071
 *
 * @author - u337814
 * Modified to publish DTCC and affiliate responses
 */

public class RegRepRespProcessorimpl implements RegRepRespProcessor
{
	private Marshaller marshaller;

	@SuppressWarnings("unused")
	private Unmarshaller unmarshaller;
	private String tempFileLoc;
	private static AtomicLong sequence = new AtomicLong(1);
	
	@Autowired
	MailSenderService mailSenderService;
	
	@Value("${regRep.filter.validation.mail.enabled}")
	String emailFlag;  

	private static Logger logger = Logger.getLogger(RegRepRespProcessorimpl.class.getName());

	@Override
	public Message<?> process(Message<?> message) throws MessagingException
	{
		String sdrMessageId 						= null;
		String errorString 							= null;
		SdrRequest sdrRequest						= null;
		ReportingContext reportingContext 			= null;
		RulesResultsContext rulesResultsContext 	= null;
		RegRepResponse regRepResponse 				= null;
		List<ValidationResult> altertValidationList = null;
		List<ValidationResult> filterValidationList = null;
		String correlationId 						= null;
		List<MessageType> messageTypeList 			= null;
		String reportType 							= null;
		String assetClass                           = null;
		
		logger.debug("Entering RegRepRespProcessorimpl");

		if (null == message)
		{
			errorString = "Null incoming object. RegRepRespProcessorimpl failed";
			logger.debug("########## " + errorString);

			return message;
			// throw new MessagingException("RespProcessor:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		if (!(message.getPayload() instanceof ReportingContext))
		{
			errorString 	= "Invalid incoming object type. Response processing failed";
			sdrMessageId 	= (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			logger.debug("########## " + errorString);

			return message;
			// throw new MessagingException("RespProcessor:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId);
		}

		reportingContext = (ReportingContext) message.getPayload();
		
		//AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.RegRepRespProcessor);
		//AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(reportingContext.getMessageId()));
		AbstractDriver.setMDCInfo(reportingContext, AbstractDriver.RegRepRespProcessor);

		if (null == reportingContext || null == reportingContext.getPayload())
		{
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			errorString = "Invalid incoming payload. Response processing  failed";
			logger.debug("########## " + errorString);

			return message;
			// throw new MessagingException("RespProcessor:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId);
		}

		sdrMessageId 		= reportingContext.getMessageId();
		rulesResultsContext = reportingContext.getRulesResultsContext();
		sdrRequest 			= reportingContext.getSdrRequest();
				
		if (sdrRequest != null)
		{
			correlationId = sdrRequest.getMessageId();
			assetClass =    sdrRequest.getAssetClass();
		}
		else if(null != message.getHeaders() && null != message.getHeaders().get(Constants.RESPONSE_MESSAGE_ID) && message.getHeaders().get(Constants.RESPONSE_MESSAGE_ID) instanceof String)
		{
			correlationId = (String)message.getHeaders().get(Constants.RESPONSE_MESSAGE_ID);
		}
		else
		{
			correlationId = sdrMessageId;
		}

		regRepResponse = new RegRepResponse();
		regRepResponse.setMessageId(correlationId);
		
		if(!GeneralUtils.IsListNullOrEmpty(reportingContext.getRegulatories()))
		{
			regRepResponse.setReportingJurisdiction(reportingContext.getRegulatories().keySet()
																					  .stream()
																					  .filter(s -> !GeneralUtils.IsNull(s))
																					  .map(s->StringUtils.substringBefore(s, Constants.UNDERSCORE))
																					  .collect(Collectors.joining(Constants.SEMICOLON)));
		}

		if (null != rulesResultsContext && 
				((Constants.RESPONSE_SDR_REQ).equalsIgnoreCase(rulesResultsContext.getResultsSource()) 
						|| (Constants.RESPONSE_SDR_RES).equalsIgnoreCase(rulesResultsContext.getResultsSource())))
		{
			altertValidationList = rulesResultsContext.getAlertValidationResultList();
			filterValidationList = rulesResultsContext.getFilterValidationResultList();

			messageTypeList = new ArrayList<MessageType>(5);

			if (altertValidationList == null && filterValidationList == null)
			{
				regRepResponse.setResponseCode(ResponseCodeEnum.ACK);

				if((Constants.RESPONSE_SDR_RES).equalsIgnoreCase(rulesResultsContext.getResultsSource()))
				{	
					if(null != reportingContext.getResponse())
						reportType = reportingContext.getResponse().getParentreportType();
					
					MessageType currMessageType = new MessageType();
					currMessageType.setValue(ResponseCodeEnum.ACK.value());
					currMessageType.setDescription("GTR ACKNOWLEDGED " + reportType + " message");

					messageTypeList.add(currMessageType);
					regRepResponse.setIsResponseInternal(false);
				}
				else if((Constants.RESPONSE_SDR_REQ).equalsIgnoreCase(rulesResultsContext.getResultsSource()))
				{
					MessageType currMessageType = new MessageType();
					currMessageType.setValue(ResponseCodeEnum.ACK.value());
					currMessageType.setDescription("REG REP ACKNOWLEDGED");

					messageTypeList.add(currMessageType);
					regRepResponse.setIsResponseInternal(true);
					
				}
			}
			else if (altertValidationList != null && filterValidationList == null)
			{
				if((Constants.RESPONSE_SDR_REQ).equalsIgnoreCase(rulesResultsContext.getResultsSource()))
				{
					//regRepResponse.setResponseCode(ResponseCodeEnum.VALIDATION_ERROR);
					regRepResponse.setResponseCode(ResponseCodeEnum.WACK);
					regRepResponse.setIsResponseInternal(true);
				}
				else if((Constants.RESPONSE_SDR_RES).equalsIgnoreCase(rulesResultsContext.getResultsSource()))
				{
					regRepResponse.setResponseCode(ResponseCodeEnum.WACK);
					regRepResponse.setIsResponseInternal(false);
				 }
			}
			else if (filterValidationList != null)
			{
				 if((Constants.RESPONSE_SDR_REQ).equalsIgnoreCase(rulesResultsContext.getResultsSource()))
				 {
					 ValidationResult currValidationResult = filterValidationList.get(0);
					 if(Constants.RESPONSE_INACTIVE_CAD.equalsIgnoreCase(currValidationResult.getValidationType()) )
					 {
						 regRepResponse.setResponseCode(ResponseCodeEnum.WACK);
						 regRepResponse.setIsResponseInternal(true); 
					 }
					 else
					 {
						 regRepResponse.setResponseCode(ResponseCodeEnum.NACK);
						 regRepResponse.setIsResponseInternal(true);
					 }
					 //regRepResponse.setResponseCode(ResponseCodeEnum.VALIDATION_ERROR);
				 }
				 else if((Constants.RESPONSE_SDR_RES).equalsIgnoreCase(rulesResultsContext.getResultsSource()))
				 {
					 regRepResponse.setResponseCode(ResponseCodeEnum.NACK);
					 regRepResponse.setIsResponseInternal(false);
				 }
			}
			
			/*** add all alert validation details to response ***/
			if (altertValidationList != null)
			{
				for (ValidationResult currValidationResult : altertValidationList)
				{
					MessageType currMessageType = new MessageType();
					currMessageType.setValue(currValidationResult.getFieldName());
					currMessageType.setDescription(currValidationResult.getErrorDesc());

					messageTypeList.add(currMessageType);
				}
			}

			/*** add all filter validation details to response ***/
			if (filterValidationList != null)
			{
				for (ValidationResult currValidationResult : filterValidationList)
				{
					MessageType currMessageType = new MessageType();
					currMessageType.setValue(currValidationResult.getFieldName());
					currMessageType.setDescription(currValidationResult.getErrorDesc());

					messageTypeList.add(currMessageType);
				}
			}

			regRepResponse.getMessage().addAll(messageTypeList);
		}
		else if(null != rulesResultsContext && (Constants.RESPONSE_GTR_USI).equals(rulesResultsContext.getResultsSource()))
		{
			messageTypeList = new ArrayList<MessageType>(2);
			regRepResponse.setResponseCode(ResponseCodeEnum.USI);

			MessageType currMessageType = new MessageType();
			
			if(null != reportingContext.getUsi() && reportingContext.getUsi().length() > 10)
			{
				currMessageType.setValue(reportingContext.getUsi().substring(0, 10) + Constants.COLON + reportingContext.getUsi().substring(10, reportingContext.getUsi().length()));
			}
			else
			{
				currMessageType.setValue(reportingContext.getUsi());
			}
			
			currMessageType.setDescription("GTR CREATED USI");

			messageTypeList.add(currMessageType);
			
			/*if(null != repContext.getReportTypes() && repContext.getReportTypes().size() > 0){
				
				reportType = repContext.getReportTypes().get(0);
			}else{													// this is only for debugging
					
				logger.debug("Report Type was not populated");;
				reportType = "";
			}*/
			
			// Fix QC-606
			
			if(null != reportingContext.getResponse())
			{
				reportType = reportingContext.getResponse().getParentreportType();
			} 
			else
			{
				logger.debug("Report Type was not populated");
				reportType = "";
			}
			
			currMessageType = new MessageType();
			currMessageType.setValue(ResponseCodeEnum.ACK.value());
			currMessageType.setDescription("GTR ACKNOWLEDGED " + reportType + " message");

			messageTypeList.add(currMessageType);

			regRepResponse.getMessage().addAll(messageTypeList);
			regRepResponse.setIsResponseInternal(false);
		}		

		if (regRepResponse != null)
		{
			try
			{
				String respXml = prepareResponse(regRepResponse);

				/*** Set respXml in message as Payload in Reporting Context ***/
				if (respXml != null)
				{
					reportingContext.setPayload(respXml);
				}
				//send mails to front office in case filtering message on RegRep Validations
				if(null != filterValidationList && filterValidationList.size() > 0 && (Constants.RESPONSE_SDR_REQ).equalsIgnoreCase(rulesResultsContext.getResultsSource()) &&	Constants.TRUE.equalsIgnoreCase(emailFlag))
				{
					
					String messageID[]=StringUtils.split(regRepResponse.getMessageId(),Constants.COLON);
					String subject="Regulatory Reporting:  Trade validation failed for trade: "+ messageID[0];
					StringBuffer messageBody=new StringBuffer();
					messageBody.append("Information 					:Trade validation failed, hence this trade was filtered in 1STR \n ");
					messageBody.append("Asset Class 					:"+ assetClass);
					messageBody.append("Response Code 	 			    :"+ regRepResponse.getResponseCode()+" \n ");
					messageBody.append("Traded ID 		                :"+ messageID[0]+" \n ");
					messageBody.append("Traded Version	  				:"+ messageID[1]+" \n ");
					messageBody.append("Internal Response 				:"+ regRepResponse.getIsResponseInternal()+" \n ");
					for (MessageType messageType : regRepResponse.getMessage())
					{
						messageBody.append("Error Reason 				:"+ messageType.getValue()+"-"+messageType.getDescription() +" \n ");
					}
					mailSenderService.sendAssetClassMail(assetClass,subject , messageBody.toString(),null,null,regRepResponse.getReportingJurisdiction());
				}
				
				logger.info("--> Response XML : \n " + respXml);
			}
			catch (Exception e)
			{
				errorString = "Exception occurred while parsing incoming sdr request using JaxB : " + e.getMessage();
				logger.error("########## " + errorString);

				throw new MessagingException("IpParser:5", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, reportingContext.getSwapTradeId());
			}
		}

		logger.debug("Exiting RegRepRespProcessorimpl");
		
		return message;

	}

	/**
	 * converts RegRepResponse object into response xml
	 *
	 * @param regRepResponse
	 * @return
	 * @throws Exception
	 */
	private String prepareResponse(RegRepResponse regRepResponse) throws Exception
	{	
		String response = null;
		String fileName = null;
		File tempFile 	= null; 
				
		fileName = Constants.REG_REP_TEMP + Constants.UNDERSCORE + (new Date()).getTime() + sequence.getAndIncrement();
		tempFile = new File(tempFileLoc + File.separator + fileName);		
		
		FileOutputStream fileOutputStream = null;
		
		try
		{
			fileOutputStream = new FileOutputStream(tempFile);
			marshaller.marshal(regRepResponse, new StreamResult(fileOutputStream));
			Scanner respScanner = new Scanner(tempFile);
			response 			= respScanner.useDelimiter("\\Z").next();
			
			respScanner.close();
		}
		catch (Exception exp)
		{
			throw exp;
		}
		finally
		{
			if (fileOutputStream != null)
			{
				fileOutputStream.close();
			}

			tempFile.delete();
		}

		return response;
	}

	public String getTempFileLoc()
	{
		return tempFileLoc;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}
}
