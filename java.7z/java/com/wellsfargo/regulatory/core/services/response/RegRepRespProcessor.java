package com.wellsfargo.regulatory.core.services.response;

import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public interface RegRepRespProcessor
{

	public Message<?> process(Message<?> message) throws MessagingException;

}
