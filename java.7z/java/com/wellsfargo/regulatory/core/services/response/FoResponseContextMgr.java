package com.wellsfargo.regulatory.core.services.response;

import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.core.services.enrichers.RegRepContextManager;

@Component
public class FoResponseContextMgr extends RegRepContextManager
{
	private static Logger logger = Logger.getLogger(ReportingContext.class.getName());

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		ReportingContext context 		= null;
		ReportingContext respContext 	= null;
		Message<?> messageOut 			= null;
		logger.debug("Entering ResponseContextMgr: updateContext:   method");

		context = (ReportingContext) message.getPayload();
		
		//context.setContextType(PayloadTypeEnum.REG_REP_RESPONSE);

		/*** Getting a new context exclusively for this flow. ***/
		//AbstractDriver.setMDCInfo(respContext, AbstractDriver.FoResponseContextMgr);

		respContext = getNewContext(context, context.getMessageId(), NULL, false);
		respContext.setContextType(PayloadTypeEnum.REG_REP_RESPONSE);
		
		messageOut = MessageBuilder.withPayload(respContext).copyHeadersIfAbsent(message.getHeaders()).build();

		return messageOut;
	}

}
