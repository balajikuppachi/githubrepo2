package com.wellsfargo.regulatory.core.services.parsers;

import java.io.StringReader;

import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;

@Component
public class SdrRequestParser implements RegRepMsgParser
{
	@Autowired
	@Qualifier("sdrRequestJaxbMarshaller")
	private Marshaller marshaller;
	@Autowired
	@Qualifier("sdrRequestJaxbMarshaller")
	private Unmarshaller unmarshaller;

	private static Logger logger = Logger.getLogger(SdrRequestParser.class.getName());

	@Override
	public Message<?> parse(Message<?> message) throws MessagingException
	{
		logger.debug("Entering input message parsing");

		String sdrMessageId 		= null;
		String errorString 			= null;
		SdrRequest trade 			= null;
		ReportingContext repContext = null;
		String payload 				= null;
		Object parsedObject 		= null;
		StringReader payLoadStream 	= null;

		if (null == message)
		{
			errorString = "Null incoming object. Parsing failed";
			logger.error("########## " + errorString);

			return message;
			// throw new MessagingException("IpParser:1", ExceptionSeverityEnum.ERROR,
			// ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		if (!(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming object type. Parsing failed";
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			logger.error("########## " + errorString);

			throw new MessagingException("IpParser:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		repContext = (ReportingContext) message.getPayload();

		if (null == repContext || null == repContext.getPayload())
		{
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			errorString = "Invalid incoming payload. Parsing failed";
			logger.error("########## " + errorString);

			throw new MessagingException("IpParser:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		payload 		= repContext.getPayload();
		sdrMessageId 	= repContext.getMessageId();

		try
		{
			payLoadStream 	= new StringReader(payload);
			parsedObject 	= unmarshaller.unmarshal(new StreamSource(payLoadStream));
		}
		catch (Exception e)
		{
			errorString = "Exception occurred while parsing incoming sdr request using JaxB : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("IpParser:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);

		}

		if (null == parsedObject || !(parsedObject instanceof SdrRequest))
		{
			errorString = "Invalid parsed object";
			logger.error("########## " + errorString);

			throw new MessagingException("IpParser:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		trade = (SdrRequest) parsedObject;

		try
		{
			// - Initializing the context
			repContext.initializeContext(trade, sdrMessageId, PayloadTypeEnum.REG_REP_XML, repContext);

			// START : Setting the MDC from the Context
			// AbstractDriver.setMDCInfo(repContext, AbstractDriver.SdrRequestParser);
			// END : Setting the MDC from the Context

		}
		catch (Exception e)
		{
			errorString = "Error instantiating the Reporting context : " + e.getMessage();
			logger.error("########## " + errorString);

			throw new MessagingException("IpParser:5", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, e, null);
		}

		logger.debug("Successfully parsed the incoming trade.");

		return message;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}

}
