package com.wellsfargo.regulatory.core.services.parsers;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ResponseUtils;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class ResponseMessageParser extends Parser
{
	private static Logger logger = Logger.getLogger(ResponseMessageParser.class.getName());

	@SuppressWarnings("deprecation")
	public static Message<?> parse(Message<?> message) throws MessagingException
	{
		logger.debug("Entering input message parsing");

		String origPayload 			= null;
		String sdrMessageId 		= null;
		String errorString 			= null;
		Object parsedObject 		= null;
		ReportingContext repContext = null;
		String[] responseDetails 	= null;
		String objectFactory 		= null;
		String responseType 		= null;
		Object genericResponse 		= null;

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		if ((null == message.getPayload()) || !(message.getPayload() instanceof ReportingContext))
		{
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			errorString = "Invalid incoming message type";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		repContext 		= (ReportingContext) message.getPayload();
		sdrMessageId 	= repContext.getMessageId();
		origPayload 	= repContext.getPayload();

		responseDetails = ResponseUtils.getResponseDetails(origPayload);
		objectFactory 	= responseDetails[0];
		responseType 	= responseDetails[1];

		setObjectfactory(objectFactory);
		parsedObject = parse(origPayload, sdrMessageId);

		if (null == parsedObject || !(parsedObject instanceof JAXBElement))
		{
			errorString = "Invalid parsed object";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		genericResponse = ((JAXBElement<?>) parsedObject).getValue();

		if (null == genericResponse)
		{
			errorString = "Null extracted object from Jaxb";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		try
		{
			/*** Initializing the context ***/
			repContext.initializeContext(genericResponse, sdrMessageId, PayloadTypeEnum.fromValue(responseType), repContext);
		}
		catch (Exception e)
		{
			errorString = "Error instantiating the Reporting context";
			logger.error("########## " + errorString, e);

			throw new MessagingException("Rsp:Prsr:5", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, e, repContext.getSwapTradeId());
		}

		Message<?> messageOut = MessageBuilder.withPayload(repContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Successfully parsed the incoming response.");
		
		return messageOut;
	}

}
