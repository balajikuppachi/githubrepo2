package com.wellsfargo.regulatory.core.services.parsers;

import java.io.StringReader;

import javax.xml.bind.JAXBElement;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ResponseUtils;

@Component
public class DtccRespParser implements RegRepMsgParser
{
	
	@Autowired
	@Qualifier("dtccRespJaxbMarshaller")
	private Marshaller marshaller;

	@Autowired
	@Qualifier("dtccRespJaxbMarshaller")
	private Unmarshaller unmarshaller;

	private static Logger logger = Logger.getLogger(DtccRespParser.class.getName());

	@Override
	public Message<?> parse(Message<?> message) throws MessagingException
	{
		logger.debug("Entering parse() method");

		String origPayload 			= null;
		String sdrMessageId 		= null;
		String errorString 			= null;
		Object parsedObject 		= null;
		ReportingContext repContext = null;
		String[] responseDetails 	= null;
		String responseType 		= null;
		Object genericResponse 		= null;
		String eventType;
		
		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		if ((null == message.getPayload()) || !(message.getPayload() instanceof ReportingContext))
		{
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			errorString = "Invalid incoming message type";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		repContext 		= (ReportingContext) message.getPayload();
		
		AbstractDriver.setMDCInfo(repContext, AbstractDriver.DtccRespParser);

		sdrMessageId 	= repContext.getMessageId();
		origPayload 	= repContext.getPayload();

		responseDetails = ResponseUtils.getResponseDetails(origPayload);
		responseType 	= responseDetails[1];
		eventType 		= ResponseUtils.getResponseEventType(origPayload);

		try
		{
			StringReader respStream = null;
			respStream 		= new StringReader(origPayload);
			parsedObject 	= unmarshaller.unmarshal(new StreamSource(respStream));
		}
		catch (Exception exe)
		{
			errorString = "Exception occurred while parsing incoming sdr request using JaxB "+ExceptionUtils.getFullStackTrace(exe);
			logger.error("########## " + errorString);
			//exe.printStackTrace();

			throw new MessagingException("IpParser:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, repContext.getSwapTradeId());
		}

		if (null == parsedObject || !(parsedObject instanceof JAXBElement))
		{
			errorString = "Invalid parsed object";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, repContext.getSwapTradeId());
		}

		genericResponse = ((JAXBElement<?>) parsedObject).getValue();

		if (null == genericResponse)
		{
			errorString = "Null extracted object from Jaxb";
			logger.error("########## " + errorString);

			throw new MessagingException("Rsp:Prsr:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, repContext.getSwapTradeId());
		}

		try
		{
			if(!RegulatoryBeanFactory.validatePayloadTypeEnum(responseType))
			{
				errorString = "Error before instantiating the Reporting context, Invalid responseType >>>>>>>>>> " + responseType;
				logger.error("########## " + errorString);
			}
			
			/*** Initializing the context ***/
			repContext.initializeContext(genericResponse, sdrMessageId, PayloadTypeEnum.fromValue(responseType), repContext);
			
			if (eventType != null)
			{
				repContext.setLifeCycleEvent(eventType);
			}
		}
		catch (Exception e)
		{
			errorString = "Error instantiating the Reporting context, ResponseType : " + responseType;
			logger.error("########## " + errorString, e);

			throw new MessagingException("Rsp:Prsr:5", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, e, repContext.getSwapTradeId());
		}

		Message<?> messageOut = MessageBuilder.withPayload(repContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Successfully parsed the incoming response.");
		
		return messageOut;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}

}
