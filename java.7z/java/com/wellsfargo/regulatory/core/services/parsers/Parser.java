package com.wellsfargo.regulatory.core.services.parsers;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

@Deprecated
public abstract class Parser
{
	private static String objectfactory = null;
	private static Logger logger = Logger.getLogger(Parser.class.getName());
	private static String destFilePath;

	/**
	 * @param String
	 * : name of the temp file to set
	 * @return void
	 */
	public void setDestFilePath(String destFilePath)
	{
		Parser.destFilePath = destFilePath;
	}

	/**
	 * @param String
	 * : name of the objectfactory to set
	 * @return void
	 */
	public static void setObjectfactory(String objectfactory)
	{
		Parser.objectfactory = objectfactory;
	}

	/**
	 * @param File
	 * @param String
	 * @throws MessagingException
	 */
	public static Object parse(String message, String sdrMessageId) throws MessagingException
	{
		logger.debug("Entering parse() method");

		JAXBContext context 		= null;
		Unmarshaller unMarshaller 	= null;
		Object parsedObject 		= null;
		String errorString 			= null;
		Class<?> clazz 				= null;
		File fileToParse 			= null;

		if (null == Parser.objectfactory)
		{
			errorString = "Invalid object factory. It is set as " + objectfactory;
			logger.error("########## " + errorString);

			throw new MessagingException("Parser:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, null);
		}

		try
		{
			fileToParse = createTemporaryFile(message);
			clazz 		= Class.forName(objectfactory);

			logger.debug("Instantiating parser context....");
			context = JAXBContext.newInstance(clazz);

			unMarshaller = context.createUnmarshaller();

			logger.debug("Parsing initiated....");
			parsedObject = unMarshaller.unmarshal(fileToParse);

		}
		catch (JAXBException | ClassNotFoundException | MessagingException e)
		{
			errorString = "Failed to parse the incoming message --> " + e;
			logger.error("########## " + errorString);

			throw new MessagingException("Parser:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, sdrMessageId, e.getCause(), null);
		}
		finally
		{
			FileUtils.deleteQuietly(fileToParse);
			logger.debug("Deleting the temparory file " + fileToParse.toString());
		}

		logger.debug("@@@@ Message successfully parsed.\nLeaving parse() method");

		return parsedObject;
	}

	private static File createTemporaryFile(String data) throws MessagingException
	{
		logger.debug("Entering createTemporaryFile() method");

		File fileToParse 	= null;
		String errorString 	= null;
		String fileName 	= null;

		if (null == data)
		{
			errorString = "Failed to create temp file for parsing since the incoming data was null";
			logger.error("########## " + errorString);

			throw new MessagingException("Parser:tempFile:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		fileName 	= Constants.REG_REP_TEMP + Constants.UNDERSCORE + (new Date()).getTime();
		fileToParse = new File(destFilePath + File.separator + fileName);

		try
		{
			FileUtils.writeStringToFile(fileToParse, data);
		}
		catch (IOException e)
		{
			errorString = "Failed to create temp file for parsing --> " + e;
			logger.error("########## " + errorString);

			throw new MessagingException("Parser:tempFile:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		logger.debug("Successfully created temp file to parse.");
		return fileToParse;
	}

}
