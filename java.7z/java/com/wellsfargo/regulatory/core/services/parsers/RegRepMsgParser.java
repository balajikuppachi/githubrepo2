package com.wellsfargo.regulatory.core.services.parsers;

import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public interface RegRepMsgParser
{
	public Message<?> parse(Message<?> message) throws MessagingException;

}
