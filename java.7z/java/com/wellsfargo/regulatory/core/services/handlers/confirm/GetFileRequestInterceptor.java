package com.wellsfargo.regulatory.core.services.handlers.confirm;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.xml.transform.StringSource;

public class GetFileRequestInterceptor implements ClientInterceptor
{

	String username;
	String password;

	private Logger logger = Logger.getLogger(this.getClass().getName());

	public boolean handleFault(MessageContext context) throws WebServiceClientException
	{
		return true;
	}

	public boolean handleRequest(MessageContext context) throws WebServiceClientException
	{
		enrichHeaders(context);
		logger.info(context.getRequest().toString());
		return true;
	}

	public boolean handleResponse(MessageContext context) throws WebServiceClientException
	{

		return true;
	}

	private void enrichHeaders(MessageContext context)
	{

		SoapMessage soapMessage = (SoapMessage) context.getRequest();
		SoapHeader soapHeader = soapMessage.getSoapHeader();
		try
		{
			StringSource additionalHeader = new StringSource("<Header1>" + "<authHeader1/>" + "<id>" + Base64.encodeBase64(username.getBytes()) + "</id>" + "<password>" + Base64.encodeBase64(password.getBytes()) + "</password>" + "</Header1>");
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(additionalHeader, soapHeader.getResult());
		}
		catch (Exception e)
		{
			logger.error(e);
		}
	}

	public void setUsername(String username)
	{
		this.username = username;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	/*
	 * (non-Javadoc)
	 * @see org.springframework.ws.client.support.interceptor.ClientInterceptor#afterCompletion(org.
	 * springframework.ws.context.MessageContext, java.lang.Exception)
	 */
	@Override
	public void afterCompletion(MessageContext arg0, Exception arg1) throws WebServiceClientException
	{
		// TODO Auto-generated method stub

	}
}
