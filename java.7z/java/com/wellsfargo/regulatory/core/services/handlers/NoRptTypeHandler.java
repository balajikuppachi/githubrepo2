package com.wellsfargo.regulatory.core.services.handlers;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */
@Component
public class NoRptTypeHandler extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(NoRptTypeHandler.class.getName());

	public Message<?> handleNoRptType(Message<?> message) throws MessagingException
	{
		ReportingContext context = null;
		String errorString = null;
		String messageId = null;
		List<String> reportTypes = null;
		ReportingStatus reportingStatus = new ReportingStatus();

		if (null == message || !(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("noRpt-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		context = (ReportingContext) message.getPayload();
		messageId = context.getMessageId();
		reportTypes = context.getReportTypes();

		try{

			if (null != reportTypes && reportTypes.size() < 1)
			{

				reportingStatus.setReportStatus(false);
				reportingStatus.setReportReason(NotReportingReasonEnum.NOT_REPORTABLE);
				context.setReportingStatus(reportingStatus);

				context.setReportable(false);

				addFilterValidationResult(context, "eligibleReportTypeFilter", "NO_RPT_1",
				        "No eligible reports matched for the message  ", "NOT-REPORTABLE");

				/*
				 * ConfirmMessageDecorater sets flag for paper confirms
				 * in isDtccMatrixParticipant
				 *
				 * ConfirmMessageDecorater sets flag for confirms messages
				 * in comment
				 *
				 */

				if(Constants.Confirmation.equals(context.getSdrRequest().getTrade().getTradeHeader().getComment())
						||context.getSdrRequest().getTrade().getTradeDetail().getDocumentation().isDtccMatrixParticipant())
				{
					logger.info("\n------------------------------------------------------------------------------------------\n**** NONE OF RULES FOR (Paper/Confirm) REPORTS TRIGGERED TO GENERATE THE REPORT ****\n------------------------------------------------------------------------------------------");
				}
				else
				{
					logger.info("\n------------------------------------------------------------------------------------------ \n**** NONE OF RULES FOR (RT/PET) REPORTS TRIGGERED TO GENERATE THE REPORT **** \n------------------------------------------------------------------------------------------");
				}
			}
			else
			{
				// - This is in case there is an error in the router. due to which msg gets routed to
				// default channel. ??????
				logger.info("\n------------------------------------------------------------------------------------------\nIncoming trade with message id : " + messageId + " generated the report types ! " + StringUtils.collectionToDelimitedString(reportTypes, "|") + " \n------------------------------------------------------------------------------------------");
			}
		}catch(Exception e){

			logger.error("Error in noRptTypeHnadler : "+e.getMessage());
			//logger.debug("Error in noRptTypeHnadler : "+e);
		}

		return message;
	}
}
