package com.wellsfargo.regulatory.core.services.handlers.confirm;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

// TODO: AZ - Add schema validation
@XmlRootElement(name = "ScritturaConfirmAck")
public class ScritturaMessage
{

	@XmlElement(name = "TradeId")
	private String tradeId;

	@XmlElement(name = "CRID")
	private String crId;

	@XmlElement(name = "TradeVersion")
	private String tradeVersion;

	@XmlElement(name = "USI")
	private String usi;

	@XmlElement(name = "MessageDateTime")
	private Date messageDateTime;

	@XmlElement(name = "ConfirmDateTime")
	private Date confirmDateTime;

	@XmlElement(name = "DocId")
	private String docId;

	@XmlElement(name = "SourceSystem")
	private String sourceSystem;

	@XmlElement(name = "PaperFlag")
	private Boolean paperFlag;

	@XmlElement(name = "ConfirmSentTimeToCpty")
	private Date confirmDateTimeToCpty;

	public String getTradeId()
	{
		return tradeId;
	}

	public String getTradeVersion()
	{
		return tradeVersion;
	}

	public String getCrId()
	{
		return crId;
	}

	public String getUsi()
	{
		return usi;
	}

	public Date getMessageDateTime()
	{
		return messageDateTime;

		/*
		 * try { return Utils.parseDate(messageDateTime); } catch (ParseException e) { throw new
		 * CalculationException("XML Date Parsing Error",
		 * "Error parsing MessageDateTime : "+e.getMessage(), e); }
		 */
	}

	public Date getConfirmDateTime()
	{
		/*
		 * try { return Utils.parseDate(confirmDateTime); } catch (ParseException e) { throw new
		 * CalculationException("XML Date Parsing Error",
		 * "Error parsing ConfirmDateTime : "+e.getMessage(), e); }
		 */
		return confirmDateTime;
	}

	public String getDocId()
	{
		return docId;
	}

	public String getSourceSystem()
	{
		return sourceSystem;
	}

	public Boolean getPaperFlag()
	{
		return paperFlag == null ? false : paperFlag;
	}

	/**
	 * @return the confirmDateTimeToCpty
	 */
	public Date getConfirmDateTimeToCpty()
	{
		return confirmDateTimeToCpty;
	}

}
