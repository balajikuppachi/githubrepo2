package com.wellsfargo.regulatory.core.services.handlers;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */
@Component
@Deprecated
public class NrpMessageHandler
{
	private static Logger logger = Logger.getLogger(NrpMessageHandler.class.getName());

	public Message<?> handleNrpTrade(Message<?> message) throws MessagingException
	{
		String errorString = null;
		ReportingContext context = null;
		ReportingStatus reportingStatus = new ReportingStatus();

		if (null == message || !(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("NonRptPty-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		context = (ReportingContext) message.getPayload();

		reportingStatus.setReportStatus(false);
		reportingStatus.setReportReason(NotReportingReasonEnum.NRP_TRADE);

		// updating context with non reporting reason
		context.setReportingStatus(reportingStatus);

		AbstractDriver.setMDCInfo(context, AbstractDriver.NrpMessageHandler);

		logger.warn("\n------------------------------------------------------------------------------------------\n* ------- WELLS NON-REPORTING PARTY FOR TRADE --------------------------------------------- *\n------------------------------------------------------------------------------------------");

		// TODO : Update message table record for Non Reporting Party Message.

		return message;
	}

}
