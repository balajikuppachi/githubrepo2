package com.wellsfargo.regulatory.core.services.handlers;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.core.integration.filters.FilterRulesContextMgr;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */
@Component
public class NonEligibleMessageHandler extends FilterRulesContextMgr
{
	private static Logger logger = Logger.getLogger(NonEligibleMessageHandler.class.getName());

	public Message<?> handleNonEligibleTrade(Message<?> message) throws MessagingException
	{
		ReportingContext context 	= null;
		String errorString 			= null;
		String messageId 			= null;
		//Set<String> regulatories = null;
		ReportingStatus reportingStatus = new ReportingStatus();
		
		if (null == message || !(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("NonRptbl-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		context 	= (ReportingContext) message.getPayload();
		messageId 	= context.getMessageId();
		//regulatories = context.getRegulatories().keySet();

		reportingStatus.setReportStatus(false);
		reportingStatus.setReportReason(NotReportingReasonEnum.INVALID_TRADE);

		/*** updating context with non reporting reason ***/
		context.setReportingStatus(reportingStatus);

		context.setReportingParty(false);

		if (null == context.getRegulatories() || null == context.getRegulatories().keySet()
				|| context.getRegulatories().keySet().size() < 1)
		{
			// logger.info(" Incoming trade with message id : "+messageId+" was of non-reporting party type ");
			// logger.debug(" Incoming trade with message id : "+messageId+" was of non-reporting party type "+context.toString());
			
			errorString = "No jurisdictions populated in the incoming trade ";
			logger.warn(" Incoming trade with message id : " + messageId + " : "+errorString);
		}
		else
		{
			// logger.info(" Incoming trade with message id : "+messageId+" could not be routed to appropriate jurisdiction");
			// logger.debug(" Incoming trade with message id : "+messageId+" could not be routed to appropriate jurisdiction "+context.toString());
			
			errorString = "Unsupported Jurisdiction/(s) : "+ context.getRegulatories().keySet();			
			logger.warn(" Incoming trade with message id : " + messageId + " : "+errorString);
		}
		
		addFilterValidationResult(context, "rptingtJrsdnChk", "Invalid", errorString, "INVALID_TRADE");

		return message;
	}

}
