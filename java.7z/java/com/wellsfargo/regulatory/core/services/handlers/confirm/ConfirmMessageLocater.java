package com.wellsfargo.regulatory.core.services.handlers.confirm;

import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.RegRepMessageTypeEum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepReportDao;
import com.wellsfargo.regulatory.persister.dao.impl.RegRepMessageDaoImpl;
import com.wellsfargo.regulatory.persister.dao.impl.RegRepReportDaoImpl;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepPayload;
import com.wellsfargo.regulatory.persister.dto.RegRepReport;

@Component
public class ConfirmMessageLocater
{

	@Autowired
	RegRepMessageDao regRepMessageDao;
	
	@Autowired
	RegRepReportDao regRepReportDao;

	private static Logger logger = Logger.getLogger(ConfirmMessageLocater.class.getName());

	public Message<?> locateConfirmMessageTrade(Message<?> message) throws MessagingException
	{
		ReportingContext context 	= null;
		String errorString 			= null;
		SdrRequest request 			= null;
		String externalMsgId 		= null;
		List<RegRepMessage> messages = null;
		Set<RegRepPayload> payloads = null;
		String confirmPayload 		= null;
		boolean found 				= false;

		if (null == message || !(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgLct-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		context = (ReportingContext) message.getPayload();
		request = context.getSdrRequest();

		if (null == request)
		{
			errorString = "Invalid incoming message : sdrRequest object is null ";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgLct-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), context.getSwapTradeId());
		}

		externalMsgId = request.getMessageId();

		if (null == externalMsgId)
		{
			errorString = "Invalid external message id : null ";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgLct-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), context.getSwapTradeId());
		}
		
		if(!GeneralUtils.IsNull(request.getConfirmation()) && GeneralUtils.IsNull(request.getConfirmation().getConfirmationDateTime()))
		{
			errorString = "Invalid trade,ConfirmationDateTime is not available , message id :"+ externalMsgId;
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgLct-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), context.getSwapTradeId());
			
		}
		
	


		logger.debug("Getting Confirm Message based on External Message Id..");
		messages = regRepMessageDao.loadRegRepMsgsByExtrnlMsgId(externalMsgId);

		for (RegRepMessage msg : messages)
		{

			if (null != msg && null != msg.getRegRepPayloads())
			{
				if(!RegRepMessageTypeEum.SDR_TRADE.type().equals(msg.getMessageType()))
					continue;

				payloads = msg.getRegRepPayloads();

				for (RegRepPayload payload : payloads)
				{

					if (null != payload && !StringUtils.isBlank(payload.getPayload()))
					{
						confirmPayload = payload.getPayload();
						
						/*** If this payload is Confirmation payload, ignore this payload. ***/
						if (confirmPayload!=null && confirmPayload.contains(Constants.ConfirmationKey + Constants.UNDERSCORE))
							continue;
						
						found = true;
						break;
					}
				}

				if (found) break;
			}
		}

		if (null == confirmPayload)
		{
			errorString = "Trade payload for the cofirm alert could not be found";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgLct-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), context.getSwapTradeId());
		}

		context.setPayload(confirmPayload);

		return message;
	}

	public Message<?> checkGeneratedRtPetMesgs(Message<?> message) throws MessagingException
	{
		ReportingContext context 	= null;
		String errorString 			= null;
		SdrRequest request 			= null;
		String tradeId 				= null;
		List<RegRepReport> reports 	= null;

		if (null == message || !(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgCheckRtPet-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		context = (ReportingContext) message.getPayload();
		request = context.getSdrRequest();

		if (null == request)
		{
			errorString = "Invalid incoming message : sdrRequest object is null ";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgCheckRtPet-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), context.getSwapTradeId());
		}

		 if (request.getConfirmation() != null)
			 
			 tradeId = request.getConfirmation().getTradeId();
		
		if (null == tradeId)
		{
			errorString = "Input Trade id : null ";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgCheckRtPet-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), context.getSwapTradeId());
		}
		
		logger.debug("Getting Reports based on TradeId..");
		reports = regRepReportDao.loadRegRepRptsBySwapTradeId(tradeId);
		
		if (reports == null || reports.size() == 0 ){
			
			errorString = "RT/PET messages for the tradeId: "+ tradeId +" are not submitted, not sending the confirm alerts.. ";
			logger.error("########## " + errorString);

			throw new MessagingException("cnfMsgCheckRtPet-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					errorString, context.getMessageId(), context.getSwapTradeId());
		}
		
		return message;
	}
	
	public void setRegRepMessageDao(RegRepMessageDaoImpl regRepMessageDao)
	{
		this.regRepMessageDao = regRepMessageDao;
	}
	
	public void setRegRepReportDao(RegRepReportDaoImpl regRepReportDao)
	{
		this.regRepReportDao = regRepReportDao;
	}
}
