package com.wellsfargo.regulatory.core.services.handlers;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.core.driver.main.RegRepComponent;

import static com.wellsfargo.regulatory.commons.keywords.Constants.GTRCREATE;

/**
 * sends Filtered trades (messages) to UI alerts stores in RegRepException table sends an nack sends
 * response to FO system
 *
 * @author u373071
 */

public class FilterMessageHandler extends RegRepComponent
{
	private static Logger logger = Logger.getLogger(FilterMessageHandler.class.getName());

	public Message<?> handleFilteredTrade(Message<?> message) throws MessagingException
	{
		String 				errorString 	= null;
		ReportingContext 	context 		= null;
		String 				validationType	= null;
		String 				sdrMessageId	= null;

		logger.debug("Entering handleFilteredTrade() method");

		ReportingStatus reportingStatus = new ReportingStatus();

		if (null == message || !(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming message ";
			logger.error("########## " + errorString);

			throw new MessagingException("FilteredTrade-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		sdrMessageId 	= (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
		context 		= (ReportingContext) message.getPayload();

		if (sdrMessageId == null && (context.isEodRefresh() || context.isEodInsertRefresh() || context.isEodValuationRefresh()))
		{
			sdrMessageId = context.getMessageId();
		}
		
		AbstractDriver.setMDCInfo(context, AbstractDriver.FilterMessageHandler);

		if(null == context)
		{
			errorString = "Incoming message context is null";
			logger.error("########## " + errorString);

			throw new MessagingException("FilteredTrade-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		reportingStatus.setReportStatus(true);

		// updating context with non reporting reason
		context.setReportingStatus(reportingStatus);

		context.getRulesResultsContext().setResultsSource("SDR_REQ");

		if(null != context.getRulesResultsContext())
		{
			if(null != context.getRulesResultsContext().getFilterValidationResultList() && context.getRulesResultsContext().getFilterValidationResultList().size() > 0)
			{
				validationType = context.getRulesResultsContext().getFilterValidationResultList().get(0).getValidationType();
				
				/*
				 * Check - If the filter only got applied for non reporting party
				 */
				if(("FILTER").equals(validationType) 
						&& !context.isReportingParty() && context.getRulesResultsContext().getFilterValidationResultList().size() == 1)
				{
					validationType = "NON-REP-PARTY";
					context.setFiltered(false);
					context.getRulesResultsContext().getFilterValidationResultList().clear();
				}
				else
				{
					for (ValidationResult currValidationResult : context.getRulesResultsContext().getFilterValidationResultList())
					{
						// Validation is done only on Input data
						if("VALIDATION".equals(validationType))
						{
							errorString = "Invalidated due to : " + currValidationResult.getFieldName() + ". Reason  " + currValidationResult.getErrorDesc();
							dispatchException(message, sdrMessageId, errorString, "fltrHndlr:2", ExceptionSeverityEnum.ERROR, 
									ExceptionTypeEnum.INPUT_DATA_ERROR, context.getSwapTradeId());
						}
						else if("INACTIVE_CAD".equals(validationType))
						{
							errorString = "Alert due to : " + currValidationResult.getFieldName() + ". Reason  " + currValidationResult.getErrorDesc();
							context.setFiltered(false);
							dispatchException(message, sdrMessageId, errorString, "fltrHndlr:2", ExceptionSeverityEnum.WARNING, 
									ExceptionTypeEnum.REG_REP_ERROR, context.getSwapTradeId());
						}
						else if("FILTER_ESMAL2".equals(validationType))
						{
							errorString = "Filtered due to : " + currValidationResult.getFieldName() + ". Reason  " + currValidationResult.getErrorDesc();
							context.setFiltered(true);
							dispatchException(message, sdrMessageId, errorString, "fltrHndlr:EsmaL2", ExceptionSeverityEnum.WARNING, 
									ExceptionTypeEnum.REG_REP_ERROR, context.getSwapTradeId());
						}
						else
						{
							errorString = "Filtered due to : " + currValidationResult.getFieldName() + ". Reason  " + currValidationResult.getErrorDesc();						
							dispatchException(message, sdrMessageId, errorString, "fltrHndlr:2", ExceptionSeverityEnum.ERROR, context.getSwapTradeId());
						}
					}
				}

			}

			if(null != context.getRulesResultsContext().getAlertValidationResultList() && context.getRulesResultsContext().getAlertValidationResultList().size() > 0)
			{
				validationType = context.getRulesResultsContext().getAlertValidationResultList().get(0).getValidationType();
				
				for (ValidationResult currValidationResult : context.getRulesResultsContext().getAlertValidationResultList())
				{			
					if("Duplicate".equals(validationType)) continue;
					
					errorString = "Alert due to : " + currValidationResult.getFieldName() + ". Reason  " + currValidationResult.getErrorDesc();
					dispatchException(message, sdrMessageId, errorString, "fltrHndlr:3", ExceptionSeverityEnum.ALERT, context.getSwapTradeId());
				}
				
				// In case of only alert, we don't want it to get invalidated
				// Only exception is report, where we want to stop the message transmission
				if(null == context.getRulesResultsContext().getFilterValidationResultList() && !context.isDuplicateReport())
				{
					return message;
				}
			}

			reportingStatus.setReportStatus(false);
			
			/*
			 * Exclusively for additonal validators added for historical data load.
			 * These validators don't ad the to filter list, since we don't want these
			 * exceptions to end up in REG_REP_EXCEPTION table 
			 */
			if(context.isInvalid()){
				
				reportingStatus.setReportReason(NotReportingReasonEnum.INVALID_TRADE);
			}
			
			/*
			 * Validation type doesn't get over written between Filter and Alert
			 * One type of validator only sets one validation type but populates different kind of list
			 * based on the severity 
			 * 
			 */		
			
			else if(null == validationType)
			{
				reportingStatus.setReportReason(NotReportingReasonEnum.FILTERD_TRADE);
			}
			else if("VALIDATION".equals(validationType))
			{
				reportingStatus.setReportReason(NotReportingReasonEnum.INVALID_TRADE);
			}
			else if("FILTER".equals(validationType))
			{
				reportingStatus.setReportReason(NotReportingReasonEnum.FILTERD_TRADE);
			}
			else if("NON-REP-PARTY".equals(validationType))
			{
				reportingStatus.setReportReason(NotReportingReasonEnum.NRP_TRADE);
			}
			else if("NOT-REPORTABLE".equals(validationType))
			{
				reportingStatus.setReportReason(NotReportingReasonEnum.NOT_REPORTABLE);
			}
			else if("Duplicate".equals(validationType))
			{
				reportingStatus.setReportReason(NotReportingReasonEnum.DUPLICATE_SUBMISSION);
			}
			else if("FILTER_ESMAL2".equals(validationType))
			{
				reportingStatus.setReportReason(NotReportingReasonEnum.FILTERD_TRADE);
			}

			// updating context with non reporting reason
			context.setReportingStatus(reportingStatus);

			context.getRulesResultsContext().setResultsSource("SDR_REQ");

		}
		
		/*** Quick fix : Removing GTR create in case of a filtered trade ***/
		try
		{
			if(null != context.getUsi() || (context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().getUSI() !=null && 
					context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().getUSI().contains(GTRCREATE)))
			{
				context.setUsi(context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().getPrevUSI());
				context.getSdrRequest().getTrade().getTradeDetail().getProduct().getProductKeys().setPrevUSI(null);
			}
		}
		catch(Exception e)
		{
			logger.error("######### Failed to reset the original usi for the filtered trade for the message id --> "+context.getMessageId());
		}

		logger.info("\n------------------------------------------------------------------------------------------\n "
				+ "@@@@@@ TRADE GOT FILTERED OUT !!!! "
				+ "\n------------------------------------------------------------------------------------------");

		logger.debug("Leaving handleFilteredTrade() method");

		return message;
	}

}
