package com.wellsfargo.regulatory.core.services.handlers.confirm;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

@XmlRootElement(name = "getFileAsAttachmentResponse", namespace = "http://com.webservice/Scrittura")
public class GetFileAsAttachmentResponse
{

	public InlineFileAttachment getResult()
	{
		return result;
	}

	@XmlElementRef()
	public InlineFileAttachment result;

	public byte[] getDocumentAsByteArray() throws MessagingException
	{
		return ((null != result) ? result.getDocumentAsByteArray() : null);
	}

	public boolean saveFile(String fileName) throws MessagingException
	{
		return ((null != result) ? result.saveDocument(fileName) : false);
	}

	public boolean isDocumentEmpty()
	{
		return (result.isDocumentEmpty());
	}
}