package com.wellsfargo.regulatory.core.services.handlers.confirm;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.net.ssl.HostnameVerifier;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.HttpsUrlConnectionMessageSender;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;

public class ConfirmMessagedecorater
{
	private static Logger logger = Logger.getLogger(ConfirmMessagedecorater.class.getName());

	static String filePath;
	String bypassSecurity;

	@Autowired
	WebServiceTemplate webServiceTemplate;

	boolean hostnameVerifierFlag;
	final String tempFileName = "test.pdf";

	static
	{
		filePath = (String) System.getProperty("REG_REP_HOME");
		filePath = filePath + File.separator + "data" + File.separator + "paperDocs";

		if (!(new File(filePath)).exists())
		{
			(new File(filePath)).mkdir();
		}

		/*
		 * Only for testing Copying the test pdf to be downloaded for testing
		 */
	/*	if ((new File(filePath)).listFiles().length < 1)
		{
			(new File(((ClassLoader.getSystemResource("com/wellsfargo/regulatory/xsl/test.pdf")).getFile()))).renameTo(new File(filePath + "/test.pdf"));
		} */
	}

	public Message<?> decorateConfirmMessage(Message<?> message) throws MessagingException
	{

		String errorString 		= null;
		ReportingContext cntxt 	= null;
		String msgToDecorate 	= null;
		String pdfDoc 			= null;
		String docId 			= null;
		boolean docDownloaded 	= false;
		boolean isPaperConf 	= false;
		String decoratedMsg 	= null;
		String customDocId 		= null;

		if (null == message)
		{
			errorString = "Null incoming object";
			logger.error("########## " + errorString);

			throw new MessagingException("Parser:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
		}

		cntxt 			= (ReportingContext) message.getPayload();
		msgToDecorate 	= cntxt.getPayload();

		decoratedMsg 	= msgToDecorate;
		docId 			= cntxt.getSdrRequest().getConfirmation().getDocumentId();

		if(null == docId) docId = " ";

		customDocId		= Constants.ConfirmationKey + Constants.UNDERSCORE + docId;
		isPaperConf 	= cntxt.getSdrRequest().getConfirmation().isIsPaper();

		if (isPaperConf)
		{
			docDownloaded = fetchDocument(docId, null);

			if (docDownloaded)
			{
				pdfDoc = ConversionUtils.fileToBase64(filePath, docId + ".pdf");
			}
			else
			{
				// Dummy pdf doc for testing
				pdfDoc = ConversionUtils.fileToBase64(filePath, tempFileName);
			}

			decoratedMsg = getDecoratedPaperMessage(pdfDoc, customDocId, msgToDecorate, cntxt.getSdrRequest().getConfirmation().getConfirmationDateTime()+"");
		}
		else
		{
			decoratedMsg = getDecoratedElectonicMessage(customDocId, msgToDecorate, cntxt.getSdrRequest().getConfirmation().getConfirmationDateTime()+"");
		}

		cntxt.setPayload(decoratedMsg);

		return message;
	}

	private String getDecoratedPaperMessage(String pdfDoc, String docId, String msgToDecorate, String confDate)
	{
		DocumentBuilderFactory docFactory 	= null;
		DocumentBuilder docBuilder 			= null;
		InputSource is 						= null;
		Document doc 						= null;
		NodeList docmentaionNodes 			= null;
		NodeList tradeDetailNodes 			= null;
		NodeList cntrctSupplmntTypeNodes 	= null;
		NodeList tradeHeaderNodes 			= null;
		NodeList commentNodes 				= null;
		Element element 					= null;
		Element line 						= null;
		String decoratedMsg 				= null;
		NodeList dtccMatrixParticipantNodes = null;
		NodeList mstrAgrmntDateNodes 		= null;

		try
		{

			docFactory 	= DocumentBuilderFactory.newInstance();
			docBuilder 	= docFactory.newDocumentBuilder();
			is 			= new InputSource();
			is.setCharacterStream(new StringReader(msgToDecorate));

			doc = docBuilder.parse(is);
			docmentaionNodes 			= doc.getElementsByTagName("documentation");
			tradeDetailNodes 			= doc.getElementsByTagName("tradeDetail");
			dtccMatrixParticipantNodes 	= doc.getElementsByTagName("dtccMatrixParticipant");
			mstrAgrmntDateNodes 		= doc.getElementsByTagName("masterAgreementDate");
			tradeHeaderNodes 			= doc.getElementsByTagName("tradeHeader");

			if (null == tradeDetailNodes || tradeDetailNodes.getLength() == 0) throw new MessagingException("cnfMsgDcd:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR,
			        "Invalid confirm message, as no Trade Detail block was found");

			if (null == tradeHeaderNodes || tradeHeaderNodes.getLength() == 0) throw new MessagingException("cnfMsgDcd:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR,
			        "Invalid confirm message, as no Trade Header block was found");

			if (null != docmentaionNodes && docmentaionNodes.getLength() > 0)
			{
				// iterate the contractualTermsSupplementType
				for (int i = 0; i < docmentaionNodes.getLength();)
				{
					element 				= (Element) docmentaionNodes.item(i);
					cntrctSupplmntTypeNodes = element.getElementsByTagName("contractualTermsSupplementType");

					if (null != cntrctSupplmntTypeNodes && null != cntrctSupplmntTypeNodes.item(0))
					{
						line = (Element) cntrctSupplmntTypeNodes.item(0);
						logger.debug("Replacing contractualTermsSupplementType Node's value : " + getCharacterDataFromElement(line) + " with base64 converted pdf doc");
						docmentaionNodes.item(0).removeChild(cntrctSupplmntTypeNodes.item(0));
					}

					break;
				}
			}
			else
			{
				addNode("documentation", tradeDetailNodes.item(0), false, null, null, null, doc);
				docmentaionNodes = doc.getElementsByTagName("documentation");
			}

			if (dtccMatrixParticipantNodes != null && dtccMatrixParticipantNodes.getLength() > 0)
			{
				docmentaionNodes.item(0).removeChild(doc.getElementsByTagName("dtccMatrixParticipant").item(0));
			}
			
			if (mstrAgrmntDateNodes != null && mstrAgrmntDateNodes.getLength() > 0)
			{
				docmentaionNodes.item(0).removeChild(doc.getElementsByTagName("masterAgreementDate").item(0));
			}

			addNode("contractualTermsSupplementType", docmentaionNodes.item(0), true, pdfDoc, null, null, doc);
			addNode("dtccMatrixParticipant", docmentaionNodes.item(0), true, "true", null, null, doc);
			addNode("masterAgreementDate", docmentaionNodes.item(0), true, confDate, null, null, doc);

			if (null != tradeHeaderNodes)
			{
				// iterate the contractualTermsSupplementType
				for (int i = 0; i < tradeHeaderNodes.getLength();)
				{
					element = (Element) tradeHeaderNodes.item(i);
					commentNodes = element.getElementsByTagName("comment");

					if (null != commentNodes && null != commentNodes.item(0))
					{
						line = (Element) commentNodes.item(0);
						logger.debug("Replacing comment Node's value : " + getCharacterDataFromElement(line) + " with documentId of the paper doc");
						tradeHeaderNodes.item(0).removeChild(commentNodes.item(0));
					}

					break;
				}
			}

			addNode("comment", tradeHeaderNodes.item(0), true, docId, null, null, doc);
			decoratedMsg = generateXml(doc);
		}
		catch (TransformerFactoryConfigurationError | ParserConfigurationException | TransformerException | MessagingException | SAXException | IOException e)
		{
			logger.error("######### Failed to insert encoded pdf since " + e.getMessage());
		}

		return decoratedMsg;

	}

	private String getDecoratedElectonicMessage(String comment, String msgToDecorate, String confDate)
	{
		DocumentBuilderFactory docFactory 	= null;
		DocumentBuilder docBuilder 			= null;
		InputSource is 						= null;
		Document doc 						= null;
		NodeList tradeHeaderNodes 			= null;
		NodeList commentNodes 				= null;
		Element element 					= null;
		Element line 						= null;
		String decoratedMsg 				= null;
		NodeList docmentaionNodes 			= null;
		NodeList mstrAgrmntDateNodes 		= null;
		NodeList tradeDetailNodes 			= null;
		
		try
		{
			docFactory = DocumentBuilderFactory.newInstance();
			docBuilder = docFactory.newDocumentBuilder();

			is = new InputSource();
			is.setCharacterStream(new StringReader(msgToDecorate));

			doc = docBuilder.parse(is);
			docmentaionNodes 	= doc.getElementsByTagName("documentation");
			tradeHeaderNodes 	= doc.getElementsByTagName("tradeHeader");
			mstrAgrmntDateNodes = doc.getElementsByTagName("masterAgreementDate");
			tradeDetailNodes 	= doc.getElementsByTagName("tradeDetail");
			
			if (null == docmentaionNodes || docmentaionNodes.getLength() == 0)
			{
				addNode("documentation", tradeDetailNodes.item(0), false, null, null, null, doc);
				docmentaionNodes = doc.getElementsByTagName("documentation");
			}
			
			if (mstrAgrmntDateNodes != null && mstrAgrmntDateNodes.getLength() > 0)
			{
				docmentaionNodes.item(0).removeChild(doc.getElementsByTagName("masterAgreementDate").item(0));
			}
						
			addNode("masterAgreementDate", docmentaionNodes.item(0), true, confDate, null, null, doc);
			
			if (null == tradeHeaderNodes || tradeHeaderNodes.getLength() == 0)
				throw new MessagingException("cnfMsgDcd:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Invalid confirm message, as no Trade Header block was found");

			if (null != tradeHeaderNodes)
			{
				// iterate the contractualTermsSupplementType
				for (int i = 0; i < tradeHeaderNodes.getLength();)
				{
					element = (Element) tradeHeaderNodes.item(i);
					commentNodes = element.getElementsByTagName("comment");

					if (null != commentNodes && null != commentNodes.item(0))
					{
						line = (Element) commentNodes.item(0);
						logger.debug("Replacing comment Node's value : " + getCharacterDataFromElement(line) + " with documentId of the paper doc");
						tradeHeaderNodes.item(0).removeChild(commentNodes.item(0));
					}

					break;
				}
			}
			
			addNode("comment", tradeHeaderNodes.item(0), true, comment, null, null, doc);
			decoratedMsg = generateXml(doc);

		}
		catch (TransformerFactoryConfigurationError | ParserConfigurationException | TransformerException | MessagingException | SAXException | IOException e)
		{
			logger.error("Failed to insert comment for confirm message" + e.getMessage());
		}

		return decoratedMsg;
	}

	/**
	 * @param doc
	 * @param outWriter
	 * @return
	 * @throws TransformerFactoryConfigurationError
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	private static String generateXml(Document doc) throws TransformerFactoryConfigurationError, TransformerConfigurationException, TransformerException
	{
		StringWriter outWriter 					= new StringWriter();
		TransformerFactory transformerFactory 	= TransformerFactory.newInstance();
		Transformer transformer 				= transformerFactory.newTransformer();
		DOMSource source 						= new DOMSource(doc);
		StreamResult result 					= new StreamResult(outWriter);
		transformer.transform(source, result);

		StringBuffer sb = outWriter.getBuffer();
		
		return sb.toString();
	}

	public static String getCharacterDataFromElement(Element e)
	{
		String val = null;

		if (null == e) return val;

		Node child = e.getFirstChild();
		org.w3c.dom.CharacterData cd;
		
		if (child instanceof org.w3c.dom.CharacterData)
		{
			cd = (org.w3c.dom.CharacterData) child;
			val = cd.getData();
		}

		return val;
	}

	public static void addNode(String nodeName, Node parentNode, boolean isLeaf, String leafValue, String attribName, String attribVal, Document doc)
	{
		Element childNode = doc.createElement(nodeName);
		
		if(null != childNode)
		{
			parentNode.appendChild(childNode);
			
			if (isLeaf) 
				childNode.appendChild(doc.createTextNode(leafValue));
			else if (null != attribName) 
				childNode.setAttribute(attribName, attribVal);
		}
	}

	private boolean fetchDocument(String documentId, String tradeId)
	{
		String FQFN = filePath + File.separator + documentId + ".pdf";
		File file 	= new File(FQFN);
		if (file.exists()) return true;

		try
		{
			GetFileAsAttachment message = new GetFileAsAttachment();
			message.setString(documentId);
			GetFileAsAttachmentResponse response = null;

			/* START Bypass Security - Host name verification */
			if (!hostnameVerifierFlag && "true".equalsIgnoreCase(bypassSecurity))
			{
				HostnameVerifier verifier = new SkipHostNameVerifier();
				HttpsUrlConnectionMessageSender sender = new HttpsUrlConnectionMessageSender();
				sender.setHostnameVerifier(verifier);
				webServiceTemplate.setMessageSender(sender);
				hostnameVerifierFlag = true;
			}
			/* END Bypass Security - Host name verification */

			if ((response = (GetFileAsAttachmentResponse) webServiceTemplate.marshalSendAndReceive((message))) != null)
			{
				if (response.saveFile(FQFN))
				{
					logger.debug("Commodities: Saved PDF file @ location [" + FQFN + "]");
					return true;
				}
			}
		}
		catch (Exception e)
		{
			logger.error("ConfirmMessagedecorater, Failed to fetch Document[" + documentId + ".pdf] since " + e.getMessage());
			logger.error("Exception", e);
		}

		return false;

	}

	public void setWebServiceTemplate(WebServiceTemplate webServiceTemplate)
	{
		this.webServiceTemplate = webServiceTemplate;
	}

	public void setBypassSecurity(String bypassSecurity)
	{
		this.bypassSecurity = bypassSecurity;
	}

}
