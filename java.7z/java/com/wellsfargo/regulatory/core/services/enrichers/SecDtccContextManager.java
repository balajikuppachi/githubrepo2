package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.JURISDICTION_SEC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

@Component
public class SecDtccContextManager  extends RegRepContextManager
{
	private static Logger logger = Logger.getLogger(SecDtccContextManager.class.getName());
	
	private static final String JURISDICTION 	= JURISDICTION_SEC;	
	private static final String REPOSITORY 		= DTCC;
	private static final String CURR_JUR_FIELD 	= "currJurisdiction";
	
	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		logger.debug("Entering updateContext() method");

		String 				regulatory 	= null;
		ReportingContext 	context 	= null;
		ReportingContext 	secJurisdictionContext
										= null;		
		Message<?> 			messageOut 	= null;	
		List<String> 		jurList		= new ArrayList<String>(2);

		if(null == message)
			return message;

		context = (ReportingContext) message.getPayload();

		// Move this to constants file.
		regulatory = JURISDICTION + UNDERSCORE + REPOSITORY;
		
		/*
		 * Getting a new context exclusively for this flow.
		 */
		secJurisdictionContext = getNewContext(context, context.getMessageId(), regulatory, true);
		
		//clear the RulesResult context from existing context
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");
		secJurisdictionContext.setRulesResultsContext(rulesResultsContext);
		
		if(null == secJurisdictionContext.getReportingStatus())
			secJurisdictionContext.setReportingStatus(new ReportingStatus());
			
		secJurisdictionContext.getReportingStatus().setReportReason(NotReportingReasonEnum.FILTERD_TRADE);
		secJurisdictionContext.getReportingStatus().setReportStatus(false);
		
		jurList.add(JURISDICTION);
		
		secJurisdictionContext.setEsmaReportable(false);
		
		updateContext(secJurisdictionContext, CURR_JUR_FIELD, jurList);

		messageOut = MessageBuilder.withPayload(secJurisdictionContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Leaving updateContext() method");

		return messageOut;		
	}

}
