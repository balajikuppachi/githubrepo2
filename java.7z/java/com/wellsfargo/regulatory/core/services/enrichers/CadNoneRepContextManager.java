package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class CadNoneRepContextManager extends RegRepContextManager
{
	private static Logger logger = Logger.getLogger(CadNoneRepContextManager.class.getName());

	private static final String CURR_JUR_FIELD = "currJurisdiction";

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		ReportingContext context = null;
		ReportingContext cadDtccContext = null;
		Message<?> messageOut = null;
		String[] repInfo = null;
		List<String> jurList = new ArrayList<String>(5);
		Set<String> elgSet = null;
		String jurisdiction = null;
		// boolean cftcReportable = false;

		logger.debug("Creating a new context for CAD none reportable Flow");

		if (!(message.getPayload() instanceof ReportingContext)) return message;

		context = (ReportingContext) message.getPayload();

		/*** Getting a new context exclusively for this flow. ***/
		cadDtccContext = getNewContext(context, context.getMessageId(), NULL, true);

		//clear the RulesResult context from existing context
				RulesResultsContext rulesResultsContext = new RulesResultsContext();
				rulesResultsContext.setResultsSource("SDR_REQ");
				cadDtccContext.setRulesResultsContext(rulesResultsContext);

		if (null != context.getRegulatories())
		{
			elgSet = context.getRegulatories().keySet();

			for (String reg : elgSet)
			{
				if (null == reg) continue;

				repInfo = reg.split(UNDERSCORE);

				if (null == repInfo) continue;

				if (repInfo.length > 0 && null != repInfo[0])
				{
					jurisdiction = repInfo[0];

					if (JurisdictionEnum.CAD_CA.value().equals(jurisdiction) || JurisdictionEnum.CAD_NS.value().equals(jurisdiction) )
					{
						jurList.add(jurisdiction);
					}
				}
			}
		}

		updateContext(cadDtccContext, CURR_JUR_FIELD, jurList);
		messageOut = MessageBuilder.withPayload(cadDtccContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Successfully created new context for CAD Flow");

		return messageOut;

	}

}
