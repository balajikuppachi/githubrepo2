package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_CONF;
import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import java.util.ArrayList;
import java.util.List;

import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class ConfirmContextManager extends RegRepContextManager
{
	private static final String REPORT_TYPE = MESSAGE_TYPE_CONF;
	private static final String REPORT_TYPE_FIELD = "reportTypes";

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		String reportType = null;
		ReportingContext context = null;
		ReportingContext cfmContext = null;
		List<String> reportTypes = null;
		Message<?> messageOut = null;

		if(null == message)
			return message;

		context = (ReportingContext) message.getPayload();

		/*
		 * Getting a new context exclusively for this flow.
		 */

		cfmContext = getNewContext(context, context.getMessageId(), NULL, false);
		cfmContext.getReportTypes().clear();

		//clear the RulesResult context from existing context
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");
		cfmContext.setRulesResultsContext(rulesResultsContext);
		
		// Move this to constants file.
		reportType = REPORT_TYPE;

		reportTypes = new ArrayList<String>(1);
		reportTypes.add(reportType);

		updateContext(cfmContext, REPORT_TYPE_FIELD, reportTypes);

		messageOut = MessageBuilder.withPayload(cfmContext).copyHeadersIfAbsent(message.getHeaders()).build();

		return messageOut;

	}

}
