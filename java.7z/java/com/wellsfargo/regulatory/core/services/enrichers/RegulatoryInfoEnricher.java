package com.wellsfargo.regulatory.core.services.enrichers;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 *
 */
public class RegulatoryInfoEnricher {
	
//	public Message<?> updateRegulatoryInfo(Message<?> message){
//		RegulatoryType regData 	= ((SDRRequest)message.getPayload()).getRegRepData().getTrade().getRegulatory();
//		Message<?> messageOut 	= null;
//		String jurisdiction		= null;
//		String repository		= null;
//		try{
//			jurisdiction 	= enrichJurisdiction(regData);
//			repository		= enrichRepository(regData);
//			messageOut 		= populateHeaders(repository, jurisdiction, message);
//		}catch(MessagingException e){
//			throw new MessagingException("910", ExceptionSeverity.ERROR.toString(), e.getMessage(), 
//					(String)message.getHeaders().get("sdrMessageId"));			
//		}
//		
//		return messageOut;			
//	}
//	
//	private String enrichRepository(RegulatoryType regData)throws MessagingException{
//		String repository	= null;
//		
//		if(regData.getFirstReportedSDR().equalsIgnoreCase(Constants.REPOSITORY_DTCC)){
//			
//			repository =  Constants.REPOSITORY_DTCC;			
//		}else if(regData.getFirstReportedSDR().equalsIgnoreCase(Constants.REPOSITORY_ICE)){
//			
//			repository =  Constants.REPOSITORY_ICE;
//		}else{
//			throw new MessagingException("910", ExceptionSeverity.ERROR.toString(), "Unable to determine Repository");
//		}	
//		
//		KeywordType keywordType = new KeywordType();
//		Keyword key = new Keyword();
//		key.setName(Constants.DATA_REPOSITORY);
//		key.setValue(repository);
//		keywordType.setKeyword(key);
//		regData.getKeywords().add(keywordType);
//		
//		return repository;
//	}
//	
//	private String enrichJurisdiction(RegulatoryType regData){
//		String jurisdiction = null;
//		
//		if(regData.getEmirReportable().equalsIgnoreCase(Constants.TRUE)){
//			
//			jurisdiction = Constants.JURISDICTION_ESMA;		
//		}else if(regData.getCsaReportable().equalsIgnoreCase(Constants.TRUE)){
//			
//			jurisdiction = Constants.JURISDICTION_CFTC;
//		}else{
//			throw new MessagingException("789", ExceptionSeverity.ERROR.toString(), "Unable to determine Reporting Jurisdiction");
//		}
//		
//		KeywordType keywordType = new KeywordType();
//		Keyword key = new Keyword();
//		key.setName(Constants.REPORTING_JURISDICTION);
//		key.setValue(jurisdiction);
//		keywordType.setKeyword(key);
//		regData.getKeywords().add(keywordType);
//		
//		return jurisdiction;
//	}
//	
//	private Message<?> populateHeaders(String repository, String jurisdiction, Message<?> message){
//		Message<?> messageOut = MessageBuilder
//		.withPayload(message.getPayload())
//		.copyHeadersIfAbsent(message.getHeaders())
//		.setHeader(Constants.DATA_REPOSITORY, repository)
//		.setHeader(Constants.REPORTING_JURISDICTION,jurisdiction)
//		.build();
//		
//		return messageOut;		
//	}
}
