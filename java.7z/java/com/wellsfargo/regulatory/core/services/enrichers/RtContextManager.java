package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_RT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class RtContextManager extends RegRepContextManager
{
	private static Logger logger = Logger.getLogger(RtContextManager.class.getName());

	private static final String REPORT_TYPE = MESSAGE_TYPE_RT;
	private static final String REPORT_TYPE_FIELD = "reportTypes";

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		logger.debug("Entering updateContext() method");

		ReportingContext context 	= null;
		ReportingContext rtContext 	= null;
		List<String> reportTypes 	= null;
		Message<?> messageOut 		= null;

		if (null == message) return message;

		context = (ReportingContext) message.getPayload();
		
		/*** Getting a new context exclusively for this flow. ***/
		rtContext = getNewContext(context, context.getMessageId(), NULL, false);
		rtContext.getReportTypes().clear();
		
		//clear the RulesResult context from existing context
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");
		rtContext.setRulesResultsContext(rulesResultsContext);
		
		reportTypes = new ArrayList<String>(1);
		
		reportTypes.add(REPORT_TYPE);

		updateContext(rtContext, REPORT_TYPE_FIELD, reportTypes);

		messageOut = MessageBuilder.withPayload(rtContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Leaving updateContext() method");

		return messageOut;
	}
}
