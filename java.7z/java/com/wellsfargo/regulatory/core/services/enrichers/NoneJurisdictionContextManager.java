package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.NONE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.List;

import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class NoneJurisdictionContextManager extends RegRepContextManager
{
	private static final String JURISDICTION 		= NONE;	
	private static final String REGULATORY_FIELD 	= "regulatories";
	private static final String CURR_JUR_FIELD 		= "currJurisdiction";

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		String 				regulatory 	= null;
		ReportingContext 	context 	= null;
		ReportingContext 	noneJurisdictionContext
										= null;
		List<String> 		newRegulatories
										= null;
		Message<?> 			messageOut 	= null;
		String				repository	= null;
		List<String> 		jurList		= new ArrayList<String>(2);

		if(null == message)
			return message;

		context = (ReportingContext) message.getPayload();

		/*
		 * Getting a new context exclusively for this flow.
		 */
		noneJurisdictionContext = getNewContext(context, context.getMessageId(), NULL, true);
		
		//clear the RulesResult context from existing context
				RulesResultsContext rulesResultsContext = new RulesResultsContext();
				rulesResultsContext.setResultsSource("SDR_REQ");
				noneJurisdictionContext.setRulesResultsContext(rulesResultsContext);

		// Based on the assumption - in case of NONE only one jurisdiction is populated!
		if(null != context.getSdrRequest()){			
			if(null != context.getSdrRequest().getTrade()){				
				if(null != context.getSdrRequest().getTrade().getRegulatory()){					
					if(null != context.getSdrRequest().getTrade().getRegulatory().getReportingEligibility()
							&& context.getSdrRequest().getTrade().getRegulatory().getReportingEligibility().size() > 0){
						
						if(null != context.getSdrRequest().getTrade().getRegulatory().getReportingEligibility().get(0).getRepository()){
							
							repository = context.getSdrRequest().getTrade().getRegulatory().getReportingEligibility().get(0).getRepository().value();
						}
							
					}
				}
			}
		}		
		
		// Move this to constants file.
		regulatory = JURISDICTION + UNDERSCORE + repository;

		newRegulatories 	= new ArrayList<String>(1);

		// Making NONE_NONE as the first regulatory in this flow
		newRegulatories.clear();
		newRegulatories.add(0, regulatory);

		updateContext(noneJurisdictionContext, REGULATORY_FIELD, newRegulatories);
		//updateContext(noneJurisdictionContext, RPTY_FIELD, (new Boolean(false)));
		
		if(null == noneJurisdictionContext.getReportingStatus())
			noneJurisdictionContext.setReportingStatus(new ReportingStatus());
			
		noneJurisdictionContext.getReportingStatus().setReportReason(NotReportingReasonEnum.FILTERD_TRADE);
		noneJurisdictionContext.getReportingStatus().setReportStatus(false);
			
		jurList.add(JURISDICTION);		
		updateContext(noneJurisdictionContext, CURR_JUR_FIELD, jurList);

		messageOut = MessageBuilder.withPayload(noneJurisdictionContext)
				.copyHeadersIfAbsent(message.getHeaders()).build();

		return messageOut;

	}

}
