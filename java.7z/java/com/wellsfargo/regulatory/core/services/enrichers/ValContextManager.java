package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_VALUATION;
import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class ValContextManager  extends RegRepContextManager 
{
	private static Logger logger = Logger.getLogger(ValContextManager.class.getName());

	private static final String REPORT_TYPE = MESSAGE_TYPE_VALUATION;
	private static final String REPORT_TYPE_FIELD = "reportTypes";

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		logger.debug("Entering updateContext() method");

		String reportType 			= null;
		ReportingContext context 	= null;
		ReportingContext ssContext 	= null;
		List<String> reportTypes 	= null;
		Message<?> messageOut 		= null;
		
		if(null == message)
			return message;

		context = (ReportingContext) message.getPayload();

		/*
		 * Getting a new context exclusively for this flow.
		 */

		ssContext = getNewContext(context, context.getMessageId(), NULL, false);
		ssContext.getReportTypes().clear();

		//clear the RulesResult context from existing context
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");
		ssContext.setRulesResultsContext(rulesResultsContext);

		// Move this to constants file.
		reportType = REPORT_TYPE;

		reportTypes = new ArrayList<String>(1);
		
		reportTypes.add(reportType);

		updateContext(ssContext, REPORT_TYPE_FIELD, reportTypes);

		messageOut = MessageBuilder.withPayload(ssContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Leaving updateContext() method");

		return messageOut;

	}

}
