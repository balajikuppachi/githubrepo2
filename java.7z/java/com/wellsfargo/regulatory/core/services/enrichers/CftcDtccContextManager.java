package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.CFTC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class CftcDtccContextManager extends RegRepContextManager 
{
	private static Logger logger = Logger.getLogger(CftcDtccContextManager.class.getName());

	private static final String JURISDICTION 		= CFTC;
	private static final String REPOSITORY 			= DTCC;
	private static final String REGULATORY_FIELD 	= "regulatories";
	private static final String CURR_JUR_FIELD 		= "currJurisdiction";

	public Message<?> updateContext(Message<?> message) throws MessagingException 
	{
		logger.debug("Entering updateContext() method");

		String regulatory 					= null;
		ReportingContext context 			= null;
		ReportingContext cftcDtccContext 	= null;
		Map<String, String> oldRegulatories = null;
		Map<String, String> newRegulatories = null;
		Message<?> messageOut 				= null;
		List<String> jurList 				= new ArrayList<String>(2);

		if (null == message)
			return message;

		context = (ReportingContext) message.getPayload();

		/*** Getting a new context exclusively for this flow. ***/
		cftcDtccContext = getNewContext(context, context.getMessageId(), NULL, true);
		// cftcDtccContext.getRegulatories().clear();
		
		/*** Clear the RulesResult context from existing context ***/
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");
		cftcDtccContext.setRulesResultsContext(rulesResultsContext);

		/*** Move this to constants file. ***/
		regulatory = JURISDICTION + UNDERSCORE + REPOSITORY;

		oldRegulatories = cftcDtccContext.getRegulatories();
		newRegulatories = new LinkedHashMap<String, String>(8);

		/*** Making CFTC_DTCC as the first regulatory in this flow ***/
		newRegulatories.put(regulatory, oldRegulatories.get(regulatory));
		
		for (String reg : oldRegulatories.keySet()) 
		{
			if (regulatory.equalsIgnoreCase(reg))
				continue;

			newRegulatories.put(reg, oldRegulatories.get(reg));
		}

		jurList.add(JURISDICTION);

		updateContext(cftcDtccContext, REGULATORY_FIELD, newRegulatories);
		updateContext(cftcDtccContext, CURR_JUR_FIELD, jurList);

		messageOut = MessageBuilder.withPayload(cftcDtccContext).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Leaving updateContext() method");

		return messageOut;

	}

}
