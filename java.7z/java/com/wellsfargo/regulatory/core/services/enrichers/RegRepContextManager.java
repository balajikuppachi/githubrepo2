package com.wellsfargo.regulatory.core.services.enrichers;

import java.beans.Statement;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;

public abstract class RegRepContextManager
{
	private static Logger logger = Logger.getLogger(RegRepContextManager.class.getName());
	
	protected void updateContext(ReportingContext context, String feildName, Object value)
	{
		Statement stmt = null;
		String setterPrefix = "set";
		feildName = setterPrefix + GeneralUtils.capitalizeFirstLetter(feildName);

		try
		{
			stmt = new Statement(context, feildName, new Object[] { value });
			stmt.execute();
			
			
		}
		catch (Exception e)
		{
			logger.error("########## Failed to update the property " + feildName + " on the objet " + context.getClass().getName());

		}

	}

	protected ReportingContext getNewContext(ReportingContext origCtxt, String messageId, String parentMessageId, boolean cloneSdrRequest)
	{
		ReportingContext newCtxt = null;

		if (null == origCtxt || null == messageId)
		{
			// - Log a message here
			return newCtxt;
		}

		newCtxt = origCtxt.getClone(messageId, parentMessageId, cloneSdrRequest);

	//	logger.debug("***** Successfully created the new context " + newCtxt);

		// START : Setting the MDC from the Context - As Context got updated
		if (null != newCtxt) AbstractDriver.setMDCInfo(newCtxt, AbstractDriver.RegRepContextManager);
		// END : Setting the MDC from the Context

		return newCtxt;
	}

}
