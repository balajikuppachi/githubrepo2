package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_PET;
import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import java.util.ArrayList;
import java.util.List;

import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class PetContextManager extends RegRepContextManager
{
	private static final String REPORT_TYPE = MESSAGE_TYPE_PET;
	private static final String REPORT_TYPE_FIELD = "reportTypes";

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		String reportType 			= null;
		ReportingContext context 	= null;
		ReportingContext petContext = null;
		List<String> reportTypes 	= null;
		Message<?> messageOut 		= null;

		if(null == message)
			return message;

		context = (ReportingContext) message.getPayload();


		/*
		 * Getting a new context exclusively for this flow.
		 */

		petContext = getNewContext(context, context.getMessageId(), 
				NULL, false);
		petContext.getReportTypes().clear();

		//clear the RulesResult context from existing context
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");
		petContext.setRulesResultsContext(rulesResultsContext);
		
		reportType = REPORT_TYPE;
		
		reportTypes = new ArrayList<String>(1);
		reportTypes.add(reportType);

		updateContext(petContext, REPORT_TYPE_FIELD, reportTypes);

		messageOut = MessageBuilder.withPayload(petContext).copyHeadersIfAbsent(message.getHeaders()).build();

		return messageOut;

	}

}
