/**
 *
 */
package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.cache.loader.DomainMappingCacheLoader;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * @author u337814
 */
public class RouterContextManager extends RegRepContextManager
{
	private static Logger logger = Logger.getLogger(RouterContextManager.class.getName());

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		logger.debug("Entering updateContext() method");

		ReportingContext context 	= null;
		Message<?> messageOut 		= null;
		ReportingContext routeCntxt = null;
		String rulesField 			= "RulesResultsContext";

		if (null == message) return message;

		context = (ReportingContext) message.getPayload();

		/*** Getting a new context exclusively for this flow. ***/
		routeCntxt = getNewContext(context, context.getMessageId(), NULL, false);

		updateContext(routeCntxt, rulesField, new RulesResultsContext());

		messageOut = MessageBuilder.withPayload(routeCntxt).copyHeadersIfAbsent(message.getHeaders()).build();

		logger.debug("Leaving updateContext() method");

		return messageOut;
	}
}
