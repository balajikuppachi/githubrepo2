/**
 *
 */
package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL;

import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * @author u337814
 */
public class FilterContextManager extends RegRepContextManager
{

	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		ReportingContext context = null;
		Message<?> messageOut = null;
		ReportingContext routeCntxt = null;
		String rulesField = "ContextType";

		if (null == message) return message;

		context = (ReportingContext) message.getPayload();

		/*
		 * Getting a new context exclusively for this flow.
		 */

		routeCntxt = getNewContext(context, context.getMessageId(), NULL, false);
		updateContext(routeCntxt, rulesField, PayloadTypeEnum.REG_REP_FILTERED);
		messageOut = MessageBuilder.withPayload(routeCntxt).copyHeadersIfAbsent(message.getHeaders()).build();

		return messageOut;

	}
}
