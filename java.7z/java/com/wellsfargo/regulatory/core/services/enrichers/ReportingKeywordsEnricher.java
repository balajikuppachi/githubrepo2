package com.wellsfargo.regulatory.core.services.enrichers;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeInfoType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FeeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.core.rules.util.KieSessionFactory;
import com.wellsfargo.regulatory.core.rules.util.KieSessionProvider;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

@Component
public class ReportingKeywordsEnricher
{
	private static Logger logger = Logger.getLogger(ReportingKeywordsEnricher.class.getName());

	public Message<?> enrich(Message<?> message) throws MessagingException
	{
		if (null == message) return message;

		ReportingContext ctxt = (ReportingContext) message.getPayload();

		// START : Setting the MDC from the Context - As Context got updated
		AbstractDriver.setMDCInfo(ctxt, AbstractDriver.ReportingKeywordsEnricher);
		// END : Setting the MDC from the Context

		logger.debug("Entering enrich() method");

		message = populateKeywords(message);

		try
		{
			enrichReportabilityData(message);
		}
		catch (MessagingException e)
		{
			logger.error("########## Failed to enrich reportability data");
		}

		logger.debug("Leaving enrich() method");

		return message;
	}

	public Message<?> populateKeywords(Message<?> message) throws MessagingException
	{
		logger.debug("Entering populateKeywords() method");

		if (null == message) return message;

		ReportingContext context 	= (ReportingContext) message.getPayload();
		SdrRequest request 			= context.getSdrRequest();
		ProductType prdType 		= null;

		try
		{
			prdType = request.getTrade().getTradeDetail().getProduct();
			addDtccPremiumPayerReceiverRef(request);
			addPremiumPayerReceiverRef(request);
		}
		catch (Exception e)
		{
			logger.error("########## Failed to populate keywords --> ", e);
		}

		try
		{
			if (Constants.PRODUCT_TYPE_FRA.equals(context.getProductType())) addPeriodInfo(request);

			if (null != prdType)
			{
				addPaymentFreqPeriod(prdType);
				addPaymentFreqMultiplier(prdType);
				addFloatingRateFields(prdType);
				addResetFreqPeriodAndMultiplier(prdType);
			}
			// fixDataForDemo(request);
		}
		catch (Exception e)
		{
			logger.error("Failed to populate keywords --> ", e);
		}

		logger.debug("Leaving populateKeywords() method");

		return message;
	}

	private void addResetFreqPeriodAndMultiplier(ProductType prdType)   throws MessagingException
	{
		logger.debug("Entering addResetFreqPeriodAndMultiplier() method");

		String resetFrequency 	= null;
		List<Keyword> keys 		= prdType.getKeywords().getKeyword();
		Keyword periodKW 		= null;
		Keyword multiplierKW 	= null;
		int legSize 			= prdType.getLeg().size();

		try
		{
			if (null != prdType.getProduct())
			{
				for (ProductType prd : prdType.getProduct())
				{
					addResetFreqPeriodAndMultiplier(prd);
				}
			}

			for (int i = 0; i < legSize; i++)
			{
				periodKW 		= new Keyword();
				multiplierKW 	= new Keyword();
				
				String resetFreqPeriod 		= null;
				String resetFreqMultiplier 	= null;
				resetFrequency 				= prdType.getLeg().get(i).getResetFrequency();
				
				if (resetFrequency != null )
				{
					if (resetFrequency.indexOf(Constants.COLON) >= 0 && resetFrequency.length() > 1)
					{
						resetFreqMultiplier = resetFrequency.substring(0,resetFrequency.indexOf(Constants.COLON) );
						resetFreqPeriod = resetFrequency.substring(resetFrequency.indexOf(Constants.COLON) + 1, resetFrequency.length());
					}
				}
				
				if (resetFreqPeriod != null && resetFreqMultiplier != null)
				{
					periodKW.setName(Constants.RESET_FREQ_PERIOD + (i+1));
					periodKW.setValue(resetFreqPeriod);
					
					multiplierKW.setName(Constants.RESET_FREQ_MULTIPLIER + (i+1));
					multiplierKW.setValue(resetFreqMultiplier);
					
					keys.add(periodKW);
					keys.add(multiplierKW);
				}
			}
		}
		catch (Exception e)
		{
			throw new MessagingException("124", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while poplulating reset frequency Period and Multiplier", e.getMessage(), null);
		}

		logger.debug("Leaving addResetFreqPeriodAndMultiplier() method");
	}

	@SuppressWarnings("unused")
	private void fixDataForDemo(SdrRequest request)
	{
		String eventStatus = request.getTrade().getTradeHeader().getStatus();
		
		String s[] =
		{ "CH_TOBE_VER", "PENDING", "DAY_PENDING", "MO_REVIEW", "DAY_MO_REVIEW", "TRADER_REVIEW", "DAY_TRADER_REVIEW", "ASSIGNED", "SHADOW_TERM", "TERMINATED", "PENDING", "PARTIAL_TERM", "SHADOW_SDR" };
		
		boolean validStatus = false;
		for (int i = 0; i < s.length; i++)
		{
			if (eventStatus.equals(s[i]))
			{
				validStatus = true;
				break;
			}
		}
		
		if (!validStatus)
		{
			request.getTrade().getTradeHeader().setStatus("PENDING");
			logger.debug("******* Demo purpose setting the trade header status to PENDING ***************");
		}

		ProductType prdType = request.getTrade().getTradeDetail().getProduct();
		String productType = null;

		if (null != prdType && prdType.getLeg().size() > 0)
		{
			productType = prdType.getProductType();

			if (prdType.getLeg().get(0).getFixedRate() != null)
			{
				if (prdType.getLeg().get(0).getFixedRate().intValue() == 0)
				{
					prdType.getLeg().get(0).setFixedRate(BigDecimal.valueOf(0.685));
					logger.debug("*******Demo purpose setting the trade Leg 1 fixedRate to 0.685 ***************");
				}
			}
			else if ("ForeignExchange".equals(request.getAssetClass()))
			{
				prdType.getLeg().get(0).setFixedRate(BigDecimal.valueOf(.567));
				logger.debug("*******Demo purpose setting the trade Leg 1 adding fixedRate ***************");
			}
		}

		if ("FXOption".equals(productType) || "Swaption".equals(productType))
		{
			FeeInfoType feesType = request.getTrade().getTradeDetail().getFeeInfo();
			if (feesType == null)
			{
				FeeType fee = new FeeType();
				fee.setType("PREMIUM");
				fee.setAmount(new BigDecimal(100.0));
				fee.setCurrency("INR");
				fee.setDate(CalendarUtils.toXMLGregorianCalendar(new Date()));
				fee.setPayerLEI(request.getTrade().getTradeHeader().getProcessingOrgLEI());
				fee.setReceiverLEI(request.getTrade().getTradeHeader().getCounterpartyLEI());
				feesType = new FeeInfoType();
				feesType.getFee().add(fee);
				request.getTrade().getTradeDetail().setFeeInfo(feesType);
				
				logger.debug("*******Demo purpose adding the Premium FEE BLOCK ***************");
			}
		}

	}

	private void addDtccPremiumPayerReceiverRef(SdrRequest request) throws MessagingException
	{
		String processingOrgLei = null;
		String counterPartyLei 	= null;
		String wfParticipantId 	= null;
		String cpParticipantId 	= null;
		List<FeeType> fees 		= null;
		
		try
		{
			processingOrgLei 	= request.getTrade().getTradeHeader().getProcessingOrgLEI();
			counterPartyLei 	= request.getTrade().getTradeHeader().getCounterpartyLEI();

			if (null == processingOrgLei) throw new RuntimeException("ProcessingOrgLEI is null");
			if (null == counterPartyLei) throw new RuntimeException("CounterPartyLEI is null");

			List<TradePartyType> parties = request.getTrade().getTradeDetail().getTradeParties().getParty();

			if (null == parties) throw new RuntimeException("Parties is null");

			for (TradePartyType party : parties)
			{
				if (processingOrgLei.equals(party.getLEI()))
				{
					wfParticipantId = party.getDtccParticipantId();
				}
				else if (counterPartyLei.equals(party.getLEI()))
				{
					cpParticipantId = party.getDtccParticipantId();
				}
				if (wfParticipantId != null && cpParticipantId != null)
				{
					break;
				}
			}

			if (request.getTrade().getTradeDetail().getFeeInfo() == null) return;

			fees = request.getTrade().getTradeDetail().getFeeInfo().getFee();
			if (null == fees) return;

			int keyWordsCount = 0;

			for (int i = 0; i < fees.size(); i++)
			{
				if (!"PREMIUM".equals(fees.get(i).getType())) continue;
				if (wfParticipantId == null && cpParticipantId == null) continue;
				
				// avoiding null pointer here.
				// Adding null checks
				if (!(null!= wfParticipantId && wfParticipantId.equals(fees.get(i).getPayerLEI())) && !(null != cpParticipantId && cpParticipantId.equals(fees.get(i).getPayerLEI())) 
						|| !(null != wfParticipantId && wfParticipantId.equals(fees.get(i).getReceiverLEI())) && !(null != cpParticipantId && cpParticipantId.equals(fees.get(i).getReceiverLEI()))) continue;
				
				keyWordsCount++;
				
				addPremiumPayReceiveKeyword(fees.get(i), wfParticipantId, cpParticipantId, keyWordsCount, request.getTrade().getTradeDetail().getProduct().getKeywords().getKeyword());
			}
		}
		catch (Exception e)
		{
			throw new MessagingException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while poplulating Preminum Payer Receiver");
		}
	}

	private void addPremiumPayerReceiverRef(SdrRequest request) throws MessagingException
	{
		String processingOrgLei = null;
		String counterPartyLei 	= null;
		List<FeeType> fees 		= null;
		String payerLei 		= null;
		String receiverLei 		= null;
		
		try
		{
			processingOrgLei 	= request.getTrade().getTradeHeader().getProcessingOrgLEIValue();
			counterPartyLei 	= request.getTrade().getTradeHeader().getCounterpartyLEIValue();
			
			if (processingOrgLei == null)
				processingOrgLei = request.getTrade().getTradeHeader().getProcessingOrgLEI();
			
			if (counterPartyLei == null)
				counterPartyLei = request.getTrade().getTradeHeader().getCounterpartyLEI();
			
			if (null == processingOrgLei) throw new RuntimeException("ProcessingOrgLEI is null");
			if (null == counterPartyLei) throw new RuntimeException("CounterPartyLEI is null");
			
			if (request.getTrade().getTradeDetail().getFeeInfo() == null) return;
			
			fees = request.getTrade().getTradeDetail().getFeeInfo().getFee();
			if (null == fees) return;

			int keyWordsCount = 0;

			for (int i = 0; i < fees.size(); i++)
			{
				if (!"PREMIUM".equals(fees.get(i).getType())) continue;
				
				payerLei 		= (fees.get(i).getPayerLEIValue() != null) ? fees.get(i).getPayerLEIValue(): fees.get(i).getPayerLEI();
				receiverLei 	= (fees.get(i).getReceiverLEIValue() != null ) ? fees.get(i).getReceiverLEIValue():fees.get(i).getReceiverLEI();
				
				if (!(processingOrgLei).equals(payerLei) && !(counterPartyLei).equals(payerLei) || !processingOrgLei.equals(receiverLei)
				        && !counterPartyLei.equals(receiverLei)) continue;
				
				keyWordsCount++;
				
				addPremiumPayReceiveKeyword(fees.get(i), processingOrgLei, counterPartyLei, keyWordsCount, request.getTrade().getTradeDetail().getProduct().getKeywords().getKeyword());
			}
		}
		catch (Exception e)
		{
			throw new MessagingException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while poplulating Preminum Payer Receiver", e.getMessage(), null);
		}
	}

	private void addPremiumPayReceiveKeyword(FeeType feeType, String wfParticipantId, String cpParticipantId, int i, List<Keyword> keyword)
	{
		Keyword keyword1 = null, keyword2 = null;

		if (wfParticipantId.equals(feeType.getPayerLEI()) || cpParticipantId.equals(feeType.getReceiverLEI()))
		{
			keyword1 = new Keyword();
			keyword1.setName(Constants.PREMIUM_PAYER + (i));
			keyword1.setValue(Constants.PARTY1);
			
			keyword2 = new Keyword();
			keyword2.setName(Constants.PREMIUM_RECEIVER + (i));
			keyword2.setValue(Constants.PARTY2);
		}
		else
		{
			keyword1 = new Keyword();
			keyword1.setName(Constants.PREMIUM_PAYER + (i));
			keyword1.setValue(Constants.PARTY2);
			
			keyword2 = new Keyword();
			keyword2.setName(Constants.PREMIUM_RECEIVER + (i));
			keyword2.setValue(Constants.PARTY1);
		}
		
		if (null != keyword1) keyword.add(keyword1);
		if (null != keyword2) keyword.add(keyword2);

	}

	private void addPaymentFreqMultiplier(ProductType prdType) throws MessagingException
	{
		logger.debug("Entering addPaymentFreqMultiplier() method");

		String paymentFrequency 	= null;
		List<Keyword> keys 			= prdType.getKeywords().getKeyword();
		Keyword periodMultiplierKW 	= null;
		DomainMappingCache cache 	= null;
		int legSize = prdType.getLeg().size();

		cache = DomainMappingCache.getInstance();

		try
		{
			if (null != prdType.getProduct())
			{
				for (ProductType prd : prdType.getProduct())
				{
					addPaymentFreqMultiplier(prd);
				}
			}

			for (int i = 0; i < legSize; i++)
			{
				periodMultiplierKW 	= new Keyword();
				String periodFreq 	= null;
				paymentFrequency 	= prdType.getLeg().get(i).getPaymentFrequency();

				if (null != paymentFrequency) periodFreq = cache.getValue( Constants.PERIOD_MULTIPLIER + Constants.UNDERSCORE + paymentFrequency);

				periodMultiplierKW.setName(Constants.PAYMENT_FREQ_MULTIPLIER + (i + 1));

				if (null != periodFreq)
				{
					periodMultiplierKW.setValue(periodFreq);
				}
				else
				{
					periodMultiplierKW.setValue(Constants.EMPTY_STRING);
				}

				keys.add(periodMultiplierKW);
			}
		}
		catch (Exception e)
		{
			throw new MessagingException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while poplulating payment frequency Multiplier", e.getMessage(), null);
		}

		logger.debug("Leaving addPaymentFreqMultiplier() method");
	}

	private void addFloatingRateFields(ProductType prdType) throws MessagingException
	{
		logger.debug("Entering addFloatingRateFields() method");

		String indexCurrency 		= null;
		String indexName 			= null;
		String indexSource 			= null;
		Keyword multiplierKW 		= null;
		Keyword periodKW 			= null;
		String period 				= "";
		String multiplier 			= "";
		String indexTenor 			= null;
		String floatingRateIndex 	= null;
		List<Keyword> keys 			= prdType.getKeywords().getKeyword();
		Keyword floatingRateIndexKW = null;
		int legSize 				= prdType.getLeg().size();
		DomainMappingCache cache 	= null;
		
		cache = DomainMappingCache.getInstance();
		
		try
		{

			if (null != prdType.getProduct())
			{
				for (ProductType prd : prdType.getProduct())
				{
					addFloatingRateFields(prd);
				}
			}

			for (int i = 0; i < legSize; i++)
			{
				floatingRateIndexKW = new Keyword();
				indexCurrency 		= prdType.getLeg().get(i).getIndexCurrency();
				indexName 			= prdType.getLeg().get(i).getIndexName();
				indexSource 		= prdType.getLeg().get(i).getIndexSource();

				if (null != indexCurrency && null != indexName && null != indexSource)
				{
					floatingRateIndexKW.setName(Constants.FLOATING_RATE_INDEX + (i + 1));

					floatingRateIndex = cache.getValue( Constants.FLOATING_RATE_INDEX + Constants.UNDERSCORE + indexCurrency + Constants.HYPHEN + indexName + Constants.HYPHEN + indexSource);
					
					if (null == floatingRateIndex )
					{
						floatingRateIndex = indexCurrency + Constants.HYPHEN + indexName + Constants.HYPHEN + indexSource;
					}
						
					floatingRateIndexKW.setValue(floatingRateIndex);
					
					keys.add(floatingRateIndexKW);
				}

				indexTenor = prdType.getLeg().get(i).getIndexTenor();

				if (null != indexTenor)
				{
					for (String c : indexTenor.split("[a-zA-Z]*"))
					{
						if (StringUtils.isBlank(c)) continue;

						multiplier = multiplier + c;
					}

					for (String c : indexTenor.split("[0-9]*"))
					{
						if (StringUtils.isBlank(c)) continue;

						period = period + c;
					}

					periodKW 		= new Keyword();
					multiplierKW 	= new Keyword();
					
					periodKW.setName(Constants.INDEX_PERIOD + (i + 1));
					periodKW.setValue(period);
					
					multiplierKW.setName(Constants.INDEX_MULTIPLIER + (i + 1));
					multiplierKW.setValue(multiplier);
					
					keys.add(periodKW);
					keys.add(multiplierKW);
				}
				
				// reset the values
				period 		= "";
				multiplier 	= "";
			}
		}
		catch (Exception e)
		{
			throw new MessagingException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while poplulating floating rate fields", e.getMessage(), null);
		}

		logger.debug("Leaving addFloatingRateFields() method");
	}

	private void addPaymentFreqPeriod(ProductType prdType) throws MessagingException
	{
		logger.debug("Entering addPaymentFreqPeriod() method");

		String paymentFrequency = null;
		List<Keyword> keys 		= prdType.getKeywords().getKeyword();
		Keyword periodKW 		= null;
		DomainMappingCache cache = null;
		String periodFreq 		= null;
		int legSize 			= prdType.getLeg().size();

		try
		{
			cache = DomainMappingCache.getInstance();

			if (null != prdType.getProduct())
			{
				for (ProductType prd : prdType.getProduct())
				{
					addPaymentFreqPeriod(prd);
				}
			}

			for (int i = 0; i < legSize; i++)
			{
				periodKW 			= new Keyword();
				paymentFrequency 	= prdType.getLeg().get(i).getPaymentFrequency();

				if (null != paymentFrequency) periodFreq = cache.getValue(Constants.PAYMENT_PERIOD + Constants.UNDERSCORE + paymentFrequency);

				periodKW.setName(Constants.PAYMENT_FREQ_PERIOD + (i + 1));

				if (null != periodFreq)
				{
					periodKW.setValue(periodFreq);
				}
				else
				{
					periodKW.setValue(Constants.EMPTY_STRING);
				}

				keys.add(periodKW);
			}

		}
		catch (Exception e)
		{
			throw new MessagingException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while poplulating frequency period", e.getMessage(), null);
		}

		logger.debug("Leaving addPaymentFreqPeriod() method");

	}

	private SdrRequest addPeriodInfo(SdrRequest request) throws MessagingException
	{
		logger.debug("Entering addPeriodInfo() method");

		List<Keyword> keys 	= null;
		String indexTenor 	= null;
		Keyword period 		= new Keyword();
		Keyword periodMultiplier = new Keyword();
		String time 		= "";
		String multiplier 	= "";

		try
		{
			indexTenor 	= request.getTrade().getTradeDetail().getProduct().getLeg().get(0).getIndexTenor();
			keys 		= request.getTrade().getRegulatory().getKeywords().getKeyword();

			if (null == indexTenor) throw new RuntimeException("Index Tenor not found");

			for (String c : indexTenor.split("[a-zA-Z]*"))
			{
				if (StringUtils.isBlank(c)) continue;
				multiplier = multiplier + c;
			}

			for (String c : indexTenor.split("[0-9]*"))
			{
				if (StringUtils.isBlank(c)) continue;

				time = time + c;
			}

			period.setName("period");
			period.setValue(time);

			periodMultiplier.setName("periodMultiplier");
			periodMultiplier.setValue(multiplier);

			keys.add(period);
			keys.add(periodMultiplier);

		}
		catch (Exception e)
		{
			throw new MessagingException("123", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					"Error while poplulating period keywords", e.getMessage(), null);
		}

		logger.debug("Leaving addPeriodInfo() method");

		return request;
	}

	/*
	 * @SuppressWarnings("unchecked") public Message<?> enrichReportabilityData(Message<?> message)
	 * throws MessagingException { logger.debug("Entering enrichReportabilityData() method");
	 * StatefulKnowledgeSession session; ReportingContext context = (ReportingContext)
	 * message.getPayload(); String messageId = context.getMessageId(); try { String key =
	 * getDrlKey(message, Constants.RULE_TYPE_ENRICH); DRLCache cache = DRLCache.getInstance();
	 * List<String> drlFilesString = cache.getValues(key); DroolsDriverImpl drlDriver = new
	 * DroolsDriverImpl(); drlDriver.initDrools(drlFilesString, DroolsDriver.SESSION_TYPE_STATEFULL,
	 * ResourceType.DRL, context); session = drlDriver.getStateFulKnowledgeSession();
	 * session.execute(CommandFactory.newInsert(context));
	 * session.execute(CommandFactory.newFireAllRules()); session.dispose(); } catch (Exception e) {
	 * // TODO : Tweak until enricher is fixed throw new MessagingException("80R",
	 * ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage(), messageId, e);
	 * // -- Enriched fixed // context.getReportTypes().add("RT"); } //
	 * LOGGER.debug("Leaving decideReport() method");
	 * logger.debug("Leaving enrichReportabilityData() method"); return message; }
	 */

	public Message<?> enrichReportabilityData(Message<?> message) throws MessagingException
	{
		logger.debug("Entering enrichReportabilityData() method");

		ReportingContext context 	= (ReportingContext) message.getPayload();
		String messageId 			= context.getMessageId();

		try
		{
			// KnowledgeBase populateKbase = (KnowledgeBase)
			// RegulatoryBeanFactory.getBean("enrichKBase");
			// StatefulKnowledgeSession enrichKession = populateKbase.newStatefulKnowledgeSession();

			//KieServices ks = KieServices.Factory.get();
			//KieContainer kc = ks.getKieClasspathContainer();
			//KieSession enrichKession = kc.newKieSession("enrichKS");
			
			KieSession enrichKession = KieSessionFactory.getKieSession("enrichKS");
			enrichKession.insert(context);
			enrichKession.setGlobal("logger", logger);
			enrichKession.fireAllRules();
			
			/*** Releases all the current session resources, setting up the session for garbage collection. 
			 * This method must always be called after finishing using the session, or the engine will not free the memory used by the session. 
			 * If a logger has been registered on this session it will be automatically closed.
			 ***/
			enrichKession.dispose();
			
		}
		catch (Exception e)
		{
			// TODO : Tweak until enricher is fixed

			logger.error("**************************************************************************************************************");
			logger.error("Error while Enriching keywords : ", e);
			logger.error("**************************************************************************************************************");
			
			throw new MessagingException("80R", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage(), messageId, e, context.getSwapTradeId());
		}

		logger.debug("Leaving enrichReportabilityData() method");

		return message;
	}

	@SuppressWarnings("unused")
	private String getDrlKey(Message<?> message, String type) throws Exception
	{
		logger.debug("Entering getDrlKey() method");

		StringBuilder key 	= null;
		String jurisdiction = null;
		String repository 	= null;
		
		ReportingContext context 	= (ReportingContext) message.getPayload();
		String eligibilty 			= context.getRegulatories().get(0);

		// Assumption that by this time reporting context is set and hence
		// context will have only one regilatoryInfo
		jurisdiction 	= eligibilty.split("_")[0];
		repository 		= eligibilty.split("_")[1];

		if (StringUtils.isBlank(type) || StringUtils.isBlank(jurisdiction) || StringUtils.isBlank(repository)) 
			throw new Exception("Unable to determine key due to invalid incoming data");

		key = new StringBuilder(Constants.DRL + Constants.KEY_SEPERATOR);
		key.append(type + Constants.KEY_SEPERATOR);
		key.append(jurisdiction.toLowerCase() + Constants.KEY_SEPERATOR);
		key.append(repository.toLowerCase());

		logger.debug("Leaving getDrlKey() method");

		return key.toString();
	}
}
