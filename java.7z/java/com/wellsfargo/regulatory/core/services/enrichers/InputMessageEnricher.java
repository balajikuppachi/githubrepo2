package com.wellsfargo.regulatory.core.services.enrichers;


public class InputMessageEnricher {
	
//	Logger logger = Logger.getLogger(InputMessageEnricher.class);
//	
//	public InputMessageEnricher() {
//		
//	}
//	
//	public Message<?> enrichMessage(Message<?> message){
//		MessageOriginEnricher	msgOriginEnricher	= new MessageOriginEnricher();
//		RegulatoryInfoEnricher 	regEnricher 		= new RegulatoryInfoEnricher();
//		
//		msgOriginEnricher.updateMessageOrigin(message);
//		regEnricher.updateRegulatoryInfo(message);
//		
//		// Update for reporting/delegate reporting party
//		// Update for fee trade status
//		
//		return message;
//	}
}
