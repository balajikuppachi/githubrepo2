package com.wellsfargo.regulatory.core.services.enrichers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.ESMA;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.ArrayList;
import java.util.List;

import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ReportingStatus;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.enums.NotReportingReasonEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

public class EsmaDtccContextManager  extends RegRepContextManager{
	
	private static final String JURISDICTION 	= ESMA;	
	private static final String REPOSITORY 		= DTCC;
	private static final String CURR_JUR_FIELD 	= "currJurisdiction";
	
	
	public Message<?> updateContext(Message<?> message) throws MessagingException
	{
		String 				regulatory 	= null;
		ReportingContext 	context 	= null;
		ReportingContext 	esmaJurisdictionContext
										= null;		
		Message<?> 			messageOut 	= null;	
		List<String> 		jurList		= new ArrayList<String>(2);

		if(null == message)
			return message;

		context = (ReportingContext) message.getPayload();

		// Move this to constants file.
		regulatory = JURISDICTION + UNDERSCORE + REPOSITORY;
		
		/*
		 * Getting a new context exclusively for this flow.
		 */
		esmaJurisdictionContext = getNewContext(context, context.getMessageId(), regulatory, true);
		
		//clear the RulesResult context from existing context
		RulesResultsContext rulesResultsContext = new RulesResultsContext();
		rulesResultsContext.setResultsSource("SDR_REQ");
		esmaJurisdictionContext.setRulesResultsContext(rulesResultsContext);
		
		if(null == esmaJurisdictionContext.getReportingStatus())
			esmaJurisdictionContext.setReportingStatus(new ReportingStatus());
			
//		esmaJurisdictionContext.getReportingStatus().setReportReason(NotReportingReasonEnum.FILTERD_TRADE);
//		esmaJurisdictionContext.getReportingStatus().setReportStatus(false);
		
		jurList.add(JURISDICTION);
		
		esmaJurisdictionContext.setEsmaReportable(true);
		
		updateContext(esmaJurisdictionContext, CURR_JUR_FIELD, jurList);

		messageOut = MessageBuilder.withPayload(esmaJurisdictionContext)
				.copyHeadersIfAbsent(message.getHeaders()).build();

		return messageOut;		
	}

}
