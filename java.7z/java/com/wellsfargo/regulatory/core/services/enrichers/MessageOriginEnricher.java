package com.wellsfargo.regulatory.core.services.enrichers;


@SuppressWarnings("unused")
public class MessageOriginEnricher {
	
//	Logger logger = Logger.getLogger(MessageOriginEnricher.class);
//	
//	@Value("${sourcesystems.InterestRate}") private String srcSystemRates;
//	@Value("${sourcesystems.Credit}") private String srcSystemCredit;
//	@Value("${sourcesystems.Equity}") private String srcSystemEquities;
//	@Value("${sourcesystems.Commodity}") private String srcSystemCommodity;
//	
//	private Set<String> ratesSystems;
//	private Set<String> creditSystems;
//	private Set<String> equitySystems;
//	private Set<String> commoditySystems;
//	
//	public MessageOriginEnricher() {
//		ratesSystems = new HashSet<String>(Arrays.asList(srcSystemRates.split("\\b*,\\b")));
//		creditSystems = new HashSet<String>(Arrays.asList(srcSystemCredit.split("\\b*,\\b")));
//		equitySystems = new HashSet<String>(Arrays.asList(srcSystemEquities.split("\\b*,\\b")));
//		commoditySystems = new HashSet<String>(Arrays.asList(srcSystemCommodity.split("\\b*,\\b")));
//	}
//	
//	public SdrRequest updateMessageOrigin(Message<?> data) {	
//		
//		SdrRequest message 	= (SdrRequest)data.getPayload();
//		String sourceSystem = message.getSource();
//		String assetClass 	= message.getAssetClass();
//		String calypsoProd 	= message.getTrade().getTradeDetail().getProduct().getProductType();
//	
//		if (sourceSystem == null) {
//			throw new MessagingException("123A",ExceptionSeverity.ERROR.name(),
//					"Source system is not specified in the incoming data " + "SourceSystemId", message.getRegRepData().getMessageId());
//		}
//		
//		//TODO: SG Remove: Dubious lookup for now to handle v12 
//		if (Util.IsNullOrBlank(assetClass)) {
//			assetClass = getPrimaryAssetClass(calypsoProd);
//			logger.warn("V12 Dubious lookup returned assetclass for [" + calypsoProd + "] as : " + assetClass);
//		}
//		
//		String origin = getOriginBySourceSystem(sourceSystem, assetClass);
//		if (Util.IsNullOrBlank(origin) && Util.IsNullOrBlank(assetClass) ) {
//			throw new MessagingException("123A",ExceptionSeverity.ERROR.name(),
//					"Unexpected Asset Class: "+ assetClass + "Origin not found " + "SourceSystemId", message.getRegRepData().getMessageId());
//		}
//		if (origin == null) {
//			throw new MessagingException("123A",ExceptionSeverity.ERROR.name(),
//					"Unexpected source system: " + sourceSystem + "SourceSystemId", message.getRegRepData().getMessageId());
//		}
//		
//		KeywordType keywordType = new KeywordType();
//		Keyword key = new Keyword();
//		key.setName(Constants.MESSAGE_ORIGIN);
//		key.setValue(origin);
//		keywordType.setKeyword(key);
//		message.getRegRepData().getTrade().getRegulatory().getKeywords().add(keywordType);
//		
//		return message;
//	}
//	
//	private String getOriginBySourceSystem(String sourceSystem, String assetClass) {
//		
//		if (!Util.IsNullOrBlank(assetClass)) {
//			if (containsIgnoreCase(assetClass,Constants.ASSET_CLASS_CREDIT))
//				return Constants.MESSAGE_ORIGIN_CALYPSO_CREDIT;
//			else if (containsIgnoreCase(assetClass,Constants.RATE))
//				return Constants.MESSAGE_ORIGIN_CALYPSO_RATES;
//			else if (containsIgnoreCase(assetClass,Constants.FX))
//				return Constants.MESSAGE_ORIGIN_CALYPSO_RATES;
//		}
//		if (sourceSystem != null) {
//			/*if (ratesSystems.contains(sourceSystem)) {
//				return Constants.MESSAGE_ORIGIN_CALYPSO_RATES;
//			} else if (creditSystems.contains(sourceSystem)) {
//				return Constants.MESSAGE_ORIGIN_CALYPSO_CREDIT;
//			}else */ 
//			if (equitySystems.contains(sourceSystem)) {
//				return Constants.MESSAGE_ORIGIN_GALAXY;
//			} else if (commoditySystems.contains(sourceSystem)) {
//				return Constants.MESSAGE_ORIGIN_ENDUR_COMMODITY;
//			} else {
//				return null;
//			}
//		} else {
//			return null;
//		}
//	}
//	
//	private String getPrimaryAssetClass(String srcProduct) {
//		// Get Primary asset class from the static table based o the product type
//		return null;
//	}
//		
//	private static boolean containsIgnoreCase(String str, String searchStr) {
//        if (str == null || searchStr == null) {
//            return false;
//        }
//        int len = searchStr.length();
//        int max = str.length() - len;
//        for (int i = 0; i <= max; i++) {
//            if (str.regionMatches(true, i, searchStr, 0, len)) {
//                return true;
//            }
//        }
//        return false;
//    }
}
