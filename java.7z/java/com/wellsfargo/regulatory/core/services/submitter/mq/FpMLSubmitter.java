package com.wellsfargo.regulatory.core.services.submitter.mq;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

/*
 * TODO: Consider replacing this class with a router that decides which channel (queue) to submit to
 * based on report type and asset class. The advantages of such an approach include 1. Simpler
 * components, all tested and built into Spring 2. Easy to wire-tap these channels to get the TRUE
 * final submission to DTCC. Otherwise we must explicitly push this message into the JSON publishing
 * channel. In the meantime, we only publish to JSON before this step.
 */

public class FpMLSubmitter
{
	private JmsTemplate jmsTemplate;
	private String dtccRatesPriorityQueue;
	private String dtccRatesNonPriorityQueue;
	private String dtccCreditPriorityQueue;
	private String dtccCreditNonPriorityQueue;
	private String dtccFxPriorityQueue;
	private String dtccFxNonPriorityQueue;
	private String dtccEquityPriorityQueue;
	private String dtccEquityNonPriorityQueue;
	private String dtccCommodityPriorityQueue;
	private String dtccCommodityNonPriorityQueue;
	private String submit;

	private static Logger logger = Logger.getLogger(FpMLSubmitter.class.getName());

	public Message<?> submitMessage(Message<?> message, String outGoingQueue) throws MessagingException
	{
		ReportingContext context = null;
		String payload = null;
		String sdrMessageId = null;
		String messageType = null;
		boolean success = false;
		String assetClass = null;

		if (null == message) return message;

		context = (ReportingContext) message.getPayload();
		payload = context.getPayload();
		sdrMessageId = context.getMessageId();
		messageType = context.getReportTypes().get(0);
		assetClass = context.getAssetClass();

		if (!ConversionUtils.stringToBoolean(submit))
		{
			logger.info("Skipping submission, since submission is turned off.");
			return message;
		}

		try
		{

			switch (messageType)
			{

				case Constants.MESSAGE_TYPE_RT:
					success = sendMessageToPriorityQueue(payload, assetClass);
					break;

				case Constants.MESSAGE_TYPE_PET:
					success = sendMessageToPriorityQueue(payload, assetClass);
					break;

				case Constants.MESSAGE_TYPE_CONF:
					success = sendMessageToPriorityQueue(payload, assetClass);
					break;

				case Constants.MESSAGE_TYPE_SNAPSHOT:
					success = sendMessageToNonPriorityQueue(payload, assetClass);
					break;

				case Constants.MESSAGE_TYPE_VALUATION:
					success = sendMessageToNonPriorityQueue(payload, assetClass);
					break;

				default:

					logger.error("Failed to submit message of type " + messageType + " with id : " + sdrMessageId + "due to invalid incoming type.");
			}

		}
		catch (MessagingException e)
		{

			throw new MessagingException("Q:sbmsn:1", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, 
					e.getMessage(), sdrMessageId, e, context.getSwapTradeId());
		}

		if (success)
		{

			logger.info("<<<<<< Message of type " + messageType + " with id : " + sdrMessageId + " was successfully submitted. >>>>>>");
		}
		else
		{

			logger.error(">>>>>> Failed to submit message of type " + messageType + " with id : " + sdrMessageId);
		}

		return message;
	}

	private boolean sendMessageToPriorityQueue(final String message, String assetClass) throws MessagingException
	{

		boolean sendStatus = false;
		String queue = null;

		MessageCreator messageCreator = new MessageCreator()
		{
			public javax.jms.Message createMessage(Session session)
			{
				TextMessage textMessage = null;
				try
				{
					textMessage = session.createTextMessage(message);

				}
				catch (JMSException e)
				{

					logger.error("Error creating Text message in sendMessageToPriorityQueue:", e);
				}

				return textMessage;
			}
		};

		try
		{

			// Send the Message to the Queue

			switch (assetClass)
			{

				case Constants.ASSET_CLASS_INTEREST_RATE:

					queue = dtccRatesPriorityQueue;
					break;

				case Constants.ASSET_CLASS_CREDIT:

					queue = dtccCreditPriorityQueue;
					break;

				case Constants.ASSET_CLASS_FOREX:

					queue = dtccFxPriorityQueue;
					// queue = dtccRatesPriorityQueue;
					break;

				case Constants.ASSET_CLASS_EQUITY:

					queue = dtccEquityPriorityQueue;
					break;

				case Constants.ASSET_CLASS_COMMODITY:

					queue = dtccCommodityPriorityQueue;
					break;

				default:
					throw new Exception("Invalid asset class");
			}

			logger.info("Sending message to Priority Queue: " + queue);
			jmsTemplate.send(queue, messageCreator);
			sendStatus = true;

			logger.info("Message successfuly sent to Priority Queue.");

		}
		catch (Exception e)
		{

			logger.error("Exception occured in sendMessageToPriorityQueue:", e);
			throw new MessagingException("PQ:submission:1", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, "Error while submiiting message to the queue " + dtccRatesPriorityQueue
			        + " ", e);
		}

		return sendStatus;
	}

	private boolean sendMessageToNonPriorityQueue(final String message, String assetClass) throws MessagingException
	{

		boolean sendStatus = false;
		String queue = null;

		MessageCreator messageCreator = new MessageCreator()
		{
			public javax.jms.Message createMessage(Session session)
			{
				TextMessage textMessage = null;
				try
				{
					textMessage = session.createTextMessage(message);

				}
				catch (JMSException e)
				{

					logger.error("Error creating Text message in sendMessageToNonPriorityQueue:", e);
				}

				return textMessage;
			}
		};

		try
		{

			// Send the Message to the Queue

			switch (assetClass)
			{

				case Constants.ASSET_CLASS_INTEREST_RATE:

					queue = dtccRatesNonPriorityQueue;
					break;

				case Constants.ASSET_CLASS_CREDIT:

					queue = dtccCreditNonPriorityQueue;
					break;

				case Constants.ASSET_CLASS_FOREX:

					queue = dtccFxNonPriorityQueue;
					break;

				case Constants.ASSET_CLASS_EQUITY:

					queue = dtccEquityNonPriorityQueue;
					break;

				case Constants.ASSET_CLASS_COMMODITY:

					queue = dtccCommodityNonPriorityQueue;
					break;

				default:

					throw new Exception("Invalid asset class");
			}

			logger.info("Sending message to Non Priority Queue: " + queue);

			jmsTemplate.send(queue, messageCreator);
			sendStatus = true;

			logger.info("Message successfuly sent to Non Priority Queue.");

		}
		catch (Exception e)
		{

			logger.error("Exception occured in sendMessageToNonPriorityQueue: ", e);
			throw new MessagingException("NPQ:submission:1", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, "Error while submiiting message to the queue " + dtccRatesNonPriorityQueue
			        + " ", e);
		}

		return sendStatus;
	}

	public void setDtccCreditPriorityQueue(String dtccCreditPriorityQueue)
	{
		this.dtccCreditPriorityQueue = dtccCreditPriorityQueue;
	}

	public void setDtccCreditNonPriorityQueue(String dtccCreditNonPriorityQueue)
	{
		this.dtccCreditNonPriorityQueue = dtccCreditNonPriorityQueue;
	}

	public void setDtccFxPriorityQueue(String dtccFxPriorityQueue)
	{
		this.dtccFxPriorityQueue = dtccFxPriorityQueue;
	}

	public void setDtccFxNonPriorityQueue(String dtccFxNonPriorityQueue)
	{
		this.dtccFxNonPriorityQueue = dtccFxNonPriorityQueue;
	}

	public void setDtccEquityPriorityQueue(String dtccEquityPriorityQueue)
	{
		this.dtccEquityPriorityQueue = dtccEquityPriorityQueue;
	}

	public void setDtccEquityNonPriorityQueue(String dtccEquityNonPriorityQueue)
	{
		this.dtccEquityNonPriorityQueue = dtccEquityNonPriorityQueue;
	}

	public void setDtccCommodityPriorityQueue(String dtccCommodityPriorityQueue)
	{
		this.dtccCommodityPriorityQueue = dtccCommodityPriorityQueue;
	}

	public void setDtccCommodityNonPriorityQueue(String dtccCommodityNonPriorityQueue)
	{
		this.dtccCommodityNonPriorityQueue = dtccCommodityNonPriorityQueue;
	}

	public void setDtccRatesNonPriorityQueue(String dtccRatesNonPriorityQueue)
	{
		this.dtccRatesNonPriorityQueue = dtccRatesNonPriorityQueue;
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}

	public void setDtccRatesPriorityQueue(String dtccRatesPriorityQueue)
	{
		this.dtccRatesPriorityQueue = dtccRatesPriorityQueue;
	}

	/**
	 * @param submit
	 * the submit to set
	 */
	public void setSubmit(String submit)
	{
		this.submit = submit;
	}

}
