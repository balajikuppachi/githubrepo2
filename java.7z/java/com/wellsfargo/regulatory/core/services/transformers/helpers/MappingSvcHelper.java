package com.wellsfargo.regulatory.core.services.transformers.helpers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.FIELD_NOT_APPLICABLE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FPML;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MAPPER_DIR;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap.Attributes;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */
@Deprecated
public class MappingSvcHelper
{

	private static Log logger = LogFactory.getLog(MappingSvcHelper.class);

	private Sheet getWBookSheet(ReportingContext context) throws MessagingException
	{

		Sheet sheet = null;
		InputStream in = null;
		String fileSeparator = SystemUtils.FILE_SEPARATOR;
		String fileExtenstion = ".xls";
		String relativeCtxtString = "/";
		String errorstring = null;
		Workbook wb = null;

		if (null == context)
		{
			return sheet;
		}

		String reportType = context.getReportTypes().get(0);
		StringBuffer filePath = new StringBuffer(relativeCtxtString + "com");

		filePath.append(fileSeparator + "wellsfargo");
		filePath.append(fileSeparator + "regulatory");
		filePath.append(fileSeparator + FPML);
		filePath.append(fileSeparator + MAPPER_DIR);
		filePath.append(fileSeparator + context.getAssetClass());
		filePath.append(fileSeparator + context.getFpmlProductType());
		filePath.append(fileSeparator + reportType);
		filePath.append(fileExtenstion);

		try
		{
			logger.debug("$$$$ MAPPING-SELECTION File-Path : " + filePath.toString());
			logger.debug("$$$$ WORKSHEET-LOOKUP for LifeCycle-Event : " + context.getLifeCycleEvent());

			in = this.getClass().getResourceAsStream(filePath.toString());
			wb = WorkbookFactory.create(in);

			if (null != wb){
				
				if(Constants.MESSAGE_TYPE_VALUATION.equals(reportType)){
					
					sheet = wb.getSheet(Constants.ALL);
				}else{
					
					sheet = wb.getSheet(context.getLifeCycleEvent());
				}
			}
				

		}
		catch (InvalidFormatException | IOException e)
		{
			errorstring = "Unable to get the workbook for xpath mapper due to : " + e.getMessage();
			logger.error(errorstring, e);
			throw new MessagingException("xpath:mapper:wb:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorstring, e);
		}
		finally
		{
			try
			{
				if (null != in) in.close();
				wb = null;
			}
			catch (IOException e)
			{
				logger.error("######### Unable to close the input stream ", e);
			}
		}

		return sheet;
	}

	@Deprecated
	public Map<String, List<String>> getXpathMap(ReportingContext context) throws MessagingException
	{

		Map<String, List<String>> xPathMap = null;
		int rowBeginIndex = 1;
		int cellBeginIndex = 0;
		Row row = null;
		Cell cell = null;
		String targetXpath = null;
		String srcXpath = null;
		List<String> data = null;
		String isHardCoded = null;
		String dataType = null;
		String condition = null;
		String usageXpath = null;
		String usageConditoin = null;
		String classTypeCondition = null;
		Sheet sheet = null;

		sheet = getWBookSheet(context);
		if (null == sheet)
		{
			logger.error("xPath mapping sheet not found for context " + context);
			throw new MessagingException("xpath:maper:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while getting the xPath mapping sheet");
		}

		int rowCount = sheet.getLastRowNum();
		logger.debug("Total Number of Rows: " + (rowCount + 1));

		if (rowCount > 0)
		{
			xPathMap = new HashMap<String, List<String>>();
		}

		try
		{
			for (int rowCounter = rowBeginIndex; rowCounter <= rowCount; rowCounter++)
			{
				row = sheet.getRow(rowCounter);

				if (null == row)
				{
					continue;
				}
				else
				{
					data = new ArrayList<>();
				}

				// Checking if the value is present
				cell = row.getCell(cellBeginIndex);
				if (null != cell && cell.getStringCellValue().equalsIgnoreCase("A")) continue;

				// Temp tweak for testing - removing the non mapped values !!
				cell = row.getCell(cellBeginIndex + 1);
				if (null != cell && cell.getStringCellValue().equalsIgnoreCase("NM")) continue;

				cell = row.getCell(cellBeginIndex + 2);
				// Temp tweak in order to avoid null rows of excel part 1
				if (null == cell) continue;

				targetXpath = cell.getStringCellValue();
				// Temp tweak in order to avoid null rows of excel part 2
				if (StringUtils.isBlank(targetXpath)) continue;

				cell = row.getCell(cellBeginIndex + 4);
				srcXpath = cell.getStringCellValue();
				data.add(srcXpath);

				cell = row.getCell(cellBeginIndex + 5);
				if (null != cell)
				{
					isHardCoded = cell.getStringCellValue();
				}
				else
				{
					isHardCoded = FIELD_NOT_APPLICABLE;
				}
				data.add(isHardCoded);

				cell = row.getCell(cellBeginIndex + 6);
				if (null != cell)
				{
					dataType = cell.getStringCellValue();
				}
				else
				{
					dataType = FIELD_NOT_APPLICABLE;
				}
				data.add(dataType);

				cell = row.getCell(cellBeginIndex + 7);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					condition = cell.getStringCellValue();
				}
				else
				{
					condition = FIELD_NOT_APPLICABLE;
				}
				data.add(condition);

				cell = row.getCell(cellBeginIndex + 11);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					usageXpath = cell.getStringCellValue();
				}
				else
				{
					usageXpath = FIELD_NOT_APPLICABLE;
				}
				data.add(usageXpath);

				cell = row.getCell(cellBeginIndex + 12);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					usageConditoin = cell.getStringCellValue();
				}
				else
				{
					usageConditoin = FIELD_NOT_APPLICABLE;
				}
				data.add(usageConditoin);

				cell = row.getCell(cellBeginIndex + 13);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					classTypeCondition = cell.getStringCellValue();
				}
				else
				{
					classTypeCondition = FIELD_NOT_APPLICABLE;
				}
				data.add(classTypeCondition);

				xPathMap.put(targetXpath, data);

			}
		}
		catch (Exception e)
		{

			logger.error("######### Failed to read xpath mapping sheet " + context + " Error : ", e);
			throw new MessagingException("xpath:maper:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					"Failed to read xpath mapping sheet ", context.getMessageId(), e, context.getSwapTradeId());
		}

		return xPathMap;

	}

	public List<FpMLXpathMap> getXpathAttributeMap(ReportingContext context) throws MessagingException
	{

		List<FpMLXpathMap> xPathMapList = null;
		int rowBeginIndex = 1;
		int cellBeginIndex = 0;
		Row row = null;
		Cell cell = null;
		String targetXpath = null;
		String srcXpath = null;
		boolean isHardCoded = false;
		String dataType = null;
		String condition = null;
		String usageXpath = null;
		String usageConditoin = null;
		String classTypeCondition = null;
		Sheet sheet = null;
		FpMLXpathMap xPathMap = null;
		Attributes attributes = null;

		sheet = getWBookSheet(context);
		if (null == sheet)
		{

			logger.error("######### xPath mapping sheet not found for context " + context);
			throw new MessagingException("xpath:maper:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while getting the xPath mapping sheet");
		}

		int rowCount = sheet.getLastRowNum();
		logger.debug("Total Number of Rows: " + (rowCount + 1));

		if (rowCount > 0)
		{
			xPathMapList = new ArrayList<>();
		}

		try
		{
			for (int rowCounter = rowBeginIndex; rowCounter <= rowCount; rowCounter++)
			{
				row = sheet.getRow(rowCounter);

				if (null == row)
				{
					continue;
				}

				// Checking if the value is present
				cell = row.getCell(cellBeginIndex);
				if (null != cell && cell.getStringCellValue().equalsIgnoreCase("A")) continue;

				// Temp tweak for testing - removing the non mapped values !!
				cell = row.getCell(cellBeginIndex + 1);
				if (null != cell && cell.getStringCellValue().equalsIgnoreCase("NM")) continue;

				cell = row.getCell(cellBeginIndex + 2);
				// Temp tweak in order to avoid null rows of excel part 1
				if (null == cell) continue;

				isHardCoded = false;
				targetXpath = null;
				srcXpath = null;
				dataType = null;
				condition = null;
				usageXpath = null;
				classTypeCondition = null;
				usageConditoin = null;

				targetXpath = cell.getStringCellValue();
				// Temp tweak in order to avoid null rows of excel part 2
				if (StringUtils.isBlank(targetXpath)) continue;

				xPathMap = new FpMLXpathMap();
				attributes = xPathMap.getMappingAttributes();
				xPathMap.setFpmlXpath(targetXpath);

				cell = row.getCell(cellBeginIndex + 4);
				srcXpath = cell.getStringCellValue();
				attributes.setSrcXpath(srcXpath);

				cell = row.getCell(cellBeginIndex + 5);
				if (null != cell)
				{
					isHardCoded = ConversionUtils.stringToBoolean(cell.getStringCellValue());
				}

				attributes.setIsHardCoded(isHardCoded);

				cell = row.getCell(cellBeginIndex + 6);
				if (null != cell)
				{
					dataType = cell.getStringCellValue();
				}
				else
				{
					dataType = FIELD_NOT_APPLICABLE;
				}
				attributes.setDataType(dataType);

				cell = row.getCell(cellBeginIndex + 7);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					condition = cell.getStringCellValue();
				}
				else
				{
					condition = FIELD_NOT_APPLICABLE;
				}
				attributes.setCondition(condition);

				cell = row.getCell(cellBeginIndex + 11);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					usageXpath = cell.getStringCellValue();
				}
				else
				{
					usageXpath = FIELD_NOT_APPLICABLE;
				}
				attributes.setUsageXpath(usageXpath);

				cell = row.getCell(cellBeginIndex + 12);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					usageConditoin = cell.getStringCellValue();
				}
				else
				{
					usageConditoin = FIELD_NOT_APPLICABLE;
				}
				attributes.setUsageConditoin(usageConditoin);

				cell = row.getCell(cellBeginIndex + 13);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					classTypeCondition = cell.getStringCellValue();
				}
				else
				{
					classTypeCondition = FIELD_NOT_APPLICABLE;
				}

				attributes.setClassTypeCondition(classTypeCondition);

				xPathMapList.add(xPathMap);
			}
		}
		catch (Exception e)
		{
			logger.error("######### Failed to read xpath mapping sheet " + context + " Error : ", e);
			throw new MessagingException("xpath:maper:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, 
					"Failed to read xpath mapping sheet ", context.getMessageId(), e, context.getSwapTradeId());
		}
		finally
		{
			sheet = null;
		}

		return xPathMapList;
	}

}
