package com.wellsfargo.regulatory.core.services.transformers.impl;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.NonpublicExecutionReport;
import com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.NonpublicExecutionReportRetracted;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.cache.FpMLXpathMapCache;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.core.services.transformers.FpmlMessageGenerator;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class PetMessageGenerator extends FpmlMessageGenerator
{
	@Autowired
	FpMLXpathMapCache xPathMappingCache;

	private static Logger logger = Logger.getLogger(PetMessageGenerator.class.getName());

	@Override
	public Message<?> generateMessage(Message<?> message) throws MessagingException
	{
		List<FpMLXpathMap> xPathmap = null;
		String petMessage 			= null;
		String reportId 			= null;
		ReportingContext context 	= null;
		SdrRequest sdrRequest 		= null;
		Object report 				= null;
		String errorString 			= null;

		if (null == message) return message;

		try
		{

			context = (ReportingContext) message.getPayload();

			// START : Setting the MDC from the Context - As Context got updated
			AbstractDriver.setMDCInfo(context, AbstractDriver.PetMessageGenerator);
			// END : Setting the MDC from the Context

			logger.debug("Entering generatePETMessage() method");

			sdrRequest = context.getSdrRequest();

			if(Constants.Cancel.equals(context.getSdrRequest().getTrade().getTradeHeader().getAction()))
			{
				report = new NonpublicExecutionReportRetracted();
				//setTargetObject(report);
			}
			else
			{
				report = new NonpublicExecutionReport();
				//setTargetObject(report);
			}

			setSrcObject(sdrRequest);
			//setTargetObject(report);
			setTargetPackageName(Constants.FPML_NS_RECORDKEEPING);
			setProductType(context.getFpmlProductType());

			xPathmap = xPathMappingCache.getXpathMap(context);

			if (null == xPathmap)
			{
				logger.warn("\n##################################################################################### \n NO XPATH MAP FOUND for the current Product/SubProduct. Verify the PRODUCT Mapping. \n#####################################################################################");
				
				errorString = "NO XPATH MAP FOUND for the current Product/SubProduct [" + context.getMessageId() + "]. Verify the PRODUCT Mapping. ";
				//errorString = "Failed to populate xPath map for message with messageId --> " + context.getMessageId() +" .Context is "+context;
				logger.error("########## " + errorString);

				// Commented for now, not to show in UI-alerts.
				//dispatchException(message, context.getMessageId(), errorString, "petMsgGen:1", ExceptionSeverityEnum.ERROR, context.getSwapTradeId());

				return null;
			}

			/*
			 * Generating a new messageId for the report.
			 */
			reportId = ReportingDataUtils.generateMessageId();

			helper.setLifecycleEvent(context.getLifeCycleEvent());
			helper.setReportType(Constants.MESSAGE_TYPE_PET);
			
			generateFpmlReport(xPathmap, reportId, report);
			
			petMessage = getGeneratedMessage();

			// Enbale below - Testing Purpose Only
			 //writeToAFile(petMessage);

			context.setPayload(petMessage);
			context.setContextType(PayloadTypeEnum.FpML);
			context.setMessageSource(Constants.FPML_REPORT_TYPE);
			context.setSrcMessageId(context.getMessageId());
			context.setMessageId(reportId);

			logger.debug("(Primary Economic Terms), PET-MESSAGE \n" + petMessage);

			logger.info("\n------------------------------------------------------------------------------------------ \n@@@@@@ GENERATED PET-MESSAGE ! \n------------------------------------------------------------------------------------------");

		}
		catch (Exception e)
		{
			throw new MessagingException("petMsgGen:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, e.getMessage(), context.getMessageId(), e, context.getSwapTradeId());
		}
		finally
		{
			//if (null != xPathmap) xPathmap.clear();
			xPathmap 	= null;
			report 		= null;
			petMessage 	= null;
		}

		return message;
	}

	@SuppressWarnings("unused")
	private void writeToAFile(String message)
	{

		logger.debug("Entering writeToAFile() method");

		String filePath = "C:\\Users\\u337814\\Desktop\\out-FpML\\PET\\";
		String fileName = (new Date()).toString().replace(" ", "_").replace(":", "_") + ".xml";

		try
		{

			File file = new File(filePath + fileName);
			if (!file.exists()) file.createNewFile();

			FileUtils.writeStringToFile(file, message);

		}
		catch (IOException e)
		{
			logger.error("######### Unable to write PET message to file " + e);
		}

		logger.debug("Leaving writeToAFile() method");

	}

	public void setxPathMappingCache(FpMLXpathMapCache xPathMappingCache) {
		this.xPathMappingCache = xPathMappingCache;
	}
}
