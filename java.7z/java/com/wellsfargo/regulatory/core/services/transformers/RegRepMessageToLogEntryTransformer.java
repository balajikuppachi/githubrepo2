package com.wellsfargo.regulatory.core.services.transformers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.RegRepMessageTypeEum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.logging.monitor.LogEntry;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageRegulatoryDao;
import com.wellsfargo.regulatory.persister.dao.RegRepReportDao;
import com.wellsfargo.regulatory.persister.dao.RegRepSdrRequestDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepParty;
import com.wellsfargo.regulatory.persister.dto.RegRepProduct;
import com.wellsfargo.regulatory.persister.dto.RegRepReport;
import com.wellsfargo.regulatory.persister.dto.RegRepResponse;
import com.wellsfargo.regulatory.persister.dto.RegRepSdrRequest;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeDetail;
import com.wellsfargo.regulatory.persister.dto.RegRepTradeHeader;

@Component
public class RegRepMessageToLogEntryTransformer
{
	private static Logger logger = Logger.getLogger(RegRepMessageToLogEntryTransformer.class.getName());

	@Autowired
	RegRepSdrRequestDao regRepSdrRequestDao;
	@Autowired
	RegRepMessageDao regRepMessageDao;
	@Autowired
	RegRepReportDao regRepReportDao;
	@Autowired
	RegRepMessageRegulatoryDao regRepMessageRegulatoryDao;

	// @Transformer
	public LogEntry transform(Message<RegRepMessage> simessage) throws MessagingException
	{
		RegRepMessage rrmessage = simessage.getPayload();

		LogEntry entry = new LogEntry(new Date()); // TODO: Make Date a testable parameter
		if (null == rrmessage || "DUMMY".equals(rrmessage.getRegRepMessageId()))
		{
			logger.warn("RegRepMessageToLogEntryTransformer: null response message; returning dummy LogEntry");
			return entry;
		}
		
	//	entry.addCustomField("RspCntxt", rrmessage.toString());
		

		RegRepMessage reportMessage = null;

		if (null == rrmessage.getMessageType()) logger.error("transform: null MessageType for " + rrmessage.getRegRepMessageId());
		else if (isType(rrmessage, RegRepMessageTypeEum.SDR_REPORT))
		{
			reportMessage = rrmessage;
		}
		else if (isType(rrmessage, RegRepMessageTypeEum.SDR_TRADE))
		{
		}
		else logger.warn("transform: called for unexpected MessageType " + rrmessage.getMessageType());

		if (null != rrmessage.getTradeUsi()) entry.addCustomField("USI", rrmessage.getTradeUsi());
		if (null != rrmessage.getTradeUti()) entry.addCustomField("UTI", rrmessage.getTradeUti());

		if (null != reportMessage)
		{
			RegRepReport rrReport = regRepReportDao.findByPrimaryKey(rrmessage.getRegRepMessageId());
			if (null != rrReport)
			{
				entry.setReportType(rrReport.getSdrMessageType());
				entry.addCustomField("Submission timestamp", rrReport.getSubmissionTimestamp());
			}
			else if (isType(rrmessage, RegRepMessageTypeEum.SDR_REPORT))
			{
				logger.warn("transform: Couldn't find RegRepReport for report message " + rrmessage.getRegRepMessageId());
			}
			
			if (null == reportMessage.getRegRepMessageRegulatories())
			{
				logger.warn("transform: No regulatories found for report " + reportMessage.getRegRepMessageId());
			}
			else if (1 != reportMessage.getRegRepMessageRegulatories().size())
			{
				logger.warn("transform: Expected exactly 1 regulatory for report " + reportMessage.getRegRepMessageId() + ", found " + reportMessage.getRegRepMessageRegulatories().size());
			}
			else
			{
				final String msgId = reportMessage.getRegRepMessageId();
				List<String> sdrs = new ArrayList<String>();
//				for (RegRepMessageRegulatory reg : regRepMessageRegulatoryDao.find(criteria -> {
//					criteria.createCriteria("regRepMessage")
//					.add(Restrictions.eq("regRepMessageId", msgId));			
//				})) // .findByPrimaryKey(reportMessage.getRegRepMessageId())) // reportMessage.getRegRepMessageRegulatories())
//				{
//					if (null == reg.getReportingJurisdiction()) logger.warn("transform: reg.getReportingJurisdiction returned null for report" + reportMessage.getRegRepMessageId());
//					else entry.addJurisdiction(reg.getReportingJurisdiction());
//					sdrs.add(reg.getRepository());
//					if (null != reg.getReportingParty())
//					{
//						entry.addCustomField("Reporting Party", reg.getReportingParty());
//					}
//				}
				if (sdrs.size() > 0) {
					if (null == sdrs.get(0)) logger.warn("RegRepMessageToLogEntryTransformer: sdrs.get(0) returned null");
					else entry.addCustomField(LogEntry.SDR_FLD, sdrs.get(0)); //TODO: Change to list
				}
			}
			entry.addCustomField(LogEntry.SDR_FLD, "DTCC"); // TODO: HARDCODED. REMOVE THIS LINE WHEN
			// ABOVE IS WORKING.
			entry.addJurisdiction("CFTC"); // TODO: HARDCODED. REMOVE THIS LINE WHEN ABOVE IS WORKING.
		}
		
		RegRepSdrRequest req = getRequest(rrmessage);
		if (null != req)
		{
			entry.setAssetClass(req.getAssetClass());
			entry.setLifeCycleEventId(req.getRegRepMessageId());
			entry.addCustomField("Create Time",  req.getCreateDateTime());

			entry.setProductType(getProductType(req));
			if (null != getProductSubtype(req)) entry.addCustomField("Subproduct Type", getProductSubtype(req));

			RegRepTradeHeader header = req.getRegRepTradeHeader();
			if (null != header)
			{
				entry.setTradeId(header.getTradeId());
				if (null == header.getTradeId())
					logger.warn("RegRepMessageToLogEntryTransformer: TradeID is NULL for message " + rrmessage.getRegRepMessageId());
				entry.setTradeAction(req.getRegRepTradeHeader().getAction()); // TODO: TradeAction
																			  // doesn't need to be
																			  // mandatory
				if (null != header.getTraderName()) entry.addCustomField("Trader", header.getTraderName());
				if (null != header.getBookName()) entry.addCustomField("Book", header.getBookName());
				if (null != header.getAction()) entry.addCustomField("Action", header.getAction());
				if (null != header.getExecutionDateTime()) entry.addCustomField("Execution Time", header.getExecutionDateTime());
				if (null != header.getTradeVersion()) entry.addCustomField("Version", header.getTradeVersion());
				if (null != header.getRegRepLifecycle()) entry.addCustomField("Lifecycle Event", header.getRegRepLifecycle().getEventType());
				if (null != header.getStatus()) entry.addCustomField("Trade Status", header.getStatus());
			} else{
				logger.warn("RegRepMessageToLogEntryTransformer: TradeHeader is NULL");
			}
			
			RegRepTradeDetail tradeDetails = req.getRegRepTradeDetail();
			if (null != tradeDetails)
			{
				RegRepParty processingParty = tradeDetails.getRegRepPartyByLei(rrmessage.getEntityLei());
				RegRepParty counterparty = tradeDetails.getRegRepPartyByLei(rrmessage.getCounterpartyLei());
				if (null != processingParty) entry.addCustomField("Processing Org", processingParty.getPartyName());
				if (null != counterparty) entry.addCustomField("Counterparty", counterparty.getPartyName());
			}
			
		} else {
			logger.warn("RegRepMessageToLogEntryTransformer: SdrRequest is NULL for response " + rrmessage.getRegRepMessageId());		
		}
	
		RegRepResponse response = rrmessage.getRegRepResponse();
		if (null != response)
			entry.addCustomField("Response Time", response.getAcknowledgementTimestamp());

		String status = (String) simessage.getHeaders().get("ReportStatus");
		if (null == status) status = "Received";
		entry.addCustomField(LogEntry.STATUS_FLD, status);

		entry.setOriginalMessageId(rrmessage.getRegRepMessageId());
		entry.setUuid(rrmessage.getRegRepMessageId());

		return entry;
	}

	private RegRepSdrRequest getRequest(RegRepMessage rrmessage)
	{
		if (null == rrmessage) {
			logger.warn("getRequest: Received null RegRepMessage. Returning null.");
			return null;			
		}

		int retryCount = 3;
		int sleepInterval = 3; // seconds
		while (true) {
			RegRepSdrRequest req = regRepSdrRequestDao.findByPrimaryKey(rrmessage.getRegRepMessageId());
			if (null != req) {
				logger.debug("getRequest: Found SdrRequest message " + req.getRegRepMessageId());
				return req;
			}
			if (isType(rrmessage, RegRepMessageTypeEum.SDR_TRADE)) {
				String msg = "getRequest: RegRepMessage " + rrmessage.getRegRepMessageId() + " of type " + rrmessage.getMessageType() + " has no RegRepSdrRequest.";
				if (retryCount > 0) {
					msg = msg + " Retrying in " + sleepInterval + " seconds.";
				}
				else
					msg = msg + " Giving up.";
				logger.warn(msg);
				if (retryCount-- > 0)
					try {
						Thread.sleep(sleepInterval * 1000);
					} catch (InterruptedException e) {
						e.printStackTrace(); // TODO: Replace this
					}
				else
					break;
			}
			else
				break;
		}
		RegRepMessage requestMessage = rrmessage.getRegRepMessageBySrcRegRepMessageId();
		return getRequest(requestMessage);
	}

	private RegRepMessage getRequestMessage(RegRepMessage m)
	{

		RegRepMessage reqMessage = m.getRegRepMessageBySrcRegRepMessageId();
		if (null == reqMessage) // TODO: Consider testing if this is an SDR_REQUEST MessageType.
		{
			if (! isType(m, RegRepMessageTypeEum.SDR_TRADE))
			{
				logger.warn("transform: Treating message " + m.getRegRepMessageId() + " as a request message, but its MessageType is " + m.getMessageType());
			}
			return m;
		}
		return reqMessage;
	}

	public RegRepProduct getParentProduct(Set<RegRepProduct> products)
	{
		if (null == products || products.isEmpty()) return null;
		// Products can be hierarchical, but there's currently no way to traverse the tree.
		// Just find the first one whose parent type is null.
		for (RegRepProduct product : products)
		{
			if (null == product.getRegRepParentProductType()) return product;
		}
		// We couldn't find one with a null parent product type, so just return the first.
		logger.warn("Found no product with null parent type. Using first in set.");
		return (RegRepProduct) products.toArray()[0];
	}

	private RegRepProduct getProduct(RegRepSdrRequest req)
	{
		Set<RegRepProduct> products = null;

		if (null != req && null != req.getRegRepTradeDetail()) products = req.getRegRepTradeDetail().getRegRepProducts();

		if (null == products || products.isEmpty())
		{
			logger.warn("REG_REP_SDR_REQUEST has no products: " + req.getRegRepMessageId());
			return new RegRepProduct();
		}
		if (products.size() > 1)
		{
			logger.info("Request has more than 1 product.");
		}
		return getParentProduct(products);
	}

	private String getProductType(RegRepSdrRequest req)
	{
		return getProduct(req).getProductType();
	}

	private String getProductSubtype(RegRepSdrRequest req)
	{
		return getProduct(req).getProductSubType();
	}

	private String formatTimeDiff(long millis)
	{
		long seconds = (millis / (1000)) % 60;
		long minutes = (millis / (1000 * 60)) % 60;
		long hours   = (millis / (1000 * 60 * 60)) % 24;
		long days    = (millis / (1000 * 60 * 60 * 24));

		String ret = String.format("%02ds", seconds);
		if (minutes > 0 || hours > 0 || days > 0)
			ret = String.format("%02dm %s", minutes, ret);
		if (hours > 0 || days > 0)
			ret = String.format("%02dh %s", hours, ret);
		if (days > 0)
			ret = String.format("%dd %s", days, ret);

		return ret;
	}


	public static boolean isType(RegRepMessage m, RegRepMessageTypeEum type)
	{
		return null != m.getMessageType() && m.getMessageType().equalsIgnoreCase(type.type());
	}
}
