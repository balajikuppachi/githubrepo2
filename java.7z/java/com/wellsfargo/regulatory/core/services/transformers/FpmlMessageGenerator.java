package com.wellsfargo.regulatory.core.services.transformers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.APP_NOT_APPLICABLE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.COMMA;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FALSE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FPML_NS_RECORDKEEPING;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FPML_NS_TRANSPARENCY;
import static com.wellsfargo.regulatory.commons.keywords.Constants.FpML_MSG_ID_XPATH;
import static com.wellsfargo.regulatory.commons.keywords.Constants.NULL_USAGE_VALUE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.PERCENTAGE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.STRING_TO_REMOVE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.TRUE;

import java.io.InputStream;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

// import org.apache.camel.converter.jaxp.StringSource;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.xml.transform.StringSource;

import com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.NonpublicExecutionReport;
import com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.NonpublicExecutionReportRetracted;
import com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.ValuationReport;
import com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency.PublicExecutionReport;
import com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency.PublicExecutionReportRetracted;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.JurisdictionEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap.Attributes;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.factory.RegulatoryBeanFactory;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.core.driver.main.RegRepComponent;
import com.wellsfargo.regulatory.core.services.transformers.helpers.MsgGenSvcHelper;

/**
 * @author 	Amit Rana
 * @date 	08/23/2014
 * @version 1.0
 */

public abstract class FpmlMessageGenerator extends RegRepComponent
{
	@Autowired
	protected MsgGenSvcHelper helper;

	private String fpmlMessage;
	private Object srcObject;
	//private Object targetObject;
	private String targetPackageName;
	private String productType;

	public static  String 		xslCleanerFileName;
	private static Transformer 	transformer;
	private static JAXBContext 	transparencyContext;
	private static JAXBContext 	recordkeepingContext;

	private static Logger logger = Logger.getLogger(FpmlMessageGenerator.class.getName());

	static
	{
		/*** Instantiating Transparency and Recordkeeping context ***/
		try 
		{
			transparencyContext = JAXBContext.newInstance(FPML_NS_TRANSPARENCY);
			recordkeepingContext = JAXBContext.newInstance(FPML_NS_RECORDKEEPING);
			
			/** Instantiate Cleaner transformer */
			if(null == transformer) setCleanerTransformer();
		} 
		catch (JAXBException e) 
		{
			logger.error("############################# Error instatiatiating Transparency and Recordkeeping context ",e);
		}
	}


	public abstract Message<?> generateMessage(Message<?> message) throws MessagingException;

	private boolean checkFor(Object srcDataValue)
	{
		String data = null;

		if (null == srcDataValue)
		{
			return false;
		}

		if (srcDataValue instanceof String)
		{
			data = (String) srcDataValue;

			if (StringUtils.isBlank(data))
			{
				return false;
			}
		}

		return true;
	}

	/*
	 * Embeds Report Id for submission
	 */
	private void embeddMessageId(JXPathContext rptContext, String messageId)
	{
		String messageIdXpath = FpML_MSG_ID_XPATH;
		rptContext.setValue(messageIdXpath, messageId);
	}

	private void publishFpml(Object targetObject)
	{
		logger.debug("Entering publishFpml() method");

		String 		generatedFpml = null;
		Marshaller	marshaller 	  = null;

		try
		{
			StringWriter writer = new StringWriter();

			if(targetObject instanceof PublicExecutionReport || targetObject instanceof PublicExecutionReportRetracted)
			{
				marshaller = transparencyContext.createMarshaller();
			}
			else if(targetObject instanceof NonpublicExecutionReport 
					|| targetObject instanceof NonpublicExecutionReportRetracted
					|| targetObject instanceof ValuationReport)
			{
				marshaller = recordkeepingContext.createMarshaller();
			}

			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			marshaller.marshal(targetObject, writer);

			generatedFpml 	= writer.toString();
			fpmlMessage 	= cleanXml(generatedFpml);
		}
		catch (Exception e)
		{
			fpmlMessage = null;
			logger.error("######### Exception occured (publishFpml): " + ExceptionUtils.getFullStackTrace(e));
		}
		
		logger.debug("Leaving publishFpml() method");
	}

	private String parseCondition(String conditionString, String srcDataValue)
	{
		logger.debug("Entering parseCondition() method");

		String result = null;
		String[] conditions;
		String actionString = null;
		String consequence = null;

		if (null == srcDataValue || null == conditionString) return result;

		conditions = conditionString.split("\\|");

		for (String condition : conditions)
		{
			// To handle the conditions where the consequence itself contains semicolons (") for ex RIC:"http://www.fpml.org/spec/2003/instrument-id-Reuters-RIC"
			if (condition.contains("\""))
			{
				if (null != condition.split(":") && condition.split(":").length > 1)
				{
					actionString = condition.split(":")[0];
					String tmpconsequence = condition.substring(condition.indexOf(":")+1);
					consequence = tmpconsequence.replace("\"", "");
				}
			} 
			else if (null != condition.split(":") && condition.split(":").length > 1)
			{
				actionString = condition.split(":")[0];
				consequence = condition.split(":")[1];
			}

			if (null != actionString)
			{
				for (String action : actionString.split(","))
				{
					if (PERCENTAGE.equals(action) || srcDataValue.equalsIgnoreCase(action))
					{
						result = consequence;
						break;
					}
				}
			}
			else
			{
				// works for the case of a default value specified without any condition.
				result = consequence;
				break;
			}
		}

		logger.debug("Leaving parseCondition() method");

		return result;
	}

	private String parseUsageCondition(String conditionString, List<String> srcDataValue)
	{
		logger.debug("Entering parseUsageCondition() method");

		String result 			= null;
		String[] conditions 	= null;
		String actionString 	= null;
		String consequence 		= null;
		String[] intermediateResults = null;
		int i = 0;

		try
		{
			if (GeneralUtils.IsListNullOrEmpty(srcDataValue) || null == conditionString) return result;

			conditions = conditionString.split("\\|");
			intermediateResults = new String[conditions.length];

			for (String condition : conditions)
			{
				if (null != condition.split(":") && condition.split(":").length > 1)
				{
					actionString = condition.split(":")[0];
					consequence = condition.split(":")[1];
				}

				if (null != actionString)
				{
					for (String action : actionString.split(","))
					{
						// percentage helps if u want to pick the consequence on "any" (non null)
						// value
					
						if ((PERCENTAGE.equals(action) && (!NULL_USAGE_VALUE.equals(srcDataValue.get(i)))) || srcDataValue.get(i).equalsIgnoreCase(action))
						{
							intermediateResults[i] = consequence;
							break;
						}
					}
				}
				else
				{
					// works for the case of a default value specified without any condition.
					intermediateResults[i] = consequence;
					break;
				}

				i++;
			}

			if (intermediateResults.length > 1)
			{
				for (String iResult : intermediateResults)
				{
					result = TRUE;

					if (!result.equalsIgnoreCase(iResult))
					{
						result = FALSE;
						break;
					}
				}
			}
			else if (intermediateResults.length == 1)
			{
				result = intermediateResults[0];
			}
		}
		catch (Exception e)
		{
			logger.debug("######### Failed to get the usageCondition for " + conditionString + " for the value " + srcDataValue.toString());
		}

		logger.debug("Leaving parseUsageCondition() method");

		return result;
	}

	/**
	 * Can take comma separated values for mapping abstract class with implementation class on time.
	 * For example -> /x/y/z/exercise : American This would map exercise class falling under /x/y/z/
	 * path in the target path to American class implementation. This value can also take an xpath
	 * for source class type For example -> /x/y/z/exercise : /p/q/r/exerciseType. This would map
	 * exercise class falling under /x/y/z/ path in the target path to value falling in
	 * /p/q/r/exerciseType. Multiple mappings may also be specified, seperated by comma(,). For
	 * example -> /x/y/z/exercise : American, /a/b/c/product : /p/q/s/productType
	 */
	private List<String[]> parseClassType(String conditionString, JXPathContext srcContext)
	{
		logger.debug("Entering parseClassType() method");

		List<String[]> result 	= null;
		String[] classMap 		= null;
		String[] conditions 	= null;
		String targetXpath 		= null;
		String srcval 			= null;
		Object object 			= null;
		Class<?> clss 			= null;

		if (null == conditionString) return result;

		conditions = conditionString.split(COMMA);

		for (String condition : conditions)
		{
			if (null != condition.split(":") && condition.split(":").length > 1)
			{
				targetXpath = condition.split(":")[0];
				srcval 		= condition.split(":")[1];
			}

			if (null != srcval && srcval.contains("/"))
			{
				try
				{
					// This is an xpath in that case
					object = srcContext.getValue(srcval);
				}
				catch (Exception e)
				{
					logger.debug("######### Faled to eveluate path --> " + srcval + " since ", e);
				}

				if (null != object)
				{
					if (object instanceof java.lang.String)
					{
						srcval = (String) object;
					}
					else
					{
						clss = object.getClass();
						if (clss.getName().contains("Enum"))
						{
							try
							{
								Method method = clss.getDeclaredMethod("toStringValue", String.class);
								srcval = (String) method.invoke(null, object.toString());
							}
							catch (Exception e)
							{
								logger.debug("######### Failed to generate the object class since : ", e);
							}
						}
					}
				}
			}

			if (null != srcval && null != targetXpath)
			{
				classMap 	= new String[2];
				classMap[0] = targetXpath;
				classMap[1] = srcval;
			}

			if (null != classMap)
			{
				if (null == result) result = new ArrayList<String[]>(3);
				result.add(classMap);
				classMap = null;
			}
		}

		logger.debug("Leaving parseClassType() method");

		return result;
	}

	/*
	 * Trims generated XML of any empty tags
	 */
	private String cleanXml(String ipXml)
	{
		logger.debug("Entering cleanXml() method");

		String transformedXml 		= null;
		StringWriter resultWriter 	= null;
		Source sourceXML 			= null;

		//if (null == ipXml || StringUtils.isBlank(xslCleanerFileName)) return ipXml;
		if (null == ipXml )
			return ipXml;

		resultWriter = new StringWriter();

		try
		{
			sourceXML = new StringSource(ipXml);

		//	if(null == transformer) setCleanerTransformer();
			
			if(null != transformer && null != sourceXML)
			{
				transformer.transform(sourceXML, new StreamResult(resultWriter));
				transformedXml = resultWriter.toString();
			}
		}
		catch (Exception e)
		{
			logger.debug("######### Failed while removing empty tags from FpML " + ExceptionUtils.getFullStackTrace(e));
		}

		if(null == transformedXml) transformedXml = ipXml;

		if(StringUtils.isBlank(transformedXml))
		{
			logger.warn("Empty clean transformed xml");
		}

		logger.debug("Message after removing empty tags is --> "+transformedXml);
		
		// Temp fix for sp ch - '&'
		// Removing this fix since DTCC doesn't parse '&' symbol (making this xml encoded)		
		/*
			transformedXml = transformedXml.replace("&amp;", "&");
		*/
		
		// Fix to keep those fields which are to be mandatorily reported Blank
		transformedXml = transformedXml.replace(STRING_TO_REMOVE, "");
		
		logger.debug("Leaving cleanXml() method");

		return transformedXml;
	}

	public void generateFpmlReport(List<FpMLXpathMap> xPathmapList, String messageId, Object targetObject)
	{
		logger.debug("Entering generateFpmlReport() method");

		JXPathContext srcContext 	= null;
		JXPathContext rptContext 	= null;
		Object srcDataValue 		= null;
		String dataType 			= null;
		String condition 			= null;
		List<String> usageValues 	= null;
		String usageConditon 		= null;
		String classTypeCondition 	= null;
		List<String[]> classTypeList = null;
		String fpmlXpath 			= new String();
		boolean toUse 				= true;
		Attributes mappingAttributes = null;
		String xPath 				= null;
		Object tempObject 			= null;
		String val 					= null;
		String intermediateSrcXpath = null;

		srcContext = JXPathContext.newContext(srcObject);
		rptContext = JXPathContext.newContext(targetObject);

		helper.setPackageName(targetPackageName);
		helper.setProdutType(productType);

		for (FpMLXpathMap fpmlXpathMap : xPathmapList)
		{
			fpmlXpath 			= fpmlXpathMap.getFpmlXpath();
			mappingAttributes 	= fpmlXpathMap.getMappingAttributes();
			dataType 			= mappingAttributes.getDataType();
			condition 			= mappingAttributes.getCondition();
			classTypeCondition 	= mappingAttributes.getClassTypeCondition();

			 //Below is DEBUG Purpose only
/*			 if(fpmlXpath.equals("/originatingEvent/value"))
			 {
			 	 System.out.println("here");
			 }*/
 		

			/*** Removing values from previous loop run */
			{
				toUse 			= true;
 				usageValues 	= null;
				usageConditon 	= null;
				srcDataValue 	= null;
				classTypeList 	= null;
				intermediateSrcXpath = null;
			}

			if (!(APP_NOT_APPLICABLE.equals(mappingAttributes.getUsageXpath())))
			{
				try
				{
					usageValues = new ArrayList<>(4);
					for (String usageXpath : mappingAttributes.getUsageXpath().split("\\|"))
					{
						val 		= null;
						tempObject 	= null;
						xPath 		= usageXpath;
												
						try
						{
							tempObject = srcContext.getValue(usageXpath);
						}
						catch(Exception e)
						{
							logger.debug("######### Failed while fetching --> " + usageXpath + " with error : " +e.getMessage());
						}

						if (null != tempObject)
						{
							if (tempObject instanceof String)
							{
								val = tempObject.toString();
							}
							else if (tempObject instanceof Boolean)
							{
								val = String.valueOf(tempObject);
							}
							else if (tempObject instanceof BigDecimal)
							{
								val = ((BigDecimal)tempObject).toString(); 
							}
							
							else
							{
								/** Temp Fix for now. TODO : Please fix this **/
								String className = tempObject.getClass().getName();

								if (className.equals(FixedFloatEnum.class.getName()))
								{
									val = ((FixedFloatEnum) tempObject).value();
								}
								else if (className.equals(ExerciseTypeEnum.class.getName()))
								{
									val = ((ExerciseTypeEnum) tempObject).value();
								}
								else if (className.equals(JurisdictionEnum.class.getName()))
								{
									val = ((JurisdictionEnum) tempObject).value();
								}
								else if (className.equals(UsThemEnum.class.getName()))
								{
									val = ((UsThemEnum) tempObject).value();
								}
							}
						}
												
						if(null == val)
							val = NULL_USAGE_VALUE;
						
						usageValues.add(val);
					}
				}
				catch (Exception e)
				{
					logger.debug("######### Failed to retrieve value in the incoming data at " + xPath + " since " + e.getMessage());
					// Fix to populate the hard coded schema values only when other elements are
					// present in that main element
					toUse = false;
				}

				usageConditon = mappingAttributes.getUsageConditoin();

				if (null != usageValues)
				{
					toUse = ConversionUtils.stringToBoolean(parseUsageCondition(usageConditon, usageValues));
				}
			}

			if (toUse)
			{
				if (mappingAttributes.getIsHardCoded())
				{
					srcDataValue = mappingAttributes.getSrcXpath();
				}
				else
				{
					try
					{
						intermediateSrcXpath = 	mappingAttributes.getSrcXpath();
						
						if(null != intermediateSrcXpath
								&& StringUtils.startsWith(intermediateSrcXpath,"|")
								&& StringUtils.endsWith(intermediateSrcXpath,"|"))
						{
							intermediateSrcXpath 	= StringUtils.removeStart(StringUtils.removeEnd(intermediateSrcXpath,"|"),"|");
							srcDataValue 			= srcContext.getValue(intermediateSrcXpath);

							if(srcDataValue instanceof BigInteger)
							{
								srcDataValue = ((BigInteger)srcDataValue).abs();
							}
							
							if(srcDataValue instanceof BigDecimal)
							{
								srcDataValue = ((BigDecimal)srcDataValue).abs();
							}
							
							if(srcDataValue instanceof Integer)
							{
								srcDataValue = ((Integer)srcDataValue) < 0 ? ((Integer)srcDataValue*-1) : srcDataValue;
							}
							
							if(srcDataValue instanceof Float)
							{
								srcDataValue = ((Float)srcDataValue) < 0 ? ((Float)srcDataValue*-1) : srcDataValue;
							}
							
							if(srcDataValue instanceof Double)
							{
								srcDataValue = ((Double)srcDataValue) < 0 ? ((Double)srcDataValue*-1) : srcDataValue;
							}
							
							if(srcDataValue instanceof Long)
							{
								srcDataValue = ((Long)srcDataValue) < 0 ? ((Long)srcDataValue*-1) : srcDataValue;
							}

						}
						else
						{
							srcDataValue = srcContext.getValue(intermediateSrcXpath);

							if (srcDataValue instanceof BigDecimal)
							{
								BigDecimal bd = ((BigDecimal)srcContext.getValue(intermediateSrcXpath)).setScale(10, RoundingMode.HALF_UP).stripTrailingZeros();
								srcDataValue = bd;
							}
						}
					}
					catch (Exception e)
					{
						logger.debug("######### Failed to populate " + fpmlXpath + " since " + e.getMessage());
						// - Skipping rest of the loop since src value could not be read.
						continue;
					}
				}

				if (!(APP_NOT_APPLICABLE.equals(classTypeCondition)))
				{
					classTypeList = parseClassType(classTypeCondition, srcContext);
				}

				if (!(APP_NOT_APPLICABLE.equals(condition)) && null != srcDataValue)
				{
					srcDataValue = parseCondition(condition, srcDataValue.toString());
				}

				try
				{
					if (checkFor(srcDataValue))
					{
						helper.evaluateXpath(rptContext, fpmlXpath, srcDataValue, dataType, classTypeList);
					}
					else
					{
						logger.debug("######### Warning : Failed to populate data for " + fpmlXpath + " since invalid input data for " + mappingAttributes.getSrcXpath());
					}
				}
				catch (Exception e)
				{
					logger.debug("######### Warning : Failed to populate data for " + fpmlXpath + "|" + e);
				}
				finally{
					fpmlXpath 			= null;
					mappingAttributes 	= null;
					dataType 			= null;
					condition 			= null;
					classTypeCondition  = null;
				}
			}
		}

		// Embed Report Id
		if (null != messageId) embeddMessageId(rptContext, messageId);

		publishFpml(targetObject);
		
		logger.debug("Leaving generateFpmlReport() method");
	}

	private static void setCleanerTransformer()
	{
		logger.debug("Entering setCleanerTransformer() method");

		/*** Instantiating XML Cleaner Transformer ***/
		TransformerFactory factory = TransformerFactory.newInstance();

		// From ClassLoader, all paths are "absolute" already - there's no context
		// from which they could be relative. Therefore you don't need a leading slash.
		//InputStream in = this.getClass().getClassLoader().getResourceAsStream(xslCleanerFileName);

		// From Class, the path is relative to the package of the class unless 
		// you include a leading slash, so if you don't want to use the current package, include a slash
		//InputStream stream = this.getClass().getResourceAsStream("/"+xslCleanerFileName);
		InputStream stream = RegulatoryBeanFactory.loadXSLCleanerFileInputStream();

		try 
		{
			transformer = factory.newTransformer(new StreamSource(stream));
		} 
		catch (TransformerConfigurationException e) 
		{
			logger.error("############################# Error instatiatiating XML cleaner transformer ",e);
		}

		logger.debug("Leaving setCleanerTransformer() method");
	}


	public static void setXslCleanerFileName(String xslCleanerFileName)
	{
		FpmlMessageGenerator.xslCleanerFileName = xslCleanerFileName;
	}

	public String getGeneratedMessage()
	{
		return fpmlMessage;
	}

	public void setSrcObject(Object srcObject)
	{
		this.srcObject = srcObject;
	}

	//public void setTargetObject(Object targetObject)
	//{
	//	this.targetObject = targetObject;
	//}

	public void setTargetPackageName(String targetPackageName)
	{
		this.targetPackageName = targetPackageName;
	}

	public void setProductType(String productType)
	{
		this.productType = GeneralUtils.capitalizeFirstLetter(productType);
	}

	public void setHelper(MsgGenSvcHelper helper)
	{
		this.helper = helper;
	}
}
