package com.wellsfargo.regulatory.core.services.transformers;

import static com.wellsfargo.regulatory.commons.keywords.Constants.COLON;
import static com.wellsfargo.regulatory.commons.keywords.Constants.GTRCREATE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MSG_STATUS_WACK;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;

import com.wellsfargo.regulatory.commons.beans.FpMLResponse;
import com.wellsfargo.regulatory.commons.beans.FpMLResponse.Reason;
import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrResponse.ResponseCodeEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

public class RegRepResponseGenerator
{

	private static RegRepMessageDao regRepMessageDao;

	private static Logger logger = Logger.getLogger(RegRepResponseGenerator.class.getName());
	private static String GTR_CREATE_USI;

	static
	{
		GTR_CREATE_USI = GTRCREATE + COLON + GTRCREATE;
	}

	public Message<?> prepareResponse(Message<?> message){

		ReportingContext 	context;
		RulesResultsContext rulesResultsContext;
		PayloadTypeEnum		cntxtType;
		FpMLResponse 		response;
		ValidationResult	result;
		String				reportId;
		RegRepMessage		parentMessage;
		List<Reason>		reasons;				
		
		logger.debug("Entering prepareResponse");

		if(null == message
				|| null == message.getPayload()
				|| !(message.getPayload() instanceof ReportingContext))
			return message;

		context = (ReportingContext)message.getPayload();

		cntxtType 	= context.getContextType();
		response 	= context.getResponse();

		if(null == cntxtType
				|| null == response)
			return message;


		if (null == context.getResponse())
			return message;

		reportId 		= context.getResponse().getInReplyTo();

		if(null == reportId)
			return message;

		parentMessage 	= regRepMessageDao.findByPrimaryKeyNS(reportId);

		if(null == parentMessage)
			return message;

		/*
		 * Amit Rana
		 * Change - 1.1
		 * Setting for response that has to be published upstream
		 */

		if(null == context.getSdrRequest())
			context.setSdrRequest(new SdrRequest());

		context.getSdrRequest()
		.setMessageId(parentMessage.getExternalMessageId());

		/*
		 * change 1.1 - finished
		 */

		rulesResultsContext = new RulesResultsContext();
		context.setRulesResultsContext(rulesResultsContext);

		rulesResultsContext.setResultsSource("SDR_RES");

		/*
		 * In case of ACK -  Both lists are supposed to be empty
		 * In case of Wack - Only alert List needs to populated
		 * In case of Nack - Only filter List needs to populated
		 *
		 */

		if (PayloadTypeEnum.SDR_RESPONSE_NACK.equals(cntxtType)){			
			
			reasons = response.getReasons();
			
			if(null != reasons && reasons.size() > 0){
				
				if(ExceptionTypeEnum.SDR_WARNING.equals(reasons.get(0).type)){
					
					cntxtType = PayloadTypeEnum.SDR_RESPONSE_WACK;
				}
			}
		}
			
		if (PayloadTypeEnum.SDR_RESPONSE_NACK.equals(cntxtType)){
			
			reasons = response.getReasons();
			
			if(null != reasons && reasons.size() > 0){
			
				for (Reason reason : reasons)
				{
					
					if(null == reason)
						continue;
					
					result = new ValidationResult();
					result.setCode(reason.reasonCode);
					result.setErrorDesc(reason.description);
					result.setValidationType(ResponseCodeEnum.NACK.value());
					result.setFieldName(reason.ProblemLocationType);

					rulesResultsContext.addFilterValidationResult(result);
				}
			}	
			
		}else if (PayloadTypeEnum.SDR_RESPONSE_WACK.equals(cntxtType)){

			for (Reason reason : response.getReasons())
			{

				result = new ValidationResult();
				result.setCode(reason.reasonCode);
				result.setErrorDesc(reason.description);
				result.setValidationType(ResponseCodeEnum.WACK.value());
				result.setFieldName(reason.ProblemLocationType);

				rulesResultsContext.addAlertValidationResult(result);
			}
		}

		// Check for DTCC USI here
		if (PayloadTypeEnum.SDR_RESPONSE_ACK.equals(cntxtType)){

			if(GTR_CREATE_USI.equals(parentMessage.getTradeUsi())){

				rulesResultsContext.setResultsSource("GTR_USI");
			}
		}

		logger.debug("Leaving prepareResponse");
		return message;
	}

	public static void setRegRepMessageDao(RegRepMessageDao regRepMessageDao) {
		RegRepResponseGenerator.regRepMessageDao = regRepMessageDao;
	}

}
