package com.wellsfargo.regulatory.core.services.transformers;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;

@Component
public class ResponseContextToRegRepMessageTransformer
{
	@Autowired
	RegRepMessageDao regRepMessageDao;

	private static Logger logger = Logger.getLogger(ResponseContextToRegRepMessageTransformer.class.getName());

	// @Transformer
	public RegRepMessage transform(Message<ReportingContext> simessage) throws MessagingException
	{
		ReportingContext responseContext = simessage.getPayload();
		
		//AbstractDriver.setMDCInfo(responseContext, AbstractDriver.ResponseContextToRegRepMessageTransformer);

		RegRepMessage reportedMessage = null;
		
		try 
		{
			reportedMessage = getReportedMessage(responseContext);
		}
		catch (Exception e) 
		{
			logger.warn("Caught " + e.getLocalizedMessage());
		}
		
		if (null == reportedMessage) 
		{
			logger.debug("transform: filtering out NRP response: " + responseContext.getMessageId());
			logger.debug("NRP message: " + responseContext.getPayload());
			
			return null; // Filter out NRP alleged messages from SDR
		}

		return reportedMessage;
	}

	/**
	 * @param responseContext
	 */
	public RegRepMessage getReportedMessage(ReportingContext responseContext)
	{
		// TODO: Check if we can do this without an explicit DB find
		// by using a RegRepResponse object instead.
		// TODO: OR move this to a utility class and use it from
		// Driver.persist as well.
		// TODO: OR add a one-to-one mapping to the HBM config
		if (null == responseContext.getResponse()) logger.error("NULL FpMLResponse in ReportingContext");
		
		//AbstractDriver.setMDCInfo(responseContext, AbstractDriver.ResponseContextToRegRepMessageTransformer);

		String reportedMessageId = responseContext.getResponse().getInReplyTo();
		
		if (null == reportedMessageId) logger.error(">>>>>>>>> FpMLResponse from ReportingContext has no inReplyTo ID <<<<<<<<< ");
		
		RegRepMessage reportedMessage = regRepMessageDao.findByPrimaryKeyNS(reportedMessageId);
		
		if (null == reportedMessage)
		{
			logger.warn(">>>>>>>>> COULDN'T FIND THE ORIGINAL SUBMITTED REPORT MESSAGE FOR RECIEVED RESPONSE <<<<<<<<< ReplyTo: " + responseContext.getResponse().getInReplyTo());
		}
		
		return reportedMessage;
	}
}
