/**
 *
 */
package com.wellsfargo.regulatory.core.services.transformers;

import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepUniqueIdentifierMappingCache;
import com.wellsfargo.regulatory.persister.dao.RegRepMessageDao;
import com.wellsfargo.regulatory.persister.dao.RegRepUniqueIdentifierMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepMessage;
import com.wellsfargo.regulatory.persister.dto.RegRepTrade;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMappingId;

/**
 * @author u337814
 */

@Component
public class RegRepGtrCreateIdentifier
{

	@Autowired
	RegRepMessageDao messageDao;

	@Autowired
	RegRepUniqueIdentifierMappingDao usiMappingDao;
	
	@Autowired
	RegRepUniqueIdentifierMappingCache regRepUniqueIdentifierMappingCache;

	private static Logger logger = Logger.getLogger(RegRepGtrCreateIdentifier.class.getName());
	
	
	public static final Pattern usiPrefixPattern= Pattern.compile("<issuer issuerIdScheme.+>(.*?)</issuer>", Pattern.DOTALL);
	public static final Pattern usiValuePattern= Pattern.compile("<tradeId tradeIdScheme=\"http://www.fpml.org/coding-scheme/external/unique-transaction-identifier\">(.*?)</tradeId>", Pattern.DOTALL);
	public static final Pattern sentByPattern= Pattern.compile("<sentBy>(.*?)</sentBy>", Pattern.DOTALL);
	

	public Message<?> handleGtrCreate(Message<?> message)
	{

		ReportingContext cntxt = null;
		RegRepUniqueIdentifierMapping usiMap = null;
		String gtrUsi = null;
		String orglMsg = null;
		PayloadTypeEnum resType = null;
		String[] rptType = null;
		String prntRptType = null;
		Boolean isAck = false;
		String lifeCycleEvent = null;
		
		cntxt = (ReportingContext) message.getPayload();

//		if (null != usiMap)
		{

			orglMsg = cntxt.getPayload();
			resType = cntxt.getContextType();

			rptType = new String[2];
			prntRptType = cntxt.getResponse().getParentreportType();
			
			if (cntxt.getLifeCycleEvent()!= null )
				lifeCycleEvent = cntxt.getLifeCycleEvent();
			
			if (PayloadTypeEnum.SDR_RESPONSE_ACK.equals(resType))
			{
				if (Constants.MESSAGE_TYPE_PET.equals(prntRptType) || Constants.MESSAGE_TYPE_CONF.equals(prntRptType))
				{
					rptType[0] = Constants.FPML_PET_ACK_NS_TYPE;
					rptType[1] = Constants.FPML_PET_NS_TYPE;
				}
				else if (Constants.MESSAGE_TYPE_RT.equals(prntRptType))
				{
					rptType[0] = Constants.FPML_RT_ACK_NS_TYPE;
					rptType[1] = Constants.FPML_RT_NS_TYPE;
				}

				isAck = true;
			}
			else if (PayloadTypeEnum.SDR_RESPONSE_NACK.equals(resType))
			{
				if (Constants.MESSAGE_TYPE_PET.equals(prntRptType) || Constants.MESSAGE_TYPE_CONF.equals(prntRptType))
				{
					rptType[0] = Constants.FPML_PET_NACK_NS_TYPE;
					rptType[1] = Constants.FPML_PET_NS_TYPE;
				}
				else if (Constants.MESSAGE_TYPE_RT.equals(prntRptType))
				{
					rptType[0] = Constants.FPML_RT_NACK_NS_TYPE;
					rptType[1] = Constants.FPML_RT_NS_TYPE;
				}
			}

			if (lifeCycleEvent == null)
			{
				return message;
			}
			
			
			gtrUsi = extractGtrUsi(orglMsg, rptType, isAck, cntxt);
			
			if (gtrUsi == null || gtrUsi.isEmpty() || gtrUsi.equals(":")){
				
				return message;
			}
			
			cntxt.setUsi(gtrUsi);

			usiMap = checkGtrCreate(cntxt);

			if (null != gtrUsi && null != usiMap)
			{
				usiMap.setCurrentValue(gtrUsi);
				usiMap.setUpdateDatetime(CalendarUtils.getCurrentDateInUTC());

				updateUsiMap(usiMap);
			}
		}

		return message;
	}

	
	/**
	 * @param orglMsg
	 * @return
	 */
	public String extractGtrUsi(String orglMsg, String[] rptType,
			 Boolean isAck, ReportingContext cntxt)
	{

		String gtrUsi = null;
		String usiPrefix = null;
		String usiVal = null;
		String sentBy = null;

		try
		{

			Matcher usiPrefixpath = usiPrefixPattern.matcher(orglMsg);
			if(usiPrefixpath.find()) 
			{	 
				usiPrefix = usiPrefixpath.group(1);
			}
			Matcher usiValuepath = usiValuePattern.matcher(orglMsg);
			if(usiValuepath.find()) 
			{	 
				usiVal = usiValuepath.group(1);
			}
			Matcher sentBypath = sentByPattern.matcher(orglMsg);
			if(sentBypath.find()) 
			{	 
				sentBy = sentBypath.group(1);
			}
			
			
			/*
			 * Logic for CFTC - DTCC
			 */
			if("DTCCUS".equals(sentBy)){
				cntxt.getRegulatories().clear();
				cntxt.getRegulatories().put("CFTC_DTCC",UsThemEnum.US+"");
			}


		}
		catch (Exception e)
		{
			logger.error(e);
		}

		if (null != usiPrefix && null != usiVal) gtrUsi = usiPrefix + usiVal;

		return gtrUsi;
	}

	private RegRepUniqueIdentifierMapping checkGtrCreate(ReportingContext cntxt)
	{

		Boolean isGtrCreate = false;
		String reportId = null;
		RegRepMessage message = null;
		RegRepTrade trade = null;
		String tradeId = null;
		RegRepUniqueIdentifierMappingId usiMapId = null;
		RegRepUniqueIdentifierMapping usiMap = null;
		String jrsdctn = null;
		String rpstry = null;
		String identifier = null;
		Set<String>	regulatorySet = null;
		String regulatory = null;
		String rptType = null;

		if (null == cntxt || null == cntxt.getResponse()) 
			return usiMap;

		reportId = cntxt.getResponse().getInReplyTo();
		rptType = cntxt.getResponse().getParentreportType();

		/**
		 * QC:948 -> Prod - Submitting different USI's to DTCC for the same Trade
		 * Do persist or update in REG_REP_UNIQUE_IDENTIFIER_MAPPING only for PET messages*/
		if (null == reportId || !StringUtils.equalsIgnoreCase(Constants.MESSAGE_TYPE_PET,rptType)) 
			return usiMap;

		try
		{

			message = messageDao.findByPrimaryKeyNS(reportId);

			if (null == message) return usiMap;

			trade = message.getRegRepTrade();

			if (null == trade) return usiMap;

			tradeId = trade.getSwapTradeId();

			if (null == tradeId) return usiMap;

			if (null != cntxt.getRegulatories())
			{				
				regulatorySet = cntxt.getRegulatories().keySet();
				
				Optional<String> availableRegulatory = regulatorySet.stream().filter(s -> s!=null).findAny();
				regulatory=availableRegulatory.isPresent()?availableRegulatory.get():null;
				if(null != regulatory){
					String regArr[]=StringUtils.split(regulatory, Constants.UNDERSCORE);
					jrsdctn = regArr[0];
					if (regArr.length > 1) 
						rpstry = regArr[1];
				}
				
			}

			if (Constants.DTCC.equals(rpstry))
			{
				identifier = Constants.USI;
			}
			else if (Constants.ESMA.equals(rpstry))
			{
				identifier = Constants.UTI;
			}

			if (null == rpstry || null == jrsdctn || null == identifier) return usiMap;

			usiMapId = new RegRepUniqueIdentifierMappingId();
			usiMapId.setIdentifierType(identifier);
			usiMapId.setJurisdiction(jrsdctn);
			usiMapId.setRepository(rpstry);
			usiMapId.setTradeId(tradeId);

			usiMap = usiMappingDao.findByPrimaryKey(usiMapId);

			if (null != usiMap)
			{
				if (null == usiMap.getCurrentValue() || usiMap.getCurrentValue().equals(":")) isGtrCreate = true;
			}
		}
		catch (Exception e)
		{
			logger.error(e);
		}

		if (!isGtrCreate) usiMap = null;

		return usiMap;
	}

	private Boolean updateUsiMap(RegRepUniqueIdentifierMapping usiMap)
	{

		Boolean successfullyUpdated = false;

		try
		{
			usiMappingDao.saveOrUpdate(usiMap);
			//updating cache
			regRepUniqueIdentifierMappingCache.updateTradeUsiMapping(usiMap);
			successfullyUpdated = true;
		}
		catch (Exception e)
		{
			logger.error(e);
		}

		return successfullyUpdated;
	}

	public void setMessageDao(RegRepMessageDao messageDao)
	{
		this.messageDao = messageDao;
	}

	public void setUsiMappingDao(RegRepUniqueIdentifierMappingDao usiMappingDao)
	{
		this.usiMappingDao = usiMappingDao;
	}

}
