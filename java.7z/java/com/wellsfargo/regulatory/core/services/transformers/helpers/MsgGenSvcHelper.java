package com.wellsfargo.regulatory.core.services.transformers.helpers;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.CollateralTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DesignationEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.VerificationMethodEnum;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class MsgGenSvcHelper
{

	private static final String XPATH_SEPERATOR = "/";
	private String packageName;
	private String productType;
	private String lifecycleEvent;
	private String reportType;
	
	private static final String SEPERATOR = ".";

	private static final Log logger = LogFactory.getLog(MsgGenSvcHelper.class);

	public void setPackageName(String packageName)
	{
		this.packageName = packageName;
	}

	public void setProdutType(String productType)
	{
		this.productType = productType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	
	public String getReportType() {
		return reportType;
	}

	public String getLifecycleEvent() {
		return lifecycleEvent;
	}

	public void setLifecycleEvent(String lifecycleEvent) {
		this.lifecycleEvent = lifecycleEvent;
	}

	/**
	 * @param jxPathContext
	 * - context to be evaluated
	 * @param xPath
	 * - xPath to be evaluated
	 * @param value
	 * - value to be set in case of a leaf node
	 * @param dataType
	 * - type of the value Checks and generates the object in a JxContext for given xPath till the
	 * leaf node
	 */
	public void evaluateXpath(JXPathContext jxPathContext, String xPath, Object value, String dataType, List<String[]> classTypeList)
	{
		logger.debug("Entering evaluateXpath() method");

		String traversedPath 	= "";
		boolean isLeafode 		= false;
		String[] nodes 			= xPath.split(XPATH_SEPERATOR);

		if (nodes.length <= 0)
		{
			return;
		}

		for (String node : nodes)
		{
			if (StringUtils.isBlank(node))
			{
				traversedPath = traversedPath + XPATH_SEPERATOR;
				continue;
			}

			traversedPath = traversedPath + node;

			if (xPath.equals(traversedPath))
			{
				isLeafode = true;
			}

			setNodeValue(jxPathContext, traversedPath, isLeafode, value, dataType, classTypeList, false);
			traversedPath = traversedPath + XPATH_SEPERATOR;
		}
		
		logger.debug("Leaving evaluateXpath() method");
	}

	@SuppressWarnings("unchecked")
	private void setNodeValue(JXPathContext jxPathContext, String traversedPath, boolean isLeafNode, Object value, String dataType, List<String[]> classTypeList, boolean toAdd)
	{
		logger.debug("Entering setNodeValue() method");

		Object classObject 				= null;
		String className 				= null;
		String[] elements 				= null;
		String currentElement 			= null;
		String[] methodArgs 			= null;
		XMLGregorianCalendar calendar 	= null;
		String format 					= null;
		SimpleDateFormat sdf 			= null;

		if (isLeafNode)
		{
			try
			{
				if ("byte[]".equals(dataType))
				{
					jxPathContext.setValue(traversedPath, ((String) value).getBytes());
					return;
				}

				if (dataType.contains("XMLGregorianCalendarTime"))
				{
					dataType 	= "javax.xml.datatype.XMLGregorianCalendar";
					format 		= CalendarUtils.FORMAT_2;
				}
				else if(dataType.contains("XMLGregorianCalendarDate"))
				{
					dataType 	= "javax.xml.datatype.XMLGregorianCalendar";
					format 		= CalendarUtils.FORMAT_3;
				}
				else
				{
					format = CalendarUtils.FORMAT_1;
				}

				Class<?> clss = Class.forName(dataType.trim());

				if (dataType.contains("Enum"))
				{
					value = getEnumValue(value, clss);
				}
				else if (dataType.contains("XMLGregorianCalendar"))
				{
					if (value instanceof XMLGregorianCalendar)
					{
						calendar	= (XMLGregorianCalendar) value;
						value 		= CalendarUtils.getCalendarInSpecificFormat(format, calendar);
					}
					else if(value instanceof String)
					{
						sdf = new SimpleDateFormat(format);
						
						if(CalendarUtils.FORMAT_3.equals(format))
							value = CalendarUtils.getDateFromString((String)value, sdf);
						if(CalendarUtils.FORMAT_2.equals(format))
							value = CalendarUtils.getTimeFromString((String)value, sdf);
					}
				}
				
				/*** TODO : Temp fix for Designation Enum, DTCC expects the value to be non-SD/MSP. Enum doesn't take - or / as names. ***/
				if(value instanceof DesignationEnum)
				{
					value  = ((DesignationEnum) value).value();
					if (value.equals("Non-SD_Non-MSP"))
					{
						value = "non-SD/MSP";
					}
				} 
				else if (value instanceof CollateralTypeEnum)
				{
					value  = ((CollateralTypeEnum) value).value();
				}
				else if (value instanceof VerificationMethodEnum)
				{
					value  = ((VerificationMethodEnum) value).value();
				}
				else if ( value instanceof com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.dtcc.OptionTypeEnum || 
						value instanceof com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency.dtcc.OptionTypeEnum )
				{
					value  = ((com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.dtcc.OptionTypeEnum) value).value();
				} 
				else if (value instanceof com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.dtcc.ExerciseStyleEnum  ||
							value instanceof com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.transparency.dtcc.ExerciseStyleEnum ) 
				{
					value  = ((com.wellsfargo.regulatory.commons.bo.fpml.fpml_5_5.recordkeeping.dtcc.ExerciseStyleEnum) value).value();		
				}  
				/*** TODO : temp fix for option type and option style enum value population - qcid 593 ***/
				
				jxPathContext.setValue(traversedPath, value);
			}
			catch (Exception e)
			{
				try
				{
					jxPathContext.setValue(traversedPath, new BigInteger(value.toString()));
				}
				catch (Exception er)
				{
					jxPathContext.setValue(traversedPath, new BigDecimal(value.toString()));
				}
			}

			return;
		}

		elements 			= traversedPath.split(XPATH_SEPERATOR);
		currentElement 		= elements[elements.length - 1];
		Object nodeObject 	= getValue(jxPathContext, traversedPath, dataType, classTypeList);

		if (null == nodeObject)
		{
			className 		= GeneralUtils.capitalizeFirstLetter(currentElement);
			className 		= getClassNameExceptions(className, classTypeList, traversedPath);
			classObject 	= getOjectInstance(className);

			jxPathContext.setValue(traversedPath, classObject);
		}
		else if (nodeObject instanceof List<?>)
		{
			if (currentElement.contains("=")) 
				methodArgs = getMethodArgs(currentElement);

			currentElement 	= currentElement.replaceAll("\\[([^\\]]+)]", "");
			className 		= GeneralUtils.capitalizeFirstLetter(currentElement);
			className 		= getClassNameExceptions(className, classTypeList, traversedPath);
			classObject 	= getOjectInstance(className);

			if (null != methodArgs) 
				setAttribute(classObject, methodArgs);

			((List<Object>) nodeObject).add(classObject);
		}
		else 
		{
			/*** Adding @ a later stage. So toAdd makes sure it doesn't cause any regression. ***/
			if(toAdd)
				jxPathContext.setValue(traversedPath, nodeObject);
		}
		
		logger.debug("Leaving setNodeValue() method");
	}

	private Object getEnumValue(Object value, Class<?> clss)
	{
		logger.debug("Entering getEnumValue() method");
		try 
		{
			Method method = clss.getDeclaredMethod("fromValue", String.class);
			value = method.invoke(null, value.toString());
			
		} 
		catch (Exception e) 
		{
			    Enum<?>[] enumValues = (Enum<?>[])clss.getEnumConstants();
				for (Enum<?> enuTocheck : enumValues) 
				{
					if(value!=null && enuTocheck!=null && enuTocheck.name().equalsIgnoreCase(value.toString()))
						return enuTocheck;
				}
		}
		
		logger.debug("Leaving getEnumValue() method");

		return value;
	}

	@SuppressWarnings("unchecked")
	private Object getValue(JXPathContext jxPathContext, String path, String dataType, List<String[]> classTypeList)
	{
		Object object 				= null;
		List<Object> objInsideList 	= null;
		String[] elements 			= null;
		String currentElement 		= null;
		String updatedPath 			= "";
		int pos 					= -1;

		if (StringUtils.isBlank(path) || null == jxPathContext) return object;

		// In order to get an object inside a collection
		try
		{
			object = jxPathContext.getValue(path);
			return object;
		}
		catch (Exception e)
		{
			object = null;
		}

		elements 		= path.split(XPATH_SEPERATOR);
		currentElement 	= elements[elements.length - 1];

		if (currentElement.contains("["))
		{
			if (!currentElement.contains("="))
			{
				pos = getPositionInList(currentElement) - 1;
			}

			currentElement = currentElement.replaceAll("\\[([^\\]]+)]", "");

			for (int counter = 0; counter < elements.length - 1; counter++)
			{
				updatedPath = updatedPath + elements[counter] + XPATH_SEPERATOR;
			}

			path 			= updatedPath + currentElement;
			objInsideList 	= (List<Object>) jxPathContext.getValue(path);

			/*
			 * Change 1.1 Tweak to ensure if a subsequent element in the list is getting inserted
			 * first. For example trying to set partyId[2]/value when party[1] has not been
			 * inserted. Here (pos - listSize - 1) would give the position of the element, where we
			 * need to start the insertion from. This is to take care of the condition when position
			 * 1,2 are present inside the list and we are now inserting 5
			 */

			if (pos > objInsideList.size())
			{	
				for (int i = objInsideList.size(); i <= pos; i++)
				//for (int i = pos - objInsideList.size() - 1; i < pos; i++)
					setNodeValue(jxPathContext, path + "[" + i + "]", false, null, dataType, classTypeList, true);
			}

			/*
			 * Change 1.1 ends here.
			 */
			object = objInsideList;
		}
		else
		{
			object = jxPathContext.getValue(path);
		}

		return object;
	}

	private Object getOjectInstance(String className)
	{
		Object object = null;
		Class<?> clazz = null;

		if (null == className)
		{
			logger.error("######### Object instance could not be created, since the class name was null ");
			return object;
		}

		try
		{
			/*
			 * Fully qualified name also be specified
			 */
			if(StringUtils.contains(className, SEPERATOR))
			{
				clazz = Class.forName(className);
			}
			else
			{
				clazz = Class.forName(packageName + SEPERATOR + className);
			}

			Constructor<?> ctor = clazz.getConstructor();
			object = ctor.newInstance(new Object[]{});
		}
		catch (Exception e)
		{
			logger.error("######### Failed to create instance of class :  " + className, e);
		}

		return object;
	}

	private void setAttribute(Object object, String[] methodArgs)
	{
		String setterMethod = null;
		Class<?> clazz = null;

		if (null == methodArgs || null == object || methodArgs.length < 2) return;

		clazz = object.getClass();
		setterMethod = "set" + GeneralUtils.capitalizeFirstLetter(methodArgs[0]);

		try
		{
			Method method = clazz.getDeclaredMethod(setterMethod, String.class);
			method.invoke(object, methodArgs[1]);
		}
		catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e)
		{
			logger.error("######### Failed to set the atributes " + methodArgs[0] + " " + methodArgs[1] + " of Object " + object.getClass());
		}
	}

	// - This would eventually go to a static table
	private String getClassNameExceptions(String className, List<String[]> classTypeList, String traversedPath)
	{
		if (null != classTypeList)
		{
			for (String[] classMap : classTypeList)
			{
				if (null != traversedPath)
				{
					if (traversedPath.equalsIgnoreCase(classMap[0]))
					{
						className = classMap[1];
						break;
					}
				}
			}
		}

		if (className.equalsIgnoreCase("product"))
		{
			if ( productType!=null && productType.contains("DTCC") &&  !Constants.MESSAGE_TYPE_SNAPSHOT.equals(getReportType()) &&
				 !(Constants.Trade.equals(lifecycleEvent) || Constants.Amendment.equals(lifecycleEvent) || Constants.Cancel.equals(lifecycleEvent)))
			{
				className = "OriginalProductReferenceDTCC";
			} 
			else 
			{
				className = productType;
			}
			
			if(className.contains("DTCC"))
				className = packageName + SEPERATOR + "dtcc" + SEPERATOR + className;
		}
		else if (className.equalsIgnoreCase("primaryassetClass"))
		{
			className = "AssetClass";
		}
		else if (className.equalsIgnoreCase("header"))
		{
			className = "RequestMessageHeader";
		}
		else if (className.equalsIgnoreCase("amendment"))
		{
			className = "TradeAmendmentContent";
		}
		else if (className.equalsIgnoreCase("novation"))
		{
			className = "TradeNovationContent";
		}
		else if (className.equalsIgnoreCase("increase"))
		{
			className = "TradeNotionalChange";
		}
		else if (className.equalsIgnoreCase("notional") || className.equalsIgnoreCase("remainingAmount") || className.equalsIgnoreCase("novatedAmount"))
		{
			className = "Money";
		}
		else if (className.equalsIgnoreCase("paymentAmount") || className.equalsIgnoreCase("outstandingNotionalAmount") || className.equalsIgnoreCase("changeInNotionalAmount")
		        || className.equalsIgnoreCase("putCurrencyAmount") || className.equalsIgnoreCase("callCurrencyAmount"))
		{
			className = "NonNegativeMoney";
		}
		else if (className.equalsIgnoreCase("sentBy"))
		{
			className = "MessageAddress";
		}
		else if (className.equalsIgnoreCase("adjustedEffectiveDate"))
		{
			className = "RequiredIdentifierDate";
		}
		else if (className.equalsIgnoreCase("fixedRate") && !productType.equalsIgnoreCase(Constants.CREDITDEFAULTSWAP))
		{
			className = "IdentifiedRate";
		}
		else if (className.equalsIgnoreCase("termination"))
		{
			className = "TradeNotionalChange";
		}
		else if (className.equalsIgnoreCase("indexTenor"))
		{
			className = "Period";
		}
		else if (className.equalsIgnoreCase("originatingTradeId"))
		{
			className = "TradeIdentifier";
		}
		else if (className.equalsIgnoreCase("issuer"))
		{
			className = "IssuerId";
		}
		else if (className.equalsIgnoreCase("sendTo"))
		{
			className = "MessageAddress";
		}
		else if (className.equalsIgnoreCase("businessUnitId"))
		{
			className = "Unit";
		}
		else if (className.equalsIgnoreCase("newTradeIdentifier") || className.equalsIgnoreCase("feeTradeIdentifier") || className.equalsIgnoreCase("oldTradeIdentifier"))
		{
			className = "PartyTradeIdentifier";
		}
		else if (className.equalsIgnoreCase("oldTrade") || className.equalsIgnoreCase("newTrade") || className.equalsIgnoreCase("feeTrade") || className.equalsIgnoreCase("originalTrade"))
		{
			className = "Trade";
		}
		else if (className.equalsIgnoreCase("novationAmount"))
		{
			className = "TradeLegSizeChange";
		}
		else if (className.equalsIgnoreCase("role"))
		{
			className = "PartyRole";
		}
		else if (className.equalsIgnoreCase("version"))
		{
			className = "ImplementationSpecificationVersion";
		}
		else if (className.equalsIgnoreCase("issuer"))
		{
			className = "IssuerId";
		}
		else if (className.equalsIgnoreCase("eventIdentifier"))
		{
			className = "BusinessEventIdentifier";
		}
		else if (className.equalsIgnoreCase("swapStream"))
		{
			className = "InterestRateStream";
		}
		else if (className.equalsIgnoreCase("buyerPartyReference") || className.equalsIgnoreCase("sellerPartyReference") || className.equalsIgnoreCase("payerPartyReference")
		        || className.equalsIgnoreCase("receiverPartyReference"))
		{
			className = "PartyReference";
		}
		else if (className.equalsIgnoreCase("NotionalSchedule"))
		{

			className = "Notional";
		}
		else if (className.equalsIgnoreCase("notionalStepSchedule"))
		{

			className = "NonNegativeAmountSchedule";
		}
		else if (className.equalsIgnoreCase("EffectiveDate") || className.equalsIgnoreCase("terminationDate"))
		{

			className = "AdjustableDate";
		}
		else if (className.equalsIgnoreCase("unadjustedDate"))
		{

			className = "IdentifiedDate";
		}
		else if (className.equalsIgnoreCase("rateCalculation"))
		{

			className = "FloatingRateCalculation";
		}
		else if (className.equalsIgnoreCase("paymentFrequency"))
		{

			className = "Frequency";
		}
		else if (className.equalsIgnoreCase("additionalPayment"))
		{

			className = "Payment";
		}
		else if (className.equalsIgnoreCase("fixedRateSchedule"))
		{

			className = "Schedule";
		}
		else if (className.equalsIgnoreCase("tradeDate"))
		{

			className = "IdentifiedDate";
		}
		else if (className.equalsIgnoreCase("expirationDate") || className.equalsIgnoreCase("settlementDate"))
		{

			className = "AdjustableOrRelativeDate";
		}
		else if (className.equalsIgnoreCase("European"))
		{

			className = "EuropeanExercise";
		}
		else if (className.equalsIgnoreCase("American"))
		{

			className = "AmericanExercise";
		}
		else if (className.equalsIgnoreCase("Bermudan"))
		{

			className = "BermudaExercise";
		}
		else if (className.equalsIgnoreCase("paymentDate"))
		{

			className = "AdjustableOrAdjustedDate";
		}
		else if (className.equalsIgnoreCase("exchangedCurrency1") || className.equalsIgnoreCase("exchangedCurrency2"))
		{

			className = "Payment";
		}
		else if (className.equalsIgnoreCase("strike"))
		{

			className = "FxStrikePrice";
		}

		return className;
	}

	private int getPositionInList(String data)
	{
		String matchedPattern = null;

		Pattern patt 	= Pattern.compile("\\[(\\d+)\\]");
		Matcher match 	= patt.matcher(data);
		while (match.find())
		{
			matchedPattern = match.group();
			if (null != matchedPattern)
			{
				matchedPattern = matchedPattern.replace("[", "");
				matchedPattern = matchedPattern.replace("]", "");
			}
		}

		return Integer.parseInt(matchedPattern);
	}

	private String[] getMethodArgs(String data)
	{
		String[] args 			= null;
		String matchedPattern 	= null;

		Pattern patt 	= Pattern.compile("\\[([^\\]]+)]");
		Matcher match 	= patt.matcher(data);
		
		while (match.find())
		{
			matchedPattern = match.group();
			if (null != matchedPattern)
			{
				matchedPattern = matchedPattern.replace("[", "");
				matchedPattern = matchedPattern.replace("]", "");
				matchedPattern = matchedPattern.replace("'", "");

				args = matchedPattern.split("=");
			}
		}

		return args;
	}
	
}
