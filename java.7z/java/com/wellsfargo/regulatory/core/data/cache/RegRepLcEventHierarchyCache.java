package com.wellsfargo.regulatory.core.data.cache;

import java.util.ArrayList;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.cache.dao.impl.RegRepLcEventHierarchyDaoImpl;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepLcEventHierarchy;

/**
 * @author Raji Komatreddy
 */

@Component
public class RegRepLcEventHierarchyCache
{
	@Autowired
	CacheManager cacheManager;

	@Autowired
	RegRepLcEventHierarchyDaoImpl regRepLcEventHierarchyDaoImpl;
	private static Log logger = LogFactory.getLog(RegRepLcEventHierarchyCache.class);

	public void loadLeEventsToCache()
	{
		logger.info("inside RegRepLcEventHierarchyCache: loadLeEventsToCache method ");
		if (null != cacheManager)
		{
			try
			{

				Cache lCEventCache = cacheManager.getCache("lCEventCache");

				lCEventCache.removeAll();
				List<RegRepLcEventHierarchy> eventsList = null;
				List<Element> eventElementList = new ArrayList<Element>();

				// get Data from RegRepLcEventHierarchy table
				if (null != regRepLcEventHierarchyDaoImpl) eventsList = regRepLcEventHierarchyDaoImpl.getAllEvents();

				for (RegRepLcEventHierarchy currEvent : eventsList)
				{

					if (null != currEvent.getEventName())
					{
						Element currElement = new Element(currEvent.getEventName(), currEvent);
						eventElementList.add(currElement);
					}
					else
					{
						logger.info("no data inside RegRepTradeValidation table ");

					}

				}

				lCEventCache.putAll(eventElementList);

			}
			catch (Exception ex)
			{
				logger.error("exception occurred while loading cache into RegRepLcEventHierarchyCache " + ExceptionUtils.getFullStackTrace(ex));
			}
		}

	}

	/**
	 * @param childEvent
	 * Gets all valid parent events possible for given child event first checks in cache, if not
	 * available try to get it from DB
	 * @return
	 */
	public List<String> getParentEvents(String childEvent)
	{
		List<String> parentEventsList = new ArrayList<String>();
		RegRepLcEventHierarchy currRegRepLcEventHierarchy = null;
		String parentEvent = null;
		String[] parentEvents = null;

		Cache lCEventCache = cacheManager.getCache("lCEventCache");
		if (null != lCEventCache)
		{
			Element currElement = lCEventCache.get(childEvent);
			if (null != currElement)
			{
				currRegRepLcEventHierarchy = (RegRepLcEventHierarchy) currElement.getObjectValue();
				logger.info("getting RegRepTradeValidation object from Cache: "  + childEvent);
				
			}
				
		}

		if (null == currRegRepLcEventHierarchy)
		{
			if(null !=  regRepLcEventHierarchyDaoImpl.getEvent(childEvent) && regRepLcEventHierarchyDaoImpl.getEvent(childEvent).size() > 0)
			{
				currRegRepLcEventHierarchy = regRepLcEventHierarchyDaoImpl.getEvent(childEvent).get(0);
				Element currElement = new Element(currRegRepLcEventHierarchy.getEventName(), currRegRepLcEventHierarchy);
				lCEventCache.put(currElement);
				
				logger.info("getting RegRepTradeValidation object from DB and added to cache now :" + childEvent);
				
			}
			

		}
		if (null != currRegRepLcEventHierarchy)
		{
			parentEvent = currRegRepLcEventHierarchy.getParentEventNames();
			if (null != parentEvent) parentEvents = parentEvent.split(",");

			for (String currParent : parentEvents)
			{
				parentEventsList.add(currParent.trim());
			}

		}

		if (parentEventsList.size() == 0)
			logger.info("child LifeCycle event neither present in Cache nor in DB :" + childEvent);

		return parentEventsList;
	}

}
