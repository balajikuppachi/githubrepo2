package com.wellsfargo.regulatory.core.data.cache;

import java.util.ArrayList;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.cache.dao.impl.RegRegTradeValidationDaoImpl;
import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;

/**
 * @author Raji Komatreddy
 */

@Component
public class RegRepTradeValidationCache
{
	@Autowired
	CacheManager cacheManager;

	@Autowired
	RegRegTradeValidationDaoImpl regRegTradeValidationDaoImpl;
	private static Log logger = LogFactory.getLog(RegRepTradeValidationCache.class);
	

	public void loadTradeValidationToCache()
	{
		logger.info("inside RegRepTradeValidationCache: loadTradeValidationToCache method ");

		if (null != cacheManager)
		{
			try
			{

				Cache eodCache = cacheManager.getCache("eodCache");
				
				//remove all existing elements from cache
				eodCache.removeAll();
				
				List<RegRepTradeValidation> tradeValList = null;
				List<Element> tradeElementList = new ArrayList<Element>();

				// get Data from TradeValidation table
				if (null != regRegTradeValidationDaoImpl) tradeValList = regRegTradeValidationDaoImpl.getAllTrades();

				for (RegRepTradeValidation currTradeVal : tradeValList)
				{

					if (null != currTradeVal.getTradeid())
					{
						Element currElement = new Element(currTradeVal.getTradeid(), currTradeVal);
						tradeElementList.add(currElement);
					}
					else
					{
						logger.info("no data inside RegRepTradeValidation table ");

					}

				}

				eodCache.putAll(tradeElementList);
			}
			catch (Exception ex)
			{
				logger.error("exception occurred while loading cache into RegRepTradeValidationCache " + ExceptionUtils.getFullStackTrace(ex));
			}

		}

		logger.info("exiting RegRepTradeValidationCache: loadTradeValidationToCache method ");

	}

	public RegRepTradeValidation getTradeValidationDtls(String tradeID)
	{
		String cuurTradeId = null;
		RegRepTradeValidation currRegRepTradeValidation = null;
		
		Cache eodCache = cacheManager.getCache("eodCache");
		
		if (null != eodCache)
		{
			Element currElement = eodCache.get(tradeID);
			if (null != currElement)
			{
				currRegRepTradeValidation = (RegRepTradeValidation) currElement.getObjectValue();
				logger.info("getting RegRepTradeValidation object from Cache");
				
			}
			

			
		}

		if (null == currRegRepTradeValidation)
		{
			List<RegRepTradeValidation> tradeDetails = regRegTradeValidationDaoImpl.getTrade(tradeID);
			if (!GeneralUtils.IsListNullOrEmpty(tradeDetails))
			{
				currRegRepTradeValidation = (RegRepTradeValidation) tradeDetails.get(0);
				if (null != currRegRepTradeValidation)
				{
					cuurTradeId = currRegRepTradeValidation.getTradeid();

					Element currElement = new Element(cuurTradeId, currRegRepTradeValidation);
					eodCache.put(currElement);

					logger.info("tradeId does not exist in cache before, adding it now");

				}

			}

			if (null != currRegRepTradeValidation)
			{
				logger.info("got RegRepTradeValidation object from Database");
			}
			else
			{
				logger.info("could not find RegRepTradeValidation object either in Cache or Database");
			}

		}

		return currRegRepTradeValidation;

	}
//update cache and update trade in DB
	public void updateTradeValCache(RegRepTradeValidation regRepTradeValidation)
	{
		String cuurTradeId = null;
		if (null != regRepTradeValidation)
		{
			cuurTradeId = regRepTradeValidation.getTradeid();
			Cache eodCache = cacheManager.getCache("eodCache");

			Element currElement = new Element(cuurTradeId, regRepTradeValidation);
			eodCache.put(currElement);
			
			regRegTradeValidationDaoImpl.updateTradeVal(regRepTradeValidation);

			logger.info("updated cache for tradeID :" + cuurTradeId);

		}

	}
	
	//update cache and update trade in DB as CptyLei as changed
		public void updateTradeValCacheForCPtyLeiChange(RegRepTradeValidation regRepTradeValidation)
		{
			String cuurTradeId = null;
			if (null != regRepTradeValidation)
			{
				cuurTradeId = regRepTradeValidation.getTradeid();
				Cache eodCache = cacheManager.getCache("eodCache");

				Element currElement = new Element(cuurTradeId, regRepTradeValidation);
				eodCache.put(currElement);
				
				regRegTradeValidationDaoImpl.updateTradeValForCptyLeiChange(regRepTradeValidation);

				logger.info("updated cache for tradeID :" + cuurTradeId);

			}

		}

}
