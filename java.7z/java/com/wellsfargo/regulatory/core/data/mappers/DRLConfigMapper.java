package com.wellsfargo.regulatory.core.data.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.beans.DRLConfig;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

@SuppressWarnings("rawtypes")
public class DRLConfigMapper implements RowMapper
{

	public DRLConfig mapRow(ResultSet rst, int rownum) throws SQLException
	{
		DRLConfig config = null;

		config = new DRLConfig();
		config.setId(rst.getInt("ID"));
		config.setDrlKey(rst.getString("DRL_KEY"));
		config.setReportingJurisdiction(rst.getString("REPORTING_JURISDICTION"));
		config.setRepository(rst.getString("REPOSITORY"));
		config.setDrlType(rst.getString("DRL_TYPE"));
		config.setFileLocation(rst.getString("FILE_LOCATION"));

		return config;
	}

}
