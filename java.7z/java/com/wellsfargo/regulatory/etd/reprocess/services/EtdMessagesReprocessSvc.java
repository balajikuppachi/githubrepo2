package com.wellsfargo.regulatory.etd.reprocess.services;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.persister.etd.dao.EtdPayloadDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;

/**
 * @author Raji Komatreddy Reprocess the payloads persisted in ETDPAYLOAD table createdate between
 * fromDateString and toDateString, converts payload into file and places in a directory where
 * etdMessage reader listening
 */

@Component
public class EtdMessagesReprocessSvc
{

	@Autowired
	private EtdPayloadDao etdPayloadDao;

	@Value("${etd.reprocess.from.date}")
	private String fromDateString;

	@Value("${etd.reprocess.to.date}")
	private String toDateString;

	@Value("${etd.request.file.path}")
	private String reprocessDirecotry;

	private static Logger logger = Logger.getLogger(EtdMessagesReprocessSvc.class.getName());

	public void reprocess(Message<?> message) throws EtdMessageException
	{
		logger.info("Inside EtdMessagesReprocessSvc reprocess method");
		String errorString = null;
		String fromDate = null;
		String toDate = null;
		Date reportFromDate = null;
		Date reportToDate = null;
		Object ipMessage = null;

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		List<EtdPayload> etdPayloadList = null;

		if (null == message)
		{
			errorString = "Null incoming message RegRepEodJobDetails";
			logger.error("########## " + errorString);
			throw new EtdMessageException("EtdMessagesReprocessSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, errorString);
		}

		ipMessage = message.getPayload();

		if (ipMessage instanceof File)
		{
			try
			{
				String reprocessFile = null;
				String[] fileParams = null;

				int numParams = 0;
				File inFile = (File) ipMessage;
				if (null != inFile)
				{
					reprocessFile = inFile.getName();
					reprocessFile = StringUtils.substringBefore(reprocessFile, ".");
					fileParams = reprocessFile.split("_");
					numParams = fileParams.length;
					if (numParams >= 3)
					{
						fromDate = fileParams[1];
						toDate = fileParams[2];
					}
					else
					{
						logger.error("reprocess file does not contain proper file name convention: eg: reprocess_2015-07-29_2015-07-30 ");
					}
					inFile.delete();
				}

			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating RegRepEodJobRequest  " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new EtdMessageException("EtdMessagesReprocessSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.PORTREC_ERROR, e.getMessage());

			}
		}

		try
		{
			reportFromDate = dateFormat.parse(fromDate);
			reportToDate = dateFormat.parse(toDate);
		}
		catch (ParseException e)
		{
			logger.error("Exception occurred while parsing reportDate " + e.getMessage());
		}
		if (null != etdPayloadDao)
		{
			etdPayloadList = etdPayloadDao.getEtdPayLoadByCreateDate(reportFromDate, reportToDate);
			if (null != etdPayloadList)
			{
				logger.info("number EtdMessages to reprocess :" + etdPayloadList.size());
				for (EtdPayload currEtdPayload : etdPayloadList)
				{
					String fileName = "etdRequestMessage_" + currEtdPayload.getMessageId() + ".xml";
					String destFileName = reprocessDirecotry;
					File etdFile = new File(fileName);
					File destFile = new File(destFileName);

					try
					{
						FileUtils.writeStringToFile(etdFile, currEtdPayload.getPayload());
						FileUtils.moveFileToDirectory(etdFile, destFile, true);
					}
					catch (IOException e)
					{
						logger.error("Exception occurred while writing etd message to file " + e.getMessage());
					}
					// logger.info("current payload string : " + currEtdPayload.getPayload());
				}
			}
		}

		logger.info("exiting EtdMessagesReprocessSvc reprocess method");
	}

}
