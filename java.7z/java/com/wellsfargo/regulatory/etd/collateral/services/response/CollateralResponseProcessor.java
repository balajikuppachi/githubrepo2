package com.wellsfargo.regulatory.etd.collateral.services.response;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;

import com.wellsfargo.regulatory.commons.bo.etd.response.MessageType;
import com.wellsfargo.regulatory.commons.bo.etd.response.SdrResponse;
import com.wellsfargo.regulatory.commons.collateral.dto.CollateralResponseMessage;
import com.wellsfargo.regulatory.commons.collateral.utils.CollateralConstants;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.CollateralResponseException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;

public class CollateralResponseProcessor
{

	private EtdTradeJurisdictionDao etdTradeJurisdictionDao;
	
	private Marshaller marshaller;

	@SuppressWarnings("unused")
	private Unmarshaller unmarshaller;
	
	private String tempFileLoc;
	private MessageChannel errorChannel;
	private MessageChannel etdResHeaderEnrichChannel;

	private static Logger logger = Logger.getLogger(CollateralResponseProcessor.class.getName());

	@SuppressWarnings("unchecked")
	public void process(Message<?> message) throws CollateralResponseException
	{
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.CollateralResponseProcessor);		

		logger.info("Enter CollateralResponseProcessor: process method");
		String errorString = null;
		Object ipMessage = null;
		String origPayload = null;
		JobExecution currJobExecution = null;
		ExitStatus currExitStatus = null;
		List<CollateralResponseMessage> collateralResponseMessageList = null;
		String etdTradeJurisdictionId = null;
		String sdrMessageId = null;
		long dataSubmitterMessageID = 0;
		EtdTradeJurisdiction etdTradeJurisdiction = null;
		Date currDate = new Date();
		SdrResponse sdrResponse = null;
		String nackResponseString = null;
		String[] collateralNackRespStrArray = null;

		if (null == message)
		{
			errorString = "Null incoming message in CollateralResponseProcessor  process method";
			logger.error("########## " + errorString);
			throw new CollateralResponseException("CollateralRsp:0", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.COLLATERAL_RES_ERROR, errorString);
		}

		ipMessage = message.getPayload();

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
			// TODO : prepare file using string payload
		}
		else if (ipMessage instanceof JobExecution)
		{
			currJobExecution = (JobExecution) ipMessage;
			currExitStatus = currJobExecution.getExitStatus();

			if (currExitStatus.getExitCode().equalsIgnoreCase("EXECUTING"))
			{
				logger.info(" Collateral response Batch job is still running ");

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("COMPLETED"))
			{
				logger.info(" Collateral response Batch job finished successfully ");

				collateralResponseMessageList = (List<CollateralResponseMessage>) currJobExecution.getExecutionContext().get(CollateralConstants.COLLATERAL_RESPONSE_MESSAGE_LIST);
				
				if (null != collateralResponseMessageList)
				{
					for (CollateralResponseMessage currCollateralResponseMessage : collateralResponseMessageList)
					{
						etdTradeJurisdictionId = currCollateralResponseMessage.getDataSubmitterMessageID();
						
						if (null != etdTradeJurisdictionId && StringUtils.isNotEmpty(etdTradeJurisdictionId))
						{
							try
							{
								dataSubmitterMessageID = Long.parseLong(etdTradeJurisdictionId);
								etdTradeJurisdiction = etdTradeJurisdictionDao.findByPrimaryKey(dataSubmitterMessageID);
							}
							catch(Exception e)
							{
								errorString = "Exception occurred while getting collateral response data submitter ID : " + e.getMessage() ;
								logger.error("########## " + errorString);
								throw new CollateralResponseException("CollateralRsp:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.COLLATERAL_RES_ERROR, errorString);
							}
							
							if (null != etdTradeJurisdiction)
							{
								logger.info(" retrieved EtdTradeJurisdiction record for datasubmitter message Id " + dataSubmitterMessageID);
								
								String msgType = etdTradeJurisdiction.getMsgType();
								
								EtdPayload currEtdPayload = null;
								currEtdPayload = etdTradeJurisdiction.getEtdPayload();
								
								if (null != currEtdPayload)
								{
									sdrMessageId = currEtdPayload.getMessageId();
								}
								
								AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(sdrMessageId));
								
								List<MessageType> messageTypeList = new ArrayList<MessageType>();
								
								if (StringUtils.equals(msgType, CollateralConstants.ETD_REGREP_COLLATERALVALUE))
								{
									
									sdrResponse = new SdrResponse();
									sdrResponse.setFoMessageId(etdTradeJurisdiction.getSourceSystemMessageId());
									sdrResponse.setFoSystem(CollateralConstants.ETD_COLLATERAL_FO_SYSTEM);
									sdrResponse.setSdrSystem(CollateralConstants.ETD_COLLATERAL_RPT_REPOSITORY);
									sdrResponse.setSdrMessageId(sdrMessageId);
									try
									{
										GregorianCalendar gc = new GregorianCalendar();
										gc.setTimeInMillis(currDate.getTime());
										DatatypeFactory df = DatatypeFactory.newInstance();
										XMLGregorianCalendar xg = df.newXMLGregorianCalendar(gc);
										sdrResponse.setResponseTimestamp(xg);

									}
									catch (Exception exp)
									{
										errorString = "Error while preparing XMLGregorianCalendar date for response message";
										logger.debug("########## " + errorString);

									}
									
									if (currCollateralResponseMessage.getResponseType().equalsIgnoreCase(CollateralConstants.COLLATERAL_ACK))
									{

										etdTradeJurisdiction.setState(CollateralConstants.COLLATERAL_TRADE_STATE_FROM_DTCC);
										etdTradeJurisdiction.setSubmissionStatus(CollateralConstants.COLLATERAL_TRADE_STATUTUS_ACCEPTED);
										etdTradeJurisdiction.setUpdateDatetime(currDate);

										etdTradeJurisdictionDao.saveOrUpdate(etdTradeJurisdiction);
										
										sdrResponse.setResponseCode(CollateralConstants.COLLATERAL_ACK);

									}
									else if (currCollateralResponseMessage.getResponseType().equalsIgnoreCase(CollateralConstants.COLLATERAL_NACK))
									{
										etdTradeJurisdiction.setState(CollateralConstants.COLLATERAL_TRADE_STATE_FROM_DTCC);
										etdTradeJurisdiction.setSubmissionStatus(CollateralConstants.COLLATERAL_TRADE_STATUTUS_REJECTED);
										etdTradeJurisdiction.setUpdateDatetime(currDate);

										etdTradeJurisdictionDao.saveOrUpdate(etdTradeJurisdiction);
										
										sdrResponse.setResponseCode(CollateralConstants.COLLATERAL_NACK);
										
										String nackResponseDelimitor = "[,]";
										
										nackResponseString = currCollateralResponseMessage.getErrorCodeAndReason();
										
										if (null != nackResponseString)
										{
											collateralNackRespStrArray = nackResponseString.split(nackResponseDelimitor);
											String currNackRespWithErrorCode = null;
											String currNackErrorCode = null;
											String currNackErrorString = null;
											for (int i = 0; i < collateralNackRespStrArray.length; i++)
											{
												currNackRespWithErrorCode = collateralNackRespStrArray[i];
												if (null != currNackRespWithErrorCode)
												{
													currNackErrorCode = StringUtils.substringBefore(currNackRespWithErrorCode, CollateralConstants.COLLATERAL_NACK_ERRORCODE_SEPARATOR);
													currNackErrorString = StringUtils.substringAfter(currNackRespWithErrorCode, CollateralConstants.COLLATERAL_NACK_ERRORCODE_SEPARATOR);
													
													MessageType currMessageType = new MessageType();
													currMessageType.setValue(currNackErrorCode);
													currMessageType.setDescription(currNackErrorString);

													messageTypeList.add(currMessageType);
													
													errorString = "ETD Collateral Nack response sent by Dtcc with error code: " + currNackErrorCode + " and failure reason:  " + currNackErrorString;

													dispatchException(message, sdrMessageId, errorString, "CollateralRsp:2", ExceptionSeverityEnum.ERROR);
												}
											}
										}
									}
									
									sdrResponse.getMessage().addAll(messageTypeList);
									if (sdrResponse != null)
									{
										try
										{
											String respXml = prepareResponse(sdrResponse);

											if (respXml != null)
											{
												//Message<String> responseMessage = null;
												//responseMessage = MessageBuilder.withPayload(respXml).copyHeaders(message.getHeaders()).build();

												//etdResHeaderEnrichChannel.send(responseMessage);

												//logger.info("published dtcc etd collateral response to FO ");
											}

											logger.info("etd collateral response xml : " + respXml);
										}
										catch (Exception e)
										{
											errorString = "Exception occurred while parsing etd collateral nack response : " + e.getMessage();
											logger.error("########## " + errorString);

											throw new CollateralResponseException("CollateralRsp:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.COLLATERAL_RES_ERROR, errorString);

										}

									}
									
								} else if (StringUtils.equals(msgType, CollateralConstants.OTC_EMIR_COLLATERALVALUE))
								{
									// Persist into Table. No FO response creation 
									
									if (currCollateralResponseMessage.getResponseType().equalsIgnoreCase(CollateralConstants.COLLATERAL_ACK))
									{

										etdTradeJurisdiction.setState(CollateralConstants.COLLATERAL_TRADE_STATE_FROM_DTCC);
										etdTradeJurisdiction.setSubmissionStatus(CollateralConstants.COLLATERAL_TRADE_STATUTUS_ACCEPTED);
										etdTradeJurisdiction.setUpdateDatetime(currDate);

										etdTradeJurisdictionDao.saveOrUpdate(etdTradeJurisdiction);

									}
									else if (currCollateralResponseMessage.getResponseType().equalsIgnoreCase(CollateralConstants.COLLATERAL_NACK))
									{
										etdTradeJurisdiction.setState(CollateralConstants.COLLATERAL_TRADE_STATE_FROM_DTCC);
										etdTradeJurisdiction.setSubmissionStatus(CollateralConstants.COLLATERAL_TRADE_STATUTUS_REJECTED);
										etdTradeJurisdiction.setUpdateDatetime(currDate);

										etdTradeJurisdictionDao.saveOrUpdate(etdTradeJurisdiction);
										
										String nackResponseDelimitor = "[,]";
										
										nackResponseString = currCollateralResponseMessage.getErrorCodeAndReason();
										
										if (null != nackResponseString)
										{
											collateralNackRespStrArray = nackResponseString.split(nackResponseDelimitor);
											String currNackRespWithErrorCode = null;
											String currNackErrorCode = null;
											String currNackErrorString = null;
											for (int i = 0; i < collateralNackRespStrArray.length; i++)
											{
												currNackRespWithErrorCode = collateralNackRespStrArray[i];
												if (null != currNackRespWithErrorCode)
												{
													currNackErrorCode = StringUtils.substringBefore(currNackRespWithErrorCode, CollateralConstants.COLLATERAL_NACK_ERRORCODE_SEPARATOR);
													currNackErrorString = StringUtils.substringAfter(currNackRespWithErrorCode, CollateralConstants.COLLATERAL_NACK_ERRORCODE_SEPARATOR);
													errorString = "EMIR Collateral Nack response sent by Dtcc with error code: " + currNackErrorCode + " and failure reason:  " + currNackErrorString;

													dispatchException(message, sdrMessageId, errorString, "CollateralRsp:4", ExceptionSeverityEnum.ERROR);
												}
											}
										}
									}
									
								}
							}
							else
							{
								logger.info(" no record exists in EtdTradeJurisdiction for datasubmitter message Id " + dataSubmitterMessageID);
							}
						}
					}
				}
			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("FAILED"))
			{
				errorString = currJobExecution.getStepExecutions().toString();
				logger.error(" Batch job Failed " + currJobExecution.getStepExecutions().toString());
				throw new CollateralResponseException("CollateralRsp:5", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.COLLATERAL_RES_ERROR, errorString);
			}
		}
		logger.info("Exit CollateralResponseProcessor: process method");
	}

	
	private void dispatchException(Message<?> message, String sdrMessageId, String errorString, String errorCode, ExceptionSeverityEnum severity)
	{
		logger.debug("Enter collateral response dispatchException : " + errorString);
		
		CollateralResponseException currMessageException = null;
		Message<CollateralResponseException> excWrapper = null;

		currMessageException = new CollateralResponseException(errorCode, severity, ExceptionTypeEnum.COLLATERAL_RES_ERROR, errorString, sdrMessageId);
		excWrapper = MessageBuilder.withPayload(currMessageException).copyHeaders(message.getHeaders()).build();

		errorChannel.send(excWrapper);

		logger.debug("Exit collateral response dispatchException : " + errorString);
	}
	
	private String prepareResponse(SdrResponse sdrResponse) throws Exception
	{
		String response = null;
		String fileName = Constants.REG_REP_TEMP + Constants.UNDERSCORE + "CollateralResponseProcessor"  + Constants.UNDERSCORE + (new Date()).getTime();

		File tempFile = new File(tempFileLoc + File.separator + fileName);

		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(tempFile);

			marshaller.marshal(sdrResponse, new StreamResult(fos));
			
			Scanner respScanner = new Scanner(tempFile);			
			response = respScanner.useDelimiter("\\Z").next();
			respScanner.close();			

		}
		catch (Exception exp)
		{
			throw exp;
		}
		finally
		{
			if (fos != null)
			{
				fos.close();
			}

			tempFile.delete();
		}

		return response;
	}

	public String getTempFileLoc()
	{
		return tempFileLoc;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}

	public void setErrorChannel(MessageChannel errorChannel)
	{
		this.errorChannel = errorChannel;
	}

	public void setEtdTradeJurisdictionDao(EtdTradeJurisdictionDao etdTradeJurisdictionDao)
	{
		this.etdTradeJurisdictionDao = etdTradeJurisdictionDao;
	}

	public void setEtdResHeaderEnrichChannel(MessageChannel etdResHeaderEnrichChannel)
	{
		this.etdResHeaderEnrichChannel = etdResHeaderEnrichChannel;
	}

}
