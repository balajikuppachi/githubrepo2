package com.wellsfargo.regulatory.etd.collateral.batch.services;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.commons.collateral.dto.CollateralAckMessage;
import com.wellsfargo.regulatory.commons.collateral.dto.CollateralResponseMessage;
import com.wellsfargo.regulatory.commons.collateral.utils.CollateralConstants;
import com.wellsfargo.regulatory.etd.batch.report.MessageToEtdRptRequestService;

public class CollateralAckMessageProcessor implements ItemProcessor<CollateralAckMessage, CollateralResponseMessage>
{
	private static Logger logger = Logger.getLogger(MessageToEtdRptRequestService.class.getName());

	@Override
	public CollateralResponseMessage process(CollateralAckMessage collateralAckMessage) throws Exception
	{
		CollateralResponseMessage collateralResponseMessage = new CollateralResponseMessage();

		logger.debug("input collateral ack message  " + collateralAckMessage.toString());
		collateralResponseMessage.setDataSubmitterMessageID(collateralAckMessage.getDataSubmitterMessageID());
		collateralResponseMessage.setResponseType(CollateralConstants.COLLATERAL_ACK);	
		collateralResponseMessage.setMessageType(collateralAckMessage.getMessageType());
		collateralResponseMessage.setStatus(CollateralConstants.COLLATERAL_RESPONSE_ACCEPTED);

		return collateralResponseMessage;
	}

}
