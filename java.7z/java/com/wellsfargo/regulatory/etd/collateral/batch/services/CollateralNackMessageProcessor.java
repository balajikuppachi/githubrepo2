package com.wellsfargo.regulatory.etd.collateral.batch.services;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.commons.collateral.dto.CollateralNackMessage;
import com.wellsfargo.regulatory.commons.collateral.dto.CollateralResponseMessage;
import com.wellsfargo.regulatory.commons.collateral.utils.CollateralConstants;
import com.wellsfargo.regulatory.core.services.reader.RegulatoryMessageReader;

public class CollateralNackMessageProcessor implements ItemProcessor<CollateralNackMessage, CollateralResponseMessage>
{
	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());
	@Override
    public CollateralResponseMessage process(CollateralNackMessage collateralNackMessage) throws Exception
    {
		CollateralResponseMessage currCollateralResponseMessage = new CollateralResponseMessage();
		
		logger.debug("input collateral nack message  " + collateralNackMessage.toString());
		currCollateralResponseMessage.setDataSubmitterMessageID(collateralNackMessage.getDataSubmitterMessageID());
		currCollateralResponseMessage.setResponseType(CollateralConstants.COLLATERAL_NACK);
		currCollateralResponseMessage.setErrorCodeAndReason(collateralNackMessage.getErrorCodeAndReason());
		currCollateralResponseMessage.setMessageType(collateralNackMessage.getMessageType());
		currCollateralResponseMessage.setStatus(CollateralConstants.COLLATERAL_RESPONSE_REJECTED);
		
		return currCollateralResponseMessage;
    }

	
}
