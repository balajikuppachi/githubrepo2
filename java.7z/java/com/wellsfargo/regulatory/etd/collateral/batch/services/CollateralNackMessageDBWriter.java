package com.wellsfargo.regulatory.etd.collateral.batch.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;

import com.wellsfargo.regulatory.commons.collateral.dto.CollateralResponseMessage;
import com.wellsfargo.regulatory.commons.collateral.utils.CollateralConstants;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.core.services.reader.RegulatoryMessageReader;

public class CollateralNackMessageDBWriter implements ItemWriter<CollateralResponseMessage>, StepExecutionListener
{
	private List<CollateralResponseMessage> collateralResponseMessageList = new ArrayList<CollateralResponseMessage>();
	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());

	@Override
	public void write(List<? extends CollateralResponseMessage> collateralResponseMessages) throws Exception
	{
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.CollateralNackMessageDBWriter);
		logger.info("Exit CollateralNackMessageDBWriter");
		collateralResponseMessageList.addAll(collateralResponseMessages);
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution)
	{
		List<CollateralResponseMessage> executionCollateralResponseMessageList = null;
		executionCollateralResponseMessageList = collateralResponseMessageList;
		
		stepExecution.getExecutionContext().put(CollateralConstants.COLLATERAL_RESPONSE_MESSAGE_LIST, executionCollateralResponseMessageList);	
		stepExecution.getJobExecution().getExecutionContext().put(CollateralConstants.COLLATERAL_RESPONSE_MESSAGE_LIST, executionCollateralResponseMessageList);
		return null;
	}

	@Override
	public void beforeStep(StepExecution arg0)
	{
		// TODO Auto-generated method stub
	}

}
