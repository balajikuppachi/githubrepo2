package com.wellsfargo.regulatory.etd.collateral.batch;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.collateral.utils.CollateralConstants;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.CollateralResponseException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

public class CollateralResponseGenJobRequest
{

	private Job collateralAckjob;
	private Job collateralNckjob;
	private String tempFileLoc;

	
	Logger logger = Logger.getLogger(this.getClass());

	@Transformer
	public Message<JobLaunchRequest> toRequest(Message<?> message) throws CollateralResponseException
	{
		Object ipMessage = null;
		String errorString = null;
		String collateralBatchResponseFileLoc = null;
		String fileName = null;
		JobLaunchRequest collateralResponseJob = null;
		Message<JobLaunchRequest> collateralResponseGenRequest = null;
		
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.CollateralResponseGenJobRequest);

		logger.info("Enter CollateralResponseGenJobRequest JobLaunchRequest method");
		
		if (null == message)
		{
			errorString = "Null incoming message from  CollateralResponseGenJobRequest ";
			logger.error("########## " + errorString);
			throw new CollateralResponseException("CollateralResponseGenJobRequest-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.COLLATERAL_RES_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		if (ipMessage instanceof File)
		{

			logger.info("Consuming ETD/OTC collateral ACK/NACK response");
			try
			{
				File inFile = (File) ipMessage;
				collateralBatchResponseFileLoc = inFile.getAbsolutePath();
				fileName = inFile.getName();
				File tempFile = new File(tempFileLoc + fileName);
				
				tempFile.mkdirs();
				Files.copy(inFile.toPath(), tempFile.toPath(), StandardCopyOption .REPLACE_EXISTING);
				collateralBatchResponseFileLoc = tempFile.getAbsolutePath();
				inFile.delete();

				JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
				
				String fileNameWithoutExtn = StringUtils.substringBefore(fileName, ".");

				if (fileNameWithoutExtn.endsWith(CollateralConstants.COLLATERAL_ACK_FILE))
				{
					jobParametersBuilder.addString(CollateralConstants.COLLATERAL_ACK_RESP_FILE_LOC, collateralBatchResponseFileLoc);
					collateralResponseJob = new JobLaunchRequest(collateralAckjob, jobParametersBuilder.toJobParameters());
					collateralResponseGenRequest = MessageBuilder.withPayload(collateralResponseJob).setHeader(CollateralConstants.COLLATERAL_RESPONSE_TYPE, CollateralConstants.COLLATERAL_ACK).build();
				}
				else if (fileNameWithoutExtn.endsWith(CollateralConstants.COLLATERAL_NACK_FILE))
				{
					jobParametersBuilder.addString(CollateralConstants.COLLATERAL_NACK_RESP_FILE_LOC, collateralBatchResponseFileLoc);
					collateralResponseJob = new JobLaunchRequest(collateralNckjob, jobParametersBuilder.toJobParameters());
					collateralResponseGenRequest = MessageBuilder.withPayload(collateralResponseJob).setHeader(CollateralConstants.COLLATERAL_RESPONSE_TYPE, CollateralConstants.COLLATERAL_NACK).build();
				}
				else
				{
					errorString = "collateral file name does not end with ACK or NACK hence existing the process " ;
					logger.error("########## " + errorString);
				}

			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating collateral response jobrequest " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new CollateralResponseException("CollateralResponseGenJobRequest-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.COLLATERAL_RES_ERROR, errorString);

			}

		}

		logger.info("Exit CollateralResponseGenJobRequest JobLaunchRequest method");
		return collateralResponseGenRequest;

	}


	public void setCollateralAckjob(Job collateralAckjob) {
		this.collateralAckjob = collateralAckjob;
	}

	public void setCollateralNckjob(Job collateralNckjob) {
		this.collateralNckjob = collateralNckjob;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

}
