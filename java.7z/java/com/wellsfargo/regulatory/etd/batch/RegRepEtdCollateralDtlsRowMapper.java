package com.wellsfargo.regulatory.etd.batch;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdCollateralDtls;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class RegRepEtdCollateralDtlsRowMapper implements RowMapper<RegRepEtdCollateralDtls>
{

	@Override
	public RegRepEtdCollateralDtls mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		RegRepEtdCollateralDtls currRegRepEtdCollateralDtls = new RegRepEtdCollateralDtls();

		currRegRepEtdCollateralDtls.setMessageId(rs.getString("message_id"));
		currRegRepEtdCollateralDtls.setCobDate(rs.getString("cob_date"));
		currRegRepEtdCollateralDtls.setSrcSysMessageId(rs.getString("src_sys_message_id"));
		currRegRepEtdCollateralDtls.setAction(rs.getString("action"));
		currRegRepEtdCollateralDtls.setDataSubmitterLei(rs.getString("data_submitter_lei"));
		currRegRepEtdCollateralDtls.setTradePartyLei(rs.getString("trade_party_lei"));
		currRegRepEtdCollateralDtls.setExecutionagentLei(rs.getString("executionagent_lei"));
		currRegRepEtdCollateralDtls.setPortfolioCode(rs.getString("portfolio_code"));
		currRegRepEtdCollateralDtls.setPortfolioIndicator(rs.getString("portfolio_indicator"));
		currRegRepEtdCollateralDtls.setValue(rs.getBigDecimal("value"));
		currRegRepEtdCollateralDtls.setCurrency(rs.getString("currency"));
		currRegRepEtdCollateralDtls.setValuationDate(rs.getString("valuation_date"));
		currRegRepEtdCollateralDtls.setReportingDate(rs.getString("reporting_date"));
		currRegRepEtdCollateralDtls.setExecutionAgentMaskInd(rs.getString("execution_agent_mask_ind"));
		currRegRepEtdCollateralDtls.setSuppressReporting(rs.getString("suppressReporting"));

		return currRegRepEtdCollateralDtls;
	}

}
