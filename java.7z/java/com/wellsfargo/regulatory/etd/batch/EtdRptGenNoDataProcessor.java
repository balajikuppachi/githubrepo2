package com.wellsfargo.regulatory.etd.batch;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component
public class EtdRptGenNoDataProcessor
{
	private static Logger logger = Logger.getLogger(EtdRptGenNoDataProcessor.class.getName());
	public void handleNoDataRpt(Message<?> message)
	{
		logger.info("Inside  EtdRptGenNoDataProcessor : handleNoDataRpt method ");
		logger.info("Inside  EtdRptGenNoDataProcessor : handleNoDataRpt data not present in DB to generate Report");
	}

}
