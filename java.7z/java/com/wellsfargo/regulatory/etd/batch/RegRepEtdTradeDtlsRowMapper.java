package com.wellsfargo.regulatory.etd.batch;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdTradeDtls;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class RegRepEtdTradeDtlsRowMapper implements RowMapper<RegRepEtdTradeDtls> {

	@Override
	public RegRepEtdTradeDtls mapRow(ResultSet rs, int rowNum)
			throws SQLException {
	
		
		RegRepEtdTradeDtls currTradeDtls = new RegRepEtdTradeDtls();
		currTradeDtls.setEtdTradeDtlsID(rs.getBigDecimal("EtdTradeDtlsID"));
		currTradeDtls.setFileId(rs.getBigDecimal("FileId"));
		currTradeDtls.setCobDate(rs.getString("CobDate"));
		currTradeDtls.setVersion(rs.getString("version"));
		currTradeDtls.setMsgType(rs.getString("msgType"));
		currTradeDtls.setCobDate(rs.getString("action"));
		currTradeDtls.setCobDate(rs.getString("transactionType"));
		currTradeDtls.setCobDate(rs.getString("uti"));
		currTradeDtls.setCobDate(rs.getString("assetClass"));
		currTradeDtls.setCobDate(rs.getString("reportingParty"));
		currTradeDtls.setCobDate(rs.getString("rptObligationParty1"));
		currTradeDtls.setCobDate(rs.getString("rptObligationParty2"));
		currTradeDtls.setCobDate(rs.getString("party1Value"));
		currTradeDtls.setCobDate(rs.getString("party2Value"));
		currTradeDtls.setCobDate(rs.getString("party1Domicile"));
		
		//TODO remaining fields mapping
		
		return currTradeDtls;
	}

}
