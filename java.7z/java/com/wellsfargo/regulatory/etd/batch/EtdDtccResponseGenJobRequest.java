package com.wellsfargo.regulatory.etd.batch;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;

/**
 * @author Raji Komatreddy
 *  
 * <p> Prepares jobLaunchRequest to launch dtcc response processing batch job
 */
public class EtdDtccResponseGenJobRequest
{

	private Job etdDtccAckjob;
	private Job etdDtccNckjob;
	private String tempFileLoc;   // = "C:\\SDR\\test\\";

	
	Logger logger = Logger.getLogger(this.getClass());

	@Transformer
	public Message<JobLaunchRequest> toRequest(Message<?> message) throws EtdMessageException
	{
		Object ipMessage = null;
		String errorString = null;
		String dtccAckResponseFileLoc = null;
		String fileName = null;
		JobLaunchRequest etdDtccResponseJob = null;
		Message<JobLaunchRequest> etdDtccResponseGenRequest = null;
		
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdDtccResponseGenJobRequest);

		logger.info("Inside EtdDtccResponseGenJobRequest JobLaunchRequest method");
		
		if (null == message)
		{
			errorString = "Null incoming message from  EtdDtccResponseGenJobRequest ";
			logger.error("########## " + errorString);
			throw new EtdMessageException("EtdDtccResponseGenJobRequest-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		if (ipMessage instanceof File)
		{

			logger.info("Consuming dtcc ACK/NACK response for ETD reports from local folder");
			try
			{
				File inFile = (File) ipMessage;
				dtccAckResponseFileLoc = inFile.getAbsolutePath();
				fileName = inFile.getName();
				File tempFile = new File(tempFileLoc + fileName);
				
				  tempFile.mkdirs();
				Files.copy(inFile.toPath(), tempFile.toPath(), StandardCopyOption .REPLACE_EXISTING);
				dtccAckResponseFileLoc = tempFile.getAbsolutePath();
				inFile.delete();

				JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
				jobParametersBuilder.addString(EtdConstants.DTTC_ACK_RESP_FILE_LOC, dtccAckResponseFileLoc);

				if (fileName.startsWith(EtdConstants.ETD_ACK))
				{
					etdDtccResponseJob = new JobLaunchRequest(etdDtccAckjob, jobParametersBuilder.toJobParameters());
					etdDtccResponseGenRequest = MessageBuilder.withPayload(etdDtccResponseJob).setHeader(EtdConstants.ETD_DTCC_RESPONSE_TYPE, EtdConstants.ETD_ACK).build();

				}
				else if (fileName.startsWith(EtdConstants.ETD_NACK))
				{
					etdDtccResponseJob = new JobLaunchRequest(etdDtccNckjob, jobParametersBuilder.toJobParameters());
					etdDtccResponseGenRequest = MessageBuilder.withPayload(etdDtccResponseJob).setHeader(EtdConstants.ETD_DTCC_RESPONSE_TYPE, EtdConstants.ETD_NACK).build();
				}
				else
				{
					errorString = "dtcc file name does not start with ACK or NACK hence existing the process " ;
					logger.error("########## " + errorString);
					
				}

			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating Dtcc ETD response jobrequest " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new EtdMessageException("EtdDtccResponseGenJobRequest-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

			}

		}

		logger.info("Exiting EtdDtccResponseGenJobRequest JobLaunchRequest method");

		return etdDtccResponseGenRequest;

	}

	public void setEtdDtccAckjob(Job etdDtccAckjob)
	{
		this.etdDtccAckjob = etdDtccAckjob;
	}

	public void setEtdDtccNckjob(Job etdDtccNckjob)
	{
		this.etdDtccNckjob = etdDtccNckjob;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

}
