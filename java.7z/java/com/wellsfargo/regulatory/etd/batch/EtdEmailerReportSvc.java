package com.wellsfargo.regulatory.etd.batch;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;

@Component
public class EtdEmailerReportSvc {
	
	private static Logger logger = Logger.getLogger(EtdEmailerReportSvc.class.getName());
	
	@Autowired
	private MailSenderService mailSender;
		
	@Value("${mail.etd.from.recon}")
	String mailETDFrom;
	@Value("${mail.etd.to.recon}")
	String mailETDTo;
	@Value("${mail.etd.cc.recon}")
	String mailETDCC;
	@Value("${mail.etd.host}")
	String mailETDHost;
	@Value("${etd.to.nonReportable.dtcc.input.file.path}")
	String shadowFilesLoc;
	@Value("${etd.email.env}")
	String env;
	@Value("${etd.to.dtcc.input.file.path}")
	String reportableFilesLoc;
		
	public void genEtdEmail(Message<?> message) throws IOException
	{
		String sub = null;
		StringBuilder msg = new StringBuilder();
		JobLaunchRequest jobLauncheRequest;
		String cobDate = null;
		Boolean shadowFiles = false;
		Boolean repFiles = false;
		Object ipMessage = null;
		ipMessage = message.getPayload();
		
		if(ipMessage instanceof JobLaunchRequest)
		{
			
			jobLauncheRequest = (JobLaunchRequest) ipMessage;
			
			cobDate = jobLauncheRequest.getJobParameters().getString(EtdConstants.COBDATE);
			
			logger.info("Service Activator Called for Email for CobDate " + cobDate );
				
				shadowFilesLoc = shadowFilesLoc+"//"+cobDate;
				reportableFilesLoc = reportableFilesLoc+"//"+cobDate;
				
				File shadowFile = new File(shadowFilesLoc);
				File repFile = new File(reportableFilesLoc);
					
				if(shadowFile.isDirectory() && shadowFile.listFiles()!= null) {
					shadowFiles = true;
					logger.info("Files Available at " + shadowFile.toString());
				}
				if(repFile.isDirectory() && repFile.listFiles() != null) {
					repFiles = true;
					logger.info("Files Available at " + repFile.toString());
				}
				
				
			if(StringUtils.isNotBlank(mailETDHost) && (repFiles || shadowFiles)){	
				msg.append("Greetings,").append("\n").append("\n");
				if(repFiles){
					msg.append("ETD Submission Reports are available for reporting date " + cobDate + " at ").append("\n");
					msg.append("\\\\").append(mailETDHost).append("\\\\reports\\\\ETD\\\\Reported\\\\").append(cobDate).append("\\\\").append("\n").append("\n");
				}
				if(shadowFiles){
					msg.append("ETD Shadow Reports are available for reporting date " + cobDate + " at ").append("\n");
					msg.append("\\\\").append(mailETDHost).append("\\\\reports\\\\ETD\\\\Shadow\\\\").append(cobDate).append("\\\\").append("\n").append("\n");
				}
				msg.append("\n").append("Thanks,").append("\n");
				msg.append("WFSRegITSupport. ");
			}
				
				sub = "ETD SDR reporting ("+env.trim()+") for " + cobDate;
				
				logger.info(msg.toString());
				logger.info(sub);

				if(StringUtils.isNotBlank(msg.toString()))  {
					mailSender.sendMail(sub, msg.toString(), mailETDFrom, mailETDTo, mailETDCC, null, null);
				} else {
					logger.info("No ETD Files available For CobDate " + cobDate);
				}
			}
		}
	}


