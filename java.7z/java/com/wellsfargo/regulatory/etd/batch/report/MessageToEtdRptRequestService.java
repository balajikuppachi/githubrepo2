package com.wellsfargo.regulatory.etd.batch.report;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.dto.EtdReportGenRequest;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.utils.FileUtils;

/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class MessageToEtdRptRequestService
{
	@Value("${etd.to.dtcc.input.file.path.ondemand.backup}")
	private String tempOnDemandDtccFileLoc;
	
	private static Logger logger = Logger.getLogger(MessageToEtdRptRequestService.class.getName());

	public EtdReportGenRequest prepEtdRequest(Message<?> message) throws EtdMessageException
	{
		logger.info("Inside MessageToEtdRptRequestService: prepEtdRequest method" );
		String errorString = null;
		String onDemandDtccFileSubLoc = null;
		String onDemandFilename = null;
		EtdReportGenRequest currEtdReportGenRequest = null;
		Object ipMessage = null;
		String origPayload = null;
		File srcFile = null;
		String suppressReport = null;
		
		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);
			throw new EtdMessageException("etdReqSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
			
		}
		ipMessage =  message.getPayload();
		
		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
			//to do prepare file using string payload
		}
		else if (ipMessage instanceof File)
		{
			srcFile = ((File) ipMessage);

			try
			{
				
				onDemandDtccFileSubLoc = srcFile.getAbsolutePath();
				onDemandFilename = srcFile.getName();
				File tempFile = new File(tempOnDemandDtccFileLoc + onDemandFilename);
				
				  tempFile.mkdirs();
				Files.copy(srcFile.toPath(), tempFile.toPath(), StandardCopyOption .REPLACE_EXISTING);
				onDemandDtccFileSubLoc = tempFile.getAbsolutePath();
				srcFile.delete();

				currEtdReportGenRequest = new EtdReportGenRequest(tempFile, suppressReport);
				
				String filePathwithName = srcFile.getAbsolutePath();
				String fileName = currEtdReportGenRequest.getFile().getName();
				
				logger.info("Sending ETD report file to DTCC: file name including file path: " + filePathwithName);
				logger.info("Sending ETD report file to DTCC: file name: " + fileName);
				
				// - Remove the src file
				//FileUtils.deleteAFile(srcFile);
			}
			catch (Exception e)
			{
				errorString = "Failed to read the payload MessageToEtdRptRequestService " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);	
				throw new EtdMessageException("etdReqSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
			}
		}
		
		logger.info("Exiting MessageToEtdRptRequestService: prepEtdRequest method" );
		
		
		return currEtdReportGenRequest;
	}
	

}
