package com.wellsfargo.regulatory.etd.batch.report;

import java.io.File;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.dto.EtdReportGenRequest;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeBatchOutputDao;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeBatchOutput;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdTradeBatchOutputMapper;

/**
 * @author Raji Komatreddy
 */
@Component
public class JobExecutionToEtdRptRequestSvc
{
	@Autowired
	private EtdTradeBatchOutputDao etdTradeBatchOutputDao;

 @Autowired
	private EtdTradeJurisdictionDao etdTradeJurisdictionDao;

	private static Logger logger = Logger.getLogger(MessageToEtdRptRequestService.class.getName());

	private String etdTradeJurisdictionUpdateQuery = 
			      " update com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction "
	              + "set submission_status = 'submitted'  , batch_id = ?, update_datetime = getdate() "
	              + " where cob_date = ? and msg_type = ? and isReportable = 'true' and submission_status = 'batched'";

	public EtdReportGenRequest prepEtdRequest(Message<?> message) throws EtdMessageException
	{
		logger.info("Inside JobExecutionToEtdRptRequestSvc: prepEtdRequest method");
		String errorString = null;
		EtdReportGenRequest currEtdReportGenRequest = null;
		Object ipMessage = null;
		String origPayload = null;
		File srcFile = null;
		String outPutfileName = null;
		String msgType = null;
		String cobDate = null;
		JobExecution currJobExecution = null;
		ExitStatus currExitStatus = null;
		long batchId = 0;
		String supressReportingFlag = null;

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);
			return currEtdReportGenRequest;
		}
		ipMessage = message.getPayload();

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
			// to do prepare file using string payload
		}
		else if (ipMessage instanceof JobExecution)
		{
			currJobExecution = (JobExecution) ipMessage;
			currExitStatus = currJobExecution.getExitStatus();

			if (currExitStatus.getExitCode().equalsIgnoreCase("EXECUTING"))
			{
				logger.info(" Batch job is still running ");
			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("COMPLETED"))
			{
				try
				{
					logger.info(" Batch job finished successfully ");
					outPutfileName = currJobExecution.getJobParameters().getString(EtdConstants.DTTC_OUT_FILE_LOC);
					msgType = currJobExecution.getJobParameters().getString(EtdConstants.MESSAGETYPE);
					cobDate = currJobExecution.getJobParameters().getString(EtdConstants.COBDATE);
					supressReportingFlag =  currJobExecution.getJobParameters().getString(EtdConstants.ETD_SUPRESS_REPORTING);

					srcFile = new File(outPutfileName);

					currEtdReportGenRequest = new EtdReportGenRequest(srcFile, supressReportingFlag);

					String filePathwithName = srcFile.getAbsolutePath();
					String fileShortName = currEtdReportGenRequest.getFile().getName();

					logger.info("Sending ETD report file to DTCC: file name including file path: " + filePathwithName);
					logger.info("Sending ETD report file to DTCC: file name: " + fileShortName);

					EtdTradeBatchOutput currEtdTradeBatchOutput = new EtdTradeBatchOutput();
					currEtdTradeBatchOutput.setMsgType(msgType);
					currEtdTradeBatchOutput.setCobDate(cobDate);
					currEtdTradeBatchOutput.setOutFileName(filePathwithName);

					EtdTradeBatchOutputMapper currEtdTradeBatchOutputMapper = new EtdTradeBatchOutputMapper();

					currEtdTradeBatchOutput = currEtdTradeBatchOutputMapper.populateEtdTradeBatchOut(currEtdTradeBatchOutput);

					logger.debug("Persisting batchout put details into EtdTradeBatchOutput table: " + currEtdTradeBatchOutput.toString());

					currEtdTradeBatchOutput = etdTradeBatchOutputDao.save(currEtdTradeBatchOutput);

					// update EtdTradeJurisdiction table with batch id and status as submitted

					if (null != currEtdTradeBatchOutput)
					{
						batchId = currEtdTradeBatchOutput.getBatchId();
						
						String batchIdStr = Long.toString(batchId);
					int updatedCnt = 	etdTradeJurisdictionDao.bulkUpdate(etdTradeJurisdictionUpdateQuery, new Object [] { batchId , cobDate, msgType } );
						
						logger.debug("updated EtdTradeBatchOutput table: number records updated are :  " + updatedCnt);
						
					}

				}
				catch (Exception e)
				{
					errorString = "exception occurred JobExecutionToEtdRptRequestSvc " + ExceptionUtils.getFullStackTrace(e);
					logger.error("########## " + errorString);
					throw new EtdMessageException("EtdBatchJobExec:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

				}

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("FAILED"))
			{
				errorString = currJobExecution.getStepExecutions().toString();
				logger.error(" Batch job Failed " + currJobExecution.getStepExecutions().toString());
				throw new EtdMessageException("EtdBatchJobExec:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

			}

		}

		logger.info("Exiting MessageToEtdRptRequestService: prepEtdRequest method");

		return currEtdReportGenRequest;
	}

	public void setEtdTradeBatchOutputDao(EtdTradeBatchOutputDao etdTradeBatchOutputDao)
	{
		this.etdTradeBatchOutputDao = etdTradeBatchOutputDao;
	}

/*	public void setEtdTradeJurisdictionDao(EtdTradeJurisdictionDao etdTradeJurisdictionDao)
	{
		this.etdTradeJurisdictionDao = etdTradeJurisdictionDao;
	}
*/
	

}
