package com.wellsfargo.regulatory.etd.batch.report;

import org.apache.log4j.Logger;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.ChannelInterceptorAdapter;
import org.springframework.stereotype.Component;
/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class SftpLoggingInterceptor extends ChannelInterceptorAdapter
{
	private static Logger logger = Logger.getLogger(SftpLoggingInterceptor.class.getName());
	
	public void postSend( Message<?> message, MessageChannel channel,	boolean sent) {
		
		logger.info("inside SftpLoggingInterceptor:  ");
		if(sent)
		{
			logger.info("File has been delivered: " + message.getPayload());
			
		}
		else
		{
			logger.info("File has NOT been delivered: " + message.getPayload());
			
		}
		
		logger.info("Exiting SftpLoggingInterceptor:  ");
		
	
	}

}
