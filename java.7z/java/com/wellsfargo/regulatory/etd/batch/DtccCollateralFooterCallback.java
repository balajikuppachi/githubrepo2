package com.wellsfargo.regulatory.etd.batch;

import java.io.IOException;
import java.io.Writer;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.item.file.FlatFileFooterCallback;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;

/**
 * @author Raji Komatreddy <p> Helper class to add Footer record to Dtcc report
 */
public class DtccCollateralFooterCallback extends StepExecutionListenerSupport implements FlatFileFooterCallback
{

	private StepExecution stepExecution;

	@Autowired
	private FileStaticContentGenerator fileStaticContentGenerator;

	private static Logger logger = Logger.getLogger(DtccEtdFileHeaderCallback.class.getName());

	public void writeFooter(Writer writer) throws IOException
	{
		String applicationTrailer = null;
		String dataTrakTrailer = null;
		int recCount = 0;

		StringBuffer fileTrailer = new StringBuffer();
		try
		{
			if (null != fileStaticContentGenerator)
			{
				recCount = stepExecution.getWriteCount();
				applicationTrailer = fileStaticContentGenerator.getAPPLICATION_TRAILER(recCount,  EtdConstants.COLLATERAL_RPT);
				dataTrakTrailer = fileStaticContentGenerator.getDATATRAK_TRAILER(recCount,  EtdConstants.COLLATERAL_RPT);

				fileTrailer.append(applicationTrailer);
				fileTrailer.append(EtdConstants.LINE_SEPERATOR);
				fileTrailer.append(dataTrakTrailer);

			}
			
		}
		catch(Exception exp)
		{
			logger.error("Exception occurred inside DtccFooterCallback " +  ExceptionUtils.getFullStackTrace(exp));
        	
		}
		

		writer.write(fileTrailer.toString());
	}

	@Override
	public void beforeStep(StepExecution stepExecution)
	{
		this.stepExecution = stepExecution;
	}

}
