package com.wellsfargo.regulatory.etd.batch;

import java.io.IOException;
import java.io.Writer;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;

/**
 * 
 * @author Raji Komatreddy
 * 
 * <p> Helper class to add File header to the file submitting to DTCC
 *
 */
public class DtccEtdFileHeaderCallback implements LineCallbackHandler,
		FlatFileHeaderCallback {
  
	@Autowired
	private FileStaticContentGenerator fileStaticContentGenerator;
	
	private static Logger logger = Logger.getLogger(DtccEtdFileHeaderCallback.class.getName());

	@Override
	public void writeHeader(Writer writer) throws IOException {
		String applicationHeader1 = null;
		String applicationHeader2 = null;
		String  dataTrackHeader = null;
		StringBuffer fileHeader =  new StringBuffer();
		String finalFileHeader = null;
		
		try
        {
			if(null != fileStaticContentGenerator)
			{
				dataTrackHeader =   fileStaticContentGenerator.getDATATRAK_HEADER(null);
				applicationHeader1 = fileStaticContentGenerator.getAPPLICATION_HEADER(null);
				applicationHeader2 = EtdConstants.ETD_DTCC_APPLICATION_HEADER;
				
				fileHeader.append(dataTrackHeader);
				fileHeader.append(EtdConstants.LINE_SEPERATOR);
				fileHeader.append(applicationHeader1);
				fileHeader.append(EtdConstants.LINE_SEPERATOR);
				fileHeader.append(applicationHeader2);
				finalFileHeader = fileHeader.toString();
			}
			
	        
        }
        catch (Exception exp)        {
	       //to-do throw this exception to calling class 
        	logger.error("Exception occurred inside DtccEtdFileHeaderCallback " +  ExceptionUtils.getFullStackTrace(exp));
        	
        }
		writer.write(finalFileHeader);
	}
				
				

	@Override
	public void handleLine(String arg0) {
		// TODO Auto-generated method stub

	}

}
