package com.wellsfargo.regulatory.etd.batch;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdValuationDtls;

public class RegRepEtdValuationDtlsRowMapper implements RowMapper<RegRepEtdValuationDtls>
{

	@Override
    public RegRepEtdValuationDtls mapRow(ResultSet rs, int rowNum) throws SQLException
    {
		RegRepEtdValuationDtls currRegRepEtdValuationDtls = new RegRepEtdValuationDtls();		
		
		currRegRepEtdValuationDtls.setOutputMessage(rs.getString("output_message"));
		currRegRepEtdValuationDtls.setMessageId(rs.getString("message_id"));		
		currRegRepEtdValuationDtls.setCobDate(rs.getString("cob_date"));
		currRegRepEtdValuationDtls.setSrcSysMessageId(rs.getString("src_sys_message_id"));
		currRegRepEtdValuationDtls.setTradeId(rs.getString("trade_id"));
		currRegRepEtdValuationDtls.setTradeVersion(rs.getString("trade_version"));
		currRegRepEtdValuationDtls.setUti(rs.getString("uti"));
		currRegRepEtdValuationDtls.setUsi(rs.getString("usi"));
		currRegRepEtdValuationDtls.setMeasureType(rs.getString("measure_type"));
		currRegRepEtdValuationDtls.setMeasureValue(rs.getString("measure_value"));
		currRegRepEtdValuationDtls.setCurrency(rs.getString("currency"));
		currRegRepEtdValuationDtls.setValuationDate(rs.getString("valuation_date"));
		currRegRepEtdValuationDtls.setReportable(rs.getString("isReportable"));
		
		
	    return currRegRepEtdValuationDtls;
    }

}
