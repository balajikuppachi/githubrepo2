package com.wellsfargo.regulatory.etd.batch;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.dto.EtdReportGenerationRequest;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionExtnDao;

/**
 * @author Raji Komatreddy <p> 
 * This class starts batch job which is defined in spring configuration
 * file, etdBatchjob picks records from Etd_trade_jurisdiction table for Transaction and Position messages, 
 *   etdValuationBatchjob job picks valuation records from etd_valuation_Dtls table for Valuation messages
 */
public class EtdRptGenJobRequest
{

	private Job etdBatchjob;
	private Job etdCompressionBatchjob;
	private Job etdValuationBatchjob;
	private Job etdCollateralBatchjob;
	private Job etdBatchNonReportablejob;
	private Job etdValuationNonRepBatchjob;
	private Job etdCollateralNonRepBatchjob;
	private String messageType;
	private String cobDate;
	private String dtccOutFileLoc;
	private String nonReportableFileLoc;

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	EtdTradeJurisdictionExtnDao etdTradeJurisdictionExtnDao;

	@Transformer
	public Message<JobLaunchRequest> toRequest(Message<?> message) throws EtdMessageException
	{
		Object ipMessage = null;
		String errorString = null;
		EtdReportGenerationRequest inEtdReportGenerationRequest = null;
		String outFileName = null;
		String dtccFileAbsolutLoc = null;
		String outFileDate = null;
		JobLaunchRequest etdBatchJobLaunch = null;
		Message<JobLaunchRequest> etdBatchJobLaunchMessage = null;		
		int cntOfrecords  = 0;
		String suppressReporting = null;

		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdRptGenJobRequest);

		logger.info("Inside EtdRptGenJobRequest JobLaunchRequest method");
		if (null == message)
		{
			errorString = "Null incoming message EtdRptGenJobRequest";
			logger.error("########## " + errorString);
			throw new EtdMessageException("EtdRptGenJobRequest-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		if (ipMessage instanceof EtdReportGenerationRequest)
		{
			inEtdReportGenerationRequest = (EtdReportGenerationRequest) ipMessage;
			messageType = inEtdReportGenerationRequest.getMessageType();
			cobDate = inEtdReportGenerationRequest.getCobDate();

		}
		else if (ipMessage instanceof File)
		{

			logger.info("OnDemand job started by file watcher, msgType and cobDate will be taken from file name or taken from config file");
			try
			{
				String onDemandFileName = null;
				String [] fileParams = null;
				 
				int numParams = 0;
				File inFile = (File) ipMessage;
				if(null != inFile)
				{
					 onDemandFileName = inFile.getName();
					 onDemandFileName= StringUtils.substringBefore(onDemandFileName, ".");
					 fileParams = onDemandFileName.split("_");
					 numParams = fileParams.length;
					 if(numParams >= 2)
					 {
						 messageType = fileParams[0];
						 cobDate     = fileParams[1];
					 }	
					 else
					 {
						 messageType = fileParams[0];
					 }
										 
					inFile.delete();

				}
				
			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating Dtcc ETD response jobrequest " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new EtdMessageException("EtdRptGenJobRequest-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, e.getMessage());

			}

		}
		Date currDate = new Date();
		String dateFormat = EtdConstants.ETD_COBDATE_FORMAT;
		SimpleDateFormat cobDateFormat = new SimpleDateFormat(dateFormat);
		if (StringUtils.isBlank(cobDate))
		{
			cobDate = cobDateFormat.format(currDate);

		}
		/*else
		{
			cobDate = cobDateFormat.format(cobDate);
		}*/
		try
		{

			String fileDateFormat = "yyMMddHHmmssZ";
			SimpleDateFormat currfileDateFormat = new SimpleDateFormat(fileDateFormat);
			outFileDate = currfileDateFormat.format(currDate);

			outFileName = messageType + "_" + outFileDate + ".csv";
			
			if(null != messageType &&
					( messageType.equalsIgnoreCase(EtdConstants.TRANSACTION_RPT_NONREPORTABLE) ||
					  messageType.equalsIgnoreCase(EtdConstants.POSITION_RPT_NONREPORTABLE)	||
					  messageType.equalsIgnoreCase(EtdConstants.VALUATION_RPT_NONREPORTABLE)	||
					  messageType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT_NONREPORTABLE)	 ))
			{
				dtccFileAbsolutLoc = nonReportableFileLoc + "//" + cobDate + "//" +  outFileName;
				suppressReporting = EtdConstants.ETD_TRUE;
			}
			else
			{
				dtccFileAbsolutLoc = dtccOutFileLoc + "//" + cobDate + "//" +  outFileName;
			}
		

			JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();

			jobParametersBuilder.addString(EtdConstants.MESSAGETYPE, messageType);

			jobParametersBuilder.addString(EtdConstants.COBDATE, cobDate);
			jobParametersBuilder.addString(EtdConstants.DTTC_OUT_FILE_LOC, dtccFileAbsolutLoc);
			jobParametersBuilder.addString(EtdConstants.ETD_SUPRESS_REPORTING, suppressReporting);

			if (null == messageType) messageType = EtdConstants.TRANSACTION_RPT;

			if (messageType.equalsIgnoreCase(EtdConstants.VALUATION_RPT))
			{
				cntOfrecords =  etdTradeJurisdictionExtnDao.getCntOfValuationRecords(cobDate);
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdValuationBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.VALUATION_RPT).build();	
					logger.info("Job request is for Valuation report number of records" + cntOfrecords + "forCobDate" + cobDate);
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdValuationBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();
					logger.info("Job request is for Valuation report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Valuation report: EtdRptGenJobRequest");


			}
			else if (messageType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT))
			{
				cntOfrecords =  etdTradeJurisdictionExtnDao.getCntOfCollateralRecords(cobDate);
				
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdCollateralBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.COLLATERAL_RPT).build();					
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdCollateralBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();	
					logger.info("Job request is for Collateral report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Collateral report: EtdRptGenJobRequest");


			}
			else if (messageType.equalsIgnoreCase(EtdConstants.POSITION_RPT))
			{
				cntOfrecords =  etdTradeJurisdictionExtnDao.getCntOfTransactionRecords(messageType, cobDate);
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.TRANSACTION_RPT).build();
					logger.info("Job request is for Postion report number of postion records " + cntOfrecords + "forCobDate" + cobDate);
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();
					logger.info("Job request is for Postion report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Position report: EtdRptGenJobRequest");


			}
			else if(messageType.equalsIgnoreCase(EtdConstants.TRANSACTION_RPT))
			{
				cntOfrecords =   etdTradeJurisdictionExtnDao.getCntOfTransactionRecords(messageType, cobDate);
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.TRANSACTION_RPT).build();
					logger.info("Job request is for Transaction report:but there is no data in DB for cobDate " + cobDate);
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();
					logger.info("Job request is for Transaction report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Postion/Transaction report: EtdRptGenJobRequest");


			}
			else if (messageType.equalsIgnoreCase(EtdConstants.VALUATION_RPT_NONREPORTABLE))
			{
				messageType = EtdConstants.VALUATION_RPT;
				jobParametersBuilder.addString(EtdConstants.MESSAGETYPE, messageType);
				cntOfrecords =  etdTradeJurisdictionExtnDao.getCntOfValuationNonReportableRecords(cobDate);
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdValuationNonRepBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.VALUATION_RPT).build();	
					logger.info("Job request is for Valuation Non Reportable report number of records" + cntOfrecords + "forCobDate" + cobDate);
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdValuationNonRepBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();
					logger.info("Job request is for Valuation non reportable report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Valuation non reportable report: EtdRptGenJobRequest");


			}
			else if (messageType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT_NONREPORTABLE))
			{
				messageType = EtdConstants.COLLATERAL_RPT;
				jobParametersBuilder.addString(EtdConstants.MESSAGETYPE, messageType);
				cntOfrecords =  etdTradeJurisdictionExtnDao.getCntOfCollateralNonReportableRecords(cobDate);
				
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdCollateralNonRepBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.COLLATERAL_RPT).build();					
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdCollateralNonRepBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();	
					logger.info("Job request is for Collateral non reportable report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Collateral  non reportable report: EtdRptGenJobRequest");


			}
			else if (messageType.equalsIgnoreCase(EtdConstants.POSITION_RPT_NONREPORTABLE))
			{
				messageType = EtdConstants.POSITION_RPT;
				jobParametersBuilder.addString(EtdConstants.MESSAGETYPE, messageType);
				cntOfrecords =  etdTradeJurisdictionExtnDao.getCntOfTransactionNonReportableRecords(messageType, cobDate);
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchNonReportablejob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.TRANSACTION_RPT).build();
					logger.info("Job request is for Postion non reportable report number of postion records " + cntOfrecords + "forCobDate" + cobDate);
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchNonReportablejob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();
					logger.info("Job request is for Postion non reportable report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Position non reportable report: EtdRptGenJobRequest");


			}
			else if(messageType.equalsIgnoreCase(EtdConstants.TRANSACTION_RPT_NONREPORTABLE))
			{
				messageType = EtdConstants.TRANSACTION_RPT;
				jobParametersBuilder.addString(EtdConstants.MESSAGETYPE, messageType);
				cntOfrecords =   etdTradeJurisdictionExtnDao.getCntOfTransactionNonReportableRecords(messageType, cobDate);
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchNonReportablejob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.TRANSACTION_RPT).build();
					logger.info("Job request is for Transaction non reportable report:but there is no data in DB for cobDate " + cobDate);
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdBatchNonReportablejob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();
					logger.info("Job request is for Transaction non reportable report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Transaction non reportable report: EtdRptGenJobRequest");


			}
			else if(messageType.equalsIgnoreCase(EtdConstants.COMPRESSION_RPT))
			{
				cntOfrecords =   etdTradeJurisdictionExtnDao.getCntOfTransactionRecords(messageType, cobDate);
				if(cntOfrecords > 0)
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdCompressionBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.COMPRESSION_RPT).build();
					logger.info("Job request is for Compression report number of records" + cntOfrecords + "forCobDate" + cobDate);
				}
				else
				{
					etdBatchJobLaunch = new JobLaunchRequest(etdCompressionBatchjob, jobParametersBuilder.toJobParameters());
					etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.NODATA_RPT).build();
					logger.info("Job request is for Compression report:but there is no data in DB for cobDate " + cobDate);
				}
				
				logger.info("Job request is for Compression report: EtdRptGenJobRequest");


			}
			
			else if(messageType.equalsIgnoreCase(EtdConstants.EMAILER))
			{
				etdBatchJobLaunch = new JobLaunchRequest(etdBatchjob, jobParametersBuilder.toJobParameters());
				etdBatchJobLaunchMessage = MessageBuilder.withPayload(etdBatchJobLaunch).setHeader(EtdConstants.ETD_REQUEST_TYPE, EtdConstants.EMAILER).build();
				logger.info("Job request is for Emailer forCobDate" + cobDate);
				
				logger.info("Job request is for Emailer report: EtdRptGenJobRequest");
			}
			
			else
			{
				logger.info("Job request received for invalid message type: EtdRptGenJobRequest");
			}
		}
		catch (Exception exp)
		{
			errorString = "exception occurred while creating Etd Batch job launch request " + ExceptionUtils.getFullStackTrace(exp);
			logger.error("########## " + errorString);
			throw new EtdMessageException("EtdRptGenJobRequest-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

		}
		finally
		{
			//clearing message type and cobdate for next execution to be picked properly
			messageType = null;
			cobDate = null;
		}

		return etdBatchJobLaunchMessage;

	}	
	

	public void setMessageType(String messageType)
	{
		this.messageType = messageType;
	}

	public void setEtdBatchjob(Job etdBatchjob)
	{
		this.etdBatchjob = etdBatchjob;
	}

	public void setEtdValuationBatchjob(Job etdValuationBatchjob)
	{
		this.etdValuationBatchjob = etdValuationBatchjob;
	}

	public void setCobDate(String cobDate)
	{
		this.cobDate = cobDate;
	}

	public void setDtccOutFileLoc(String dtccOutFileLoc)
	{
		this.dtccOutFileLoc = dtccOutFileLoc;
	}

	public Job getEtdCollateralBatchjob()
	{
		return etdCollateralBatchjob;
	}

	public void setEtdCollateralBatchjob(Job etdCollateralBatchjob)
	{
		this.etdCollateralBatchjob = etdCollateralBatchjob;
	}

	public Job getEtdBatchNonReportablejob()
	{
		return etdBatchNonReportablejob;
	}

	public void setEtdBatchNonReportablejob(Job etdBatchNonReportablejob)
	{
		this.etdBatchNonReportablejob = etdBatchNonReportablejob;
	}

	public Job getEtdCollateralNonRepBatchjob()
	{
		return etdCollateralNonRepBatchjob;
	}

	public void setEtdCollateralNonRepBatchjob(Job etdCollateralNonRepBatchjob)
	{
		this.etdCollateralNonRepBatchjob = etdCollateralNonRepBatchjob;
	}

	public EtdTradeJurisdictionExtnDao getEtdTradeJurisdictionExtnDao()
	{
		return etdTradeJurisdictionExtnDao;
	}

	public void setEtdTradeJurisdictionExtnDao(EtdTradeJurisdictionExtnDao etdTradeJurisdictionExtnDao)
	{
		this.etdTradeJurisdictionExtnDao = etdTradeJurisdictionExtnDao;
	}

	public Job getEtdValuationNonRepBatchjob()
	{
		return etdValuationNonRepBatchjob;
	}

	public void setEtdValuationNonRepBatchjob(Job etdValuationNonRepBatchjob)
	{
		this.etdValuationNonRepBatchjob = etdValuationNonRepBatchjob;
	}

	public String getNonReportableFileLoc()
	{
		return nonReportableFileLoc;
	}

	public void setNonReportableFileLoc(String nonReportableFileLoc)
	{
		this.nonReportableFileLoc = nonReportableFileLoc;
	}


	public Job getEtdCompressionBatchjob() {
		return etdCompressionBatchjob;
	}


	public void setEtdCompressionBatchjob(Job etdCompressionBatchjob) {
		this.etdCompressionBatchjob = etdCompressionBatchjob;
	}
	
}
