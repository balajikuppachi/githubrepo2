package com.wellsfargo.regulatory.etd.batch;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdTradeJurisdiction;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class RegRepEtdTradeJurisdictionRowMapper implements RowMapper<RegRepEtdTradeJurisdiction>
{

	@Override
	public RegRepEtdTradeJurisdiction mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		RegRepEtdTradeJurisdiction currTradeJurisdiction = new RegRepEtdTradeJurisdiction();

		currTradeJurisdiction.setJurisdictionId(rs.getInt("jurisdiction_id"));
		//currTradeJurisdiction.setMessageId(rs.getString("message_id"));
		//currTradeJurisdiction.setMsgType(rs.getString("msg_type"));
		//currTradeJurisdiction.setCobDate(rs.getString("cob_date"));
		//currTradeJurisdiction.setIsReportable(rs.getString("isReportable"));
		//currTradeJurisdiction.setSubmissionStatus(rs.getString("submission_status"));
		//currTradeJurisdiction.setState(rs.getString("state"));
		//currTradeJurisdiction.setJurisdiction(rs.getString("jurisdiction"));
		//currTradeJurisdiction.setRepository(rs.getString("repository"));
		//currTradeJurisdiction.setBatchId(rs.getInt("batch_id"));
		currTradeJurisdiction.setOutputMessage(rs.getString("output_message"));
		//currTradeJurisdiction.setCreateDatetime(rs.getDate("create_datetime"));
		//currTradeJurisdiction.setUpdateDatetime(rs.getDate("update_datetime"));

		return currTradeJurisdiction;
	}

}
