package com.wellsfargo.regulatory.etd.batch.services;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.bo.dtcc.ETDDtccTemplate;
import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdValuationDtls;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.etd.services.parsers.ETDDtccTemplateParser;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdTradeJurisdictionMapper;

/**
 * 
 * @author Raji Komatreddy
 *  <p> Preapares a Valuation record by using data from Position record and 
 * inserts Valuation record into EtdTradeJurisdiction table
 * updates etdDtccTemplate object with valuation trade information and passes that object to writer 
 * to prepare final Valuation csv file to be submitted to DTCC
 *
 */
public class EtdDtccValuationRptMapperProcessor implements ItemProcessor<RegRepEtdValuationDtls, ETDDtccTemplate>
{

	@Autowired
	private ETDDtccTemplateParser eTDDtccTemplateParser;
	
	private EtdTradeJurisdictionDao etdTradeJurisdictionDao;

	private static Logger logger = Logger.getLogger(EtdDtccRptMapperProcessor.class.getName());

	@Override
	public ETDDtccTemplate process(RegRepEtdValuationDtls regRepEtdValuationDtls) throws EtdMessageException
	{
		logger.debug("inside EtdDtccValuationRptMapperProcessor processor");
		ETDDtccTemplate etdDtccTemplate = new ETDDtccTemplate();
		String outMsgToDtcc = regRepEtdValuationDtls.getOutputMessage();
		Object parsedObj = null;
		EtdTradeJurisdictionMapper etdTradeJurisdictionMapper = new EtdTradeJurisdictionMapper();
		String updatedOutPutMessage = null;
		
		String valuationTypeParty1 = null;
		String delegatedRep = null;
		
		if (null != outMsgToDtcc)
		{
			try
			{
				parsedObj = eTDDtccTemplateParser.unmarshallToTemplateObj(outMsgToDtcc);
				if (parsedObj instanceof ETDDtccTemplate)
				{
					etdDtccTemplate = (ETDDtccTemplate) parsedObj;
					// set correlation ID (Data submitter ID) inside dtccTemplate object
					//etdDtccTemplate.setDataSubmitterMsgID(Integer.toString(etdTradeJurisdiction.getJurisdictionId()));					
					
					
					// set valuation related information
					etdDtccTemplate.setMsgType(EtdConstants.VALUATION_RPT);
					
					delegatedRep = etdDtccTemplate.getSubmittedForValue();
										
					etdDtccTemplate.setMTMValueParty1(regRepEtdValuationDtls.getMeasureValue());
					etdDtccTemplate.setMTMCurrencyParty1(regRepEtdValuationDtls.getCurrency());
					etdDtccTemplate.setValuationDatetimeParty1(regRepEtdValuationDtls.getValuationDate());
					
					valuationTypeParty1 = regRepEtdValuationDtls.getMeasureType();
					
					if(valuationTypeParty1.equalsIgnoreCase(EtdConstants.ETD_VAL_MTM_ACTUAL_VALUE))
						  valuationTypeParty1 = EtdConstants.ETD_VAL_MTM_DTCC_VALUE;
					
					etdDtccTemplate.setValuationTypeParty1(valuationTypeParty1);
					
					if(null != delegatedRep && StringUtils.equals(delegatedRep, EtdConstants.ETD_DELEGATED_REPORT_SUBMITTEDFOR_VALUE)){
							etdDtccTemplate.setMTMValueParty2(regRepEtdValuationDtls.getMeasureValue());
							etdDtccTemplate.setMTMCurrencyParty2(regRepEtdValuationDtls.getCurrency());
							etdDtccTemplate.setValuationDatetimeParty2(regRepEtdValuationDtls.getValuationDate());
							etdDtccTemplate.setValuationTypeParty2(valuationTypeParty1);
					}
					
					updatedOutPutMessage = eTDDtccTemplateParser.marshallToDtccTemplateString(etdDtccTemplate);
					
					// save valuation record into Etd_tradeJurisdiction table
					EtdTradeJurisdiction currEtdTradeJurisdiction = etdTradeJurisdictionMapper.populateEtdTradeJurisdiction(regRepEtdValuationDtls);
					currEtdTradeJurisdiction.setOutputMessage(updatedOutPutMessage);
					currEtdTradeJurisdiction =  etdTradeJurisdictionDao.save(currEtdTradeJurisdiction);
					if(null != currEtdTradeJurisdiction ) 
						etdDtccTemplate.setDataSubmitterMsgID(Long.toString(currEtdTradeJurisdiction.getJurisdictionId()));
					
				}

			}
			catch (Exception exp)
			{
				throw new EtdMessageException("etdRowMapper-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, exp.getMessage(), regRepEtdValuationDtls.getMessageId());
			}

		}

		logger.debug("Exiting EtdDtccRptMapperProcessor processor");
		return etdDtccTemplate;
	}

	public void setEtdTradeJurisdictionDao(EtdTradeJurisdictionDao etdTradeJurisdictionDao)
	{
		this.etdTradeJurisdictionDao = etdTradeJurisdictionDao;
	}

}
