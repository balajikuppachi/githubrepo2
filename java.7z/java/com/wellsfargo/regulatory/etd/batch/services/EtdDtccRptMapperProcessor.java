package com.wellsfargo.regulatory.etd.batch.services;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.bo.dtcc.ETDDtccTemplate;
import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdTradeJurisdiction;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.etd.services.parsers.ETDDtccTemplateParser;

/**
 * 
 * @author Raji Komatreddy
 * 
 *  <p> prepares DtccEtdResponseMessage object out of DtccEtdAckMessage object and passes on to writer
 *
 */
public class EtdDtccRptMapperProcessor implements ItemProcessor<RegRepEtdTradeJurisdiction, ETDDtccTemplate>
{
    @Autowired
	private ETDDtccTemplateParser eTDDtccTemplateParser;
    private static Logger logger = Logger.getLogger(EtdDtccRptMapperProcessor.class.getName());
    
	@Override
	public ETDDtccTemplate process(RegRepEtdTradeJurisdiction etdTradeJurisdiction) throws EtdMessageException
	{
		logger.debug("inside EtdDtccRptMapperProcessor processor");
		ETDDtccTemplate etdDtccTemplate = new ETDDtccTemplate();
		String outMsgToDtcc =  etdTradeJurisdiction.getOutputMessage();
		Object parsedObj = null;
	
		
		if(null != outMsgToDtcc)
		{
			try
			{
				parsedObj = eTDDtccTemplateParser.unmarshallToTemplateObj(outMsgToDtcc);
				if(parsedObj instanceof ETDDtccTemplate )
				{
					etdDtccTemplate = (ETDDtccTemplate)parsedObj;
					//set correlation ID (Data submitter ID) inside dtccTemplate object
					etdDtccTemplate.setDataSubmitterMsgID(Integer.toString(etdTradeJurisdiction.getJurisdictionId()));
				}
				
			}
			catch(Exception exp)
			{
				throw new EtdMessageException("etdRowMapper-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, exp.getMessage(), etdTradeJurisdiction.getMessageId());
			}
			
		}
		
		logger.debug("Exiting EtdDtccRptMapperProcessor processor");
		return etdDtccTemplate;
	}

}
