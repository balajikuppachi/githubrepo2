package com.wellsfargo.regulatory.etd.batch.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;

import com.wellsfargo.regulatory.commons.etd.dto.DtccEtdResponseMessage;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.core.services.reader.RegulatoryMessageReader;

/**
 * 
 * @author Raji Komatreddy
 * 
 *  <p> Places DtccEtdResponseMessage list in JobExecution
 *
 */
public class EtdDtccAckMessageDBWriter implements ItemWriter<DtccEtdResponseMessage>,StepExecutionListener
{
	private List<DtccEtdResponseMessage> finalDtccEtdResponseMessageList = new ArrayList<DtccEtdResponseMessage>();
	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());
	 

	@Override
    public void write(List<? extends DtccEtdResponseMessage> dtccEtdResponseMessageList) throws Exception
    {
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdDtccAckMessageDBWriter);
		finalDtccEtdResponseMessageList.addAll(dtccEtdResponseMessageList);
		
		logger.info("Inside  EtdDtccAckMessageDBWriter");
	    
    }

	@Override
    public ExitStatus afterStep(StepExecution stepExecution)
    {
		List<DtccEtdResponseMessage> executionDtccEtdResponseMessageList = null;
		executionDtccEtdResponseMessageList = finalDtccEtdResponseMessageList;
		
		stepExecution.getExecutionContext().put(EtdConstants.DTTC_RESPONSE_MESSAGE_LIST, executionDtccEtdResponseMessageList);	
		stepExecution.getJobExecution().getExecutionContext().put(EtdConstants.DTTC_RESPONSE_MESSAGE_LIST, executionDtccEtdResponseMessageList);
		
	//	String inputFinename = stepExecution.getJobParameters().getString(EtdConstants.DTTC_ACK_RESP_FILE_LOC);
	//	File inFile = new File(inputFinename);
	//	inFile.delete();
		
	    return null;
    }

	@Override
    public void beforeStep(StepExecution arg0)
    {
	    // TODO Auto-generated method stub
	    
    }

}
