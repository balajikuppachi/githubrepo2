package com.wellsfargo.regulatory.etd.batch.services;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.commons.etd.dto.DtccEtdNackMessage;
import com.wellsfargo.regulatory.commons.etd.dto.DtccEtdResponseMessage;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.core.services.reader.RegulatoryMessageReader;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class EtdDtccNackMessageProcessor implements ItemProcessor<DtccEtdNackMessage, DtccEtdResponseMessage>
{
	private static Logger logger = Logger.getLogger(RegulatoryMessageReader.class.getName());
	@Override
    public DtccEtdResponseMessage process(DtccEtdNackMessage dtccEtdNackMessage) throws Exception
    {
		DtccEtdResponseMessage currDtccEtdResponseMessage = new DtccEtdResponseMessage();
		
		currDtccEtdResponseMessage.setAssetClass(dtccEtdNackMessage.getPrimaryAssetClass());
		currDtccEtdResponseMessage.setDataSubmitterMessageID(dtccEtdNackMessage.getDataSubmitterMessageID());
		currDtccEtdResponseMessage.setDtccResponseType(EtdConstants.DTTC_RESPONSE_NACK);
		currDtccEtdResponseMessage.setErrorCodeAndReason(dtccEtdNackMessage.getErrorCodeAndReason());
		currDtccEtdResponseMessage.setMessageType(dtccEtdNackMessage.getMessageType());
		currDtccEtdResponseMessage.setStatus(EtdConstants.DTTC_RESPONSE_REJECTED);
		currDtccEtdResponseMessage.setTransactionReferenceID(dtccEtdNackMessage.getTransactionReferenceID());
		
		
		logger.debug("input nack message from  dtcc " + dtccEtdNackMessage.toString());
		    return currDtccEtdResponseMessage;
	    
    }

	
}
