package com.wellsfargo.regulatory.etd.batch.services;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.commons.etd.dto.DtccEtdAckMessage;
import com.wellsfargo.regulatory.commons.etd.dto.DtccEtdResponseMessage;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.etd.batch.report.MessageToEtdRptRequestService;

/**
 * 
 * @author Raji Komatreddy
 * 
 * <p> prepared DtccEtdResponseMessage object out of DtccEtdAckMessage object and passes on to writer
 *
 */
public class EtdDtccAckMessageProcessor implements ItemProcessor<DtccEtdAckMessage, DtccEtdResponseMessage>
{
	private static Logger logger = Logger.getLogger(MessageToEtdRptRequestService.class.getName());

	@Override
	public DtccEtdResponseMessage process(DtccEtdAckMessage dtccEtdAckMessage) throws Exception
	{
		DtccEtdResponseMessage currDtccEtdResponseMessage = new DtccEtdResponseMessage();

		currDtccEtdResponseMessage.setAssetClass(dtccEtdAckMessage.getAssetClass());
		currDtccEtdResponseMessage.setDataSubmitterMessageID(dtccEtdAckMessage.getDataSubmitterMessageID());
		currDtccEtdResponseMessage.setDtccResponseType(EtdConstants.DTTC_RESPONSE_ACK);	
		currDtccEtdResponseMessage.setMessageType(dtccEtdAckMessage.getMessageType());
		currDtccEtdResponseMessage.setStatus(EtdConstants.DTTC_RESPONSE_ACCEPTED);
		currDtccEtdResponseMessage.setTransactionReferenceID(dtccEtdAckMessage.getTransactionReferenceID());

		logger.debug("input ack message from  dtcc " + dtccEtdAckMessage.toString());
		return currDtccEtdResponseMessage;

		
		
	}

}
