package com.wellsfargo.regulatory.etd.batch.services;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.etd.bo.collateral.dtcc.ETDCollateralDtccTemplate;
import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdCollateralDtls;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.etd.services.parsers.ETDCollateralDtccTemplateParser;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdTradeJurisdictionMapper;

/**
 * @author Raji Komatreddy
 */
public class EtdDtccCollateralRptMapperProcessor implements ItemProcessor<RegRepEtdCollateralDtls, ETDCollateralDtccTemplate>
{

	@Autowired
	ETDCollateralDtccTemplateParser eTDCollateralDtccTemplateParser;
	
	@Autowired
	EtdTradeJurisdictionDao etdTradeJurisdictionDao;

	private static Logger logger = Logger.getLogger(EtdDtccCollateralRptMapperProcessor.class);

	@Override
	public ETDCollateralDtccTemplate process(RegRepEtdCollateralDtls regRepEtdCollateralDtls) throws Exception
	{
		logger.debug("inside ETDCollateralDtccTemplate : process method");
		String dataSubmitterLei = null;
		String tradepartyLei = null;
		String executionAgentLei = null;
		String dtccOutMsg = null;

		ETDCollateralDtccTemplate currETDCollateralDtccTemplate = new ETDCollateralDtccTemplate();
		EtdTradeJurisdictionMapper etdTradeJurisdictionMapper = new EtdTradeJurisdictionMapper();
		
		
		
		if (null != regRepEtdCollateralDtls)
		{
			dataSubmitterLei = regRepEtdCollateralDtls.getDataSubmitterLei();
			tradepartyLei = regRepEtdCollateralDtls.getTradePartyLei();
			executionAgentLei = regRepEtdCollateralDtls.getExecutionagentLei();

			currETDCollateralDtccTemplate.setVersion(EtdConstants.ETD_COLLATERL_TEMPLATE_VERSION);
			currETDCollateralDtccTemplate.setMsgType(EtdConstants.ETD_COLLATERL_VALUE_MSG);
			// currETDCollateralDtccTemplate.setDataSubmitterMsgID(value); set after saving message to etd Tradejurisdiction table
			currETDCollateralDtccTemplate.setAction(regRepEtdCollateralDtls.getAction());
			currETDCollateralDtccTemplate.setDataSubmitterPrefix(StringUtils.substringBefore(dataSubmitterLei, ":"));
			currETDCollateralDtccTemplate.setDataSubmitterValue(StringUtils.substringAfter(dataSubmitterLei, ":"));
			currETDCollateralDtccTemplate.setTradePartyPrefix(StringUtils.substringBefore(tradepartyLei, ":"));
			currETDCollateralDtccTemplate.setTradePartyValue(StringUtils.substringAfter(tradepartyLei, ":"));
			currETDCollateralDtccTemplate.setExecutionAgentPartyPrefix(StringUtils.substringBefore(executionAgentLei, ":"));
			currETDCollateralDtccTemplate.setExecutionAgentPartyValue(StringUtils.substringAfter(executionAgentLei, ":"));
			currETDCollateralDtccTemplate.setCollateralPortfolioCode(regRepEtdCollateralDtls.getPortfolioCode());
			currETDCollateralDtccTemplate.setCollateralPortfolioIndicator(regRepEtdCollateralDtls.getPortfolioIndicator());

			if (null != regRepEtdCollateralDtls.getValue())
			{
				currETDCollateralDtccTemplate.setValueOfCollateral(regRepEtdCollateralDtls.getValue());
			}
				

			currETDCollateralDtccTemplate.setCurrencyOfCollateral(regRepEtdCollateralDtls.getCurrency());
			currETDCollateralDtccTemplate.setCollateralValutionDate(regRepEtdCollateralDtls.getValuationDate()); // change	to UTC																							 // to
			
			currETDCollateralDtccTemplate.setCollateralReportingDate(regRepEtdCollateralDtls.getReportingDate()); //change to YYYY_MM_DD format
			currETDCollateralDtccTemplate.setSendTo(EtdConstants.ETD_COLLATERL_SEND_TO);
			currETDCollateralDtccTemplate.setExecutionAgentMaskingIndicator(regRepEtdCollateralDtls.getExecutionAgentMaskInd());
			
			// save valuation record into Etd_tradeJurisdiction table
			if(null != eTDCollateralDtccTemplateParser)
			{
				dtccOutMsg =  eTDCollateralDtccTemplateParser.marshallToCollateralDtccTemplateString(currETDCollateralDtccTemplate);
			}
			
			EtdTradeJurisdiction currEtdTradeJurisdiction = etdTradeJurisdictionMapper.populateEtdTradeJurisdiction(regRepEtdCollateralDtls);
			                                     currEtdTradeJurisdiction.setOutputMessage(dtccOutMsg);
			currEtdTradeJurisdiction =  etdTradeJurisdictionDao.save(currEtdTradeJurisdiction);
			if(null != currEtdTradeJurisdiction ) 
				currETDCollateralDtccTemplate.setDataSubmitterMsgID(Long.toString(currEtdTradeJurisdiction.getJurisdictionId()));

		}

		return currETDCollateralDtccTemplate;
	}

}
