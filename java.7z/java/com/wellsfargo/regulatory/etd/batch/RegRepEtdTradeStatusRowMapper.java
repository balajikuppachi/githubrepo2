package com.wellsfargo.regulatory.etd.batch;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.etd.dto.RegRepEtdTradeStatus;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class RegRepEtdTradeStatusRowMapper implements RowMapper<RegRepEtdTradeStatus>
{

	@Override
    public RegRepEtdTradeStatus mapRow(ResultSet rs, int rowNum) throws SQLException
    {
		RegRepEtdTradeStatus currRegRepEtdTradeStatus = new RegRepEtdTradeStatus();
		currRegRepEtdTradeStatus.setOutPutMsg(rs.getString("outPutMsg"));
	    
	    return currRegRepEtdTradeStatus;
    }

}
