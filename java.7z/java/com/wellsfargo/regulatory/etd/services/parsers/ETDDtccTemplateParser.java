package com.wellsfargo.regulatory.etd.services.parsers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.StringReader;
import java.util.Date;
import java.util.Scanner;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.etd.bo.dtcc.ETDDtccTemplate;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * 
 * @author Raji Komatreddy
 * 
 * converts etdDtccTemplate string to ETDDtccTemplate object using JaxB
 *
 */
@Component
public class ETDDtccTemplateParser
{
	@Autowired
	@Qualifier("etdDtccTemplateJaxbMarshaller")
	private Marshaller marshaller;
	@Autowired
	@Qualifier("etdDtccTemplateJaxbMarshaller")
	private Unmarshaller unmarshaller;
	@Value("${regRep.response.file.path}")
	private String tempFileLoc;

	private static Logger logger = Logger.getLogger(ETDDtccTemplateParser.class.getName());

	/**
	 * converts payload into ETDDtccTemplate java object
	 * 
	 * @param payload
	 * @return
	 * @throws Exception
	 */
	public ETDDtccTemplate unmarshallToTemplateObj(String payload) throws Exception
	{
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.ETDDtccTemplateParser);
		
		logger.debug("inside ETDDtccTemplateParser unmarshallToTemplateObj method");
		StringReader payLoadStream = null;
		Object parsedObject = null;
		String errorString = null;
		ETDDtccTemplate currEtdDtccTemplate = null;

		try
		{
			payLoadStream = new StringReader(payload);
			parsedObject = unmarshaller.unmarshal(new StreamSource(payLoadStream));
		}
		catch (Exception e)
		{
			errorString = "Exception occurred while parsing incoming sdr request using JaxB : " + e.getMessage();
			logger.error("########## " + errorString);
			return null;
		}

		if (null == parsedObject || !(parsedObject instanceof ETDDtccTemplate))
		{
			errorString = "Invalid parsed object : ";
			logger.error("########## " + errorString);
			return null;

		}

		currEtdDtccTemplate = (ETDDtccTemplate) parsedObject;

		logger.debug(" EtdDtccTemplate object formed out of xml string: " + currEtdDtccTemplate.toString());
		logger.debug("exiting ETDDtccTemplateParser unmarshallToTemplateObj method");

		return currEtdDtccTemplate;

	}

	public String marshallToDtccTemplateString(ETDDtccTemplate inETDDtccTemplate) throws Exception
	{
		String response = null;
		String fileName = Constants.REG_REP_TEMP + Constants.UNDERSCORE + "ETDDtccTemplateParser" +  Constants.UNDERSCORE + (new Date()).getTime();

		File tempFile = new File(tempFileLoc + File.separator + fileName);

		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(tempFile);

			marshaller.marshal(inETDDtccTemplate, new StreamResult(fos));
			
			Scanner respScanner = new Scanner(tempFile);			
			response = respScanner.useDelimiter("\\Z").next();
			respScanner.close();	
		
			logger.debug("EtdDtccTemplate string: " + response);

		}
		catch (Exception exp)
		{
			throw exp;

		}
		finally
		{
			if (fos != null)
			{
				fos.close();
			}

			tempFile.delete();
		}

		return response;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

}
