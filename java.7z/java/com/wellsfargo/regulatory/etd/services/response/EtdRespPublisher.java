package com.wellsfargo.regulatory.etd.services.response;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * 
 * @author Raji Komatreddy
 *
 * <p> Publishes response to FO system through dataLink
 *  uses connection factory defined in etd_context file </P>
 */
@Component
public class EtdRespPublisher
{
	private static Logger logger = Logger.getLogger(EtdRespPublisher.class.getName());

	public String publish(Message<?> message) throws EtdMessageException
	{
		String sdrMessageId = null;
		String errorString = null;
		ReportingContext repContext = null;
		String etdResponse = null;

		logger.info("inside EtdRespPublisher: publish method ");

		if (null == message)
		{
			errorString = "Null incoming object. EtdRespPublisher failed";
			logger.debug("########## " + errorString);
			return null;
		}

		if (!(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming object type.EtdRespPublisher process failed";
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			logger.debug("########## " + errorString + "for msgId: " + sdrMessageId);
			return null;

		}

		repContext = (ReportingContext) message.getPayload();
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdRespPublisher);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(repContext.getMessageId()));

		etdResponse = repContext.getPayload();
		//String header = message.getHeaders().toString();
		
		//logger.info("exiting EtdRespPublisher: header information : " + header );
		
		logger.info("exiting EtdRespPublisher: publish method: response sent to dataLink : " + etdResponse );

		return etdResponse;
	}

}
