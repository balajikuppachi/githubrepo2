package com.wellsfargo.regulatory.etd.services.response;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.RulesResultsContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.bo.etd.response.MessageType;
import com.wellsfargo.regulatory.commons.bo.etd.response.SdrResponse;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.core.services.parsers.SdrRequestParser;

/**
 * @author Raji Komatreddy
 * 
 * <p> sends response to FO system.
 *  Receives ack/nack/wack details from validation service,
 *  Stores wack/nack details in Etd_Exception table </p>
 */
public class EtdRespProcessor
{

	private Marshaller marshaller;

	@SuppressWarnings("unused")
	private Unmarshaller unmarshaller;
	private String tempFileLoc;
	private MessageChannel errorChannel;

	private static Logger logger = Logger.getLogger(SdrRequestParser.class.getName());

	public Message<?> process(Message<?> message) throws EtdMessageException
	{
		String sdrMessageId = null;
		String errorString = null;
		SdrRequest request = null;
		ReportingContext repContext = null;
		RulesResultsContext rulesResultsContext = null;
		SdrResponse sdrResponse = null;
		List<ValidationResult> altertValidationList = null;
		List<ValidationResult> filterValidationList = null;
		String correlationId = null;
		String tradeId = null;
		Boolean valuationAlert = false;
		Boolean collateralAlert = false;

		logger.debug("Entering EtdRespProcessor");

		if (null == message)
		{
			errorString = "Null incoming object. EtdRespProcessor failed";
			logger.debug("########## " + errorString);

			return message;
		}

		if (!(message.getPayload() instanceof ReportingContext))
		{
			errorString = "Invalid incoming object type.Etd Response processing failed";
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			logger.debug("########## " + errorString);

			return message;

		}

		repContext = (ReportingContext) message.getPayload();

		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdRespProcessor);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(repContext.getMessageId()));

		if (null == repContext || null == repContext.getPayload())
		{
			sdrMessageId = (String) message.getHeaders().get(Constants.REG_REP_MESSAGE_ID);
			errorString = "Invalid incoming payload. Etd Response processing  failed";
			logger.debug("########## " + errorString);

			return message;

		}

		sdrMessageId = repContext.getMessageId();
		rulesResultsContext = repContext.getRulesResultsContext();
		request = repContext.getSdrRequest();
		valuationAlert =  repContext.isValuationAlert();
		collateralAlert = repContext.isCollateralAlert();

		if (request != null)
		{
			correlationId = request.getMessageId();
			if(valuationAlert)
			{
				if(null != request.getValuation())
				{
					if( null != request.getValuation().getValuationItem().get(0))
					{
						tradeId = request.getValuation().getValuationItem().get(0).getTradeId();
					}
					
				}
				
			}
			else if (collateralAlert)
			{
				if(null != request.getCollateral())
				{
					tradeId = request.getCollateral().getTradePartyLEI();
					
				}
				
			}
			else
			{
				tradeId = request.getTrade().getTradeHeader().getTradeId();				
			}
			
			
		}
		else
		{
			correlationId = sdrMessageId;
		}

		if ((EtdConstants.ETD_REQUEST).equalsIgnoreCase(rulesResultsContext.getResultsSource()))
		{
			altertValidationList = rulesResultsContext.getAlertValidationResultList();
			filterValidationList = rulesResultsContext.getFilterValidationResultList();
			sdrResponse = new SdrResponse();
			sdrResponse.setFoMessageId(correlationId);
			sdrResponse.setFoSystem(EtdConstants.ETD_FO_SYSTEM);
			sdrResponse.setFoTradeId(tradeId);
			sdrResponse.setSdrSystem(EtdConstants.ESMA_RPT_JURISDICTION);
			try
			{
				Date currDate = new Date();
				GregorianCalendar gc = new GregorianCalendar();
				gc.setTimeInMillis(currDate.getTime());
				DatatypeFactory df = DatatypeFactory.newInstance();
				XMLGregorianCalendar xg = df.newXMLGregorianCalendar(gc);
				sdrResponse.setResponseTimestamp(xg);

			}
			catch (Exception exp)
			{
				errorString = "Error while preparing XMLGregorianCalendar date for response message" +  ExceptionUtils.getFullStackTrace(exp);
				logger.debug("########## " + errorString);

				return message;

			}

			if (!GeneralUtils.IsListNullOrEmpty(repContext.getRegulatories()))
			{

				String currJurisdiction = repContext.getRegulatories().get(0);
				// sdrResponse.setReportingJurisdiction(StringUtils.substringBefore(currJurisdiction,
				// "_"));
				sdrResponse.setReportingJurisdiction(EtdConstants.ESMA_RPT_JURISDICTION);
			}
			else
			{
				sdrResponse.setReportingJurisdiction(EtdConstants.ESMA_RPT_JURISDICTION);
			}

			List<MessageType> messageTypeList = new ArrayList<MessageType>();

			if (altertValidationList == null && filterValidationList == null)
			{
				sdrResponse.setResponseCode(EtdConstants.ETD_ACK);
			}
			else if (altertValidationList != null && filterValidationList == null)
			{
				sdrResponse.setResponseCode(EtdConstants.ETD_WACK);

			}
			else if (filterValidationList != null)
			{
				sdrResponse.setResponseCode(EtdConstants.ETD_NACK);
			}
			// add all alert validation details to response
			if (altertValidationList != null)
			{
				for (ValidationResult currValidationResult : altertValidationList)
				{

					MessageType currMessageType = new MessageType();
					currMessageType.setValue(currValidationResult.getFieldName());
					currMessageType.setDescription(currValidationResult.getErrorDesc());

					messageTypeList.add(currMessageType);

					errorString = "Validation failed for ETD SDR Request for :" + currValidationResult.getFieldName() + "  failure reason  " + currValidationResult.getErrorDesc();

					dispatchException(message, sdrMessageId, errorString, "EtdRsp:1", ExceptionSeverityEnum.ALERT);
				}

			}

			// add all filter validation details to response
			if (filterValidationList != null)
			{
				for (ValidationResult currValidationResult : filterValidationList)
				{
					MessageType currMessageType = new MessageType();
					currMessageType.setValue(currValidationResult.getFieldName());
					currMessageType.setDescription(currValidationResult.getErrorDesc());

					messageTypeList.add(currMessageType);

					errorString = "Validation failed for Etd SDR Request for field :" + currValidationResult.getFieldName() + "  failure reason: " + currValidationResult.getErrorDesc();

					dispatchException(message, sdrMessageId, errorString, "EtdRsp:2", ExceptionSeverityEnum.ERROR);
				}

			}

			sdrResponse.getMessage().addAll(messageTypeList);

		}

		if (sdrResponse != null)
		{
			try
			{
				String respXml = prepareResponse(sdrResponse);

				// set respXml in message as payload in Reportingcontext

				if (respXml != null)
				{
					repContext.setPayload(respXml);
				}

				logger.info("etd response xml : " + respXml);
			}
			catch (Exception e)
			{
				errorString = "Exception occurred while parsing incoming etd sdr request using JaxB : " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);

				throw new EtdMessageException("EtdRsp:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString, sdrMessageId);

			}

		}

		logger.info("Exiting EtdRespProcessor");
		return message;

	}

	/**
	 * @param message
	 * @param sdrMessageId
	 * @param errorString
	 */
	private void dispatchException(Message<?> message, String sdrMessageId, String errorString, String errorCode, ExceptionSeverityEnum severity)
	{

		EtdMessageException currMessageException = null;
		Message<EtdMessageException> excWrapper = null;

		logger.debug("Entering dispatchException for : " + errorString);

		currMessageException = new EtdMessageException(errorCode, severity, ExceptionTypeEnum.ETD_ERROR, errorString, sdrMessageId);
		excWrapper = MessageBuilder.withPayload(currMessageException).copyHeaders(message.getHeaders()).build();

		errorChannel.send(excWrapper);

		logger.debug("Exiting etd dispatchException for : " + errorString);
	}

	/**
	 * converts RegRepResponse object into response xml
	 *
	 * @param regRepResponse
	 * @return
	 * @throws Exception
	 */
	private String prepareResponse(SdrResponse sdrResponse) throws Exception
	{
		String response = null;
		String fileName = Constants.REG_REP_TEMP + Constants.UNDERSCORE + "EtdRespProcessor"  + Constants.UNDERSCORE + (new Date()).getTime();

		File tempFile = new File(tempFileLoc + File.separator + fileName);

		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(tempFile);

			marshaller.marshal(sdrResponse, new StreamResult(fos));

			Scanner respScanner = new Scanner(tempFile);			
			response = respScanner.useDelimiter("\\Z").next();
			respScanner.close();		
		
		}
		catch (Exception exp)
		{
			throw exp;
		}
		finally
		{
			if (fos != null)
			{
				fos.close();
			
				
			}
		tempFile.delete();
		
		}

		return response;
	}

	public String getTempFileLoc()
	{
		return tempFileLoc;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}

	public void setErrorChannel(MessageChannel errorChannel)
	{
		this.errorChannel = errorChannel;
	}

}
