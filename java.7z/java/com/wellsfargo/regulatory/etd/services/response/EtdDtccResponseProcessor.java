package com.wellsfargo.regulatory.etd.services.response;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;

import com.wellsfargo.regulatory.commons.bo.etd.response.MessageType;
import com.wellsfargo.regulatory.commons.bo.etd.response.SdrResponse;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.dto.DtccEtdResponseMessage;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.core.services.parsers.SdrRequestParser;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;

/**
 * @author Raji Komatreddy 
 *  
 *  <p>  (batch ack/nack resposne processor)  
 *   sends response to FO system on getting data from ack/nack csv file from  DTCC  
 *  receives job Execution which contains list of ack/nack details,
 *  nack details are stored in etd_exception table and updates etd_trade_jurisdiction table with status information,
 *   prepares response to be sent to front office with nack/ack information 
 *  received from DTCC, uses etd_response_flow etdResHeaderEnrichChannel to send response to front 
 *  office system  </p>
 */
public class EtdDtccResponseProcessor
{

	private EtdTradeJurisdictionDao etdTradeJurisdictionDao;
	private Marshaller marshaller;

	@SuppressWarnings("unused")
	private Unmarshaller unmarshaller;
	private String tempFileLoc;
	private MessageChannel errorChannel;
	private MessageChannel etdResHeaderEnrichChannel;

	private static Logger logger = Logger.getLogger(SdrRequestParser.class.getName());

	@SuppressWarnings("unchecked")
	public void process(Message<?> message) throws EtdMessageException
	{
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdDtccResponseProcessor);		

		logger.info("inside EtdDtccResponseProcessor: process method");
		String errorString = null;
		Object ipMessage = null;
		String origPayload = null;
		JobExecution currJobExecution = null;
		ExitStatus currExitStatus = null;
		List<DtccEtdResponseMessage> dtccEtdResponseMessageList = null;
		String etdTradeJurisdictionId = null;
		String sdrMessageId = null;
		long dataSubmitterMessageID = 0;
		EtdTradeJurisdiction etdTradeJurisdiction = null;
		Date currDate = new Date();
		SdrResponse sdrResponse = null;
		String nackResponseString = null;
		String[] dtccNackRespStrArray = null;

		if (null == message)
		{
			errorString = "Null incoming message in EtdDtccResponseProcessor  process method";
			logger.error("########## " + errorString);
		}

		ipMessage = message.getPayload();

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
			// to do prepare file using string payload
		}
		else if (ipMessage instanceof JobExecution)
		{
			currJobExecution = (JobExecution) ipMessage;
			currExitStatus = currJobExecution.getExitStatus();

			if (currExitStatus.getExitCode().equalsIgnoreCase("EXECUTING"))
			{
				logger.info(" Etd Dtcc response Batch job is still running ");

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("COMPLETED"))
			{
				logger.info(" Etd Dtcc response procesing Batch job finished successfully ");
				dtccEtdResponseMessageList = (List<DtccEtdResponseMessage>) currJobExecution.getExecutionContext().get(EtdConstants.DTTC_RESPONSE_MESSAGE_LIST);
				if (null != dtccEtdResponseMessageList)
				{
					for (DtccEtdResponseMessage currDtccEtdResponseMessage : dtccEtdResponseMessageList)
					{
						etdTradeJurisdictionId = currDtccEtdResponseMessage.getDataSubmitterMessageID();
						if (null != etdTradeJurisdictionId && StringUtils.isNotEmpty(etdTradeJurisdictionId))
						{
							try
							{
								dataSubmitterMessageID = Long.parseLong(etdTradeJurisdictionId);

								etdTradeJurisdiction = etdTradeJurisdictionDao.findByPrimaryKey(dataSubmitterMessageID);
								
							}
							catch(Exception e)
							{
								errorString = "Exception occurred while getting data submitter ID : " + e.getMessage() ;
								logger.error("########## " + errorString);

								throw new EtdMessageException("EtdDtccRsp:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
								
								
							}
							
							if (null != etdTradeJurisdiction)
							{
								logger.info(" retrieved EtdTradeJurisdiction record for datasubmitter message Id " + dataSubmitterMessageID);
								sdrResponse = new SdrResponse();
								sdrResponse.setFoMessageId(etdTradeJurisdiction.getSourceSystemMessageId());
								sdrResponse.setFoSystem(EtdConstants.ETD_FO_SYSTEM);
								sdrResponse.setSdrSystem(EtdConstants.ETD_RPT_REPOSITORY);
								try
								{
									GregorianCalendar gc = new GregorianCalendar();
									gc.setTimeInMillis(currDate.getTime());
									DatatypeFactory df = DatatypeFactory.newInstance();
									XMLGregorianCalendar xg = df.newXMLGregorianCalendar(gc);
									sdrResponse.setResponseTimestamp(xg);

								}
								catch (Exception exp)
								{
									errorString = "Error while preparing XMLGregorianCalendar date for response message";
									logger.debug("########## " + errorString);

								}

								EtdPayload currEtdPayload = null;
								currEtdPayload = etdTradeJurisdiction.getEtdPayload();
								if (null != currEtdPayload)
								{
									sdrMessageId = currEtdPayload.getMessageId();
									sdrResponse.setSdrMessageId(sdrMessageId);

								}
								AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(sdrMessageId));

								List<MessageType> messageTypeList = new ArrayList<MessageType>();

								if (currDtccEtdResponseMessage.getDtccResponseType().equalsIgnoreCase(EtdConstants.DTTC_RESPONSE_ACK))
								{

									etdTradeJurisdiction.setState(EtdConstants.ETD_TRADE_STATE_FROM_DTCC);
									etdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_ACCEPTED);
									etdTradeJurisdiction.setUpdateDatetime(currDate);

									etdTradeJurisdictionDao.saveOrUpdate(etdTradeJurisdiction);

									sdrResponse.setResponseCode(EtdConstants.ETD_ACK);

								}
								else if (currDtccEtdResponseMessage.getDtccResponseType().equalsIgnoreCase(EtdConstants.DTTC_RESPONSE_NACK))
								{
									etdTradeJurisdiction.setState(EtdConstants.ETD_TRADE_STATE_FROM_DTCC);
									etdTradeJurisdiction.setSubmissionStatus(EtdConstants.ETD_TRADE_STATUTUS_REJECTED);
									etdTradeJurisdiction.setUpdateDatetime(currDate);

									etdTradeJurisdictionDao.saveOrUpdate(etdTradeJurisdiction);

									sdrResponse.setResponseCode(EtdConstants.ETD_NACK);
									
									String nackResponseDelim = "[,]";

									// example response string -
									// "ETD0706-Trade Party1 is invalid","ETD0748-Accounts are same for both the trade parties"
									nackResponseString = currDtccEtdResponseMessage.getErrorCodeAndReason();
									if (null != nackResponseString)
									{
										dtccNackRespStrArray = nackResponseString.split(nackResponseDelim);
										String currNackRespWithErrorCode = null;
										String currNackErrorCode = null;
										String nackNackErrorString = null;
										for (int i = 0; i < dtccNackRespStrArray.length; i++)
										{

											currNackRespWithErrorCode = dtccNackRespStrArray[i];
											if (null != currNackRespWithErrorCode)
											{
												currNackErrorCode = StringUtils.substringBefore(currNackRespWithErrorCode, EtdConstants.ETD_DTCC_NACK_ERRORCODE_SEPARATOR);
												nackNackErrorString = StringUtils.substringAfter(currNackRespWithErrorCode, EtdConstants.ETD_DTCC_NACK_ERRORCODE_SEPARATOR);
												MessageType currMessageType = new MessageType();
												currMessageType.setValue(currNackErrorCode);
												currMessageType.setDescription(nackNackErrorString);

												messageTypeList.add(currMessageType);
												errorString = "Nack response sent by Dtcc with error code: " + currNackErrorCode + " and failure reason:  " + nackNackErrorString;

												dispatchException(message, sdrMessageId, errorString, "EtdDtccRsp:2", ExceptionSeverityEnum.ERROR);
											}

										}

									}
									sdrResponse.getMessage().addAll(messageTypeList);
									if (sdrResponse != null)
									{
										try
										{
											String respXml = prepareResponse(sdrResponse);

											if (respXml != null)
											{
												Message<String> responseMessage = null;
												responseMessage = MessageBuilder.withPayload(respXml).copyHeaders(message.getHeaders()).build();

												etdResHeaderEnrichChannel.send(responseMessage);

												logger.info("published Dtcc nack response details to front office ");
											}

											logger.info("etd dtcc response xml : " + respXml);
										}
										catch (Exception e)
										{
											errorString = "Exception occurred while parsing dtcc etd nack response : " + e.getMessage();
											logger.error("########## " + errorString);

											throw new EtdMessageException("EtdDtccRsp:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

										}

									}

								}
								else
								{
									logger.info(" received invalid response type from DTCC or response type is null ");
								}

							}
							else
							{
								logger.info(" no record exists in EtdTradeJurisdiction for datasubmitter message Id " + dataSubmitterMessageID);
							}

						}

					}

				}

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("FAILED"))
			{
				errorString = currJobExecution.getStepExecutions().toString();
				logger.error(" Batch job Failed " + currJobExecution.getStepExecutions().toString());
				throw new EtdMessageException("EtdDtccRsp:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

			}

		}

		logger.info("exiting EtdDtccResponseProcessor: process method");

	}

	/**
	 * @param message
	 * @param sdrMessageId
	 * @param errorString
	 */
	private void dispatchException(Message<?> message, String sdrMessageId, String errorString, String errorCode, ExceptionSeverityEnum severity)
	{

		EtdMessageException currMessageException = null;
		Message<EtdMessageException> excWrapper = null;

		logger.debug("Entering dispatchException for etd dtcc nack response : " + errorString);

		currMessageException = new EtdMessageException(errorCode, severity, ExceptionTypeEnum.ETD_ERROR, errorString, sdrMessageId);
		excWrapper = MessageBuilder.withPayload(currMessageException).copyHeaders(message.getHeaders()).build();

		errorChannel.send(excWrapper);

		logger.debug("Exiting etd dispatchException for : " + errorString);
	}

	/**
	 * converts RegRepResponse object into response xml
	 *
	 * @param regRepResponse
	 * @return
	 * @throws Exception
	 */
	private String prepareResponse(SdrResponse sdrResponse) throws Exception
	{
		String response = null;
		String fileName = Constants.REG_REP_TEMP + Constants.UNDERSCORE + "EtdDtccResponseProcessor"  + Constants.UNDERSCORE + (new Date()).getTime();

		File tempFile = new File(tempFileLoc + File.separator + fileName);

		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(tempFile);

			marshaller.marshal(sdrResponse, new StreamResult(fos));
			
			Scanner respScanner = new Scanner(tempFile);			
			response = respScanner.useDelimiter("\\Z").next();
			respScanner.close();			

		}
		catch (Exception exp)
		{
			throw exp;
		}
		finally
		{
			if (fos != null)
			{
				fos.close();
			}

			tempFile.delete();
		}

		return response;
	}

	public String getTempFileLoc()
	{
		return tempFileLoc;
	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

	public void setMarshaller(Marshaller marshaller)
	{
		this.marshaller = marshaller;
	}

	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}

	public void setErrorChannel(MessageChannel errorChannel)
	{
		this.errorChannel = errorChannel;
	}

	public void setEtdTradeJurisdictionDao(EtdTradeJurisdictionDao etdTradeJurisdictionDao)
	{
		this.etdTradeJurisdictionDao = etdTradeJurisdictionDao;
	}

	public void setEtdResHeaderEnrichChannel(MessageChannel etdResHeaderEnrichChannel)
	{
		this.etdResHeaderEnrichChannel = etdResHeaderEnrichChannel;
	}

}
