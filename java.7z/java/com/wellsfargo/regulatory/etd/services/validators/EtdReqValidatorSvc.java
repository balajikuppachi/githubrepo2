package com.wellsfargo.regulatory.etd.services.validators;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.beans.ValidationResult;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.core.rules.util.KieSessionFactory;

/**
 * 
 * @author Raji Komatreddy
 *  
 * <p> Validates input etd sdr request using rules defined in drools files,
 *     as of now only mandatory fields check was performed </p>
 *
 */

@Component
public class EtdReqValidatorSvc
{
	private static Logger logger = Logger.getLogger(EtdReqValidatorSvc.class.getName());

	@Value("${regRep.esmaL2.validations.enabled}")
	String esmaL2ValidationFlag ;

	public Message<?> validate(Message<?> message) throws EtdMessageException
	{
		logger.debug("Entering EtdReqValidatorSvc: validate() method");

		if (null == message) return message;

		ReportingContext context 	= (ReportingContext) message.getPayload();
		String messageId 			= context.getMessageId();
		
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdReqValidatorSvc);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(context.getMessageId()));

		try
		{
			//KieServices kieServices 	= KieServices.Factory.get();
			//KieContainer kieContainer 	= kieServices.getKieClasspathContainer();
			//KieSession kieSession 		= kieContainer.newKieSession("etdReqValKsession");

			KieSession etdReqValKsession_1 = KieSessionFactory.getKieSession("etdReqValKsession");
			etdReqValKsession_1.insert(context);
			etdReqValKsession_1.setGlobal("logger", logger);
			Agenda agenda = etdReqValKsession_1.getAgenda(); /*** All rules placed under commonAgenda will be executed first ***/
			//agenda.getAgendaGroup("etdCollateralAgenda").setFocus();
			//agenda.getAgendaGroup("etdTransactionAndPositionAgenda").setFocus();
			agenda.getAgendaGroup("etdcommonAgenda").setFocus();
			etdReqValKsession_1.fireAllRules();
			etdReqValKsession_1.dispose();
			
			logger.debug(" Initialized rulesResultsContext and created msgType in context " + context);

			
			//KieSession Ksession2 = kieContainer.newKieSession("etdReqValKsession");
			KieSession etdReqValKsession_2 = KieSessionFactory.getKieSession("etdReqValKsession");
			etdReqValKsession_2.insert(context);
			etdReqValKsession_2.setGlobal("logger", logger);
			Agenda agenda2 = etdReqValKsession_2.getAgenda();
			agenda2.getAgendaGroup("etdCollateralAgenda").setFocus();
			agenda2.getAgendaGroup("etdTransactionAndPositionAgenda").setFocus();
			etdReqValKsession_2.fireAllRules();
			etdReqValKsession_2.dispose();
			
			
			/*** START : Testing purpose Only ****/
			if (context.getRulesResultsContext() != null)
			{
				List<ValidationResult> validationResultList = context.getRulesResultsContext().getAlertValidationResultList();

				if (validationResultList != null)
				{
					for (ValidationResult currValidationResult : validationResultList)
					{
						logger.debug("Validation results are: " + currValidationResult.toString());
					}
				}
			}
			/*** END : Testing purpose Only ****/
		}
		catch (Exception e)
		{
			logger.error("########## Unable to validate Etd request ", e);
			
			throw new EtdMessageException("etdVldtr:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, e.getMessage(), messageId, e);
		}

		logger.debug("EtdReqValidatorSvc: validate()  method");

		return message;
	}

}
