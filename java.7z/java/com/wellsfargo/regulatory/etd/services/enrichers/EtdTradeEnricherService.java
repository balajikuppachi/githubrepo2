package com.wellsfargo.regulatory.etd.services.enrichers;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

/**
 * @author Raji Komatreddy
 * 
 * place holder to enrich trade data 
 * 
 */
@Component
public class EtdTradeEnricherService
{
	private static Logger logger = Logger.getLogger(EtdTradeEnricherService.class.getName());

	public Message<?> enrich(Message<?> message) throws EtdMessageException
	{
		logger.info("Inside EtdTradeEnricherService persist method");
		ReportingContext context = null;
		SdrRequest sdrRequest = null;
		TradeType trade = null;
		RegulatoryType regulatory = null;
		TradeHeaderType tradeHeader = null;
		String processingOrgLei = null;
		String counterPartylei = null;
		String intraGroupFlag = null;
		String errorString = null;
		String sdrMessageId = null;

		if (null == message)
		{
			errorString = "Null incoming message";
			logger.error("message received as null inside EtdDtccReportMapper: ");
			throw new EtdMessageException("etdTradeEnrich-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		context = (ReportingContext) message.getPayload();
		if (null == context)
		{
			logger.error("payload received is not of ReportingContext type inside EtdDtccReportMapper: ");
			return message;
		}
		try
		{
			sdrRequest = context.getSdrRequest();
			sdrMessageId = context.getMessageId();
			
			AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdTradeEnricherService);
			AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(sdrMessageId));
			
			if (null != sdrRequest)
			{
				trade = sdrRequest.getTrade();
				if (null != trade) tradeHeader = trade.getTradeHeader();

			}

			if (null != tradeHeader)
			{
				processingOrgLei = tradeHeader.getProcessingOrgLEI();
				counterPartylei = tradeHeader.getCounterpartyLEI();
				regulatory = trade.getRegulatory();

			}

			intraGroupFlag = StringUtils.equalsIgnoreCase(processingOrgLei, counterPartylei) ? EtdConstants.ETD_TRUE : EtdConstants.ETD_FALSE;

			if (null == regulatory && null != trade)
			{
				regulatory = new RegulatoryType();
				trade.setRegulatory(regulatory);
			}

			// adding calculated dtcc output message as keyword to RequlaoryType
			ReportingDataUtils.addKeyword(regulatory, EtdConstants.ETD_INTRAGROUP_FLAG, intraGroupFlag);

			logger.info("exiting EtdTradeEnricherService persist method");

		}
		catch (Exception exp)
		{
			errorString = "exception occurred while while enriching the trade: EtdTradeEnricherService:  " + ExceptionUtils.getFullStackTrace(exp);
			logger.error("########## " + errorString);
			
			throw new EtdMessageException("etdTradeEnrich-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString,sdrMessageId);

		}

		return message;

	}

}
