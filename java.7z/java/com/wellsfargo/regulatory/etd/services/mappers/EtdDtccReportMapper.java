package com.wellsfargo.regulatory.etd.services.mappers;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.BuySellEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ClearingType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.CommodityTermsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.DocumentationType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ExerciseProvisionType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.FixedFloatEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.KeywordsType.Keyword;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LegType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.LifeCycleType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.OptionTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductKeysType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ProductType.UnderlyingAsset;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.RegulatoryType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.ReportingEligibilityType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SettlementTypeEnum;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeDetailType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeHeaderType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartiesType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradePartyType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.TradeType;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.UsThemEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.bo.dtcc.ETDDtccTemplate;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;
import com.wellsfargo.regulatory.etd.services.parsers.ETDDtccTemplateParser;

/**
 * @author Raji Komatreddy populates data from SDRRequest to ETDDtccTemplate object
 */

@Component
public class EtdDtccReportMapper
{
	@Autowired
	private ETDDtccTemplateParser eTDDtccTemplateParser;

	private static Logger logger = Logger.getLogger(EtdDtccReportMapper.class.getName());

	public Message<?> map(Message<?> message) throws EtdMessageException
	{
		logger.info("inside EtdDtccReportMapper: map method");

		ReportingContext context 					= null;
		SdrRequest sdrRequest 						= null;
		TradeHeaderType tradeHeader 				= null;
		TradeType trade 							= null;
		TradeDetailType tradeDetail 				= null;
		LifeCycleType lifeCycle 					= null;
		ProductType product 						= null;
		ProductKeysType productKeys 				= null;
		KeywordsType productkeywords 				= null;
		TradePartiesType tradeParties 				= null;
		List<TradePartyType> tradePartyLsit 		= null;
		TradePartyType processingOrgTradeParty 		= null;
		TradePartyType counterpartyTradeParty 		= null;
		//LegType leg = null;
		//LegType leg2 = null;
		RegulatoryType regulatory 					= null;
		ReportingEligibilityType reportingEligibility = null;
		String dtccOutMsg 							= null;
		String dtccOutMsgCompression 				= null;
		Boolean party1FcmIndicator 					= false;
		Boolean party2FcmIndicator 					= false;
		Boolean isPosition 							= false;
		String positionAsOfDateString 				= null;
		String submittedFor 						= null;
		String party1LeiPrefix 						= null;
		String party1LeiValue 						= null;
		String party2LeiPrefix 						= null;
		String party2LeiValue 						= null;
		String brokerLeiParty1Prefix 				= null;
		String brokerLeiParty1Value 				= null;
		String brokerLeiParty2Prefix 				= null;
		String brokerLeiParty2Value 				= null;
		String clearingBrokerparty1LEIPrefix 		= null;
		String clearingBrokerparty1LEIValue 		= null;
		String clearingBrokerparty2LEIPrefix 		= null;
		String clearingBrokerparty2LEIValue 		= null;
		String executionAgentparty1LEIPrefix 		= null;
		String executionAgentparty1LEIValue 		= null;
		String executionAgentparty2LEIPrefix 		= null;
		String executionAgentparty2LEIValue 		= null;
		String beneficiaryIdparty1LEIPrefix 		= null;
		String beneficiaryIdparty1LEIValue 			= null;
		String beneficiaryIdparty2LEIPrefix 		= null;
		String beneficiaryIdparty2LEIValue 			= null;
		String financingParty1 						= EtdConstants.ETD_FALSE;
		String financingParty2 						= EtdConstants.ETD_FALSE;
		String party1TaxonomyPrefix 				= null;
		String party1Taxonomyvalue 					= null;
		String party2TaxonomyPrefix 				= null;
		String party2Taxonomyvalue 					= null;
		ClearingType clearing 						= null;
		ExerciseProvisionType exerciseProvisionType = null;
		String intraGroupFlag 						= null;
		KeywordsType keywords 						= null;
		String sdrMessageId 						= null;
		String errorString 							= null;
		Boolean emirDirectlyLinked 					= false;
		String msgType 								= EtdConstants.ETD_MSG_TRANSACTION;
		String etdIndicator 						= EtdConstants.ETD_TRUE;
		String settlementType 						= null;
		String delegatedReporting 					= null;
		String action 								= null;
		String actionType 							= null;
		String assetClass 							= null;
		DocumentationType documentationType 		= null;
				
		if (null == message)
		{
			logger.error("message received as null inside EtdDtccReportMapper: ");
			return message;
		}

		context = (ReportingContext) message.getPayload();
		if (null == context)
		{
			logger.error("payload received is not of ReportingContext type inside EtdDtccReportMapper: ");
			return message;
		}

		sdrRequest 		= context.getSdrRequest();
		sdrMessageId 	= context.getMessageId();

		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_COMPONENT, AbstractDriver.EtdDtccReportMapper);
		AbstractDriver.addThreadInformation(AbstractDriver.MDC_KEY_GUUID, StringUtils.trimToEmpty(sdrMessageId));
		
		if (null != sdrRequest)
		{
			trade 		= sdrRequest.getTrade();
			tradeHeader = trade.getTradeHeader();
			tradeDetail = trade.getTradeDetail();
		}

		ETDDtccTemplate currETDDtccTemplate 		= new ETDDtccTemplate();
		ETDDtccTemplate compressionETDDtccTemplate 	= new ETDDtccTemplate();

		currETDDtccTemplate.setVersion(EtdConstants.ETD_TEMPLATE_VERSION);

		assetClass = sdrRequest.getAssetClass();
		currETDDtccTemplate.setPrimaryAssetClass(assetClass);
		currETDDtccTemplate.setTransactionType(EtdConstants.ETD_GTR_TRANSACTION_TYPE);

		if (tradeHeader != null)
		{
			try
			{
				lifeCycle 		= tradeHeader.getLifeCycle();
				party1LeiPrefix = StringUtils.substringBefore(tradeHeader.getProcessingOrgLEI(), Constants.COLON);
				party1LeiValue 	= StringUtils.substringAfter(tradeHeader.getProcessingOrgLEI(), Constants.COLON);
				party2LeiPrefix = StringUtils.substringBefore(tradeHeader.getCounterpartyLEI(), Constants.COLON);
				party2LeiValue 	= StringUtils.substringAfter(tradeHeader.getCounterpartyLEI(), Constants.COLON);

				isPosition = tradeHeader.isIsPosition();
				if (null != isPosition) msgType = isPosition ? EtdConstants.ETD_MSG_POSITION : EtdConstants.ETD_MSG_TRANSACTION;

				currETDDtccTemplate.setMsgType(msgType);

				// if (msgType.equalsIgnoreCase(EtdConstants.ETD_MSG_TRANSACTION))
				// currETDDtccTemplate.setLifecycleEvent("New");
				// if (msgType.equalsIgnoreCase(EtdConstants.ETD_MSG_POSITION))
				// currETDDtccTemplate.setLifecycleEvent("EOD");
				
				currETDDtccTemplate.setEffectiveDate(CalendarUtils.xmlGregCalToCustomFormat(tradeHeader.getTradeDate(), null));
				
				if (null != tradeHeader.getPositionAsOfDate())
				{
					positionAsOfDateString = CalendarUtils.xmlGregCalToUtcFormat(tradeHeader.getPositionAsOfDate());
					currETDDtccTemplate.setAsofDateTime(positionAsOfDateString);
				}

				action = tradeHeader.getAction();
				currETDDtccTemplate.setAction(action);
				
				if(StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_TRANSACTION))
				{
					if(StringUtils.equalsIgnoreCase(action, EtdConstants.ETD_ACTION_NEW))
					{
						actionType = EtdConstants.ETD_ACTION_TYPE_N;
					}
					else if(StringUtils.equalsIgnoreCase(action, EtdConstants.ETD_ACTION_CANCEL))
					{
						actionType = EtdConstants.ETD_ACTION_TYPE_C;
					}
					else if(StringUtils.equalsIgnoreCase(action, EtdConstants.ETD_ACTION_MODIFY))
					{
						actionType = EtdConstants.ETD_ACTION_TYPE_M;
					}
				}
				
				currETDDtccTemplate.setActionTypeParty1(actionType);
				/*currETDDtccTemplate.setActionTypeParty2(actionType);*/
				
				
				if(StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_TRANSACTION) 
						&& (StringUtils.equalsIgnoreCase(currETDDtccTemplate.getActionTypeParty1(), EtdConstants.ETD_ACTION_TYPE_C)
								|| StringUtils.equalsIgnoreCase(currETDDtccTemplate.getActionTypeParty2(), EtdConstants.ETD_ACTION_TYPE_C)))
				{
					currETDDtccTemplate.setTerminationDate(CalendarUtils.xmlGregCalToCustomFormat(lifeCycle.getEventExecutionDateTime(), null));
				}
				
				if (null != lifeCycle)
				{
					String compressionString 		= null;
					Boolean compression 			= false;
					String mandatoryclearingJuris 	= null;
					Boolean clearingStatus 			= false;
					
					// currETDDtccTemplate.setTransactionType(lifeCycle.getEventType());
					
					if(StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_POSITION) || StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_TRANSACTION))
					{
						currETDDtccTemplate.setLifecycleEvent(lifeCycle.getEventType());	
					}
					
					clearing = lifeCycle.getClearing();
					if (null != clearing)
					{
						clearingStatus = clearing.isClearedTrade();

						if (null != clearingStatus) 
							currETDDtccTemplate.setCleared(clearing.isClearedTrade().toString());

						currETDDtccTemplate.setClearingTimestamp(CalendarUtils.convertXmlGregCalToUtcFormat(clearing.getClearedDateTime()));
						currETDDtccTemplate.setClearingDCOPrefix(StringUtils.substringBefore(clearing.getClearingHouseLEI(), Constants.COLON));
						currETDDtccTemplate.setClearingDCOValue(StringUtils.substringAfter(clearing.getClearingHouseLEI(), Constants.COLON));

						mandatoryclearingJuris = clearing.getMandatoryClearingIndicator();
						if (null != mandatoryclearingJuris)
						{
							// valid values for this "ESMA-Y","ESMA-N","ESMA-X"
							// -- todo which one to
							// use
							if (mandatoryclearingJuris.equalsIgnoreCase(EtdConstants.ESMA_RPT_JURISDICTION)) mandatoryclearingJuris = mandatoryclearingJuris + "-N";
							currETDDtccTemplate.setMandatoryClearingIndicator(mandatoryclearingJuris);
						}
					}
					
					compressionString = lifeCycle.getPortfolioCompression();
					if (null != compressionString && compressionString.equalsIgnoreCase(EtdConstants.ETD_TRUE)) compression = Boolean.TRUE;
					currETDDtccTemplate.setCompression(compression.toString());
				}

				currETDDtccTemplate.setParty1Prefix(party1LeiPrefix);
				currETDDtccTemplate.setParty1Value(party1LeiValue);
				currETDDtccTemplate.setParty2Prefix(party2LeiPrefix);
				currETDDtccTemplate.setParty2Value(party2LeiValue);
				
				currETDDtccTemplate.setTransactionReferenceID(tradeHeader.getTradeId());
				currETDDtccTemplate.setExecutionVenuePrefix(tradeHeader.getExecutionVenuePrefix());
				currETDDtccTemplate.setExecutionVenueValue(tradeHeader.getExecutionVenue());
				
				if (StringUtils.isNotBlank(tradeHeader.getExecutionVenue()) && tradeHeader.getExecutionVenue().equalsIgnoreCase(EtdConstants.ETD_XOFF_EXECUTION_VENUE))
				{
					currETDDtccTemplate.setETDIndicator(EtdConstants.ETD_FALSE);
				}
				else
				{
					// always set ETD indicator as true
					currETDDtccTemplate.setETDIndicator(etdIndicator.toLowerCase());
				}

				currETDDtccTemplate.setExecutionTimestamp(CalendarUtils.convertXmlGregCalToUtcFormat(tradeHeader.getExecutionDateTime()));

				if (null != tradeHeader.getConfirmationMethod()) currETDDtccTemplate.setConfirmationType(tradeHeader.getConfirmationMethod().value());
				if (null != tradeHeader.getConfirmationDateTime()) currETDDtccTemplate.setConfirmationDateTime(CalendarUtils.convertXmlGregCalToUtcFormat(tradeHeader.getConfirmationDateTime()));
			}
			catch (Exception exp)
			{
				errorString = "Exception occurred while mapping data from tradeHeader to ETD template " + ExceptionUtils.getFullStackTrace(exp);
				logger.error("########## " + errorString);
				throw new EtdMessageException("EtdRptMapper:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString, sdrMessageId);
			}
		}

		if (null != tradeDetail)
		{
			try
			{
				product = tradeDetail.getProduct();
				
				if (null != product)
				{
					productKeys 		= product.getProductKeys();
					productkeywords 	= product.getKeywords();
					
					if (null != productKeys) 
						currETDDtccTemplate.setUTIValue(productKeys.getUTI());

					if (null != product.getBuySell())
					{
						if (product.getBuySell().toString().equalsIgnoreCase(BuySellEnum.BUY.value()))
						{
							currETDDtccTemplate.setBuyerPrefixParty1(party1LeiPrefix);
							currETDDtccTemplate.setBuyerValueParty1(party1LeiValue);
						}
						else if (product.getBuySell().toString().equalsIgnoreCase(BuySellEnum.SELL.value()))
						{
							currETDDtccTemplate.setBuyerPrefixParty1(party2LeiPrefix);
							currETDDtccTemplate.setBuyerValueParty1(party2LeiValue);
						}
					}
					
					List<LegType> legs = product.getLeg();
					
					if(null != legs && !legs.isEmpty())
					{
						for (LegType leg : legs) 
						{
							if (leg.getLegId() == 0)
							{
								if(StringUtils.equalsIgnoreCase(assetClass, EtdConstants.RATE_ASSETCLASS))
								{
									/*For ETD there are scenarios where both fixed and float fields are populated on the same leg.  */
									/*if (null != leg.getFixedFloat() && StringUtils.equalsIgnoreCase(leg.getFixedFloat().value(), FixedFloatEnum.FIXED.value()))*/
									{
										if (null != leg.getFixedRate())
										{
											currETDDtccTemplate.setFixedrateofleg1(leg.getFixedRate().toString());
										}
										if(null != leg.getDayCountFraction())
										{
											currETDDtccTemplate.setFixedratedaycount(leg.getDayCountFraction());
										}
										if(null != leg.getPaymentFrequency())
										{
											currETDDtccTemplate.setFixedlegpaymentfrequency(leg.getPaymentFrequency());
										}
									}
									
									/*if (null != leg.getFixedFloat() && StringUtils.equalsIgnoreCase(leg.getFixedFloat().value(), FixedFloatEnum.FLOAT.value()))*/
									{
												
										String indexTenor = "";
										if(null != leg.getIndexTenor()) 
											indexTenor = leg.getIndexTenor();
										
										String indexName = "";
										if(null != leg.getIndexName()) 
											indexName = leg.getIndexName();
										
										if(StringUtils.isNotBlank(indexName) || StringUtils.isNotBlank(indexTenor))
										{
											currETDDtccTemplate.setFloatingrateofleg1(indexTenor + "" + indexName);
										}
										if(null != leg.getResetFrequency())
										{
											currETDDtccTemplate.setFloatingrateresetfrequency(leg.getResetFrequency());
										}
										if(null != leg.getFloatPaymentFrequency())
										{
												currETDDtccTemplate.setFloatingratepaymentfrequency(leg.getFloatPaymentFrequency());
										}
									}
								}
								
								if(StringUtils.equalsIgnoreCase(assetClass, EtdConstants.FX_ASSETCLASS))
								{
									if (null != leg.getSettlementCurrency() && null != leg.getCurrency())
									{
										String settlementCurr 	= leg.getSettlementCurrency();
										String currency 		= leg.getCurrency();
										currETDDtccTemplate.setExchangeRateBasis(settlementCurr+ "/" +currency);
									}
									
									if (null != leg.getCurrency())
									{	
										currETDDtccTemplate.setCurrency2(leg.getCurrency());
									}
									
									if (null != leg.getFixedRate())
									{
										currETDDtccTemplate.setExchangeRate1(leg.getFixedRate().toString());
									}
									
								}
								
								currETDDtccTemplate.setNotionalCurrencyUnits(leg.getNotionalCurrency());
								currETDDtccTemplate.setSettlementCurrency(leg.getSettlementCurrency());

								if (null != leg.getPriceMultiplier())
								{
									currETDDtccTemplate.setPriceMultiplier(leg.getPriceMultiplier().toString());
								}

								if (null != leg.getPrice()) 
									currETDDtccTemplate.setPriceNotationPrice(leg.getPrice().toString());
								
								if(StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_TRANSACTION))
								{
									currETDDtccTemplate.setPriceNotationPriceType(null != leg.getPriceType() ? leg.getPriceType().value() : "Price");
								}
								
								currETDDtccTemplate.setQuantityUnit(leg.getQuantityUnit());
								
								if (null != leg.getNotional()) 
									currETDDtccTemplate.setNotionalAmount(leg.getNotional().toString());
								
								currETDDtccTemplate.setNotionalCurrencyUnits(leg.getNotionalCurrency());

								if (null != leg.getTotalQuantity()) 
									currETDDtccTemplate.setQuantity(leg.getTotalQuantity().toString());

								if (null != leg.getSettlementType())
								{
									if (leg.getSettlementType().compareTo(SettlementTypeEnum.CASH) == 0)
									{
										settlementType = "C";
									}
									else if (leg.getSettlementType().compareTo(SettlementTypeEnum.PHYSICAL) == 0)
									{
										settlementType = "P";
									}
									else
									{
										settlementType = "O";
									}
								}
								
								
								currETDDtccTemplate.setDeliverytype(settlementType);
								//currETDDtccTemplate.setEffectiveDate(CalendarUtils.xmlGregCalToCustomFormat(leg.getStartDate(), null));
								currETDDtccTemplate.setScheduledTerminationDate(CalendarUtils.xmlGregCalToCustomFormat(leg.getEndDate(), null));
								currETDDtccTemplate.setDateofSettlement(CalendarUtils.xmlGregCalToCustomFormat(leg.getSettlementDate(), null));

								if (null != leg.getOptionType())
								{
									if (leg.getOptionType().compareTo(OptionTypeEnum.CALL) == 0)
									{
										currETDDtccTemplate.setOptionType(EtdConstants.ETD_OPTION_CALL);
									}
									else if (leg.getOptionType().compareTo(OptionTypeEnum.PUT) == 0)
									{
										currETDDtccTemplate.setOptionType(EtdConstants.ETD_OPTION_PUT);
									}
								}

								if (null != leg.getOptionStrike()) 
									currETDDtccTemplate.setOptionStrikePrice(leg.getOptionStrike().toString());
								
								currETDDtccTemplate.setOptionStrikePriceCCY(leg.getOptionStrikeCurrency());
							}
							
							if (leg.getLegId() == 1)
							{
								if(StringUtils.equalsIgnoreCase(assetClass, EtdConstants.RATE_ASSETCLASS))
								{
									/*	if (null != leg.getFixedFloat() && StringUtils.equalsIgnoreCase(leg.getFixedFloat().value(), FixedFloatEnum.FIXED.value()))*/
									{
										if (null != leg.getFixedRate())
										{
											currETDDtccTemplate.setFixedrateofleg2(leg.getFixedRate().toString());
										}
									}
										
									/*if (null != leg.getFixedFloat() && StringUtils.equalsIgnoreCase(leg.getFixedFloat().value(), FixedFloatEnum.FLOAT.value()))*/
									{
										String indexTenor = "";
										if(null != leg.getIndexTenor()) 
											indexTenor = leg.getIndexTenor();
											
										String indexName = "";
										if(null != leg.getIndexName()) 
											indexName = leg.getIndexName();
										if(StringUtils.isNotBlank(indexName) || StringUtils.isNotBlank(indexTenor))
										{
											currETDDtccTemplate.setFloatingrateofleg2(indexTenor + " " + indexName);
										}
									}
									
								}
															
							}
						}
					}
					
					exerciseProvisionType = product.getExerciseProvision();
					if (null != exerciseProvisionType)
					{
						if (null != exerciseProvisionType.getExerciseType()) currETDDtccTemplate.setOptionStyle(exerciseProvisionType.getExerciseType().value());
					}

					if (null != productkeywords)
					{
						List<Keyword> productkeyworkList = productkeywords.getKeyword();
						for (Keyword currKeyword : productkeyworkList)
						{
							if (currKeyword.getName().equalsIgnoreCase(EtdConstants.ETD_PRODUCTID1))
							{
								party1TaxonomyPrefix 	= StringUtils.substringBefore(currKeyword.getValue(), Constants.COLON);
								party1Taxonomyvalue 	= StringUtils.substringAfter(currKeyword.getValue(), Constants.COLON);
								
								currETDDtccTemplate.setProductIDPrefix1(party1TaxonomyPrefix);
								currETDDtccTemplate.setProductIDValue1(party1Taxonomyvalue);
								
								/*if(StringUtils.equalsIgnoreCase(party1Taxonomyvalue, "CU")){
									if(StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_TRANSACTION) 
											|| StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_POSITION)){
										currETDDtccTemplate.setCurrency2("XXX");
									}
								}*/
								
								if(StringUtils.equalsIgnoreCase(party1TaxonomyPrefix, "E"))
								{
									currETDDtccTemplate.setETDIndicator(EtdConstants.ETD_FALSE);
								}
							}
							
							if (currKeyword.getName().equalsIgnoreCase(EtdConstants.ETD_PRODUCTID2))
							{
								party2TaxonomyPrefix 	= StringUtils.substringBefore(currKeyword.getValue(), Constants.COLON);
								party2Taxonomyvalue 	= StringUtils.substringAfter(currKeyword.getValue(), Constants.COLON);
								
								//currETDDtccTemplate.setProductIDPrefix2(party2TaxonomyPrefix);
								currETDDtccTemplate.setProductIDPrefix2(EtdConstants.BLANK);
								currETDDtccTemplate.setProductIDValue2(party2Taxonomyvalue);
							}
						}
					}
					
					UnderlyingAsset underlyingAsset = product.getUnderlyingAsset();
					if(null != underlyingAsset)
					{
						currETDDtccTemplate.setUnderlyingAsset(underlyingAsset.getAssetValue());	
						
						if(null != underlyingAsset.getAssetType())
						{
							currETDDtccTemplate.setUnderlyingAssetIdentifierType(underlyingAsset.getAssetType().value());	
						}
					}
					
					CommodityTermsType commodityTermsType = product.getCommodityTerms();
					if(null != commodityTermsType)
					{
						currETDDtccTemplate.setCommodityBase(commodityTermsType.getCommodityType());
						currETDDtccTemplate.setCommodityDetails(commodityTermsType.getCommodityTypeDetail());
						currETDDtccTemplate.setDeliveryPointorZone(commodityTermsType.getDeliveryPoint());
						currETDDtccTemplate.setInterConnectionPoint(commodityTermsType.getInterconnectionPoint());
						currETDDtccTemplate.setLoadType(commodityTermsType.getLoadType());
						currETDDtccTemplate.setDeliveryStartDateTime(CalendarUtils.convertXmlGregCalToUtcFormat(commodityTermsType.getDeliveryStartDateTime()));
						currETDDtccTemplate.setDeliveryEndDateTime(CalendarUtils.convertXmlGregCalToUtcFormat(commodityTermsType.getDeliveryEndDateTime()));
						currETDDtccTemplate.setContractCapacity(commodityTermsType.getContractCapacity());
						
						if(null != commodityTermsType.getPriceTimeInterval())
						{
							currETDDtccTemplate.setPriceTimeIntervalQuantities(commodityTermsType.getPriceTimeInterval().toString());
						}
					}
				}
				
				documentationType = tradeDetail.getDocumentation();
				
				if(null != documentationType)
				{
					currETDDtccTemplate.setMasterAgreementtype(documentationType.getMasterAgreementType());
					currETDDtccTemplate.setMasterAgreementversion(documentationType.getMasterAgreementVersion());
				}

				tradeParties = tradeDetail.getTradeParties();

				if (null != tradeParties)
				{
					tradePartyLsit = tradeParties.getParty();
					
					if(null != tradePartyLsit.get(0)){
						processingOrgTradeParty = tradePartyLsit.get(0);
					}

					if(null != tradePartyLsit.get(1)){
						counterpartyTradeParty = tradePartyLsit.get(1);
					}
					
				/*							
					for (TradePartyType currTradeParty : tradePartyLsit)
					{
						if (currTradeParty.getLEI().equalsIgnoreCase(tradeHeader.getProcessingOrgLEI()))
						{
							processingOrgTradeParty = currTradeParty;
						}
						else if (currTradeParty.getLEI().equalsIgnoreCase(tradeHeader.getCounterpartyLEI()))
						{
							counterpartyTradeParty = currTradeParty;
						}
					}
				*/
					
					if (null != processingOrgTradeParty)
					{
						party1FcmIndicator = processingOrgTradeParty.isIsFCM();

						// if (null != party1FcmIndicator) etdIndicator =
						// party1FcmIndicator ? EtdConstants.ETD_TRUE :
						// EtdConstants.ETD_FALSE;

						String party1FullAddress = formatAddress(processingOrgTradeParty);

						currETDDtccTemplate.setParty1Domicile(party1FullAddress);

						String country = processingOrgTradeParty.getCountry();
						
						if (null != country)
						{
							country = StringUtils.replace(country, ",", " ");
							// currETDDtccTemplate.setParty1BrLoc(country);
						}

						// currETDDtccTemplate.setParty1CorpSect(processingOrgTradeParty.getCorporateSector());

						if (processingOrgTradeParty.isFinancialEntity())
						{
							currETDDtccTemplate.setParty1FinanceEntyJuris(EtdConstants.ESMA_RPT_JURISDICTION);
						}
						else
						{
							currETDDtccTemplate.setParty1NonFinanceEntyJuris(EtdConstants.ESMA_RPT_JURISDICTION);
							
							if (processingOrgTradeParty.isEmirClearingThreshold() == true)
							{
								currETDDtccTemplate.setClearingThresholdParty1(EtdConstants.ETD_TRUE);
							}
								if (processingOrgTradeParty.isEmirClearingThreshold() == false)
							{
								currETDDtccTemplate.setClearingThresholdParty1(EtdConstants.ETD_FALSE);
							}
						}

						currETDDtccTemplate.setTradingcapacityParty1(processingOrgTradeParty.getEmirTradingCapacity());
						// currETDDtccTemplate.setPartyRegion(processingOrgTradeParty.getEmirRegionEEA());

						emirDirectlyLinked = processingOrgTradeParty.isEmirDirectlyLinked();

						if (null != emirDirectlyLinked && emirDirectlyLinked == Boolean.TRUE) financingParty1 = EtdConstants.ETD_TRUE;

						currETDDtccTemplate.setFinancingParty1(financingParty1);
						/*
						 * party1TaxonomyPrefix =
						 * StringUtils.substringBefore(processingOrgTradeParty.getEmirTaxonomy(),
						 * Constants.COLON); party1Taxonomyvalue =
						 * StringUtils.substringAfter(processingOrgTradeParty.getEmirTaxonomy(),
						 * Constants.COLON); currETDDtccTemplate.setProductIDPrefix1(party1TaxonomyPrefix);
						 * currETDDtccTemplate.setProductIDValue1(party1Taxonomyvalue);
						 */
						
							
												
						
						currETDDtccTemplate.setNameofParty1(processingOrgTradeParty.getPartyName());
						if (null != processingOrgTradeParty.getBrokerLEI())
						{
							brokerLeiParty1Prefix 	= StringUtils.substringBefore(processingOrgTradeParty.getBrokerLEI(), Constants.COLON);
							brokerLeiParty1Value 	= StringUtils.substringAfter(processingOrgTradeParty.getBrokerLEI(), Constants.COLON);
							
							currETDDtccTemplate.setBrokerIdParty1Prefix(brokerLeiParty1Prefix);
							currETDDtccTemplate.setBrokerIdParty1Value(brokerLeiParty1Value);
						}

						if (null != processingOrgTradeParty.getClearingBrokerLEI())
						{
							clearingBrokerparty1LEIPrefix 	= StringUtils.substringBefore(processingOrgTradeParty.getClearingBrokerLEI(), Constants.COLON);
							clearingBrokerparty1LEIValue 	= StringUtils.substringAfter(processingOrgTradeParty.getClearingBrokerLEI(), Constants.COLON);
							
							currETDDtccTemplate.setClearingBrokerParty1Prefix(clearingBrokerparty1LEIPrefix);
							currETDDtccTemplate.setClearingBrokerParty1Value(clearingBrokerparty1LEIValue);
						}
						
						if (null != processingOrgTradeParty.getExecutionAgentLEI())
						{
							executionAgentparty1LEIPrefix 	= StringUtils.substringBefore(processingOrgTradeParty.getExecutionAgentLEI(), Constants.COLON);
							executionAgentparty1LEIValue 	= StringUtils.substringAfter(processingOrgTradeParty.getExecutionAgentLEI(), Constants.COLON);
							
							currETDDtccTemplate.setExecutionAgentParty1Prefix(executionAgentparty1LEIPrefix);
							currETDDtccTemplate.setExecutionAgentParty1Value(executionAgentparty1LEIValue);
						}
						
						if (null != processingOrgTradeParty.getBeneficiaryIdLEI())
						{
							beneficiaryIdparty1LEIPrefix 	= StringUtils.substringBefore(processingOrgTradeParty.getBeneficiaryIdLEI(), Constants.COLON);
							beneficiaryIdparty1LEIValue 	= StringUtils.substringAfter(processingOrgTradeParty.getBeneficiaryIdLEI(), Constants.COLON);
							
							currETDDtccTemplate.setBeneficiaryIDParty1Prefix(beneficiaryIdparty1LEIPrefix);
							currETDDtccTemplate.setBeneficiaryIDParty1Value(beneficiaryIdparty1LEIValue);
						}

						if (null != msgType && msgType.equalsIgnoreCase(EtdConstants.ETD_MSG_POSITION))
						{
							if (null != processingOrgTradeParty.getCollateralizationType()) 
								  currETDDtccTemplate.setCollateralizedParty1(processingOrgTradeParty.getCollateralizationType().value());

							currETDDtccTemplate.setCollateralportfoliocodeParty1(processingOrgTradeParty.getCollateralPortfolioCode());
						}
					}

					if (null != counterpartyTradeParty)
					{
						party2FcmIndicator = counterpartyTradeParty.isIsFCM();

						String party2FullAddress = formatAddress(counterpartyTradeParty);

						currETDDtccTemplate.setParty2Domicile(party2FullAddress);

						String country2 = counterpartyTradeParty.getCountry();
						if (null != country2)
						{
							country2 = StringUtils.replace(country2, ",", " ");
							currETDDtccTemplate.setParty2BrLoc(country2);
						}

						// currETDDtccTemplate.setParty2CorpSect(counterpartyTradeParty.getCorporateSector());

						if (null != party2FcmIndicator && party2FcmIndicator == Boolean.TRUE)
						{
							currETDDtccTemplate.setClearingBrokerParty2Prefix(party2LeiPrefix);
							currETDDtccTemplate.setClearingBrokerParty2Value(party2LeiValue);
						}

						// currETDDtccTemplate.setTradingcapacityParty2(counterpartyTradeParty.getEmirTradingCapacity());
						currETDDtccTemplate.setCounterpartyRegion(counterpartyTradeParty.getEmirRegionEEA());
						currETDDtccTemplate.setNameofParty2(counterpartyTradeParty.getPartyName());

						if (null != msgType && msgType.equalsIgnoreCase(EtdConstants.ETD_MSG_POSITION))
						{
							if (null != counterpartyTradeParty.getCollateralizationType())
								currETDDtccTemplate.setCollateralizedParty2(counterpartyTradeParty.getCollateralizationType().value());

							currETDDtccTemplate.setCollateralportfoliocodeParty2(counterpartyTradeParty.getCollateralPortfolioCode());
						}
					}
				}
			}
			catch (Exception exp)
			{
				errorString = "Exception occurred while mapping data from tradeDetails to ETD template" + ExceptionUtils.getFullStackTrace(exp);
				logger.error("########## " + errorString);
				throw new EtdMessageException("EtdRptMapper:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString, sdrMessageId);
			}
		}

		if (null != trade)
		{
			regulatory = trade.getRegulatory();
			if (null != regulatory)
			{
				try
				{
					reportingEligibility = regulatory.getReportingEligibility().get(0);

					if (null != reportingEligibility)
					{
						delegatedReporting = reportingEligibility.getDelegatedReporting();

						if (null != reportingEligibility.getReportingParty())
						{
							submittedFor = reportingEligibility.getReportingParty().value();
						}
						
						if (null != submittedFor)
						{
							if (submittedFor.equalsIgnoreCase(UsThemEnum.US.toString()) || submittedFor.equalsIgnoreCase(UsThemEnum.BOTH.toString()))
							{
								currETDDtccTemplate.setDataSubmitterPrefix(party1LeiPrefix);
								currETDDtccTemplate.setDataSubmitterValue(party1LeiValue);
								currETDDtccTemplate.setSubmittedForPrefix(party1LeiPrefix);
								currETDDtccTemplate.setSubmittedForValue(party1LeiValue);

								/*
								 * currETDDtccTemplate.setBeneficiaryIDParty1Prefix(party1LeiPrefix);
								 * currETDDtccTemplate.setBeneficiaryIDParty1Value(party1LeiValue);
								 */

								if (null != reportingEligibility.getReportingJurisdiction())
								{
									currETDDtccTemplate.setRprtObligParty1(reportingEligibility.getReportingJurisdiction().value());
								}
								else
								{
									currETDDtccTemplate.setRprtObligParty1(EtdConstants.ESMA_RPT_JURISDICTION.toString());
								}
							}
							else if (submittedFor.equalsIgnoreCase(UsThemEnum.THEM.toString()))
							{
								currETDDtccTemplate.setDataSubmitterPrefix(party2LeiPrefix);
								currETDDtccTemplate.setDataSubmitterValue(party2LeiValue);
								currETDDtccTemplate.setSubmittedForPrefix(party2LeiPrefix);
								currETDDtccTemplate.setSubmittedForValue(party2LeiValue);

								/*
								 * currETDDtccTemplate.setBeneficiaryIDParty2Prefix(party2LeiPrefix);
								 * currETDDtccTemplate.setBeneficiaryIDParty2Value(party2LeiValue);
								 */

								if (null != counterpartyTradeParty) 
								{
									currETDDtccTemplate.setTradingcapacityParty2(counterpartyTradeParty.getEmirTradingCapacity());
									if (null != counterpartyTradeParty.getBeneficiaryIdLEI())
									{
										beneficiaryIdparty2LEIPrefix = StringUtils.substringBefore(counterpartyTradeParty.getBeneficiaryIdLEI(), Constants.COLON);
										beneficiaryIdparty2LEIValue = StringUtils.substringAfter(counterpartyTradeParty.getBeneficiaryIdLEI(), Constants.COLON);
										currETDDtccTemplate.setBeneficiaryIDParty2Prefix(beneficiaryIdparty2LEIPrefix);
										currETDDtccTemplate.setBeneficiaryIDParty2Value(beneficiaryIdparty2LEIValue);
									}
								}

								currETDDtccTemplate.setRprtObligParty2(EtdConstants.ESMA_RPT_JURISDICTION.toString());

							}// delegated reporting logic
							
							
							if (StringUtils.isNotBlank(delegatedReporting) && delegatedReporting.equalsIgnoreCase(EtdConstants.ETD_DELEGATED_REPORT_TRUE))
							{
								currETDDtccTemplate.setActionTypeParty2(actionType);		
								currETDDtccTemplate.setSubmittedForPrefix(null);
								currETDDtccTemplate.setSubmittedForValue(EtdConstants.ETD_DELEGATED_REPORT_SUBMITTEDFOR_VALUE);

								if (null != counterpartyTradeParty)
								{
																		
									emirDirectlyLinked = counterpartyTradeParty.isEmirDirectlyLinked();
									if (null != emirDirectlyLinked && emirDirectlyLinked == Boolean.TRUE) financingParty2 = EtdConstants.ETD_TRUE;
									currETDDtccTemplate.setFinancingParty2(financingParty2);

									if (counterpartyTradeParty.isFinancialEntity())
									{
										currETDDtccTemplate.setParty2FinanceEntyJuris(EtdConstants.ESMA_RPT_JURISDICTION);
									}
									else
									{
										currETDDtccTemplate.setParty2NonFinanceEntyJuris(EtdConstants.ESMA_RPT_JURISDICTION);

										if (counterpartyTradeParty.isEmirClearingThreshold() == true)
										{
											currETDDtccTemplate.setClearingThresholdParty2(EtdConstants.ETD_TRUE.toLowerCase());
										}
										if (counterpartyTradeParty.isEmirClearingThreshold() == false)
										{
											currETDDtccTemplate.setClearingThresholdParty2(EtdConstants.ETD_FALSE.toLowerCase());
										}
									}

									if (null != reportingEligibility.getReportingJurisdiction())
									{
										currETDDtccTemplate.setRprtObligParty2(reportingEligibility.getReportingJurisdiction().value());

									}
									
									if (null != counterpartyTradeParty.getBeneficiaryIdLEI())
									{
										beneficiaryIdparty2LEIPrefix = StringUtils.substringBefore(counterpartyTradeParty.getBeneficiaryIdLEI(), Constants.COLON);
										beneficiaryIdparty2LEIValue = StringUtils.substringAfter(counterpartyTradeParty.getBeneficiaryIdLEI(), Constants.COLON);
										
										currETDDtccTemplate.setBeneficiaryIDParty2Prefix(beneficiaryIdparty2LEIPrefix);
										currETDDtccTemplate.setBeneficiaryIDParty2Value(beneficiaryIdparty2LEIValue);
									}
									currETDDtccTemplate.setTradingcapacityParty2(counterpartyTradeParty.getEmirTradingCapacity());
								}

								currETDDtccTemplate.setReportingDelegationModel(EtdConstants.ETD_RPT_DELEGATION_FULL);
								currETDDtccTemplate.setRprtObligParty1(EtdConstants.ESMA_RPT_JURISDICTION.toString());
								currETDDtccTemplate.setRprtObligParty2(EtdConstants.ESMA_RPT_JURISDICTION.toString());

								// delegated reporting for both party1 and party2 buyer value should
								// be same as Party1 buyer value
								/*currETDDtccTemplate.setBuyerPrefixParty2(currETDDtccTemplate.getBuyerPrefixParty1());
								currETDDtccTemplate.setBuyerValueParty2(currETDDtccTemplate.getBuyerValueParty1());*/

								/*
								 * currETDDtccTemplate.setBuyerPrefixParty1(party2LeiPrefix);
								 * currETDDtccTemplate.setBuyerValueParty1(party2LeiValue);
								 * currETDDtccTemplate.setBuyerPrefixParty2(party2LeiPrefix);
								 * currETDDtccTemplate.setBuyerValueParty2(party2LeiValue);
								 */

								if (null != counterpartyTradeParty)
								{
									if (null != counterpartyTradeParty.getLEI()) if (null != counterpartyTradeParty.getBrokerLEI())
									{
										brokerLeiParty2Prefix = StringUtils.substringBefore(counterpartyTradeParty.getBrokerLEI(), Constants.COLON);
										brokerLeiParty2Value = StringUtils.substringAfter(counterpartyTradeParty.getBrokerLEI(), Constants.COLON);
										currETDDtccTemplate.setBrokerIdParty2Prefix(brokerLeiParty2Prefix);
										currETDDtccTemplate.setBrokerIdParty2Value(brokerLeiParty2Value);
									}
									
									if (null != counterpartyTradeParty.getClearingBrokerLEI())
									{
										clearingBrokerparty2LEIPrefix = StringUtils.substringBefore(counterpartyTradeParty.getClearingBrokerLEI(), Constants.COLON);
										clearingBrokerparty2LEIValue = StringUtils.substringAfter(counterpartyTradeParty.getClearingBrokerLEI(), Constants.COLON);
										currETDDtccTemplate.setClearingBrokerParty2Prefix(clearingBrokerparty2LEIPrefix);
										currETDDtccTemplate.setClearingBrokerParty2Value(clearingBrokerparty2LEIValue);
									}
									
									if (null != counterpartyTradeParty.getExecutionAgentLEI())
									{
										executionAgentparty2LEIPrefix = StringUtils.substringBefore(counterpartyTradeParty.getExecutionAgentLEI(), Constants.COLON);
										executionAgentparty2LEIValue = StringUtils.substringAfter(counterpartyTradeParty.getExecutionAgentLEI(), Constants.COLON);
										currETDDtccTemplate.setExecutionAgentParty2Prefix(executionAgentparty2LEIPrefix);
										currETDDtccTemplate.setExecutionAgentParty2Value(executionAgentparty2LEIValue);
									}
								}

								if (null != processingOrgTradeParty)
								{
									currETDDtccTemplate.setPartyRegion(processingOrgTradeParty.getEmirRegionEEA());
								}
								
								
							}
							else
							{
								currETDDtccTemplate.setReportingDelegationModel(EtdConstants.ETD_RPT_DELEGATION_INDEPENDENT);
							}
						}
					}
					
					keywords = regulatory.getKeywords();
					if (null != keywords)
					{
						List<Keyword> keyworkList = keywords.getKeyword();
						
						for (Keyword currKeyword : keyworkList)
						{
							if (currKeyword.getName().equalsIgnoreCase(EtdConstants.ETD_INTRAGROUP_FLAG))
							{
								intraGroupFlag = currKeyword.getValue();
								currETDDtccTemplate.setIntragroup(intraGroupFlag);
							}
						}
					}
				}
				catch (Exception exp)
				{
					errorString = "Exception occurred while mapping data from regulatoryDetails to ETD template" + ExceptionUtils.getFullStackTrace(exp);
					logger.error("########## " + errorString);
					throw new EtdMessageException("EtdRptMapper:3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString, sdrMessageId);
				}
			}
		}
		
		try {
			if(submittedFor.equalsIgnoreCase(UsThemEnum.THEM.toString()) && delegatedReporting.equalsIgnoreCase(EtdConstants.ETD_DELEGATED_REPORT_TRUE)){
				
				currETDDtccTemplate.setRprtObligParty2(EtdConstants.BLANK);
				currETDDtccTemplate.setParty2FinanceEntyJuris(EtdConstants.BLANK);
				currETDDtccTemplate.setBrokerIdParty2Prefix(EtdConstants.BLANK);
				currETDDtccTemplate.setBrokerIdParty2Value(EtdConstants.BLANK);
				currETDDtccTemplate.setSubmittedForPrefix(party1LeiPrefix);
				currETDDtccTemplate.setSubmittedForValue(party1LeiValue);
				currETDDtccTemplate.setReportingDelegationModel(EtdConstants.ETD_RPT_DELEGATION_INDEPENDENT);
				currETDDtccTemplate.setPartyRegion(EtdConstants.BLANK);
				currETDDtccTemplate.setClearingBrokerParty2Prefix(EtdConstants.BLANK);
				currETDDtccTemplate.setClearingBrokerParty2Value(EtdConstants.BLANK);
				currETDDtccTemplate.setBeneficiaryIDParty2Prefix(EtdConstants.BLANK);
				currETDDtccTemplate.setBeneficiaryIDParty2Value(EtdConstants.BLANK);
				currETDDtccTemplate.setFinancingParty2(EtdConstants.BLANK);
				currETDDtccTemplate.setIntragroup(EtdConstants.FALSE);
				currETDDtccTemplate.setActionTypeParty2(EtdConstants.BLANK);	
				currETDDtccTemplate.setTradingcapacityParty2(EtdConstants.BLANK);
			}
		}
		catch (Exception exp)
		{
			errorString = "Exception occurred while mapping data from regulatoryDetails to ETD template" + ExceptionUtils.getFullStackTrace(exp);
			logger.error("########## " + errorString);
			throw new EtdMessageException("EtdRptMapper:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString, sdrMessageId);
		}
		
		try
		{
			dtccOutMsg = eTDDtccTemplateParser.marshallToDtccTemplateString(currETDDtccTemplate);
			
			if(StringUtils.equalsIgnoreCase(msgType, EtdConstants.ETD_MSG_TRANSACTION) && StringUtils.equalsIgnoreCase(action, EtdConstants.ETD_ACTION_NEW))
			{
						
				compressionETDDtccTemplate = getClonedETDDtccTemplate(currETDDtccTemplate);
				
				compressionETDDtccTemplate.setMsgType(EtdConstants.ETD_MSG_TRANSACTION);  
				compressionETDDtccTemplate.setLifecycleEvent(EtdConstants.ETD_LIFECYCLE_EVENT_COMPRESSION);
				compressionETDDtccTemplate.setAction(EtdConstants.ETD_ACTION_MODIFY);
				compressionETDDtccTemplate.setActionTypeParty1(EtdConstants.ETD_ACTION_TYPE_Z);
				if (StringUtils.isNotBlank(delegatedReporting) && delegatedReporting.equalsIgnoreCase(EtdConstants.ETD_DELEGATED_REPORT_TRUE))
				{
					compressionETDDtccTemplate.setActionTypeParty2(EtdConstants.ETD_ACTION_TYPE_Z);
				}
				
				dtccOutMsgCompression = eTDDtccTemplateParser.marshallToDtccTemplateString(compressionETDDtccTemplate);
			}
			
			
			if (null != trade)
			{
				regulatory = trade.getRegulatory();
				if (null == regulatory)
				{
					regulatory = new RegulatoryType();
					trade.setRegulatory(regulatory);
				}

				// adding calculated dtcc output message as keyword to
				// RequlaoryType
				ReportingDataUtils.addKeyword(regulatory, EtdConstants.DTCC_OUT_MSG, dtccOutMsg);
				
				if(null != dtccOutMsgCompression){
					ReportingDataUtils.addKeyword(regulatory, EtdConstants.DTCC_OUT_MSG_COMPRESSION, dtccOutMsgCompression);
				}
			}
		}
		catch (Exception exp)
		{
			errorString = "Exception occurred while marshalling to dtcc template string " + ExceptionUtils.getFullStackTrace(exp);
			logger.error("########## " + errorString);
			throw new EtdMessageException("EtdRptMapper:4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, exp.getMessage(), sdrMessageId);
		}

		logger.info("exiting EtdDtccReportMapper: map method: ");

		return message;
	}

	private String formatAddress(TradePartyType currTradePartyType)
	{

		String address1 = null;
		String address2 = null;
		String city = null;
		String state = null;
		String country = null;
		String zip = null;
		StringBuffer partyFullAddress = new StringBuffer();
		address1 = currTradePartyType.getAddress1();
		address2 = currTradePartyType.getAddress2();
		city = currTradePartyType.getCity();
		state = currTradePartyType.getState();
		country = currTradePartyType.getCountry();
		zip = currTradePartyType.getZip();

		if (null != address1)
		{
			address1 = StringUtils.replaceChars(address1, ",", " ");
			partyFullAddress.append(address1);
			partyFullAddress.append(" ");
		}

		if (null != address2)
		{
			address2 = StringUtils.replaceChars(address2, ",", " ");
			partyFullAddress.append(address2);
			partyFullAddress.append(" ");
		}
		if (null != city)
		{
			city = StringUtils.replaceChars(city, ",", " ");
			partyFullAddress.append(city);
			partyFullAddress.append(" ");
		}
		if (null != state)
		{
			state = StringUtils.replaceChars(state, ",", " ");
			partyFullAddress.append(state);
			partyFullAddress.append(" ");
		}

		if (null != country)
		{
			country = StringUtils.replaceChars(country, ",", " ");
			partyFullAddress.append(country);
			partyFullAddress.append(" ");

		}
		if (null != zip)
		{
			partyFullAddress.append(zip);
		}

		return partyFullAddress.toString();
	}

	public void seteTDDtccTemplateParser(ETDDtccTemplateParser eTDDtccTemplateParser)
	{
		this.eTDDtccTemplateParser = eTDDtccTemplateParser;
	}
	
	private ETDDtccTemplate getClonedETDDtccTemplate(ETDDtccTemplate currETDDtccTemplate) 
	{
		ETDDtccTemplate compressionETDDtccTemplate = new ETDDtccTemplate();
		
		compressionETDDtccTemplate.setAction(currETDDtccTemplate.getAction());
		compressionETDDtccTemplate.setActionTypeParty1(currETDDtccTemplate.getActionTypeParty1());
		compressionETDDtccTemplate.setActionTypeParty2(currETDDtccTemplate.getActionTypeParty2());
		compressionETDDtccTemplate.setAddlRepository1Prefix(currETDDtccTemplate.getAddlRepository1Prefix());
		compressionETDDtccTemplate.setAddlRepository1Value(currETDDtccTemplate.getAddlRepository1Value());
		compressionETDDtccTemplate.setAsofDateTime(currETDDtccTemplate.getAsofDateTime());
		compressionETDDtccTemplate.setBeneficiaryIDParty1Prefix(currETDDtccTemplate.getBeneficiaryIDParty1Prefix());
		compressionETDDtccTemplate.setBeneficiaryIDParty1Value(currETDDtccTemplate.getBeneficiaryIDParty1Value());
		compressionETDDtccTemplate.setBeneficiaryIDParty2Prefix(currETDDtccTemplate.getBeneficiaryIDParty2Prefix());
		compressionETDDtccTemplate.setBeneficiaryIDParty2Value(currETDDtccTemplate.getBeneficiaryIDParty2Value());
		compressionETDDtccTemplate.setBrokerIdParty1Prefix(currETDDtccTemplate.getBrokerIdParty1Prefix());
		compressionETDDtccTemplate.setBrokerIdParty1Value(currETDDtccTemplate.getBrokerIdParty1Value());
		compressionETDDtccTemplate.setBrokerIdParty2Prefix(currETDDtccTemplate.getBrokerIdParty2Prefix());
		compressionETDDtccTemplate.setBrokerIdParty2Value(currETDDtccTemplate.getBrokerIdParty2Value());
		compressionETDDtccTemplate.setBuyerPrefixParty1(currETDDtccTemplate.getBuyerPrefixParty1());
		compressionETDDtccTemplate.setBuyerPrefixParty2(currETDDtccTemplate.getBuyerPrefixParty2());
		compressionETDDtccTemplate.setBuyerValueParty1(currETDDtccTemplate.getBuyerValueParty1());
		compressionETDDtccTemplate.setBuyerValueParty2(currETDDtccTemplate.getBuyerValueParty2());
		compressionETDDtccTemplate.setCcyCollateralValueParty1(currETDDtccTemplate.getCcyCollateralValueParty1());
		compressionETDDtccTemplate.setCcyCollateralValueParty2(currETDDtccTemplate.getCcyCollateralValueParty2());
		compressionETDDtccTemplate.setCleared(currETDDtccTemplate.getCleared());
		compressionETDDtccTemplate.setClearingBrokerParty1Prefix(currETDDtccTemplate.getClearingBrokerParty1Prefix());
		compressionETDDtccTemplate.setClearingBrokerParty1Value(currETDDtccTemplate.getClearingBrokerParty1Value());
		compressionETDDtccTemplate.setClearingBrokerParty2Prefix(currETDDtccTemplate.getClearingBrokerParty2Prefix());
		compressionETDDtccTemplate.setClearingBrokerParty2Value(currETDDtccTemplate.getClearingBrokerParty2Value());
		compressionETDDtccTemplate.setClearingDCOPrefix(currETDDtccTemplate.getClearingDCOPrefix());
		compressionETDDtccTemplate.setClearingDCOValue(currETDDtccTemplate.getClearingDCOValue());
		compressionETDDtccTemplate.setClearingThresholdParty1(currETDDtccTemplate.getClearingThresholdParty1());
		compressionETDDtccTemplate.setClearingThresholdParty2(currETDDtccTemplate.getClearingThresholdParty2());
		compressionETDDtccTemplate.setClearingTimestamp(currETDDtccTemplate.getClearingTimestamp());
		compressionETDDtccTemplate.setCollateralizedParty1(currETDDtccTemplate.getCollateralizedParty1());
		compressionETDDtccTemplate.setCollateralizedParty2(currETDDtccTemplate.getCollateralizedParty2());
		compressionETDDtccTemplate.setCollateralportfoliocodeParty1(currETDDtccTemplate.getCollateralportfoliocodeParty1());
		compressionETDDtccTemplate.setCollateralportfoliocodeParty2(currETDDtccTemplate.getCollateralportfoliocodeParty2());
		compressionETDDtccTemplate.setComment(currETDDtccTemplate.getComment());
		compressionETDDtccTemplate.setCommodityBase(currETDDtccTemplate.getCommodityBase());
		compressionETDDtccTemplate.setCommodityDetails(currETDDtccTemplate.getCommodityDetails());
		compressionETDDtccTemplate.setCompression(currETDDtccTemplate.getCompression());
		compressionETDDtccTemplate.setConfirmationDateTime(currETDDtccTemplate.getConfirmationDateTime());
		compressionETDDtccTemplate.setConfirmationType(currETDDtccTemplate.getConfirmationType());
		compressionETDDtccTemplate.setContractCapacity(currETDDtccTemplate.getContractCapacity());
		compressionETDDtccTemplate.setCounterpartyRegion(currETDDtccTemplate.getCounterpartyRegion());
		compressionETDDtccTemplate.setCurrency2(currETDDtccTemplate.getCurrency2());
		compressionETDDtccTemplate.setDataSubmitterMsgID(currETDDtccTemplate.getDataSubmitterMsgID());
		compressionETDDtccTemplate.setDataSubmitterPrefix(currETDDtccTemplate.getDataSubmitterPrefix());
		compressionETDDtccTemplate.setDataSubmitterValue(currETDDtccTemplate.getDataSubmitterValue());
		compressionETDDtccTemplate.setDateofSettlement(currETDDtccTemplate.getDateofSettlement());
		compressionETDDtccTemplate.setDeliveryEndDateTime(currETDDtccTemplate.getDeliveryEndDateTime());
		compressionETDDtccTemplate.setDeliveryPointorZone(currETDDtccTemplate.getDeliveryPointorZone());
		compressionETDDtccTemplate.setDeliveryStartDateTime(currETDDtccTemplate.getDeliveryStartDateTime());
		compressionETDDtccTemplate.setDeliverytype(currETDDtccTemplate.getDeliverytype());
		compressionETDDtccTemplate.setEffectiveDate(currETDDtccTemplate.getEffectiveDate());
		compressionETDDtccTemplate.setETDIndicator(currETDDtccTemplate.getETDIndicator());
		compressionETDDtccTemplate.setEventIDParty1(currETDDtccTemplate.getEventIDParty1());
		compressionETDDtccTemplate.setEventIDParty2(currETDDtccTemplate.getEventIDParty2());
		compressionETDDtccTemplate.setExchangeRate1(currETDDtccTemplate.getExchangeRate1());
		compressionETDDtccTemplate.setExchangeRateBasis(currETDDtccTemplate.getExchangeRateBasis());
		compressionETDDtccTemplate.setExecutionAgentParty1Prefix(currETDDtccTemplate.getExecutionAgentParty1Prefix());
		compressionETDDtccTemplate.setExecutionAgentParty1Value(currETDDtccTemplate.getExecutionAgentParty1Value());
		compressionETDDtccTemplate.setExecutionAgentParty2Prefix(currETDDtccTemplate.getExecutionAgentParty2Prefix());
		compressionETDDtccTemplate.setExecutionAgentParty2Value(currETDDtccTemplate.getExecutionAgentParty2Value());
		compressionETDDtccTemplate.setExecutionTimestamp(currETDDtccTemplate.getExecutionTimestamp());
		compressionETDDtccTemplate.setExecutionVenuePrefix(currETDDtccTemplate.getExecutionVenuePrefix());
		compressionETDDtccTemplate.setExecutionVenueValue(currETDDtccTemplate.getExecutionVenueValue());
		compressionETDDtccTemplate.setFinancingParty1(currETDDtccTemplate.getFinancingParty1());
		compressionETDDtccTemplate.setFinancingParty2(currETDDtccTemplate.getFinancingParty2());
		compressionETDDtccTemplate.setFixedlegpaymentfrequency(currETDDtccTemplate.getFixedlegpaymentfrequency());
		compressionETDDtccTemplate.setFixedratedaycount(currETDDtccTemplate.getFixedratedaycount());
		compressionETDDtccTemplate.setFixedrateofleg1(currETDDtccTemplate.getFixedrateofleg1());
		compressionETDDtccTemplate.setFixedrateofleg2(currETDDtccTemplate.getFixedrateofleg2());
		compressionETDDtccTemplate.setFloatingrateofleg1(currETDDtccTemplate.getFloatingrateofleg1());
		compressionETDDtccTemplate.setFloatingrateofleg2(currETDDtccTemplate.getFloatingrateofleg2());
		compressionETDDtccTemplate.setFloatingratepaymentfrequency(currETDDtccTemplate.getFloatingratepaymentfrequency());
		compressionETDDtccTemplate.setFloatingrateresetfrequency(currETDDtccTemplate.getFloatingrateresetfrequency());
		compressionETDDtccTemplate.setForwardExchangeRate(currETDDtccTemplate.getForwardExchangeRate());
		compressionETDDtccTemplate.setInterConnectionPoint(currETDDtccTemplate.getInterConnectionPoint());
		compressionETDDtccTemplate.setIntragroup(currETDDtccTemplate.getIntragroup());
		compressionETDDtccTemplate.setLifecycleEvent(currETDDtccTemplate.getLifecycleEvent());
		compressionETDDtccTemplate.setLifecycleEventEffectiveDate(currETDDtccTemplate.getLifecycleEventEffectiveDate());
		compressionETDDtccTemplate.setLoadType(currETDDtccTemplate.getLoadType());
		compressionETDDtccTemplate.setMandatoryClearingIndicator(currETDDtccTemplate.getMandatoryClearingIndicator());
		compressionETDDtccTemplate.setMasterAgreementtype(currETDDtccTemplate.getMasterAgreementtype());
		compressionETDDtccTemplate.setMasterAgreementversion(currETDDtccTemplate.getMasterAgreementversion());
		compressionETDDtccTemplate.setMsgType(currETDDtccTemplate.getMsgType());
		compressionETDDtccTemplate.setMTMCurrencyCCP(currETDDtccTemplate.getMTMCurrencyCCP());
		compressionETDDtccTemplate.setMTMCurrencyParty1(currETDDtccTemplate.getMTMCurrencyParty1());
		compressionETDDtccTemplate.setMTMCurrencyParty2(currETDDtccTemplate.getMTMCurrencyParty2());
		compressionETDDtccTemplate.setMTMValueCCP(currETDDtccTemplate.getMTMValueCCP());
		compressionETDDtccTemplate.setMTMValueParty1(currETDDtccTemplate.getMTMValueParty1());
		compressionETDDtccTemplate.setMTMValueParty2(currETDDtccTemplate.getMTMValueParty2());
		compressionETDDtccTemplate.setNameofParty1(currETDDtccTemplate.getNameofParty1());
		compressionETDDtccTemplate.setNameofParty2(currETDDtccTemplate.getNameofParty2());
		compressionETDDtccTemplate.setNotionalAmount(currETDDtccTemplate.getNotionalAmount());
		compressionETDDtccTemplate.setNotionalCurrencyUnits(currETDDtccTemplate.getNotionalCurrencyUnits());
		compressionETDDtccTemplate.setOptionStrikePrice(currETDDtccTemplate.getOptionStrikePrice());
		compressionETDDtccTemplate.setOptionStrikePriceCCY(currETDDtccTemplate.getOptionStrikePriceCCY());
		compressionETDDtccTemplate.setOptionStyle(currETDDtccTemplate.getOptionStyle());
		compressionETDDtccTemplate.setOptionType(currETDDtccTemplate.getOptionType());
		compressionETDDtccTemplate.setParty1BrLoc(currETDDtccTemplate.getParty1BrLoc());
		compressionETDDtccTemplate.setParty1CorpSect(currETDDtccTemplate.getParty1CorpSect());
		compressionETDDtccTemplate.setParty1Domicile(currETDDtccTemplate.getParty1Domicile());
		compressionETDDtccTemplate.setParty1FinanceEntyJuris(currETDDtccTemplate.getParty1FinanceEntyJuris());
		compressionETDDtccTemplate.setParty1NonFinanceEntyJuris(currETDDtccTemplate.getParty1NonFinanceEntyJuris());
		compressionETDDtccTemplate.setParty1Prefix(currETDDtccTemplate.getParty1Prefix());
		compressionETDDtccTemplate.setParty1Value(currETDDtccTemplate.getParty1Value());
		compressionETDDtccTemplate.setParty2BrLoc(currETDDtccTemplate.getParty2BrLoc());
		compressionETDDtccTemplate.setParty2CorpSect(currETDDtccTemplate.getParty2CorpSect());
		compressionETDDtccTemplate.setParty2Domicile(currETDDtccTemplate.getParty2Domicile());
		compressionETDDtccTemplate.setParty2FinanceEntyJuris(currETDDtccTemplate.getParty2FinanceEntyJuris());
		compressionETDDtccTemplate.setParty2NonFinanceEntyJuris(currETDDtccTemplate.getParty2NonFinanceEntyJuris());
		compressionETDDtccTemplate.setParty2Prefix(currETDDtccTemplate.getParty2Prefix());
		compressionETDDtccTemplate.setParty2Value(currETDDtccTemplate.getParty2Value());
		compressionETDDtccTemplate.setPartyInternalReference(currETDDtccTemplate.getPartyInternalReference());
		compressionETDDtccTemplate.setPartyRegion(currETDDtccTemplate.getPartyRegion());
		compressionETDDtccTemplate.setPriceMultiplier(currETDDtccTemplate.getPriceMultiplier());
		compressionETDDtccTemplate.setPriceNotationPrice(currETDDtccTemplate.getPriceNotationPrice());
		compressionETDDtccTemplate.setPriceNotationPriceType(currETDDtccTemplate.getPriceNotationPriceType());
		compressionETDDtccTemplate.setPriceTimeIntervalQuantities(currETDDtccTemplate.getPriceTimeIntervalQuantities());
		compressionETDDtccTemplate.setPrimaryAssetClass(currETDDtccTemplate.getPrimaryAssetClass());
		compressionETDDtccTemplate.setPriorUTIPrefix(currETDDtccTemplate.getPriorUTIPrefix());
		compressionETDDtccTemplate.setPriorUTIValue(currETDDtccTemplate.getPriorUTIValue());
		compressionETDDtccTemplate.setProductIDPrefix1(currETDDtccTemplate.getProductIDPrefix1());
		compressionETDDtccTemplate.setProductIDPrefix2(currETDDtccTemplate.getProductIDPrefix2());
		compressionETDDtccTemplate.setProductIDValue1(currETDDtccTemplate.getProductIDValue1());
		compressionETDDtccTemplate.setProductIDValue2(currETDDtccTemplate.getProductIDValue2());
		compressionETDDtccTemplate.setQuantity(currETDDtccTemplate.getQuantity());
		compressionETDDtccTemplate.setQuantityUnit(currETDDtccTemplate.getQuantityUnit());
		compressionETDDtccTemplate.setReportingDelegationModel(currETDDtccTemplate.getReportingDelegationModel());
		compressionETDDtccTemplate.setRprtObligParty1(currETDDtccTemplate.getRprtObligParty1());
		compressionETDDtccTemplate.setRprtObligParty2(currETDDtccTemplate.getRprtObligParty2());
		compressionETDDtccTemplate.setScheduledTerminationDate(currETDDtccTemplate.getScheduledTerminationDate());
		compressionETDDtccTemplate.setSettlementCurrency(currETDDtccTemplate.getSettlementCurrency());
		compressionETDDtccTemplate.setSubmittedForPrefix(currETDDtccTemplate.getSubmittedForPrefix());
		compressionETDDtccTemplate.setSubmittedForValue(currETDDtccTemplate.getSubmittedForValue());
		compressionETDDtccTemplate.setTBD10(currETDDtccTemplate.getTBD10());
		compressionETDDtccTemplate.setTBD11(currETDDtccTemplate.getTBD11());
		compressionETDDtccTemplate.setTBD12(currETDDtccTemplate.getTBD12());
		compressionETDDtccTemplate.setTBD13(currETDDtccTemplate.getTBD13());
		compressionETDDtccTemplate.setTBD14(currETDDtccTemplate.getTBD14());
		compressionETDDtccTemplate.setTBD15(currETDDtccTemplate.getTBD15());
		compressionETDDtccTemplate.setTBD16(currETDDtccTemplate.getTBD16());
		compressionETDDtccTemplate.setTBD17(currETDDtccTemplate.getTBD17());
		compressionETDDtccTemplate.setTBD18(currETDDtccTemplate.getTBD18());
		compressionETDDtccTemplate.setTBD19(currETDDtccTemplate.getTBD19());
		compressionETDDtccTemplate.setTBD20(currETDDtccTemplate.getTBD20());
		compressionETDDtccTemplate.setTBD9(currETDDtccTemplate.getTBD9());
		compressionETDDtccTemplate.setTerminationDate(currETDDtccTemplate.getTerminationDate());
		compressionETDDtccTemplate.setTradingcapacityParty1(currETDDtccTemplate.getTradingcapacityParty1());
		compressionETDDtccTemplate.setTradingcapacityParty2(currETDDtccTemplate.getTradingcapacityParty2());
		compressionETDDtccTemplate.setTransactionReferenceID(currETDDtccTemplate.getTransactionReferenceID());
		compressionETDDtccTemplate.setTransactionType(currETDDtccTemplate.getTransactionType());
		compressionETDDtccTemplate.setUnderlyingAsset(currETDDtccTemplate.getUnderlyingAsset());
		compressionETDDtccTemplate.setUnderlyingAssetIdentifierType(currETDDtccTemplate.getUnderlyingAssetIdentifierType());
		compressionETDDtccTemplate.setUpfrontpayment(currETDDtccTemplate.getUpfrontpayment());
		compressionETDDtccTemplate.setUpfrontpaymentCCY(currETDDtccTemplate.getUpfrontpaymentCCY());
		compressionETDDtccTemplate.setUTIPrefix(currETDDtccTemplate.getUTIPrefix());
		compressionETDDtccTemplate.setUTIValue(currETDDtccTemplate.getUTIValue());
		compressionETDDtccTemplate.setValuationDatetimeCCP(currETDDtccTemplate.getValuationDatetimeCCP());
		compressionETDDtccTemplate.setValuationDatetimeParty1(currETDDtccTemplate.getValuationDatetimeParty1());
		compressionETDDtccTemplate.setValuationDatetimeParty2(currETDDtccTemplate.getValuationDatetimeParty2());
		compressionETDDtccTemplate.setValuationTypeCCP(currETDDtccTemplate.getValuationTypeCCP());
		compressionETDDtccTemplate.setValuationTypeParty1(currETDDtccTemplate.getValuationTypeParty1());
		compressionETDDtccTemplate.setValuationTypeParty2(currETDDtccTemplate.getValuationTypeParty2());
		compressionETDDtccTemplate.setValueofthecollateralParty1(currETDDtccTemplate.getValueofthecollateralParty1());
		compressionETDDtccTemplate.setValueofthecollateralParty2(currETDDtccTemplate.getValueofthecollateralParty2());
		compressionETDDtccTemplate.setVersion(currETDDtccTemplate.getVersion());

		return compressionETDDtccTemplate;
	}

}
