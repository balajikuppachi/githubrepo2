package com.wellsfargo.regulatory.etd.services.sftp;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.dto.EtdReportGenRequest;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;
import com.wellsfargo.regulatory.commons.keywords.Constants;


/**
 * @author Raji Komatreddy
 */

@Component
public class SftpEtdReportsToDtccSvc
{
	@Value("${etd.sftp.outputEnabled.dtcc}")
	private String sftpToDtccEnabled;

	@Value("${etd.sftp.host.dtcc}")
	private String hostName;

	@Value("${etd.sftp.user.dtcc}")
	private String userName;

	@Value("${etd.sftp.password.dtcc}")
	private String password;
	
	@Value("${etd.sftp.script.loc}")
	private String sftpScriptLoc;
	
	@Value("${etd.collateral.sftp.user.dtcc}")
	private String userNameCollateral;

	@Value("${etd.collateral.sftp.password.dtcc}")
	private String passwordCollateral;
	
	@Autowired
	SecureDBPwdFactory secureDBPwdFactory;

	private static Logger logger = Logger.getLogger(SftpEtdReportsToDtccSvc.class.getName());

	public void sftpEtdReports(Message<?> message) throws EtdMessageException
	{
		logger.info("inside SftpEtdReportsToDtccSvc: sftpEtdReports method");
		String errorString = null;
		EtdReportGenRequest currEtdReportGenRequest = null;
		Object ipMessage = null;
		File sftpFile = null;
		String sftpFileAbsPath = null;
		String sftpFileName = null;
		String decodedPwd = null;
		String decodedCollateralPwd = null;
		String scriptPwd = null;
		String suppressReporting = null;
		boolean suppressReptFlag = false;
		String msgType = null;
		
		decodedPwd = secureDBPwdFactory.getPassword(password);
		decodedCollateralPwd = secureDBPwdFactory.getPassword(passwordCollateral);

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);
		}
		ipMessage = message.getPayload();

		if (ipMessage instanceof EtdReportGenRequest)
		{
			currEtdReportGenRequest = (EtdReportGenRequest) ipMessage;
			sftpFile = currEtdReportGenRequest.getFile();
			suppressReporting = currEtdReportGenRequest.getSuppressReport();
			sftpFileAbsPath = sftpFile.getAbsolutePath();
			sftpFileName = sftpFile.getName();
			msgType = currEtdReportGenRequest.getMessageType();
			
			if( null != suppressReporting && suppressReporting.equalsIgnoreCase(EtdConstants.ETD_TRUE) )
			{
				suppressReptFlag = true;
			}
			
			
			//to upload collateral file need to be sent to different Ocode than other messages
			if(null != sftpFile && (StringUtils.startsWith(sftpFileName, "Collateral_") || ( null != msgType && msgType.equalsIgnoreCase(Constants.EOD_REGREP_COLLATERALVALUE))))
			{
				userName = userNameCollateral;
				scriptPwd = decodedCollateralPwd;
			}
			else
			{
				scriptPwd = decodedPwd;
			}

			if (null != sftpFileAbsPath && !suppressReptFlag && sftpToDtccEnabled.equalsIgnoreCase(EtdConstants.ETD_TRUE))
			{
				String ftpCmd[] = { sftpScriptLoc, hostName, userName, scriptPwd, sftpFileAbsPath };
				
				Process process = null;
				try
				{
					String line;
			      //  logger.info("Sftp running for :" + Arrays.toString(ftpCmd)+", please wait processing ...");
					logger.info("Sftp running for :" + "sftpScriptLoc:" + sftpScriptLoc  +" sftpFileAbsPath"  + sftpFileAbsPath + 
							 ", please wait processing ...");
					
			        process = Runtime.getRuntime().exec(ftpCmd);
					
			        BufferedReader bri = new BufferedReader(new InputStreamReader(process.getInputStream()));
			        BufferedReader bre = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			        while ((line = bri.readLine()) != null) 
			        {
			        	logger.info("Output Sftp script: "+line);
			        }
			        bri.close();
			        
			        while ((line = bre.readLine()) != null) 
			        {
			        	logger.info("Exception inside Sftp script: "+line);
			        }
			        
			        bre.close();
			        process.waitFor();
			        logger.info("Sftp Completed.");
				}
				catch (Exception e)
				{					
					errorString = "###### exception occurred while sftp to DTCC"  + ExceptionUtils.getFullStackTrace(e);
					logger.error(errorString);
					throw new EtdMessageException("SftpEtdReportsToDtccSvc:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
				}
				finally
				{
					/* Clean-up */
					if(null != process) 
						process.destroy();
				}
			}
			else
			{
				logger.info("sftpEnable flag is false in configuration hence not sending file to dtcc");
			}
		}
	}

	public void setSftpToDtccEnabled(String sftpToDtccEnabled)
	{
		this.sftpToDtccEnabled = sftpToDtccEnabled;
	}

	public void setHostName(String hostName)
	{
		this.hostName = hostName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

}
