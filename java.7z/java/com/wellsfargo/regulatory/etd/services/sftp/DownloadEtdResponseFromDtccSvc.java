package com.wellsfargo.regulatory.etd.services.sftp;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.dto.EtdReportGenRequest;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;


/**
 * @author Raji Komatreddy
 */
@Component
public class DownloadEtdResponseFromDtccSvc
{

	@Value("${etd.sftp.inboundEnabled.from.dtcc}")
	private String sftpFromDtccEnabled;

	@Value("${etd.sftp.host.dtcc}")
	private String hostName;

	@Value("${etd.sftp.download.user.dtcc}")
	private String userName;

	@Value("${etd.sftp.download.password.dtcc}")
	private String password;

	@Value("${etd.sftp.download.script.loc}")
	private String sftpScriptLoc;
	
	@Value("${etd.sftp.download.dtccResponse.local.directory.loc}")
	private String localDirectory;
	
	@Autowired
	SecureDBPwdFactory secureDBPwdFactory;

	private static Logger logger = Logger.getLogger(DownloadEtdResponseFromDtccSvc.class.getName());

	public Message<EtdReportGenRequest> downloadEtdResponse() throws EtdMessageException
	{
		logger.info("inside DownloadEtdResponseFromDtccSvc: downloadEtdResponse method");
		String errorString = null;
		EtdReportGenRequest currEtdReportGenRequest = new EtdReportGenRequest();
		Message<EtdReportGenRequest> downLoadDtccResponseMessge  = null;
		String decodedPassword = null;
		
		decodedPassword = secureDBPwdFactory.getPassword(password);
		

			if (sftpFromDtccEnabled.equalsIgnoreCase(EtdConstants.ETD_TRUE))
			{
				String ftpCmd[] =
				{ sftpScriptLoc, hostName, userName, decodedPassword,localDirectory };

				Process process = null;
				try
				{
					String line;
				//	logger.info("Sftp running for :" + Arrays.toString(ftpCmd) + ", please wait processing ...");

					logger.info("Sftp running for :" + "sftpScriptLoc:" + sftpScriptLoc  +" localDirectory"  + localDirectory + 
							 ", please wait processing ...");
					
					process = Runtime.getRuntime().exec(ftpCmd);

					BufferedReader bri = new BufferedReader(new InputStreamReader(process.getInputStream()));
					BufferedReader bre = new BufferedReader(new InputStreamReader(process.getErrorStream()));
					while ((line = bri.readLine()) != null)
					{
						logger.info("Output download Sftp script: " + line);
					}
					bri.close();

					while ((line = bre.readLine()) != null)
					{
						logger.info("Exception inside download Sftp script: " + line);
					}
					bre.close();
					process.waitFor();
					logger.info("download Completed.");
					
					downLoadDtccResponseMessge = MessageBuilder.withPayload(currEtdReportGenRequest).build();			

				
				
				}
				catch (Exception e)
				{
					errorString = "###### exception occurred while sftp to DTCC" + ExceptionUtils.getFullStackTrace(e);
					logger.error(errorString);
					throw new EtdMessageException("DownloadEtdResponseFromDtccSvc:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
				}
				finally
				{
					/* Clean-up */
					if (null != process) process.destroy();
				}
			}
			else
			{
				logger.info("sftpFromDtccEnabled flag is false in configuration hence not downloading file from dtcc");
			}
		
		
		logger.info("exiting DownloadEtdResponseFromDtccSvc: downloadEtdResponse method");
		
		return downLoadDtccResponseMessge;
	}

	
	public void setHostName(String hostName)
	{
		this.hostName = hostName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}


	public void setSftpFromDtccEnabled(String sftpFromDtccEnabled)
	{
		this.sftpFromDtccEnabled = sftpFromDtccEnabled;
	}


	public void setLocalDirectory(String localDirectory)
	{
		this.localDirectory = localDirectory;
	}

}
