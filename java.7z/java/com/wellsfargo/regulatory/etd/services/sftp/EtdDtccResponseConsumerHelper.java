package com.wellsfargo.regulatory.etd.services.sftp;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * 
 * @author Raji Komatreddy
 *
 */

@Component
public class EtdDtccResponseConsumerHelper
{
	private static Logger logger = Logger.getLogger(EtdDtccResponseConsumerHelper.class.getName());
	public void consumeResponse(Message<?> message)
	{
		logger.info("inside EtdDtccResponseConsumerHelper:  consumeResponse");
	}

}
