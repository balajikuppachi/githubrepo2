package com.wellsfargo.regulatory.etd.services.persister;

import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * 
 * @author Raji Komatreddy
 *
 */
@Component
public class EtdPayLoadPersisterSvc
{
	private static Logger logger = Logger.getLogger(EtdPayLoadPersisterSvc.class.getName());

	public Message<?> persist(Message<?> message) throws MessagingException
	{
		logger.info("Inside EtdPayLoadPersisterSvc persist method");
		
		
		return message;
		
	}	

}
