package com.wf.df.sdr.metaimporter;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.ConfigurationNode;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class MetadataImporter {
	
	private static Log logger = LogFactory.getLog(MetadataImporter.class); 

	private XMLConfiguration config;
	
	private TreeSet<String> fieldAttributeNames = new TreeSet<String>();
	
	private Map<String, Field> fields = new LinkedHashMap<String, Field>();
	
	private List<ProductBasedFieldMapping> fieldMappings = new LinkedList<ProductBasedFieldMapping>();
	
	//public static final String DEFAULT_RATES_FILE_NAME = "Rates-TR_Upload_Template_Ext_v26 01.xlsx";
	
	public MetadataImporter(XMLConfiguration config) {
		this.config = config;
	}
	
	public void importMetadata() {
		ConfigurationNode root = config.getRootNode();
		List<ConfigurationNode> inputs = root.getChildren(MetaDataConstants.INPUT);
		if (inputs.size() != 1) {
			throw new ImportConfigurationException("Configuration file must have exactly one <input> element");
		}
		
		for (ConfigurationNode fileCfgNode : inputs.get(0).getChildren(MetaDataConstants.FILE)) {
			importFile(fileCfgNode);
		}
		
		
		List<ConfigurationNode> outputs = root.getChildren(MetaDataConstants.OUTPUT);
		if (outputs.size() != 1) {
			throw new ImportConfigurationException("Configuration file must have exactly one <output> element");
		}
		
		List<ConfigurationNode> fieldsCfgNodes = outputs.get(0).getChildren(MetaDataConstants.FIELDS);
		if (fieldsCfgNodes.size() != 1) {
			throw new ImportConfigurationException("'output' configuration element must have exactly one <fields> element");
		}
		
		List<ConfigurationNode> fieldMappingsCfgNodes = outputs.get(0).getChildren(MetaDataConstants.FIELDMAPPINGS);
		if (fieldMappingsCfgNodes.size() != 1) {
			throw new ImportConfigurationException("'output' configuration element must have exactly one <fieldMappings> element");
		}

		writeFieldsFile(fieldsCfgNodes.get(0));
		writeFieldMappingsFile(fieldMappingsCfgNodes.get(0));
		
		logger.info("Import complete.");
	}
	
	private void importFile(ConfigurationNode fileCfgNode) {
		String path = getAttr(fileCfgNode, MetaDataConstants.PATH);
		if (path == null) {
			throw new ImportConfigurationException("Single 'path' attribute is required for File configuration element");
		}
		logger.info("File to import: " + path);
		
		String assetClass = getAttr(fileCfgNode, MetaDataConstants.ASSETCLASS);
		if (assetClass == null) {
			throw new ImportConfigurationException("Single 'assetClass' attribute is required for <file> configuration element: " + path);
		}
		
		String specVersion = getAttr(fileCfgNode, MetaDataConstants.SPECVERSION);
		if (specVersion == null) {
			throw new ImportConfigurationException("Single 'specVersion' attribute is required for <file> configuration element: " + path);
		}
		
		String sdrRepository = getAttr(fileCfgNode, MetaDataConstants.SDRREPOSITORY);
		if (sdrRepository == null) {
			throw new ImportConfigurationException("Single 'reportingTo' attribute is required for <file> configuration element: " + path);
		}
		
		File file = new File(path);
		if (!file.exists()) {
			try {
				file = new File(ClassLoader.getSystemResource(path).toURI());
			} catch (URISyntaxException e) {
				throw new ImportException("Couldn't load the file from resources: " + path, e);
			}
			
			if (!file.exists()) {
				throw new ImportException("File doesn't exist: " + path);
			}
		}
		
		InputStream is = null;
		Workbook wb;
		try {
			is = new BufferedInputStream (new FileInputStream(file));
			wb = WorkbookFactory.create(is);
			
		} catch (InvalidFormatException e) {
			throw new ImportException("Provided file is not a valid Excel Workbook: " + path, e);
		} catch (IOException e) {
			throw new ImportException("Couldn't read the file: " + path, e);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					throw new ImportException("Couldn't close input stream.. Really??: " + path, e);
				}
			}
		}
		
		importCreditRatesWorkbook(fileCfgNode, wb, assetClass,specVersion,sdrRepository);
	}
	
	private void importCreditRatesWorkbook(ConfigurationNode fileCfgNode, Workbook wb, String assetClass,String specVersion,String sdrRepository) {
		/**Do once for each repository*/
		StringTokenizer st = new StringTokenizer(sdrRepository, MetaDataConstants.PIPELINE);
		while ( st.hasMoreTokens() )
		{
			String sdrRepo=st.nextToken();
			for (ConfigurationNode sheetCfgNode : fileCfgNode.getChildren(MetaDataConstants.SHEET)) {
				importSheet(sheetCfgNode, wb, assetClass,specVersion,sdrRepo);
			}
		}
	}
	
	private void writeFieldsFile(ConfigurationNode fieldsCfgNode) {
		String path = getAttr(fieldsCfgNode, MetaDataConstants.PATH);
		if (path == null) {
			throw new ImportConfigurationException("Single 'path' attribute is required for <fields> configuration element");
		}
		
		File file = new File(path);
		logger.info("Writing fields to " + file.getAbsolutePath());

		Writer out = null;
		try {
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
			
			// header row
			out.append(MetaDataConstants.ID).append(MetaDataConstants.DELIMETER).append(MetaDataConstants.NAME);
			for (String attrName : fieldAttributeNames) {
				out.append(MetaDataConstants.DELIMETER).append(attrName);
			}
			out.append(MetaDataConstants.LINE_SEPARATOR);
			
			// data rows
			for (Field field : fields.values()) {
				out.append(Long.toString(field.getId())).append(MetaDataConstants.DELIMETER).append(field.getName());
				for (String attrName : fieldAttributeNames) {
					String attrValue = field.getAttributes().get(attrName);
					out.append(MetaDataConstants.DELIMETER);
					if (attrValue != null) {
						out.append(attrValue.replace(MetaDataConstants.LINE_SEPARATOR, MetaDataConstants.SPACE));
					}
				}
				out.append(MetaDataConstants.LINE_SEPARATOR);
			}
		} catch (IOException e) {
			throw new ImportException("Can't write to file: " + file, e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					throw new ImportException("Couldn't close file writer.. Really??: " + path, e);
				}
			}
		}
	}
	
	private void writeFieldMappingsFile(ConfigurationNode fieldMappingsCfgNode) {
		String path = getAttr(fieldMappingsCfgNode, MetaDataConstants.PATH);
		if (path == null) {
			throw new ImportConfigurationException("Single 'path' attribute is required for <fieldMappings> configuration element");
		}
		
		Set<String> tempSet=new TreeSet<String>(Collections.reverseOrder());
		tempSet.addAll(fieldAttributeNames);
		
		File file = new File(path);
		logger.info("Writing field mappings to " + file.getAbsolutePath());

		Writer out = null;
		try {
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
			/**Changed to match the column order in text file and database table*/
			/*out
			.append("id").append("|")
			.append("sequenceNumber").append("|")
			.append("optionality").append("|")
			.append("assetClass").append("|")
			.append("productType").append("|")
			.append("productSubtype").append("|")
			.append("reportType").append("|")
			.append("transactionType").append("|")
			.append("fieldName").append("|")
			.append("fieldId");*/
			out
			.append(MetaDataConstants.ID).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.FIELDID).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.FIELDNAME).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.SEQUENCENUMBER).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.OPTIONALITY).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.ASSETCLASS).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.PRODUCTTYPE).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.PRODUCTSUBTYPE).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.REPORTTYPE).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.TRANSACTIONTYPE);
			
			
			for (String attrName : tempSet) {
				out.append(MetaDataConstants.DELIMETER).append(attrName);
			}
			
			out.append(MetaDataConstants.DELIMETER).append(MetaDataConstants.SPECVER).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.CREATEDATE).append(MetaDataConstants.DELIMETER)
			.append(MetaDataConstants.SDR_REPOSITORY);
			
			out.append(MetaDataConstants.LINE_SEPARATOR);
			for (ProductBasedFieldMapping fieldMapping : fieldMappings) {
				String transType = fieldMapping.getTransactionType() == null ? MetaDataConstants.EMPTY : fieldMapping.getTransactionType();
				String subproduct = fieldMapping.getFullProduct().getSubproduct() == null ? MetaDataConstants.EMPTY : fieldMapping.getFullProduct().getSubproduct(); 
				/**Changed to match the column order in text file and database table*/
					/*out
					.append(Long.toString(fieldMapping.getId())).append("|")
					.append(Integer.toString(fieldMapping.getSequenceNumber())).append("|")
					.append(fieldMapping.getOptionality()).append("|")
					.append(fieldMapping.getFullProduct().getAssetClass()).append("|")
					.append(fieldMapping.getFullProduct().getProduct()).append("|")
					.append(subproduct).append("|")
					.append(fieldMapping.getReportType()).append("|")
					.append(transType).append("|")
					.append(fieldMapping.getField().getName()).append("|")
					.append(Long.toString(fieldMapping.getField().getId()));*/
					out
					.append(Long.toString(fieldMapping.getId())).append(MetaDataConstants.DELIMETER)
					.append(Long.toString(fieldMapping.getField().getId())).append(MetaDataConstants.DELIMETER)
					.append(fieldMapping.getField().getName()).append(MetaDataConstants.DELIMETER)
					.append(Integer.toString(fieldMapping.getSequenceNumber())).append(MetaDataConstants.DELIMETER)
					.append(fieldMapping.getOptionality()).append(MetaDataConstants.DELIMETER)
					.append(fieldMapping.getFullProduct().getAssetClass()).append(MetaDataConstants.DELIMETER)
					.append(fieldMapping.getFullProduct().getProduct()).append(MetaDataConstants.DELIMETER)
					.append(subproduct).append(MetaDataConstants.DELIMETER)
					.append(fieldMapping.getReportType()).append(MetaDataConstants.DELIMETER)
					.append(transType);
				
				
				// add all field attributes as well.. 
				for (String attrName : tempSet) {
					String attrValue = fieldMapping.getField().getAttributes().get(attrName);
					out.append(MetaDataConstants.DELIMETER);
					if (attrValue != null) {
						out.append(attrValue.replace(MetaDataConstants.LINE_SEPARATOR, MetaDataConstants.SPACE));
					}
				}
				
				out.append(MetaDataConstants.DELIMETER).append(fieldMapping.getSpecVersion()).append(MetaDataConstants.DELIMETER)
				.append(new Timestamp(new Date().getTime()).toString()).append(MetaDataConstants.DELIMETER)
				.append(fieldMapping.getSdrRepository());
				
				
				out.append(MetaDataConstants.LINE_SEPARATOR);
			}
		} catch (IOException e) {
			throw new ImportException("Can't write to file: " + file, e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					throw new ImportException("Couldn't close file writer.. Really??: " + path, e);
				}
			}
		}
	}
	
	private void importSheet(ConfigurationNode sheetCfgNode, Workbook wb, String assetClass,String specVersion,String sdrRepo) {
		String sheetName = getAttr(sheetCfgNode, MetaDataConstants.SHEETNAME);
		Sheet sheet = wb.getSheet(sheetName);
		if (sheet == null) {
			throw new ImportException("Sheet '" + sheetName + "' not found in Excel Workbook");
		}
		
		String headerRowStr = getAttr(sheetCfgNode, MetaDataConstants.HEADERROW, "1");
		int headerRowIndex;
		try {
			 headerRowIndex = Integer.parseInt(headerRowStr);
		} catch (NumberFormatException e) {
			throw new ImportConfigurationException("Bad headerRow attribute format", e);
		}
		
		String lastRowStr = getAttr(sheetCfgNode, MetaDataConstants.LASTROW);
		if (lastRowStr == null) {
			throw new ImportConfigurationException("Single 'lastRow' attribute is required for <sheet> configuration element");
		}
		int lastRowIndex;
		try {
			 lastRowIndex = Integer.parseInt(lastRowStr);
		} catch (NumberFormatException e) {
			throw new ImportConfigurationException("Bad lastRow attribute format", e);
		}
		
		String reportType = getAttr(sheetCfgNode, MetaDataConstants.REPORTTYPE);
		if (reportType == null) {
			throw new ImportConfigurationException("Single 'reportType' attribute is required for <sheet> configuration element");
		}
		
		/** Read the optionality  column index from config.xml */
		String optionalityHeader = getAttr(sheetCfgNode, MetaDataConstants.OPTIONALITYHEADER);
		Integer optionalityCol=0 ;
		if(optionalityHeader!=null)
		{
			StringTokenizer st = new StringTokenizer(optionalityHeader, MetaDataConstants.PIPELINE);
			while ( st.hasMoreTokens() )
			{    String s=st.nextToken();
			    if (s.contains(sdrRepo))
			    	optionalityCol= Integer.parseInt(s.split(MetaDataConstants.COLON)[1]);
			}	
		}
		Map<String, String> dataElements = new HashMap<String, String>();
		Map<String, FullProduct> products = new HashMap<String, FullProduct>();
		
		for (ConfigurationNode columnCfgNode : sheetCfgNode.getChildren(MetaDataConstants.COLUMN)) {
			String columnHeader = getAttr(columnCfgNode, MetaDataConstants.HEADER);
			
			if (columnHeader == null) {
				throw new ImportConfigurationException("Single 'header' attribute is required for <column> configuration element");
			}
			
			String dataElement = getAttr(columnCfgNode, MetaDataConstants.DATAELEMENT);
			String product = getAttr(columnCfgNode, MetaDataConstants.PRODUCT);
			String subproduct = getAttr(columnCfgNode, MetaDataConstants.SUBPRODUCT);
			/** Added to take the forex msg type in to account*/
			String msgType = getAttr(columnCfgNode, MetaDataConstants.MSGTYPE);
			
			if (dataElement != null) {
				dataElements.put(columnHeader, dataElement);
			} else if (product != null) {
				FullProduct fullProduct = new FullProduct();
				fullProduct.setAssetClass(assetClass);
				fullProduct.setProduct(product);
				fullProduct.setSubproduct(subproduct);
			
				/** Added to take the forex msg type only in to account */
				fullProduct.setMsgType(msgType);
			
				products.put(columnHeader, fullProduct);
			} else {
				throw new ImportConfigurationException("Either single 'dataElement' or 'product' attribute is required for <column> configuration element");
			}
		}
		
		Map<String, Integer> dataElementIndexes = new HashMap<String, Integer>();
		//TODO: it doesn't need to be a hashmap - we only need a data structure to store pairs of values
		Map<Integer, FullProduct> indexedProducts = new HashMap<Integer, FullProduct>();
		
		Row headerRow = sheet.getRow(headerRowIndex - 1);
		for (Cell cell : headerRow) {
			int colInd = cell.getColumnIndex();
			if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
				String cellValue = cell.getStringCellValue();
				if (cellValue != null) {
					String colName = cellValue.trim();
					if (dataElements.containsKey(colName)) {
						dataElementIndexes.put(dataElements.remove(colName), colInd);
					} else if (products.containsKey(colName)) {
						
						indexedProducts.put(colInd, products.remove(colName));
					}
				}
			}
		}
		
		if (!dataElements.isEmpty()) {
			throw new ImportException("Not all the data element columns found in the Excel sheet: " + sheetName + ", " + dataElements.toString());
		}
		
		if (!products.isEmpty()) {
			throw new ImportException("Not all the subproduct columns found in the Excel sheet: " + sheetName + ", " + products.toString());
		}
		
		int seqNum = 1;
		for (int rowInd = headerRowIndex; rowInd < lastRowIndex; rowInd++) {
			Row row = sheet.getRow(rowInd);
			if (row != null) {
				importRow(row, reportType, seqNum++, dataElementIndexes, indexedProducts,specVersion,sdrRepo,optionalityCol);
			}
		}
		
	}

	private void importRow(Row row, String reportType, int sequenceNumber,
			Map<String, Integer> dataElementIndexes, Map<Integer, FullProduct> indexedProducts,String specVersion,String sdrRepo,int optionalityCol)
	{
		if (!dataElementIndexes.containsKey(MetaDataConstants.FIELDNAME)) {
			throw new ImportConfigurationException("'fieldName' data element is required to be configured for Excel sheet");
		}
		String fieldName = getStringCellVal(row, dataElementIndexes.get(MetaDataConstants.FIELDNAME));
		if (fieldName == null) {
			throw new ImportException("'fieldName' must not be empty: row=" + (row.getRowNum() + 1));
		}
		

		if (fieldName.contains(MetaDataConstants.LINE_SEPARATOR)) {
			logger.warn("Row " + (row.getRowNum() + 1) + " in '" + row.getSheet().getSheetName() + "' sheet has a field with line break in its name - replacing a new line with a space");
		}
		fieldName = fieldName.replace(MetaDataConstants.LINE_SEPARATOR, " ");
		
		Field field = fields.get(fieldName);
		if (field == null) {
			field = new Field();
			field.setId(FieldIdSequence.getNextId());
			field.setName(fieldName);
			
			Map<String, String> attrs = field.getAttributes();
			for (Entry<String, Integer> dataElementEntry : dataElementIndexes.entrySet()) {
				if (dataElementEntry.getKey().equals(MetaDataConstants.FIELDNAME)) {
					continue;
				}
				// this doesn't change the set if the key is already there
				fieldAttributeNames.add(dataElementEntry.getKey());
				
				Integer attrColIndex = dataElementEntry.getValue();
				String attrValue = getStringCellVal(row, attrColIndex);
				attrs.put(dataElementEntry.getKey(), attrValue);
			}
			
			fields.put(fieldName, field);
		}
		
		for (Entry<Integer, FullProduct> productEntry : indexedProducts.entrySet()) {
			int productColInd = productEntry.getKey();
			FullProduct fullProduct = productEntry.getValue();
			int index=0;
			if(reportType.equalsIgnoreCase(MetaDataConstants.FX))
			{
				/**For snapshot messages, read the optionality for EMIR/DTCC*/
				if(MetaDataConstants.SNAPSHOT.equals( fullProduct.getMsgType()))
					index=optionalityCol!=0?optionalityCol:productColInd;
				else
					index=productColInd;
			}else
			{
				/**if optionality col no. avaliable use it ,else use from product type column*/
				index=optionalityCol!=0?optionalityCol:productColInd;
			}
			String orgOptionality = getStringCellVal(row, index);
			String optionality = null;
			if (orgOptionality == null) {
				optionality = MetaDataConstants.NA;
			} else if (orgOptionality.trim().equalsIgnoreCase(MetaDataConstants.NA)) {
				optionality = MetaDataConstants.NA;
			} else if (orgOptionality.trim().equalsIgnoreCase(MetaDataConstants.NBA)) {
				optionality = MetaDataConstants.NA;
			} else if (orgOptionality.trim().equalsIgnoreCase(MetaDataConstants.NOTALLOWED)) {
				optionality = MetaDataConstants.NA;
			} else if (orgOptionality.trim().equalsIgnoreCase(MetaDataConstants.R)) {
				optionality = MetaDataConstants.R; //  Required
			} else if (orgOptionality.trim().equalsIgnoreCase(MetaDataConstants.REQUIRED)) {
				optionality = MetaDataConstants.R; //  Required
			} else if (orgOptionality.trim().equalsIgnoreCase(MetaDataConstants.O)) {
				optionality = MetaDataConstants.O; //  Optional
			} else if (orgOptionality.trim().toUpperCase().startsWith(MetaDataConstants.OPTIONAL)) {
				optionality = MetaDataConstants.O; //  Optional
			} else {
				optionality = MetaDataConstants.C; // Conditional
			}
			
			ProductBasedFieldMapping fieldMapping = new ProductBasedFieldMapping();
			if(reportType.equalsIgnoreCase(MetaDataConstants.FX))
			{
				StringTokenizer st = new StringTokenizer(fullProduct.getProduct(), MetaDataConstants.PIPELINE);
				/** Looping through the 2 product type of Forex*/
				while ( st.hasMoreTokens() )
				{
					String s=st.nextToken();
					/** Added to take the forex msg type in to account*/	
					FullProduct prod= new FullProduct();
					prod.setAssetClass(fullProduct.getAssetClass());
					prod.setMsgType(fullProduct.getMsgType());
					prod.setProduct(s);
					
					fieldMapping = new ProductBasedFieldMapping();
					fieldMapping.setField(field);
					fieldMapping.setId(FieldMappingIdSequence.getNextId());
					fieldMapping.setSequenceNumber(sequenceNumber);
					fieldMapping.setOptionality(optionality);
					fieldMapping.setFullProduct(prod);
					fieldMapping.setReportType(prod.getMsgType());
					fieldMapping.setSpecVersion(specVersion);
					fieldMapping.setSdrRepository(sdrRepo);
					fieldMappings.add(fieldMapping);
				}
				
			}else
			{
				/** For rate and credits*/
				fieldMapping.setField(field);
				fieldMapping.setId(FieldMappingIdSequence.getNextId());
				fieldMapping.setSequenceNumber(sequenceNumber);
				fieldMapping.setOptionality(optionality);
				fieldMapping.setFullProduct(fullProduct);
				fieldMapping.setReportType(reportType);
				fieldMapping.setSpecVersion(specVersion);
				fieldMapping.setSdrRepository(sdrRepo);
				fieldMappings.add(fieldMapping);	
			}
			
		}
	}
	
	private int getCellType(Row row, int ind) {
		Cell cell = row.getCell(ind);
		if (cell == null) {
			return Cell.CELL_TYPE_BLANK;
		}
		
		return cell.getCellType() == Cell.CELL_TYPE_FORMULA ? cell.getCachedFormulaResultType() : cell.getCellType();
	}
	
	private String getStringCellVal(Row row, int ind) {
		Cell cell = row.getCell(ind);
		int cellType = getCellType(row, ind);
		
		switch (cellType) {
		case Cell.CELL_TYPE_BLANK : return null;
		case Cell.CELL_TYPE_STRING : return cell.getStringCellValue();
		default :
			logger.warn("Unexpected cell type (expecting String): row=" + (row.getRowNum()+1) + ", col=" + ind);
			return null;
		}
	}
	
	private <T> T getAttr(ConfigurationNode cfgNode, String attrName) {
		List<ConfigurationNode> attrNodes = cfgNode.getAttributes(attrName);
		if (attrNodes.size() != 1) {
			return null;
		}

		@SuppressWarnings("unchecked")
		T result = (T)attrNodes.get(0).getValue(); 
		return result;
	}
	
	private <T> T getAttr(ConfigurationNode cfgNode, String attrName, T defaultValue) {
		T value = this.<T>getAttr(cfgNode, attrName);
		return value == null ? defaultValue : value; 
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		URL configURL = null;
		if (args.length > 0 && args[0] != null) {
			File cfgFile = new File(args[0]);
			if (!cfgFile.exists() || !cfgFile.canRead()) {
				logger.info("Configuration file doesn't exist or unreadable: " + cfgFile.getAbsolutePath());
				return;
			}
			try {
				configURL = cfgFile.toURI().toURL();
			} catch (MalformedURLException e) {
				logger.info("Usage: java -jar metadata-importer.jar <config file URL>");
			}
		} else {
			configURL = ClassLoader.getSystemResource(MetaDataConstants.DEFAULT_CONFIG_FILE_NAME);
		}
		
		XMLConfiguration config;
		try {
			config = new XMLConfiguration(configURL);
		} catch (ConfigurationException e) {
			e.printStackTrace();
			return;
		}
		
		MetadataImporter importer = new MetadataImporter(config);
		importer.importMetadata();
		
	}

}
