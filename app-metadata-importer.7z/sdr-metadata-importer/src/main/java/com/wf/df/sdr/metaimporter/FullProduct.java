package com.wf.df.sdr.metaimporter;

public class FullProduct {
	private String assetType;
	private String product;
	private String subproduct;
	private String msgType;

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	public String getAssetClass() {
		return assetType;
	}
	
	public void setAssetClass(String assetType) {
		this.assetType = assetType;
	}
	
	public String getProduct() {
		return product;
	}
	
	public void setProduct(String product) {
		this.product = product;
	}
	
	public String getSubproduct() {
		return subproduct;
	}
	
	public void setSubproduct(String subproduct) {
		this.subproduct = subproduct;
	}

	@Override
	public String toString() {
		return "FullProduct [assetType=" + assetType + ", product=" + product
				+ ", subproduct=" + subproduct + "]";
	}
	
}
