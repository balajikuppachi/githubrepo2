package com.wf.df.sdr.metaimporter;

public class ProductBasedFieldMapping {
	private long id;
	private Field field;
	private FullProduct fullProduct;
	private String transactionType;
	private String reportType;
	private String optionality;
	private int sequenceNumber;
	private String specVersion;
	private String sdrRepository;
	
	public String getSpecVersion() {
		return specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	
	public Field getField() {
		return field;
	}
	
	public void setField(Field field) {
		this.field = field;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public String getReportType() {
		return reportType;
	}
	
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	public String getOptionality() {
		return optionality;
	}
	
	public void setOptionality(String optionality) {
		this.optionality = optionality;
	}

	public int getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public FullProduct getFullProduct() {
		return fullProduct;
	}

	public void setFullProduct(FullProduct fullProduct) {
		this.fullProduct = fullProduct;
	}

	
	public String getSdrRepository() {
		return sdrRepository;
	}

	public void setSdrRepository(String sdrRepository) {
		this.sdrRepository = sdrRepository;
	}

	@Override
	public String toString() {
		return "FieldMapping [id=" + id + ", field=" + field + ", fullProduct="
				+ fullProduct + ", transactionType=" + transactionType
				+ ", reportType=" + reportType + ", optionality=" + optionality
				+ ", sequenceNumber=" + sequenceNumber  
				+ ", sdrRepository=" + sdrRepository +"]";
	}
	
	
}
