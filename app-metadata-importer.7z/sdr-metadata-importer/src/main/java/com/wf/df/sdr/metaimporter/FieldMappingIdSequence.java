package com.wf.df.sdr.metaimporter;

public class FieldMappingIdSequence {
	
	private static long nextId = 1;
	
	public static long getNextId() {
		return nextId++;
	}
}
