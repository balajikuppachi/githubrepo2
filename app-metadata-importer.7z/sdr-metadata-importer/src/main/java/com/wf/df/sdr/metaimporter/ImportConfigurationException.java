package com.wf.df.sdr.metaimporter;

public class ImportConfigurationException extends RuntimeException {
	
	private static final long serialVersionUID = 8214032494368880135L;

	public ImportConfigurationException() {
		super();
	}
	
	public ImportConfigurationException(String msg) {
		super(msg);
	}
	
	public ImportConfigurationException(String msg, Throwable cause) {
		super(msg, cause);
	}
	
	public ImportConfigurationException(Throwable cause) {
		super(cause);
	}

}
