package com.wf.df.sdr.metaimporter.ng;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.configuration.tree.ConfigurationNode;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;

import com.wf.df.sdr.calc.core.def.CalculationMetadata;
import com.wf.df.sdr.calc.core.def.SelectCalculationDefinition;
import com.wf.df.sdr.calc.core.def.SelectOption;
import com.wf.df.sdr.metadata.FieldMapping;
import com.wf.df.sdr.metadata.ReportField;
import com.wf.df.sdr.metadata.ReportTemplate;
import com.wf.df.sdr.metaimporter.ImportConfigurationException;
import com.wf.df.sdr.metaimporter.ImportException;

public class EquityWorkbookImporter {
	
	private Workbook wb;
	private ConfigurationNode configNode;
	
	private Pattern nameRangePattern = Pattern.compile("([a-zA-Z]+)\\s*(\\d+)\\s*-\\s*(\\d+)");
	
	private ReportTemplate masterTemplate;
	
	public EquityWorkbookImporter(Workbook wb, ConfigurationNode configNode) {
		this.wb = wb;
		this.configNode = configNode;
	}
	
	public void importEquityWorkbook() {
		for (ConfigurationNode sheetCfgNode : configNode.getChildren("sheet")) {
			importEquitySheet(sheetCfgNode, wb);
		}
	}
	
	private void importEquitySheet(ConfigurationNode sheetCfgNode, Workbook wb) {
		String sheetName = ConfigUtils.getAttr(sheetCfgNode, "sheetName");
		Sheet sheet = wb.getSheet(sheetName);
		if (sheet == null) {
			throw new ImportException("Sheet '" + sheetName + "' not found in Excel Workbook");
		}
		
		int headerRowIndex = ConfigUtils.getIntAttr(sheetCfgNode, "headerRow");
		int lastRowIndex = ConfigUtils.getIntAttr(sheetCfgNode, "lastRow");
		String sheetType = ConfigUtils.getAttr(sheetCfgNode, "type");
		String templateId = ConfigUtils.getAttr(sheetCfgNode, "template");
		
		
		if (sheetType == null) {
			throw new ImportConfigurationException("Single 'type' attribute is required for Equity <sheet> configuration element");
		} else if (sheetType.equals("equityMessageType")) {
			ReportTemplate template = MetadataUtils.initTemplate(templateId);
			importEquityMessageTypeSheet(sheetCfgNode, template, headerRowIndex, lastRowIndex, sheet);
			MetadataUtils.saveTemplate(template);
		} else if (sheetType.equals("equityMaster")) {
			if (masterTemplate != null) {
				throw new ImportConfigurationException("Sheet with type 'equityMaster' must be defined only once"); 
			}
			masterTemplate = MetadataUtils.initTemplate(templateId);
			CalculationMetadata calculationDefinitions = MetadataUtils.initCalculationMetadata();
			importEquityProductSheet(sheetCfgNode, masterTemplate, calculationDefinitions, headerRowIndex, lastRowIndex, sheet);
			MetadataUtils.saveCalculationDefinitions(templateId, calculationDefinitions);
		} else if (sheetType.equals("equityProduct")) {
			if (masterTemplate == null) {
				throw new ImportConfigurationException("Sheet with type 'equityMaster' must be defined and it should go before any 'equityProduct' sheets"); 
			}
			ReportTemplate template = MetadataUtils.copyTemplate(masterTemplate, templateId);
			CalculationMetadata calculationDefinitions = MetadataUtils.initCalculationMetadata();
			importEquityProductSheet(sheetCfgNode, template, calculationDefinitions, headerRowIndex, lastRowIndex, sheet);
			MetadataUtils.saveTemplate(template);
			MetadataUtils.saveCalculationDefinitions(templateId, calculationDefinitions);
		} else {
			throw new ImportConfigurationException("Specified 'type' attribute for Equity <sheet> configuration is not supported: " + sheetType);
		}
	}
	
	private void importEquityMessageTypeSheet(ConfigurationNode sheetCfgNode, ReportTemplate template,
			int headerRowIndex, int lastRowIndex, Sheet sheet) {
		
		Map<String, String> fieldAttributes = ConfigUtils.prepareFieldAttributeHeaders(sheetCfgNode);

		List<ConfigurationNode> optionalityNodes = sheetCfgNode.getChildren("optionality");
		if (optionalityNodes.size() != 1) {
			throw new ImportConfigurationException("Single 'optionality' element is required for <sheet> configuration element with defined 'productType'");
		}
		String optionalityHeader = ConfigUtils.getAttr(optionalityNodes.get(0), "header");
		if (optionalityHeader == null) {
			throw new ImportConfigurationException("Single 'header' attribute is required for <optionality> configuration element");
		}
			
		Map<String, Integer> dataElementIndexes = new HashMap<String, Integer>();
		int optionalityIndex = -1;
		
		Row headerRow = sheet.getRow(headerRowIndex - 1);
		for (Cell cell : headerRow) {
			int colInd = cell.getColumnIndex();
			if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
				String cellValue = cell.getStringCellValue();
				if (cellValue != null) {
					String colName = cellValue.trim().replaceAll("[\r\n]", "");
					if (fieldAttributes.containsKey(colName)) {
						dataElementIndexes.put(fieldAttributes.remove(colName), colInd);
					} else if (colName.equals(optionalityHeader)) {
						optionalityIndex = colInd;
					}
				}
			}
		}
		
		if (!fieldAttributes.isEmpty()) {
			throw new ImportException("Not all the field attributes found in the Excel sheet: " + sheet.getSheetName() + ", " + fieldAttributes.toString());
		}
		
		if (optionalityIndex == -1) {
			throw new ImportException("Optionality column is not found in the Excel sheet: " + sheet.getSheetName() + ", " + optionalityHeader);
		}
		
		for (int rowInd = headerRowIndex; rowInd < lastRowIndex; rowInd++) {
			Row row = sheet.getRow(rowInd);
			if (row != null) {
				importEquityMessageTypeRow(row, template, dataElementIndexes, optionalityIndex);
			}
		}
	}
	
	private void importEquityMessageTypeRow(Row row, ReportTemplate template,
			Map<String, Integer> dataElementIndexes, int optionalityColumnIndex)
	{
		String fieldName = ExcelUtils.getStringCellVal(row, dataElementIndexes.get("fieldName"));
		if (fieldName == null) {
			throw new ImportException("'fieldName' must not be empty: row=" + (row.getRowNum() + 1));
		}
		fieldName = fieldName.trim().replaceAll("[\r\n]", "");
		
		int fieldSequence = (int)ExcelUtils.getNumericCellVal(row, dataElementIndexes.get("fieldSequence"));
		if (fieldSequence == 0) {
			throw new ImportException("'fieldSequence' must not be empty or zeor: row=" + (row.getRowNum() + 1));
		}
		
		String fieldFormat = ExcelUtils.getStringCellVal(row, dataElementIndexes.get("fieldFormat"));
		String fieldDescription = ExcelUtils.getStringCellVal(row, dataElementIndexes.get("fieldDescription"));
		String orgOptionality = ExcelUtils.getStringCellVal(row, optionalityColumnIndex);
		String optionality = MetadataUtils.decodeOptionality(orgOptionality);

		ReportField reportField = new ReportField();
		reportField.setSequenceNumber(fieldSequence);
		reportField.setId(fieldName);
		reportField.setHeader(fieldName);
		reportField.setFormat(fieldFormat);
		reportField.setDescription(fieldDescription);
		template.getFields().put(reportField.getId(), reportField);
		
		FieldMapping fieldMapping = new FieldMapping();
		fieldMapping.setFieldId(fieldName);
//		fieldMapping.setValue("Constants.NotImplemented");
		fieldMapping.setOptionality(optionality);
		template.getMappings().put(fieldMapping.getFieldId(), fieldMapping);
	}
	
	private void importEquityProductSheet(ConfigurationNode sheetCfgNode, ReportTemplate template, CalculationMetadata calculationDefinitions,
			int headerRowIndex, int lastRowIndex, Sheet sheet) {

		Map<String, String> fieldAttributes = ConfigUtils.prepareFieldAttributeHeaders(sheetCfgNode);
		
		List<ConfigurationNode> optionalityNodes = sheetCfgNode.getChildren("optionality");
		Map<String, Map<String, Integer>> optionalityMessageTypeMap = new HashMap<String, Map<String, Integer>>();
		for (ConfigurationNode optionalityNode : optionalityNodes) {
			String messageType = ConfigUtils.getAttr(optionalityNode, "messageType");
			Map<String, Integer> optionalityTransactionTypeMap = optionalityMessageTypeMap.get(messageType);
			if (optionalityTransactionTypeMap == null) {
				optionalityTransactionTypeMap = new HashMap<String, Integer>();
				optionalityMessageTypeMap.put(messageType, optionalityTransactionTypeMap);
			}
			String transactionType = ConfigUtils.getAttr(optionalityNode, "transactionType");
			String column = ConfigUtils.getAttr(optionalityNode, "column");
			int columnIndex = CellReference.convertColStringToIndex(column);
			optionalityTransactionTypeMap.put(transactionType, columnIndex);
		}
		
		List<ConfigurationNode> forceRequiredOptionalityNodes = sheetCfgNode.getChildren("forceRequiredOptionality");
		Set<String> requiredOptionalityFields = new HashSet<String>();
		for (ConfigurationNode forceRequiredOptionalityNode : forceRequiredOptionalityNodes) {
			String field = ConfigUtils.getAttr(forceRequiredOptionalityNode, "fieldName");
			requiredOptionalityFields.add(field);
		}
		
		Map<String, Integer> dataElementIndexes = new HashMap<String, Integer>();
		Row headerRow = sheet.getRow(headerRowIndex - 1);
		for (Cell cell : headerRow) {
			int colInd = cell.getColumnIndex();
			if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
				String cellValue = cell.getStringCellValue();
				if (cellValue != null) {
					String colName = cellValue.trim().replaceAll("[\r\n]", "");
					if (fieldAttributes.containsKey(colName)) {
						dataElementIndexes.put(fieldAttributes.remove(colName), colInd);
					}
				}
			}
		}
		
		if (!fieldAttributes.isEmpty()) {
			throw new ImportException("Not all the field attributes found in the Excel sheet: " + sheet.getSheetName() + ", " + fieldAttributes.toString());
		}
		
		for (int rowInd = headerRowIndex; rowInd < lastRowIndex; rowInd++) {
			Row row = sheet.getRow(rowInd);
			if (row != null) {
				importEquityProductRow(row, template, calculationDefinitions, dataElementIndexes, optionalityMessageTypeMap, requiredOptionalityFields);
			}
		}
	}
	
	private void importEquityProductRow(Row row, ReportTemplate template, CalculationMetadata calculationDefinitions,
			Map<String, Integer> headerToIndexMap, Map<String, Map<String, Integer>> optionalityMessageTypeMap, Set<String> requiredOptionalityFields)
	{
		String fieldFormat = ExcelUtils.getStringCellVal(row, headerToIndexMap.get("fieldFormat"));
		String fieldDescription = ExcelUtils.getStringCellVal(row, headerToIndexMap.get("fieldDescription"));
		
		int seqColIndex = headerToIndexMap.get("fieldSequence");
		int seqCellType = ExcelUtils.getCellType(row, seqColIndex);
		int seqFrom = 0, seqTo = 0;
		switch (seqCellType) {
		case Cell.CELL_TYPE_NUMERIC:
			seqFrom = seqTo = (int)ExcelUtils.getNumericCellVal(row, seqColIndex);
			break;
		case Cell.CELL_TYPE_STRING:
			String seqRangeStr = ExcelUtils.getStringCellVal(row, seqColIndex);
			String[] seqRange = seqRangeStr.split("-");
			seqFrom = Integer.parseInt(seqRange[0]);
			seqTo = Integer.parseInt(seqRange[1]);
			break;
		default:
			throw new ImportException("Unexpected cell type for field sequence number column: row=" + (row.getRowNum() + 1));
		}
		
		if (seqFrom == 0 || seqTo == 0) {
			throw new ImportException("Field sequence number must not be empty or zero: row=" + (row.getRowNum() + 1));
		}
		
		String fieldName = ExcelUtils.getStringCellVal(row, headerToIndexMap.get("fieldName"));
		if (fieldName == null) {
			throw new ImportException("'fieldName' must not be empty: row=" + (row.getRowNum() + 1));
		}
		fieldName = fieldName.trim().replaceAll("[\r\n]", "");

		if (seqFrom == seqTo) {
			ReportField reportField = new ReportField();
			reportField.setSequenceNumber(seqFrom);
			reportField.setId(fieldName);
			reportField.setHeader(fieldName);
			reportField.setFormat(fieldFormat);
			reportField.setDescription(fieldDescription);
			Map<String, ReportField> fields = template.getFields();
			MetadataUtils.makeIdUniqueAndPut(fields, reportField);

			String fieldOptionality;
			if (requiredOptionalityFields.contains(reportField.getId())) {
				fieldOptionality = "Optionality.Required";
			} else {
				fieldOptionality = template.getTemplateId() + "." + reportField.getId() + ".Optionality";
				buildEquityOptionalityCalculation(row, calculationDefinitions, fieldOptionality, optionalityMessageTypeMap);
			}
			FieldMapping fieldMapping = new FieldMapping();
			fieldMapping.setFieldId(reportField.getId());
//			fieldMapping.setValue("Constants.NotImplemented");
			fieldMapping.setOptionality(fieldOptionality);
			template.getMappings().put(fieldMapping.getFieldId(), fieldMapping);
			
		} else {
			Matcher nameRangeMatcher = nameRangePattern.matcher(fieldName);
			if (!nameRangeMatcher.find()) {
				throw new ImportException("Row " + (row.getRowNum() + 1) + " in '" + row.getSheet().getSheetName() + "' sheet has a sequence number defined as range but the field name doesn't match the pattern '<baseName><seq# from>-<seq# to>'");
			}
			String baseFieldName = nameRangeMatcher.group(1);
			int fieldIndFrom = Integer.parseInt(nameRangeMatcher.group(2));
			int fieldIndTo = Integer.parseInt(nameRangeMatcher.group(3));
			
			if (fieldIndTo - fieldIndFrom - (seqTo - seqFrom) != 0) {
				throw new ImportException("Row " + (row.getRowNum() + 1) + " in '" + row.getSheet().getSheetName() + "' sheet defines a range of names but the numbers in the range doesn't match with that of the seq range");
			}
			
			for (int fieldInd = fieldIndFrom, fieldSeq = seqFrom; fieldSeq <= seqTo; fieldInd++, fieldSeq++) {
				String fullFieldName = baseFieldName + fieldInd;

				ReportField reportField = new ReportField();
				reportField.setSequenceNumber(fieldSeq);
				reportField.setId(fullFieldName);
				reportField.setHeader(fullFieldName);
				reportField.setFormat(fieldFormat);
				reportField.setDescription(fieldDescription);
				Map<String, ReportField> fields = template.getFields();
				MetadataUtils.makeIdUniqueAndPut(fields, reportField);

				FieldMapping fieldMapping = new FieldMapping();
				fieldMapping.setFieldId(reportField.getId());
				fieldMapping.setValue("Constants.Blank");
				fieldMapping.setOptionality("Optionality.NA");
				template.getMappings().put(fieldMapping.getFieldId(), fieldMapping);
			}
		}
	}
	
	private void buildEquityOptionalityCalculation(Row row, CalculationMetadata calculationMetadata, String calculationName, 
			Map<String, Map<String, Integer>> optionalityMessageTypeMap)
	{
		SelectCalculationDefinition messageTypeSelectCalculation = new SelectCalculationDefinition();
		messageTypeSelectCalculation.setName(calculationName);
		messageTypeSelectCalculation.setCheck("messageType");
		List<SelectOption> messageTypeOptions = new LinkedList<SelectOption>();
		messageTypeSelectCalculation.setOptions(messageTypeOptions);
		calculationMetadata.getCalculationDefinitions().put(messageTypeSelectCalculation.getName(), messageTypeSelectCalculation);
		
		for (String messageType : optionalityMessageTypeMap.keySet()) {
			SelectOption messageTypeOption = new SelectOption();
			messageTypeOption.setIfEquals(messageType);
			String optionalityTransactionTypeCalculationName = calculationName + "." + messageType;
			messageTypeOption.setPick(optionalityTransactionTypeCalculationName);
			messageTypeOptions.add(messageTypeOption);
			
			Map<String, Integer> optionalityTransactionTypeMap = optionalityMessageTypeMap.get(messageType);
			SelectCalculationDefinition transactionTypeSelectCalculation = new SelectCalculationDefinition();
			transactionTypeSelectCalculation.setName(optionalityTransactionTypeCalculationName);
			transactionTypeSelectCalculation.setCheck("transactionTypeCalc");
			List<SelectOption> transactionTypeOptions = new LinkedList<SelectOption>();
			transactionTypeSelectCalculation.setOptions(transactionTypeOptions);
			calculationMetadata.getCalculationDefinitions().put(transactionTypeSelectCalculation.getName(), transactionTypeSelectCalculation);
			
			for (String transactionType : optionalityTransactionTypeMap.keySet()) {
				SelectOption transactionTypeOption = new SelectOption();
				transactionTypeOption.setIfEquals(transactionType);
				int optionalityColIndex = optionalityTransactionTypeMap.get(transactionType);
				String optionality = MetadataUtils.decodeOptionality(ExcelUtils.getStringCellVal(row, optionalityColIndex));
				transactionTypeOption.setPick(optionality);
				transactionTypeOptions.add(transactionTypeOption);
			}
		}
	}
}
