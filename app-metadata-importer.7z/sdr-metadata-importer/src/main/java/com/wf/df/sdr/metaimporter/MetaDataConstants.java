package com.wf.df.sdr.metaimporter;

/**
 * The Class MetaDataConstants.
 */
public class MetaDataConstants {
	
	public static final String LINE_SEPARATOR = "\n";
	public static final String DEFAULT_CONFIG_FILE_NAME = "config.xml";
	public static final String DELIMETER = "~";
	public static final String INPUT = "input";
	public static final String FILE = "file";
	public static final String OUTPUT = "output";
	public static final String PATH = "path";
	public static final String FIELDS = "fields";
	public static final String SHEET = "sheet";
	public static final String ASSETCLASS = "assetClass";
	public static final String SPECVERSION = "specVersion";
	public static final String FIELDMAPPINGS = "fieldMappings";
	public static final String NAME = "name";
	public static final String ID = "ID";
	public static final String SPACE = " ";
	public static final String FIELDID = "fieldId";
	public static final String FIELDNAME = "fieldName";
	public static final String SEQUENCENUMBER = "sequenceNumber";
	public static final String OPTIONALITY = "optionality";
	public static final String PRODUCTTYPE = "productType";
	public static final String PRODUCTSUBTYPE = "productSubtype";
	public static final String REPORTTYPE = "reportType";
	public static final String TRANSACTIONTYPE = "transactionType";
	public static final String SPECVER = "spec_ver";
	public static final String CREATEDATE = "create_date";
	public static final String EMPTY = "";
	public static final String SHEETNAME = "sheetName";
	public static final String HEADERROW = "headerRow";
	public static final String LASTROW = "lastRow";
	public static final String COLUMN = "column";
	public static final String HEADER = "header";
	public static final String DATAELEMENT = "dataElement";
	public static final String PRODUCT = "product";
	public static final String SUBPRODUCT = "subproduct";
	public static final String MSGTYPE = "msgType";
	public static final String NA = "NA";
	public static final String NBA = "N/A";
	public static final String NOTALLOWED = "Not Allowed";
	public static final String REQUIRED = "Required";
	public static final String R = "R";
	public static final String OPTIONAL = "OPTIONAL";
	public static final String O = "O";
	public static final String C = "C";
	public static final String FX = "FX";
	public static final String PIPELINE = "|";
	public static final String SDR_REPOSITORY = "sdr_repository";
	public static final String DTCC = "DTCC";
	public static final String OPTIONALITYHEADER = "optionalityHeader";
	public static final String SDRREPOSITORY = "sdrRepository";
	public static final String COLON = ":";
	public static final String SNAPSHOT = "Snapshot";
	
}
