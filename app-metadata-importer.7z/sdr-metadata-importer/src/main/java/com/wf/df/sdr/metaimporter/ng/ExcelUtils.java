package com.wf.df.sdr.metaimporter.ng;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExcelUtils {
	private static Logger logger = LoggerFactory.getLogger(ExcelUtils.class);
	
	public static int getCellType(Row row, int ind) {
		Cell cell = row.getCell(ind);
		if (cell == null) {
			return Cell.CELL_TYPE_BLANK;
		}
		
		return cell.getCellType() == Cell.CELL_TYPE_FORMULA ? cell.getCachedFormulaResultType() : cell.getCellType();
	}
	
	public static String getStringCellVal(Row row, int ind) {
		Cell cell = row.getCell(ind);
		int cellType = getCellType(row, ind);
		
		switch (cellType) {
		case Cell.CELL_TYPE_BLANK : return null;
		case Cell.CELL_TYPE_STRING : return cell.getStringCellValue();
		default :
			logger.warn("Unexpected cell type (expecting String): row=" + (row.getRowNum()+1) + ", col=" + ind);
			return null;
		}
	}
	
	public static double getNumericCellVal(Row row, int ind) {
		Cell cell = row.getCell(ind);
		int cellType = getCellType(row, ind);
		
		switch (cellType) {
		case Cell.CELL_TYPE_BLANK : return 0;
		case Cell.CELL_TYPE_NUMERIC : return cell.getNumericCellValue();
		default :
			logger.warn("Unexpected cell type (expecting Numeric): row=" + (row.getRowNum()+1) + ", col=" + ind);
			return 0;
		}
	}
	
}
