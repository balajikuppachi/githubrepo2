package com.wf.df.sdr.metaimporter;

public class ImportException extends RuntimeException {
	
	private static final long serialVersionUID = -4073068523490489575L;

	public ImportException() {
		super();
	}
	
	public ImportException(String msg) {
		super(msg);
	}
	
	public ImportException(String msg, Throwable cause) {
		super(msg, cause);
	}
	
	public ImportException(Throwable cause) {
		super(cause);
	}

}
