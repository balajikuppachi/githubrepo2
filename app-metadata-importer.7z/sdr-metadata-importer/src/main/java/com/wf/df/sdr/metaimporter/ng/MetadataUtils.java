package com.wf.df.sdr.metaimporter.ng;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wf.df.sdr.calc.core.def.CalculationDefinition;
import com.wf.df.sdr.calc.core.def.CalculationMetadata;
import com.wf.df.sdr.calc.core.def.CalculationMetadataManager;
import com.wf.df.sdr.metadata.FieldMapping;
import com.wf.df.sdr.metadata.ReportField;
import com.wf.df.sdr.metadata.ReportMetadata;
import com.wf.df.sdr.metadata.ReportMetadataManager;
import com.wf.df.sdr.metadata.ReportTemplate;

public class MetadataUtils {
	
	private static Logger logger = LoggerFactory.getLogger(MetadataUtils.class);
	
	private static ReportMetadataManager reportMetadataManager = new ReportMetadataManager();
	private static CalculationMetadataManager calculationMetadataManager = new CalculationMetadataManager();
	
	public static ReportTemplate initTemplate(String templateId) {
		
		ReportTemplate reportTemplate = new ReportTemplate();
		reportTemplate.setTemplateId(templateId);
		
		reportTemplate.setFields(new LinkedHashMap<String, ReportField>());
		reportTemplate.setMappings(new LinkedHashMap<String, FieldMapping>());
		
		return reportTemplate;
	}
	
	public static CalculationMetadata initCalculationMetadata() {
		CalculationMetadata calculationMetadata = new CalculationMetadata();
		Map<String, CalculationDefinition> calculationDefinitions = new LinkedHashMap<String, CalculationDefinition>();
		calculationMetadata.setCalculationDefinitions(calculationDefinitions);
		return calculationMetadata;
	}
	
	public static ReportTemplate copyTemplate(ReportTemplate srcTemplate, String newTemplateId) {
		ReportTemplate reportTemplate = initTemplate(newTemplateId);
		reportTemplate.merge(srcTemplate);
		return reportTemplate;
	}
	
	public static void saveTemplate(ReportTemplate reportTemplate) {
		Map<String, ReportTemplate> reportTemplatesMap = new LinkedHashMap<String, ReportTemplate>();
		reportTemplatesMap.put(reportTemplate.getTemplateId(), reportTemplate);
		ReportMetadata reportMetadata = new ReportMetadata();
		reportMetadata.setTemplates(reportTemplatesMap);
		
		File templateFile = new File("target/template-" + reportTemplate.getTemplateId() + ".xml");
		logger.info("Writing to " + templateFile.getAbsolutePath());
		reportMetadataManager.store(reportMetadata, templateFile);
	}
	
	public static void saveCalculationDefinitions(String template, CalculationMetadata calculationMetadata) {
		File calculationsFile = new File("target/calculations-optionality-" + template + ".xml");
		logger.info("Writing to " + calculationsFile.getAbsolutePath());
		calculationMetadataManager.store(calculationMetadata, calculationsFile);
	}
	
	public static void makeIdUniqueAndPut(Map<String, ReportField> fields, ReportField reportField) {
		int dupInd = 0;
		String baseName = reportField.getId();
		while (fields.containsKey(reportField.getId())) {
			reportField.setId(baseName + "#dup" + ++dupInd);
		}
		
		if (dupInd > 0) {
			logger.warn("Field name already exists - appending '#dup" + dupInd + "' to it: " + reportField.getId());
		}
		
		fields.put(reportField.getId(), reportField);
	}
	
	public static String decodeOptionality(String orgOptionality) {
		if (orgOptionality == null) {
			return "Optionality.NA";
		} else if (orgOptionality.trim().equalsIgnoreCase("NA")) {
			return "Optionality.NA";
		} else if (orgOptionality.trim().equalsIgnoreCase("N/A")) {
			return "Optionality.NA";
		} else if (orgOptionality.trim().equalsIgnoreCase("X")) {
			return "Optionality.NA";
		} else if (orgOptionality.trim().equalsIgnoreCase("Not Allowed")) {
			return "Optionality.NA";
		} else if (orgOptionality.trim().equalsIgnoreCase("N")) {
			return "Optionality.NA";
		} else if (orgOptionality.trim().equalsIgnoreCase("R")) {
			return "Optionality.Required"; //  Required
		} else if (orgOptionality.trim().equalsIgnoreCase("Required")) {
			return "Optionality.Required"; //  Required
		} else if (orgOptionality.trim().equalsIgnoreCase("√")) {
			return "Optionality.Required"; //  Required
		} else if (orgOptionality.trim().equalsIgnoreCase("O")) {
			return "Optionality.Optional"; //  Optional
		} else if (orgOptionality.trim().toUpperCase().startsWith("OPTIONAL")) {
			return "Optionality.Optional"; //  Optional
		} else {
			return "Optionality.Conditional"; // Conditional
		}
	}
}
