package com.wf.df.sdr.metaimporter.ng;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.ConfigurationNode;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.wf.df.sdr.metaimporter.ImportConfigurationException;
import com.wf.df.sdr.metaimporter.ImportException;

public class MetadataImporterNg {
	
	private Log logger = LogFactory.getLog(getClass()); 

	private XMLConfiguration config;
	
	public static final String DEFAULT_CONFIG_NG_FILE_NAME = "config_ng.xml";
	
	public MetadataImporterNg(XMLConfiguration config) {
		this.config = config;
	}
	
	public void importMetadata() {
		ConfigurationNode root = config.getRootNode();
		List<ConfigurationNode> inputs = root.getChildren("input");
		if (inputs.size() != 1) {
			throw new ImportConfigurationException("Configuration file must have exactly one <input> element");
		}
		
		for (ConfigurationNode fileCfgNode : inputs.get(0).getChildren("file")) {
			importFile(fileCfgNode);
		}
		
		logger.info("Import complete.");
	}
	
	private void importFile(ConfigurationNode fileCfgNode) {
		String path = ConfigUtils.getAttr(fileCfgNode, "path");
		if (path == null) {
			throw new ImportConfigurationException("Single 'path' attribute is required for File configuration element");
		}
		logger.info("File to import: " + path);
		
		String assetClass = ConfigUtils.getAttr(fileCfgNode, "assetClass");
		if (assetClass == null) {
			throw new ImportConfigurationException("Single 'assetClass' attribute is required for <file> configuration element: " + path);
		}
		
		File file = new File(path);
		if (!file.exists()) {
			try {
				file = new File(ClassLoader.getSystemResource(path).toURI());
			} catch (URISyntaxException e) {
				throw new ImportException("Couldn't load the file from resources: " + path, e);
			}
			
			if (!file.exists()) {
				throw new ImportException("File doesn't exist: " + path);
			}
		}
		
		InputStream is = null;
		Workbook wb;
		try {
			is = new BufferedInputStream (new FileInputStream(file));
			wb = WorkbookFactory.create(is);
			
		} catch (InvalidFormatException e) {
			throw new ImportException("Provided file is not a valid Excel Workbook: " + path, e);
		} catch (IOException e) {
			throw new ImportException("Couldn't read the file: " + path, e);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					throw new ImportException("Couldn't close input stream.. Really??: " + path, e);
				}
			}
		}
		
		new EquityWorkbookImporter(wb, fileCfgNode).importEquityWorkbook();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		URL configURL = ClassLoader.getSystemResource(DEFAULT_CONFIG_NG_FILE_NAME);
		
		XMLConfiguration config;
		try {
			config = new XMLConfiguration(configURL);
		} catch (ConfigurationException e) {
			e.printStackTrace();
			return;
		}
		
		MetadataImporterNg importer = new MetadataImporterNg(config);
		importer.importMetadata();
		
	}

}
