package com.wf.df.sdr.metaimporter.ng;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration.tree.ConfigurationNode;

import com.wf.df.sdr.metaimporter.ImportConfigurationException;

public class ConfigUtils {
	
	public static Map<String, String> prepareFieldAttributeHeaders(ConfigurationNode cfgNode) {
		Map<String, String> fieldAttributes = new HashMap<String, String>();
		for (ConfigurationNode columnCfgNode : cfgNode.getChildren("fieldAttribute")) {
			String columnHeader = ConfigUtils.getAttr(columnCfgNode, "header");
			if (columnHeader == null) {
				throw new ImportConfigurationException("Single 'header' attribute is required for <fieldAttribute> configuration element");
			}
			
			String fieldAttributeName = ConfigUtils.getAttr(columnCfgNode, "attributeName");
			
			if (fieldAttributeName != null) {
				fieldAttributes.put(columnHeader, fieldAttributeName);
			} else {
				throw new ImportConfigurationException("Single 'attributeName' attribute is required for <fieldAttribute> configuration element");
			}
		}
		
		if (!fieldAttributes.containsValue("fieldName")) {
			throw new ImportConfigurationException("Single 'fieldAttribute' element with 'attributeName' = 'fieldName' is required for 'sheet' element");
		}
		
		return fieldAttributes;
	}
	
	public static <T> T getAttr(ConfigurationNode cfgNode, String attrName) {
		List<ConfigurationNode> attrNodes = cfgNode.getAttributes(attrName);
		if (attrNodes.size() != 1) {
			return null;
		}

		@SuppressWarnings("unchecked")
		T result = (T)attrNodes.get(0).getValue(); 
		return result;
	}
	
//	public static <T> T getAttr(ConfigurationNode cfgNode, String attrName, T defaultValue) {
//		T value = getAttr(cfgNode, attrName);
//		return value == null ? defaultValue : value; 
//	}
//	
	public static int getIntAttr(ConfigurationNode cfgNode, String attrName) {
		String attrStr = getAttr(cfgNode, attrName);
		return Integer.parseInt(attrStr);
	}
	
	
}
