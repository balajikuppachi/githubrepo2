package com.wellsfargo.regulatory.commons.cache;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.wellsfargo.regulatory.commons.cache.loader.DomainMappingCacheLoader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class DomainMappingCache
{

	private static DomainMappingCache instance;
	private Map<String, String> domainMappingMap;

	private DomainMappingCache()
	{
		domainMappingMap = new HashMap<String, String>();
	}

	public static DomainMappingCache getInstance()
	{

		if (null == instance)
		{
			instance = new DomainMappingCache();
			DomainMappingCacheLoader.loadDomainCache(instance);
		}

		return instance;
	}

	public void setValue(String key, String value)
	{
		domainMappingMap.put(key, value);
	}

	public String getValue(String key)
	{
		return domainMappingMap.get(key);
	}

	public Set<String> getKeys()
	{
		return domainMappingMap.keySet();
	}

}
