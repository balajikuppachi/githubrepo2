package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepComplianceMatrix;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepComplainceMatrixDao;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepComplainceMatrixDaoImpl implements RegRepComplainceMatrixDao
{
	private static Logger logger = Logger.getLogger(RegRepComplainceMatrixDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public RegRepComplainceMatrixDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<RegRepComplianceMatrix> findAll()
	{
		logger.debug("Entering findAll() method");

		String query = QueryMaster.GET_ALL_COMPLIANCE_MATRIX;

		List<RegRepComplianceMatrix> configs = new ArrayList<RegRepComplianceMatrix>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

		for (Map<String, Object> row : rows)
		{
			RegRepComplianceMatrix config = new RegRepComplianceMatrix();

			config.setJurisdiction((String) (row.get("JURISDICTION")));
			config.setRegion((String) row.get("REGION"));
			config.setRepository((String) (row.get("REPOSITORY")));
			config.setReportType((String) (row.get("REPORT_TYPE")));
			config.setComplianceMinutes((Integer) (row.get("COMPLIANCE_MINUTES")));

			configs.add(config);

		}

		logger.debug("Leaving findAll() method");

		return configs;

	}

}
