package com.wellsfargo.regulatory.commons.cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wellsfargo.regulatory.commons.cache.loader.RulesCacheLoader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class DRLCache
{

	private static DRLCache instance;
	private Map<String, List<String>> DRLMap;

	private DRLCache()
	{

		DRLMap = new HashMap<String, List<String>>();
	}

	public static DRLCache getInstance()
	{
		if (null == instance)
		{
			instance = new DRLCache();
			RulesCacheLoader.loadRulesCache(instance);
		}

		return instance;
	}

	// public Map<String, List<File>>getDRLMap(){
	// return DRLMap;
	// }

	public void setValue(String key, List<String> values)
	{
		DRLMap.put(key, values);
	}

	public List<String> getValues(String key)
	{
		return DRLMap.get(key);
	}

}
