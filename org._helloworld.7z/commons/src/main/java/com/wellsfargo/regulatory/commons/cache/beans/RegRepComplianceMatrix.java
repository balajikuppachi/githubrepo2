package com.wellsfargo.regulatory.commons.cache.beans;

public class RegRepComplianceMatrix implements java.io.Serializable
{

	/**
	 * @author Amit Rana
	 * @date 08/23/2014
	 * @version 1.0
	 */

	private static final long serialVersionUID = 1L;

	private String jurisdiction;
	private String region;
	private String repository;
	private String reportType;
	private int complianceMinutes;

	public RegRepComplianceMatrix()
	{
		super();
	}

	public RegRepComplianceMatrix(String jurisdiction, String region, String repository, String reportType, int complianceMinutes)
	{
		super();
		this.jurisdiction = jurisdiction;
		this.region = region;
		this.repository = repository;
		this.reportType = reportType;
		this.complianceMinutes = complianceMinutes;
	}

	public String getJurisdiction()
	{
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction)
	{
		this.jurisdiction = jurisdiction;
	}

	public String getRegion()
	{
		return region;
	}

	public void setRegion(String region)
	{
		this.region = region;
	}

	public String getRepository()
	{
		return repository;
	}

	public void setRepository(String repository)
	{
		this.repository = repository;
	}

	public String getReportType()
	{
		return reportType;
	}

	public void setReportType(String reportType)
	{
		this.reportType = reportType;
	}

	public int getComplianceMinutes()
	{
		return complianceMinutes;
	}

	public void setComplianceMinutes(int complianceMinutes)
	{
		this.complianceMinutes = complianceMinutes;
	}

	@Override
	public String toString()
	{
		return "RegRepComplianceMatrix [jurisdiction=" + jurisdiction + ", region=" + region + ", repository=" + repository + ", reportType=" + reportType + ", complianceMinutes=" + complianceMinutes
		        + "]";
	}

}
