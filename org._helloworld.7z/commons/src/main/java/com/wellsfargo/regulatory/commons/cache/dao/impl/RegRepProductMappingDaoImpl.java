package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepProductMapping;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepProductMappingDao;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepProductMappingDaoImpl implements RegRepProductMappingDao
{

	private static Logger logger = Logger.getLogger(RegRepProductMappingDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public RegRepProductMappingDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<RegRepProductMapping> findAll()
	{
		logger.debug("Entering findAll() method");

		RegRepProductMapping config = null;

		String query = QueryMaster.GET_ALL_PRODUCT_MAPPING;

		List<RegRepProductMapping> configs 	= new ArrayList<RegRepProductMapping>();
		List<Map<String, Object>> rows 		= jdbcTemplate.queryForList(query);

		for (Map<String, Object> row : rows)
		{

			config = new RegRepProductMapping();

			config.setSrcAssetClass((String) row.get("SRC_ASSET_CLASS"));
			config.setSrcPrdType((String) row.get("SRC_PRD_TYPE"));
			config.setSrcSubPrdType((String) (row.get("SRC_SUB_PRD_TYPE")));
			config.setDtccAssetClass((String) row.get("DTCC_ASSET_CLASS"));
			config.setDtccPrdType((String) row.get("DTCC_PROD_TYPE"));
			config.setDtccSubPrdType((String) (row.get("DTCC_SUB_PROD_TYPE")));
			config.setMappingType((String) row.get("MAPPING_TYPE"));
			config.setFpmlProductType((String) row.get("FpML_PRODUCT_TYPE"));

			configs.add(config);
		}

		logger.debug("Leaving findAll() method");

		return configs;

	}
}
