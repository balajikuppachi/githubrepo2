package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.cache.dao.RealtimeConfigDAO;


/******************************************************************************
 * Filename    : RealtimeConfigDAOImpl.java
 * Author      : Rama Nuti
 * Date Created: 2015-11-05
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class RealtimeConfigDAOImpl implements RealtimeConfigDAO 
{
	
	private JdbcTemplate m_jdbcTemplate;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<String, Set<String>> loadRealtimeConfigData() throws Exception 
	{
		final Map<String, Set<String>> config = new LinkedHashMap<String, Set<String>>();
		
		getJdbcTemplate().query("SELECT PROPERTY_NAME, PROPERTY_VALUE FROM REGREP_PROPERTY_VALUES", new RowMapper() 
		{
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				String propname = rs.getString("PROPERTY_NAME");
				
				Set<String> values = null;
				
				if(config.containsKey(propname)) 
				{
					values = config.get(propname);
				}
				else 
				{
					values = new HashSet<String>();
					config.put(propname, values);
				}
				
				values.add(rs.getString("PROPERTY_VALUE"));
				
				return null;
			}
			
		});
		
		return config;
	}
	
	public int updateRealtimeConfig(String propKey, String propValue, String propDate) throws Exception
	{
		int updatedRecords = 0;
		
		updatedRecords=getJdbcTemplate().update("UPDATE REGREP_PROPERTY_VALUES SET PROPERTY_VALUE = ? , UPDATE_USER_TIMESTAMP= ? WHERE PROPERTY_NAME = ? ", new Object[] {propValue, propDate, propKey});
		
		return updatedRecords;
	}

	public int updateRefreshConfig() throws Exception
	{
		int updatedRecords = 0;
		
		updatedRecords=getJdbcTemplate().update("UPDATE REGREP_REFRESH_TABLES SET LAST_UPDATE_TIMESTAMP = GETDATE() where TABLE_NAME = 'REGREP_PROPERTY_VALUES' ");
		
		return updatedRecords;
	}

	public int updateRefreshConfig(String propKey) throws Exception
	{
		int updatedRecords = 0;
		
		updatedRecords=getJdbcTemplate().update("UPDATE REGREP_REFRESH_TABLES SET LAST_UPDATE_TIMESTAMP = GETDATE() where TABLE_NAME = ? ", new Object[] {propKey});
		
		return updatedRecords;
	}

	public int updateRefreshConfigByDate(String propValue) throws Exception
	{
		int updatedRecords = 0;
		
		updatedRecords=getJdbcTemplate().update("UPDATE REGREP_REFRESH_TABLES SET LAST_UPDATE_TIMESTAMP = ? where TABLE_NAME = 'REGREP_PROPERTY_VALUES' ", new Object[] {propValue});
		
		return updatedRecords;
	}
	public JdbcTemplate getJdbcTemplate() 
	{
        return m_jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        m_jdbcTemplate = jdbcTemplate;
    }

}
