package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.Collection;

/******************************************************************************
 * Filename    : StaticDataCache.java
 * Author      : Rama Nuti
 * Date Created: 2015-11-05
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public interface StaticDataCache 
{
	Collection<Object> refresh(String table, String criteria) throws Exception;
	
	Collection<Object> get(String table) throws Exception;
}
