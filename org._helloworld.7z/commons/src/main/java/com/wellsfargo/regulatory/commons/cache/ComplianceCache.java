package com.wellsfargo.regulatory.commons.cache;

import java.util.HashMap;
import java.util.Map;

import com.wellsfargo.regulatory.commons.cache.loader.ComplianceCacheLoader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class ComplianceCache
{

	private static ComplianceCache instance;
	private Map<String, Integer> complianceMatrixMap;

	private ComplianceCache()
	{

		complianceMatrixMap = new HashMap<String, Integer>();
	}

	public static ComplianceCache getInstance()
	{
		if (null == instance)
		{
			instance = new ComplianceCache();
			ComplianceCacheLoader.loadComplianceCache(instance);
		}

		return instance;
	}

	// public Map<String, List<File>>getDRLMap(){
	// return DRLMap;
	// }

	public void setValue(String key, Integer value)
	{

		complianceMatrixMap.put(key, value);
	}

	public Integer getValue(String key)
	{

		return complianceMatrixMap.get(key);
	}

}
