package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepDomainMappingDao;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepDomainMappingDaoImpl implements RegRepDomainMappingDao
{
	private static Logger logger = Logger.getLogger(RegRepDomainMappingDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public RegRepDomainMappingDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<RegRepDomainMapping> findAll()
	{
		logger.debug("Entering findAll() method");

		RegRepDomainMapping config = null;

		String query = QueryMaster.GET_ALL_DOMAIN_MAPPING;

		List<RegRepDomainMapping> configs = new ArrayList<RegRepDomainMapping>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

		for (Map<String, Object> row : rows)
		{
			config = new RegRepDomainMapping();

			config.setDomainName((String) row.get("DOMAIN_NAME"));
			config.setSrcCode((String) row.get("SRC_CODE"));
			config.setDtccCode((String) (row.get("DTCC_CODE")));

			configs.add(config);
		}

		logger.debug("Leaving findAll() method");

		return configs;
	}


}
