package com.wellsfargo.regulatory.commons.cache.loader;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.cache.ProductMappingCache;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepProductMapping;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepProductMappingDao;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class ProductMappingCacheLoader
{
	@Autowired
	private static RegRepProductMappingDao productMapDao;
	
	private static Logger logger = Logger.getLogger(ProductMappingCacheLoader.class.getName());

	public void setdRLConfigDao(RegRepProductMappingDao productMapDao)
	{
		ProductMappingCacheLoader.productMapDao = productMapDao;
	}

	public static void loadProductMappingCache(ProductMappingCache prdCache)
	{
		logger.debug("Entering loadProductMappingCache() method");

		String key 					= null;
		List<String> values 		= null;
		StringBuilder keyBuilder 	= null;

		List<RegRepProductMapping> configList = productMapDao.findAll();

		for (RegRepProductMapping config : configList)
		{
			keyBuilder = new StringBuilder();

			keyBuilder.append(StringUtils.strip(config.getSrcAssetClass()));
			keyBuilder.append(Constants.UNDERSCORE);
			keyBuilder.append(StringUtils.strip(config.getSrcPrdType()));
			keyBuilder.append(Constants.UNDERSCORE);
			keyBuilder.append(StringUtils.strip(config.getSrcSubPrdType()));
			keyBuilder.append(Constants.UNDERSCORE);
			keyBuilder.append(StringUtils.strip(config.getMappingType()));

			values = new ArrayList<String>(5);

			values.add(config.getDtccAssetClass());
			values.add(config.getDtccPrdType());
			values.add(config.getDtccSubPrdType());
			values.add(config.getJurisdiction());
			values.add(config.getFpmlProductType());

			key = keyBuilder.toString();

			prdCache.setValue(key, values);
		}

		logger.debug("Successfully instantiated Product Mapping cache.");
	}

}
