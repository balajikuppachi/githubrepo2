/**
 *
 */
package com.wellsfargo.regulatory.commons.cache;

import static com.wellsfargo.regulatory.commons.keywords.Constants.FPML;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MAPPER_DIR;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_VALUATION;
import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_SNAPSHOT;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC_EVENT_TYPE_NEW;
import static com.wellsfargo.regulatory.commons.keywords.Constants.DTCC_EVENT_TYPE_WITHDRAWAL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.ALL;
import static com.wellsfargo.regulatory.commons.keywords.Constants.UNDERSCORE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap;
import com.wellsfargo.regulatory.commons.cache.dao.impl.DRLConfigDaoImpl;
import com.wellsfargo.regulatory.commons.cache.loader.FpMLXpathMapCacheLoader;


/**
 * @author u337814
 *
 */
public class FpMLXpathMapCache 
{
	private static Logger logger = Logger.getLogger(FpMLXpathMapCache.class);
	
	@Autowired
	FpMLXpathMapCacheLoader cacheLoader;

	private static Map<String, List<FpMLXpathMap>> fpMLXpathMap;

	static
	{
		fpMLXpathMap = new HashMap<String, List<FpMLXpathMap>>(400);
	}

	public void setValue(String key, List<FpMLXpathMap> value)
	{
		fpMLXpathMap.put(key, value);
	}

	public List<FpMLXpathMap> getXpathMap(ReportingContext rptCntxt)
	{
		logger.debug("Entering getXpathMap() method");
		
		List<FpMLXpathMap> 	xpathList 	= null;
		String 				key			= null;

		key = generateKey(rptCntxt);

		xpathList = fpMLXpathMap.get(key);

		if(null == xpathList || xpathList.size() == 0 )
			xpathList = cacheLoader.loadFpMLXpathMapCache(this, key);

		logger.debug("Leaving getXpathMap() method");

		return xpathList;
	}

	public String generateKey(ReportingContext rptCntxt)
	{
		logger.debug("Entering generateKey() method");

		String fileSeparator 	= UNDERSCORE;
		String fileExtenstion 	= ".xls";

		String reportType 		= rptCntxt.getReportTypes().get(0);
		StringBuffer filePath 	= new StringBuffer("com");
		filePath.append(fileSeparator + "wellsfargo");
		filePath.append(fileSeparator + "regulatory");
		filePath.append(fileSeparator + FPML);
		filePath.append(fileSeparator + MAPPER_DIR);
		filePath.append(fileSeparator + rptCntxt.getAssetClass());
		filePath.append(fileSeparator + rptCntxt.getFpmlProductType());
		filePath.append(fileSeparator + reportType);
		filePath.append(fileExtenstion);
		
		if(MESSAGE_TYPE_VALUATION.equals(reportType))
			filePath.append(fileSeparator + ALL);
		
		else if (MESSAGE_TYPE_SNAPSHOT.equals(reportType))
		{
			/*if (rptCntxt.isEodExitMsg() )
			{
				filePath.append(fileSeparator + DTCC_EVENT_TYPE_WITHDRAWAL);
			}
			else
			{*/
				filePath.append(fileSeparator + DTCC_EVENT_TYPE_NEW);
			//}
		}
		else	
			filePath.append(fileSeparator + rptCntxt.getLifeCycleEvent());

		logger.debug("++++ Mapper Lookup File : "+StringUtils.trimToEmpty(filePath.toString()));
		
		logger.debug("Leaving generateKey() method");

		return filePath.toString();
	}

	public void setCacheLoader(FpMLXpathMapCacheLoader cacheLoader) 
	{
		this.cacheLoader = cacheLoader;
	}

}
