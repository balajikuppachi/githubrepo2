/**
 *
 */
package com.wellsfargo.regulatory.commons.cache.dao.impl;

import static com.wellsfargo.regulatory.commons.keywords.Constants.FIELD_NOT_APPLICABLE;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap.Attributes;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepFpMLXpathMappingDao;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;

/**
 * @author	Amit Rana
 * @date 	08/23/2014
 * @version 1.0
 */
public class RegRepFpMLXpathMappingDaoImpl implements RegRepFpMLXpathMappingDao 
{
	/* (non-Javadoc)
	 * @see com.wellsfargo.regulatory.commons.cache.dao.RegRepFpMLXpathMappingDao#findAll(java.lang.String)
	 */

	private static Log logger = LogFactory.getLog(RegRepFpMLXpathMappingDaoImpl.class);

	private Sheet getWBookSheet(String filePath, String lifeCycleEvent)
	{
		logger.debug("Entering getWBookSheet() method");

		Sheet sheet = null;
		InputStream in = null;
		String errorstring = null;
		Workbook wb = null;

		if (null == filePath)
		{
			return sheet;
		}

		try
		{
			logger.debug("$$$$ MAPPING-SELECTION File-Path : " + filePath);
			logger.debug("$$$$ WORKSHEET-LOOKUP for LifeCycle-Event : " + lifeCycleEvent);

			in = this.getClass().getResourceAsStream(filePath);
			wb = WorkbookFactory.create(in);

			if (null != wb) sheet = wb.getSheet(lifeCycleEvent);

		}
		catch (InvalidFormatException | IOException e)
		{
			errorstring = "Unable to get the workbook for xpath mapper due to : " + e.getMessage();
			logger.error(errorstring, e);
			return sheet;
			//throw new MessagingException("xpath:mapper:wb:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorstring, e);
		}
		finally
		{
			try
			{
				if (null != in) in.close();
				wb = null;
			}
			catch (IOException e)
			{
				logger.error("######### Unable to close the input stream ", e);
			}
		}

		logger.debug("Leaving getWBookSheet() method");

		return sheet;
	}

	@Override
	//public String getXpathAttributeMap(String filePath, String lifeCycleEvent)
	public List<FpMLXpathMap> getXpathAttributeMap(String filePath, String lifeCycleEvent)
	{
		logger.debug("Entering getXpathAttributeMap() method");

		List<FpMLXpathMap> xPathMapList = null;
		//String xPathMapList 			= null;
		int rowBeginIndex 				= 1;
		int cellBeginIndex 				= 0;
		Row row 						= null;
		Cell cell 						= null;
		String targetXpath 				= null;
		String srcXpath 				= null;
		boolean isHardCoded 			= false;
		String dataType 				= null;
		String condition 				= null;
		String usageXpath 				= null;
		String usageConditoin 			= null;
		String classTypeCondition 		= null;
		Sheet sheet 					= null;
		FpMLXpathMap xPathMap 			= null;
		Attributes attributes 			= null;

		//if(filePath.contains("/")) return "amit";

		sheet = getWBookSheet(filePath, lifeCycleEvent);
		
		if (null == sheet)
		{
			logger.error("######### xPath mapping sheet not found for filePath " + filePath+" LCE : "+lifeCycleEvent);
			return xPathMapList;
			//throw new MessagingException("xpath:maper:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Error while getting the xPath mapping sheet");
		}

		int rowCount = sheet.getLastRowNum();
		logger.debug("Total Number of Rows: " + (rowCount + 1));

		if (rowCount > 0)
		{
			xPathMapList = new ArrayList<>();
			//xPathMapList = new String();
		}

		try
		{
			for (int rowCounter = rowBeginIndex; rowCounter <= rowCount; rowCounter++)
			{
				row = sheet.getRow(rowCounter);

				if (null == row)
				{
					continue;
				}

				/*** Checking if the value is present ***/
				cell = row.getCell(cellBeginIndex);
				if (null != cell && cell.getStringCellValue().equalsIgnoreCase("A")) continue;

				/*** Cell:1 Temp tweak for testing - removing the non mapped values ***/
				cell = row.getCell(cellBeginIndex + 1);
				if (null != cell && cell.getStringCellValue().equalsIgnoreCase("NM")) continue;
				
				/*** Cell:2 ***/
				cell = row.getCell(cellBeginIndex + 2);
				
				/*** Temp tweak in order to avoid null rows of excel part 1 ***/
				if (null == cell) continue;

				isHardCoded		= false;
				targetXpath 	= null;
				srcXpath 		= null;
				dataType 		= null;
				condition 		= null;
				usageXpath 		= null;
				classTypeCondition = null;
				usageConditoin 	= null;

				targetXpath = cell.getStringCellValue();
				
				/*** Temp tweak in order to avoid null rows of excel part 2 ***/
				if (StringUtils.isBlank(targetXpath)) continue;

				xPathMap 	= new FpMLXpathMap();
				attributes 	= xPathMap.getMappingAttributes();
				xPathMap.setFpmlXpath(targetXpath);

				/*** Cell:4 ***/
				cell 		= row.getCell(cellBeginIndex + 4);
				srcXpath 	= cell.getStringCellValue();
				attributes.setSrcXpath(srcXpath);

				/*** Cell:5 ***/
				cell = row.getCell(cellBeginIndex + 5);
				if (null != cell)
				{
					isHardCoded = ConversionUtils.stringToBoolean(cell.getStringCellValue());
				}
				attributes.setIsHardCoded(isHardCoded);

				/*** Cell:6 ***/
				cell = row.getCell(cellBeginIndex + 6);
				if (null != cell)
				{
					dataType = cell.getStringCellValue();
				}
				else
				{
					dataType = FIELD_NOT_APPLICABLE;
				}
				attributes.setDataType(dataType);
				
				/*** Cell:7 ***/
				cell = row.getCell(cellBeginIndex + 7);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					condition = cell.getStringCellValue();
				}
				else
				{
					condition = FIELD_NOT_APPLICABLE;
				}
				attributes.setCondition(condition);

				/*** Cell:11 ***/
				cell = row.getCell(cellBeginIndex + 11);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					usageXpath = cell.getStringCellValue();
				}
				else
				{
					usageXpath = FIELD_NOT_APPLICABLE;
				}
				attributes.setUsageXpath(usageXpath);

				/*** Cell:12 ***/
				cell = row.getCell(cellBeginIndex + 12);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					usageConditoin = cell.getStringCellValue();
				}
				else
				{
					usageConditoin = FIELD_NOT_APPLICABLE;
				}
				attributes.setUsageConditoin(usageConditoin);

				/*** Cell:13 ***/
				cell = row.getCell(cellBeginIndex + 13);
				if (null != cell && !StringUtils.isBlank(cell.getStringCellValue()))
				{
					classTypeCondition = cell.getStringCellValue();
				}
				else
				{
					classTypeCondition = FIELD_NOT_APPLICABLE;
				}
				attributes.setClassTypeCondition(classTypeCondition);
				
				
				xPathMapList.add(xPathMap);
			}
		}
		catch (Exception e)
		{
			logger.error("######### Failed to read xpath mapping sheet " + filePath + " for LCE "+lifeCycleEvent+" Error : ", e);
			//throw new MessagingException("xpath:maper:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, "Failed to read xpath mapping sheet ", context.getMessageId(), e);
		}
		finally
		{
			sheet = null;
		}

		logger.debug("Leaving getXpathAttributeMap() method");

		return xPathMapList;
	}

}
