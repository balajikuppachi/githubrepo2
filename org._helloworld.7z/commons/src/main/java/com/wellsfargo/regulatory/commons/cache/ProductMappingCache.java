package com.wellsfargo.regulatory.commons.cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wellsfargo.regulatory.commons.cache.loader.ProductMappingCacheLoader;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class ProductMappingCache
{

	private static ProductMappingCache instance;
	private Map<String, List<String>> productsMap;

	private ProductMappingCache()
	{

		productsMap = new HashMap<String, List<String>>();
	}

	public static ProductMappingCache getInstance()
	{
		if (null == instance)
		{
			instance = new ProductMappingCache();
			ProductMappingCacheLoader.loadProductMappingCache(instance);
		}

		return instance;
	}

	// public Map<String, List<File>>getDRLMap(){
	// return DRLMap;
	// }

	public void setValue(String key, List<String> values)
	{
		productsMap.put(key, values);
	}

	public List<String> getValues(String key)
	{

		return productsMap.get(key);
	}
}
