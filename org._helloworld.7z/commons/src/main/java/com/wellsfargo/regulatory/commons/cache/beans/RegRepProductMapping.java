package com.wellsfargo.regulatory.commons.cache.beans;

import java.util.Date;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepProductMapping
{

	private String srcAssetClass;
	private String srcPrdType;
	private String srcSubPrdType;
	private String dtccAssetClass;
	private String dtccPrdType;
	private String dtccSubPrdType;
	private String dtccTransactionType;
	private String mappingType;
	private String jurisdiction;
	private String fpmlProductType;
	private Date createDateTime;

	public String getSrcAssetClass()
	{
		return srcAssetClass;
	}

	public void setSrcAssetClass(String srcAssetClass)
	{
		this.srcAssetClass = srcAssetClass;
	}

	public String getSrcPrdType()
	{
		return srcPrdType;
	}

	public void setSrcPrdType(String srcPrdType)
	{
		this.srcPrdType = srcPrdType;
	}

	public String getSrcSubPrdType()
	{
		return srcSubPrdType;
	}

	public void setSrcSubPrdType(String srcSubPrdType)
	{
		this.srcSubPrdType = srcSubPrdType;
	}

	public String getDtccAssetClass()
	{
		return dtccAssetClass;
	}

	public void setDtccAssetClass(String dtccAssetClass)
	{
		this.dtccAssetClass = dtccAssetClass;
	}

	public String getDtccPrdType()
	{
		return dtccPrdType;
	}

	public void setDtccPrdType(String dtccPrdType)
	{
		this.dtccPrdType = dtccPrdType;
	}

	public String getDtccSubPrdType()
	{
		return dtccSubPrdType;
	}

	public void setDtccSubPrdType(String dtccSubPrdType)
	{
		this.dtccSubPrdType = dtccSubPrdType;
	}

	public String getDtccTransactionType()
	{
		return dtccTransactionType;
	}

	public void setDtccTransactionType(String dtccTransactionType)
	{
		this.dtccTransactionType = dtccTransactionType;
	}

	public String getMappingType()
	{
		return mappingType;
	}

	public void setMappingType(String mappingType)
	{
		this.mappingType = mappingType;
	}

	public String getJurisdiction()
	{
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction)
	{
		this.jurisdiction = jurisdiction;
	}

	public String getFpmlProductType()
	{
		return fpmlProductType;
	}

	public void setFpmlProductType(String fpmlProductType)
	{
		this.fpmlProductType = fpmlProductType;
	}

	public Date getCreateDateTime()
	{
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime)
	{
		this.createDateTime = createDateTime;
	}

	@Override
	public String toString()
	{
		return "RegRepProductMapping [srcAssetClass=" + srcAssetClass + ", srcPrdType=" + srcPrdType + ", srcSubPrdType=" + srcSubPrdType + ", dtccAssetClass=" + dtccAssetClass + ", dtccPrdType="
		        + dtccPrdType + ", dtccSubPrdType=" + dtccSubPrdType + ", dtccTransactionType=" + dtccTransactionType + ", mappingType=" + mappingType + ", jurisdiction=" + jurisdiction
		        + ", fpmlProductType=" + fpmlProductType + ", createDateTime=" + createDateTime + "]";
	}

}