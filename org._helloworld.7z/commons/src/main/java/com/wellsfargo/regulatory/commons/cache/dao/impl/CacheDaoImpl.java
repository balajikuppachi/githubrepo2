package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.cache.dao.CacheDao;

/******************************************************************************
 * Filename    : CacheDaoImpl.java
 * Author      : Rama Nuti
 * Date Created: 2015-11-05
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class CacheDaoImpl implements CacheDao 
{
    protected static final Logger LOG = Logger.getLogger(CacheDaoImpl.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Collection<Object> loadrows(String table, final Map<String, String> attrmap, String criteria, final Class clazz) throws Exception 
    {
        final Collection<Object> rows 	= new ArrayList<Object>();
        StringBuilder stringBuilder 	= new StringBuilder("SELECT * FROM ");
        
        stringBuilder.append(table).append(" WHERE ").append(StringUtils.isEmpty(criteria) ? "1=1" : criteria);
        
        getJdbcTemplate().query(stringBuilder.toString(), new Object[]{}, new RowMapper() 
        {
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
            {
                try 
                {
                    Object objInstance 					= clazz.newInstance();
                    ResultSetMetaData resultSetMetaData = rs.getMetaData();
                    
                    for (int rsIndex = 1; rsIndex <= resultSetMetaData.getColumnCount(); rsIndex++) 
                    {
                        String colname = resultSetMetaData.getColumnName(rsIndex);
                        
                        if (!attrmap.containsKey(colname)) 
                        {
                            continue;
                        }
                        
                        String prop = attrmap.get(colname);
                        int coltype = resultSetMetaData.getColumnType(rsIndex);
                        
                        //LOG.info("@@@@ ColType " + coltype);

                        switch (coltype) 
                        {
                            case Types.CHAR: // 1
                            case Types.LONGVARCHAR:	// -1
                                BeanUtils.setProperty(objInstance, prop, rs.getString(rsIndex));
                                break;
                            case Types.VARCHAR: // 12
                                BeanUtils.setProperty(objInstance, prop, rs.getString(rsIndex));
                                break;
                            case Types.INTEGER: // 4
                                BeanUtils.setProperty(objInstance, prop, rs.getInt(rsIndex));
                                break;
                            case Types.NUMERIC: // 2
                                //BeanUtils.setProperty(objInstance, prop, rs.getBigDecimal(rsIndex));
                                //break;
                    			switch (resultSetMetaData.getScale(rsIndex)) 
                    			{
	                    			case 0:
	                                    BeanUtils.setProperty(objInstance, prop, rs.getInt(rsIndex));
	                                    break;
	                    			case 2:
	                                    BeanUtils.setProperty(objInstance, prop, rs.getDouble(rsIndex));
	                                    break;
	                    			case -127:
	                                    BeanUtils.setProperty(objInstance, prop, rs.getDouble(rsIndex));
	                                    break;
	                    			default:
	                                    BeanUtils.setProperty(objInstance, prop, rs.getBigDecimal(rsIndex));
                    			}
                    			break;

                            case Types.TIMESTAMP: // 93
                            case Types.DATE: // 91
                                BeanUtils.setProperty(objInstance, prop, new Date(rs.getTimestamp(rsIndex).getTime()));
                                break;
                        }
                    }
                    
                    rows.add(objInstance);
                }
                catch (Exception ex) 
                {
                    LOG.error("######### Exception occured : "+ExceptionUtils.getFullStackTrace(ex));
                }
                return null;
            }
        });
        
        return rows;
    }

	@SuppressWarnings("unused")
	private Class<?> DBDataTypeToJAVADataType(int type, int scale) 
	{
		Class<?> javaTypeClass = null;
		
		switch (type) 
		{
			case Types.LONGVARCHAR: // -1
				javaTypeClass = Long.class;
				break;
			case Types.CHAR: // 1
				javaTypeClass = Character.class;
				break;
			case Types.NUMERIC: // 2
				switch (scale) 
				{
					case 0:
						javaTypeClass = Integer.class;
						break;
					case 2:
						javaTypeClass = Double.class;
						break;
					case -127:
						javaTypeClass = Double.class;
						break;
					default:
						javaTypeClass = Integer.class;
				}
				break;
			case Types.INTEGER:// 4
				javaTypeClass = Integer.class;
				break;
			case Types.VARCHAR: // 12
				javaTypeClass = String.class;
				break;
			case Types.DATE: // 91
				javaTypeClass = Date.class;
				break;
			case Types.TIMESTAMP: // 93
				javaTypeClass = Date.class;
				break;
			case Types.BLOB:
				javaTypeClass = Blob.class;
				break;
			default:
				javaTypeClass = String.class;
		}
		
		return javaTypeClass;
	}

    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Object[]> getTablesLastChanged() 
    {
        final List<Object[]> rows = new ArrayList<Object[]>();
        String sql = "SELECT * FROM REGREP_REFRESH_TABLES";
        
        getJdbcTemplate().query(sql, new RowMapper() 
        {
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
            {
                Object[] obj 	= new Object[2];
                obj[0] 			= rs.getString("TABLE_NAME");
                obj[1] 			= rs.getTimestamp("LAST_UPDATE_TIMESTAMP");
                
                rows.add(obj);
                return null;
            }
        });
        
        return rows;
    }

    public JdbcTemplate getJdbcTemplate() 
    {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) 
    {
        this.jdbcTemplate = jdbcTemplate;
    }

}
