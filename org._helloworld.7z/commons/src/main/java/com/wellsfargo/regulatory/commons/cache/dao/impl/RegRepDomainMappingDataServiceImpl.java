package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepDomainMappingDataService;
import com.wellsfargo.regulatory.commons.cache.dao.StaticDataCache;
import com.wellsfargo.regulatory.commons.keywords.Constants;

public class RegRepDomainMappingDataServiceImpl implements RegRepDomainMappingDataService, Observer 
{
	private static final Logger LOG = Logger.getLogger(RegRepDomainMappingDataServiceImpl.class.getName());

    private Map<String, String> m_regRepDomainMappingMap = Collections.synchronizedMap(new HashMap<String, String>());
    
    private static final String REG_REP_DOMAIN_MAPPING = "REG_REP_DOMAIN_MAPPING";
    
    private StaticDataCache m_cache;
    
	public RegRepDomainMappingDataServiceImpl()
	{
		
	}
	
	public void loadDomainMappings(Collection<Object> rows) throws Exception 
	{
        if(LOG.isDebugEnabled()) LOG.debug("Loading Domain Mapping cache...");
        
		for (Object o : rows) 
		{
			RegRepDomainMapping regRepDMObj = (RegRepDomainMapping)o; 

			setValue(StringUtils.join(new String[]{regRepDMObj.getDomainName(), Constants.UNDERSCORE, regRepDMObj.getSrcCode()}) , regRepDMObj.getDtccCode());	        
		}
        
		if(LOG.isDebugEnabled()) LOG.debug("Domain Mapping Size:" + m_regRepDomainMappingMap.size());
	}
	
	
	/**
	 * Method called at the startup to load the cache.
	 */
    public void initializeRegRepDomainMappings()
    {
    	try 
    	{
			this.loadDomainMappings(this.m_cache.refresh(REG_REP_DOMAIN_MAPPING, null));				
		}
		catch (Exception ex) 
    	{
			LOG.error("######### Error encountered while initializing Domain Mapping", ex);
		}
    	
		Observable o = (Observable)getCache();
		o.addObserver(this);
    }
	
    /**
     * This method is sent a notification by the Observable class 
     * when any Inserts/updates/deletes are made on the table 
     */
	@Override
	public void update(Observable o, Object arg) 
	{
    	if(REG_REP_DOMAIN_MAPPING.equals(arg.toString())) 
    	{
			try 
			{
				LOG.info("Notification received to refresh cache from table:" + REG_REP_DOMAIN_MAPPING);
				
				Collection<Object> rows = this.m_cache.get(REG_REP_DOMAIN_MAPPING);
				
				synchronized (this.m_regRepDomainMappingMap) 
				{
					this.m_regRepDomainMappingMap.clear();
					
					this.loadDomainMappings(rows);
				}
				
				LOG.info("Cache has been updated from table : " + REG_REP_DOMAIN_MAPPING);
			}
			catch(Exception ex) 
			{
				LOG.error("######### Could not refresh mappings", ex);
			}			
    	}
    }
	
    public Map<String, String> getDomainMappingsMap() throws Exception 
    {
        return m_regRepDomainMappingMap;
    }
    
    /**
	 * @return the m_cache
	 */
	public StaticDataCache getCache() 
	{
		return m_cache;
	}

	/**
	 * @param mCache the m_cache to set
	 */
	public void setCache(StaticDataCache mCache) 
	{
		m_cache = mCache;
	}
	
	public void setValue(String key, String value)
	{
		m_regRepDomainMappingMap.put(key, value);
	}

	public String getValue(String key)
	{
		return m_regRepDomainMappingMap.get(key);
	}

	public Set<String> getKeys()
	{
		return m_regRepDomainMappingMap.keySet();
	}

	
}
