package com.wellsfargo.regulatory.commons.cache.loader;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.cache.ComplianceCache;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepComplianceMatrix;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepComplainceMatrixDao;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class ComplianceCacheLoader
{

	@Autowired
	private static RegRepComplainceMatrixDao complianceMatrixDao;

	private static Logger logger = Logger.getLogger(ComplianceCacheLoader.class.getName());

	public void setdRLConfigDao(RegRepComplainceMatrixDao complianceMatrixDao)
	{
		ComplianceCacheLoader.complianceMatrixDao = complianceMatrixDao;
	}

	public static void loadComplianceCache(ComplianceCache compCache)
	{
		StringBuilder key 	= null;
		Integer value 		= null;
		String keySeperator = Constants.UNDERSCORE;

		List<RegRepComplianceMatrix> configList = complianceMatrixDao.findAll();

		for (RegRepComplianceMatrix config : configList)
		{
			key = new StringBuilder();

			key.append(config.getJurisdiction());
			key.append(keySeperator);

			/*
			 * Amit - Ignoring Region for now, since compliance doesn't differ based on a region
			 * with in a jurisdiction. key.append(config.getRegion()); key.append(keySeperator);
			 */

			key.append(config.getRepository());
			key.append(keySeperator);
			key.append(config.getReportType());

			value = config.getComplianceMinutes();

			compCache.setValue(key.toString(), value);
		}

		logger.debug("Successfully instantiated Compliance cache.");
	}

}
