package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.Map;

public interface RegRepDomainMappingDataService 
{
    Map<String, String> getDomainMappingsMap() throws Exception;

    
}
