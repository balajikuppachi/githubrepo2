package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.List;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepProductMapping;

public interface RegRepProductMappingDao {
	
	public List<RegRepProductMapping> findAll();

}
