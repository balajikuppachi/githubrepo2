package com.wellsfargo.regulatory.commons.cache.loader;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.cache.DRLCache;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepRulesConfig;
import com.wellsfargo.regulatory.commons.cache.dao.DRLConfigDao;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RulesCacheLoader
{

/*	@Autowired
	private static DRLConfigDao dRLConfigDao;*/

	private static Logger logger = Logger.getLogger(RulesCacheLoader.class.getName());

	public void setdRLConfigDao(DRLConfigDao dRLConfigDao)
	{
		//RulesCacheLoader.dRLConfigDao = dRLConfigDao;
	}

	public static void loadRulesCache(DRLCache drlCache)
	{
		//logger.debug("Entering loadRulesCache() method");

		//String key = null;
		//List<String> values = null;

		/*
		 * Testing the connection via one insert DRLConfig config1 = new DRLConfig(3,
		 * "DRL_filters_cftc_dtcc", "CFTC", "DTCC", "report",
		 * "drools/report/cftc/dtcc/SDR_message_rules.xls"); dRLConfigDao.insertConfig(config1);test
		 * code ends here.
		 */

		/*List<RegRepRulesConfig> configList = dRLConfigDao.findAll();

		for (RegRepRulesConfig config : configList)
		{

			key = config.getDrlKey();
			values = drlCache.getValues(key);

			if (null == values)
			{
				values = new ArrayList<String>(5);
			}

			values.add(config.getFileLocation());
			drlCache.setValue(key, values);
		}*/

		//logger.debug("Successfully instantiated DRL cache.");
	}

}
