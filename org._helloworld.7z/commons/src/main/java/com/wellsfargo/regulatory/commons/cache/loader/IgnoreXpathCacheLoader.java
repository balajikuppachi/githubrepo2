package com.wellsfargo.regulatory.commons.cache.loader;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.cache.IgnoreXpathCache;
import com.wellsfargo.regulatory.commons.cache.beans.DupCheckXpathBean;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepDupCheckMappingDao;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author	Amit Rana
 * @date 	03/03/2015
 * @version 1.0
 */

public class IgnoreXpathCacheLoader 
{
	@Autowired
	private static RegRepDupCheckMappingDao dupCheckMapDao;
	
	private static Logger logger = Logger.getLogger(IgnoreXpathCacheLoader.class.getName());

	public void setdRLConfigDao(RegRepDupCheckMappingDao dupCheckMapDao)
	{
		IgnoreXpathCacheLoader.dupCheckMapDao = dupCheckMapDao;
	}

	public static void loadIgnoreXpathCache(IgnoreXpathCache xPathCache)
	{
		logger.debug("Entering loadIgnoreXpathCache() method");

		StringBuilder key 	= null;
		List<String> values = null;
		
		List<DupCheckXpathBean> configList = dupCheckMapDao.findAll();

		for (DupCheckXpathBean config : configList)
		{
			key = new StringBuilder();
						
			if(null == config) continue;
			
			if(null == config.getReportType() || null == config.getSdrProductType()) continue;
						
			key.append(config.getReportType().toUpperCase().trim());
			key.append(Constants.UNDERSCORE);
			key.append(config.getSdrProductType().toUpperCase().trim());
			
			values = xPathCache.getValues(key.toString());
			
			if(null == values)
			{
				values = new ArrayList<String>(5);
				xPathCache.setValue(key.toString(), values);
			}

			values.add(config.getXpath());			
		}

		logger.debug("Successfully instantiated Duplicate Check Mapping cache.");
	}

}
