package com.wellsfargo.regulatory.commons.cache.loader;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.cache.DomainMappingCache;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepDomainMappingDao;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class DomainMappingCacheLoader
{
	@Autowired
	private static RegRepDomainMappingDao domainMapDao;

	private static Logger logger = Logger.getLogger(DomainMappingCacheLoader.class.getName());

	public void setdRLConfigDao(RegRepDomainMappingDao domainMapDao)
	{
		DomainMappingCacheLoader.domainMapDao = domainMapDao;
	}

	public static void loadDomainCache(DomainMappingCache domainCache)
	{
		logger.debug("Entering loadDomainCache() method");

		String key = null;
		String value = null;

		List<RegRepDomainMapping> configList = domainMapDao.findAll();

		for (RegRepDomainMapping config : configList)
		{

			key = config.getDomainName() + Constants.UNDERSCORE + config.getSrcCode();
			value = config.getDtccCode();

			domainCache.setValue(key, value);
		}

		logger.debug("Successfully loaded Domain Mapping cache " + domainCache);

		logger.debug("Leaving loadDomainCache() method");

		return;
	}

}
