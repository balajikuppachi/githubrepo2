package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/******************************************************************************
 * Filename    : CacheDao.java
 * Author      : Rama Nuti
 * Date Created: 2015-11-05
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public interface CacheDao 
{
	@SuppressWarnings("rawtypes")
    Collection<Object> loadrows(String table, Map<String, String> attrmap, String criteria, Class clazz) throws Exception;
    
    List<Object[]> getTablesLastChanged();
}
