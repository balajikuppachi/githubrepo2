package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.beans.DRLConfig;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepRulesConfig;
import com.wellsfargo.regulatory.commons.cache.dao.DRLConfigDao;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class DRLConfigDaoImpl implements DRLConfigDao
{
	private static Logger logger = Logger.getLogger(DRLConfigDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public DRLConfigDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}

	public void insertConfig(DRLConfig drlConfig)
	{
		logger.debug("Entering insertConfig() method");

		String query = QueryMaster.INSERT_CONFIG;

		jdbcTemplate.update(query, new Object[]
		{ drlConfig.getId(), drlConfig.getDrlKey(), drlConfig.getReportingJurisdiction(), drlConfig.getRepository(), drlConfig.getDrlType(), drlConfig.getFileLocation() });

		logger.debug("Leaving insertConfig() method");
	}

	public DRLConfig findConfigByKey(String key)
	{
		logger.debug("Entering findConfigByKey() method");

		DRLConfig config = null;

		logger.debug("Leaving findConfigByKey() method");

		return config;
	}

	public List<RegRepRulesConfig> findAll()
	{
		logger.debug("Entering findAll() method");

		String query = QueryMaster.GET_ALL_CONFIG;

		List<RegRepRulesConfig> configs = new ArrayList<RegRepRulesConfig>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

		for (Map<String, Object> row : rows)
		{
			RegRepRulesConfig config = new RegRepRulesConfig();

			config.setRegRepRulesConfigId((Integer) row.get("REG_REP_RULES_CONFIG_ID"));
			config.setReportingJurisdiction((String) row.get("REPORTING_JURISDICTION"));
			config.setRepository((String) (row.get("REPOSITORY")));
			config.setFileLocation((String) (row.get("FILE_LOCATION")));
			config.setDrlType((String) (row.get("DRL_TYPE")));
			config.setDrlKey((String) (row.get("DRL_KEY")));

			configs.add(config);

		}

		logger.debug("Leaving findAll() method");

		return configs;

	}

}
