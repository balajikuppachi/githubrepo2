package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.List;

import com.wellsfargo.regulatory.commons.cache.beans.DupCheckXpathBean;

public interface RegRepDupCheckMappingDao {
	
	public List<DupCheckXpathBean> findAll();

}
