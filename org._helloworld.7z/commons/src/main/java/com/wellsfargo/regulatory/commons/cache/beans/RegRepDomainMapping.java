package com.wellsfargo.regulatory.commons.cache.beans;

import java.util.Date;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public class RegRepDomainMapping implements java.io.Serializable
{
    // Fields    

	 private static final long serialVersionUID = 1045827890454903057L;
	
	 private String domainName;
     private String srcCode;
     private String srcDesc;
     private String dtccCode;
     private String dtccDesc;
     private Date createDateTime;


     // Constructors

     /** default constructor */
     public RegRepDomainMapping() 
     {
     }

     /** minimal constructor */
     public RegRepDomainMapping(String domainName, String srcCode, String srcDesc, String dtccCode, String dtccDesc) 
     {
        this.domainName = domainName;
        this.srcCode = srcCode;
        this.srcDesc = srcDesc;
        this.dtccCode = dtccCode;
        this.dtccDesc = dtccDesc;
     }
    
     /** full constructor */
     public RegRepDomainMapping(String domainName, String srcCode, String srcDesc, String dtccCode, String dtccDesc, Date createDateTime) 
     {
        this.domainName = domainName;
        this.srcCode = srcCode;
        this.srcDesc = srcDesc;
        this.dtccCode = dtccCode;
        this.dtccDesc = dtccDesc;
        this.createDateTime = createDateTime;
     }
    
    // Property accessors

    public String getDomainName() 
    {
        return this.domainName;
    }
    
    public void setDomainName(String domainName) 
    {
        this.domainName = domainName;
    }

    public String getSrcCode() 
    {
        return this.srcCode;
    }
    
    public void setSrcCode(String srcCode) 
    {
        this.srcCode = srcCode;
    }

    public String getSrcDesc() 
    {
        return this.srcDesc;
    }
    
    public void setSrcDesc(String srcDesc) 
    {
        this.srcDesc = srcDesc;
    }

    public String getDtccCode() 
    {
        return this.dtccCode;
    }
    
    public void setDtccCode(String dtccCode) 
    {
        this.dtccCode = dtccCode;
    }

    public String getDtccDesc() 
    {
        return this.dtccDesc;
    }
    
    public void setDtccDesc(String dtccDesc) 
    {
        this.dtccDesc = dtccDesc;
    }

    public Date getCreateDateTime() 
    {
        return this.createDateTime;
    }
    
    public void setCreateDateTime(Date createDateTime) 
    {
        this.createDateTime = createDateTime;
    }

    public boolean equals(Object other) 
    {
         if ( (this == other ) ) return true;
		 if ( (other == null ) ) return false;
		 if ( !(other instanceof RegRepDomainMapping) ) return false;
		 RegRepDomainMapping castOther = ( RegRepDomainMapping ) other; 
         
		 return ( (this.getDomainName()==castOther.getDomainName()) || ( this.getDomainName()!=null && castOther.getDomainName()!=null && this.getDomainName().equals(castOther.getDomainName()) ) )
				 && ( (this.getSrcCode()==castOther.getSrcCode()) || ( this.getSrcCode()!=null && castOther.getSrcCode()!=null && this.getSrcCode().equals(castOther.getSrcCode()) ) )
				 && ( (this.getSrcDesc()==castOther.getSrcDesc()) || ( this.getSrcDesc()!=null && castOther.getSrcDesc()!=null && this.getSrcDesc().equals(castOther.getSrcDesc()) ) )
				 && ( (this.getDtccCode()==castOther.getDtccCode()) || ( this.getDtccCode()!=null && castOther.getDtccCode()!=null && this.getDtccCode().equals(castOther.getDtccCode()) ) )
				 && ( (this.getDtccDesc()==castOther.getDtccDesc()) || ( this.getDtccDesc()!=null && castOther.getDtccDesc()!=null && this.getDtccDesc().equals(castOther.getDtccDesc()) ) );
    }
   
   public int hashCode() 
   {
         int result = 17;
         
         result = 37 * result + ( getDomainName() == null ? 0 : this.getDomainName().hashCode() );
         result = 37 * result + ( getSrcCode() == null ? 0 : this.getSrcCode().hashCode() );
         result = 37 * result + ( getSrcDesc() == null ? 0 : this.getSrcDesc().hashCode() );
         result = 37 * result + ( getDtccCode() == null ? 0 : this.getDtccCode().hashCode() );
         result = 37 * result + ( getDtccDesc() == null ? 0 : this.getDtccDesc().hashCode() );
         
         return result;
   	}   
   
   	
	@Override
	public String toString()
	{
		return "RegRepDomainMapping [domainName=" + domainName + ", dtccCode=" + dtccCode + ", dtccDesc=" + dtccDesc + ", srcCode=" + srcCode + ", srcDesc=" + srcDesc + ", createDateTime="
		        + createDateTime + "]";
	}

	
	
}
