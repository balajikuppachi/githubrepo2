package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wellsfargo.regulatory.commons.cache.beans.DupCheckXpathBean;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepDupCheckMappingDao;
import com.wellsfargo.regulatory.commons.keywords.QueryMaster;

/**
 * @author	Amit Rana
 * @date 	03/03/2015
 * @version 1.0
 */

public class RegRepDupCheckMappingDaoImpl implements RegRepDupCheckMappingDao 
{
	/* (non-Javadoc)
	 * @see com.wellsfargo.regulatory.commons.cache.dao.RegRepFpMLXpathMappingDao#findAll(java.lang.String)
	 */

	private static Log logger = LogFactory.getLog(RegRepDupCheckMappingDaoImpl.class);	
	
	private JdbcTemplate jdbcTemplate;

	public RegRepDupCheckMappingDaoImpl(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}
	
	@Override
	public List<DupCheckXpathBean> findAll()
	{
		logger.debug("Entering findAll() method");

		DupCheckXpathBean config = null;

		String query = QueryMaster.GET_ALL_DUP_CHECK_MAPPING;

		List<DupCheckXpathBean> configs = new ArrayList<DupCheckXpathBean>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);

		for (Map<String, Object> row : rows)
		{
			config = new DupCheckXpathBean();

			config.setSdrProductType((String) row.get("SDR_PRODUCT_TYPE"));
			config.setXpath((String) row.get("IGNORE_XPATH"));
			config.setReportType((String)row.get("REPORT_TYPE"));
			
			configs.add(config);
		}

		logger.debug("Leaving findAll() method");

		return configs;

	}

}
