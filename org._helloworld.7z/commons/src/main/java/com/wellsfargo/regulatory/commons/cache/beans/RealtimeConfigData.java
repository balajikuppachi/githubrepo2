package com.wellsfargo.regulatory.commons.cache.beans;

import java.util.Date;

/******************************************************************************
 * Filename    : RealtimeConfigData.java
 * Author      : Rama Nuti
 * Date Created: 2015-11-05
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class RealtimeConfigData 
{
	private long propertyId;
	private String propertyName;
	private String propertyValue;
    private Date createUserTimestamp;
    private Date updateUserTimestamp;
    private String createUserId;
    private String updateUserId;
	
	public RealtimeConfigData() {
	}

	public RealtimeConfigData(long propertyId) 
	{
		this.propertyId = propertyId;
	}
	
	public RealtimeConfigData(long propertyId, String propertyName, String propertyValue,  Date createUserTimestamp, Date updateUserTimestamp, String createUserId, String updateUserId) 
	{
	   this.propertyId 			= propertyId;
	   this.propertyName 		= propertyName;
	   this.propertyValue 		= propertyValue;
       this.createUserTimestamp = createUserTimestamp;
       this.updateUserTimestamp = updateUserTimestamp;
       this.createUserId 		= createUserId;
       this.updateUserId 		= updateUserId;
	}


	/**
	 * @return the propertyId
	 */
	public long getPropertyId() {
		return propertyId;
	}


	/**
	 * @param propertyId the propertyId to set
	 */
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}


	/**
	 * @return the propertyName
	 */
	public String getPropertyName() {
		return propertyName;
	}


	/**
	 * @param propertyName the propertyName to set
	 */
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}


	/**
	 * @return the propertyValue
	 */
	public String getPropertyValue() {
		return propertyValue;
	}


	/**
	 * @param propertyValue the propertyValue to set
	 */
	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

    public Date getCreateUserTimestamp() {
        return this.createUserTimestamp;
    }
    
    public void setCreateUserTimestamp(Date createUserTimestamp) {
        this.createUserTimestamp = createUserTimestamp;
    }
    public Date getUpdateUserTimestamp() {
        return this.updateUserTimestamp;
    }
    
    public void setUpdateUserTimestamp(Date updateUserTimestamp) {
        this.updateUserTimestamp = updateUserTimestamp;
    }
    public String getCreateUserId() {
        return this.createUserId;
    }
    
    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }
    public String getUpdateUserId() {
        return this.updateUserId;
    }
    
    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }


}
