package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Observable;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.wellsfargo.regulatory.commons.cache.dao.CacheDao;
import com.wellsfargo.regulatory.commons.cache.dao.StaticDataCache;

/******************************************************************************
 * Filename    : StaticDataCacheImpl.java
 * Author      : Rama Nuti
 * Date Created: 2015-11-05
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

@SuppressWarnings("deprecation")
public class StaticDataCacheImpl extends Observable implements StaticDataCache 
{
    @SuppressWarnings("unused")
	public static void main(String[] args) throws Exception 
    {
        XmlBeanFactory xmlBeanFactory 		= new XmlBeanFactory(new ClassPathResource("cache-config.xml"));
        PropertyPlaceholderConfigurer cfg 	= new PropertyPlaceholderConfigurer();
        
        //cfg.setLocation(new ClassPathResource("cache.properties"));
        cfg.postProcessBeanFactory(xmlBeanFactory);
        
        Object targetObject 			= xmlBeanFactory.getBean("cache");
        StaticDataCache staticDataCache = (StaticDataCache)targetObject;
        
        Collection<Object> rows = staticDataCache.refresh("REGREP_PROPERTY_VALUES", null);
        
    }
	
	
    @SuppressWarnings("rawtypes")
	private Map<String, Class> entityTableMap;
    private Map<String, Map<String, String>> tableAttrmap;
    private CacheDao cacheDAO;
    
    private Map<String, Collection<Object>> cache = Collections.synchronizedMap(new LinkedHashMap<String, Collection<Object>>());

    public CacheDao getCacheDAO() 
    {
        return cacheDAO;
    }

    public void setCacheDAO(CacheDao cacheDAO) 
    {
        this.cacheDAO = cacheDAO;
    }

    public Collection<Object> get(String table) throws Exception 
    {
        if (this.cache.containsKey(table)) 
        {
            Collection<Object> rows = this.cache.get(table);
            return Collections.unmodifiableCollection(rows);
        }
        else 
        {
            return new ArrayList<Object>();
        }
    }

    protected static final Logger LOG = Logger.getLogger(StaticDataCacheImpl.class);

    @SuppressWarnings("rawtypes")
	public Collection<Object> refresh(String table, String criteria) throws Exception 
    {
        Class clazz = getEntityTableMap().get(table);
        
        if (clazz == null) 
        {
            LOG.warn(">>>>>>>>> No class definition found for table : " + table + ". Returning empty collection !!!");
            return new ArrayList<Object>();
        }
        
        Map<String, String> attrmap = getTableAttrmap().get(table);
        if (attrmap == null) 
        {
            throw new IllegalArgumentException("######### Missing attribute definition for table:" + table + " and entity:" + clazz.toString());
        }
        
        //LOG.info("@@@@ AttributeMap Object " + ReflectionToStringBuilder.toString(attrmap));
        
        Collection<Object> rows = getCacheDAO().loadrows(table, attrmap, criteria, clazz);
        this.cache.put(table, rows);
        setChanged();
        notifyObservers(table);
        
        LOG.info("@@@@ UPDATED LOADED CACHE from " + table + " : " + rows.size());
        //LOG.info("@@@@ AttributeMap Object " + Arrays.toString(rows.toArray()));
        printCollection(rows);
        
        return rows;
    }

    @SuppressWarnings("rawtypes")
	private void printCollection(Collection collection) 
    {
    	for (Object obj : collection) 
    	{
            LOG.debug("@@@@ AttributeMap Object " + ReflectionToStringBuilder.toString(obj));
    	}
    }
    
    
    @SuppressWarnings("rawtypes")
	public Map<String, Class> getEntityTableMap() {
        return entityTableMap;
    }

    @SuppressWarnings("rawtypes")
	public void setEntityTableMap(Map<String, Class> entityTableMap) {
        this.entityTableMap = entityTableMap;
    }

    public Map<String, Map<String, String>> getTableAttrmap() {
        return tableAttrmap;
    }

    public void setTableAttrmap(Map<String, Map<String, String>> tableAttrmap) {
        this.tableAttrmap = tableAttrmap;
    }

    private int pollInterval = 0;

    public int getPollInterval() {
        return pollInterval;
    }

    public void setPollInterval(int pollInterval) {
        this.pollInterval = pollInterval;
    }

    public void initialize() 
    {
        if (pollInterval == 0) 
        {
            return;
        }
        
        new Thread(new Runnable() 
        {
            public void run() 
            {
                while (true) 
                {
                    pollForRefresh();
                    
                    try 
                    {
                        Thread.sleep(pollInterval * 60 * 1000);
                    }
                    catch (InterruptedException e) 
                    {
                        LOG.error("######### poll thread interrupted");
                    }
                }
            }
        }).start();
    }

    Map<String, Object> lastChanged = new HashMap<String, Object>();

    private void pollForRefresh() 
    {
        LOG.info("POLLING FOR STATIC DATA CHANGED");
        
        List<Object[]> tablesLastChanged = getCacheDAO().getTablesLastChanged();
        
        for (Object[] tableLastChanged : tablesLastChanged) 
        {
            String table = (String)tableLastChanged[0];
            Object lastChangedStamp = tableLastChanged[1];
            
            if (getTableAttrmap().containsKey(table)) 
            {                
                if (!lastChanged.containsKey(table)) 
                {                    
                    lastChanged.put(table, lastChangedStamp);
                }                
                
                if (!lastChangedStamp.equals(lastChanged.get(table))) 
                {
                    LOG.info("*****  TABLE HAS BEEN UPDATED, CACHE WILL TRGGER REFRESH: " + table);
                    
                    lastChanged.put(table, lastChangedStamp);
                    
                    try 
                    {
                        refresh(table, null);
                    }
                    catch (Exception e) 
                    {
                        LOG.error("######### Failed to refresh cache for table: " + table, e);
                    }
                }                
            }
        }
    }



}
