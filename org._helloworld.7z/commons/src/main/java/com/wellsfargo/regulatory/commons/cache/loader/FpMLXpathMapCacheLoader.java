/**
 *
 */
package com.wellsfargo.regulatory.commons.cache.loader;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.cache.FpMLXpathMapCache;
import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap;
import com.wellsfargo.regulatory.commons.cache.dao.RegRepFpMLXpathMappingDao;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author u337814
 *
 */
public class FpMLXpathMapCacheLoader 
{
	@Autowired
	private static RegRepFpMLXpathMappingDao regRepFpMLXpathMappingDao;

	private static Logger logger = Logger.getLogger(FpMLXpathMapCacheLoader.class.getName());

	public void setRegRepFpMLXpathMappingDao(RegRepFpMLXpathMappingDao regRepFpMLXpathMappingDao)
	{
		FpMLXpathMapCacheLoader.regRepFpMLXpathMappingDao = regRepFpMLXpathMappingDao;
	}

	public List<FpMLXpathMap> loadFpMLXpathMapCache(FpMLXpathMapCache fpMLXpathMapCache, String key)
	{
		logger.debug("Entering loadFpMLXpathMapCache() method");

		String[] keySplit 				= null;
		String fileSeparator 			= SystemUtils.FILE_SEPARATOR;
		String filePath					= null;
		List<FpMLXpathMap> xpathList 	= null;
		String relativeCtxtString 		= "/";

		StringBuilder keyBuilder = new StringBuilder(relativeCtxtString);
		keySplit = key.split(Constants.UNDERSCORE);

		String lifeCycleEvent = keySplit[keySplit.length - 1];

		for(int marker=0; marker<keySplit.length -1; marker++)
		{
			keyBuilder.append(keySplit[marker]);
			keyBuilder.append(fileSeparator);
		}

		filePath = keyBuilder.toString();
		filePath = StringUtils.removeEnd(filePath, fileSeparator);

		xpathList = regRepFpMLXpathMappingDao.getXpathAttributeMap(filePath, lifeCycleEvent);
		
		fpMLXpathMapCache.setValue(key, xpathList);

		logger.debug("Successfully loaded mapping xPath cacahe for "+filePath.toString());

		logger.debug("Leaving loadFpMLXpathMapCache() method");

		return xpathList;
	}

}
