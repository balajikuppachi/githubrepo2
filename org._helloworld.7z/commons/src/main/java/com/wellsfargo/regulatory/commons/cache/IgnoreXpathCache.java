package com.wellsfargo.regulatory.commons.cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wellsfargo.regulatory.commons.cache.loader.IgnoreXpathCacheLoader;

public class IgnoreXpathCache {
	
	private static IgnoreXpathCache instance;
	private Map<String, List<String>> xPathMap;

	private IgnoreXpathCache()
	{
		xPathMap = new HashMap<String, List<String>>();
	}

	public static IgnoreXpathCache getInstance()
	{
		if (null == instance)
		{
			instance = new IgnoreXpathCache();
			IgnoreXpathCacheLoader.loadIgnoreXpathCache(instance);
		}

		return instance;
	}

	public void setValue(String key, List<String> values)
	{
		xPathMap.put(key, values);
	}

	public List<String> getValues(String key)
	{
		return xPathMap.get(key);
	}

}
