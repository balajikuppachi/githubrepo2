package com.wellsfargo.regulatory.commons.cache.beans;

public class FpMLXpathMap
{

	private String fpmlXpath;
	private Attributes mappingAttributes;

	public String getFpmlXpath()
	{
		return fpmlXpath;
	}

	public void setFpmlXpath(String fpmlXpath)
	{
		this.fpmlXpath = fpmlXpath;
	}

	public Attributes getMappingAttributes()
	{

		if (null == mappingAttributes) mappingAttributes = new Attributes();

		return mappingAttributes;
	}

	public static class Attributes
	{

		private String srcXpath;
		private boolean isHardCoded;
		private String dataType;
		private String condition;
		private String usageXpath;
		private String usageConditoin;
		private String classTypeCondition;

		protected Attributes()
		{

		}

		public String getSrcXpath()
		{
			return srcXpath;
		}

		public void setSrcXpath(String srcXpath)
		{
			this.srcXpath = srcXpath;
		}

		public boolean getIsHardCoded()
		{
			return isHardCoded;
		}

		public void setIsHardCoded(boolean isHardCoded)
		{
			this.isHardCoded = isHardCoded;
		}

		public String getDataType()
		{
			return dataType;
		}

		public void setDataType(String dataType)
		{
			this.dataType = dataType;
		}

		public String getCondition()
		{
			return condition;
		}

		public void setCondition(String condition)
		{
			this.condition = condition;
		}

		public String getUsageXpath()
		{
			return usageXpath;
		}

		public void setUsageXpath(String usageXpath)
		{
			this.usageXpath = usageXpath;
		}

		public String getUsageConditoin()
		{
			return usageConditoin;
		}

		public void setUsageConditoin(String usageConditoin)
		{
			this.usageConditoin = usageConditoin;
		}

		public String getClassTypeCondition()
		{
			return classTypeCondition;
		}

		public void setClassTypeCondition(String classTypeCondition)
		{
			this.classTypeCondition = classTypeCondition;
		}

		@Override
		public String toString()
		{
			return "Attributes [srcXpath=" + srcXpath + ", isHardCoded=" + isHardCoded + ", dataType=" + dataType + ", condition=" + condition + ", usageXpath=" + usageXpath + ", usageConditoin="
			        + usageConditoin + ", classTypeCondition=" + classTypeCondition + "]";
		}

	}

	@Override
	public String toString()
	{
		return "FpMLXpathMap [fpmlXpath=" + fpmlXpath + ", mappingAttributes=" + mappingAttributes + "]";
	}

}
