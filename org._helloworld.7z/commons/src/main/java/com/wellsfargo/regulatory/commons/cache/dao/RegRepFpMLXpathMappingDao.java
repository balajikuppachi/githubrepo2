/**
 *
 */
package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.List;

import com.wellsfargo.regulatory.commons.cache.beans.FpMLXpathMap;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;

/**
 * @author u337814
 *
 */

/*
 * Plan is load all these xPaths to a table later.
 * That's why Dao
 *
 */

public interface RegRepFpMLXpathMappingDao {

	/**
	 * @param filePath
	 * @param lifeCycleEvent
	 * @return
	 * @throws MessagingException
	 */
	//String getXpathAttributeMap(String filePath,
	List<FpMLXpathMap> getXpathAttributeMap(String filePath,
			String lifeCycleEvent);

}
