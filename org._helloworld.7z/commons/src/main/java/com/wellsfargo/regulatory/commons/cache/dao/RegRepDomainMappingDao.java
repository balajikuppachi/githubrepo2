package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.List;

import com.wellsfargo.regulatory.commons.cache.beans.RegRepDomainMapping;

public interface RegRepDomainMappingDao {
	
	public List<RegRepDomainMapping> findAll();
}
