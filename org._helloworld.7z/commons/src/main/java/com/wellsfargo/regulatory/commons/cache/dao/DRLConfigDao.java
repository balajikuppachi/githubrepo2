package com.wellsfargo.regulatory.commons.cache.dao;

import java.util.List;

import com.wellsfargo.regulatory.commons.beans.DRLConfig;
import com.wellsfargo.regulatory.commons.cache.beans.RegRepRulesConfig;

public interface DRLConfigDao {
	
	public void insertConfig(DRLConfig drlConfig);
	
	public DRLConfig findConfigByKey(String key);
	
	public List<RegRepRulesConfig> findAll();
}
