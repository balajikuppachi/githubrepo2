package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.dao.DataRetrievalFailureException;

import com.wellsfargo.regulatory.commons.cache.beans.RealtimeConfig;
import com.wellsfargo.regulatory.commons.cache.beans.RealtimeConfigData;
import com.wellsfargo.regulatory.commons.cache.dao.StaticDataCache;

/******************************************************************************
 * Filename    : RealtimeConfigImpl.java
 * Author      : Rama Nuti
 * Date Created: 2015-11-05
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class RealtimeConfigImpl implements RealtimeConfig, Observer 
{
    private static final Logger LOG = Logger.getLogger(RealtimeConfigImpl.class.getName());

    private Map<String, Set<String>> m_configmap = Collections.synchronizedMap(new HashMap<String, Set<String>>());

    private StaticDataCache m_cache;
    private static final String REALTIME_CONFIG_DATA = "REGREP_PROPERTY_VALUES";

    public Map<String, Set<String>> getConfig() throws Exception 
    {
        return this.m_configmap;
    }

    public Set<String> getValues(String key) 
    {
        return getValues(key, true);
    }

    public Set<String> getValues(String key, boolean mustBePresent) 
    {
        try 
        {
            Set<String> data = getConfig().get(key);
            
            if (data == null) 
            {
                if (mustBePresent) 
                {
                    throw new IllegalArgumentException("######### Missing mapping values in db for key=" + key);
                } 
                else 
                {
                    data = new HashSet<String>();
                }
            }
            
            return data;
        } 
        catch (Exception ex) 
        {
            throw new DataRetrievalFailureException("######### Unable to retrieve mapping data from db->" + ex.getMessage());
        }

        // return getConfig().get(key);
    }

    /**
     * This is called in 2 scenarios: 
     * a) When the loadOrRefreshTemplateCache is called at the start 
     * b) When any insert/update is done on the table.
     * Its job is to load the cache(m_map) with the fresh data from the DB
     */
    public void loadRealtimeConfigDataCache(Collection<Object> rows) throws Exception 
    {
        LOG.debug("Loading RealtimeConfigData cache...");
        
        for (Object o : rows) 
        {
            RealtimeConfigData realtimeConfig 	= (RealtimeConfigData) o;
            String propname 					= realtimeConfig.getPropertyName();
            Set<String> values = null;
            
            if (m_configmap.containsKey(propname)) 
            {
                values = m_configmap.get(propname);
            } 
            else 
            {
                values = new HashSet<String>();
                m_configmap.put(propname, values);
            }
            
            values.add(realtimeConfig.getPropertyValue());
        }
    }

    /**
     * Method called at the start ( init ). This calls the StaticDataCache to get the data from the table and then populates the cache (m_map) with the data
     */
    public void initializeRealtimeConfigDataCache() 
    {
        try 
        {
            this.loadRealtimeConfigDataCache(this.m_cache.refresh(REALTIME_CONFIG_DATA, null));
        } 
        catch (Exception ex) 
        {
            LOG.error("######### Error encountered while refreshing mappings", ex);
        }
        
        Observable o = (Observable) getCache();
        
        o.addObserver(this);

    }

    /**
     * This method is sent a notification by the Observable class when any Inserts/updates/deletes are made on the table
     */
    @Override
    public void update(Observable o, Object arg) 
    {
        if (REALTIME_CONFIG_DATA.equals(arg.toString())) 
        {
            try 
            {
                LOG.info("Notification received to refresh cache from table:" + REALTIME_CONFIG_DATA);
                
                Collection<Object> rows = this.m_cache.get(REALTIME_CONFIG_DATA);
                
                synchronized (this.m_configmap) 
                {
                    this.m_configmap.clear();
                    this.loadRealtimeConfigDataCache(rows);
                }
                LOG.info("Cache has been updated from table:" + REALTIME_CONFIG_DATA);
                
            } 
            catch (Exception ex) 
            {
                LOG.error("######### Could not refresh mappings"+StringUtils.trimToEmpty(ex.getMessage()));
            }
        }
    }

    /**
     * @return the m_cache
     */
    public StaticDataCache getCache() {
        return m_cache;
    }

    /**
     * @param mCache
     *            the m_cache to set
     */
    public void setCache(StaticDataCache mCache) {
        m_cache = mCache;
    }

}
