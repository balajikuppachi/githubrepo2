package com.wellsfargo.regulatory.commons.cache.beans;


/**
 * @author	Amit Rana
 * @date 	03/03/2015
 * @version 1.0
 */

public class DupCheckXpathBean {
	
	private String xPath;
	private String sdrProductType;
	private String reportType;
	
	
	public String getReportType() {
		return reportType;
	}


	public void setReportType(String reportType) {
		this.reportType = reportType;
	}


	public DupCheckXpathBean(String xPath, String sdrProductType, String reportType) {
		
		super();
		this.xPath = xPath;
		this.sdrProductType = sdrProductType;
		this.reportType = reportType;
	}

	
	public DupCheckXpathBean() {
		super();		
	}


	public String getXpath() {		
		return xPath;
	}
	
	public void setXpath(String xPath) {		
		this.xPath = xPath;
	}
		
	public String getSdrProductType() {			
		return sdrProductType;
	}
	
	public void setSdrProductType(String sdrProductType) {
		this.sdrProductType = sdrProductType;
	}
	
	
	@Override
	public String toString() {
		return "DupCheckXpathMapping [fpmlXpath=" + xPath
				+ ", sdrProductType=" + sdrProductType 
				+ ",reportType=" + reportType + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((xPath == null) ? 0 : xPath.hashCode());
		result = prime * result
				+ ((sdrProductType == null) ? 0 : sdrProductType.hashCode());
		result = prime * result
				+ ((reportType == null) ? 0 : reportType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DupCheckXpathBean other = (DupCheckXpathBean) obj;
		if (xPath == null) {
			if (other.xPath != null)
				return false;
		} else if (!xPath.equals(other.xPath))
			return false;
		if (sdrProductType == null) {
			if (other.sdrProductType != null)
				return false;
		} else if (!sdrProductType.equals(other.sdrProductType))
			return false;		
		if (reportType == null) {
			if (other.reportType != null)
				return false;
		} else if (!reportType.equals(other.reportType))
			return false;
		
		return true;
	}


}
