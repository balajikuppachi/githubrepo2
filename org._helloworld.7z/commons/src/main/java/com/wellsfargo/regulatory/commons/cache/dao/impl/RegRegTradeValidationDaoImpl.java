package com.wellsfargo.regulatory.commons.cache.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.eod.dto.RegRepTradeValidation;
/**
 * 
 * @author Raji Komatreddy
 *
 */

@Component
public class RegRegTradeValidationDaoImpl implements RowMapper<RegRepTradeValidation>
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	String selectSql = "select  tradeid, usi, uti, entity_lei, counterparty_lei, lifecycle_event_type  from REG_REP_TRADE_VALIDATION";
	
	String selectTradeSql = "select  tradeid, usi, uti, entity_lei, counterparty_lei , lifecycle_event_type  from REG_REP_TRADE_VALIDATION where tradeid = ? ";

	String insertSql = "insert into REG_REP_TRADE_VALIDATION (tradeid, usi, uti, entity_lei, counterparty_lei, lifecycle_event_type, create_datetime, update_datetime)  VALUES"
	        + " (?, ?, ?, ?, ?, ?, getDate(), getDate())";
	
	String updateSql = "update REG_REP_TRADE_VALIDATION set usi = ?, uti = ?  where tradeid = ?";
	
	String updateCptyLeiSql = "update REG_REP_TRADE_VALIDATION set counterparty_lei = ? where tradeid = ?";

	@Override
	public RegRepTradeValidation mapRow(ResultSet rs, int row) throws SQLException
	{
		RegRepTradeValidation currRegRepTradeValidation = new RegRepTradeValidation();

		currRegRepTradeValidation.setTradeid(rs.getString("tradeid"));
		currRegRepTradeValidation.setUsi(rs.getString("usi"));
		currRegRepTradeValidation.setUti(rs.getString("uti"));
		currRegRepTradeValidation.setEntityLei(rs.getString("entity_lei"));
		currRegRepTradeValidation.setCounterpartyLei(rs.getString("counterparty_lei"));
		currRegRepTradeValidation.setLifecycleEventType(rs.getString("lifecycle_event_type"));

		return currRegRepTradeValidation;
	}

	public List<RegRepTradeValidation> getAllTrades()
	{
		List<RegRepTradeValidation> regRepTradeValidationList = null;
		regRepTradeValidationList = jdbcTemplate.query(selectSql, this);
		return regRepTradeValidationList;
	}
	
	public List<RegRepTradeValidation> getTrade(String tradeId)
	{
		List<RegRepTradeValidation> regRepTradeValidationList = null;
		regRepTradeValidationList = jdbcTemplate.query(selectTradeSql, new Object [] {tradeId}, this);
		return regRepTradeValidationList;
	}
	
	public void insertTradeVal(RegRepTradeValidation currRegRepTradeValidation)
	{
		jdbcTemplate.update(insertSql, new Object[] {currRegRepTradeValidation.getTradeid(),
				 currRegRepTradeValidation.getUsi(), currRegRepTradeValidation.getUti(),
				 currRegRepTradeValidation.getEntityLei(), currRegRepTradeValidation.getCounterpartyLei(),
				 currRegRepTradeValidation.getLifecycleEventType()});
		
	}
	
	public void updateTradeVal(RegRepTradeValidation currRegRepTradeValidation)
	{
		jdbcTemplate.update(updateSql, new Object[] {  currRegRepTradeValidation.getUsi(), currRegRepTradeValidation.getUti(),
				currRegRepTradeValidation.getTradeid()	});
		
	}
	
	public void updateTradeValForCptyLeiChange(RegRepTradeValidation currRegRepTradeValidation)
	{
		jdbcTemplate.update(updateCptyLeiSql, new Object[] {  currRegRepTradeValidation.getCounterpartyLei(),
				currRegRepTradeValidation.getTradeid()	});
		
	}

}
