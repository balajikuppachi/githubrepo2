package com.wellsfargo.regulatory.commons.helpers.crypto;

import junit.framework.TestCase;

/******************************************************************************
 * Filename    : SecureDBPwdFactoryTest.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class SecureDBPwdFactoryTest extends TestCase 
{
    public void testEncryptionEnabled() throws Exception 
    {
        String password = "password123";

        SecureDBPwdFactory pwdFactory = new SecureDBPwdFactory();
        pwdFactory.setEncryptionEnabled(true);
        pwdFactory.setPassword(encryptPassword(password));
        pwdFactory.init();

        assertEquals(password, pwdFactory.getPassword());
    }

    public void testEncryptionDisabled() throws Exception 
    {
        String password = "password123";

        SecureDBPwdFactory pwdFactory = new SecureDBPwdFactory();
        pwdFactory.setEncryptionEnabled(false);
        pwdFactory.setPassword(password);
        pwdFactory.init();

        assertEquals(password, pwdFactory.getPassword());
    }

    private String encryptPassword(String password) 
    {
        SecureDBPwdHelper secureDBPwdHelper = new SecureDBPwdHelper();
        String encryptedPassword = secureDBPwdHelper.encrypt(password);
        
        return encryptedPassword;
    }
}
