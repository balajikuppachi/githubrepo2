package com.wellsfargo.sdr.sdr_commons;

import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

public class TestLeiValidation
{

	public static void main(String[] args)
	{
		
		String lei =  "213800TELOTNBG58CT33";  // "A4YGKK8ZD8QY7GZR5F87" ;   //"kB1H1DSPRFMYMCUFXT09";
		
		boolean isValidlei = ReportingDataUtils.validateLei(lei);
		System.out.println("is lei valid : " + isValidlei);

	}

}

