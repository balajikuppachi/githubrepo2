package com.wellsfargo.sdr.sdr_commons;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.wellsfargo.regulatory.commons.utils.CalendarUtils;

public class TestXmlGregCalToUtcString
{

	public static void main(String[] args)
	{
		String dateString = "2014-01-18T23:59:59.000-05:00";
		String utcDateString = null;
		
		try
        {
	        XMLGregorianCalendar calender =  DatatypeFactory.newInstance().newXMLGregorianCalendar(dateString);
	        utcDateString =  CalendarUtils.xmlGregCalToUtcFormat(calender);
	        System.out.println("utc date format " + utcDateString);
	      
	        System.out.println("utc date format 2" + CalendarUtils.getCurrentDateInUTC());	  
	        System.out.println("utc date format 1" + CalendarUtils.getCurrentDate());
	        
	      //  System.out.println("utc date format 2" + CalendarUtils.getCurrentDateInUTCFormat());

	        
	      
        }
        catch (DatatypeConfigurationException e)
        {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
        }
	}

}
