package com.wellsfargo.sdr.sdr_commons;

import com.wellsfargo.regulatory.commons.enums.InterimTaxonomyEnum;
import com.wellsfargo.regulatory.commons.enums.TaxonomyEnum;

public class TestInterimTaxonomyEnum
{
	public static void main(String args[])
	{
		String assetClass = "InterestRate22";
		String taxnomy = "IB";
		String taxnomyVal = null;
		String productIdVal = null;
		try
		{
			if( null != InterimTaxonomyEnum.fromValue(assetClass))
			  productIdVal = InterimTaxonomyEnum.fromValue(assetClass).toString();
			
			if(null != TaxonomyEnum.fromValue(taxnomy))
						 taxnomyVal = TaxonomyEnum.fromValue(taxnomy).toString();
			
			System.out.println("product Id value " + productIdVal);
			System.out.println("product Id value " + taxnomyVal);
		}
		catch(Exception e)
		{
			System.out.println("Exception occurred  " + e);
		}
		
		
	}

}
