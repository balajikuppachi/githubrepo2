package com.wellsfargo.sdr.sdr_commons;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ReportingDataUtils;

public class TestReportingDataUtils
{
	public static void main(String args[])
	{
		String uti = "A1232ab c_343";	
	//	boolean valid = ReportingDataUtils.validateUTI(uti);
		
		Timestamp insertTimeStamp =new Timestamp(CalendarUtils.getCurrentDateInUTC().getTime());
		
		System.out.println("utc time s " + insertTimeStamp);
		
		//double inDouble = 102.345;
		
		//BigDecimal inDecimal =new BigDecimal("-102.345");
		//int size = ReportingDataUtils.getLengthOfBigDecimal(inDecimal);
		
		//System.out.println("length of BigDecimal number is:  " + size);
		
		
	}

}
