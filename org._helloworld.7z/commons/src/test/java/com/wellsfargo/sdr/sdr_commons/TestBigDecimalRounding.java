package com.wellsfargo.sdr.sdr_commons;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.regulatory.commons.utils.ConversionUtils;

public class TestBigDecimalRounding
{

	public static void main(String[] args)
	{
		
		/*Double resDouble =  null;
		Integer resInt = 0;
		BigDecimal currDecimal = new BigDecimal(18.88282828838384242342535252542);
		
		resDouble =  	ConversionUtils.bigDecimalToDouble(currDecimal);
		resInt =  ConversionUtils.bigDecimalToInteger(currDecimal);
		
		System.out.println("rounded double value is " + resDouble);
		System.out.println("rounded double value is " + resInt);*/
		
		List<String> tradeList =   new ArrayList<String>();		
		tradeList.add("123");
		tradeList.add("124");
		tradeList.add("125");
		tradeList.add("126");
		tradeList.add("127");
		tradeList.add("128");
		tradeList.add("129");
		tradeList.add("130");
		tradeList.add("131");
		tradeList.add("132");
		tradeList.add("133");
		tradeList.add("134");
		tradeList.add("135");
		
		String updateTradeList = ConversionUtils.convertListToDelimitedString(tradeList, "\n \t");
		System.out.println("tradeList is "+ updateTradeList);

	}

}
