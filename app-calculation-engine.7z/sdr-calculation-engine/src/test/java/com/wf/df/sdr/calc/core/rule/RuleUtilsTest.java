package com.wf.df.sdr.calc.core.rule;

import org.junit.Before;
import org.junit.Ignore;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wf.df.sdr.calc.core.CalculationRegistry;

@Ignore //TODO: AZ - add some tests
public class RuleUtilsTest {
	CalculationRegistry registry;
	CalculationDefinitionBuilder defBuilder;
	
	@Before
	public void init() {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
        context.setConfigLocation("classpath:com/wf/df/sdr/calc/core/test-calc-application-context.xml");
        context.refresh();
        registry = context.getBean("calculationRegistry", CalculationRegistry.class);
        defBuilder = context.getBean("calculationDefinitionBuilder", CalculationDefinitionBuilder.class);
	}
}
