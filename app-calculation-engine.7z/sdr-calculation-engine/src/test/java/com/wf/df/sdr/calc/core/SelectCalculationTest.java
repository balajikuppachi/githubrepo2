package com.wf.df.sdr.calc.core;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.wf.df.sdr.TestApplicationContext;
import com.wf.df.sdr.calc.core.def.SelectOption;
import com.wf.df.sdr.calc.core.def.SelectCalculationDefinition;
import com.wf.df.sdr.calc.core.def.Source;
import com.wf.df.sdr.calc.core.def.SourceField;

@SuppressWarnings("serial")
public class SelectCalculationTest {
	
	public static final String ValueToTest = "valueToTest";
	public static final String One = "s1";
	public static final String Two = "s2";
	public static final String Three = "s3";
	public static final String Four = "s4";
	
	TestApplicationContext appContext; 
	
	@Before
	public void init() {
		appContext = new TestApplicationContext();
        appContext.setConfigLocation("classpath:com/wf/df/sdr/calc/core/test-calc-application-context.xml");
	}
    
    @Test
    public void testDefault() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, SelectCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(ValueToTest, 777);
        	put(One, 1);
        	put(Two, 2);
        	put(Three, 3);
        	put(Four, 4);
        }});
        
        Assert.assertEquals(new Integer(4), calcContext.getValue(SelectCalc.NAME, Integer.class));
    }
    
    @Test
    public void testFirstPick() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, SelectCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(ValueToTest, 1);
        	put(One, 1);
        	put(Two, 2);
        	put(Three, 3);
        	put(Four, 4);
        }});
        
        Assert.assertEquals(new Integer(2), calcContext.getValue(SelectCalc.NAME, Integer.class));
    }
    
    @Test
    public void testSecondPick() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, SelectCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(ValueToTest, 3);
        	put(One, 1);
        	put(Two, 2);
        	put(Three, 3);
        	put(Four, 4);
        }});
        
        Assert.assertEquals(new Integer(3), calcContext.getValue(SelectCalc.NAME, Integer.class));
    }
    

    public static class SelectCalc {

    	public static final String NAME = "SelectCalc";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new SelectCalculationDefinition(NAME, ValueToTest, Four, Arrays.asList(
            				new SelectOption(One, Two),
            				new SelectOption(Three, Three))));
    	}
    }
    
    public static class TestSources {
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
    		Source source = new Source();
    		source.setId("testSource");
    		Map<String, SourceField> sourceFields = new HashMap<String, SourceField>();
    		sourceFields.put(One, sourceField(One));
    		sourceFields.put(Two, sourceField(Two));
    		sourceFields.put(Three, sourceField(Three));
    		sourceFields.put(Four, sourceField(Four));
    		sourceFields.put(ValueToTest, sourceField(ValueToTest));
    		source.setFields(sourceFields);
    		calculationRegistry.addSource(source);
    	}
    	
    	private SourceField sourceField(String fieldId) {
    		SourceField sourceField = new SourceField();
    		sourceField.setId(fieldId);
    		return sourceField;
    	}
    }
}