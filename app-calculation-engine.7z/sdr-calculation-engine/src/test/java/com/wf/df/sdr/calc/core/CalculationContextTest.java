package com.wf.df.sdr.calc.core;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.wf.df.sdr.TestApplicationContext;
import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.ExtendedCalculationDefinition;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.calc.core.def.SelectCalculationDefinition;
import com.wf.df.sdr.calc.core.def.SelectOption;
import com.wf.df.sdr.calc.core.def.Source;
import com.wf.df.sdr.calc.core.def.SourceField;

@SuppressWarnings("serial")
public class CalculationContextTest {
	
	public static final String One = "s1";
	public static final String Two = "s2";
	public static final String Four = "s4";
	public static final String yyyyMMdd = "yyyyMMdd";
	
	TestApplicationContext appContext; 
	
	@Before
	public void init() {
		appContext = new TestApplicationContext();
        appContext.setConfigLocation("classpath:com/wf/df/sdr/calc/core/test-calc-application-context.xml");
	}


    @Test
    public void testCalculationContextIsNotSingleton() throws Exception{
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext1 = registry.createContext(null);
        Assert.assertNotNull(calcContext1);
        CalculationContext calcContext2 = registry.createContext(null);
        Assert.assertNotNull(calcContext2);
        Assert.assertTrue("CalculationContext must not be singleton", calcContext1 != calcContext2);
    }

    @Test
    public void testSourceValue() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        	put(Two, 2);
        }});
        
        Assert.assertEquals(new Integer(2), calcContext.getValue(Two, Integer.class));
    }
    
	@Test
    public void testBasicCalculation() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, OnePlusTwoCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        	put(Two, 2);
        }});
        
        Assert.assertEquals(new Integer(3), calcContext.getValue(OnePlusTwoCalc.NAME, Integer.class));
    }
    
    @Test(expected=CalculationEngineException.class)
    public void testUnknwonCalculation() throws Exception{
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        	put(Two, 2);
        }});
        
    	calcContext.getValue("unknownCalc", Integer.class);
    }
    
    @Test
    public void testCalculationDependencies() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, OnePlusTwoCalc.class, OnePlusTwoFourTimesCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        	put(Two, 2);
        	put(Four, 4);
        }});
        
        Assert.assertEquals(new Integer(12), calcContext.getValue(OnePlusTwoFourTimesCalc.NAME, Integer.class));
        Assert.assertEquals(new Integer(12), calcContext.getValue(OnePlusTwoFourTimesCalc.NAME, Integer.class));
    }
    
    @Test
    public void testCalculationReuse() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, OnePlusTwoCalc.class, OnePlusTwoFourTimesCalc.class, MultPrototypeCalc.class, MultExtendedCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);

        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        	put(Two, 2);
        	put(Four, 4);
        }});

        Assert.assertEquals(new Integer(36), calcContext.getValue(MultExtendedCalc.NAME, Integer.class));
    }
    
    @Test
    public void testPrototypeCalculation() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, FormatDatePrototypeCalc.class, NowExtendedCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);

        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(yyyyMMdd, yyyyMMdd);
        }});

        Assert.assertEquals(new SimpleDateFormat(yyyyMMdd).format(new Date()), calcContext.getValue(NowExtendedCalc.NAME, String.class));
    }
    
    @Test
    public void testCalculationDefinitionParameter() throws Exception{
    	appContext.setAdditionalComponents(
    			TestSources.class,
    			OnePlusTwoFourTimesCalc.class,
    			OnePlusTwoCalc.class,
    			DependencyNamePrototypeCalc.class,
    			DependencyNameExtendedCalc.class);
    	
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        	put(Two, 2);
        	put(Four, 4);
        }});
        
        
        Assert.assertEquals(OnePlusTwoFourTimesCalc.NAME, calcContext.getValue(DependencyNameExtendedCalc.NAME, String.class));
    }
    
    @Test
    public void testContextHierarchy() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, OnePlusTwoCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext parentCalcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        }});
        
        CalculationContext childCalcContext = registry.createContext(parentCalcContext, new HashMap<String, Object>() {{
        	put(Two, 2);
        }});
        
        Assert.assertEquals(new Integer(3), childCalcContext.getValue(OnePlusTwoCalc.NAME, Integer.class));
    }
    
    @Test
    public void testParentCalcRunsOnce() throws Exception{
    	appContext.setAdditionalComponents(
    			TestSources.class, 
    			CounterCalc.class,
    			MultPrototypeCalc.class,
    			MultCounterTwoExtendedCalc.class,
    			MultCounterFourExtendedCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext parentCalcContext = registry.createContext(new HashMap<String, Object>());
        
        CalculationContext childCalcContext1 = registry.createContext(parentCalcContext, new HashMap<String, Object>() {{
        	put(Two, 2);
        }});
        
        CalculationContext childCalcContext2 = registry.createContext(parentCalcContext, new HashMap<String, Object>() {{
        	put(Four, 4);
        }});
        
        Assert.assertEquals(new Integer(2), childCalcContext1.getValue(MultCounterTwoExtendedCalc.NAME, Integer.class));
        Assert.assertEquals(new Integer(4), childCalcContext2.getValue(MultCounterFourExtendedCalc.NAME, Integer.class));
        Assert.assertEquals(new Integer(1), childCalcContext2.getValue(CounterCalc.NAME, Integer.class));
    }
    
    @Test
    public void testSelectCalculation() throws Exception{
    	appContext.setAdditionalComponents(TestSources.class, SelectCalc.class);
        appContext.refresh();
        CalculationRegistry registry = appContext.getBean("calculationRegistry", CalculationRegistry.class);
        
        CalculationContext calcContext = registry.createContext(new HashMap<String, Object>() {{
        	put(One, 1);
        	put(Two, 2);
        	put(Four, 4);
        }});
        
        Assert.assertEquals(new Integer(4), calcContext.getValue(SelectCalc.NAME, Integer.class));
    }
    

    public static class SelectCalc {

    	public static final String NAME = "SelectCalc";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new SelectCalculationDefinition(NAME, One, Four, Arrays.asList(
            				new SelectOption(Two, Two),
            				new SelectOption(yyyyMMdd, yyyyMMdd))));
    	}
    }
    
    public static class OnePlusTwoCalc {
    	
    	public static final String NAME = "1+2";
    	
        @Calculation(value=NAME, isPrototype=false)
    	public Integer sum(
    			@DerivedFrom(One) Integer number1,
    			@DerivedFrom(Two) Integer number2)
    	{
    		return number1 + number2;
    	}
    }

    public static class OnePlusTwoFourTimesCalc {
    	
    	public static final String NAME = "(1+2)*4";
    	
        @Calculation(value=NAME, isPrototype=false)
    	public Integer mult(
    			@DerivedFrom(OnePlusTwoCalc.NAME) Integer number1,
    			@DerivedFrom(Four) Integer number2)
    	{
    		return number1 * number2;
    	}
    }

    public static class MultExtendedCalc {

    	public static final String NAME = "((1+2)*4)*(1+2)";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new ExtendedCalculationDefinition(NAME, MultPrototypeCalc.NAME, new String[] {OnePlusTwoFourTimesCalc.NAME, OnePlusTwoCalc.NAME}));
    	}
    }
    
    public static class MultPrototypeCalc {

    	public static final String NAME = "? * ?";
    	
        @Calculation(NAME)
    	public Integer mult(
    			@DerivedFrom("") Integer number1,
    			@DerivedFrom("") Integer number2)
    	{
    		return number1 * number2;
    	}
    }
    
    public static class FormatDatePrototypeCalc {
    	
    	public static final String NAME = "now as ?";
    	
        @Calculation(value=NAME, isPrototype=true)
    	public String format(
    			@DerivedFrom("") String format)
    	{
        	return new SimpleDateFormat(format).format(new Date());
    	}
    }
    
    public static class NowExtendedCalc {
    	
    	public static final String NAME = "now as yyyyMMdd";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new ExtendedCalculationDefinition(NAME, FormatDatePrototypeCalc.NAME, new String[] {yyyyMMdd}));
    	}
    }
    
    public static class DependencyNamePrototypeCalc {
    	
    	public static final String NAME = "First dependency name";
    	
    	/**
    	 * @param dependency0 first dependency
    	 * @param dependency1 second dependency
    	 */
        @Calculation(NAME)
    	public String getFirstDependencyName(
    			@DerivedFrom("") Integer dependency0,
    			MethodCalculationDefinition def,
    			@DerivedFrom("") Integer dependency1)
    	{
        	return def.getDependencyNames()[0];
    	}
    }
    
    public static class DependencyNameExtendedCalc {
    	
    	public static final String NAME = "'" + OnePlusTwoFourTimesCalc.NAME + "' name";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new ExtendedCalculationDefinition(NAME, DependencyNamePrototypeCalc.NAME, new String[] {
            				OnePlusTwoFourTimesCalc.NAME, OnePlusTwoCalc.NAME}));
    	}
    }
    
    public static class CounterCalc {
    	
    	private static Integer counter = 0; 
    	
    	public static final String NAME = "++Counter";
    	
        @Calculation(value=NAME, isPrototype=false)
    	public Integer calc()
    	{
    		return ++counter;
    	}
    }
    
    public static class MultCounterTwoExtendedCalc {
    	
    	public static final String NAME = "Counter*2";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new ExtendedCalculationDefinition(NAME, MultPrototypeCalc.NAME, new String[] {CounterCalc.NAME, Two}));
    	}
    }
    
    public static class MultCounterFourExtendedCalc {
    	
    	public static final String NAME = "Counter*4";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new ExtendedCalculationDefinition(NAME, MultPrototypeCalc.NAME, new String[] {CounterCalc.NAME, Four}));
    	}
    }
    
    public static class TestSources {
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
    		Source source = new Source();
    		source.setId("testSource");
    		Map<String, SourceField> sourceFields = new HashMap<String, SourceField>();
    		sourceFields.put(One, sourceField(One));
    		sourceFields.put(Two, sourceField(Two));
    		sourceFields.put(Four, sourceField(Four));
    		sourceFields.put(yyyyMMdd, sourceField(yyyyMMdd));
    		source.setFields(sourceFields);
    		calculationRegistry.addSource(source);
    	}
    	
    	private SourceField sourceField(String fieldId) {
    		SourceField sourceField = new SourceField();
    		sourceField.setId(fieldId);
    		return sourceField;
    	}
    }}