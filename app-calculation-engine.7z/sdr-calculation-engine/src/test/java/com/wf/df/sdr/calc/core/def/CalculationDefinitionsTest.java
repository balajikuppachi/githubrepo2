package com.wf.df.sdr.calc.core.def;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CalculationDefinitionsTest {
	
	private static Logger logger = LoggerFactory.getLogger(CalculationDefinitionsTest.class);
	
	private static CalculationMetadataManager calculationMetadataManager;
	
	@BeforeClass
	public static void init() throws IOException {
		calculationMetadataManager = new CalculationMetadataManager();
		if (logger.isDebugEnabled()) {
			//TODO: AZ - Find a better way to generate schema
			logger.debug("Calculation definitions schema generated from class files is: \n");
			calculationMetadataManager.storeSchema(System.out);
		}
	}
	
	@Test
	public void testSelectXmlUnmarshall() throws URISyntaxException {
		File inputFile = new File(getClass().getResource("test-select-calculation-def.xml").toURI());
		CalculationMetadata defs = calculationMetadataManager.load(inputFile);
		
		Map<String, CalculationDefinition> defMap = defs.getCalculationDefinitions();
		Assert.assertEquals(1, defMap.size());
		
		SelectCalculationDefinition def = (SelectCalculationDefinition)defMap.get("calculation-id");
		Assert.assertEquals("calculation-id", def.getName());
		Assert.assertEquals("calculation-check", def.getCheck());
		Assert.assertEquals("calculation-default", def.getDefaultPick());
		
		List<SelectOption> options = def.getOptions();
		for (int i = 1; i < 3; i++) {
			SelectOption option = options.get(i - 1);
			Assert.assertEquals("if-equals-" + i, option.getIfEquals());
			Assert.assertEquals("pick-" + i, option.getPick());
		}
	}
	
	@Test
	public void testExtendedXmlUnmarshall() throws URISyntaxException {
		File inputFile = new File(getClass().getResource("test-extended-calculation-def.xml").toURI());
		CalculationMetadata defs = calculationMetadataManager.load(inputFile);
		
		Map<String, CalculationDefinition> defMap = defs.getCalculationDefinitions();
		Assert.assertEquals(1, defMap.size());
		
		ExtendedCalculationDefinition def = (ExtendedCalculationDefinition)defMap.get("extended-calculation-id");
		Assert.assertEquals("extended-calculation-id", def.getName());
		Assert.assertEquals("calculation-prototype", def.getBaseCalculationName());
		
		List<Dependency> dependencies = def.getDependencies();
		for (int i = 1; i < 3; i++) {
			Dependency dependency = dependencies.get(i - 1);
			Assert.assertEquals("dep-" + i, dependency.getDependencyName());
		}
	}
	
	@Test
	public void testXmlMarshall() throws IOException {
		
		ExtendedCalculationDefinition extendedDef = new ExtendedCalculationDefinition("extended-calculation-id", "calculation-prototype", new String[] {"dep-1","dep-2"});
		SelectCalculationDefinition selectDef = new SelectCalculationDefinition("calculation-id", "calculation-check", "calculation-default",
				Arrays.asList(new SelectOption("if-equals-1", "pick-1"), new SelectOption("if-equals-2", "pick-2")));
		CalculationMetadata defs = new CalculationMetadata();
		Map<String, CalculationDefinition> calcMap = new LinkedHashMap<String, CalculationDefinition>();
		calcMap.put(extendedDef.getName(), extendedDef);
		calcMap.put(selectDef.getName(), selectDef);
		defs.setCalculationDefinitions(calcMap);
		
		File tempFile = File.createTempFile("sdr-def-marshalling-test", ".xml");
		tempFile.deleteOnExit();
		
		calculationMetadataManager.store(defs, tempFile);
		CalculationMetadata unmarshalledDefs = calculationMetadataManager.load(tempFile);
		
		Assert.assertEquals(extendedDef, unmarshalledDefs.getCalculationDefinitions().get(extendedDef.getName()));
		Assert.assertEquals(selectDef, unmarshalledDefs.getCalculationDefinitions().get(selectDef.getName()));
	}
}
