package com.wf.df.sdr;

import java.io.IOException;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApplicationContext extends ClassPathXmlApplicationContext {
	private Class<?>[] additionalComponents = new Class<?>[0];
	
	public void setAdditionalComponents(Class<?>...additionalComponents) {
		this.additionalComponents = additionalComponents;
	}
	
	@Override
	protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory)
			throws BeansException, IOException {
		super.loadBeanDefinitions(beanFactory);
		for (Class<?> clazz : additionalComponents) {
			BeanDefinitionReaderUtils.registerWithGeneratedName(
					BeanDefinitionBuilder.rootBeanDefinition(clazz).getBeanDefinition(),
					beanFactory);
		}
	}
}

