package com.wf.df.sdr.calc.core;

import javax.annotation.PostConstruct;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContextException;

import com.wf.df.sdr.TestApplicationContext;
import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.ExtendedCalculationDefinition;

public class CalculationRegistryTest {
	
	TestApplicationContext context;
	
	@Before
	public void init() {
		context = new TestApplicationContext();
		context.setConfigLocation("classpath:com/wf/df/sdr/calc/core/test-calc-application-context.xml");
	}
	
    @Test
    public void testNormalInitialization() throws Exception{
    	TestApplicationContext context = new TestApplicationContext();
    	context.refresh();
    }
    
    @Test
    public void testInconsistentCalculationTypes() throws Exception{
    	context.setAdditionalComponents(FormatIntegerPrototypeCalc.class, StringCalc.class, FormatIntegerExtendedBadCalc.class);
        try {
        	context.refresh();
        	Assert.fail("Calculation registry was expected to fail due to inconsistent calculation types");
        } catch (ApplicationContextException e) {
        	// OK - expected failure
        	Assert.assertTrue("Application context is expected to fail due to CalculationEngineException", e.getCause() instanceof CalculationEngineException);
        }
    }
    
    @Test
    public void testPrototypeCalculationBeingUsedDirectly() throws Exception{
    	context.setAdditionalComponents(FormatIntegerPrototypeCalc.class, DerivedFromPrototypeBadCalc.class);
        try {
        	context.refresh();
        	Assert.fail("Calculation registry was expected to fail due to prototype calculation being used directly");
        } catch (ApplicationContextException e) {
        	// OK - expected failure
        	Assert.assertTrue("Application context is expected to fail due to CalculationEngineException", e.getCause() instanceof CalculationEngineException);
        }
    }
    
    @Test
    public void testCalculationNameIsNotUnique() throws Exception{
    	context.setAdditionalComponents(StringCalc.class, StringCalcDuplicateCalc.class);
        try {
        	context.refresh();
        	Assert.fail("Calculation registry was expected to fail due to calculation name not being unique");
        } catch (BeanCreationException e) {
        	// OK - expected failure
        	Assert.assertTrue("Bean creation is expected to fail due to CalculationEngineException", e.getCause() instanceof CalculationEngineException);
        }
    }
    
    public static class StringCalc {
    	
    	public static final String NAME = "StringCalc";
    	
        @Calculation(value=NAME, isPrototype=false)
    	public String calc() {
        	return "Some calculated string";
    	}
    }
    
    public static class FormatIntegerPrototypeCalc {
    	
    	public static final String NAME = "FormatIntegerPrototypeCalc";
    	
        @Calculation(value=NAME, isPrototype=true)
    	public String calc(
        	@DerivedFrom("") Integer param)
        {
        	return param.toString();
    	}
    }
    
    public static class FormatIntegerExtendedBadCalc {
    	
    	public static final String NAME = "FormatIntegerExtendedBadCalc";
    	
    	@Autowired
    	CalculationRegistry calculationRegistry;
    	
    	@PostConstruct
    	public void init() {
            calculationRegistry.addDefinition(
            		new ExtendedCalculationDefinition(NAME, FormatIntegerPrototypeCalc.NAME, new String[] {StringCalc.NAME}));
    	}
    }
    
    public static class DerivedFromPrototypeBadCalc {
    	
    	public static final String NAME = "DerivedFromPrototypeBadCalc";

    	@Calculation(value=NAME, isPrototype=false)
    	public String calc(
    			@DerivedFrom(value=FormatIntegerPrototypeCalc.NAME, isInternal=true) String formattedInteger)
    	{
			return "Formatted integer is " + formattedInteger; //but it will fail earlier
		}
    }
    
    public static class StringCalcDuplicateCalc {

    	public static final String NAME = "StringCalc";

    	@Calculation(value=NAME, isPrototype=false)
    	public String calc()
    	{
			return "I'm a duplicate calculation";
		}
    }
}
