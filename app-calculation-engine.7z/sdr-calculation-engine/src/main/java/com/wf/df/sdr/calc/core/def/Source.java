package com.wf.df.sdr.calc.core.def;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.UnmarshalException;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


@XmlRootElement(name="source")
public class Source {
	
	private String id;
	private Map<String, SourceField> fields;
	
	public Source() {
	}

	@XmlAttribute(name="id")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@XmlElementRef(required=true)
	@XmlJavaTypeAdapter(SourceFieldContainerXmlAdapter.class)
	public Map<String, SourceField> getFields() {
		return fields;
	}

	public void setFields(Map<String, SourceField> fields) {
		this.fields = fields;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fields == null) ? 0 : fields.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Source other = (Source) obj;
		if (fields == null) {
			if (other.fields != null)
				return false;
		} else if (!fields.equals(other.fields))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Source [id=" + id + ", fields=" + fields + "]";
	}



	public static class SourceFieldContainerXmlAdapter extends XmlAdapter<SourceFieldContainer, Map<String, SourceField>> {

		@Override
		public Map<String, SourceField> unmarshal(SourceFieldContainer sourceFieldContainer)
				throws Exception {
			
			if (sourceFieldContainer == null || sourceFieldContainer.getFields() == null) {
				return null;
			}

			Map<String, SourceField> map = new LinkedHashMap<String, SourceField>();
			for (SourceField field : sourceFieldContainer.getFields()) {
				if (map.containsKey(field.getId())) {
					throw new UnmarshalException("Source field ID already exists: " + field.getId());
				}
				map.put(field.getId(), field);
			}
			
			return map;
		}

		@Override
		public SourceFieldContainer marshal(Map<String, SourceField> sourceFields)
				throws Exception {
			
			if (sourceFields == null) {
				return null;
			}
			
			List<SourceField> list = new LinkedList<SourceField>();
			list.addAll(sourceFields.values());
			
			SourceFieldContainer sourceFieldContainer = new SourceFieldContainer();
			sourceFieldContainer.setFields(list);
			return sourceFieldContainer;
		}
	}
	
	
}
