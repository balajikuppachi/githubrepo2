package com.wf.df.sdr.calc.core.def;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.UnmarshalException;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name="calculation-metadata")
@XmlType(propOrder={"sources", "calculationDefinitions"})
public class CalculationMetadata {
	
	private Map<String, Source> sources;
	private Map<String, CalculationDefinition> calculationDefinitions;

	@XmlElementRef(required=false)
	@XmlJavaTypeAdapter(SourceContainerXmlAdapter.class)
	public Map<String, Source> getSources() {
		return sources;
	}

	public void setSources(Map<String, Source> sources) {
		this.sources = sources;
	}
	
	@XmlElementRef(required=false)
	@XmlJavaTypeAdapter(CalculationDefinitionContainerXmlAdapter.class)
	public Map<String, CalculationDefinition> getCalculationDefinitions() {
		return calculationDefinitions;
	}

	public void setCalculationDefinitions(
			Map<String, CalculationDefinition> calculationDefinitions) {
		this.calculationDefinitions = calculationDefinitions;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((calculationDefinitions == null) ? 0
						: calculationDefinitions.hashCode());
		result = prime * result + ((sources == null) ? 0 : sources.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CalculationMetadata other = (CalculationMetadata) obj;
		if (calculationDefinitions == null) {
			if (other.calculationDefinitions != null)
				return false;
		} else if (!calculationDefinitions.equals(other.calculationDefinitions))
			return false;
		if (sources == null) {
			if (other.sources != null)
				return false;
		} else if (!sources.equals(other.sources))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CalculationMetadata [sources=" + sources
				+ ", calculationDefinitions=" + calculationDefinitions + "]";
	}



	public static class CalculationDefinitionContainerXmlAdapter extends XmlAdapter<CalculationDefinitionContainer, Map<String, CalculationDefinition>> {

		@Override
		public Map<String, CalculationDefinition> unmarshal(CalculationDefinitionContainer calculationDefinitionContainer)
				throws Exception {
			
			if (calculationDefinitionContainer == null || calculationDefinitionContainer.getCalculationDefinitions() == null) {
				return null;
			}

			Map<String, CalculationDefinition> map = new LinkedHashMap<String, CalculationDefinition>();
			for (CalculationDefinition calculationDefinition : calculationDefinitionContainer.getCalculationDefinitions()) {
				if (map.containsKey(calculationDefinition.getName())) {
					throw new UnmarshalException("Calculation name already exists: " + calculationDefinition.getName());
				}
				map.put(calculationDefinition.getName(), calculationDefinition);
			}
			
			return map;
		}

		@Override
		public CalculationDefinitionContainer marshal(Map<String, CalculationDefinition> calculationDefinitions)
				throws Exception {
			
			if (calculationDefinitions == null) {
				return null;
			}
			
			List<CalculationDefinition> list = new LinkedList<CalculationDefinition>();
			list.addAll(calculationDefinitions.values());
			
			CalculationDefinitionContainer calculationDefinitionContainer = new CalculationDefinitionContainer();
			calculationDefinitionContainer.setCalculationDefinitions(list);
			return calculationDefinitionContainer;
		}
	}
	
	public static class SourceContainerXmlAdapter extends XmlAdapter<SourceContainer, Map<String, Source>> {

		@Override
		public Map<String, Source> unmarshal(SourceContainer sourceContainer)
				throws Exception {
			
			if (sourceContainer == null || sourceContainer.getSources() == null) {
				return null;
			}

			Map<String, Source> map = new LinkedHashMap<String, Source>();
			for (Source source : sourceContainer.getSources()) {
				if (map.containsKey(source.getId())) {
					throw new UnmarshalException("Source ID already exists: " + source.getId());
				}
				map.put(source.getId(), source);
			}
			
			return map;
		}

		@Override
		public SourceContainer marshal(Map<String, Source> sources)
				throws Exception {
			
			if (sources == null) {
				return null;
			}
			
			List<Source> list = new LinkedList<Source>();
			list.addAll(sources.values());
			
			SourceContainer sourceContainer = new SourceContainer();
			sourceContainer.setSources(list);
			return sourceContainer;
		}
	}

}
