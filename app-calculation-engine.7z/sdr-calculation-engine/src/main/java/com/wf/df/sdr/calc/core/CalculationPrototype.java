package com.wf.df.sdr.calc.core;

import java.lang.reflect.Method;

public class CalculationPrototype {
	
	private String calculationName;
	private Object bean;
	private Method method;
	
	private String[] dependencyNames;
	private Boolean[] dependenciesInternalFlags;
	private int internalDependenciesCount = 0;
	private int calculationDefinitionParamIndex = -1;
	
	
	public CalculationPrototype(String calculationName, Object bean, Method method, String[] dependencyNames, Boolean[] dependencyInternalFlags,
			int calculationDefinitionParamIndex)
	{
		super();

		this.calculationName = calculationName;
		this.bean = bean;
		this.method = method;
		this.dependencyNames = dependencyNames;
		this.dependenciesInternalFlags = dependencyInternalFlags;
		this.calculationDefinitionParamIndex = calculationDefinitionParamIndex;
		
		
		for(int i = 0; i < dependencyInternalFlags.length; i++) {
			if (dependencyInternalFlags[i]) {
				internalDependenciesCount++;
			}
		}
		
	}
	
	public String getName() {
		return calculationName;
	}
	
	public Object getBean() {
		return bean;
	}

	public Method getMethod() {
		return method;
	}
	
	public String[] getDependencyNames() {
		return dependencyNames;
	}
	
	public Boolean[] getDependencyInternalFlags() {
		return dependenciesInternalFlags;
	}
	
	public int getInternalDependenciesCount() {
		return internalDependenciesCount;
	}
	
	public int getCalculationDefinitionParamIndex() {
		return calculationDefinitionParamIndex;
	}
}
