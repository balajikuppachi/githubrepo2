package com.wf.df.sdr.calc.core.def;

import java.util.List;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="fields")
public class SourceFieldContainer {
	private List<SourceField> fields;

	@XmlElementRef
	public List<SourceField> getFields() {
		return fields;
	}

	public void setFields(List<SourceField> fields) {
		this.fields = fields;
	}
}