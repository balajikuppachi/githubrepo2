package com.wf.df.sdr.calc.core.def;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.SchemaOutputResolver;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.ValidationEventLocator;
import javax.xml.bind.helpers.DefaultValidationEventHandler;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class CalculationMetadataManager {
	
	public static final String SCHEMA_LOCATION = "calculation-definitions.xsd";
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private JAXBContext calculationsJaxbContext;
	private Marshaller calculationsMarshaller;
	private Unmarshaller calculationsUnmarshaller;
	
	
	public CalculationMetadataManager() {
		try {
			ValidationEventHandler validationEventHandler = new MetadataValidationEventHandler();
	
			SchemaFactory calculationsSchemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Source calculationsSchemaSource = new StreamSource(CalculationMetadata.class.getResourceAsStream(SCHEMA_LOCATION));
			Schema calculationsSchema = calculationsSchemaFactory.newSchema(calculationsSchemaSource);
			
			calculationsJaxbContext = JAXBContext.newInstance(CalculationMetadata.class.getPackage().getName());
			
			calculationsMarshaller = calculationsJaxbContext.createMarshaller();
			calculationsMarshaller.setEventHandler(validationEventHandler);
			calculationsMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			calculationsMarshaller.setSchema(calculationsSchema);
			
			calculationsUnmarshaller = calculationsJaxbContext.createUnmarshaller();
			calculationsUnmarshaller.setEventHandler(validationEventHandler);
			calculationsUnmarshaller.setSchema(calculationsSchema);
		} catch (JAXBException e) {
			throw new CalculationMetadataException(e);
		} catch (SAXException e) {
			throw new CalculationMetadataException(e);
		}
	}
	
	public CalculationMetadata load(InputStream input) {
		try {
			Object unmarshalled = calculationsUnmarshaller.unmarshal(input);
			if (!(unmarshalled instanceof CalculationMetadata)) {
				throw new CalculationMetadataException("Couldn't load calculation metadata: root element must be 'calculation-metadata'");
			}
			return (CalculationMetadata)unmarshalled;
		} catch (JAXBException e) {
			throw new CalculationMetadataException("Couldn't load calculation definitions resource", e);
		}
	}
	
	public CalculationMetadata load(File file) {
		InputStream input = null;
		try {
			input = new FileInputStream(file);
			return load(input);
		} catch (FileNotFoundException e) {
			throw new CalculationMetadataException("Couldn't load calculation metadata from file: " + file, e);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}
	}
	
	public void store(CalculationMetadata calculationMetadata, OutputStream output) {
		try {
			calculationsMarshaller.marshal(calculationMetadata, output);
			output.flush();
		} catch (JAXBException e) {
			throw new CalculationMetadataException("Couldn't store calculation metadata", e);
		} catch (IOException e) {
			throw new CalculationMetadataException("Couldn't store calculation metadata", e);
		}
	}
	
	public void store(CalculationMetadata calculationMetadata, File file) {
		OutputStream output = null;
		try {
			output = new FileOutputStream(file);
			store(calculationMetadata, output);
		} catch (FileNotFoundException e) {
			throw new CalculationMetadataException("Couldn't store calculation metadata to file: " + file, e);
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					//ignore
				}
			}
		}
	}
	
	public void storeSchema(OutputStream output) throws IOException {
		final Writer writer = new OutputStreamWriter(output);
		SchemaOutputResolver outResolver = new SchemaOutputResolver() {
			@Override
			public Result createOutput(String namespaceUri, String suggestedFileName ) throws IOException {
				Result result = new StreamResult(writer); 
				result.setSystemId("some system id");
				return result;
			}
		};
		calculationsJaxbContext.generateSchema(outResolver);
	}
	
	private class MetadataValidationEventHandler implements ValidationEventHandler {

		@Override
		public boolean handleEvent(ValidationEvent event) {
	        if( event == null ) {
	            throw new IllegalArgumentException();
	        }

	        String location = getLocation( event );
	        
	        switch ( event.getSeverity() ) {
	            case ValidationEvent.WARNING:
	            	logger.warn(event.getMessage() + ", Location: " + location);
	                return true; // continue after warnings
	            case ValidationEvent.ERROR:
	            case ValidationEvent.FATAL_ERROR:
	            default:
	            	logger.error(event.getMessage() + ", Location: " + location);
	                return false; // terminate after errors
	        }
		}
		
		/**
		 * @see DefaultValidationEventHandler
		 */
	    private String getLocation(ValidationEvent event) {
	        StringBuffer msg = new StringBuffer();
	        
	        ValidationEventLocator locator = event.getLocator();
	        
	        if( locator != null ) {
	            
	            URL url = locator.getURL();
	            Object obj = locator.getObject();
	            Node node = locator.getNode();
	            int line = locator.getLineNumber();
	            
	            if( url!=null || line!=-1 ) {
	                msg.append( "line " + line );
	                if( url!=null )
	                    msg.append( " of " + url );
	            } else if( obj != null ) {
	                msg.append( " obj: " + obj.toString() );
	            } else if( node != null ) {
	                msg.append( " node: " + node.toString() );
	            }
	        } else {
	            msg.append("Location unavailable");
	        } 
	        
	        return msg.toString();
	    }
	}
	
}
