package com.wf.df.sdr.calc.core.def;

import java.util.List;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="calculations")
public class CalculationDefinitionContainer {
	private List<CalculationDefinition> calculationDefinitions;

	@XmlElementRef
	public List<CalculationDefinition> getCalculationDefinitions() {
		return calculationDefinitions;
	}

	public void setCalculationDefinitions(List<CalculationDefinition> calculationDefinitions) {
		this.calculationDefinitions = calculationDefinitions;
	}
}