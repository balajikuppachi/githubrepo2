package com.wf.df.sdr.calc.core.rule;

public class StringContainsIgnoreCasePredicate extends AbstractPredicate<String> {
	
	private String substring;
	
	public StringContainsIgnoreCasePredicate(String substring) {
		this.substring = substring == null ? null : substring.toUpperCase();
	}

	@Override
	public boolean evaluate(String arg) {
		return substring == null || (arg != null && arg.toUpperCase().indexOf(substring) >= 0);
	}
}
