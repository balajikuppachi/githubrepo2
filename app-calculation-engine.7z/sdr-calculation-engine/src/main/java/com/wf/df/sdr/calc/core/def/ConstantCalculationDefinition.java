package com.wf.df.sdr.calc.core.def;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="constant")
@XmlType(propOrder={"name", "value"})
public class ConstantCalculationDefinition extends CalculationDefinition {
	private String value;
	
	public ConstantCalculationDefinition() {
	}
	
	public ConstantCalculationDefinition(String calculationName, String value) {
		super(calculationName);
		this.value = value;
	}
	
	
	@Override
	@XmlAttribute(name="id", required=true)
	public String getName() {
		return super.getName();
	}
	
	@Override
	public void setName(String name) {
		super.setName(name);
	}

	@XmlAttribute(name="value", required=true)
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConstantCalculationDefinition other = (ConstantCalculationDefinition) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ConstantCalculationDefinition [name=" + name + ", value=" + value + "]";
	}

}
