package com.wf.df.sdr.calc.core.rule;

public abstract class AbstractPredicate<T> implements Predicate<T> {
	@SuppressWarnings("unchecked")
	@Override
	public boolean evaluateNonTypeSafe(Object arg) {
		return evaluate((T)arg);
	}
}
