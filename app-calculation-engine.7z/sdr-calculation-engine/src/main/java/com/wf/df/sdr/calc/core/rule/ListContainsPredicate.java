package com.wf.df.sdr.calc.core.rule;

import java.util.List;

public class ListContainsPredicate<T> extends AbstractPredicate<List<T>> {
	
	private T elementToFind;
	
	public ListContainsPredicate(T elementToFind) {
		this.elementToFind = elementToFind;
	}

	@Override
	public boolean evaluate(List<T> param) {
		return elementToFind == null || (param != null && param.contains(elementToFind));
	}
}
