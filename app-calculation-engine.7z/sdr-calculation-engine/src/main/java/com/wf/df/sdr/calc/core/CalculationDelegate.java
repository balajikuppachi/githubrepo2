package com.wf.df.sdr.calc.core;

import java.lang.reflect.Type;

public interface CalculationDelegate {
	CalculationRegistry getCalculationRegistry();
	String[] getDependencyNames();
	Type getReturnType();
	void init();
	CalculationContext.ResolutionResult resolve(CalculationContext context);
}
