package com.wf.df.sdr.calc.core.def;

import java.util.List;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="sources")
public class SourceContainer {
	private List<Source> sources;

	@XmlElementRef
	public List<Source> getSources() {
		return sources;
	}

	public void setSources(List<Source> sources) {
		this.sources = sources;
	}
}