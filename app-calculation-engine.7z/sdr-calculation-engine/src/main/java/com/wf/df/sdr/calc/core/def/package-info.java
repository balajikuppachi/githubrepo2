@javax.xml.bind.annotation.XmlSchema(
		xmlns = {@javax.xml.bind.annotation.XmlNs(prefix = "", namespaceURI = "http://www.headstrong.com/calculations")},
        namespace="http://www.headstrong.com/calculations",
        attributeFormDefault=javax.xml.bind.annotation.XmlNsForm.UNQUALIFIED,
        elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.wf.df.sdr.calc.core.def;