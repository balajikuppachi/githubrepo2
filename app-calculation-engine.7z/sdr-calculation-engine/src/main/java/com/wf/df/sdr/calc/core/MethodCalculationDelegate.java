package com.wf.df.sdr.calc.core;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.ReflectionUtils;

import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;

public class MethodCalculationDelegate implements CalculationDelegate {
	
	private CalculationRegistry registry;
	private MethodCalculationDefinition definition;
	
	MethodCalculationDelegate(CalculationRegistry registry, MethodCalculationDefinition definition) {
		this.registry = registry;
		this.definition = definition;
	}

	@Override
	public CalculationRegistry getCalculationRegistry() {
		return registry;
	}
	
	@Override
	public Type getReturnType() {
		return definition.getMethod().getGenericReturnType();
	}
	
	@Override
	public String[] getDependencyNames() {
		return definition.getDependencyNames();
	}
	
	@Override
	public void init() {
		validateDependencies();
	}
	
	private void validateDependencies() {
		int allDependenciesCount = getDependencyNames().length;
		Type[] methodParameterTypes = definition.getMethod().getGenericParameterTypes();
		
		if (definition.getDependenciesAsListParamIndex() >= 0) {
			Type listParamType = methodParameterTypes[definition.getDependenciesAsListParamIndex()];
			if (!(listParamType instanceof ParameterizedType) || !(((ParameterizedType)listParamType).getRawType().equals(List.class))) {
				throw new CalculationEngineException("Cannot register calculation '" + definition.getName() +
						"': parameter " + definition.getDependenciesAsListParamIndex() + " is expected to be of type java.util.List" +
						" while " + listParamType + " was found");
			}
		}
		
		for (int dependencyIndex = 0; dependencyIndex < allDependenciesCount; dependencyIndex++) {
			String dependencyName = definition.getDependencyNames()[dependencyIndex];
			CalculationDelegate dependencyDelegate = registry.getDelegate(dependencyName);
			if (dependencyDelegate != null) {
				//FIXME: AZ - remove class check once getReturnType is supported by SwitchCalculationDelegate
				if (!(dependencyDelegate instanceof SelectCalculationDelegate)) {
					if (definition.getDependenciesAsListParamIndex() < 0) {
						int paramIndex = dependencyIndex + ((definition.getCalculationDefinitionParamIndex() < 0 || dependencyIndex < definition.getCalculationDefinitionParamIndex()) ? 0 : 1);
						Type paramType = methodParameterTypes[paramIndex];
						Type dependencyReturnType = dependencyDelegate.getReturnType();
						//TODO: AZ - Use "isAssignableFrom" instead of exact type match check
						if (!paramType.equals(dependencyReturnType)) {
							throw new CalculationEngineException("Cannot register calculation '" + definition.getName() +
									"': dependency calculation '" + dependencyName + "' returns a value of type " +
									dependencyReturnType + " while " + paramType + " is exptected");
						}
					}
				}
			} else if (registry.getPrototype(dependencyName) != null) {
				throw new CalculationEngineException("Cannot register calculation '" + definition.getName() +
						"': dependency calculation '" + dependencyName + "' is a prototype");
			} else {
				// No calculation is registered with this name - assuming it is a source field dependency
				//TODO: AZ - maintain a list of expected source field types to verify source against
			}
		}
	}
	
	@Override
	public CalculationContext.ResolutionResult resolve(CalculationContext context) {
		CalculationContext.ResolutionResult[] resolvedDeps = resolveDependencies(context);
		Object[] params = prepareDependencyParams(resolvedDeps);
		Object value = executeCalculationMethod(params);
		
		return new CalculationContext.ResolutionResult(value, mostSpecificContext(context, resolvedDeps));
	}
	
	private CalculationContext mostSpecificContext(CalculationContext currentContext, CalculationContext.ResolutionResult[] resolvedDeps) {
		int maxLevel = 0;
		
		for (CalculationContext.ResolutionResult result : resolvedDeps) {
			if (result.contextResolved.getLevel() > maxLevel) {
				maxLevel = result.contextResolved.getLevel();
			}
		}
		
		for (int i = currentContext.getLevel(); i > maxLevel; i--) {
			currentContext = currentContext.getParentContext();
		}

		return currentContext;
	}
	
	private Object executeCalculationMethod(Object[] params) {
		return ReflectionUtils.invokeMethod(definition.getMethod(), definition.getBean(), params);
	}
	
	private Object[] prepareDependencyParams(CalculationContext.ResolutionResult[] resolvedDeps) {
		Object[] params;
		String[] depNames = definition.getDependencyNames();
		
		if (definition.getDependenciesAsListParamIndex() < 0) {
			int paramCount = depNames.length + (definition.getCalculationDefinitionParamIndex() < 0 ? 0 : 1);
			params = new Object[paramCount];
			
			for (int paramIndex = 0, dependencyIndex = 0; paramIndex < params.length; paramIndex++) {
				if (paramIndex == definition.getCalculationDefinitionParamIndex()) {
					params[paramIndex] = definition;
					// don't increment dependencyIndex here as CalculationDefinition parameter we've just found is not a dependency
				} else {
					params[paramIndex] = resolvedDeps[dependencyIndex].value;
					dependencyIndex++;
				}
			}
		} else {
			int paramCount = 1 + (definition.getCalculationDefinitionParamIndex() < 0 ? 0 : 1);
			params = new Object[paramCount];
			
			List<Object> depsAsList = new ArrayList<Object>(depNames.length);
			for (CalculationContext.ResolutionResult resolvedDep : resolvedDeps) {
				depsAsList.add(resolvedDep.value);
			}
			params[definition.getDependenciesAsListParamIndex()] = depsAsList;
			
			if (definition.getCalculationDefinitionParamIndex() >= 0) {
				params[definition.getCalculationDefinitionParamIndex()] = definition;
			}
			
		}
		
		return params;
		
	}
	
	private CalculationContext.ResolutionResult[] resolveDependencies(CalculationContext calculationContext) {
		String[] depNames = definition.getDependencyNames();
		CalculationContext.ResolutionResult[] resolvedValues = new CalculationContext.ResolutionResult[depNames.length];
		
		for (int dependencyIndex = 0; dependencyIndex < depNames.length; dependencyIndex++) {
			resolvedValues[dependencyIndex] = calculationContext.resolveValue(depNames[dependencyIndex]);
		}
		
		return resolvedValues;
	}
	
}
