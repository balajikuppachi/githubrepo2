package com.wf.df.sdr.calc.core;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component
@Scope("prototype")
public class CalculationContext {
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	CalculationRegistry registry;
	CalculationContext parentContext;
	Map<String, ?> sourceValues;
	Map<String, Object> storedValues = new ConcurrentHashMap<String, Object>();
	int level;

	//package-private constructor
	CalculationContext() {}
	
	public CalculationRegistry getCalculationRegistry() {
		return registry;
	}
	
	//TODO: AZ - 'synchronized' is too expensive - need better performing thread-safety solution
	public synchronized <T> T  getValue(String name, Class<T> clazz) {
		if (name == null) {
			throw new CalculationEngineException("Calculation name must not be null");
		}
		return clazz.cast(decodeNull(resolveValue(name).value));
	}
	
	public String getString(String name) {
		return getValue(name, String.class);
	}
	
	public Boolean getBoolean(String name) {
		return getValue(name, Boolean.class);
	}
	
	synchronized ResolutionResult resolveValue(String name) {
		if (registry.getSourceField(name) != null) {
			CalculationContext currentContext = this;
			CalculationContext lastKnownContext = null;
			while (currentContext != null) {
				Object value = currentContext.getSourceValue(name);
				if (value != null) {
					return new ResolutionResult(decodeNull(value), currentContext);
				}
				lastKnownContext = currentContext;
				currentContext = currentContext.getParentContext();
			}
			//FIXME: AZ - This is not always correct to resolve null source field in the root context
			//Need to provide sources definitions as part of CalculationContext creation
			return new ResolutionResult(null, lastKnownContext);
		}
		
		CalculationDelegate delegate = registry.getDelegate(name);
		if (delegate != null) {
			CalculationContext currentContext = this;
			while (currentContext != null) {
				Object value = currentContext.getStoredValue(name);
				if (value != null) {
					return new ResolutionResult(decodeNull(value), currentContext);
				}
				currentContext = currentContext.getParentContext();
			}
			
			ResolutionResult result = delegate.resolve(this);
			result.contextResolved.storeCalculatedValue(name, result.value);
			return result;
		}
		
		throw new CalculationEngineException("No source field or calculation is registered with the given name: " + name);
	}
	
	synchronized void storeCalculatedValue(String name, Object value) {
		storedValues.put(name, encodeNull(value));
	}
	
	synchronized Object getSourceValue(String name) {
		if (sourceValues.containsKey(name)) {
			return encodeNull(sourceValues.get(name));
		} else {
			return null;
		}
	}
	
	synchronized Object getStoredValue(String name) {
		return storedValues.get(name);
	}
	
	synchronized void deleteResolvedFieldKeys(Set<String> fieldKeys) {
		if (fieldKeys.isEmpty()) return;
		
		fieldKeys.removeAll(sourceValues.keySet());
		fieldKeys.removeAll(storedValues.keySet());
		
		if (parentContext != null) {
			parentContext.deleteResolvedFieldKeys(fieldKeys);
		} else {
			return;
		}
	}

	
	CalculationContext getContext(int contextLevel) {
		CalculationContext parentContext = this;
		for (int lvl = level; lvl > contextLevel; lvl--) {
			parentContext = parentContext.parentContext;
		}
		
		return parentContext;
	}
	
	void setSourceValues(Map<String, ?> sourceValues) {
		this.sourceValues = sourceValues;
	}
	
	public Map<String,Object> getCopyOfSource() {
		
		/**
		 * This is not a deep Copy.- SG, Just copies all key,values from 1 map to the other
		 */
		Map<String, Object> map = new HashMap<String, Object>();
		synchronized (sourceValues) {
			map.putAll(sourceValues);
		}
		return map;
	}
	
	
	void setRegistry(CalculationRegistry calculationRegistry) {
		this.registry = calculationRegistry;
	}
	
	void setParentContext(CalculationContext parentContext) {
		this.parentContext = parentContext;
	}
	
	CalculationContext getParentContext() {
		return parentContext;
	}
	
	void setLevel(int level) {
		this.level = level;
	}
	
	int getLevel() {
		return level;
	}
	
	private Object encodeNull(Object value) {
		return value != null ? value : NULL_LEGIT ;
	}
	
	private Object decodeNull(Object value) {
		return value != NULL_LEGIT && value != NULL_CALC_NOT_FOUND && value != NULL_EXCEPTION ? value : null;
	}
	
	static class ResolutionResult {
		Object value;
		CalculationContext contextResolved;
		
		public ResolutionResult(Object value, CalculationContext contextResolved) {
			this.value = value;
			this.contextResolved = contextResolved;
		}
	}
	
	static final Object NULL_LEGIT = new Object();
	static final Object NULL_CALC_NOT_FOUND = new Object();
	static final Object NULL_EXCEPTION = new Object();
}
