package com.wf.df.sdr.calc.core.def;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="dependency", namespace="http://www.headstrong.com/calculations")
public class Dependency {
	private String dependencyName;
	
	public Dependency() {
		
	}
	
	public Dependency(String dependencyName) {
		this.dependencyName = dependencyName;
	}

	@XmlAttribute(name="ref", required=true)
	public String getDependencyName() {
		return dependencyName;
	}

	public void setDependencyName(String dependencyName) {
		this.dependencyName = dependencyName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dependencyName == null) ? 0 : dependencyName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dependency other = (Dependency) obj;
		if (dependencyName == null) {
			if (other.dependencyName != null)
				return false;
		} else if (!dependencyName.equals(other.dependencyName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Dependency [dependencyName=" + dependencyName + "]";
	}

	
}