package com.wf.df.sdr.calc.core.def;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement(name="select")
@XmlType(propOrder={"name", "check", "defaultPick", "options"})
public class SelectCalculationDefinition extends CalculationDefinition {
	
	private String check;
	private String defaultPick;
	private List<SelectOption> options;
	
	public SelectCalculationDefinition() {
	}
	
	public SelectCalculationDefinition(String name, String check, String defaultPick, List<SelectOption> options) {
		super(name);
		this.check = check;
		this.defaultPick = defaultPick;
		this.options = options;
	}
	

	@Override
	@XmlAttribute(name="id", required=true)
	public String getName() {
		return super.getName();
	}
	
	@Override
	public void setName(String name) {
		super.setName(name);
	}

	@XmlAttribute(name="check", required=true)
	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	@XmlAttribute(name="default", required=false)
	public String getDefaultPick() {
		return defaultPick;
	}

	public void setDefaultPick(String defaultPick) {
		this.defaultPick = defaultPick;
	}

	@XmlElementRef
	public List<SelectOption> getOptions() {
		return options;
	}

	public void setOptions(List<SelectOption> options) {
		this.options = options;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((check == null) ? 0 : check.hashCode());
		result = prime * result
				+ ((defaultPick == null) ? 0 : defaultPick.hashCode());
		result = prime * result + ((options == null) ? 0 : options.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelectCalculationDefinition other = (SelectCalculationDefinition) obj;
		if (check == null) {
			if (other.check != null)
				return false;
		} else if (!check.equals(other.check))
			return false;
		if (defaultPick == null) {
			if (other.defaultPick != null)
				return false;
		} else if (!defaultPick.equals(other.defaultPick))
			return false;
		if (options == null) {
			if (other.options != null)
				return false;
		} else if (!options.equals(other.options))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SelectCalculationDefinition [name=" + name + ", check=" + check + ", defaultPick="
				+ defaultPick + ", options=" + options + "]";
	}

	
}
