package com.wf.df.sdr.calc.core.def;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="extended")
@XmlType(propOrder={"name", "baseCalculationName", "dependencies"})
public class ExtendedCalculationDefinition extends CalculationDefinition {
	private String baseCalculationName;
	private List<Dependency> dependencies;
	
	public ExtendedCalculationDefinition() {
		
	}
	
	public ExtendedCalculationDefinition(String calculationName, String baseCalculationName, String[] extendedDependencyNames) {
		super(calculationName);
		this.baseCalculationName = baseCalculationName;
		this.dependencies = new ArrayList<Dependency>();
		for (String dependencyName : extendedDependencyNames) {
			dependencies.add(new Dependency(dependencyName));
		}
	}
	
	
	@Override
	@XmlAttribute(name="id", required=true)
	public String getName() {
		return super.getName();
	}
	
	@Override
	public void setName(String name) {
		super.setName(name);
	}

	@XmlAttribute(name="prototype", required=true)
	public String getBaseCalculationName() {
		return baseCalculationName;
	}

	public void setBaseCalculationName(String baseCalculationName) {
		this.baseCalculationName = baseCalculationName;
	}

	@XmlElementRef
	public List<Dependency> getDependencies() {
		return dependencies;
	}

	public void setDependencies(List<Dependency> dependencies) {
		this.dependencies = dependencies;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((baseCalculationName == null) ? 0 : baseCalculationName
						.hashCode());
		result = prime * result
				+ ((dependencies == null) ? 0 : dependencies.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExtendedCalculationDefinition other = (ExtendedCalculationDefinition) obj;
		if (baseCalculationName == null) {
			if (other.baseCalculationName != null)
				return false;
		} else if (!baseCalculationName.equals(other.baseCalculationName))
			return false;
		if (dependencies == null) {
			if (other.dependencies != null)
				return false;
		} else if (!dependencies.equals(other.dependencies))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ExtendedCalculationDefinition [name=" + name + ", baseCalculationName="
				+ baseCalculationName + ", dependencies=" + dependencies + "]";
	}

	
}
