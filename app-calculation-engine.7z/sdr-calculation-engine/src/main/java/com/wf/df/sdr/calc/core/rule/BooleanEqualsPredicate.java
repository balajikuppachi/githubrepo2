package com.wf.df.sdr.calc.core.rule;

import java.util.HashMap;
import java.util.Map;

public class BooleanEqualsPredicate extends AbstractPredicate<Boolean> {

private String valueString;
	
	@SuppressWarnings("serial")
	private static Map<String, Boolean> stringToBooleanMap = new HashMap<String, Boolean>(){
		{	put("YES",true);
			put("NO",false);
			put("Y",true);
			put("N",false);
			put("TRUE",true);
			put("FALSE",false);
			
		}
	};

	public BooleanEqualsPredicate(String valueString) {
		this.valueString = valueString;
	}

	@Override
	public boolean evaluate(Boolean arg) {
		return valueString == null || ( (arg != null) &&  arg.equals(stringToBooleanMap.get(valueString.toUpperCase())) );		
	}
	
	
}
