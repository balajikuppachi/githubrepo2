package com.wf.df.sdr.calc.core.def;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="option")
@XmlType(propOrder={"ifEquals", "pick"})
public class SelectOption {
	
	private String ifEquals;
	private String pick;
	
	public SelectOption() {
	}
	
	public SelectOption(String ifEquals, String pick) {
		this.ifEquals = ifEquals;
		this.pick = pick;
	}

	@XmlAttribute(name="ifEquals", required=true)
	public String getIfEquals() {
		return ifEquals;
	}

	public void setIfEquals(String ifEquals) {
		this.ifEquals = ifEquals;
	}

	@XmlAttribute(name="pick", required=true)
	public String getPick() {
		return pick;
	}

	public void setPick(String pick) {
		this.pick = pick;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ifEquals == null) ? 0 : ifEquals.hashCode());
		result = prime * result + ((pick == null) ? 0 : pick.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelectOption other = (SelectOption) obj;
		if (ifEquals == null) {
			if (other.ifEquals != null)
				return false;
		} else if (!ifEquals.equals(other.ifEquals))
			return false;
		if (pick == null) {
			if (other.pick != null)
				return false;
		} else if (!pick.equals(other.pick))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SelectOption [ifEquals=" + ifEquals + ", pick=" + pick + "]";
	}
	
	
}