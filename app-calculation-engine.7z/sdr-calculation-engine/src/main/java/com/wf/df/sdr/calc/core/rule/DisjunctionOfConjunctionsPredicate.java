package com.wf.df.sdr.calc.core.rule;

import java.util.List;
import java.util.ListIterator;

public class DisjunctionOfConjunctionsPredicate<T> extends AbstractPredicate<List<T>> {
	
	private List<ConjunctionPredicate> predicates;
	
	public DisjunctionOfConjunctionsPredicate(List<ConjunctionPredicate> predicates) {
		this.predicates = predicates;
	}

	@Override
	public boolean evaluate(List<T> args) {
		ListIterator<ConjunctionPredicate> predicateIter = predicates.listIterator();
		
		while (predicateIter.hasNext()) {
			ConjunctionPredicate predicate = predicateIter.next();
			if (predicate.evaluate(args)) {
				return true;
			}
		}
		
		return false;
	}
}
