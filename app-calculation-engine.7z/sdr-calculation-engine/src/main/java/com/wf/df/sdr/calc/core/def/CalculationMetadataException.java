package com.wf.df.sdr.calc.core.def;

public class CalculationMetadataException extends RuntimeException {
	
	private static final long serialVersionUID = -558995210883999494L;

	public CalculationMetadataException() {
		super();
	}
	
	public CalculationMetadataException(String message) {
		super(message);
	}
	
	public CalculationMetadataException(Throwable cause) {
		super(cause);
	}
	
	public CalculationMetadataException(String message, Throwable cause) {
		super(message, cause);
	}
}
