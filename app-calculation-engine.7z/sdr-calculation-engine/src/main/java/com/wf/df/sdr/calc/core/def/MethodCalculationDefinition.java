package com.wf.df.sdr.calc.core.def;

import java.lang.reflect.Method;

public class MethodCalculationDefinition extends CalculationDefinition {
	
	private Object bean;
	private Method method;
	
	private String[] dependencyNames;
	private Boolean[] dependenciesInternalFlags;
	private int internalDependenciesCount = 0;
	private int calculationDefinitionParamIndex = -1;
	private int dependenciesAsListParamIndex = -1;
	
	
	public MethodCalculationDefinition(String calculationName, Object bean, Method method, String[] dependencyNames, Boolean[] dependencyInternalFlags,
			int calculationDefinitionParamIndex, int dependenciesAsListParamIndex)
	{
		super(calculationName);

		this.bean = bean;
		this.method = method;
		this.dependencyNames = dependencyNames;
		this.dependenciesInternalFlags = dependencyInternalFlags;
		this.calculationDefinitionParamIndex = calculationDefinitionParamIndex;
		this.dependenciesAsListParamIndex = dependenciesAsListParamIndex;
		
		
		for(int i = 0; i < dependencyInternalFlags.length; i++) {
			if (dependencyInternalFlags[i]) {
				internalDependenciesCount++;
			}
		}
		
	}
	
	public Object getBean() {
		return bean;
	}

	public Method getMethod() {
		return method;
	}
	
	public String[] getDependencyNames() {
		return dependencyNames;
	}
	
	public Boolean[] getDependencyInternalFlags() {
		return dependenciesInternalFlags;
	}
	
	public int getInternalDependenciesCount() {
		return internalDependenciesCount;
	}
	
	public int getCalculationDefinitionParamIndex() {
		return calculationDefinitionParamIndex;
	}
	
	public int getDependenciesAsListParamIndex() {
		return dependenciesAsListParamIndex;
	}
}
