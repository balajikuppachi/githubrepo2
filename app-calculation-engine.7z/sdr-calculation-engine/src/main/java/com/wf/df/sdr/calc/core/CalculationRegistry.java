package com.wf.df.sdr.calc.core;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.DirectMappingCalc;
import com.wf.df.sdr.calc.core.def.CalculationDefinition;
import com.wf.df.sdr.calc.core.def.ConstantCalculationDefinition;
import com.wf.df.sdr.calc.core.def.ExtendedCalculationDefinition;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.calc.core.def.SelectCalculationDefinition;
import com.wf.df.sdr.calc.core.def.Source;
import com.wf.df.sdr.calc.core.def.SourceField;

@Component
public class CalculationRegistry implements SmartLifecycle {
	
	/**
	 * For some reason JMS Listener Container endpoint has a bean lifecycle phase of 0
	 * while other message-generating components has it set to Integer.MAX_VALUE. 
	 * We need to make sure CalculationRegistry is started before we consume any message from 
	 * the JMS queue and that's why we set the phase for CalculationRegistry to something less than 0.
	 */
	public static final int BEAN_LIFECYCLE_PHASE = -10;
	
	private Logger logger = LoggerFactory.getLogger(getClass()); 
	
	private Map<String, CalculationPrototype> prototypes = new HashMap<String, CalculationPrototype>();
	
	private Map<String, CalculationDefinition> definitions = new HashMap<String, CalculationDefinition>();
	
	private Map<String, SourceField> sourceFields = new HashMap<String, SourceField>();
	
	private Map<String, CalculationDelegate> delegates;
	
	private volatile boolean running;
	private final ReentrantLock lifecycleLock = new ReentrantLock();
	
	@Autowired
	private BeanFactory beanFactory;
	
	
	public void registerPrototype(CalculationPrototype prototype) {
		if (isRunning()) {
			throw new IllegalStateException("Cannot register calculation prototype: calculation registry is already started");
		}
		if (prototype.getName() == null || prototype.getName().trim().isEmpty()) {
			throw new IllegalStateException("Cannot register calculation prototype: calculation name is null or empty");
		}
		if (prototype.getDependencyNames().length == prototype.getInternalDependenciesCount()) {
			throw new CalculationEngineException("Cannot register calculation prototype - all the dependencies are internal: '" + prototype.getName() +"'");
		}
		
		prototypes.put(prototype.getName(), prototype);
		
		logger.debug("Registered calculation prototype '" + prototype.getName()
				+ "': " + prototype.getBean().getClass().getName()
				+ " " + prototype.getMethod().getName() + "()");
	}

	public void addDefinition(CalculationDefinition definition) {
		if (isRunning()) {
			throw new IllegalStateException("Cannot register calculation definition: calculation registry is already started");
		}
		if (definition.getName() == null || definition.getName().trim().isEmpty()) {
			throw new IllegalStateException("Cannot register calculation definition: calculation name is null or empty");
		}
		if (definitions.containsKey(definition.getName())) {
			throw new CalculationEngineException("Calculation name is not unique: '" + definition.getName() +"'");
		}
		if (sourceFields.containsKey(definition.getName())) {
			throw new CalculationEngineException("Cannot register calculation '" + definition.getName() + "': source field is defined with the same name");
		}
		definitions.put(definition.getName(), definition);
	}

	public void addSource(Source source) {
		if (isRunning()) {
			throw new IllegalStateException("Cannot register source definition: calculation registry is already started");
		}
		
		for (SourceField sourceField : source.getFields().values()) {
			if (sourceField.getId() == null || sourceField.getId().trim().isEmpty()) {
				throw new IllegalStateException("Cannot register source field defined in source '" + source.getId() + "': field id is null or empty");
			}
			if (definitions.containsKey(sourceField.getId())) {
				throw new CalculationEngineException("Cannot register source field '" + sourceField.getId() + "' defiend in source '" + source.getId() + "': calculation is defined with the same name");
			}
			sourceFields.put(sourceField.getId(), sourceField);
		}
	}
	
	public boolean isValueDefined(String name) {
		return delegates.containsKey(name) || sourceFields.containsKey(name);
	}

	public CalculationContext createContext(Map<String, ?> sources) {
		if (!isRunning()) {
			throw new IllegalStateException("Cannot create calculation context: calculation registry is not started");
		}
		CalculationContext context = beanFactory.getBean(CalculationContext.class);
		context.setLevel(0);
		context.setRegistry(this);
		context.setSourceValues(sources);
		return context;
	}
	
	public CalculationContext createContext(CalculationContext parentContext, Map<String, ?> sources) {
		if (!isRunning()) {
			throw new IllegalStateException("Cannot create calculation context: calculation registry is not started");
		}
		if (parentContext.getCalculationRegistry() != this) {
			throw new IllegalStateException("Cannot create calculation context: parent calculation context has been created with a different calculation registry");
		}
		
		Set<String> sourceKeys = new LinkedHashSet<String>(sources.keySet());
		parentContext.deleteResolvedFieldKeys(sourceKeys);
		if (sourceKeys.size() != sources.size()) {
			Set<String> sourceKeys2 = new LinkedHashSet<String>(sources.keySet());
			sourceKeys2.removeAll(sourceKeys);
			throw new CalculationEngineException("Child calculation context cannot be created as it's trying to redefine parent's source fields or calculations: " + sourceKeys2);
		}
		
		CalculationContext context = beanFactory.getBean(CalculationContext.class);
		context.setRegistry(this);
		context.setParentContext(parentContext);
		context.setLevel(parentContext.getLevel() + 1);
		context.setSourceValues(sources);
		return context;
	}
	
	CalculationDelegate getDelegate(String name) {
		if (prototypes.containsKey(name)) {
			throw new CalculationEngineException("Cannot get a value of the prototype calculation: " + name);
		}
		return delegates.get(name);
	}
	
	CalculationPrototype getPrototype(String name) {
		return prototypes.get(name);
	}
	
	SourceField getSourceField(String id) {
		return sourceFields.get(id);
	}
	
	private void doStart() {
		logger.debug("Starting calculation registry...");
		delegates = new HashMap<String, CalculationDelegate>(definitions.size());
		
		createDelegates();
		initDelegates();
		logger.info("started calculationRegistry");
	}
	
	private void doStop() {
		logger.info("stopped calculationRegistry");
	}
	
	private void createDelegates() {
		for (CalculationDefinition def : definitions.values()) {
			CalculationDelegate delegate;
			if (def instanceof MethodCalculationDefinition) {
				delegate = createDelegate((MethodCalculationDefinition)def);
			} else if (def instanceof ExtendedCalculationDefinition) {
				delegate = createDelegate((ExtendedCalculationDefinition)def);
			} else if (def instanceof SelectCalculationDefinition) {
				delegate = createDelegate((SelectCalculationDefinition)def);
			} else if (def instanceof ConstantCalculationDefinition) {
				delegate = createDelegate((ConstantCalculationDefinition)def);
			} else {
				throw new CalculationEngineException("Unexpected calculation definition class: " + def.getClass().getName());
			}
			
			delegates.put(def.getName(), delegate);
			
			logger.debug("Created delegate " + delegate + " for definition '" + def);
		}
	}

	private MethodCalculationDelegate createDelegate(MethodCalculationDefinition def) {
		return new MethodCalculationDelegate(this, def);
	}
	
	private MethodCalculationDelegate createDelegate(ExtendedCalculationDefinition def) {
		CalculationPrototype prototypeDef = prototypes.get(def.getBaseCalculationName());
		if (prototypeDef == null) {
			CalculationDefinition baseDef = definitions.get(def.getBaseCalculationName());
			if (baseDef == null) {
				throw new CalculationEngineException("Cannot register calculation '" + def.getName() +
						"' - base calculation is not defined: '" + def.getBaseCalculationName() + "'");
			} else if (def.getDependencies().size() > 0) {
				throw new CalculationEngineException("Cannot register calculation '" + def.getName() +
						"' - base calculation must be a prototype calculation or have no dependencies: '" + def.getBaseCalculationName() + "'");
			} else {
				//Allow "extending" from non-prototype calculations by using directMappingCalc
				def = new ExtendedCalculationDefinition(def.getName(), DirectMappingCalc.NAME, new String[] {baseDef.getName()});
				prototypeDef = prototypes.get(DirectMappingCalc.NAME);
			}
		}
		
		String[] existingDependencies = prototypeDef.getDependencyNames();
		int internalDepenciesCount = prototypeDef.getInternalDependenciesCount();
		
		if (def.getDependencies().size() != existingDependencies.length - internalDepenciesCount) {
			throw new CalculationEngineException("Cannot register calculation '" + def.getName() +
					"': base calculation '" + def.getBaseCalculationName() + "' expects exactly " + (existingDependencies.length - internalDepenciesCount ) +
					" non-internal dependencies, while " + def.getDependencies().size() + " has been provided");
		}
		
		Boolean[] internalDependencies = prototypeDef.getDependencyInternalFlags();
		
		String[] newDependencies = new String[existingDependencies.length];
		Boolean[] newInternalDependencies = Arrays.copyOf(internalDependencies, internalDependencies.length);
		
		for (int i = 0, j = 0; i < existingDependencies.length; i++) {
			if (internalDependencies[i]) {
				newDependencies[i] = existingDependencies[i];
			} else {
				newDependencies[i] = def.getDependencies().get(j++).getDependencyName();
			}
		}
		
		
		MethodCalculationDefinition newDef = new MethodCalculationDefinition(
				def.getName(),
				prototypeDef.getBean(),
				prototypeDef.getMethod(),
				newDependencies,
				newInternalDependencies,
				prototypeDef.getCalculationDefinitionParamIndex(),
				-1);
		
		return createDelegate(newDef);
	}
	
	private CalculationDelegate createDelegate(SelectCalculationDefinition def) {
		return new SelectCalculationDelegate(this, def);
	}
	
	private CalculationDelegate createDelegate(ConstantCalculationDefinition def) {
		return new ConstantCalculationDelegate(this, def);
	}
	
	private void initDelegates() {
		for (CalculationDelegate delegate : delegates.values()) {
			delegate.init();
		}
		
		if (logger.isDebugEnabled()) {
			for (CalculationDefinition def: definitions.values()) {
				String calcName = def.getName();
				CalculationDelegate delegate = delegates.get(calcName);
				if (calcName != null && calcName.contains(":")) {
					Set<String> sourceDependencies = new HashSet<String>();
					populateSourceDependencies(sourceDependencies, delegate);
					for (String dependency : sourceDependencies) {
						logger.debug("Field '" + calcName + "' depends on '" + dependency + "'");
					}
				}
			}
//			Set<String> sourceDependencies = new TreeSet<String>();
//			for (CalculationDefinition def: definitions.values()) {
//				String calcName = def.getName();
//				CalculationDelegate delegate = delegates.get(calcName);
//				populateSourceDependencies(sourceDependencies, delegate);
//			}
//			logger.debug("All source fields:");
//			for (String dependency : sourceDependencies) {
//				System.out.println("\t\t\t\t<field id=\"" + dependency + "\"/>");
////				logger.debug(dependency);
//			}
		}
	}
	
	private void populateSourceDependencies(Set<String> sourceDependencies, CalculationDelegate delegate) {
		for (String dependencyName : delegate.getDependencyNames()) {
			if (delegates.containsKey(dependencyName)) {
				populateSourceDependencies(sourceDependencies, delegates.get(dependencyName));
			} else {
				sourceDependencies.add(dependencyName);
			}
		}
	}
	

	@Override
	public void start() {
		this.lifecycleLock.lock();
		try {
			doStart();
			running = true;
		} finally {
			this.lifecycleLock.unlock();
		}
	}


	@Override
	public void stop() {
		this.lifecycleLock.lock();
		try {
			doStop();
			running = false;
		} finally {
			this.lifecycleLock.unlock();
		}
			
	}

	@Override
	public void stop(Runnable callback) {
		this.lifecycleLock.lock();
		try {
			try {
				doStop();
				running = false;
			} finally {
				callback.run();
			}
		} finally {
			this.lifecycleLock.unlock();
		}
	}

	@Override
	public boolean isRunning() {
		this.lifecycleLock.lock();
		try {
			return running;
		} finally {
			this.lifecycleLock.unlock();
		}
	}


	@Override
	public int getPhase() {
		return BEAN_LIFECYCLE_PHASE;
	}


	@Override
	public boolean isAutoStartup() {
		return true;
	}

}
