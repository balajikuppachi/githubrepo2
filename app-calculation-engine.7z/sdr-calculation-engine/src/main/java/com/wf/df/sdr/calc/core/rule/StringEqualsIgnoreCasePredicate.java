package com.wf.df.sdr.calc.core.rule;

public class StringEqualsIgnoreCasePredicate extends AbstractPredicate<String> {
	
	private String stringToMatch;
	
	public StringEqualsIgnoreCasePredicate(String stringToMatch) {
		this.stringToMatch = stringToMatch;
	}

	@Override
	public boolean evaluate(String arg) {
		return stringToMatch == null || (arg != null && stringToMatch.equalsIgnoreCase(arg));
	}
}
