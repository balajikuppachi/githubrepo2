package com.wf.df.sdr.calc.core;

import java.lang.reflect.Type;

import com.wf.df.sdr.calc.core.CalculationContext.ResolutionResult;
import com.wf.df.sdr.calc.core.def.ConstantCalculationDefinition;

public class ConstantCalculationDelegate implements CalculationDelegate {
	
	private CalculationRegistry registry;
	private ConstantCalculationDefinition definition;
	
	ConstantCalculationDelegate(CalculationRegistry registry, ConstantCalculationDefinition definition) {
		this.registry = registry;
		this.definition = definition;
	}

	@Override
	public CalculationRegistry getCalculationRegistry() {
		return registry;
	}
	
	@Override
	public String[] getDependencyNames() {
		return new String[0];
	}

	@Override
	public Type getReturnType() {
		return String.class;
	}

	@Override
	public void init() {
		// No initialization needed
	}

	@Override
	public ResolutionResult resolve(CalculationContext context) {
		CalculationContext contextResolved = context;
		while (contextResolved.getParentContext() != null)
			contextResolved = contextResolved.getParentContext();
		
		return new ResolutionResult(definition.getValue(), contextResolved);
	}
}
