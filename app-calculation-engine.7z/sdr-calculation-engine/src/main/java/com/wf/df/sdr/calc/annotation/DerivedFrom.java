package com.wf.df.sdr.calc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Indicates that a parameter is another calculation or source field that
 * this calculation is derived from
 * 
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
public @interface DerivedFrom {
	boolean isInternal() default false;
	String value();
}
