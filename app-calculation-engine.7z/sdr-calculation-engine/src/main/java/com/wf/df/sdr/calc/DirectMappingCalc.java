package com.wf.df.sdr.calc;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;

@Component
public class DirectMappingCalc {
	
	public static final String NAME = "directMappingCalc";
	
	@Calculation(value = NAME)
	public String executionVenue(
			@DerivedFrom("sourceField") String value)
	{
		return value;
	}
}
