package com.wf.df.sdr.calc.core.rule;

public interface Predicate<T> {
	boolean evaluate(T arg);
	boolean evaluateNonTypeSafe(Object arg);
}
