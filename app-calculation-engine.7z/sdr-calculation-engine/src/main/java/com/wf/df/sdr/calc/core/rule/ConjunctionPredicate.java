package com.wf.df.sdr.calc.core.rule;

import java.util.List;
import java.util.ListIterator;

public class ConjunctionPredicate extends AbstractPredicate<List<?>> {
	
	private List<Predicate<?>> predicates;
	
	public ConjunctionPredicate(List<Predicate<?>> predicates) {
		this.predicates = predicates;
	}

	@Override
	public boolean evaluate(List<?> args) {
		ListIterator<Predicate<?>> predicateIter = predicates.listIterator();
		ListIterator<?> argIter = args.listIterator();
		
		while (predicateIter.hasNext()) {
			Predicate<?> predicate = predicateIter.next();
			Object arg = argIter.next();
			if (!predicate.evaluateNonTypeSafe(arg)) {
				return false;
			}
		}
		
		return true;
	}
}
