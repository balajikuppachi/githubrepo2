package com.wf.df.sdr.calc.core.rule;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationEngineException;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;

@Component
public class CalculationDefinitionBuilder {
	
	public static final String SEPARATOR = "~";
	
	@Autowired
	PredicateFactory predicateFactory;
	
	public MethodCalculationDefinition createRuleFromFile(String ruleName, InputStream in) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(in)) {
			@Override
			public String readLine() throws IOException {
				String result = super.readLine();
				while (result != null) {
					if (!result.startsWith("#")) {
						return result;
					}
					result = super.readLine();
				}
				
				return null;
			}
		};
		
		String[] fields = reader.readLine().split(SEPARATOR);
		String[] conditions = reader.readLine().split(SEPARATOR);
		
		List<ConjunctionPredicate> conjunctionPredicates = new LinkedList<ConjunctionPredicate>();
		String line;
		while ((line = reader.readLine()) != null) {
			String[] params = line.split(SEPARATOR, -1);
			conjunctionPredicates.add(buildConjunctionPredicate(fields, conditions, params));
		}
		
		DisjunctionOfConjunctionsPredicate<Object> predicate = new DisjunctionOfConjunctionsPredicate<Object>(conjunctionPredicates);
		
		PredicateCalcHelper<Object> helper = new PredicateCalcHelper<Object>(predicate);
		
		return helper.createCalculationDefinition(ruleName, fields);
	}
	
	private ConjunctionPredicate buildConjunctionPredicate(String[] fields, String[] conditions, String[] params) {
		List<Predicate<?>> predicates = new LinkedList<Predicate<?>>();
		
		for (int i = 0; i < fields.length; i++) {
			predicates.add(predicateFactory.createPredicate(conditions[i], nullIfEmpty(params[i])));
		}
		
		return new ConjunctionPredicate(predicates);
	}
	
	private String nullIfEmpty(String str) {
		return str == null || str.isEmpty() ? null : str;
	}

	public static class PredicateCalcHelper<T> {
		
		private Predicate<List<T>> predicate;
		
		private PredicateCalcHelper(Predicate<List<T>> predicate) {
			this.predicate = predicate;
		}
		
		public Boolean evaluate(
				List<T> arg)
		{
			return predicate.evaluate(arg);
		}
		
		private MethodCalculationDefinition createCalculationDefinition(String calcName, String[] dependencyNames) {
			Boolean[] internalDependencies = new Boolean[dependencyNames.length];
			Arrays.fill(internalDependencies, Boolean.FALSE);
			
			return new MethodCalculationDefinition(
					calcName,
					this,
					getCalcMethod(),
					dependencyNames,
					internalDependencies,
					getCalculationDefinitionParamIndex(),
					getCalculationDependenciesAsListParamIndex());
		}
		
		private Method getCalcMethod() {
			try {
				return getClass().getMethod("evaluate", List.class);
			} catch (SecurityException e) {
				throw new CalculationEngineException("Couldn't get calculation method for predicate calculation");
			} catch (NoSuchMethodException e) {
				throw new CalculationEngineException("Couldn't get calculation method for predicate calculation");
			}
		}
		
		private int getCalculationDefinitionParamIndex() {
			return -1;
		}
		
		private int getCalculationDependenciesAsListParamIndex() {
			return 0;
		}
	}
}
