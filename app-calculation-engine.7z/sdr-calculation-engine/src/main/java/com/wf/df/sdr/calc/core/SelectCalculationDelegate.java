package com.wf.df.sdr.calc.core;

import java.lang.reflect.Type;
import java.util.LinkedList;
import java.util.List;

import com.wf.df.sdr.calc.core.CalculationContext.ResolutionResult;
import com.wf.df.sdr.calc.core.def.SelectCalculationDefinition;
import com.wf.df.sdr.calc.core.def.SelectOption;

public class SelectCalculationDelegate implements CalculationDelegate {
	
	private CalculationRegistry registry;
	
	private SelectCalculationDefinition definition;
	
	SelectCalculationDelegate(CalculationRegistry registry, SelectCalculationDefinition definition) {
		this.registry = registry;
		this.definition = definition;
	}

	@Override
	public CalculationRegistry getCalculationRegistry() {
		return registry;
	}
	
	@Override
	public String[] getDependencyNames() {
		List<String> dependencyNames = new LinkedList<String>();
		dependencyNames.add(definition.getCheck());
		if (definition.getDefaultPick() != null) {
			dependencyNames.add(definition.getDefaultPick());
		}
		for (SelectOption option : definition.getOptions()) {
			dependencyNames.add(option.getIfEquals());
			dependencyNames.add(option.getPick());
		}
		return dependencyNames.toArray(new String[dependencyNames.size()]);
	}

	@Override
	public Type getReturnType() {
		//FIXME: AZ - implement getReturnType()
		throw new UnsupportedOperationException("getReturnType() is not supported");
	}

	@Override
	public void init() {
		// No initialization needed
	}

	@Override
	public ResolutionResult resolve(CalculationContext context) {
		ResolutionResult checkResult = context.resolveValue(definition.getCheck());
		CalculationContext maxContext = checkResult.contextResolved;
		CalculationContext.ResolutionResult pickResult = null;
		for (SelectOption option : definition.getOptions()) {
			ResolutionResult ifEqualsResult = context.resolveValue(option.getIfEquals());
			maxContext = max(maxContext, ifEqualsResult.contextResolved);
			if ((checkResult.value != null && checkResult.value.equals(ifEqualsResult.value)) ||
					(checkResult.value == null && ifEqualsResult.value == null)) {
				pickResult = context.resolveValue(option.getPick());
				maxContext = max(maxContext, pickResult.contextResolved);
				break;
			}
		}
		
		if (pickResult == null && definition.getDefaultPick() != null) {
			pickResult = context.resolveValue(definition.getDefaultPick());
			maxContext = max(maxContext, pickResult.contextResolved);
		}
		
		if (pickResult != null) {
			return new CalculationContext.ResolutionResult(pickResult.value, maxContext); 
		}
		
		//TODO: AZ - consider throwing an exception or making the default value required
		return new CalculationContext.ResolutionResult(null, maxContext); 
	}
	
	private CalculationContext max(CalculationContext context1, CalculationContext context2) {
		return context1.getLevel() > context2.getLevel() ? context1 : context2;
	}
}
