package com.wf.df.sdr.calc.core;

public class CalculationEngineException extends RuntimeException {
	
	private static final long serialVersionUID = 8096636615553150736L;

	public CalculationEngineException() {
		super();
	}
	
	public CalculationEngineException(String message) {
		super(message);
	}
	
	public CalculationEngineException(Throwable cause) {
		super(cause);
	}
	
	public CalculationEngineException(String message, Throwable cause) {
		super(message, cause);
	}
}
