package com.wf.df.sdr.calc.core.rule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class PredicateFactory {
	
	public static final String PREDICATE_CONTAINS = "Contains";
	public static final String PREDICATE_EQUALS = "Equals";
	public static final String PREDICATE_CONTAINS_ELEMENT = "ContainsElement";
	public static final String PREDICATE_BOOLEAN_EQUALS = "BooleanEquals";
	
	
	@SuppressWarnings("serial")
	private Map<String, PredicateProvider<?>> predicateProvidersMap =
			new HashMap<String, PredicateProvider<?>>() {{
		put(PREDICATE_CONTAINS, new StringContainsIgnoreCasePredicateProvider());		
		put(PREDICATE_EQUALS, new StringEqualsIgnoreCasePredicateProvider());		
		put(PREDICATE_CONTAINS_ELEMENT, new ListContainsPredicateProvider<String>());	
		put(PREDICATE_BOOLEAN_EQUALS, new BooleanEqualsPredicateProvider<String>());
	}};
	
	public <T> Predicate<T> createPredicate(String name, Object param) {
		@SuppressWarnings("unchecked")
		PredicateProvider<T> provider = (PredicateProvider<T>)predicateProvidersMap.get(name);
		return provider.createPredicate(param);
	}
	
	private static interface PredicateProvider<T> {
		Predicate<T> createPredicate(Object param);
	}
	
	private static class StringContainsIgnoreCasePredicateProvider implements PredicateProvider<String> {
		@Override
		public Predicate<String> createPredicate(Object param) {
			return new StringContainsIgnoreCasePredicate((String)param);
		}
	}

	private static class StringEqualsIgnoreCasePredicateProvider implements PredicateProvider<String> {
		@Override
		public Predicate<String> createPredicate(Object param) {
			return new StringEqualsIgnoreCasePredicate((String)param);
		}
	}

	private static class ListContainsPredicateProvider<T> implements PredicateProvider<List<T>> {
		@SuppressWarnings("unchecked")
		@Override
		public Predicate<List<T>> createPredicate(Object param) {
			return new ListContainsPredicate<T>((T)param);
		}
	}
	
	private static class BooleanEqualsPredicateProvider<T> implements PredicateProvider<Boolean> {
		@Override
		public Predicate<Boolean> createPredicate(Object param) {
			return new BooleanEqualsPredicate((String)param);
		}
	}

}
