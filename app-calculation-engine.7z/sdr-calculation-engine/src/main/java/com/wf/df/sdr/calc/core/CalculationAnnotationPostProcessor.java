package com.wf.df.sdr.calc.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;

import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;

@Component
public class CalculationAnnotationPostProcessor implements BeanPostProcessor {
	
	@Autowired
	CalculationRegistry calculationRegistry;

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		return bean;
	}
	
	@Override
	public Object postProcessAfterInitialization(final Object bean, final String beanName) throws BeansException {
		final Class<?> beanClass = this.getBeanClass(bean);
		ReflectionUtils.doWithMethods(beanClass, new ReflectionUtils.MethodCallback() {
			@Override
			public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
				Annotation[] annotations = AnnotationUtils.getAnnotations(method);
				for (Annotation annotation : annotations) {
					if (annotation instanceof Calculation) {
						Calculation calcAnnotation = (Calculation)annotation;

						Annotation[][] allParamAnnotations = method.getParameterAnnotations();
						Class<?>[] parameterTypes = method.getParameterTypes();
						int numberOfParams = allParamAnnotations.length;
						List<String> dependencyNames = new LinkedList<String>();
						List<Boolean> internalDependencies = new LinkedList<Boolean>();
						int calculationDefinitionParamIndex = -1;
						for (int paramIndex = 0; paramIndex < numberOfParams; paramIndex++) {
							
							if (parameterTypes[paramIndex].equals(MethodCalculationDefinition.class)) {
								if (calculationDefinitionParamIndex < 0) {
									calculationDefinitionParamIndex = paramIndex;
								} else {
									throw new CalculationEngineException("Calculation has two parameters of CalculationDefinition class: '" +
											calcAnnotation.value() + "', " + bean.getClass().getName() + " " + method.getName() +
											"(), parameters " + paramIndex + " and " + calculationDefinitionParamIndex);
								}
							} else {
							
								Annotation[] paramAnnotations = allParamAnnotations[paramIndex];
								DerivedFrom dfAnnotation = null;
								for (Annotation paramAnnotation : paramAnnotations) {
									if (paramAnnotation instanceof DerivedFrom) {
										dfAnnotation = (DerivedFrom)paramAnnotation;
										dependencyNames.add(dfAnnotation.value());
										internalDependencies.add(dfAnnotation.isInternal());
										break;
									}
								}
								if (dfAnnotation == null) {
									throw new CalculationEngineException("Calculation's parameter is not annotated with @DerivedFrom: '" + calcAnnotation.value() + "', " + bean.getClass().getName() + " " + method.getName() + "(), parameter " + paramIndex); 
								}
							}
						}
						
						if (calcAnnotation.isPrototype()) {
							calculationRegistry.registerPrototype(new CalculationPrototype(
									calcAnnotation.value(),
									bean,
									method,
									dependencyNames.toArray(new String[dependencyNames.size()]),
									internalDependencies.toArray(new Boolean[internalDependencies.size()]),
									calculationDefinitionParamIndex));
						} else {
							calculationRegistry.addDefinition(new MethodCalculationDefinition(
									calcAnnotation.value(),
									bean,
									method,
									dependencyNames.toArray(new String[dependencyNames.size()]),
									internalDependencies.toArray(new Boolean[internalDependencies.size()]),
									calculationDefinitionParamIndex,
									-1));
						}
					}
				}
			}
		});
		return bean;
	}
	
	private Class<?> getBeanClass(Object bean) {
		Class<?> targetClass = AopUtils.getTargetClass(bean);
		return (targetClass != null) ? targetClass : bean.getClass();
	}

}
