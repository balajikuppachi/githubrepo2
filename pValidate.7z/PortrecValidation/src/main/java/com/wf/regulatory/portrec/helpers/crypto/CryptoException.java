package com.wf.regulatory.portrec.helpers.crypto;

/******************************************************************************
 * Filename    : CryptoException.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

/**
 * Insert the type's description here.
 */
public class CryptoException extends Exception 
{
	private static final long serialVersionUID = 8045554872359572522L;

	/**
	 * CryptoException constructor comment.
	 */
	public CryptoException() 
	{
		super();
	}

	/**
	 * CryptoException constructor comment.
	 * 
	 * @param s
	 *            java.lang.String
	 */
	public CryptoException(String s) 
	{
		super(s);
	}

	/**
	 * CryptoException constructor comment.
	 * 
	 * @param description
	 *            java.lang.String
	 * @param ex
	 *            java.lang.Throwable
	 */
	public CryptoException(String description, Throwable ex) 
	{
		super(description, ex);
	}
}
