package com.wf.regulatory.portrec.helpers.crypto;

/******************************************************************************
 * Filename    : Base64Encoder.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class Base64Encoder 
{
	private static final char charMap[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G',
			'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
			'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
			'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
			'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6',
			'7', '8', '9', '+', '/' };

	public Base64Encoder() 
	{
	}

	public static char[] encode(byte abyte0[]) 
	{
		int i = abyte0.length;
		int j = i % 3;
		int k = i - j;
		char ac[] = new char[(i / 3) * 4 + (j != 0 ? 4 : 0)];
		int l = 0;
		int i1;
		
		for (i1 = 0; l < k; i1 += 4) 
		{
			encodeBlock3(abyte0, l, ac, i1);
			l += 3;
		}

		if (j == 1) 
		{
			encodeBlock1(abyte0, l, ac, i1);
		} 
		else if (j == 2) 
		{
			encodeBlock2(abyte0, l, ac, i1);
		}
		
		return ac;
	}

	private static void encodeBlock1(byte abyte0[], int i, char ac[], int j) 
	{
		byte byte0 = abyte0[i];
		ac[j] = charMap[byte0 >> 2 & 0x3f];
		ac[j + 1] = charMap[(byte0 & 3) << 4];
		ac[j + 2] = '=';
		ac[j + 3] = '=';
	}

	private static void encodeBlock2(byte abyte0[], int i, char ac[], int j) 
	{
		byte byte0 = abyte0[i];
		byte byte1 = abyte0[i + 1];
		ac[j] = charMap[byte0 >> 2 & 0x3f];
		ac[j + 1] = charMap[(byte0 & 3) << 4 | byte1 >> 4 & 0xf];
		ac[j + 2] = charMap[(byte1 & 0xf) << 2];
		ac[j + 3] = '=';
	}

	private static void encodeBlock3(byte abyte0[], int i, char ac[], int j) 
	{
		byte byte0 = abyte0[i];
		byte byte1 = abyte0[i + 1];
		byte byte2 = abyte0[i + 2];
		ac[j] = charMap[byte0 >> 2 & 0x3f];
		ac[j + 1] = charMap[(byte0 & 3) << 4 | byte1 >> 4 & 0xf];
		ac[j + 2] = charMap[(byte1 & 0xf) << 2 | byte2 >> 6 & 3];
		ac[j + 3] = charMap[byte2 & 0x3f];
	}
}

