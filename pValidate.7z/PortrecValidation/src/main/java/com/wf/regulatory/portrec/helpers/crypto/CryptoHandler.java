package com.wf.regulatory.portrec.helpers.crypto;

/******************************************************************************
 * Filename    : CryptoHandler.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class CryptoHandler 
{

	public static String decrypt(String input, String privateKey) 
	{
		byte dbytes[] = Base64Decoder.decode(input.toCharArray());
		return new String(dbytes);
	}

	public static String encrypt(String input, String privateKey) 
	{
		return new String(Base64Encoder.encode(input.getBytes()));
	}
	
	public static String generatePrivateKey() 
	{
		return "NOT_IMPLEMENTED";
	}
}