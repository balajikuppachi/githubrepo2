package com.wf.regulatory.portrec.main;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.Message;
import org.springframework.integration.MessagingException;

//@Component
public class PortrecDataValidator {

	@Value("${dev.db.url}")
	String devUrl;
	
	@Value("${dev.db.username}")
	String devUser;
	
	@Value("${dev.db.password}")
	String devPwd;
	
	@Value("${sit.db.url}")
	String sitUrl;
	
	@Value("${sit.db.username}")
	String sitUser;
	
	@Value("${sit.db.password}")
	String sitPwd;
	
	@Value("${uat.db.url}")
	String uatUrl;
	
	@Value("${uat.db.username}")
	String uatUser;
	
	@Value("${uat.db.password}")
	String uatPwd;
	
	@Value("${prod.db.url}")
	String prodUrl;
	
	@Value("${prod.db.username}")
	String prodUser;
	
	@Value("${prod.db.password}")
	String prodPwd;

	@Autowired
	ReportGenerator generator;
	
	private static final Logger logger = Logger.getLogger(PortrecDataValidator.class);

	public void start(Message<?> message) throws MessagingException {
		
		logger.info("PortrecDataValidator execution started ...");
		
		File sourceFile = null;
		Object inputMessage = message.getPayload();
		try {
			if (inputMessage instanceof File) {

				sourceFile = ((File) inputMessage);

				String originalPayload = FileUtils.readFileToString(sourceFile);

				if (!originalPayload.isEmpty()) {
					load(originalPayload);
				}

			}
		} catch (Exception e) {
			logger.error("Error while executing PortrecDataValidator ..." + e.getMessage());
			e.printStackTrace();
		} finally {
			sourceFile.delete();
		}
		
		logger.info("PortrecDataValidator execution ended ...");
	}

	private void load(String originalPayload) throws Exception {
		
		logger.info("Enter load method:");
		
		try 
		{
			if (originalPayload.equals("DEV"))
			{
				generator.readExecuteQueryToValidateExcel(devUrl, devUser, devPwd);
			}
			else if (originalPayload.equals("SIT"))
			{
				generator.readExecuteQueryToValidateExcel(sitUrl, sitUser, sitPwd);
			}
			else if (originalPayload.equals("UAT"))
			{
				generator.readExecuteQueryToValidateExcel(uatUrl, uatUser, uatPwd);
			}
			else if (originalPayload.equals("PROD"))
			{
				generator.readExecuteQueryToValidateExcel(prodUrl, prodUser, prodPwd);
			}

		} catch (Exception e) {
			throw e;
		}
		
		logger.info("Exit load method:");
	}

}
