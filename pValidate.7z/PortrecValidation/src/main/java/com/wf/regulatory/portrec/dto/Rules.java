package com.wf.regulatory.portrec.dto;

public class Rules {
	
	String tableName;
	String ruleDesc;
	//String rulePassOrFail;
	String ruleByNumberPassOrFail;
	
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	public String getRuleDesc() {
		return ruleDesc;
	}
	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}
	
	/*public String getRulePassOrFail() {
		return rulePassOrFail;
	}
	public void setRulePassOrFail(String rulePassOrFail) {
		this.rulePassOrFail = rulePassOrFail;
	}*/
	public String getRuleByNumberPassOrFail() {
		return ruleByNumberPassOrFail;
	}
	public void setRuleByNumberPassOrFail(String ruleByNumberPassOrFail) {
		this.ruleByNumberPassOrFail = ruleByNumberPassOrFail;
	}
	
	

}
