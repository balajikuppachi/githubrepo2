package com.wf.regulatory.portrec.helpers.crypto;

/******************************************************************************
 * Filename    : Base64Decoder.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class Base64Decoder 
{
	private static final byte byteMap[] = { -1, -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
			62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1,
			-1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
			14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
			-1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41,
			42, 43, 44, 45, 46, 47, 48, 49, 50, 51 };

	public Base64Decoder() 
	{
	}

	public static byte[] decode(char ac[]) 
	{
		int i = ac.length;
		int j = (i / 4) * 3;
		int k = j;
		byte abyte0[] = new byte[j];
		int l = 0;
		
		for (int i1 = 0; l < i; i1 += 3) 
		{
			decodeBlock(ac, l, abyte0, i1);
			l += 4;
		}

		if (abyte0[j - 1] == 0) 
		{
			k--;
			
			if (abyte0[j - 2] == 0) 
			{
				k--;
			}
		}
		
		byte abyte1[] = new byte[k];
		System.arraycopy(abyte0, 0, abyte1, 0, k);
		
		return abyte1;
	}

	private static void decodeBlock(char ac[], int i, byte abyte0[], int j) 
	{
		if (ac[i + 2] != '=') 
		{
			if (ac[i + 3] != '=') 
			{
				abyte0[j] = (byte) (byteMap[ac[i]] << 2 | (byteMap[ac[i + 1]] & 0x30) >> 4);
				abyte0[j + 1] = (byte) ((byteMap[ac[i + 1]] & 0xf) << 4 | (byteMap[ac[i + 2]] & 0x3c) >> 2);
				abyte0[j + 2] = (byte) ((byteMap[ac[i + 2]] & 3) << 6 | byteMap[ac[i + 3]]);
			} 
			else 
			{
				abyte0[j] = (byte) (byteMap[ac[i]] << 2 | (byteMap[ac[i + 1]] & 0x30) >> 4);
				abyte0[j + 1] = (byte) ((byteMap[ac[i + 1]] & 0xf) << 4 | (byteMap[ac[i + 2]] & 0x3c) >> 2);
				abyte0[j + 2] = (byte) ((byteMap[ac[i + 2]] & 3) << 6);
			}
		} 
		else 
		{
			abyte0[j] = (byte) (byteMap[ac[i]] << 2 | (byteMap[ac[i + 1]] & 0x30) >> 4);
			abyte0[j + 1] = (byte) ((byteMap[ac[i + 1]] & 0xf) << 4);
			abyte0[j + 2] = 0;
		}
	}
}

