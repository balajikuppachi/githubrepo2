package com.wf.regulatory.portrec.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	private static final String DB_DRIVER = "com.sybase.jdbc4.jdbc.SybDriver";
	
	private static DBConnection dBConnection;
	
	private DBConnection(){
		
	}
	
	public static DBConnection getInstance() 
	{    
        if (dBConnection==null)  
	    {  
        	dBConnection = new DBConnection();  
	    }  
        return dBConnection;  
	}

	public Connection getConnection(String url, String userName, String dbPassword) throws SQLException, ClassNotFoundException {
		 
		Connection dbConnection = null;
		
			try 
			{
				Class.forName(DB_DRIVER);
				dbConnection = DriverManager.getConnection(url, userName, dbPassword);
				
			} catch (ClassNotFoundException e) {
				throw e;
			} catch (SQLException e) {
				throw e;
			}
 
		return dbConnection;
	}
	
}
