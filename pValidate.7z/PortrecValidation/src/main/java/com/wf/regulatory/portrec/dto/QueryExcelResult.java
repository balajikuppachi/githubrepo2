package com.wf.regulatory.portrec.dto;

public class QueryExcelResult {
	
	private int queryNo;
	private String query;
	private String ruleDesc;
	private int queryResultCount;
	private String ruleId;
	
	public int getQueryNo() {
		return queryNo;
	}
	public void setQueryNo(int queryNo) {
		this.queryNo = queryNo;
	}
	
	public String getRuleDesc() {
		return ruleDesc;
	}
	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}
	public int getQueryResultCount() {
		return queryResultCount;
	}
	public void setQueryResultCount(int queryResultCount) {
		this.queryResultCount = queryResultCount;
	}
	
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	
}
