package com.wf.regulatory.portrec.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.wf.regulatory.portrec.db.DBConnection;
import com.wf.regulatory.portrec.dto.QueryExcelResult;
import com.wf.regulatory.portrec.dto.Rules;
import com.wf.regulatory.portrec.helpers.crypto.SecureDBPwdFactory;

public class ReportGenerator {

	private static String dbUrl = null;
	private static String dbUserName = null;
	private static String dbPassword = null;

	static String[] input = { "CID", "LiveTrades", "PortfolioSizeLog", "CPTY_FREQ", "DA_REPORT" };
	
	private static final Logger logger = Logger.getLogger(ReportGenerator.class);
	
	@Value("${pathToQueryExcel}")
	String pathToQueryExcel;
	
	@Value("${pathToRuleExcel}")
	String pathToRuleExcel;
	
	@Value("${job_execution_id}")
	BigDecimal jobExecId;
	
	@Value("${as_of_date}")
	String asOfDate;
	
	@Value("${outputFolder}")
	String outputFolder;

	@Autowired
	SecureDBPwdFactory secureDBPwdFactory;
	
	private void initializeDbProperties(String dbUrlArg, String dbUserNameArg, String dbPasswordArg) {
		
		logger.info("Enter initializeDbProperties method:");

		dbUrl = dbUrlArg;
		dbUserName = dbUserNameArg;
		dbPassword = secureDBPwdFactory.getPassword(dbPasswordArg);
		
		logger.info("dbUrl : " + dbUrl);
		logger.info("dbUserName : " + dbUserName);
		
		logger.info("Exit initializeDbProperties method:");
	}
	
	public void readExecuteQueryToValidateExcel(String dbUrlArg, String dbUserNameArg, String dbPasswordArg) throws Exception {

		logger.info("Enter readExecuteQueryToValidateExcel method:");
		
		initializeDbProperties(dbUrlArg, dbUserNameArg, dbPasswordArg);

		Map<String, List<QueryExcelResult>> data = new TreeMap<String, List<QueryExcelResult>>();
		
		logger.info("pathToQueryExcel:" + pathToQueryExcel);
		
		try {
			FileInputStream infile = new FileInputStream(pathToQueryExcel);
			XSSFWorkbook workbook = new XSSFWorkbook(infile);
			int sheetcount = workbook.getNumberOfSheets();
			
			DataFormatter formatter = new DataFormatter();
			
			logger.info("Reading and executing queries");
			
			// Iterate over each sheet in QueryToValidate.xlsx
			for (int i = 0; i < sheetcount; i++) {

				int iterater = 1;
				int a = 0;
				List<QueryExcelResult> queryResultsPerSheet = new ArrayList<QueryExcelResult>();

				XSSFSheet sheet = workbook.getSheet(input[i]);
				
				Iterator<Row> rowIterator = sheet.iterator();
				
				// Iterate over each row in each sheet inside QueryToValidate.xlsx
				while (rowIterator.hasNext()) {
					
					QueryExcelResult queryExcelResult = new QueryExcelResult();
					
					Row row = rowIterator.next();
					if (row.getRowNum() == 0)
					{
						continue;
					}
					
					Iterator<Cell> cellIterator = row.cellIterator();

					// Iterate over each cell in each row in each sheet inside QueryToValidate.xlsx
					while (cellIterator.hasNext()) 
					{
						Cell cell = cellIterator.next();

						queryExcelResult.setQueryNo(iterater);

						if (cell.getColumnIndex() == 0) 
						{
							if (cell.getStringCellValue() == null)
							{
								continue;
							}
							else {
								
								// Column "Dynamic/Static"
								String isStaticOrDynamicQuery = row.getCell(2).getStringCellValue();
								
								// Column "QUERY"
								String query = cell.getStringCellValue();
								queryExcelResult.setQuery(query);

								Integer count = executeQuery(query, isStaticOrDynamicQuery);

								queryExcelResult.setQueryResultCount(count);
							}
						} 
						else if (cell.getColumnIndex() == 1) 
						{
							// Column "DESCRIPTION"
							queryExcelResult.setRuleDesc(cell.getStringCellValue());
						}
						else if (cell.getColumnIndex() == 3) 
						{
							// Column "Rule Id"
							//queryExcelResult.setRuleId(String.valueOf(cell.getNumericCellValue()));
							//cell.setCellType(1);
							//queryExcelResult.setRuleId(cell.getStringCellValue());
							queryExcelResult.setRuleId(formatter.formatCellValue(cell));
						}
					} // End of while loop

					// Adding each query results to List
					queryResultsPerSheet.add(a, queryExcelResult);
					a++;
					iterater++;
				}

				// Adding each sheet query result lists to Map. Here key is SheetName
				data.put(sheet.getSheetName(), queryResultsPerSheet);
			}

			logger.info("Query Execution finished. Number of Sheets(Size of Map) : " + data.size());
			
			writeQueryResults(data);

		} catch (Exception e) {
			logger.error("Error in readExecuteQueryToValidateExcel method ..." + e.getMessage());
			throw e;
		}
		
		logger.info("Exit readExecuteQueryToValidateExcel method:");
	}
	
	private Integer executeQuery(String selectSQL, String isStaticOrDynamicQuery) throws SQLException, ClassNotFoundException {

		Connection dbConnection = null;
		Statement statement = null;
		PreparedStatement pStatement = null;
		Integer count = new Integer(0);

		try {

			dbConnection = DBConnection.getInstance().getConnection(dbUrl, dbUserName, dbPassword);
			ResultSet rs = null;
			if (isStaticOrDynamicQuery.equals("S")) 
			{
				statement = dbConnection.createStatement();
				rs = statement.executeQuery(selectSQL);
			} 
			else if (isStaticOrDynamicQuery.equals("D")) 
			{
				pStatement = dbConnection.prepareStatement(selectSQL);
				
				if (selectSQL.contains("job_execution_id")) 
				{
					pStatement.setBigDecimal(1, jobExecId);
					rs = pStatement.executeQuery();
				} 
				else if (selectSQL.contains("as_of_date")) 
				{
					pStatement.setDate(1, java.sql.Date.valueOf(asOfDate));
					rs = pStatement.executeQuery();
				}
			}

			while (rs.next()) 
			{
				count = rs.getInt(1);
			}

		} catch (SQLException e) {
			throw e;
		} finally {

			if (statement != null) {
				statement.close();
			}

			if (dbConnection != null) {
				dbConnection.close();
			}
		}

		return count;
	}
	
	
	private void writeQueryResults(Map<String, List<QueryExcelResult>> map) throws IOException {
		
		logger.info("Enter writeQueryResults method:");
		
		File folder = new File(outputFolder);
		
		if (!folder.exists()) {
			folder.mkdir();
		}

		String outputFileName = outputFolder + "//PortRecValidation_" + asOfDate + ".xlsx";
		XSSFWorkbook wb = null;
		XSSFSheet sheet = null;
		FileOutputStream fileOut = new FileOutputStream(outputFileName);

		wb = new XSSFWorkbook();
		XSSFCellStyle style1 = wb.createCellStyle();
		XSSFFont font = wb.createFont();
		// XSSFColor color=new XSSFColor(Color.blue);
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		style1.setBorderBottom((short) 1);
		style1.setBorderLeft((short) 1);
		style1.setBorderRight((short) 1);
		style1.setBorderTop((short) 1);
		style1.setFillBackgroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		style1.setFillPattern(CellStyle.ALIGN_FILL);
		style1.setFont(font);
		XSSFCellStyle style2 = wb.createCellStyle();
		style2.setBorderBottom((short) 1);
		style2.setBorderLeft((short) 1);
		style2.setBorderRight((short) 1);
		style2.setBorderTop((short) 1);

		Set<String> keyset = map.keySet();

		for (String key : keyset) {
			sheet = wb.createSheet(key);
			int rownum = 0;
			List<QueryExcelResult> objArr = map.get(key);
			for (int r = 0; r <= objArr.size(); r++) {
				Row row = sheet.createRow(rownum++);

				if (row.getRowNum() == 0) {
					row.createCell(0).setCellValue("S-No");
					row.getCell(0).setCellStyle(style1);
					row.createCell(1).setCellValue("Rule ID");
					row.getCell(1).setCellStyle(style1);
					row.createCell(2).setCellValue("Description");
					row.getCell(2).setCellStyle(style1);
					row.createCell(3).setCellValue("Count");
					row.getCell(3).setCellStyle(style1);
					row.createCell(4).setCellValue("Query");
					row.getCell(4).setCellStyle(style1);
				} else {
					row.createCell(0).setCellValue(objArr.get(r - 1).getQueryNo());
					row.getCell(0).setCellStyle(style2);
					row.createCell(1).setCellValue(objArr.get(r - 1).getRuleId());
					row.getCell(1).setCellStyle(style2);
					row.createCell(2).setCellValue(objArr.get(r - 1).getRuleDesc());
					row.getCell(2).setCellStyle(style2);
					row.createCell(3).setCellValue(objArr.get(r - 1).getQueryResultCount());
					row.getCell(3).setCellStyle(style2);
					row.createCell(4).setCellValue(objArr.get(r - 1).getQuery());
					row.getCell(4).setCellStyle(style2);
				}
			}
		}
		
		wb.write(fileOut);
		
		logger.info("Output excel created !!!");
		
		readExecuteRuleToValidateExcel(outputFileName, map);

		logger.info("Exit writeQueryResults method:");
	}

	private void readExecuteRuleToValidateExcel(String fileName, Map<String, List<QueryExcelResult>> map) throws IOException {

		logger.info("Enter readExecuteRuleToValidateExcel method:");
		
		int i = 0;
		
		DataFormatter formatter = new DataFormatter();
		
		Map<Integer, Rules> ruleMap = new TreeMap<Integer, Rules>();
		
		FileInputStream rulefile = new FileInputStream(pathToRuleExcel);
		XSSFWorkbook rulesWorkbook = new XSSFWorkbook(rulefile);
		XSSFSheet rulesSheet = rulesWorkbook.getSheetAt(0);

		Iterator<Row> ruleSheetRowIterator = rulesSheet.iterator();
		
		// Iterate over each rule in RuleToValidate.xlsx
		while (ruleSheetRowIterator.hasNext()) 
		{
			Row row = ruleSheetRowIterator.next();
			if (row.getRowNum() == 0)
				continue;
			i++;
			
			int count = 0, countValues[] = { 0, 0, 0, 0, 0, 0, 0 };
			
			String tableName = null;
			String[] tables = null;
			
			String ruleByNumber = null;
			
			String result = null;
			Rules rules = new Rules();
			
			Iterator<Cell> cellIterator = row.cellIterator();
			
			// Iterate over each cell for each rule
			while (cellIterator.hasNext()) 
			{
				Cell cell = cellIterator.next();
				
				// Column "TableName"
				if (cell.getColumnIndex() == 0) 
				{
					tableName = cell.getStringCellValue();
					if (null != tableName && tableName.contains("&"))
						tables = tableName.split("&");
					rules.setTableName(tableName);
				}
				// Column "Rule"
				else if (cell.getColumnIndex() == 1) 
				{
					// Do nothing
				}
				// Column "Description"
				else if (cell.getColumnIndex() == 2) 
				{
					rules.setRuleDesc(cell.getStringCellValue());
				}
				// Column "Rule by Id"
				else if (cell.getColumnIndex() == 3) 
				{
					//cell.setCellType(1);
					//ruleByNumber = cell.getStringCellValue();
					ruleByNumber = formatter.formatCellValue(cell); 
					if (tables == null) 
					{
						List<QueryExcelResult> listOfQueryResultsPerSheet = map.get(tableName);
						for (int x = 0; x < listOfQueryResultsPerSheet.size(); x++) 
						{
							if (ruleByNumber.matches("(.*)"	+ (listOfQueryResultsPerSheet.get(x).getRuleId()) + (".*"))) 
							{
								countValues[count] = listOfQueryResultsPerSheet.get(x).getQueryResultCount();
								count++;
							}
						}
					}
					else {
						for (int a = 0; a < tables.length; a++) 
						{
							List<QueryExcelResult> listOfQueryResultsPerSheet = map.get(tables[a]);

							for (int x = 0; x < listOfQueryResultsPerSheet.size(); x++) 
							{
								if (ruleByNumber.matches("(.*)"	+ (listOfQueryResultsPerSheet.get(x).getRuleId())+ (".*"))) 
								{
									countValues[count] = listOfQueryResultsPerSheet.get(x).getQueryResultCount();
									count++;
								}

							}
						}
					}

					if (count == 1) 
					{
						result = ((countValues[0] == 0) ? "PASS" : "FAIL");
						rules.setRuleByNumberPassOrFail(result);
					} 
					else if (count == 2) 
					{
						if (ruleByNumber.contains("and")) 
						{
							int t = 0;
							Pattern p = Pattern.compile("and");
							Matcher m = p.matcher(ruleByNumber);
							while (m.find())
								t++;
							if (t == 1) 
							{
								if (ruleByNumber.contains("zero")) 
								{
									if (countValues[0] == 0	&& countValues[1] == 0) 
									{
										result = "PASS";
									} 
									else {
										result = "FAIL";
									}
								} 
								else if (ruleByNumber.contains("equal")) 
								{
									if (countValues[0] == countValues[1]) 
									{
										result = "PASS";
									} 
									else {
										result = "FAIL";
									}
								}
							}
						} 
						else if (ruleByNumber.contains("equal") && (countValues[0] == countValues[1])) 
						{
							result = "PASS";
						} 						
						else if (ruleByNumber.contains("greater than") && (countValues[0] >= countValues[1])) 
						{
							result = "PASS";
						} 
						else {
							result = "FAIL";
						}
						rules.setRuleByNumberPassOrFail(result);
					}
					else if (count == 3) 
					{
						if (ruleByNumber.contains("sum")) 
						{
							if (countValues[0] == countValues[1] + countValues[2]) 
							{
								result = "PASS";
							} else {
								result = "FAIL";
							}
						}
						rules.setRuleByNumberPassOrFail(result);
					} 
					else if (count == 4) 
					{
						if (ruleByNumber.contains("sum")) 
						{
							int t = 0;
							Pattern p = Pattern.compile("sum");
							Matcher m = p.matcher(ruleByNumber);
							while (m.find())
								t++;
							if (t == 0) {
								if (countValues[0] == countValues[1] && countValues[2] == countValues[3]) {
									result = "PASS";
								} else {
									result = "FAIL";
								}
							} else if (t == 1) {
								if (countValues[0] == (countValues[1] + countValues[2] + countValues[3])) {
									result = "PASS";
								} else {
									result = "FAIL";
								}
							} else if (t == 2) {
								if (countValues[0] + countValues[1] == countValues[2] + countValues[3]) {
									result = "PASS";
								} else {
									result = "FAIL";
								}
							}
						} else {
							if (countValues[0] == 0 && countValues[1] == 0 && countValues[2] == 0 && countValues[3] == 0) {
								result = "PASS";
							} else if (countValues[0] == countValues[1] && countValues[2] == countValues[3]) {
								result = "PASS";
							} else {
								result = "FAIL";
							}
						}
						rules.setRuleByNumberPassOrFail(result);						
					}  
					else if (count == 5) 
					{
						if (ruleByNumber.contains("sum")) 
						{
							int t = 0;
							Pattern p = Pattern.compile("sum");
							Matcher m = p.matcher(ruleByNumber);
							while (m.find())
								t++;
							if (t == 0) {
								if (countValues[0] == countValues[1] && countValues[2] == countValues[3]) {
									result = "PASS";
								} else {
									result = "FAIL";
								}
							} else if (t == 1) {
								if (countValues[0] == (countValues[1] + countValues[2] + countValues[3] + countValues[4])) {
									result = "PASS";
								} else {
									result = "FAIL";
								}
							} else {
									result = "FAIL";
							}
						} else {
								result = "FAIL";
						}
						rules.setRuleByNumberPassOrFail(result);
					}
					else if (count == 6) 
					{
						if (countValues[0] == countValues[1] && countValues[2] == countValues[3] && countValues[4] == countValues[5]) {
							result = "PASS";
						} else {
							result = "FAIL";
						}
						rules.setRuleByNumberPassOrFail(result);
					}
					else if (count == 7) 
					{
						if (countValues[0] == countValues[1] + countValues[2] + countValues[3] + countValues[4]	+ countValues[5] + countValues[6]) {
							result = "PASS";
						} else {
							result = "FAIL";
						}
						rules.setRuleByNumberPassOrFail(result);
					}
				}
			}
			ruleMap.put(i, rules);
		}
		
		writeRuleExecutionResults(ruleMap, fileName);
		
		logger.info("Exit readExecuteRuleToValidateExcel method:");
	}

	private void writeRuleExecutionResults(Map<Integer, Rules> ruleMap, String excelFilePath) throws IOException {
		
		logger.info("Enter writeRuleExecutionResults method:");
		
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		Sheet sheet = workbook.createSheet("Rules");

		XSSFCellStyle style1 = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		style1.setBorderBottom((short) 1);
		style1.setBorderLeft((short) 1);
		style1.setBorderRight((short) 1);
		style1.setBorderTop((short) 1);
		style1.setFillBackgroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		style1.setFillPattern(CellStyle.ALIGN_FILL);
		style1.setFont(font);
		XSSFCellStyle style2 = workbook.createCellStyle();
		style2.setBorderBottom((short) 1);
		style2.setBorderLeft((short) 1);
		style2.setBorderRight((short) 1);
		style2.setBorderTop((short) 1);
		XSSFCellStyle style3 = workbook.createCellStyle();
		XSSFFont font1 = workbook.createFont();
		style3.setBorderBottom((short) 1);
		style3.setBorderLeft((short) 1);
		style3.setBorderRight((short) 1);
		style3.setBorderTop((short) 1);
		font1.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		style3.setFont(font1);
		style3.setFillBackgroundColor(IndexedColors.YELLOW.getIndex());
		style3.setFillPattern(CellStyle.ALIGN_FILL);
		XSSFCellStyle style4 = workbook.createCellStyle();
		style4.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
		style4.setFillPattern(CellStyle.ALIGN_FILL);
		XSSFCellStyle style5 = workbook.createCellStyle();
		style5.setFillBackgroundColor(IndexedColors.RED.getIndex());
		style5.setFillPattern(CellStyle.ALIGN_FILL);
		workbook.setActiveSheet(5);
		//int rownum = 0;
		
		Row row0 = sheet.createRow(0);
		row0.createCell(0).setCellValue("VALUATION RULES FOR PORTREC");
		row0.getCell(0).setCellStyle(style3);

		Row row1 = sheet.createRow(1);
		row1.createCell(0).setCellValue("Tables");
		row1.getCell(0).setCellStyle(style1);
		row1.createCell(1).setCellValue("Rules");
		row1.getCell(1).setCellStyle(style1);
		row1.createCell(2).setCellValue("Result By Rule Num");
		row1.getCell(2).setCellStyle(style1);
		
		for (int r = 1; r <= ruleMap.size(); r++) {
			Row row = sheet.createRow(r+1);
			row.createCell(0).setCellValue(ruleMap.get(r).getTableName());
			row.getCell(0).setCellStyle(style2);
			row.createCell(1).setCellValue(ruleMap.get(r).getRuleDesc());
			row.getCell(1).setCellStyle(style2);
			if (ruleMap.get(r).getRuleByNumberPassOrFail().equals("PASS")) {
				row.createCell(2).setCellValue(ruleMap.get(r).getRuleByNumberPassOrFail());
				row.getCell(2).setCellStyle(style2);
				row.getCell(2).setCellStyle(style4);
			} else if (ruleMap.get(r).getRuleByNumberPassOrFail().equals("FAIL")) {
				row.createCell(2).setCellValue(ruleMap.get(r).getRuleByNumberPassOrFail());
				row.getCell(2).setCellStyle(style2);
				row.getCell(2).setCellStyle(style5);
			}
		}

		inputStream.close();

		FileOutputStream outputStream = new FileOutputStream(excelFilePath);
		workbook.write(outputStream);
		
		logger.info("Exit writeRuleExecutionResults method:");
	}

}
