package com.wf.regulatory.portrec.helpers.crypto;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

/******************************************************************************
 * Filename    : SecureDBPwdFactory.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class SecureDBPwdFactory 
{
    private static final Logger LOG = Logger.getLogger(SecureDBPwdFactory.class);
   
    @Value("${dataSource.password.security.enabled}")
    private boolean encryptionEnabled ;
    private String passPhrase = null;
    private String password = null;

    @Autowired
    private SecureDBPwdHelper secureDBPwdHelper;

    public void setEncryptionEnabled(final boolean encryptionEnabled) 
    {
        this.encryptionEnabled = encryptionEnabled;
    }

    public void setPassPhrase(final String passPhrase) 
    {
        this.passPhrase = passPhrase;
    }

    public void setPassword(final String password) 
    {
        this.password = password;
    }

    public void init() 
    {
        LOG.info("SecureDBPwdFactory is being initialised with encryptionEnabled: " + encryptionEnabled);
        
        if (encryptionEnabled) 
        {
            LOG.info("Instatiating instance of password encoder, passphrase was " + (passPhrase == null ? "not provided" : "provided"));
            secureDBPwdHelper = new SecureDBPwdHelper(passPhrase);
        }
    }

    public String getPassword() 
    {
    	String returnPassword = "";
    	if (encryptionEnabled) 
        {
            LOG.debug("Returning decrypted password...");
            returnPassword = secureDBPwdHelper.decrypt(password);
        }
    	else {
    		LOG.debug("Returning password without decryption...");
    		returnPassword = password;
    	}
        
        
        return returnPassword;
    }
    
    public String getPassword(String passwordToDecrypt) 
    {
        String returnPassword = "";
    	if (encryptionEnabled) 
        {
            LOG.debug("Returning decrypted password...");
            returnPassword = secureDBPwdHelper.decrypt(passwordToDecrypt); 
            
        }
    	else {
    		LOG.debug("Returning password without decryption...");
    		returnPassword = passwordToDecrypt;
    	}
        
        
        return returnPassword;
    }

}
