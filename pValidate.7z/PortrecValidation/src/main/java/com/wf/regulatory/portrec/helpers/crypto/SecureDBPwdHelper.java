package com.wf.regulatory.portrec.helpers.crypto;

import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/******************************************************************************
 * Filename    : SecureDBPwdHelper.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

@Component
public class SecureDBPwdHelper 
{
    private static final Logger LOG = Logger.getLogger(SecureDBPwdHelper.class);

    private static final Base64 BASE64 = new Base64();
    private static final byte[] SALT = { (byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03 };
    private static final int ITERATION_CNT = 19;

    private static final String DEFAULT_PASS_PHRASE = "Not a very creative pass phrase!";

    private Cipher ecipher;
    private Cipher dcipher;

    public SecureDBPwdHelper() 
    {
        this(null);
    }

    public SecureDBPwdHelper(final String passPhrase) 
    {
        String effectivePassPhrase = getEffectivePassPhrase(passPhrase);

        LOG.info("Initialising encode/decode objects for passPhrase: " + obfuscate(effectivePassPhrase));

        KeySpec keySpec = new PBEKeySpec(effectivePassPhrase.toCharArray(), SALT, ITERATION_CNT);
        AlgorithmParameterSpec paramSpec = new PBEParameterSpec(SALT, ITERATION_CNT);

        try 
        {
            SecretKey key = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(keySpec);
            
            LOG.debug("Key object was created, creating cipher instances...");
            
            ecipher = Cipher.getInstance(key.getAlgorithm());
            dcipher = Cipher.getInstance(key.getAlgorithm());
            
            LOG.debug("Initialising cipher instances...");
            
            ecipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
            dcipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
            
            LOG.info("Encode/decode objects were created successfully, used algorithm: " + key.getAlgorithm());
        } 
        catch (Exception e) 
        {
            String errorMsg = "Problem occured while trying to initialise encode/decode objects, reason: " + e.getMessage();
            LOG.error(errorMsg, e);
            throw new IllegalStateException(errorMsg, e);
        }
    }

    public String encrypt(final String str) 
    {
        try 
        {
            LOG.debug("Encryption request was received for: " + obfuscate(str));
            
            byte[] enc = ecipher.doFinal(str.getBytes("UTF8"));
            String encodedStr = new String(BASE64.encode(enc), "UTF8");
            
            LOG.info(String.format("Encryption has finished, %s was encrypted to: %s", obfuscate(str), encodedStr));
            
            return encodedStr;
        } 
        catch (Exception e) 
        {
            String errorMsg = String.format("Problem occured while trying to encode string: %s, reason: %s", obfuscate(str), e.getMessage());
            LOG.error(errorMsg, e);
            
            throw new IllegalStateException(errorMsg, e);
        }
    }

    public String decrypt(final String str) 
    {
        try 
        {
            LOG.debug("Decryption request was received for: " + str);
            
            byte[] dec = BASE64.decode(str.getBytes());
            String decryptedStr = new String(dcipher.doFinal(dec), "UTF8");
            
            LOG.info(String.format("Decryption has finished, %s was decrypted to: %s", str, obfuscate(decryptedStr)));
            
            return decryptedStr;
        } 
        catch (Exception e) 
        {
            String errorMsg = String.format("Problem occured while trying to decode string: %s, reason: %s", str, e.getMessage());
            LOG.error(errorMsg, e);
            
            throw new IllegalStateException(errorMsg, e);
        }
    } 

    private String obfuscate(final String string) 
    {
        if (string.length() > 2) 
        {
            char[] charArray = string.toCharArray();
            
            for (int i = 0; i < charArray.length; i++) 
            {
                if (i > 0 && i < charArray.length - 1) 
                {
                    charArray[i] = '*';
                }
            }
            
            return new String(charArray);
        }
        
        return "**";
    }

    private String getEffectivePassPhrase(final String passPhrase) 
    {
        String effectivePassPhrase = passPhrase;
        
        if (effectivePassPhrase == null) 
        {
            LOG.warn("Parameterless constructor was called, means no passPhrase was provided, default one will be used!");
            
            effectivePassPhrase = DEFAULT_PASS_PHRASE;
        }
        
        return effectivePassPhrase;
    }

}

