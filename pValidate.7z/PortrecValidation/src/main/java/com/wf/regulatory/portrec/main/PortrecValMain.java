package com.wf.regulatory.portrec.main;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PortrecValMain {

	
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:/spring/applicationContext.xml";
	private static final Logger logger = Logger.getLogger(PortrecValMain.class);
	
	public static void main(String[] args) throws IOException	
	{
		initApp();
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		applicationContext.start();
		applicationContext.registerShutdownHook();
		
	}
	
	private static void initApp() throws IOException
	{
		String userDirPath = System.getProperty("user.dir");
		String sdrHomePath = System.getProperty("HOME");
		File sdrHome;
		
		if (sdrHomePath == null) 
		{
			
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("HOME", sdrHomePath);
		} 	
		else 
		{
			sdrHome = new File(sdrHomePath);
		}
		
		logger.info("Home as --> "+sdrHomePath);
		
		return;
	}
}
