package com.wf.df.sdr.metadata;

import java.util.List;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="mappings")
public class FieldMappingContainer {
	private List<FieldMapping> mappings;

	@XmlElementRef
	public List<FieldMapping> getMappings() {
		return mappings;
	}

	public void setMappings(List<FieldMapping> mappings) {
		this.mappings = mappings;
	}
}