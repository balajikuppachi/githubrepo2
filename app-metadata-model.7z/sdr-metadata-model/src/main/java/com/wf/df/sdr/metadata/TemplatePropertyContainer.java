package com.wf.df.sdr.metadata;

import java.util.List;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="properties")
public class TemplatePropertyContainer {
	private List<TemplateProperty> properties;

	@XmlElementRef
	public List<TemplateProperty> getProperties() {
		return properties;
	}

	public void setProperties(List<TemplateProperty> properties) {
		this.properties = properties;
	}
}