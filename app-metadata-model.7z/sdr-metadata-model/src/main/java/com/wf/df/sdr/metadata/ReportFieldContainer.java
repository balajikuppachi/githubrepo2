package com.wf.df.sdr.metadata;

import java.util.List;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="fields")
public class ReportFieldContainer {
	private List<ReportField> fields;

	@XmlElementRef
	public List<ReportField> getFields() {
		return fields;
	}

	public void setFields(List<ReportField> fields) {
		this.fields = fields;
	}
}