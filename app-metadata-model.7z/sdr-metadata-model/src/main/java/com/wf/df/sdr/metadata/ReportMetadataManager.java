package com.wf.df.sdr.metadata;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.SchemaOutputResolver;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.ValidationEventLocator;
import javax.xml.bind.helpers.DefaultValidationEventHandler;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class ReportMetadataManager {
	
	public static final String SCHEMA_LOCATION = "report-metadata.xsd";
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	
	private JAXBContext reportMetadataJaxbContext;
	private Marshaller reportMetadataMarshaller;
	private Unmarshaller reportMetadataUnmarshaller;
	
	
	public ReportMetadataManager() {
		try {
			ValidationEventHandler validationEventHandler = new MetadataValidationEventHandler();
	
			SchemaFactory reportMetadataSchemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Source reportMetadataSchemaSource = new StreamSource(ReportMetadata.class.getResourceAsStream(SCHEMA_LOCATION));
			Schema reportMetadataSchema = reportMetadataSchemaFactory.newSchema(reportMetadataSchemaSource);
			
			reportMetadataJaxbContext = JAXBContext.newInstance(ReportMetadata.class.getPackage().getName());
			
			reportMetadataMarshaller = reportMetadataJaxbContext.createMarshaller();
			reportMetadataMarshaller.setEventHandler(validationEventHandler);
			reportMetadataMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			reportMetadataMarshaller.setSchema(reportMetadataSchema);
	
			reportMetadataUnmarshaller = reportMetadataJaxbContext.createUnmarshaller();
			reportMetadataUnmarshaller.setEventHandler(validationEventHandler);
			reportMetadataUnmarshaller.setSchema(reportMetadataSchema);
		} catch (JAXBException e) {
			throw new ReportMetadataException(e);
		} catch (SAXException e) {
			throw new ReportMetadataException(e);
		}
	}
	
	public ReportMetadata load(InputStream input) {
		try {
			Object unmarshalled = reportMetadataUnmarshaller.unmarshal(input);
			if (!(unmarshalled instanceof ReportMetadata)) {
				throw new ReportMetadataException("Couldn't load report metadata: root element must be 'report-metadata'");
			}
			return (ReportMetadata)unmarshalled;
		} catch (JAXBException e) {
			throw new ReportMetadataException("Couldn't load report metadata resource", e);
		}
	}
	
	public ReportMetadata load(File file) {
		InputStream input = null;
		try {
			input = new FileInputStream(file);
			return load(input);
		} catch (FileNotFoundException e) {
			throw new ReportMetadataException("Couldn't load report metadata from file: " + file, e);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}
	}
	
	public void store(ReportMetadata reportMetadata, OutputStream output) {
		try {
			reportMetadataMarshaller.marshal(reportMetadata, output);
			output.flush();
		} catch (JAXBException e) {
			throw new ReportMetadataException("Couldn't store report metadata", e);
		} catch (IOException e) {
			throw new ReportMetadataException("Couldn't store report metadata", e);
		}
	}
	
	public void store(ReportMetadata reportMetadata, File file) {
		OutputStream output = null;
		try {
			output = new FileOutputStream(file);
			store(reportMetadata, output);
		} catch (FileNotFoundException e) {
			throw new ReportMetadataException("Couldn't store report metadata to file: " + file, e);
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					//ignore
				}
			}
		}
	}
	
	public void storeSchema(OutputStream output) throws IOException {
		final Writer writer = new OutputStreamWriter(output);
		SchemaOutputResolver outResolver = new SchemaOutputResolver() {
			@Override
			public Result createOutput(String namespaceUri, String suggestedFileName ) throws IOException {
				Result result = new StreamResult(writer); 
				result.setSystemId("some system id");
				return result;
			}
		};
		reportMetadataJaxbContext.generateSchema(outResolver);
	}
	
	private class MetadataValidationEventHandler implements ValidationEventHandler {

		@Override
		public boolean handleEvent(ValidationEvent event) {
	        if( event == null ) {
	            throw new IllegalArgumentException();
	        }

	        String location = getLocation( event );
	        
	        switch ( event.getSeverity() ) {
	            case ValidationEvent.WARNING:
	            	logger.warn(event.getMessage() + ", Location: " + location);
	                return true; // continue after warnings
	            case ValidationEvent.ERROR:
	            case ValidationEvent.FATAL_ERROR:
	            default:
	            	logger.error(event.getMessage() + ", Location: " + location);
	                return false; // terminate after errors
	        }
		}
		
		/**
		 * @see DefaultValidationEventHandler
		 */
	    private String getLocation(ValidationEvent event) {
	        StringBuffer msg = new StringBuffer();
	        
	        ValidationEventLocator locator = event.getLocator();
	        
	        if( locator != null ) {
	            
	            URL url = locator.getURL();
	            Object obj = locator.getObject();
	            Node node = locator.getNode();
	            int line = locator.getLineNumber();
	            
	            if( url!=null || line!=-1 ) {
	                msg.append( "line " + line );
	                if( url!=null )
	                    msg.append( " of " + url );
	            } else if( obj != null ) {
	                msg.append( " obj: " + obj.toString() );
	            } else if( node != null ) {
	                msg.append( " node: " + node.toString() );
	            }
	        } else {
	            msg.append("Location unavailable");
	        } 
	        
	        return msg.toString();
	    }
	}
	
}
