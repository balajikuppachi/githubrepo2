package com.wf.df.sdr.metadata;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="mapping")
@XmlType(propOrder={"fieldId", "value", "optionality"})
public class FieldMapping {
	private String fieldId;
	private String value;
	private String optionality;
	
	@XmlAttribute(name="field", required=true)
	public String getFieldId() {
		return fieldId;
	}
	
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}
	
	@XmlAttribute(name="value")
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	@XmlAttribute(name="optionality")
	public String getOptionality() {
		return optionality;
	}
	
	public void setOptionality(String optionality) {
		this.optionality = optionality;
	}
	
	public void merge(FieldMapping otherMapping) {
		if (otherMapping.getValue() != null) {
			value = otherMapping.getValue();
		}
		if (otherMapping.getOptionality() != null) {
			optionality = otherMapping.getOptionality();
		}
	}
	
	@Override
	public FieldMapping clone() {
		FieldMapping newMapping = new FieldMapping();
		newMapping.setFieldId(fieldId);
		newMapping.merge(this);
		
		return newMapping;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fieldId == null) ? 0 : fieldId.hashCode());
		result = prime * result
				+ ((optionality == null) ? 0 : optionality.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FieldMapping other = (FieldMapping) obj;
		if (fieldId == null) {
			if (other.fieldId != null)
				return false;
		} else if (!fieldId.equals(other.fieldId))
			return false;
		if (optionality == null) {
			if (other.optionality != null)
				return false;
		} else if (!optionality.equals(other.optionality))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FieldMapping [fieldId=" + fieldId + ", value=" + value
				+ ", optionality=" + optionality + "]";
	}
	
	
}
