package com.wf.df.sdr.metadata;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.UnmarshalException;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name="template")
@XmlType(propOrder={"templateId", "properties", "fields", "mappings"})
public class ReportTemplate {
	private String templateId;
	private Map<String, TemplateProperty> properties;
	private Map<String, ReportField> fields;
	private Map<String, FieldMapping> mappings;
	
	@XmlAttribute(name="id", required=true)
	public String getTemplateId() {
		return templateId;
	}
	
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	@XmlElementRef(required=false)
	@XmlJavaTypeAdapter(TemplatePropertyContainerXmlAdapter.class)
	public Map<String, TemplateProperty> getProperties() {
		return properties;
	}
	
	public void setProperties(Map<String, TemplateProperty> properties) {
		this.properties = properties;
	}
	
	@XmlElementRef(required=false)
	@XmlJavaTypeAdapter(ReportFieldContainerXmlAdapter.class)
	public Map<String, ReportField> getFields() {
		return fields;
	}
	
	public void setFields(Map<String, ReportField> fields) {
		this.fields = fields;
	}
	
	@XmlElementRef(required=false)
	@XmlJavaTypeAdapter(FieldMappingContainerXmlAdapter.class)
	public Map<String, FieldMapping> getMappings() {
		return mappings;
	}

	public void setMappings(Map<String, FieldMapping> mappings) {
		this.mappings = mappings;
	}
	
	
	public void merge(ReportTemplate otherTemplate) {
		if (otherTemplate.getProperties() != null) {
			if (properties == null) {
				properties = new LinkedHashMap<String, TemplateProperty>();
			}
			for (Entry<String, TemplateProperty> propertyEntry : otherTemplate.getProperties().entrySet()) {
				TemplateProperty property = propertyEntry.getValue();
				TemplateProperty existingProperty = properties.get(property.getId());
				if (existingProperty != null) {
					existingProperty.merge(property);
				} else {
					TemplateProperty newProperty = property.clone();
					properties.put(property.getId(), newProperty);
				}
				properties.put(property.getId(), property);
			}
		}
		
		if (otherTemplate.getFields() != null) {
			if (fields == null) {
				fields = new LinkedHashMap<String, ReportField>();
			}
			for (Entry<String, ReportField> fieldEntry : otherTemplate.getFields().entrySet()) {
				ReportField field = fieldEntry.getValue();
				ReportField existingField = fields.get(field.getId());
				if (existingField != null) {
					existingField.merge(field);
				} else {
					ReportField newField = field.clone();
					fields.put(field.getId(), newField);
				}
				fields.put(field.getId(), field);
			}
		}
		
		if (otherTemplate.getMappings() != null) {
			if (mappings == null) {
				mappings = new LinkedHashMap<String, FieldMapping>();
			}
			for (Entry<String, FieldMapping> mappingEntry : otherTemplate.getMappings().entrySet()) {
				FieldMapping mapping = mappingEntry.getValue();
				FieldMapping existingMapping = mappings.get(mapping.getFieldId());
				if (existingMapping != null) {
					existingMapping.merge(mapping);
				} else {
					FieldMapping newMapping = mapping.clone();
					mappings.put(mapping.getFieldId(), newMapping);
				}
			}
		}
	}
	
	@Override
	public ReportTemplate clone() {
		ReportTemplate template = new ReportTemplate();
		template.setTemplateId(templateId);
		
		if (properties != null) {
			Map<String, TemplateProperty> newProperties = new LinkedHashMap<String, TemplateProperty>();
			for (TemplateProperty property : properties.values()) {
				TemplateProperty newProperty = property.clone();
				newProperties.put(newProperty.getId(), newProperty);
			}
			template.setProperties(newProperties);
		}
		
		if (fields != null) {
			Map<String, ReportField> newFields = new LinkedHashMap<String, ReportField>();
			for (ReportField field : fields.values()) {
				ReportField newReportField = field.clone();
				newFields.put(newReportField.getId(), newReportField);
			}
			template.setFields(newFields);
		}
		
		if (mappings != null) {
			Map<String, FieldMapping> newMappings = new LinkedHashMap<String, FieldMapping>();
			for (FieldMapping mapping : mappings.values()) {
				FieldMapping newMapping = mapping.clone();
				newMappings.put(newMapping.getFieldId(), newMapping);
			}
			template.setMappings(newMappings);
		}
		
		return template;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fields == null) ? 0 : fields.hashCode());
		result = prime * result
				+ ((mappings == null) ? 0 : mappings.hashCode());
		result = prime * result
				+ ((properties == null) ? 0 : properties.hashCode());
		result = prime * result
				+ ((templateId == null) ? 0 : templateId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReportTemplate other = (ReportTemplate) obj;
		if (fields == null) {
			if (other.fields != null)
				return false;
		} else if (!fields.equals(other.fields))
			return false;
		if (mappings == null) {
			if (other.mappings != null)
				return false;
		} else if (!mappings.equals(other.mappings))
			return false;
		if (properties == null) {
			if (other.properties != null)
				return false;
		} else if (!properties.equals(other.properties))
			return false;
		if (templateId == null) {
			if (other.templateId != null)
				return false;
		} else if (!templateId.equals(other.templateId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ReportTemplate [templateId=" + templateId + ", properties="
				+ properties + ", fields=" + fields + ", mappings=" + mappings
				+ "]";
	}


	public static class TemplatePropertyContainerXmlAdapter extends XmlAdapter<TemplatePropertyContainer, Map<String, TemplateProperty>> {

		@Override
		public Map<String, TemplateProperty> unmarshal(TemplatePropertyContainer templatePropertyContainer)
				throws Exception {
			
			if (templatePropertyContainer == null || templatePropertyContainer.getProperties() == null) {
				return null;
			}

			Map<String, TemplateProperty> map = new LinkedHashMap<String, TemplateProperty>();
			for (TemplateProperty property : templatePropertyContainer.getProperties()) {
				if (map.containsKey(property.getId())) {
					throw new UnmarshalException("Property ID already exists: " + property.getId());
				}
				map.put(property.getId(), property);
			}
			
			return map;
		}

		@Override
		public TemplatePropertyContainer marshal(Map<String, TemplateProperty> templateProperties)
				throws Exception {
			
			if (templateProperties == null) {
				return null;
			}
			
			List<TemplateProperty> list = new LinkedList<TemplateProperty>();
			list.addAll(templateProperties.values());
			
			TemplatePropertyContainer templatePropertyContainer = new TemplatePropertyContainer();
			templatePropertyContainer.setProperties(list);
			return templatePropertyContainer;
		}
	}
	
	public static class ReportFieldContainerXmlAdapter extends XmlAdapter<ReportFieldContainer, Map<String, ReportField>> {

		@Override
		public Map<String, ReportField> unmarshal(ReportFieldContainer reportFieldContainer)
				throws Exception {
			
			if (reportFieldContainer == null || reportFieldContainer.getFields() == null) {
				return null;
			}

			Map<String, ReportField> map = new LinkedHashMap<String, ReportField>();
			for (ReportField field : reportFieldContainer.getFields()) {
				if (map.containsKey(field.getId())) {
					throw new UnmarshalException("Field ID already exists: " + field.getId());
				}
				map.put(field.getId(), field);
			}
			
			return map;
		}

		@Override
		public ReportFieldContainer marshal(Map<String, ReportField> reportFields)
				throws Exception {
			
			if (reportFields == null) {
				return null;
			}
			
			List<ReportField> list = new LinkedList<ReportField>();
			list.addAll(reportFields.values());
			
			ReportFieldContainer reportFieldContainer = new ReportFieldContainer();
			reportFieldContainer.setFields(list);
			return reportFieldContainer;
		}
	}
	
	public static class FieldMappingContainerXmlAdapter extends XmlAdapter<FieldMappingContainer, Map<String, FieldMapping>> {

		@Override
		public Map<String, FieldMapping> unmarshal(FieldMappingContainer fieldMappingContainer)
				throws Exception {
			
			if (fieldMappingContainer == null || fieldMappingContainer.getMappings() == null) {
				return null;
			}

			Map<String, FieldMapping> map = new LinkedHashMap<String, FieldMapping>();
			for (FieldMapping mapping : fieldMappingContainer.getMappings()) {
				if (map.containsKey(mapping.getFieldId())) {
					throw new UnmarshalException("Field mapping for field with ID already exists: " + mapping.getFieldId());
				}
				map.put(mapping.getFieldId(), mapping);
			}
			
			return map;
		}

		@Override
		public FieldMappingContainer marshal(Map<String, FieldMapping> fieldMappings)
				throws Exception {
			
			if (fieldMappings == null) {
				return null;
			}
			
			List<FieldMapping> list = new LinkedList<FieldMapping>();
			list.addAll(fieldMappings.values());
			
			FieldMappingContainer fieldMappingContainer = new FieldMappingContainer();
			fieldMappingContainer.setMappings(list);
			return fieldMappingContainer;
		}
	}
}
