package com.wf.df.sdr.metadata;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="field")
@XmlType(propOrder={"sequenceNumber", "id", "header", "format", "description"})
public class ReportField {
	private String id;
	private int sequenceNumber;
	private String header;
	private String format;
	private String description;
	
	@XmlAttribute(name="id", required=true)
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	@XmlAttribute(name="seq", required=true)
	public int getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	@XmlAttribute(name="header", required=true)
	public String getHeader() {
		return header;
	}
	
	public void setHeader(String header) {
		this.header = header;
	}
	
	@XmlAttribute(name="format")
	public String getFormat() {
		return format;
	}
	
	public void setFormat(String format) {
		this.format = format;
	}
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}

	public void merge(ReportField otherField) {
		sequenceNumber = otherField.getSequenceNumber();
		header = otherField.getHeader();
		description = otherField.getDescription();
		format = otherField.getFormat();
	}
	
	@Override
	public ReportField clone() {
		ReportField newField = new ReportField();
		newField.setId(id);
		newField.merge(this);
		
		return newField;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((format == null) ? 0 : format.hashCode());
		result = prime * result + ((header == null) ? 0 : header.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + sequenceNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReportField other = (ReportField) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (format == null) {
			if (other.format != null)
				return false;
		} else if (!format.equals(other.format))
			return false;
		if (header == null) {
			if (other.header != null)
				return false;
		} else if (!header.equals(other.header))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (sequenceNumber != other.sequenceNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ReportField [id=" + id + ", sequenceNumber=" + sequenceNumber
				+ ", header=" + header + ", format=" + format
				+ ", description=" + description + "]";
	}

}
