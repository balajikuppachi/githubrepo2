// See jaxb.index in the resources for a list of classes
@javax.xml.bind.annotation.XmlSchema(
		xmlns = {@javax.xml.bind.annotation.XmlNs(prefix = "", namespaceURI = "http://www.headstrong.com/wf/sdr/report-metadata")},
        namespace="http://www.headstrong.com/wf/sdr/report-metadata",
        attributeFormDefault=javax.xml.bind.annotation.XmlNsForm.UNQUALIFIED,
        elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED)  
package com.wf.df.sdr.metadata;