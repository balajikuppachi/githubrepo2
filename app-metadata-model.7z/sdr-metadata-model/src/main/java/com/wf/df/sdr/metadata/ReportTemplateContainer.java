package com.wf.df.sdr.metadata;

import java.util.List;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="templates")
public class ReportTemplateContainer {
	private List<ReportTemplate> templates;

	@XmlElementRef
	public List<ReportTemplate> getTemplates() {
		return templates;
	}

	public void setTemplates(List<ReportTemplate> templates) {
		this.templates = templates;
	}
}