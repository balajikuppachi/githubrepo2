package com.wf.df.sdr.metadata;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.UnmarshalException;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name="report-metadata")
public class ReportMetadata {
	private Map<String, ReportTemplate> templates;

	@XmlElementRef
	@XmlJavaTypeAdapter(ReportTemplateContainerXmlAdapter.class)
	public Map<String, ReportTemplate> getTemplates() {
		return templates;
	}

	public void setTemplates(Map<String, ReportTemplate> templates) {
		this.templates = templates;
	}
	
	public void merge(ReportMetadata otherMetadata) {
		if (otherMetadata.getTemplates() == null) {
			return;
		}
		
		if (templates == null) {
			templates = new LinkedHashMap<String, ReportTemplate>();
		}
		
		for (Map.Entry<String, ReportTemplate> templateEntry : otherMetadata.getTemplates().entrySet()) {
			ReportTemplate template = templateEntry.getValue();
			ReportTemplate existingTemplate = templates.get(template.getTemplateId());
			if (existingTemplate != null) {
				existingTemplate.merge(template);
			} else {
				ReportTemplate newTemplate = template.clone();
				templates.put(newTemplate.getTemplateId(), newTemplate);
			}
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((templates == null) ? 0 : templates.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReportMetadata other = (ReportMetadata) obj;
		if (templates == null) {
			if (other.templates != null)
				return false;
		} else if (!templates.equals(other.templates))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ReportMetadata [templates=" + templates + "]";
	}

	
	public static class ReportTemplateContainerXmlAdapter extends XmlAdapter<ReportTemplateContainer, Map<String, ReportTemplate>> {

		@Override
		public Map<String, ReportTemplate> unmarshal(ReportTemplateContainer templates)
				throws Exception {
			
			if (templates == null || templates.getTemplates() == null) {
				return null;
			}
			
			Map<String, ReportTemplate> map = new LinkedHashMap<String, ReportTemplate>();
			for (ReportTemplate template : templates.getTemplates()) {
				if (map.containsKey(template.getTemplateId())) {
					throw new UnmarshalException("Template already exists: " + template.getTemplateId());
				}
				map.put(template.getTemplateId(), template);
			}
			return map;
		}

		@Override
		public ReportTemplateContainer marshal(Map<String, ReportTemplate> templatesMap)
				throws Exception {
			
			if (templatesMap == null) {
				return null;
			}
			
			List<ReportTemplate> list = new LinkedList<ReportTemplate>();
			list.addAll(templatesMap.values());
			
			ReportTemplateContainer templatesForXml = new ReportTemplateContainer();
			templatesForXml.setTemplates(list);
			return templatesForXml;
		}
	}
	
}
