package com.wf.df.sdr.metadata;

public class ReportMetadataException extends RuntimeException {
	
	private static final long serialVersionUID = -5649234793632260550L;

	public ReportMetadataException() {
		super();
	}
	
	public ReportMetadataException(String message) {
		super(message);
	}
	
	public ReportMetadataException(Throwable cause) {
		super(cause);
	}
	
	public ReportMetadataException(String message, Throwable cause) {
		super(message, cause);
	}
}
