package com.wf.df.sdr.metadata;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ReportMetadataTest {
	
	private static Logger logger = LoggerFactory.getLogger(ReportMetadataTest.class);
	
	private static ReportMetadataManager reportMetadataManager;
	
	@BeforeClass
	public static void init() throws IOException {
		reportMetadataManager = new ReportMetadataManager();
		if (logger.isDebugEnabled()) {
			//TODO: AZ - Find a better way to generate schema
			logger.debug("Report metadata schema generated from class files is: \n");
			reportMetadataManager.storeSchema(System.out);
		}
	}
	
	@Test
	public void testXmlUnmarshall() throws URISyntaxException {
		
		File inputFile = new File(getClass().getResource("test-report-metadata.xml").toURI());
		ReportMetadata reportMetadata = reportMetadataManager.load(inputFile);
		
		Assert.assertEquals(2, reportMetadata.getTemplates().size());
		Assert.assertEquals("template-1", reportMetadata.getTemplates().get("template-1").getTemplateId());
		Assert.assertEquals("template-2", reportMetadata.getTemplates().get("template-2").getTemplateId());
		
		ReportField field = reportMetadata.getTemplates().get("template-1").getFields().get("field-1-2");
		Assert.assertEquals("field-1-2", field.getId());
		Assert.assertEquals("header-1-2", field.getHeader());
		Assert.assertEquals("format-1-2", field.getFormat());
		Assert.assertEquals("description-1-2", field.getDescription());
		
		FieldMapping mapping = reportMetadata.getTemplates().get("template-2").getMappings().get("field-2-1");
		Assert.assertEquals("field-2-1", mapping.getFieldId());
		Assert.assertEquals("calculation-2-1", mapping.getValue());
		Assert.assertEquals("optionality-2-1", mapping.getOptionality());
	}
	
	@Test
	public void testXmlMarshall() throws IOException {
		ReportTemplate template1 = new ReportTemplate();
		template1.setTemplateId("template-1");
		ReportField field11 = new ReportField();
		field11.setSequenceNumber(1);
		field11.setId("field-1-1");
		field11.setHeader("header-1-1");
		field11.setFormat("format-1-1");
		field11.setDescription("description-1-1");
		ReportField field12 = new ReportField();
		field12.setSequenceNumber(2);
		field12.setId("field-1-2");
		field12.setHeader("header-1-2");
		field12.setFormat("format-1-2");
		field12.setDescription("description-1-2");
		
		Map<String, ReportField> fields1 = new LinkedHashMap<String, ReportField>();
		fields1.put(field11.getId(), field11);
		fields1.put(field12.getId(), field12);
		template1.setFields(fields1);
		
		FieldMapping mapping11 = new FieldMapping();
		mapping11.setFieldId("field-1-1");
		mapping11.setValue("calculation-1-1");
		mapping11.setOptionality("optionality-1-1");
		FieldMapping mapping12 = new FieldMapping();
		mapping12.setFieldId("field-1-2");
		mapping12.setValue("calculation-1-2");
		mapping12.setOptionality("optionality-1-2");
		
		SortedMap<String, FieldMapping> mappings1 = new TreeMap<String, FieldMapping>();
		mappings1.put(mapping11.getFieldId(), mapping11);
		mappings1.put(mapping12.getFieldId(), mapping12);
		template1.setMappings(mappings1);

		
		
		ReportTemplate template2 = new ReportTemplate();
		template2.setTemplateId("template-2");
		ReportField field21 = new ReportField();
		field21.setSequenceNumber(1);
		field21.setId("field-2-1");
		field21.setHeader("header-2-1");
		field21.setFormat("format-2-1");
		field21.setDescription("description-2-1");
		ReportField field22 = new ReportField();
		field22.setSequenceNumber(2);
		field22.setId("field-2-2");
		field22.setHeader("header-2-2");
		field22.setFormat("format-2-2");
		field22.setDescription("description-2-2");

		SortedMap<String, ReportField> fields2 = new TreeMap<String, ReportField>();
		fields2.put(field21.getId(), field21);
		fields2.put(field22.getId(), field22);
		template2.setFields(fields2);
		
		FieldMapping mapping21 = new FieldMapping();
		mapping21.setFieldId("field-2-1");
		mapping21.setValue("calculation-2-1");
		mapping21.setOptionality("optionality-2-1");
		FieldMapping mapping22 = new FieldMapping();
		mapping22.setFieldId("field-2-2");
		mapping22.setValue("calculation-2-2");
		mapping22.setOptionality("optionality-2-2");
		
		SortedMap<String, FieldMapping> mappings2 = new TreeMap<String, FieldMapping>();
		mappings2.put(mapping21.getFieldId(), mapping21);
		mappings2.put(mapping22.getFieldId(), mapping22);
		template2.setMappings(mappings2);

		
		ReportMetadata metadata = new ReportMetadata();
		metadata.setTemplates(new LinkedHashMap<String, ReportTemplate>());
		metadata.getTemplates().put(template1.getTemplateId(), template1);
		metadata.getTemplates().put(template2.getTemplateId(), template2);

		File tempFile = File.createTempFile("sdr-mappings-marshalling-test", ".xml");
		tempFile.deleteOnExit();
		
		reportMetadataManager.store(metadata, tempFile);
		ReportMetadata unmarshalledMetadata = reportMetadataManager.load(tempFile);
		
		Assert.assertEquals(metadata, unmarshalledMetadata);
	}
}


