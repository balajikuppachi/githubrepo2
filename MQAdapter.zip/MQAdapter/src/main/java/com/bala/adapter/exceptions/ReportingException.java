package com.bala.adapter.exceptions;

import com.bala.adapter.enums.ExceptionSeverityEnum;
import com.bala.adapter.enums.ExceptionTypeEnum;


public abstract class ReportingException extends Exception
{

	private static final long serialVersionUID = 8734242930442261737L;

	public static final String EXCEPTION_DEFAULT_STATUS = "OPEN";

	protected String exceptionCode;
	protected ExceptionSeverityEnum exceptionSeverity;
	protected ExceptionTypeEnum exceptionType;
	protected String sdrMessageId;
	protected String swapTradeId;

	public ReportingException(String message)
	{
		super(message);
	}

	public ReportingException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public String getExceptionCode()
	{
		return exceptionCode;
	}

	public ExceptionSeverityEnum getExceptionSeverity()
	{
		return exceptionSeverity;
	}

	public ExceptionTypeEnum getExceptionType()
	{
		return exceptionType;
	}

	public String getSdrMessageId()
	{
		return sdrMessageId;
	}	
	
	public String getSwapTradeId()
	{
		return swapTradeId;
	}

	public void setSwapTradeId(String swapTradeId)
	{
		this.swapTradeId = swapTradeId;
	}


}
