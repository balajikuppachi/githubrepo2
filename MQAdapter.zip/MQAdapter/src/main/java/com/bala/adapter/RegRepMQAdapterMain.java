package com.bala.adapter;

import java.io.IOException;
import javax.jms.JMSException;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.bala.adapter.exceptions.MessagingException;

public class RegRepMQAdapterMain {

	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:/spring/regrepMqAdapterContext.xml";
	private static final Logger logger = Logger.getLogger(RegRepMQAdapterMain.class);
	
	
	public static void main(String[] args) throws IOException, MessagingException, JMSException	
	{
		logger.info("RegRepMQAdapterMain application starting...");
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		applicationContext.start();
		applicationContext.registerShutdownHook();
		logger.info("RegRepMQAdapterMain application started successfully");
	}
}
