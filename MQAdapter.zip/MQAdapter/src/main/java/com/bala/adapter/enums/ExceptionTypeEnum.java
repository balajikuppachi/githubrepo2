package com.bala.adapter.enums;

/**
 * @author Amit Rana
 * @date 08/23/2014
 * @version 1.0
 */

public enum ExceptionTypeEnum
{

	REG_REP_ERROR("REG_REP_ERROR"), SDR_ERROR("SDR_ERROR"), SDR_WARNING("SDR_WARNING"), INPUT_DATA_ERROR("INPUT_DATA_ERROR"), ETD_ERROR("ETD_ERROR"),RECON_ERROR("RECON_ERROR"),
	       DS_ERROR("DS_ERROR"), PORTREC_ERROR("PORTREC_ERROR"), CID_ERROR("CID_ERROR"), COLLATERAL_RES_ERROR("COLLATERAL_RES_ERROR"), EOD_ERROR("EOD_ERROR");

	private final String value;

	public String type()
	{
		return toString();
	}

	ExceptionTypeEnum(String v)
	{
		value = v;
	}

	public static ExceptionTypeEnum fromValue(String v)
	{

		for (ExceptionTypeEnum c : ExceptionTypeEnum.values())
		{
			if (c.value.equalsIgnoreCase(v))
			{
				return c;
			}
		}

		return null;
	}

}
