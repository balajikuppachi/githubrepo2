package com.wellsfargo.regulatory.simulator.response.dtcc;

import java.io.IOException;
import java.io.StringReader;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;

public class Generator {

	private String brokerUrl;
	private String responseQueue;
	private String simulateResponse;

	@Value("${regRep.simulate.response.delay}")
	private int publishDelay;

	public void generateResponse(Message<?> message){

		String response 	= null;
		String reportType	= null;
		String reportId		= null;
		Random random		= null;
		int    ACK			= 0;
		int	   NACK			= 1;
		int    responseType	= -1;
		AmqPublisher publisher	= null;
		ReportingContext	context = null;
		String	report = null;
		String  dtccId = null;

		if(!ConversionUtils.stringToBoolean(simulateResponse))
			return;

		if(null == message)
			return;

		context = (ReportingContext)message.getPayload();

		if(null != context){

			report = context.getPayload();

		}else{

			return;
		}

		if(report.contains("NonpublicExecutionReport")
				|| report.contains("nonpublicExecutionReport")){

			reportType = "PET";
		}else if(report.contains("publicExecutionReport")
				|| report.contains("PublicExecutionReport")){

			reportType = "RT";
		}

		reportId = getReportId(report, reportType);

		random			= new Random();
		responseType 	= random.nextInt(1 - 0 + 1) + 0;

		report = report.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","");
		report = report.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");

		if(report.contains("GTRCREATE")) {
			dtccId = ((new Date()).getTime()+"").substring(0,5);
			report = report.replaceFirst("GTRCREATE", dtccId);
			report = report.replace("GTRCREATE", "DTCC"+((new Date()).getTime()+"").substring(5,8));
		}

		if(ACK == responseType){

			if(reportType.equals("RT")){

				response = generateRtAck(reportId, report);
			}else if(reportType.equals("PET")){

				response = generatePetAck(reportId, report);
			}
		}else if(NACK == responseType){

			if(reportType.equals("RT")){

				response = generateRtNack(reportId, report);
			}else if(reportType.equals("PET")){

				response = generatePetNack(reportId, report);
			}
		}
		try {
			Thread.sleep(publishDelay);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		publisher = new AmqPublisher();
		publisher.publishMessage(response, brokerUrl, responseQueue);

		return;
	}

	private String getReportId(String report, String reportType) {

		Document document = null;
		DocumentBuilderFactory builderFactory = null;
		DocumentBuilder builder = null;
		XPath xPath = null;
		String reportId = null;
		String expression = null;

		try {
			builderFactory =
					DocumentBuilderFactory.newInstance();
			builder = builderFactory.newDocumentBuilder();
			document = builder.parse((new InputSource(new StringReader(report))));
			xPath =  XPathFactory.newInstance().newXPath();

			if("RT".equals(reportType)){

				expression = "/publicExecutionReport/header/messageId";
				reportId = xPath.compile(expression).evaluate(document);
			}else if("PET".equals(reportType)){

				expression = "/nonpublicExecutionReport/header/messageId";
				reportId = xPath.compile(expression).evaluate(document);
			}


			} catch (ParserConfigurationException |
					SAXException | IOException | XPathExpressionException e) {

				e.printStackTrace();
			}

		return reportId;
	}

	private String generateRtNack(String reportId, String origMessage){

		String nack = "<?xml version=\"1.0\" encoding=\"utf-8\"?> "+
				"<publicExecutionReportException xmlns=\"http://www.fpml.org/FpML-5/transparency\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" fpmlVersion=\"5-5\" xsi:schemaLocation=\"http://www.fpml.org/FpML-5/transparency ../fpml-main-5-5.xsd http://www.w3.org/2000/09/xmldsig# ../xmldsig-core-schema.xsd\">" +
				  "<header>" +
				    "<messageId messageIdScheme=\"http://www.sdr.com/msg_id\">SDR002</messageId>" +
				    "<inReplyTo messageIdScheme=\"http://www.sdr.com/msg_id\">"+reportId+"</inReplyTo>" +
				    "<sentBy>SDR01</sentBy>" +
				    "<sendTo>00T248</sendTo>" +
				    "<creationTimestamp>"+getDate()+"</creationTimestamp>" +

				  "</header>" +
				  "<correlationId correlationIdScheme=\"http://fpml.org/universal_swap_id\">123</correlationId>" +
				  "<reason>" +
				    "<reasonCode>400</reasonCode>" +
				    "<description>Incorrect or Unsupported Product</description>" +
				  "</reason>" +
				  "<additionalData>" +
					 "<originalMessage>" +
					 origMessage +
					 "</originalMessage>" +
				  "</additionalData>" +
				"</publicExecutionReportException>";

		return nack;
	}

	private String generateRtAck(String reportId, String origMessage){

		String ack = "<?xml version=\"1.0\" encoding=\"utf-8\"?> "+
				"<publicExecutionReportAcknowledgement  xmlns=\"http://www.fpml.org/FpML-5/transparency\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" fpmlVersion=\"5-5\" xsi:schemaLocation=\"http://www.fpml.org/FpML-5/transparency ../fpml-main-5-5.xsd http://www.w3.org/2000/09/xmldsig# ../xmldsig-core-schema.xsd\">" +
				  "<header>" +
				    "<messageId messageIdScheme=\"http://www.sdr.com/msg_id\">SDR002</messageId>" +
				    "<inReplyTo messageIdScheme=\"http://www.sdr.com/msg_id\">"+reportId+"</inReplyTo>" +
				    "<sentBy>SDR01</sentBy>" +
				    "<sendTo>00T248</sendTo>" +
				    "<creationTimestamp>"+getDate()+"</creationTimestamp>" +

				  "</header>" +
				 // "<correlationId correlationIdScheme=\"http://fpml.org/universal_swap_id\">123</correlationId>" +
				//  "<additionalData>" +
					 "<originalMessage>" +
					 origMessage +
					 "</originalMessage>" +
				//  "</additionalData>" +
				"</publicExecutionReportAcknowledgement>";

		return ack;
	}


	private String generatePetNack(String reportId, String origMessage){

		String nack = "<?xml version=\"1.0\" encoding=\"utf-8\"?> "+
				"<nonpublicExecutionReportException xmlns=\"http://www.fpml.org/FpML-5/recordkeeping\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" fpmlVersion=\"5-5\" xsi:schemaLocation=\"http://www.fpml.org/FpML-5/recordkeeping ../fpml-main-5-5.xsd http://www.w3.org/2000/09/xmldsig# ../xmldsig-core-schema.xsd\">" +
				  "<header>" +
				    "<messageId messageIdScheme=\"http://www.sdr.com/msg_id\">SDR002</messageId>" +
				    "<inReplyTo messageIdScheme=\"http://www.sdr.com/msg_id\">"+reportId+"</inReplyTo>" +
				    "<sentBy>SDR01</sentBy>" +
				    "<sendTo>00T248</sendTo>" +
				    "<creationTimestamp>"+getDate()+"</creationTimestamp>" +

				  "</header>" +
				  "<correlationId correlationIdScheme=\"http://fpml.org/universal_swap_id\">123</correlationId>" +
				  "<reason>" +
				    "<reasonCode>400</reasonCode>" +
				    "<description>Incorrect or Unsupported Product</description>" +
				  "</reason>" +
				  "<additionalData>" +
					 "<originalMessage>" +
					 origMessage+
					 "</originalMessage>" +
				  "</additionalData>" +
				"</nonpublicExecutionReportException>";

		return nack;
	}

	private String generatePetAck(String reportId, String origMessage){

		String ack = "<?xml version=\"1.0\" encoding=\"utf-8\"?> "+
				"<nonpublicExecutionReportAcknowledgement  xmlns=\"http://www.fpml.org/FpML-5/recordkeeping\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" fpmlVersion=\"5-5\" xsi:schemaLocation=\"http://www.fpml.org/FpML-5/recordkeeping ../fpml-main-5-5.xsd http://www.w3.org/2000/09/xmldsig# ../xmldsig-core-schema.xsd\">" +
				  "<header>" +
				    "<messageId messageIdScheme=\"http://www.sdr.com/msg_id\">SDR002</messageId>" +
				    "<inReplyTo messageIdScheme=\"http://www.sdr.com/msg_id\">"+reportId+"</inReplyTo>" +
				    "<sentBy>SDR01</sentBy>" +
				    "<sendTo>00T248</sendTo>" +
				    "<creationTimestamp>"+getDate()+"</creationTimestamp>" +

				  "</header>" +
				 // "<correlationId correlationIdScheme=\"http://fpml.org/universal_swap_id\">123</correlationId>" +
				 // "<additionalData>" +
					 "<originalMessage>" +
					 origMessage +
					 "</originalMessage>" +
				 // "</additionalData>" +
				"</nonpublicExecutionReportAcknowledgement>";

		return ack;
	}


	public static XMLGregorianCalendar getDate()
	{

		Date date = new Date();

		XMLGregorianCalendar xmlCalendar = null;

		GregorianCalendar gCalendar = new GregorianCalendar();

		gCalendar.setTime(date);

		try
		{

			xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCalendar);

		}
		catch (DatatypeConfigurationException ex)
		{

		}

		return xmlCalendar;

	}

	public void setBrokerUrl(String brokerUrl) {
		this.brokerUrl = brokerUrl;
	}

	public void setResponseQueue(String responseQueue) {
		this.responseQueue = responseQueue;
	}

	public void setSimulateResponse(String simulateResponse) {
		this.simulateResponse = simulateResponse;
	}
}
