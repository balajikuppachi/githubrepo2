package org.kuppachi.emailUtilityTest.email;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

@Component
public class MailSenderService
{
	//@Autowired
	private MailSender mailSender = new MailSender();

	//@Value("${mail.from.ice}")
	String mailFromICE="balaji.kuppachi@wellsfargo.com";
	//@Value("${mail.to.ice}")
	String mailToICE="balaji.kuppachi@wellsfargo.com";
	@Value("${mail.cc.ice}")
	String mailCCICE;
	@Value("${mail.bcc.ice}")
	String mailBCCIce;
	@Value("${mail.replyto.ice}")
	String mailReplyToIce;

/*	mail.from.ice=balaji.kuppachi@wellsfargo.com
	mail.to.ice=balaji.kuppachi@wellsfargo.com
*/	
	private static Logger logger = Logger.getLogger(MailSenderService.class.getName());

	public void sendMail(String subject, String msg, String from, String to, String cc, String bcc, String replyTo)
	{
		logger.debug("Entering sendMail() method");

		String[] toArr = null;
		String[] toCCArr = null;
		String[] toBCCArr = null;
		
		if (StringUtils.isNotBlank(to)) toArr = to.split(",");
		if (StringUtils.isNotBlank(cc)) toCCArr = cc.split(",");
		if (StringUtils.isNotBlank(bcc)) toBCCArr = bcc.split(",");

		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(from);

		if (toArr != null) message.setTo(toArr);
		if (toCCArr != null) message.setCc(toCCArr);
		if (toBCCArr != null) message.setBcc(toBCCArr);
		if (StringUtils.isNotBlank(replyTo)) message.setReplyTo(replyTo);
		
		message.setSubject(subject);
		message.setText(msg);
		
		try
		{
			mailSender.send(message);
			logger.info("Mail Sent :" + subject);
		}
		catch (MailException me)
		{
			logger.error("######### Error in Sending Mail" + me.getMessage());
		}

		logger.info("Leaving sendMail() method");
	}

	
	public void sendIceExceptionMail(String subject, String msg)
	{
		logger.info("Inside sendIceExceptionMail method");
	
		sendMail( subject,  msg, mailFromICE, mailToICE,mailCCICE, mailBCCIce, mailReplyToIce);
	}

}
