package org.kuppachi.emailUtilityTest;

import java.io.IOException;




import org.apache.log4j.Logger;
import org.kuppachi.emailUtilityTest.email.MailSenderService;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmailUtilTestMain {

	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:emailUtilTestContext.xml";
	private static final Logger logger = Logger.getLogger(EmailUtilTestMain.class);
	
	
	public static void main(String[] args) throws IOException
	{
		logger.info("EmailUtilTestMain application starting...");
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		applicationContext.start();
		
		MailSenderService mailSenderService = new MailSenderService();
		
		mailSenderService
		.sendIceExceptionMail(
				"IceException with job ID:"
						+12314123,
				"Exception Description : JAXB Exception. Reason : unable to parse JAXB Object to String.");
		
		
		//applicationContext.registerShutdownHook();
		logger.info("EmailUtilTestMain application started successfully");
	}
}
