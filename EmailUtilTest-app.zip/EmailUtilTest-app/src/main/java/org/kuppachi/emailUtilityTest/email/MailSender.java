
package org.kuppachi.emailUtilityTest.email;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

@Component
public class MailSender extends JavaMailSenderImpl {
	
	//@Value("${mail.host}")
	String mailHost = "mxtest.wellsfargo.com" ;
	//@Value("${mail.enabled}") 
	boolean enabled = false;
	
	/*
	mail.host=mxtest.wellsfargo.com
	mail.enabled=false
	*/
	
	
	MailSender(){
		super();
		setHost("mailHost");
		setPort(25);
		setUsername("");
		setPassword("");
		
		getJavaMailProperties().put("mail.transport.protocol", "smtp");
		getJavaMailProperties().put("mail.smtp.auth", true);
		getJavaMailProperties().put("mail.debug",true);
		getJavaMailProperties().put("mail.smtp.starttls.enable", true);		
		
	}
	
	@Override
	public void send(SimpleMailMessage simpleMessage) throws MailException {
		if (enabled){
			super.send(simpleMessage);
		}
	}
}
