package com.wellsfargo.regulatory.recon;

import java.util.Date;

import com.wellsfargo.regulatory.recon.util.ReconUtil;

public class TestformatStrDate
{

	public static void main(String[] args)
	{
		String strDate = "2014-02-24";
		Date  date = ReconUtil.formatStrDateOnly(strDate);
		
		System.out.println("formatted date " + date);

	}

}
