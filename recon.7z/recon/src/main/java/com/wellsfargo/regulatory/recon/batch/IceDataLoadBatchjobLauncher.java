package com.wellsfargo.regulatory.recon.batch;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepReconReportStatusDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportStatus;
import com.wellsfargo.regulatory.persister.util.dao.RegRepSequenceIdDao;
import com.wellsfargo.regulatory.persister.util.dto.RegRepSequenceId;
import com.wellsfargo.regulatory.recon.ice.batch.services.IceDbDataReaderRequest;
import com.wellsfargo.regulatory.recon.util.ReconConstants;
import com.wellsfargo.regulatory.recon.util.ReconUtil;

/**
 * @author Raji Komatreddy
 */
public class IceDataLoadBatchjobLauncher
{

	private Job iceDataLoadBatchjob;
	private String tempFileLoc;   // = "C:\\SDR\\test\\";
	
	@Autowired
	@Qualifier("iceDBDataLoadBatchjob")
	private Job iceDBDataLoadBatchjob;

	@Autowired
	private RegRepSequenceIdDao regRepSequenceIdDao;

	@Autowired
	private RegRepReconReportStatusDao regRepReconReportStatusDao;

	private static Logger logger = Logger.getLogger(EndurDataLoadBatchjobLauncher.class.getName());

	@Transformer
	public Message<JobLaunchRequest> launchJob(Message<?> message) throws EtdMessageException
	{
		Object ipMessage = null;
		String errorString = null;
		String iceFileLoc = null;
		String fileName = null;
		JobLaunchRequest iceDataLoadJob = null;
		Message<JobLaunchRequest> iceDataLoadBatchjobLaunch = null;
		String runDate = null;
		IceDbDataReaderRequest  iceDbDataReaderRequest = null;

		RegRepReconReportStatus currRegRepReconReportStatus = new RegRepReconReportStatus();
		Date reportDate = null;
		Date currDate = new Date();
		Date currRptDate = new Date();

		String reportDateStr = null;

		// need to write logic to make this as unique
		int batchID = 0;

		RegRepSequenceId regRepSequenceId = null;
		regRepSequenceId = regRepSequenceIdDao.getNextRegRepSequnceId(RegRepSequenceId.CALL_STOREDPROC_GETNEXTSEQUENCEID, 1);
		if (null != regRepSequenceId)
		{
			batchID = regRepSequenceId.getSequenceId();
		}

		logger.info("inside IceDataLoadBatchjobLauncher launchJob method");
		if (null == message)
		{
			errorString = "Null incoming message from  IceDataLoadBatchjobLauncher ";
			logger.error("########## " + errorString);
			throw new EtdMessageException("IceDataLoadBatchjobLauncher-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		runDate = (String) message.getHeaders().get("runDate");
		
		if(null != runDate && ipMessage instanceof File)
		{
			logger.info("loading ice data from DB for runDate " + runDate);
			reportDate = ReconUtil.formatYYYYMMDDtoDate(runDate);

			try
			{
				
		
			currRegRepReconReportStatus.setBatchId(batchID);
			currRegRepReconReportStatus.setSourceSystem(ReconConstants.ICE_SRC_SYS_NAME);
			currRegRepReconReportStatus.setReportDate(reportDate);
			currRegRepReconReportStatus.setReportStatus(ReconConstants.RECON_REPORT_STATUS_PROCESSING);
			currRegRepReconReportStatus.setOutFileName("loading from DB");
			currRegRepReconReportStatus.setCreateDatetime(currDate);
			currRegRepReconReportStatus.setUpdateDatetime(currDate);

			if (null != regRepSequenceIdDao) 
				currRegRepReconReportStatus = regRepReconReportStatusDao.save(currRegRepReconReportStatus);
			
			JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();			
			jobParametersBuilder.addString(ReconConstants.RECON_BATCH_ID, Integer.toString(batchID));
			jobParametersBuilder.addString(ReconConstants.ICE_IN_FILE_NAME, fileName);
			jobParametersBuilder.addDate(ReconConstants.RECON_REPORT_DATE, reportDate);
			jobParametersBuilder.addString(ReconConstants.RECON_REPORT_ID, Integer.toString(currRegRepReconReportStatus.getReportId()));

			iceDataLoadJob = new JobLaunchRequest(iceDBDataLoadBatchjob, jobParametersBuilder.toJobParameters());
			iceDataLoadBatchjobLaunch = MessageBuilder.withPayload(iceDataLoadJob).build();
			
			}
			catch(Exception e)
			{
				errorString = "exception occurred while creating IceDataLoadBatchjobLauncher launch request for iceDB job " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new EtdMessageException("IceDataLoadBatchjobLauncher-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
				
			}
			
		}
		
		else if (ipMessage instanceof File)
		{

			logger.info("consuming ice input file");
			try
			{
				File inFile = (File) ipMessage;
				iceFileLoc = inFile.getAbsolutePath();
				fileName = inFile.getName();
				File tempFile = new File(tempFileLoc + fileName);

				if (null != fileName && fileName.length() > 16)
				{
					reportDateStr = StringUtils.substring(fileName, 8, 16);					

				}
				else
				{
					errorString = "filename is not as in agreed format: file recieved is  " + fileName;
					logger.error("########## " + errorString);
					throw new EtdMessageException("IceDataLoadBatchjobLauncher-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

				}

				reportDate = ReconUtil.formatYYYYMMDDtoDate(reportDateStr);

				currRegRepReconReportStatus.setBatchId(batchID);
				currRegRepReconReportStatus.setSourceSystem(ReconConstants.ICE_SRC_SYS_NAME);
				currRegRepReconReportStatus.setReportDate(reportDate);
				currRegRepReconReportStatus.setReportStatus(ReconConstants.RECON_REPORT_STATUS_PROCESSING);
				currRegRepReconReportStatus.setOutFileName(iceFileLoc);
				currRegRepReconReportStatus.setCreateDatetime(currDate);
				currRegRepReconReportStatus.setUpdateDatetime(currDate);

				if (null != regRepSequenceIdDao) 
					currRegRepReconReportStatus = regRepReconReportStatusDao.save(currRegRepReconReportStatus);

				tempFile.mkdirs();
				Files.copy(inFile.toPath(), tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
				iceFileLoc = tempFile.getAbsolutePath();
				 inFile.delete();

				JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
				jobParametersBuilder.addString(ReconConstants.ICE_IN_FILE_LOC, iceFileLoc);
				jobParametersBuilder.addString(ReconConstants.RECON_BATCH_ID, Integer.toString(batchID));
				jobParametersBuilder.addString(ReconConstants.ICE_IN_FILE_NAME, fileName);
				jobParametersBuilder.addString(ReconConstants.RECON_REPORT_DATE, reportDateStr);
				jobParametersBuilder.addString(ReconConstants.RECON_REPORT_ID, Integer.toString(currRegRepReconReportStatus.getReportId()));

				iceDataLoadJob = new JobLaunchRequest(iceDataLoadBatchjob, jobParametersBuilder.toJobParameters());
				iceDataLoadBatchjobLaunch = MessageBuilder.withPayload(iceDataLoadJob).build();

			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating IceDataLoadBatchjobLauncher launch request " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new EtdMessageException("IceDataLoadBatchjobLauncher-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

			}

		}
		else if(ipMessage instanceof IceDbDataReaderRequest)
		{
			iceDbDataReaderRequest = (IceDbDataReaderRequest)ipMessage;
			runDate = iceDbDataReaderRequest.getRunDate();
			if(null != runDate )
			{
				reportDate = ReconUtil.formatYYYYMMDDtoDate(runDate);
			}
			else
			{
				Calendar calendar = Calendar.getInstance();
				int day = calendar.get(Calendar.DAY_OF_WEEK);
				if (day == 2)
				{
					currRptDate = DateUtils.addDays(currRptDate, -3);
				}
				else
				{
					currRptDate = DateUtils.addDays(currRptDate, -1);
				}
				
				reportDate = currRptDate;
			}
				
				try
				{					
			
				currRegRepReconReportStatus.setBatchId(batchID);
				currRegRepReconReportStatus.setSourceSystem(ReconConstants.ICE_SRC_SYS_NAME);
				currRegRepReconReportStatus.setReportDate(reportDate);
				currRegRepReconReportStatus.setReportStatus(ReconConstants.RECON_REPORT_STATUS_PROCESSING);
				currRegRepReconReportStatus.setOutFileName("loading from DB");
				currRegRepReconReportStatus.setCreateDatetime(currDate);
				currRegRepReconReportStatus.setUpdateDatetime(currDate);

				if (null != regRepSequenceIdDao) 
					currRegRepReconReportStatus = regRepReconReportStatusDao.save(currRegRepReconReportStatus);
				
				JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();			
				jobParametersBuilder.addString(ReconConstants.RECON_BATCH_ID, Integer.toString(batchID));				
				jobParametersBuilder.addDate(ReconConstants.RECON_REPORT_DATE, reportDate);
				jobParametersBuilder.addString(ReconConstants.RECON_REPORT_ID, Integer.toString(currRegRepReconReportStatus.getReportId()));

				iceDataLoadJob = new JobLaunchRequest(iceDBDataLoadBatchjob, jobParametersBuilder.toJobParameters());
				iceDataLoadBatchjobLaunch = MessageBuilder.withPayload(iceDataLoadJob).build();
				
				}
				catch(Exception e)
				{
					errorString = "exception occurred while creating IceDataLoadBatchjobLauncher launch request for iceDB job " + ExceptionUtils.getFullStackTrace(e);
					logger.error("########## " + errorString);
					throw new EtdMessageException("IceDataLoadBatchjobLauncher-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
					
				}
				
			
			
		}

		logger.info("exiting IceDataLoadBatchjobLauncher JobLaunchRequest method");

		return iceDataLoadBatchjobLaunch;

	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

	public Job getIceDataLoadBatchjob()
	{
		return iceDataLoadBatchjob;
	}

	public void setIceDataLoadBatchjob(Job iceDataLoadBatchjob)
	{
		this.iceDataLoadBatchjob = iceDataLoadBatchjob;
	}

}
