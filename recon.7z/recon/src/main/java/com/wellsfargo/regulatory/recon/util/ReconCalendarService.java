package com.wellsfargo.regulatory.recon.util;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.dao.RegRepPrHolidayDao;
import com.wellsfargo.regulatory.persister.dto.RegRepPrHoliday;


@Component
public class ReconCalendarService {



	private static final int WEEKEND_1 = Calendar.SATURDAY;
	private static final int WEEKEND_2 = Calendar.SUNDAY;

	@Autowired
	RegRepPrHolidayDao regRepPrHolidayDaoImpl;
	

	public boolean isWorkingDay(Date date)
	{
		boolean isWorkingDay = true;
		Calendar calInstance = Calendar.getInstance();
		calInstance.setTime(date);

		int weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
		
		
		// Not including holidays from reg rep pr calendar table
		/*List<RegRepPrHoliday> holiday = regRepPrHolidayDaoImpl.findDate(date);	
		if(holiday.isEmpty()){
			isWorkingDay=true;
		}
		else{
		for(RegRepPrHoliday regRepPrHoliday:holiday)
		{
		if (holiday != null && regRepPrHoliday.getDate() != null)
		{
			isWorkingDay = false;
		}
		}
		}*/
		if (weekDay == WEEKEND_1 || weekDay == WEEKEND_2)
		{
			isWorkingDay = false;
		}
		
		return isWorkingDay;
	}
	
	

	public 	Date getPreviousWorkingDay(Date date)
	{
		Date previousWorkingDate = null;
		try
		{
			if (date != null)
			{
				Calendar calInstance = Calendar.getInstance();
				calInstance.setTime(date);
				int weekDay = calInstance.get(Calendar.DAY_OF_WEEK);
			/*	if (!(weekDay == WEEKEND_1 || weekDay == WEEKEND_2 || !isWorkingDay(calInstance.getTime())))
				{
					return date;
				}*/

				do
				{
					calInstance.add(Calendar.DATE, -1);
					/*weekDay = calInstance.get(Calendar.DAY_OF_WEEK);*/
				}
				while (weekDay == WEEKEND_1 || weekDay == WEEKEND_2 || !isWorkingDay(calInstance.getTime()));

				previousWorkingDate = calInstance.getTime();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return previousWorkingDate;
	}
		

	
}
