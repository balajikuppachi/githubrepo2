package com.wellsfargo.regulatory.recon.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.utils.CalendarUtils;

/**
 * @author Raji Komatreddy
 */
public class ReconUtil
{

	public static final String FORMAT_1 = "MM/dd/yyyy HH:mm";
	public static final String FORMAT_2 = "MM/dd/yyyy";
	public static final String FORMAT_3 = "yyyyMMdd";
	
	public static final String FORMAT_4 = "MM/dd/yyyy hh:mm:ss a";
	public static final String FORMAT_5 = "MM-dd-yyyy";
	

	private static Logger logger = Logger.getLogger(CalendarUtils.class.getName());

	// converts string data format into Date
	public static Date formatStrDate(String dateInString)
	{
		if (null == dateInString) return null;
		SimpleDateFormat formatter = new SimpleDateFormat(FORMAT_1);
		Date date = null;

		try
		{
			date = formatter.parse(dateInString);
		}
		catch (ParseException e)
		{
			logger.error("Unable to convert " + dateInString + " string " + date + "due to an error ", e);
		}

		return date;
	}

	// converts string data format into Date
	public static Date formatStrDateOnly(String dateInString)
	{
		if (null == dateInString) return null;

		SimpleDateFormat formatter = new SimpleDateFormat(FORMAT_2);
		SimpleDateFormat formatter1 = new SimpleDateFormat(FORMAT_5);
		Date date = null;

		try
		{
			date = formatter.parse(dateInString);
		}
		catch (ParseException e)
		{
			try
			{
				date = formatter1.parse(dateInString);
			}
			catch (ParseException e1)
			{
				logger.error("Unable to convert " + dateInString + " string " + date + "due to an error ", e);
				logger.error("Unable to convert " + dateInString + " string " + date + "due to an error ", e1);
			}
		}

		return date;
	}
	
	// converts string data format into Date
		public static Date formatYYYYMMDDtoDate(String dateInString)
		{
			if (null == dateInString) return null;

			SimpleDateFormat formatter = new SimpleDateFormat(FORMAT_3);
			Date date = null;

			try
			{
				date = formatter.parse(dateInString);
			}
			catch (ParseException e)
			{
				logger.error("Unable to convert " + dateInString + " string " + date + "due to an error ", e);
			}

			return date;
		}
		
		// converts string data format into Date
		public static Date formatMmddYYHHMMSSAasStrDate(String dateInString)
		{
			if (null == dateInString) return null;
			SimpleDateFormat formatter = new SimpleDateFormat(FORMAT_4);
			Date date = null;

			try
			{
				date = formatter.parse(dateInString);
			}
			catch (ParseException e)
			{
				logger.error("Unable to convert " + dateInString + " string " + date + "due to an error ", e);
			}

			return date;
		}
	


}
