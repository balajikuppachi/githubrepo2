package com.wellsfargo.regulatory.recon.batch;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepReconReportStatusDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportStatus;
import com.wellsfargo.regulatory.recon.dto.ReconReportGenerationRequest;
import com.wellsfargo.regulatory.recon.report.services.ReconReportGeneratorSvc;
import com.wellsfargo.regulatory.recon.util.ReconConstants;
import com.wellsfargo.regulatory.recon.util.ReconUtil;

/**
 * @author Raji Komatreddy
 */

@Component
public class ReconReportGenRequest
{

	@Value("${recon.in.file.reportDate}")
	private String reportDate;
	@Value("${recon.in.file.source1}")
	private String source1;
	@Value("${recon.in.file.source2}")
	private String source2;
	@Value("${recon.ice.process.enabled}")
	private boolean iceProcessEnabled;

	@Autowired
	private ReconReportGeneratorSvc reconReportGeneratorSvc;

	@Autowired
	private RegRepReconReportStatusDao regRepReconReportStatusDao;

	private static Logger logger = Logger.getLogger(ReconReportGenRequest.class.getName());

	public Message<?> genReconReport(Message<?> message) throws EtdMessageException
	{
		Object ipMessage = null;
		String errorString = null;
		ReconReportGenerationRequest currReconReportGenerationRequest = null;
		RegRepReconReportStatus regRepReconReportStatusEndur = null;
		RegRepReconReportStatus regRepReconReportStatusIce = null;
		Date rptDate = null;
		String endurProcessStatus = null;
		String iceProcessStatus = null;
		boolean endurJobStatus = true;
		boolean iceJobStatus = true;

		Date currRptDate = new Date();
		String reconJobStatus = null;
		Message<ReconReportGenerationRequest> responseMsg = null;

		logger.info("inside ReconReportGeneratorSvc genReconReport method");
		if (null == message)
		{
			errorString = "Null incoming message ReconReportGeneratorSvc";
			logger.error("########## " + errorString);
			throw new EtdMessageException("ReconReportGeneratorSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		Calendar calendar = Calendar.getInstance();
		int day = calendar.get(Calendar.DAY_OF_WEEK);
		if (day == 2)
		{
			currRptDate = DateUtils.addDays(currRptDate, -3);
		}
		else
		{
			currRptDate = DateUtils.addDays(currRptDate, -1);
		}

		ipMessage = message.getPayload();

		if (ipMessage instanceof ReconReportGenerationRequest)
		{
			currReconReportGenerationRequest = (ReconReportGenerationRequest) ipMessage;

			if (StringUtils.isBlank(reportDate)) reportDate = currReconReportGenerationRequest.getReportDate();

			if (StringUtils.isBlank(source1)) source1 = currReconReportGenerationRequest.getSource1();

			if (StringUtils.isBlank(source2)) source2 = currReconReportGenerationRequest.getSource2();

		}

		if (StringUtils.isBlank(source1)) source1 = ReconConstants.ENDUR_SRC_SYS_NAME;

		if (StringUtils.isBlank(source2)) source2 = ReconConstants.ICE_SRC_SYS_NAME;

		String dateFormat = ReconConstants.RECON_REPORT_DATEFORMAT;
		SimpleDateFormat rptDateFormat = new SimpleDateFormat(dateFormat);

		reportDate = (StringUtils.isNotEmpty(reportDate)) ? reportDate : rptDateFormat.format(currRptDate);

		try
		{
			rptDate = rptDateFormat.parse(reportDate);
		}
		catch (ParseException e)
		{
			logger.error("Exception occurred while parsing reportDate " + e.getMessage());
		}

		if(null == currReconReportGenerationRequest)
			currReconReportGenerationRequest = new ReconReportGenerationRequest();
		
		currReconReportGenerationRequest.setReportDate(reportDate);
		currReconReportGenerationRequest.setEndurJobStatus(ReconConstants.RECON_REPORT_STATUS_SUCCESS);
		currReconReportGenerationRequest.setIceJobStatus(ReconConstants.RECON_REPORT_STATUS_SUCCESS);
		if (null != regRepReconReportStatusDao)
		{
			regRepReconReportStatusEndur = regRepReconReportStatusDao.getReconReportStatusByReportDate(rptDate, source1);
			regRepReconReportStatusIce = regRepReconReportStatusDao.getReconReportStatusByReportDate(rptDate, source2);
			if (null != regRepReconReportStatusEndur)
			{
				endurProcessStatus = regRepReconReportStatusEndur.getReportStatus();
				if (null != endurProcessStatus
				        && (endurProcessStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_ERROR) || endurProcessStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_PROCESSING)))
				{
					currReconReportGenerationRequest.setEndurJobStatus(ReconConstants.RECON_REPORT_STATUS_ERROR);
					endurJobStatus = false;

				}
			}
			else
			{
				currReconReportGenerationRequest.setEndurJobStatus(ReconConstants.RECON_REPORT_STATUS_NODATA);
				endurJobStatus = false;
			}

			if (null != regRepReconReportStatusIce)
			{
				iceProcessStatus = regRepReconReportStatusIce.getReportStatus();
				if (null != iceProcessStatus
				        && (iceProcessStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_ERROR) || iceProcessStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_PROCESSING)))
				{
					currReconReportGenerationRequest.setIceJobStatus(ReconConstants.RECON_REPORT_STATUS_ERROR);
					iceJobStatus = false;

				}
			}
			else
			{
				currReconReportGenerationRequest.setIceJobStatus(ReconConstants.RECON_REPORT_STATUS_NODATA);
				iceJobStatus = false;
			}

			logger.info("processing status of Endur file is " + endurProcessStatus);
			logger.info("processing status of ICE file is " + iceProcessStatus);

		}
		//iceJobStatus is successs only for manual file drop and iceProcessEnabled is triggered job
		if ((null != reconReportGeneratorSvc && endurJobStatus && iceJobStatus )) 
		{
			logger.info("running recon report for report date:  " + reportDate + " source1 : " + source1 + " source2: " + source2);
			reconJobStatus = reconReportGeneratorSvc.generateReport(reportDate, source1, source2);
			if (StringUtils.isNotBlank(reconJobStatus) && null != currReconReportGenerationRequest)
			{
				if (reconJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_SUCCESS))
				{
					currReconReportGenerationRequest.setReconJobStatus(ReconConstants.RECON_REPORT_STATUS_SUCCESS);
				}
				else if (reconJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_NODATA))
				{
					currReconReportGenerationRequest.setReconJobStatus(ReconConstants.RECON_REPORT_STATUS_NODATA);
				}
				else
				{
					currReconReportGenerationRequest.setReconJobStatus(ReconConstants.RECON_REPORT_STATUS_ERROR);
				}
			}

		}
		else
		{
			logger.info("inside ReconReportGeneratorSvc : reconReportGeneratorSvc is null or either Endur or Ice file was not processed for report date " + reportDate);
			currReconReportGenerationRequest.setReconJobStatus(ReconConstants.RECON_REPORT_STATUS_NODATA);

		}
		responseMsg = MessageBuilder.withPayload(currReconReportGenerationRequest).build();

		logger.info("exiting ReconReportGeneratorSvc genReconReport method");

		return responseMsg;

	}

}
