package com.wellsfargo.regulatory.recon.ice.batch.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.persister.recon.dao.RegRepCommTradeMtermsDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;
import com.wellsfargo.regulatory.recon.endur.batch.services.EndurDataDbWriter;

/**
 * @author Raji Komatreddy
 */
public class IceDataDbWriter implements ItemWriter<RegRepCommTradeMterms>, StepExecutionListener
{
	private static Logger logger = Logger.getLogger(EndurDataDbWriter.class.getName());
	private List<RegRepCommTradeMterms> finalFegRepCommTradeMtermsList = new ArrayList<RegRepCommTradeMterms>();

	@Autowired
	private RegRepCommTradeMtermsDao regRepCommTradeMtermsDao;

	@Override
	public void write(List<? extends RegRepCommTradeMterms> regRepCommTradeMtermsList) throws Exception
	{
		logger.info("inside IceDataDbWriter write method");
		finalFegRepCommTradeMtermsList.addAll(regRepCommTradeMtermsList);
		Collection<RegRepCommTradeMterms> currColliectionList = (Collection<RegRepCommTradeMterms>) regRepCommTradeMtermsList;

		// regRepCommTradeMtermsDao.saveOrUpdateAll(currColliectionList);
		regRepCommTradeMtermsDao.springBatchInsert((List<RegRepCommTradeMterms>) regRepCommTradeMtermsList);

		/*
		 * for(RegRepCommTradeMterms currRegRepCommTradeMterms : regRepCommTradeMtermsList ) {
		 * regRepCommTradeMtermsDao.save(currRegRepCommTradeMterms); }
		 */

		logger.info("exiting IceDataDbWriter write method");

	}

	@Override
	public ExitStatus afterStep(StepExecution arg0)
	{
		// stepExecution.getJobExecution().getExecutionContext().put(ReconConstants.ENDUR_MESSAGES_LIST,
		// finalFegRepCommTradeMtermsList);
		// regRepCommTradeMtermsDao.saveOrUpdateAll(finalFegRepCommTradeMtermsList);

		return null;
	}

	@Override
	public void beforeStep(StepExecution arg0)
	{
		// TODO Auto-generated method stub

	}

}
