package com.wellsfargo.regulatory.recon.ice.batch.services;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepIceOpenTransaction;
import com.wellsfargo.regulatory.recon.util.ReconConstants;

/**
 * @author Raji Komatreddy
 */
public class ComTradeMtermsDataMapperProcessor implements ItemProcessor<RegRepIceOpenTransaction, RegRepCommTradeMterms>,StepExecutionListener
{

	private static Logger logger = Logger.getLogger(ComTradeMtermsDataMapperProcessor.class.getName());
	
	Date reportDate = null;
	int batchId = 0;

	@Override
	public RegRepCommTradeMterms process(RegRepIceOpenTransaction iceOpenTransaction) throws Exception
	{

		String currBuyer = null;
		String currSeller = null;
		String currBuyerParent = null;
		String currSellerParent = null;
		String currUSReportingEntityPETData = null;
		String currUSReportingEntityContinuationData = null;
		String currBuyerSenderTradeRefId = null;
		String currSellerSenderTradeRefId = null;
		String currBuyerLEI = null;
		String currSellerLEI = null;
		String party1name = null;
		String party2name = null;
		String party1Lei = null;
		String party2Lei = null;
		String senderTradeRefId = null;
		String firstReportedSDR = null;
		Date tradeDate = null;
		Date effectiveDate = null;
		Date tlcEventDateTime = null;
		Date maturityDate = null;
		boolean buerFlag = false;
		boolean sellerFlag = false;

		byte reportingParty = 0;
		byte reportable = 0;

		Date currDate = new Date();		

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		RegRepCommTradeMterms currRegRepCommTradeMterms = new RegRepCommTradeMterms();
		
		//set ReportDate received from job parameters
		currRegRepCommTradeMterms.setReportDate(reportDate);
		currRegRepCommTradeMterms.setBatchId(batchId);
		
		currRegRepCommTradeMterms.setProductId(iceOpenTransaction.getTvProductId());
		currRegRepCommTradeMterms.setProductName(iceOpenTransaction.getTvProductName());

		try
		{
			if (null != iceOpenTransaction.getTradeDate() || !StringUtils.isEmpty(iceOpenTransaction.getTradeDate()))
			{
				currRegRepCommTradeMterms.setTradeDate(dateFormat.parse(iceOpenTransaction.getTradeDate()));
			}
			else
			{
				currRegRepCommTradeMterms.setTradeDate(tradeDate);
			}

			if (null != iceOpenTransaction.getEndDate() || !StringUtils.isEmpty(iceOpenTransaction.getEndDate()))
			{
				currRegRepCommTradeMterms.setEffectiveDate(dateFormat.parse(iceOpenTransaction.getEndDate()));
			}
			else
			{
				currRegRepCommTradeMterms.setEffectiveDate(effectiveDate);
			}
			if (null != iceOpenTransaction.getStartDate() || !StringUtils.isEmpty(iceOpenTransaction.getStartDate()))
			{
				currRegRepCommTradeMterms.setMaturityDate(dateFormat.parse(iceOpenTransaction.getStartDate()));
			}
			else
			{
				currRegRepCommTradeMterms.setMaturityDate(maturityDate);
			}

			currRegRepCommTradeMterms.setTlcEvent(iceOpenTransaction.getLifeCycleEventStatus());
			if (null != iceOpenTransaction.getLifecycleEventTimestamp() || !StringUtils.isEmpty(iceOpenTransaction.getLifecycleEventTimestamp()))
			{
				currRegRepCommTradeMterms.setTlcEventDatetime(dateFormat.parse(iceOpenTransaction.getLifecycleEventTimestamp()));
			}
			else
			{
				currRegRepCommTradeMterms.setTlcEventDatetime(tlcEventDateTime);
			}

		}
		catch (ParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		currBuyer = iceOpenTransaction.getBuyer();
		currSeller = iceOpenTransaction.getSeller();
		currBuyerParent = iceOpenTransaction.getBuyerParent();
		currSellerParent = iceOpenTransaction.getSellerParent();
		currUSReportingEntityPETData = iceOpenTransaction.getUsReportingEntityPetData();
		currUSReportingEntityContinuationData = iceOpenTransaction.getUsReportingEntityContinuationData();
		currBuyerLEI = iceOpenTransaction.getBuyerLei();
		currSellerLEI = iceOpenTransaction.getSellerLei();
		currBuyerSenderTradeRefId = iceOpenTransaction.getBuyerSenderTradeRefId();
		currSellerSenderTradeRefId = iceOpenTransaction.getSellerSenderTradeRefId();
		firstReportedSDR = iceOpenTransaction.getFirstReportedSdr();

		if (null != currBuyerParent && currBuyerParent.equalsIgnoreCase(ReconConstants.WELLS_FARGO))
			buerFlag = true;

		if (null != currSellerParent && currSellerParent.equalsIgnoreCase(ReconConstants.WELLS_FARGO)) 
			sellerFlag = true;

		if (buerFlag && sellerFlag)
		{
			if (null != currBuyer)
			{
				if ((null != currUSReportingEntityPETData && currBuyer.equalsIgnoreCase(currUSReportingEntityPETData))
				        || (null != currUSReportingEntityContinuationData && currBuyer.equalsIgnoreCase(currUSReportingEntityContinuationData)))
				{
					party1name = currBuyer;
					party2name = currSeller;

					party1Lei = currBuyerLEI;
					party2Lei = currSellerLEI;
					senderTradeRefId = currBuyerSenderTradeRefId;
				}
				else
				{
					party1name = currSeller;
					party2name = currBuyer;

					party1Lei = currSellerLEI;
					party2Lei = currBuyerLEI;
					senderTradeRefId = currSellerSenderTradeRefId;

				}
			}
		}
		else if (buerFlag)
		{
			party1name = currBuyer;
			party2name = currSeller;

			party1Lei = currBuyerLEI;
			party2Lei = currSellerLEI;
			senderTradeRefId = currBuyerSenderTradeRefId;

		}
		else if (sellerFlag)
		{
			party1name = currSeller;
			party2name = currBuyer;

			party1Lei = currSellerLEI;
			party2Lei = currBuyerLEI;
			senderTradeRefId = currSellerSenderTradeRefId;

		}
		else
		{
			logger.info("Neither buyer flag nor seller flag is true : hence not able to set party1 and party2 information");
		}

		currRegRepCommTradeMterms.setParty1Name(StringUtils.replaceChars(party1name, ",", " "));
		currRegRepCommTradeMterms.setParty2Name(StringUtils.replaceChars(party2name, ",", " "));
		
		currRegRepCommTradeMterms.setParty1Lei(party1Lei);
		currRegRepCommTradeMterms.setParty2Lei(party2Lei);

		currRegRepCommTradeMterms.setUsi(iceOpenTransaction.getUsiUti());
		currRegRepCommTradeMterms.setIceConfirmStatus(iceOpenTransaction.getTradeStatus());

		if ((null != currUSReportingEntityPETData && null != party1name && party1name.equalsIgnoreCase(currUSReportingEntityPETData))
		        || (null != currUSReportingEntityContinuationData && null != party1name && party1name.equalsIgnoreCase(currUSReportingEntityContinuationData)))
		{
			reportingParty = 1;
		}
		if (StringUtils.isNotBlank(firstReportedSDR))
		{
			reportable = 1;
			currRegRepCommTradeMterms.setReportable(reportable);
			currRegRepCommTradeMterms.setRepository(firstReportedSDR);
		}

		currRegRepCommTradeMterms.setReportingParty(reportingParty);

		if (null != senderTradeRefId && StringUtils.isNotBlank(senderTradeRefId))
		{
			currRegRepCommTradeMterms.setSenderTradeRefId(senderTradeRefId);
		}
		
		if (null != iceOpenTransaction.getRunDate())
		{
			currRegRepCommTradeMterms.setReportDate(iceOpenTransaction.getRunDate());
		}
		currRegRepCommTradeMterms.setCreateDatetime(currDate);
		currRegRepCommTradeMterms.setCreateDatetime(currDate);
		currRegRepCommTradeMterms.setSourceSystem(ReconConstants.ICE_SRC_SYS_NAME);

		return currRegRepCommTradeMterms;
	}

	@Override
    public ExitStatus afterStep(StepExecution arg0)
    {
	    // TODO Auto-generated method stub
	    return null;
    }

	@Override
    public void beforeStep(StepExecution stepExecution)
    {
		reportDate = 	stepExecution.getJobParameters().getDate(ReconConstants.RECON_REPORT_DATE);
		batchId =  Integer.parseInt(stepExecution.getJobParameters().getString(ReconConstants.RECON_BATCH_ID));
	    
    }

}
