package com.wellsfargo.regulatory.recon.report.services;

import java.io.File;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.exceptions.EtdException;
import com.wellsfargo.regulatory.recon.util.ReconConstants;

/**
 * @author Raji Komatreddy Drop empty file with name as 'Endur.txt' or ice.txt in OnDemand folder It
 * will pick file from Endur/Ice input folder and process the file
 */
@Component
public class OnDemandIceEndurFileProcessor
{

	@Value("${recon.endur.input.file.path}")
	private String endurFileinLoc;

	@Value("${recon.ice.input.file.path}")
	private String iceFileInLoc;

	private static Logger logger = Logger.getLogger(OnDemandIceEndurFileProcessor.class.getName());

	public Message<?> processFile(Message<?> message) throws EtdException
	{
		logger.info("inside OnDemandIceEndurFileProcessor: processFile method, will process Endur/Ice file from thier input folder");
		Object ipMessage = null;
		File inFile = null;
		File outFile = null;
		String endurOrIceFileLoc = null;
		String inFileName = null;
		File[] listOfFiles = null;
		String sourceType = null;
		String runDate = null;

		File endurIceInFileFolder = null;

		Message<File> endurOrIceFileMessage = null;

		if (null == message)
		{
			logger.error("input message is null: from OnDemandIceEndurFileProcessor processFile method");
			return message;
		}

		ipMessage = message.getPayload();

		if (null == ipMessage)
		{
			logger.error("input message  payload is null: from OnDemandIceEndurFileProcessor processFile method");
			return message;
		}

		if (ipMessage instanceof File)
		{
			inFile = ((File) ipMessage);
			endurOrIceFileLoc = inFile.getAbsolutePath();
			inFileName = inFile.getName();
			if (null != inFileName)
			{
				inFileName = StringUtils.substringBefore(inFileName, ".");
				inFile.delete();
			}

			logger.info("input request is to process Endur/Ice file, request file name:  : " + endurOrIceFileLoc);

			if (inFileName != null && inFileName.equalsIgnoreCase(ReconConstants.ENDUR_SRC_SYS_NAME))
			{
				endurIceInFileFolder = new File(endurFileinLoc);

				if (null != endurIceInFileFolder)
				{
					listOfFiles = endurIceInFileFolder.listFiles();
					if (null != listOfFiles)
					{
						for (File currFile : listOfFiles)
						{
							if (currFile.isFile())
							{
								outFile = currFile;
							}
						}
						if (null == outFile)
						{
							logger.error("no files exist in Endur input folder " + endurFileinLoc);
						}
						else
						{
							sourceType = ReconConstants.ENDUR_SRC_SYS_NAME;
							logger.info("endur fileName " + outFile.getName());
						}

					}
					else
					{
						logger.error("no files exist at Endur in folder  " + endurFileinLoc);
					}

				}

			}
			else if (inFileName != null && inFileName.equalsIgnoreCase(ReconConstants.ICE_SRC_SYS_NAME))
			{
				endurIceInFileFolder = new File(iceFileInLoc);

				if (null != endurIceInFileFolder)
				{
					listOfFiles = endurIceInFileFolder.listFiles();
					if (null != listOfFiles)
					{
						for (File currFile : listOfFiles)
						{
							if (currFile.isFile())
							{
								outFile = currFile;
							}
						}
						if (null == outFile)
						{
							logger.error("no files exist in ICE input folder " + iceFileInLoc);
						}
						else
						{
							sourceType = ReconConstants.ICE_SRC_SYS_NAME;
							logger.info("ice fileName " + outFile.getName());
						}

					}
					else
					{
						logger.error("no files exist at Endur in folder  " + iceFileInLoc);
					}

				}

			}
			else if(inFileName != null && inFileName.startsWith(ReconConstants.ICE_SRC_SYS_DB))
			{
				runDate = StringUtils.substringAfter(inFileName, "_");
				if(null != runDate)
					  runDate = runDate.trim();
				
				sourceType = ReconConstants.ICE_SRC_SYS_DB;
				logger.info("request for loading ice data from DB for runDate: " + runDate);
				
			}
			else
			{
				logger.error("file process request for source system other than Endur or Ice : infile name " + inFileName);
			}

			if(null != outFile)
			{
			  endurOrIceFileMessage = MessageBuilder.withPayload(outFile).setHeader("sourceType", sourceType).build();
			  outFile = null; //reset file name to null to  process next file
			}
			else if( null != runDate)
			{
				endurOrIceFileMessage = MessageBuilder.withPayload(inFile).setHeader("sourceType", sourceType).setHeader("runDate", runDate).build();
				runDate = null; //reset runDate to null
				
			}

		}

		return endurOrIceFileMessage;

	}

}
