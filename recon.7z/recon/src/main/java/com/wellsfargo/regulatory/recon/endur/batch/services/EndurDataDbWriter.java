package com.wellsfargo.regulatory.recon.endur.batch.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.persister.recon.dao.RegRepCommTradeMtermsDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;

/**
 * @author Raji Komatreddy
 */

public class EndurDataDbWriter implements ItemWriter<RegRepCommTradeMterms>, StepExecutionListener
{
	private static Logger logger = Logger.getLogger(EndurDataDbWriter.class.getName());
	private List<RegRepCommTradeMterms> finalFegRepCommTradeMtermsList = new ArrayList<RegRepCommTradeMterms>();

	@Autowired
	private RegRepCommTradeMtermsDao regRepCommTradeMtermsDao;

	@Override
	public void write(List<? extends RegRepCommTradeMterms> regRepCommTradeMtermsList) throws Exception
	{
		logger.info("inside EndurDataDbWriter write method");
		finalFegRepCommTradeMtermsList.addAll(regRepCommTradeMtermsList);

		/*
		 * for(RegRepCommTradeMterms currRegRepCommTradeMterms : regRepCommTradeMtermsList ) {
		 * regRepCommTradeMtermsDao.save(currRegRepCommTradeMterms); }
		 */
		regRepCommTradeMtermsDao.springBatchInsert((List<RegRepCommTradeMterms>) regRepCommTradeMtermsList);
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution)
	{
		// stepExecution.getJobExecution().getExecutionContext().put(ReconConstants.ENDUR_MESSAGES_LIST,
		// finalFegRepCommTradeMtermsList);
		// regRepCommTradeMtermsDao.saveOrUpdateAll(finalFegRepCommTradeMtermsList);

		return null;
	}

	@Override
	public void beforeStep(StepExecution arg0)
	{
		// TODO Auto-generated method stub

	}

}
