package com.wellsfargo.regulatory.recon.dto;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class ReconReportGenerationRequest
{	
	private String reportDate;
	private String source1;
	private String source2;
	private String reconJobStatus;
	private String endurJobStatus;
	private String iceJobStatus;
	
	
	public ReconReportGenerationRequest(String reportDate, String source1, String source2)
	{
		this.reportDate = reportDate;
		this.source1 = source1;
		this.source2 = source2;
	}
	
	public ReconReportGenerationRequest(String reportDate)
	{
		this.reportDate = reportDate;
		
	}
	public ReconReportGenerationRequest()
	{		
		
	}

	public String getReportDate()
	{
		return reportDate;
	}
	public void setReportDate(String reportDate)
	{
		this.reportDate = reportDate;
	}
	public String getSource1()
	{
		return source1;
	}
	public void setSource1(String source1)
	{
		this.source1 = source1;
	}
	public String getSource2()
	{
		return source2;
	}
	public void setSource2(String source2)
	{
		this.source2 = source2;
	}

	public String getReconJobStatus()
	{
		return reconJobStatus;
	}

	public void setReconJobStatus(String reconJobStatus)
	{
		this.reconJobStatus = reconJobStatus;
	}

	public String getEndurJobStatus()
	{
		return endurJobStatus;
	}

	public void setEndurJobStatus(String endurJobStatus)
	{
		this.endurJobStatus = endurJobStatus;
	}

	public String getIceJobStatus()
	{
		return iceJobStatus;
	}

	public void setIceJobStatus(String iceJobStatus)
	{
		this.iceJobStatus = iceJobStatus;
	}

}
