package com.wellsfargo.regulatory.recon.util;

/**
 * 
 * @author Raji Komatreddy
 *
 */
public class ReconConstants
{
	public static final String ENDUR_IN_FILE_LOC = "endurFileLoc";		
	public static final String ENDUR_SRC_SYS_NAME = "Endur";
	public static final String ENDUR_MESSAGES_LIST = "endurMessagesList";
	
	public static final String ICE_SRC_SYS_NAME = "ICE";
	public static final String ICE_IN_FILE_LOC = "iceFileLoc";	
	public static final String ICE_IN_FILE_NAME = "iceFileName";
	
	public static final String ICE_SRC_SYS_DB = "iceDB";
	
	public static final String RECON_REPORT_DATE = "reconReportDate";	
	public static final String RECON_BATCH_ID = "batchID";	
	public static final String RECON_REPORT_ID = "reportID";	
	
	public static final String  WELLS_FARGO=   "Wells Fargo";
	
	public static final String RECON_REPORT_DATEFORMAT=  "yyyy-MM-dd";
	public static final String RECON_REPORT_DATEFORMAT_MMDDYYYY=  "MM/dd/yyyy";
	public static final String RECON_REPORT_DATEFORMAT_UTC  ="yyyy-MM-dd'T'HH:mm:ssX";
	public static final String RECON_REPORT_STATUS_PROCESSING  ="Processing";
	public static final String RECON_REPORT_STATUS_SUCCESS  ="Success";
	public static final String RECON_REPORT_STATUS_NODATA  ="Nodata";
	public static final String RECON_REPORT_STATUS_ERROR  ="Error";
	
	

}
