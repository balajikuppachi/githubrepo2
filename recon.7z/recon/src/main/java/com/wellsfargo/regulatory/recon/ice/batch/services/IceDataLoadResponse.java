package com.wellsfargo.regulatory.recon.ice.batch.services;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepReconReportStatusDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportStatus;
import com.wellsfargo.regulatory.recon.endur.batch.services.EndurDataLoadResponse;
import com.wellsfargo.regulatory.recon.util.ReconConstants;

/**
 * @author Raji Komatreddy
 */
@Component
public class IceDataLoadResponse
{
	@Autowired
	private RegRepReconReportStatusDao regRepReconReportStatusDao;

	private static Logger logger = Logger.getLogger(EndurDataLoadResponse.class.getName());

	public void process(Message<?> message) throws EtdMessageException
	{
		logger.info("inside IceDataLoadResponse: process method");

		String errorString = null;
		Object ipMessage = null;
		JobExecution currJobExecution = null;
		ExitStatus currExitStatus = null;
		RegRepReconReportStatus currRegRepReconReportStatus = null;
		String reportIdStr = null;
		int reportId = 0;
		Date currDate = new Date();

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);
		}

		ipMessage = message.getPayload();

		if (ipMessage instanceof JobExecution)
		{
			currJobExecution = (JobExecution) ipMessage;
			currExitStatus = currJobExecution.getExitStatus();
			
			reportIdStr = currJobExecution.getJobParameters().getString(ReconConstants.RECON_REPORT_ID);
			if(null != regRepReconReportStatusDao)
			{
				if(StringUtils.isNotBlank(reportIdStr) )
				{
					reportId = Integer.parseInt(reportIdStr);
					currRegRepReconReportStatus =  regRepReconReportStatusDao.findByPrimaryKey(reportId);					
				}
				
			}

			if (currExitStatus.getExitCode().equalsIgnoreCase("EXECUTING"))
			{
				logger.info(" Batch job is still running ");

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("COMPLETED"))
			{
				if(null != currRegRepReconReportStatus && null != regRepReconReportStatusDao)
				{
					currRegRepReconReportStatus.setReportStatus(ReconConstants.RECON_REPORT_STATUS_SUCCESS);
					currRegRepReconReportStatus.setUpdateDatetime(currDate);
					regRepReconReportStatusDao.saveOrUpdate(currRegRepReconReportStatus);
				}

				logger.info(" Batch job finished successfully ");

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("FAILED"))
			{
				errorString = currJobExecution.getStepExecutions().toString();
				if(null != currRegRepReconReportStatus && null != regRepReconReportStatusDao)
				{
					currRegRepReconReportStatus.setReportStatus(ReconConstants.RECON_REPORT_STATUS_ERROR);
					currRegRepReconReportStatus.setUpdateDatetime(currDate);
					regRepReconReportStatusDao.saveOrUpdate(currRegRepReconReportStatus);
				}
				logger.error(" Ice Batch job Failed " + currJobExecution.getStepExecutions().toString());
				throw new EtdMessageException("IceDataLoadResponse:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

			}

		}

		logger.info("exiting IceDataLoadResponse: prepEtdRequest method");

	}

}
