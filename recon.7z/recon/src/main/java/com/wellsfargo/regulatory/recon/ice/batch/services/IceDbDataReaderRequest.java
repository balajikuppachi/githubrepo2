package com.wellsfargo.regulatory.recon.ice.batch.services;

/**
 * 
 * @author Raji Komatreddy
 *
 */

public class IceDbDataReaderRequest
{
	private String runDate;
	private String jobName;
	
	
	public IceDbDataReaderRequest(String argJobName, String argRunDate)
	{
		this.jobName = argJobName;
		this.runDate = argRunDate;
	}
	
	public IceDbDataReaderRequest(String argJobName)
	{
		this.jobName = argJobName;
	}
	
	public String getRunDate()
	{
		return runDate;
	}
	public void setRunDate(String runDate)
	{
		this.runDate = runDate;
	}
	public String getJobName()
	{
		return jobName;
	}
	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}

}
