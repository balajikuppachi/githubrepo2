package com.wellsfargo.regulatory.recon.report.services;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.recon.dto.ReconReportGenerationRequest;
import com.wellsfargo.regulatory.recon.util.ReconConstants;

/**
 * 
 * @author Raji Komatreddy
 * This class sends email notification to users once the report generation is complete
 *
 */
@Component
public class ReconReportGenResponseSvc
{
	private static Logger logger = Logger.getLogger(ReconReportGenResponseSvc.class.getName());
	
	@Autowired
	private MailSenderService mailSenderService;
	
	public void process(Message<?> message) throws EtdMessageException
	{
		logger.info("inside ReconReportGenResponseSvc process method" );
		Object ipMessage = null;
		String reconReportStatus = null;
		String reportDate = null;
		String subject = null;
		String msg = null;
		ReconReportGenerationRequest  currReconReportGenerationRequest = null;
		String endurJobStatus = null;
		String iceJobStatus = null;
		
		if(null != message )
		{
			ipMessage = message.getPayload();
			if(ipMessage instanceof ReconReportGenerationRequest)
			{
				currReconReportGenerationRequest = (ReconReportGenerationRequest) ipMessage;
				reconReportStatus = currReconReportGenerationRequest.getReconJobStatus();
				reportDate = currReconReportGenerationRequest.getReportDate();				
				subject = "Commodity Live Trade Recon Report for " + reportDate;
				endurJobStatus = currReconReportGenerationRequest.getEndurJobStatus();
				iceJobStatus  = currReconReportGenerationRequest.getIceJobStatus();
				
				if(StringUtils.isNotBlank(endurJobStatus) && endurJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_SUCCESS) &&
						StringUtils.isNotBlank(iceJobStatus) && iceJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_SUCCESS)	)
				{
					msg    = "Greetings, \n" +
							" Please find recon report for reporting date " + reportDate + " at below shared location.\n" +

						//	 "\\" + "\\samba.capmark.funb.com\\shared\\deriv\\sdr\\reports\\EOD\\Commodity\\Recon_Report\\CommodityTradeRecon_" + reportDate + ".xlsx" ;		
					
					 "\\" + "\\ncslnhf501.wellsfargo.com\\1STRreports_prod\\reports\\EOD\\Commodity\\Recon_Report\\CommodityTradeRecon_" + reportDate + ".xlsx" ;
				}
				else if(StringUtils.isNotBlank(endurJobStatus) && endurJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_NODATA))
				{
					msg    = "Greetings, \n" +
							" Endur file data is not available for report date:  " + reportDate + "  please contact SDR support for details" ;	
					reconReportStatus = ReconConstants.RECON_REPORT_STATUS_NODATA;
					
				}
				else if(StringUtils.isNotBlank(endurJobStatus) && endurJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_ERROR))
				{
					msg    = "Greetings, \n" +
							" Exception occurred while processing Endur file data: for report date " + reportDate + "  please contact SDR support for details" ;	
					reconReportStatus = ReconConstants.RECON_REPORT_STATUS_ERROR;
					
				}
				else if(StringUtils.isNotBlank(iceJobStatus) && iceJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_NODATA))
				{
					msg    = "Greetings, \n" +
							" Ice file data is not available for report date:  " + reportDate + "  please contact SDR support for details" ;	
					reconReportStatus = ReconConstants.RECON_REPORT_STATUS_NODATA;
					
				}
				else if(StringUtils.isNotBlank(iceJobStatus) && iceJobStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_ERROR))
				{
					msg    = "Greetings, \n" +
							" Exception occurred while processing ICE file data: for report date " + reportDate + "  please contact SDR support for details" ;	
					reconReportStatus = ReconConstants.RECON_REPORT_STATUS_ERROR;
					
				}				

				
				logger.info("Recon report job status "  + reconReportStatus);
				logger.info("Recon report ran for reportDate:  "  + reportDate);
				logger.info("Recon report subject  "  + subject);
				logger.info("Recon report msg  "  + msg);
				
				try
				{
					if(null != mailSenderService && StringUtils.isNotBlank(reconReportStatus) && 
						(    reconReportStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_SUCCESS) || 
							 reconReportStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_NODATA) ||
							 reconReportStatus.equalsIgnoreCase(ReconConstants.RECON_REPORT_STATUS_ERROR)     ))
						mailSenderService.sendReconReportMail(subject, msg);			
				
				}
				catch(Exception exe)
				{
					logger.error("exception occurred inside ReconReportGenResponseSvc: while sending email notification " + exe.getMessage());
				}
			
			}
		}
		
		logger.info("finished recon report generation process successfully" );
	}

}
