package com.wellsfargo.regulatory.recon.report.services;

import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
// import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.recon.dao.RegRepReconReportDataDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportData;
import com.wellsfargo.regulatory.recon.util.ReconConstants;

/**
 * @author Raji Komatreddy
 */
@Component
public class ReconReportGeneratorSvc
{

	@Autowired
	private RegRepReconReportDataDao regRepReconReportDataDao;

	@Value("${recon.report.out.file.path}")
	private String reportOutDir;

	private static Logger logger = Logger.getLogger(ReconReportGeneratorSvc.class.getName());

	public String generateReport(String reportDate, String source1, String source2)
	{
		logger.info("inside ReconReportGeneratorSvc generateReport method");

		int currRow = 0;

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = reportDate;

		Date reportdate = null;
		try
		{
			reportdate = dateFormat.parse(dateString);
		}
		catch (ParseException e)
		{
			logger.error("Exception occurred while parsing reportDate " + e.getMessage());
		}

		List<RegRepReconReportData> regRepReconReportDataList = regRepReconReportDataDao.getReconReportData(reportdate, source1, source2);
		if (null != regRepReconReportDataList && regRepReconReportDataList.size() > 0)
		{

			List<RegRepReconReportData> category1RegRepReconReportDataList = new ArrayList<RegRepReconReportData>();
			List<RegRepReconReportData> category2RegRepReconReportDataList = new ArrayList<RegRepReconReportData>();
			List<RegRepReconReportData> category3RegRepReconReportDataList = new ArrayList<RegRepReconReportData>();
			List<RegRepReconReportData> category4RegRepReconReportDataList = new ArrayList<RegRepReconReportData>();
			List<RegRepReconReportData> category5RegRepReconReportDataList = new ArrayList<RegRepReconReportData>();

			String category = null;
			for (RegRepReconReportData currRegRepReconReportData : regRepReconReportDataList)
			{
				if (null != currRegRepReconReportData)
				{
					category = currRegRepReconReportData.getCategory();
					if (StringUtils.isNotBlank(category))
					{
						if (category.equalsIgnoreCase("1")) category1RegRepReconReportDataList.add(currRegRepReconReportData);
						if (category.equalsIgnoreCase("2")) category2RegRepReconReportDataList.add(currRegRepReconReportData);
						if (category.equalsIgnoreCase("3")) category3RegRepReconReportDataList.add(currRegRepReconReportData);
						if (category.equalsIgnoreCase("4")) category4RegRepReconReportDataList.add(currRegRepReconReportData);
						if (category.equalsIgnoreCase("5")) category5RegRepReconReportDataList.add(currRegRepReconReportData);

					}

				}
			}

			// clear actual List got from DB call
			regRepReconReportDataList.clear();

			int totalMatchCnt = category1RegRepReconReportDataList.size() + category2RegRepReconReportDataList.size();
			int potentialMatchCnt = category3RegRepReconReportDataList.size();
			int unMatchsource1 = category4RegRepReconReportDataList.size();
			int unMatchsource2 = category5RegRepReconReportDataList.size();
			int totalTransactions1 = totalMatchCnt + potentialMatchCnt + unMatchsource1;
			int totalTransactions2 = totalMatchCnt + potentialMatchCnt + unMatchsource2;

			logger.info("number of catoegory 1 atchCnt : " + category1RegRepReconReportDataList.size());
			logger.info("number of catoegory 2 matchCnt :" + category2RegRepReconReportDataList.size());
			logger.info("number of totalMatchCnt : " + totalMatchCnt);
			logger.info("number of potentialMatchCnt : " + potentialMatchCnt);
			logger.info("number of unMatchsource1 : " + unMatchsource1);
			logger.info("number of unMatchsource2 : " + unMatchsource2);

			SXSSFWorkbook wb = new SXSSFWorkbook(100);  // or new HSSFWorkbook();

			// center column cellstyle
			CellStyle centerColumncellStyle = wb.createCellStyle();
			centerColumncellStyle.setFillForegroundColor(IndexedColors.INDIGO.index);
			centerColumncellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			centerColumncellStyle.setBorderLeft(CellStyle.BORDER_THIN);
			centerColumncellStyle.setBorderRight(CellStyle.BORDER_THIN);

			// data population style
			CellStyle populateDatacellStyle = wb.createCellStyle();
			populateDatacellStyle.setAlignment(CellStyle.ALIGN_GENERAL);
			populateDatacellStyle.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
			populateDatacellStyle.setBorderBottom(CellStyle.BORDER_THIN);
			populateDatacellStyle.setBottomBorderColor(IndexedColors.BLUE_GREY.getIndex());
			populateDatacellStyle.setBorderRight(CellStyle.BORDER_THIN);
			populateDatacellStyle.setRightBorderColor(IndexedColors.BLUE_GREY.getIndex());

			// data population style for category2
			CellStyle populateDatacellForCat2Style = wb.createCellStyle();
			populateDatacellForCat2Style.setAlignment(CellStyle.ALIGN_GENERAL);
			populateDatacellForCat2Style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
			populateDatacellForCat2Style.setBorderBottom(CellStyle.BORDER_THIN);
			populateDatacellForCat2Style.setBottomBorderColor(IndexedColors.BLUE_GREY.getIndex());
			populateDatacellForCat2Style.setBorderRight(CellStyle.BORDER_THIN);
			populateDatacellForCat2Style.setRightBorderColor(IndexedColors.BLUE_GREY.getIndex());
			populateDatacellForCat2Style.setFillForegroundColor(IndexedColors.CORAL.index);
			populateDatacellForCat2Style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			XSSFCellStyle unmatchStyle = (XSSFCellStyle) wb.createCellStyle();
			unmatchStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 199, 206)));
			unmatchStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
			unmatchStyle.setAlignment(CellStyle.ALIGN_GENERAL);
			unmatchStyle.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
			unmatchStyle.setBorderBottom(CellStyle.BORDER_THIN);
			unmatchStyle.setBottomBorderColor(IndexedColors.BLUE_GREY.getIndex());
			unmatchStyle.setBorderRight(CellStyle.BORDER_THIN);
			unmatchStyle.setRightBorderColor(IndexedColors.BLUE_GREY.getIndex());
			XSSFFont xSSFFont = (XSSFFont) wb.createFont();
			xSSFFont.setColor(new XSSFColor(new java.awt.Color(156, 0, 6)));
			unmatchStyle.setFont(xSSFFont);

			Sheet sheet = wb.createSheet("Summary");
			Sheet sheet_unMatch = wb.createSheet("UnMatched");
			Sheet sheet_pMatch = wb.createSheet("PotentiallyMatched");
			Sheet sheet_Match = wb.createSheet("Matched");

			formatSheet(sheet);
			formatSheet(sheet_unMatch);
			formatSheet(sheet_pMatch);
			formatSheet(sheet_Match);

			prepareFirstRow(wb, sheet, dateString, centerColumncellStyle);

			// prepare summary header

			Row row1 = sheet.createRow((short) 1);
			formatCenterColumn(wb, row1, (short) 11, centerColumncellStyle);
			Row row2 = sheet.createRow((short) 2);
			prepareSummaryHeader(wb, row2, (short) 8, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Total Transactions");
			prepareSummaryHeader(wb, row2, (short) 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(totalTransactions1));
			formatCenterColumn(wb, row2, (short) 11, centerColumncellStyle);

			prepareSummaryHeader(wb, row2, (short) 19, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Total Transactions");
			prepareSummaryHeader(wb, row2, (short) 20, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(totalTransactions2));

			Row row3 = sheet.createRow((short) 3);
			prepareSummaryHeader(wb, row3, (short) 8, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Matched Transactions");
			prepareSummaryHeader(wb, row3, (short) 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(totalMatchCnt));
			formatCenterColumn(wb, row3, (short) 11, centerColumncellStyle);

			prepareSummaryHeader(wb, row3, (short) 19, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Matched Transactions");
			prepareSummaryHeader(wb, row3, (short) 20, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(totalMatchCnt));

			Row row4 = sheet.createRow((short) 4);
			prepareSummaryHeader(wb, row4, (short) 8, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Potentially Matched Transactions");
			prepareSummaryHeader(wb, row4, (short) 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(potentialMatchCnt));
			formatCenterColumn(wb, row4, (short) 11, centerColumncellStyle);

			prepareSummaryHeader(wb, row4, (short) 19, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Potentially Matched Transactions");
			prepareSummaryHeader(wb, row4, (short) 20, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(potentialMatchCnt));

			Row row5 = sheet.createRow((short) 5);
			prepareSummaryHeader(wb, row5, (short) 8, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Unmatched Transactions");
			prepareSummaryHeader(wb, row5, (short) 9, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(unMatchsource1));
			formatCenterColumn(wb, row5, (short) 11, centerColumncellStyle);

			prepareSummaryHeader(wb, row5, (short) 19, CellStyle.ALIGN_RIGHT, CellStyle.VERTICAL_BOTTOM, "Unmatched Transactions");
			prepareSummaryHeader(wb, row5, (short) 20, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_BOTTOM, Integer.toString(unMatchsource2));

			prepareSummaryHeaderLastRow(wb, sheet);
			// unmatched transactions section header

			prepareFirstRow(wb, sheet_unMatch, dateString, centerColumncellStyle);

			currRow = 1;
			Row unMach_row1 = sheet_unMatch.createRow((short) currRow);
			unMach_row1.setHeightInPoints(20);

			CellRangeAddress unmatchedHeader = new CellRangeAddress(1, 1, 0, 22);
			RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, unmatchedHeader, sheet_unMatch, wb);
			RegionUtil.setBorderTop(CellStyle.BORDER_THIN, unmatchedHeader, sheet_unMatch, wb);
			sheet_unMatch.addMergedRegion(unmatchedHeader);
			prepareSectionHeader(wb, unMach_row1, (short) 0, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, "Unmatched Transactions");

			currRow = currRow + 1;

			// unmatched transactions section sub header
			createSectionSubHeader(wb, sheet_unMatch, currRow, centerColumncellStyle);
			currRow = currRow + 1;

			// populate unmatched transactions data from DB from this row onwards, row number
			// changes as
			// per count of
			// transactions in DB
			// currRow = 9;
			int rowNumAfterUnMatcheTransEndur = 0;
			int rowNumAfterUnMatcheTransIce = 0;

			if (null != category4RegRepReconReportDataList)
			{
				// populate Endur unmatched transactions in excel sheet
				rowNumAfterUnMatcheTransEndur = populateDataFromList(category4RegRepReconReportDataList, wb, sheet_unMatch, currRow, 0, populateDatacellStyle, centerColumncellStyle);
				currRow = rowNumAfterUnMatcheTransEndur;

				// clear data in List after writing to excel
				category4RegRepReconReportDataList.clear();
			}
			if (null != category5RegRepReconReportDataList)
			{
				// populate ICE unmatched transactions in excel sheet
				rowNumAfterUnMatcheTransIce = populateDataFromList(category5RegRepReconReportDataList, wb, sheet_unMatch, currRow, 0, populateDatacellStyle, centerColumncellStyle);
				currRow = rowNumAfterUnMatcheTransIce;

				// clear data in List after writing to excel
				category5RegRepReconReportDataList.clear();
			}

			// populate potentially matched transactions in different sheet

			prepareFirstRow(wb, sheet_pMatch, dateString, centerColumncellStyle);
			currRow = 1;

			// Potentially Matched Transactions section header
			Row potentiallyMatchedHeaderRow = sheet_pMatch.createRow(currRow);
			potentiallyMatchedHeaderRow.setHeightInPoints(20);
			CellRangeAddress pmatchedHeader = new CellRangeAddress(currRow, currRow, 0, 22);
			RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, pmatchedHeader, sheet_pMatch, wb);
			RegionUtil.setBorderTop(CellStyle.BORDER_THIN, pmatchedHeader, sheet_pMatch, wb);
			sheet_pMatch.addMergedRegion(pmatchedHeader);
			prepareSectionHeader(wb, potentiallyMatchedHeaderRow, (short) 0, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, "Potentially Matched Transactions");

			currRow = currRow + 1;

			// Potentially Matched Transactions transactions section sub header
			createSectionSubHeader(wb, sheet_pMatch, currRow, centerColumncellStyle);

			currRow = currRow + 1;

			if (null != category3RegRepReconReportDataList)
			{
				// populate matched transactions in excel sheet with USI and sender trade ref ID
				currRow = populateDataFromListForPotentialMath(category3RegRepReconReportDataList, wb, sheet_pMatch, currRow, 0, unmatchStyle, centerColumncellStyle, populateDatacellStyle);

				category3RegRepReconReportDataList.clear();

			}

			// populate matched transactions in different sheet
			// Matched Transactions section header
			prepareFirstRow(wb, sheet_Match, dateString, centerColumncellStyle);
			currRow = 1;
			Row matchedTransHeaderRow = sheet_Match.createRow(currRow);
			matchedTransHeaderRow.setHeightInPoints(20);
			CellRangeAddress matchedHeader = new CellRangeAddress(currRow, currRow, 0, 22);
			RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, matchedHeader, sheet_Match, wb);
			RegionUtil.setBorderTop(CellStyle.BORDER_THIN, matchedHeader, sheet_Match, wb);
			sheet_Match.addMergedRegion(matchedHeader);
			prepareSectionHeader(wb, matchedTransHeaderRow, (short) 0, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, "Matched Transactions");

			currRow = currRow + 1;
			createSectionSubHeader(wb, sheet_Match, currRow, centerColumncellStyle);

			currRow = currRow + 1;

			if (null != category1RegRepReconReportDataList)
			{
				// populate matched transactions in excel sheet with USI and sender trade ref ID
				currRow = populateDataFromList(category1RegRepReconReportDataList, wb, sheet_Match, currRow, 0, populateDatacellStyle, centerColumncellStyle);

				category1RegRepReconReportDataList.clear();

			}
			if (null != category2RegRepReconReportDataList)
			{
				// populate Endur matched transactions in excel sheet
				populateDataFromList(category2RegRepReconReportDataList, wb, sheet_Match, currRow, 0, populateDatacellStyle, centerColumncellStyle);

				category2RegRepReconReportDataList.clear();
			}

			// Write the output to a file
			FileOutputStream fileOut;
			try
			{
				fileOut = new FileOutputStream(reportOutDir + "CommodityTradeRecon_" + reportDate + ".xlsx");
				wb.write(fileOut);
				fileOut.close();
				wb.dispose();
				logger.info("finished writing data into excel sheet");
			}
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				logger.error("Exception occurred inside ReconReportGeneratorSvc " + e.getMessage());
				return ReconConstants.RECON_REPORT_STATUS_ERROR;

			}

			logger.info("exiting ReconReportGeneratorSvc generateReport method");
			return ReconConstants.RECON_REPORT_STATUS_SUCCESS;

		}
		else
		{
			logger.info("There is no data in DB for report date " + reportdate);
			return ReconConstants.RECON_REPORT_STATUS_NODATA;

		}

	}

	private void formatSheet(Sheet sheet)
	{
		sheet.setDisplayGridlines(false);
		sheet.setZoom(17, 20);
		for (int i = 0; i < 11; i++)
		{
			// column width is set in units of 1/256th of a character width
			sheet.setColumnWidth(i, 256 * 15);
		}
		sheet.setColumnWidth(11, 256 * 2);
		for (int i = 12; i < 23; i++)
		{
			sheet.setColumnWidth(i, 256 * 15);
		}

	}

	private void prepareFirstRow(Workbook wb, Sheet sheet, String dateString, CellStyle centerColumncellStyle)
	{
		Row row = sheet.createRow((short) 0);
		row.setHeightInPoints(30);

		// int firstRow, int lastRow, int firstCol, int lastCol
		CellRangeAddress firstHeader = new CellRangeAddress(0, 0, 0, 10);
		RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, firstHeader, sheet, wb);
		RegionUtil.setBorderTop(CellStyle.BORDER_THIN, firstHeader, sheet, wb);

		CellRangeAddress secondHeader = new CellRangeAddress(0, 0, 12, 22);
		RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, secondHeader, sheet, wb);
		RegionUtil.setBorderTop(CellStyle.BORDER_THIN, secondHeader, sheet, wb);

		sheet.addMergedRegion(firstHeader);
		sheet.addMergedRegion(secondHeader);

		formatFirstRow(wb, row, (short) 0, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, "ENDUR OPEN TRADES \n" + dateString);
		formatFirstRow(wb, row, (short) 12, CellStyle.ALIGN_CENTER, CellStyle.VERTICAL_BOTTOM, "ICE TRADE VALUT OPEN TRADES \n" + dateString);
		formatCenterColumn(wb, row, (short) 11, centerColumncellStyle);

	}

	private void formatFirstRow(Workbook wb, Row row, short column, short halign, short valign, String displayText)
	{
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = wb.createCellStyle();
		cellStyle.setAlignment(halign);
		cellStyle.setVerticalAlignment(valign);
		cellStyle.setFillForegroundColor(IndexedColors.YELLOW.index);
		cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

		cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		cellStyle.setBorderRight(CellStyle.BORDER_THIN);
		cellStyle.setBorderTop(CellStyle.BORDER_THIN);
		cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());

		cellStyle.setWrapText(true);
		Font xSSFFont = wb.createFont();
		xSSFFont.setFontName(HSSFFont.FONT_ARIAL);
		xSSFFont.setFontHeightInPoints((short) 12);
		xSSFFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		xSSFFont.setItalic(true);
		xSSFFont.setColor(HSSFColor.BLACK.index);
		cellStyle.setFont(xSSFFont);

		cell.setCellStyle(cellStyle);
	}

	private void formatCenterColumn(Workbook wb, Row row, short column, CellStyle centerColumnsStyle)
	{
		Cell cell = row.createCell(column);
		CellStyle cellStyle = centerColumnsStyle;
		cell.setCellStyle(cellStyle);
	}

	private void prepareSummaryHeader(Workbook wb, Row row, short column, short halign, short valign, String displayText)
	{
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = wb.createCellStyle();
		cellStyle.setAlignment(halign);
		cellStyle.setVerticalAlignment(valign);

		Font xSSFFont = wb.createFont();
		xSSFFont.setFontName(HSSFFont.FONT_ARIAL);
		xSSFFont.setFontHeightInPoints((short) 12);
		xSSFFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		xSSFFont.setColor(HSSFColor.BLACK.index);
		cellStyle.setFont(xSSFFont);

		cell.setCellStyle(cellStyle);

	}

	private void prepareSummaryHeaderLastRow(Workbook wb, Sheet sheet)
	{
		CellRangeAddress summaryLastRow = new CellRangeAddress(5, 5, 0, 22);

		RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, summaryLastRow, sheet, wb);

	}

	private void prepareSectionHeader(Workbook wb, Row row, short column, short halign, short valign, String displayText)
	{
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = wb.createCellStyle();
		cellStyle.setAlignment(halign);
		cellStyle.setVerticalAlignment(valign);
		cellStyle.setFillForegroundColor(IndexedColors.ORANGE.index);
		cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

		cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		cellStyle.setBorderRight(CellStyle.BORDER_THIN);
		cellStyle.setBorderTop(CellStyle.BORDER_THIN);
		cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());

		Font xSSFFont = wb.createFont();
		xSSFFont.setFontName(HSSFFont.FONT_ARIAL);
		xSSFFont.setFontHeightInPoints((short) 12);
		xSSFFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		xSSFFont.setColor(HSSFColor.BLACK.index);
		cellStyle.setFont(xSSFFont);

		cell.setCellStyle(cellStyle);

	}

	private void prepareSectionSubHeader(Workbook wb, Row row, short column, short halign, short valign, String displayText)
	{
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = wb.createCellStyle();
		cellStyle.setAlignment(halign);
		cellStyle.setVerticalAlignment(valign);
		cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.index);
		cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		cellStyle.setBorderRight(CellStyle.BORDER_THIN);
		cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());

		cell.setCellStyle(cellStyle);

	}

	private void populateData(Workbook wb, Row row, int column, short halign, short valign, String displayText, CellStyle dataStyle)
	{
		if ("null".equalsIgnoreCase(displayText)) displayText = null;
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = dataStyle;
		cell.setCellStyle(cellStyle);
	}

	private void populateDataCategory2Data(Workbook wb, Row row, int column, short halign, short valign, String displayText, CellStyle dataStyle)
	{
		if ("null".equalsIgnoreCase(displayText)) displayText = null;
		CreationHelper ch = wb.getCreationHelper();
		Cell cell = row.createCell(column);
		cell.setCellValue(ch.createRichTextString(displayText));
		CellStyle cellStyle = dataStyle;
		cell.setCellStyle(cellStyle);
	}

	private void createSectionSubHeader(Workbook wb, Sheet sheet, int argRowNum, CellStyle centerColumncellStyle)
	{
		Row transSubHeaderRow = sheet.createRow(argRowNum);
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 0, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Trade Date");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 1, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Start Date");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 2, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "End Date");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 3, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Trade ID");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 4, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Sender Trade Ref ID");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 5, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "USI");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 6, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Our Name");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 7, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Our LEI");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 8, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Cpty Name");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 9, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Cpty LEI");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 10, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Reporting Party");

		formatCenterColumn(wb, transSubHeaderRow, (short) 11, centerColumncellStyle);

		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 12, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Trade Date");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 13, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Start Date");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 14, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "End Date");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 15, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Trade ID");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 16, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Sender Trade Ref ID");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 17, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "USI");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 18, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Our Name");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 19, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Our LEI");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 20, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Cpty Name");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 21, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Cpty LEI");
		prepareSectionSubHeader(wb, transSubHeaderRow, (short) 22, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, "Reporting Party");

	}

	private int populateDataFromList(List<RegRepReconReportData> transactionsList, Workbook wb, Sheet sheet, int argRowNum, int argColumNum, CellStyle dataStyle, CellStyle centerColumnsStyle)
	{
		int currentRow = argRowNum;
		int currColumn = argColumNum;
		if (null != transactionsList)
		{

			for (RegRepReconReportData currRegRepReconReportData : transactionsList)
			{
				Row rowActive = sheet.getRow(currentRow);
				if (rowActive == null)
				{
					rowActive = sheet.createRow(currentRow);

				}

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_date1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getStart_date1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getMaturity_date1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_id1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getSender_trade_ref_id1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getUsi1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurName1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurLEI1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyName1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyLEI1(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getRp1(), dataStyle);
				currColumn = currColumn + 2;

				formatCenterColumn(wb, rowActive, (short) 11, centerColumnsStyle);

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_date2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getStart_date2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getMaturity_date2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_id2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getSender_trade_ref_id2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getUsi2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurName2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurLEI2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyName2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyLEI2(), dataStyle);
				currColumn++;
				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getRp2(), dataStyle);

				currColumn = argColumNum;
				currentRow = currentRow + 1;

			}

		}

		return currentRow;

	}

	private int populateDataFromListForPotentialMath(List<RegRepReconReportData> transactionsList, Workbook wb, Sheet sheet, int argRowNum, int argColumNum, CellStyle populateDatacellForCat2Style,
	        CellStyle centerColumnsStyle, CellStyle dataStyle)
	{
		int currentRow = argRowNum;
		int currColumn = argColumNum;
		if (null != transactionsList)
		{

			for (RegRepReconReportData currRegRepReconReportData : transactionsList)
			{
				Row rowActive = sheet.getRow(currentRow);
				if (rowActive == null)
				{
					rowActive = sheet.createRow(currentRow);

				}

				if (null != currRegRepReconReportData.getTrade_date1() && currRegRepReconReportData.getTrade_date1().equalsIgnoreCase(currRegRepReconReportData.getTrade_date2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_date1(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_date1(), populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getStart_date1() && currRegRepReconReportData.getStart_date1().equalsIgnoreCase(currRegRepReconReportData.getStart_date2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getStart_date1(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getStart_date1(), populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getMaturity_date1() && currRegRepReconReportData.getMaturity_date1().equalsIgnoreCase(currRegRepReconReportData.getMaturity_date2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getMaturity_date1(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getMaturity_date1(),
					        populateDatacellForCat2Style);
					currColumn++;
				}

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_id1(), dataStyle);
				currColumn++;

				if (null != currRegRepReconReportData.getSender_trade_ref_id1()
				        && currRegRepReconReportData.getSender_trade_ref_id1().equalsIgnoreCase(currRegRepReconReportData.getSender_trade_ref_id2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getSender_trade_ref_id1(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getSender_trade_ref_id1(),
					        populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getUsi1() && currRegRepReconReportData.getUsi1().equalsIgnoreCase(currRegRepReconReportData.getUsi2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getUsi1(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getUsi1(), populateDatacellForCat2Style);
					currColumn++;
				}

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurName1(), dataStyle);
				currColumn++;

				if (null != currRegRepReconReportData.getOurLEI1() && currRegRepReconReportData.getOurLEI1().equalsIgnoreCase(currRegRepReconReportData.getOurLEI2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurLEI1(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurLEI1(), populateDatacellForCat2Style);
					currColumn++;
				}

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyName1(), dataStyle);
				currColumn++;

				if (null != currRegRepReconReportData.getCptyLEI1() && currRegRepReconReportData.getCptyLEI1().equalsIgnoreCase(currRegRepReconReportData.getCptyLEI2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyLEI1(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyLEI1(), populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getRp1() && currRegRepReconReportData.getRp1().equalsIgnoreCase(currRegRepReconReportData.getRp2()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getRp1(), dataStyle);
				}
				else
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getRp1(), populateDatacellForCat2Style);
				}

				currColumn = currColumn + 2;

				formatCenterColumn(wb, rowActive, (short) 11, centerColumnsStyle);

				if (null != currRegRepReconReportData.getTrade_date2() && currRegRepReconReportData.getTrade_date2().equalsIgnoreCase(currRegRepReconReportData.getTrade_date1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_date2(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_date2(), populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getStart_date2() && currRegRepReconReportData.getStart_date2().equalsIgnoreCase(currRegRepReconReportData.getStart_date1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getStart_date2(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getStart_date2(), populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getMaturity_date2() && currRegRepReconReportData.getMaturity_date2().equalsIgnoreCase(currRegRepReconReportData.getMaturity_date1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getMaturity_date2(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getMaturity_date2(),
					        populateDatacellForCat2Style);
					currColumn++;
				}

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getTrade_id2(), dataStyle);
				currColumn++;

				if (null != currRegRepReconReportData.getSender_trade_ref_id2()
				        && currRegRepReconReportData.getSender_trade_ref_id2().equalsIgnoreCase(currRegRepReconReportData.getSender_trade_ref_id1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getSender_trade_ref_id2(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getSender_trade_ref_id2(),
					        populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getUsi2() && currRegRepReconReportData.getUsi2().equalsIgnoreCase(currRegRepReconReportData.getUsi1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getUsi2(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getUsi2(), populateDatacellForCat2Style);
					currColumn++;
				}

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurName2(), dataStyle);
				currColumn++;

				if (null != currRegRepReconReportData.getOurLEI2() && currRegRepReconReportData.getOurLEI2().equalsIgnoreCase(currRegRepReconReportData.getOurLEI1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurLEI2(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getOurLEI2(), populateDatacellForCat2Style);
					currColumn++;
				}

				populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyName2(), dataStyle);
				currColumn++;

				if (null != currRegRepReconReportData.getCptyLEI2() && currRegRepReconReportData.getCptyLEI2().equalsIgnoreCase(currRegRepReconReportData.getCptyLEI1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyLEI2(), dataStyle);
					currColumn++;
				}
				else
				{
					populateDataCategory2Data(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getCptyLEI2(), populateDatacellForCat2Style);
					currColumn++;
				}

				if (null != currRegRepReconReportData.getRp2() && currRegRepReconReportData.getRp2().equalsIgnoreCase(currRegRepReconReportData.getRp1()))
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getRp2(), dataStyle);
				}
				else
				{
					populateData(wb, rowActive, currColumn, CellStyle.ALIGN_GENERAL, CellStyle.VERTICAL_BOTTOM, currRegRepReconReportData.getRp2(), populateDatacellForCat2Style);
				}

				currColumn = argColumNum;
				currentRow = currentRow + 1;

			}

		}

		return currentRow;

	}

	public void setRegRepReconReportDataDao(RegRepReconReportDataDao regRepReconReportDataDao)
	{
		this.regRepReconReportDataDao = regRepReconReportDataDao;
	}

}
