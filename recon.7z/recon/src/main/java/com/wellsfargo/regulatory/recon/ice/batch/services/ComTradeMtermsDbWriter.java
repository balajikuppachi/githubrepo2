package com.wellsfargo.regulatory.recon.ice.batch.services;

import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.persister.recon.dao.RegRepCommTradeMtermsDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;
import com.wellsfargo.regulatory.recon.endur.batch.services.EndurDataDbWriter;
/**
 * 
 * @author Raji Komatreddy
 *
 */

public class ComTradeMtermsDbWriter implements ItemWriter<RegRepCommTradeMterms>
{
	private static Logger logger = Logger.getLogger(EndurDataDbWriter.class.getName());
	
	@Autowired
	private RegRepCommTradeMtermsDao regRepCommTradeMtermsDao;
	
	@SuppressWarnings("unchecked")
    @Override
    public void write(List<? extends RegRepCommTradeMterms> regRepCommTradeMtermsList) throws Exception
    {

		logger.info("inside ComTradeMtermsDbWriter write method");		
		List<RegRepCommTradeMterms> currColliectionList = (List<RegRepCommTradeMterms>) regRepCommTradeMtermsList;

		regRepCommTradeMtermsDao.springBatchInsert(currColliectionList);		

		logger.info("exiting ComTradeMtermsDbWriter write method");

	
	    
    }

}
