package com.wellsfargo.regulatory.recon.ice.batch.services;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;
import com.wellsfargo.regulatory.recon.endur.batch.services.EndurDataProcessor;
import com.wellsfargo.regulatory.recon.util.ReconConstants;
import com.wellsfargo.regulatory.recon.util.ReconUtil;

/**
 * @author Raji Komatreddy
 */

public class IceDataProcessor implements ItemProcessor<RegRepCommTradeMterms, RegRepCommTradeMterms>, StepExecutionListener
{
	private static Logger logger = Logger.getLogger(EndurDataProcessor.class.getName());
	private String batchId = null;
	private String reportDateStr = null;
	private Date reportDate = null;

	@Override
	public RegRepCommTradeMterms process(RegRepCommTradeMterms regRepCommTradeMterms) throws Exception
	{

		// logger.debug("inside  IceDataProcessor: process method");
		
		// batch Id should be retrieved from DB
		if (null != batchId) regRepCommTradeMterms.setBatchId(Integer.parseInt(batchId));

		// this date should be retraced from file eg: fileName -TVTrades20150204.csv
		regRepCommTradeMterms.setReportDate(reportDate);

		// logger.debug("exiting  IceDataProcessor: process method; RegRepCommTradeMterms record:  "
		// + regRepCommTradeMterms.toString());
		return regRepCommTradeMterms;
	}

	@Override
	public ExitStatus afterStep(StepExecution arg0)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeStep(StepExecution stepExecution)
	{
		batchId = stepExecution.getJobParameters().getString(ReconConstants.RECON_BATCH_ID);
		reportDateStr = stepExecution.getJobParameters().getString(ReconConstants.RECON_REPORT_DATE);
		if (null != reportDateStr)
		{
			reportDate = ReconUtil.formatYYYYMMDDtoDate(reportDateStr);

		}

	}

}
