package com.wellsfargo.regulatory.recon.ice.batch.services;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;
import com.wellsfargo.regulatory.recon.util.ReconConstants;
import com.wellsfargo.regulatory.recon.util.ReconUtil;

/**
 * @author Raji Komatreddy
 */
public class IceDatafieldSetMapper implements FieldSetMapper<RegRepCommTradeMterms>
{

	private static Logger logger = Logger.getLogger(IceDatafieldSetMapper.class.getName());

	@Override
	public RegRepCommTradeMterms mapFieldSet(FieldSet fieldSet) throws BindException
	{
		RegRepCommTradeMterms currRegRepCommTradeMterms = new RegRepCommTradeMterms();

		String currBuyer = null;
		String currSeller = null;
		String currBuyerParent = null;
		String currSellerParent = null;
		String currUSReportingEntityPETData = null;
		String currUSReportingEntityContinuationData = null;
		String currBuyerSenderTradeRefId = null;
		String currSellerSenderTradeRefId = null;
		String currBuyerLEI = null;
		String currSellerLEI = null;
		String party1name = null;
		String party2name = null;
		String party1Lei = null;
		String party2Lei = null;
		String senderTradeRefId = null;
		String firstReportedSDR = null; 
		boolean buerFlag = false;
		boolean sellerFlag = false;

		byte reportingParty = 0;
		byte reportable = 0;

		Date currDate = new Date();
		currRegRepCommTradeMterms.setSourceSystem(ReconConstants.ICE_SRC_SYS_NAME);

		// TO-DO change with proper value - not null field in DB
		//currRegRepCommTradeMterms.setTradeId("123");
		// currRegRepCommTradeMterms.setTradeVersion(fieldSet.readString("tran_num"));
		currRegRepCommTradeMterms.setProductId(fieldSet.readString("TVProductID"));
		currRegRepCommTradeMterms.setProductName(fieldSet.readString("TVProductName"));
		//currRegRepCommTradeMterms.setTradeDate(ReconUtil.formatStrDateOnly(fieldSet.readString("TradeDate")));
		//currRegRepCommTradeMterms.setEffectiveDate(ReconUtil.formatStrDateOnly(fieldSet.readString("TradeDate")));
		//currRegRepCommTradeMterms.setMaturityDate(ReconUtil.formatStrDateOnly(fieldSet.readString("TradeDate")));
		currRegRepCommTradeMterms.setTradeDate(fieldSet.readDate("TradeDate", ReconConstants.RECON_REPORT_DATEFORMAT, null));
		currRegRepCommTradeMterms.setEffectiveDate(fieldSet.readDate("StartDate", ReconConstants.RECON_REPORT_DATEFORMAT, null));
		currRegRepCommTradeMterms.setMaturityDate(fieldSet.readDate("EndDate", ReconConstants.RECON_REPORT_DATEFORMAT, null));
		currRegRepCommTradeMterms.setTlcEvent(fieldSet.readString("LifecycleEventStatus"));
		 currRegRepCommTradeMterms.setTlcEventDatetime(fieldSet.readDate("LifecycleEventTimestamp", ReconConstants.RECON_REPORT_DATEFORMAT_UTC, null));

		currBuyer = fieldSet.readString("Buyer");
		currSeller = fieldSet.readString("Seller");
		currBuyerParent = fieldSet.readString("BuyerParent");
		currSellerParent = fieldSet.readString("SellerParent");
		currUSReportingEntityPETData = fieldSet.readString("USReportingEntityPETData");
		currUSReportingEntityContinuationData = fieldSet.readString("USReportingEntityContinuationData");
		currBuyerLEI = fieldSet.readString("BuyerLEI");
		currSellerLEI = fieldSet.readString("SellerLEI");
		currBuyerSenderTradeRefId = fieldSet.readString("BuyerSenderTradeRefId");
		currSellerSenderTradeRefId = fieldSet.readString("SellerSenderTradeRefId");
		firstReportedSDR   =         fieldSet.readString("FirstReportedSDR");

		if (null != currBuyerParent && currBuyerParent.equalsIgnoreCase(ReconConstants.WELLS_FARGO)) buerFlag = true;

		if (null != currSellerParent && currSellerParent.equalsIgnoreCase(ReconConstants.WELLS_FARGO)) sellerFlag = true;

		if (buerFlag && sellerFlag)
		{
			if (null != currBuyer)
			{
				if ((null != currUSReportingEntityPETData && currBuyer.equalsIgnoreCase(currUSReportingEntityPETData))
				        || (null != currUSReportingEntityContinuationData && currBuyer.equalsIgnoreCase(currUSReportingEntityContinuationData)))
				{
					party1name = currBuyer;
					party2name = currSeller;

					party1Lei = currBuyerLEI;
					party2Lei = currSellerLEI;
					senderTradeRefId = currBuyerSenderTradeRefId;
				}
				else
				{
					party1name = currSeller;
					party2name = currBuyer;

					party1Lei = currSellerLEI;
					party2Lei = currBuyerLEI;
					senderTradeRefId = currSellerSenderTradeRefId;

				}
			}
		}
		else if (buerFlag)
		{
			party1name = currBuyer;
			party2name = currSeller;

			party1Lei = currBuyerLEI;
			party2Lei = currSellerLEI;
			senderTradeRefId = currBuyerSenderTradeRefId;

		}
		else if (sellerFlag)
		{
			party1name = currSeller;
			party2name = currBuyer;

			party1Lei = currSellerLEI;
			party2Lei = currBuyerLEI;
			senderTradeRefId = currSellerSenderTradeRefId;

		}
		else
		{
			logger.info("Either buyer flag or seller flag is true : hence not able to set party1 and party2 information");
		}

		currRegRepCommTradeMterms.setParty1Name(StringUtils.replaceChars(party1name, ",", " ")  );
		currRegRepCommTradeMterms.setParty2Name( StringUtils.replaceChars(party2name, ",", " ")  );
		
		//currRegRepCommTradeMterms.setParty1Name(party1name);
		//currRegRepCommTradeMterms.setParty2Name(party2name);
		currRegRepCommTradeMterms.setParty1Lei(party1Lei);
		currRegRepCommTradeMterms.setParty2Lei(party2Lei);

		currRegRepCommTradeMterms.setUsi(fieldSet.readString("USI/UTI"));
		currRegRepCommTradeMterms.setIceConfirmStatus(fieldSet.readString("TradeStatus"));

		if ((null != currUSReportingEntityPETData && null != party1name && party1name.equalsIgnoreCase(currUSReportingEntityPETData))
		        || (null != currUSReportingEntityContinuationData  && null != party1name && party1name.equalsIgnoreCase(currUSReportingEntityContinuationData)))
		{
			reportingParty = 1;
		}
		if(StringUtils.isNotBlank(firstReportedSDR))
		{
			reportable = 1;
			currRegRepCommTradeMterms.setReportable(reportable);
			currRegRepCommTradeMterms.setRepository(firstReportedSDR);
		}

		currRegRepCommTradeMterms.setReportingParty(reportingParty);
		
		if(null != senderTradeRefId && StringUtils.isNotBlank(senderTradeRefId))
		{
			currRegRepCommTradeMterms.setSenderTradeRefId(senderTradeRefId);
		}
		
		currRegRepCommTradeMterms.setCreateDatetime(currDate);

		return currRegRepCommTradeMterms;
	}

}
