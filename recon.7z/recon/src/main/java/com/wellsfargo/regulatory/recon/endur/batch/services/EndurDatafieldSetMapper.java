package com.wellsfargo.regulatory.recon.endur.batch.services;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;
import com.wellsfargo.regulatory.recon.util.ReconConstants;

/**
 * @author Raji Komatreddy
 */
public class EndurDatafieldSetMapper implements FieldSetMapper<RegRepCommTradeMterms>
{

	@Override
	public RegRepCommTradeMterms mapFieldSet(FieldSet fieldSet) throws BindException
	{
		RegRepCommTradeMterms currRegRepCommTradeMterms = new RegRepCommTradeMterms();

		byte reportable = 0;
		byte reportingParty = 0;

		Date currDate = new Date();
		currRegRepCommTradeMterms.setSourceSystem(ReconConstants.ENDUR_SRC_SYS_NAME);
		currRegRepCommTradeMterms.setTradeId(fieldSet.readString("DealId"));
		currRegRepCommTradeMterms.setTradeVersion(fieldSet.readString("TranNumber"));
		currRegRepCommTradeMterms.setProductId(fieldSet.readString("ProductId"));
		// currRegRepCommTradeMterms.setProductName(fieldSet.readString("deal_tracking_num"));
		//currRegRepCommTradeMterms.setTradeDate(ReconUtil.formatStrDateOnly(fieldSet.readString("TradeDate")));
		currRegRepCommTradeMterms.setTradeDate(fieldSet.readDate("TradeDate", ReconConstants.RECON_REPORT_DATEFORMAT_MMDDYYYY, null));
		currRegRepCommTradeMterms.setEffectiveDate(fieldSet.readDate("StartDate",ReconConstants.RECON_REPORT_DATEFORMAT_MMDDYYYY, null));
		currRegRepCommTradeMterms.setMaturityDate(fieldSet.readDate("MaturityDate",ReconConstants.RECON_REPORT_DATEFORMAT_MMDDYYYY, null ));
		currRegRepCommTradeMterms.setTlcEvent(fieldSet.readString("TLCEvent"));
		currRegRepCommTradeMterms.setTlcEventDatetime(fieldSet.readDate("LastUpdateDateTime", ReconConstants.RECON_REPORT_DATEFORMAT_UTC, null));
		currRegRepCommTradeMterms.setTradeStatus(fieldSet.readString("Status"));
		currRegRepCommTradeMterms.setParty1Name(StringUtils.replaceChars(fieldSet.readString("OurLongName"), ",", " "));
		currRegRepCommTradeMterms.setParty2Name(StringUtils.replaceChars(fieldSet.readString("CptyLongName"), ",", " ") );
		
		//currRegRepCommTradeMterms.setParty1Name(fieldSet.readString("OurLongName"));
		//currRegRepCommTradeMterms.setParty2Name(fieldSet.readString("CptyLongName") );
		
		currRegRepCommTradeMterms.setParty1Lei(fieldSet.readString("OurLEI"));
		currRegRepCommTradeMterms.setParty2Lei(fieldSet.readString("CptyLEI"));

		if (StringUtils.isNotBlank(fieldSet.readString("SDRReportable")) && !fieldSet.readString("SDRReportable").equalsIgnoreCase("NO"))
		{
			reportable = 1;
			currRegRepCommTradeMterms.setRepository(fieldSet.readString("SDRReportable"));
		}
			  
		
		currRegRepCommTradeMterms.setReportable(reportable);

		if ( reportable == 1 && null != fieldSet.readString("ReportingParty") && fieldSet.readString("ReportingParty").equalsIgnoreCase("YES")) reportingParty = 1;

		if(reportingParty == 1)
		{
			currRegRepCommTradeMterms.setReportingParty(reportingParty);
		}
		

		currRegRepCommTradeMterms.setUsi(fieldSet.readString("USI"));
		currRegRepCommTradeMterms.setEndurUniqueId(fieldSet.readString("UniqueId"));
		currRegRepCommTradeMterms.setSenderTradeRefId(fieldSet.readString("SenderTradeRefId"));
		currRegRepCommTradeMterms.setCreateDatetime(currDate);

		return currRegRepCommTradeMterms;
	}

}
