package com.wellsfargo.regulatory.recon.ice.batch.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.persister.recon.dao.RegRepCommTradeMtermsDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepCommTradeMterms;

public class IceOpenTransactionDataDbWriter {
	private List<RegRepCommTradeMterms> finalFegRepCommTradeMtermsList = new ArrayList<RegRepCommTradeMterms>();

	@Autowired
	private RegRepCommTradeMtermsDao regRepCommTradeMtermsDao;
	
	private static Logger logger = Logger.getLogger(IceOpenTransactionDataDbWriter.class.getName());
	public void write(List<? extends RegRepCommTradeMterms> regRepCommTradeMtermsList) throws Exception
	{
		
		if(!regRepCommTradeMtermsList.isEmpty() && null !=regRepCommTradeMtermsList)
		{	
		logger.info("inside IceOpenTransactionDataDbWriter write method");
		finalFegRepCommTradeMtermsList.addAll(regRepCommTradeMtermsList);
		Collection<RegRepCommTradeMterms> currColliectionList = (Collection<RegRepCommTradeMterms>) regRepCommTradeMtermsList;

		regRepCommTradeMtermsDao.springBatchInsert((List<RegRepCommTradeMterms>) regRepCommTradeMtermsList);
		logger.info("exiting IceOpenTransactionDataDbWriter write method");
		}

	}
}
