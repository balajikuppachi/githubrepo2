package com.wellsfargo.regulatory.recon.batch;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.EtdMessageException;
import com.wellsfargo.regulatory.persister.recon.dao.RegRepReconReportStatusDao;
import com.wellsfargo.regulatory.persister.recon.dto.RegRepReconReportStatus;
import com.wellsfargo.regulatory.persister.util.dao.RegRepSequenceIdDao;
import com.wellsfargo.regulatory.persister.util.dto.RegRepSequenceId;
import com.wellsfargo.regulatory.recon.util.ReconConstants;
import com.wellsfargo.regulatory.recon.util.ReconUtil;

/**
 * @author Raji Komatreddy
 */
public class EndurDataLoadBatchjobLauncher
{

	private Job endurDataLoadBatchjob;
	private String tempFileLoc;   // = "C:\\SDR\\test\\";

	@Autowired
	private RegRepSequenceIdDao regRepSequenceIdDao;

	@Autowired
	private RegRepReconReportStatusDao regRepReconReportStatusDao;

	private static Logger logger = Logger.getLogger(EndurDataLoadBatchjobLauncher.class.getName());

	@Transformer
	public Message<JobLaunchRequest> launchJob(Message<?> message) throws EtdMessageException
	{
		Object ipMessage = null;
		String errorString = null;
		String endurFileLoc = null;
		String fileName = null;
		JobLaunchRequest endurDataLoadJob = null;
		Message<JobLaunchRequest> endurDataLoadBatchjobLaunch = null;

		RegRepReconReportStatus currRegRepReconReportStatus = new RegRepReconReportStatus();
		
		Date reportDate = null;
		Date currDate = new Date();

		// need to write logic to make this as unique
		int batchID = 0;

		RegRepSequenceId regRepSequenceId = null;
		regRepSequenceId = regRepSequenceIdDao.getNextRegRepSequnceId(RegRepSequenceId.CALL_STOREDPROC_GETNEXTSEQUENCEID, 1);
		if (null != regRepSequenceId)
		{
			batchID = regRepSequenceId.getSequenceId();
		}
		String reportDateStr = null;

		logger.info("inside EndurDataLoadBatchjobLauncher launchJob method");
		if (null == message)
		{
			errorString = "Null incoming message from  EndurDataLoadBatchjobLauncher ";
			logger.error("########## " + errorString);
			throw new EtdMessageException("EndurDataLoadBatchjobLauncher-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		if (ipMessage instanceof File)
		{

			logger.info("consuming endur input file");
			try
			{
				File inFile = (File) ipMessage;
				endurFileLoc = inFile.getAbsolutePath();
				fileName = inFile.getName();
				File tempFile = new File(tempFileLoc + fileName);

				if (null != fileName && fileName.length() > 27)
				{
					reportDateStr = StringUtils.substring(fileName, 19, 27);

				}
				else
				{
					errorString = "filename is not in agreed format: file recieved is  " + fileName;
					logger.error("########## " + errorString);
					throw new EtdMessageException("EndurDataLoadBatchjobLauncher-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

				}

				reportDate = ReconUtil.formatYYYYMMDDtoDate(reportDateStr);

				currRegRepReconReportStatus.setBatchId(batchID);
				currRegRepReconReportStatus.setSourceSystem(ReconConstants.ENDUR_SRC_SYS_NAME);
				currRegRepReconReportStatus.setReportDate(reportDate);
				currRegRepReconReportStatus.setReportStatus(ReconConstants.RECON_REPORT_STATUS_PROCESSING);
				currRegRepReconReportStatus.setOutFileName(endurFileLoc);
				currRegRepReconReportStatus.setCreateDatetime(currDate);
				currRegRepReconReportStatus.setUpdateDatetime(currDate);
				
				if(null!= regRepSequenceIdDao)				
					currRegRepReconReportStatus =	regRepReconReportStatusDao.save(currRegRepReconReportStatus);
			

				tempFile.mkdirs();
				Files.copy(inFile.toPath(), tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
				endurFileLoc = tempFile.getAbsolutePath();
				 inFile.delete();

				JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
				jobParametersBuilder.addString(ReconConstants.ENDUR_IN_FILE_LOC, endurFileLoc);
				jobParametersBuilder.addString(ReconConstants.RECON_BATCH_ID, Integer.toString(batchID));
				jobParametersBuilder.addString(ReconConstants.RECON_REPORT_DATE, reportDateStr);
				jobParametersBuilder.addString(ReconConstants.RECON_REPORT_ID, Integer.toString(currRegRepReconReportStatus.getReportId()));

				endurDataLoadJob = new JobLaunchRequest(endurDataLoadBatchjob, jobParametersBuilder.toJobParameters());
				endurDataLoadBatchjobLaunch = MessageBuilder.withPayload(endurDataLoadJob).build();

			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating endurDataLoadBatchjob launch request " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new EtdMessageException("EndurDataLoadBatchjobLauncher-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

			}

		}

		logger.info("exiting EndurDataLoadBatchjobLauncher JobLaunchRequest method");

		return endurDataLoadBatchjobLaunch;

	}

	public void setTempFileLoc(String tempFileLoc)
	{
		this.tempFileLoc = tempFileLoc;
	}

	public Job getEndurDataLoadBatchjob()
	{
		return endurDataLoadBatchjob;
	}

	public void setEndurDataLoadBatchjob(Job endurDataLoadBatchjob)
	{
		this.endurDataLoadBatchjob = endurDataLoadBatchjob;
	}

}
