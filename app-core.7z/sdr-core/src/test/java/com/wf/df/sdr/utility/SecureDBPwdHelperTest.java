package com.wf.df.sdr.utility;



import junit.framework.TestCase;

/******************************************************************************
 * Filename    : SecureDBPwdHelperTest.java
 * Author      : Rama Nuti
 * Date Created: 2015-05-04
 * Contents    : 
 ******************************************************************************
 * (c) Copyright © 1999 - 2014 Wells Fargo. All rights reserved. 
 * No part of this program may be photocopied reproduced or translated to another
 * program language without prior written consent of Wells Fargo.
 ******************************************************************************/

public class SecureDBPwdHelperTest extends TestCase 
{

    public void testHelper_NoPassPhrase() 
    {
        SecureDBPwdHelper secureDBPwdHelper = new SecureDBPwdHelper();
        String toEncode = "Simple test string";
        String encodedString = secureDBPwdHelper.encrypt(toEncode);
        String decodedString = secureDBPwdHelper.decrypt(encodedString);

        System.out.println(encodedString + "===>" + encodedString);
        System.out.println(decodedString + "===>" + decodedString);

        assertEquals(toEncode, decodedString);
    }

    public void testHelper_PassPhrase() 
    {
        SecureDBPwdHelper secureDBPwdHelper = new SecureDBPwdHelper("Not a very creative pass phrase!");
        String toEncode = "sdr_prodfix99";
        String encodedString = secureDBPwdHelper.encrypt(toEncode);
        String decodedString = secureDBPwdHelper.decrypt(encodedString);

        System.out.println(encodedString + "===>" + encodedString);
        System.out.println(decodedString + "===>" + decodedString);

        assertEquals(toEncode, decodedString);
    }

    public void testHelper_DifferentPassPhrase() 
    {
        SecureDBPwdHelper secureDBPwdHelper = new SecureDBPwdHelper("New unique passphrase");
        SecureDBPwdHelper defSecureDBPwdHelper = new SecureDBPwdHelper();
        String toEncode = "Simple test string";
        String encodedString1 = secureDBPwdHelper.encrypt(toEncode);
        String encodedString2 = defSecureDBPwdHelper.encrypt(toEncode);

        System.out.println(encodedString1 + "===>" + encodedString1);
        System.out.println(encodedString2 + "===>" + encodedString2);
        
        assertFalse(encodedString1.equals(encodedString2));
    }
    
    
    public void test() 
    {
        SecureDBPwdHelper secureDBPwdHelper = new SecureDBPwdHelper();
        String toEncode = "sdradm1";
        String encodedString = secureDBPwdHelper.encrypt(toEncode);
        
        System.out.println(toEncode + "===>" + encodedString);
    }

}
