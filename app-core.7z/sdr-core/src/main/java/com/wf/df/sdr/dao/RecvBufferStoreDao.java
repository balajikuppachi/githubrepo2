package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.RecvBufferStoreDao;
import com.wf.df.sdr.dto.RecvBufferStore;
import com.wf.df.sdr.exception.dao.RecvBufferStoreDaoException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface RecvBufferStoreDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(RecvBufferStore dto);

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria ''.
	 */
	public List<RecvBufferStore> findAll() throws RecvBufferStoreDaoException;

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'buffer_id = :bufferId'.
	 */
	public List<RecvBufferStore> findWhereBufferIdEquals(BigDecimal bufferId) throws RecvBufferStoreDaoException;

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'buffer_data = :bufferData'.
	 */
	public List<RecvBufferStore> findWhereBufferDataEquals(String bufferData) throws RecvBufferStoreDaoException;

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'buffer_src = :bufferSrc'.
	 */
	public List<RecvBufferStore> findWhereBufferSrcEquals(String bufferSrc) throws RecvBufferStoreDaoException;

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<RecvBufferStore> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvBufferStoreDaoException;

}
