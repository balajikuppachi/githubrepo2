package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class ExecutionVenuePrefixCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.executionVenuePrefixCalc, isPrototype = false)
	public String executionVenuePrefix() {
		
		//This is used only with RT message types, Optional for others.
		//Its either DCM or Off-facility
		return Constants.EMPTY_STRING;
	}
}
