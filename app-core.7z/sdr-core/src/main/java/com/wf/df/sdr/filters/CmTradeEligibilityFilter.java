package com.wf.df.sdr.filters;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.dao.MsgNotEligibleDao;
import com.wf.df.sdr.dto.MsgNotEligible;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.MailSenderService;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class CmTradeEligibilityFilter {
	
	@Autowired
	NotEligblePersister nep;
	@Autowired
	MailSenderService mailSender;
	@Autowired
	MsgNotEligibleDao mneDao;
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	public boolean checkEligibility(UnitOfWork uow)
	{
		CalculationContext cc = uow.getCalculationContext();
		BigDecimal sendId = cc.getValue(Constants.SEND_ID, BigDecimal.class);
		
		if(Constants.ICE_PAPER_CONFIRM.equals(cc.getString(Constants.MESSAGE_TYPE))) {
			List<MsgNotEligible> mneList = mneDao.findWhereSendIdEquals(sendId);
			if(!Utils.IsListNullOrEmpty(mneList)) {
				MsgNotEligible mne = mneList.get(0);
				mne.setCreateDatetime(new Date());
				logger.info(sendId + " --> Paper Confirm not eligible" );
				mneDao.insert(mne);
				return false;
			} 
			
			return true;
		}
		
		String prodId = cc.getValue(Stv.ICEProductId, String.class);
		String reportable = cc.getValue(Stv.SDR_REPORTABLE, String.class);
		String physical = cc.getValue(Stv.CommodityInstrumentType, String.class);
		String party = cc.getValue(Stv.REPORTING_PARTY, String.class);
		String leiUs = cc.getValue(Stv.LEI_US, String.class);
		String tradeLifeCycleAction = cc.getValue(Stv.TradeLifeCycleAction, String.class);
		String sdrError = cc.getValue(Stv.ENDURUNQID_ERROR,String.class);
		String tradeId = cc.getValue(Stv.TradeId, String.class);
		String tradeStatus = cc.getValue(Stv.Status, String.class);
		String eConfirmEligible = cc.getValue(Stv.EConfirmEligible, String.class);
		String foreignReportingEligible = cc.getValue(Stv.FOREIGN_REPORTING_ELIGIBLE, String.class);
		String foreignReportingParty = cc.getValue(Stv.FOREIGN_REPORTING_PARTY, String.class);
		String sefTrade = cc.getValue(Stv.ECN_Source, String.class);
		
		
		
		// Product Id is not set Dont forward it
		if (Utils.IsNullOrNone(prodId))  {
			nep.save(uow, NotEligblePersister.PIDNF);
			mailSender.sendCommodityExceptionMail(NotEligblePersister.PIDNF+Constants.HYPHEN+tradeId, "ICE Product ID Not found for the Trade\n SendId "+sendId, null);
			return false;
		}
		// If its the Swaption with Excercise keyword dont forward it.
		if (StringUtils.equalsIgnoreCase(tradeLifeCycleAction,Constants.EXERCISE))  {
			nep.save(uow, NotEligblePersister.TLCEXERCISE);
			return false;
		}
		// If the STV has any error Dont forward it
		if(!Utils.IsNullOrBlank(sdrError)){
			nep.save(uow, NotEligblePersister.ENDURUNQID);
			mailSender.sendCommodityExceptionMail(NotEligblePersister.ENDURUNQID+Constants.HYPHEN+tradeId, "EndurUniqueId not found for corresponding SwapDealReferenceId\n SendId "+sendId, null);
			return false;
		}
		
		
		// If physical trade , persist in the msg_not_eligible & process trade
		if (StringUtils.equalsIgnoreCase(physical,Constants.COMM_PHYS))  {
			nep.save(uow, NotEligblePersister.EndurPhyTrade);
		}
		else {

			Boolean foreignEligible = false;
			Boolean cftcEligible = false;

			if (Constants.TRUE.equalsIgnoreCase(reportable) && (!Utils.IsNullOrBlank(party) && party.equals(leiUs))) {
				cftcEligible = true;
			}
			if (!Utils.IsNullOrBlank(foreignReportingEligible)) {

				String[] foreignReportingEligibleArray = foreignReportingEligible.split(",");

				for (String eligible : foreignReportingEligibleArray) {

					String[] splitArray = eligible.split("\\.");

					if (splitArray.length < 2)
						continue;

					if (!splitArray[1].equalsIgnoreCase("NO")) {
						String juridiction = splitArray[0];

						String contains1 = juridiction + ".Us";
						String contains2 = juridiction + ".Both";

						if (StringUtils.containsIgnoreCase(foreignReportingParty, contains1) || StringUtils.containsIgnoreCase(foreignReportingParty, contains2)) {
							foreignEligible = true;
							break;
						}

					}
				}

			}
			
			/** STR-304:  PET submission to ICE for SEF deal */
			/*// suppress PET submission for SEF executed trades (Where TradeLifeCycleAction='validate' and SEF != '' and RP = 'Wells')
			if (cftcEligible && !foreignEligible && !Utils.IsNullOrBlank(sefTrade) && StringUtils.equalsIgnoreCase(tradeLifeCycleAction, Constants.VALIDATE)) {
				nep.save(uow, NotEligblePersister.EndurSEFTrade);
				// return false;
			}
			else*/ 
				
			if (!cftcEligible && !foreignEligible && !(Constants.TRUE.equalsIgnoreCase(eConfirmEligible))) {
				nep.save(uow, NotEligblePersister.EndurRepEconf);
				logger.warn("checkEligibility returns false : Trade is not reportable or not eligible for reporting");
				// return false;
			}
		}
		
		return true;
	}

}
