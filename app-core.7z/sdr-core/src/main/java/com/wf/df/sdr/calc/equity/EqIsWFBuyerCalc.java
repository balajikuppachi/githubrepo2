package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqIsWFBuyerCalc {

	@Calculation(value = Calc.eqIsWFBuyerCalc, isPrototype = false)
	public Boolean valuationDate(
			@DerivedFrom(value = Stv.WeBuySell, isInternal = true) String weBuySell) {

		if (Utils.IsNullOrBlank(weBuySell)) {
			throw new CalculationException("FNF", "Error in calcuating Buyer or Seller for Equity. Stv tag WeBuySell is " + weBuySell);
		}
		if (Constants.Buy.equals(weBuySell)) 
			return true;
		else
			return false;
		
	}
	
}
