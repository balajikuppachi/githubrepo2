package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxOptionBuyerPrefixCalc {

	
	@Calculation(value=Calc.fxOptionBuyerPrefixCalc)
	public String fxOptionBuyerPrefixCalc(
			@DerivedFrom(value=Calc.fxWfParticipantIdPrefixCalc) String wfPrefix,
			@DerivedFrom(value=Calc.fxCptyParticipantIdPrefixCalc) String cptyPrefix,
			@DerivedFrom(value = Stv.FXOptionIsBuyFlag) String optionIsBuyFlag)	{
		if(!Utils.IsNullOrBlank(optionIsBuyFlag)  )
		{
		
			if(Constants.TRUE.equals(optionIsBuyFlag) && !Utils.IsNullOrBlank(wfPrefix))
			{	 return wfPrefix;
			}else if(Constants.FALSE.equals(optionIsBuyFlag) && !Utils.IsNullOrBlank(cptyPrefix))
			{  	 return cptyPrefix;
			}
		
		}
		return Constants.EMPTY_STRING;
	}
}
