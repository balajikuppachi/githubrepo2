package com.wf.df.sdr.calc.constant;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;

@Component
public class BooleanTrueCalc {
	@Calculation(value = Calc.booleanTrueCalc, isPrototype = false)
	public Boolean calculate() {
		return Boolean.TRUE;
	}
}
