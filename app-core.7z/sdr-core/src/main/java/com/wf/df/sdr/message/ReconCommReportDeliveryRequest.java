package com.wf.df.sdr.message;

import java.io.File;

public class ReconCommReportDeliveryRequest {

	private File file;

	public ReconCommReportDeliveryRequest( File file) {
		this.file = file;
	}

	public File getFile() {
		return file;
	}
}
