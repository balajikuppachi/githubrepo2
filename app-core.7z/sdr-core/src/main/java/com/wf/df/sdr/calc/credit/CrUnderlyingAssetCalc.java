package com.wf.df.sdr.calc.credit;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;


@Component
public class CrUnderlyingAssetCalc {

	
	Logger logger = Logger.getLogger(this.getClass());

	/**
	 * Check for 9 char clip id -> pairClipID
	 * Else check for 6 char entity clip id
	 * Else ISIN
	 * 
	 */
	@Calculation(value = Calc.crUnderlyingAssetCalc)
	public String calcAction(
			@DerivedFrom(value = Stv.DTCCPairClipId) String pairClipId,
			@DerivedFrom(value = Stv.DTCCEntityClipId) String entityClipId,
			@DerivedFrom(value = Stv.CDSIdxTrancheBasketName) String trancheName,
			@DerivedFrom(value = Stv.DTCCISIN) String isin,
			@DerivedFrom(value = Stv.CMBSCUSIP, isInternal = true) String cmbsCusip,
			@DerivedFrom(value = Stv.RMBSCUSIP, isInternal = true) String rmbsCusip) {

		if (!Utils.IsNullOrBlank(pairClipId) && !Constants.NOT_FOUND.equalsIgnoreCase(pairClipId))
			return pairClipId;
		
		else if (!Utils.IsNullOrBlank(entityClipId) && !Constants.NOT_FOUND.equalsIgnoreCase(entityClipId))
			return entityClipId;

		else if (!Utils.IsNullOrBlank(isin) && !Constants.NOT_FOUND.equalsIgnoreCase(isin) )
			return isin;

		else if (!Utils.IsNullOrBlank(cmbsCusip) && !Constants.NOT_FOUND.equalsIgnoreCase(cmbsCusip) )
			return cmbsCusip;
	
		else if (!Utils.IsNullOrBlank(rmbsCusip) && !Constants.NOT_FOUND.equalsIgnoreCase(rmbsCusip) )
			return rmbsCusip;
	
	/*	else if (!Utils.IsNullOrBlank(trancheName) && !Constants.NOT_FOUND.equalsIgnoreCase(trancheName) )
			return StringUtils.substring(trancheName, 0, 20);*/
		
		return "BespokeBasket";
		
	}
}