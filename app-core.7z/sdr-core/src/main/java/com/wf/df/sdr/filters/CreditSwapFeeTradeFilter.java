package com.wf.df.sdr.filters;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class CreditSwapFeeTradeFilter {

	@Autowired
	NotEligblePersister nep;

	@Autowired
	ParserService parser;
	
	// SPOT Credit Swap Fee Trades
	public boolean isCreditSwapFeeTrade(UnitOfWork uow) {

		CalculationContext cc = uow.getCalculationContext();
		String srcAssetClass =  cc.getValue(Calc.srcAssetClassCalc, String.class);
		String srcProdType =  cc.getValue(Stv.CalypsoProductType, String.class);
		String notionalAmount =  cc.getValue(Calc.crNotionalLessThan100Calc, String.class);

		if (Constants.ASSET_CLASS_CREDIT.equalsIgnoreCase(srcAssetClass) && Constants.CREDITDEFAULTSWAP.equals(srcProdType)) {
			
			BigDecimal HUNDRED = new BigDecimal(100);
			BigDecimal bd = new BigDecimal(notionalAmount);
			bd = bd.abs();
			
			if (bd.compareTo(HUNDRED)<0)
			{
				nep.save(uow, NotEligblePersister.CreditSFT);
				return false;
			}
			return true;
		}
		
		// default for other assetclass
		return true;
	}
}
