package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.RecvBufferStoreDao;
import com.wf.df.sdr.dto.RecvBufferStore;
import com.wf.df.sdr.exception.dao.RecvBufferStoreDaoException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class RecvBufferStoreDaoImpl extends AbstractDAO implements ParameterizedRowMapper<RecvBufferStore>, RecvBufferStoreDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(RecvBufferStore dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( buffer_id, buffer_data, buffer_src, create_datetime ) VALUES ( ?, ?, ?, ? )",dto.getBufferId(),dto.getBufferData(),dto.getBufferSrc(),dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return RecvBufferStore
	 */
	public RecvBufferStore mapRow(ResultSet rs, int row) throws SQLException
	{
		RecvBufferStore dto = new RecvBufferStore();
		dto.setBufferId( rs.getBigDecimal(1));
		dto.setBufferData( rs.getString( 2 ) );
		dto.setBufferSrc( rs.getString( 3 ) );
		dto.setCreateDatetime( rs.getTimestamp(4 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recv_buffer_store";
	}

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria ''.
	 */
	@Transactional
	public List<RecvBufferStore> findAll() throws RecvBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new RecvBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'buffer_id = :bufferId'.
	 */
	@Transactional
	public List<RecvBufferStore> findWhereBufferIdEquals(BigDecimal bufferId) throws RecvBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE buffer_id = ? ORDER BY buffer_id", this,bufferId);
		}
		catch (Exception e) {
			throw new RecvBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'buffer_data = :bufferData'.
	 */
	@Transactional
	public List<RecvBufferStore> findWhereBufferDataEquals(String bufferData) throws RecvBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE buffer_data = ? ORDER BY buffer_data", this,bufferData);
		}
		catch (Exception e) {
			throw new RecvBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'buffer_src = :bufferSrc'.
	 */
	@Transactional
	public List<RecvBufferStore> findWhereBufferSrcEquals(String bufferSrc) throws RecvBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE buffer_src = ? ORDER BY buffer_src", this,bufferSrc);
		}
		catch (Exception e) {
			throw new RecvBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_buffer_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<RecvBufferStore> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new RecvBufferStoreDaoException("Query failed", e);
		}
		
	}

}
