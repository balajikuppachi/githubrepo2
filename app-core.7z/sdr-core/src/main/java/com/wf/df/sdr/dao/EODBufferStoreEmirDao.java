package com.wf.df.sdr.dao;

import com.wf.df.sdr.dto.EODBufferStoreEmir;
import com.wf.df.sdr.exception.dao.EODBufferStoreEmirDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface EODBufferStoreEmirDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(EODBufferStoreEmir dto);

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria ''.
	 */
	public List<EODBufferStoreEmir> findAll() throws EODBufferStoreEmirDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'uti = :uti'.
	 */
	public List<EODBufferStoreEmir> findWhereUtiEquals(String uti) throws EODBufferStoreEmirDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'uti = :uti'.
	 */
	public List<EODBufferStoreEmir> findWhereUtiAndMsgTypeEquals(String uti, String msgType,String sdrRepository) throws EODBufferStoreEmirDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'asset_class = :assetClass'.
	 */
	public List<EODBufferStoreEmir> findWhereAssetClassEquals(String assetClass) throws EODBufferStoreEmirDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'send_id = :sendId'.
	 */
	public List<EODBufferStoreEmir> findWhereSendIdEquals(BigDecimal sendId) throws EODBufferStoreEmirDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'msg_buffer = :msgBuffer'.
	 */
	public List<EODBufferStoreEmir> findWhereMsgBufferEquals(String msgBuffer) throws EODBufferStoreEmirDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	public List<EODBufferStoreEmir> findWhereUpdateDatetimeEquals(Date updateDatetime) throws EODBufferStoreEmirDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'template_id = :templateId'.
	 */
	public List<EODBufferStoreEmir> findWhereTemplateIdEquals(String templateId) throws EODBufferStoreEmirDaoException;
	
	
	
		
	public int deleteBuffersForUTI(String uti) throws EODBufferStoreEmirDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<EODBufferStoreEmir> findWhereSdrRepositoryEquals(String sdrRepository) throws EODBufferStoreEmirDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'tradeId = :tradeId'.
	 */
	public List<EODBufferStoreEmir> findWhereTradeIdEquals(String tradeId) throws EODBufferStoreEmirDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'inputBufferId = :inputBufferId'.
	 */
	public List<EODBufferStoreEmir> findWhereInputBufferIdEquals(String inputBufferId) throws EODBufferStoreEmirDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'tradeId, msgType,assetClass,uti'.
	 */
	public List<EODBufferStoreEmir> findExistingTrade(String assetClass,  String msgType, String tradeId, String uti) throws EODBufferStoreEmirDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'tradeId, msgType,assetClass,uti,marketType'.
	 */
	public List<EODBufferStoreEmir> findExistingTrade(String assetClass,  String msgType, String tradeId, String uti, String marketType, Boolean isDelegated) throws EODBufferStoreEmirDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'isDuplicate = :isDuplicate'.
	 */
	public List<EODBufferStoreEmir> findWhereIsDuplicateEquals(String isDuplicate) throws EODBufferStoreEmirDaoException;

	public List<EODBufferStoreEmir> findWhereIsBufferEligibleEquals(String isBufferEligible) throws EODBufferStoreEmirDaoException;
	/** 
	 * Update    eod_buffer_store_emir table 
	 */
	public void updateIsBufferEligible(BigDecimal sendID, String msgType) throws EODBufferStoreEmirDaoException;
	
	public void saveOrUpdateEODBuffer(EODBufferStoreEmir dto) throws EODBufferStoreEmirDaoException;

	/** 
	 * Delete buffer from   eod_buffer_store_emir table 
	 */
	public int deleteBuffersForUSI(String usi) throws EODBufferStoreEmirDaoException;

	public int updateIsbufferEligibleForUsiPrev(String usiPrevious);

	public int updateIsbufferEligibleForTradeId(String tradeId);
	
	
	public void updateIsDuplicate(BigDecimal sendID, String msgType) throws EODBufferStoreEmirDaoException;
	
	public int updateIsbufferEligibleForTradeIdUsi(String tradeId,String usi);
	
	
	
}