package com.wf.df.sdr.dao;

import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MappingTradeIdUsi;
import com.wf.df.sdr.exception.dao.MappingTradeIdUsiDaoException;

public interface MappingTradeIdUsiDao
{
	/**
	 * Method 'insert'
	 *
	 * @param dto
	 */
	public void insert(MappingTradeIdUsi dto);

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria ''.
	 */
	public List<MappingTradeIdUsi> findAll() throws MappingTradeIdUsiDaoException;

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'src_trade_id = :srcTradeId'.
	 */
	public List<MappingTradeIdUsi> findWhereSrcTradeIdEquals(String srcTradeId) throws MappingTradeIdUsiDaoException;

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'asset_class = :assetClass'.
	 */
	public List<MappingTradeIdUsi> findWhereAssetClassEquals(String assetClass) throws MappingTradeIdUsiDaoException;

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'usi = :usi'.
	 */
	public List<MappingTradeIdUsi> findWhereUsiEquals(String usi) throws MappingTradeIdUsiDaoException;

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'src_trade_id = :srcTradeId and asset_class = :assetClass'.
	 */
	public  List<MappingTradeIdUsi>  findWhereSrcTradeIdAssetClassEquals(String srcTradeId, String assetClass) throws MappingTradeIdUsiDaoException;

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MappingTradeIdUsi> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingTradeIdUsiDaoException;

	/**
	 * Returns cacheSize rows from the mapping_tradeid_usi table that match the criteria ''.
	 */
	public List<MappingTradeIdUsi> findAll(String cacheSize);

}