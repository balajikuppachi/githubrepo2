package com.wf.df.sdr.calc.equity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqUnderlyngAssetCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqUnderlyngAssetCalc, isPrototype = false)
	public String calcAction(
			@DerivedFrom(value = Stv.EquityBasketSharesList, isInternal = true) List<String> typelist,
			@DerivedFrom(value = Stv.UPI, isInternal = true) String upi,
			@DerivedFrom(value = Stv.EquityProductType, isInternal = true) String eqProductType,
			@DerivedFrom(value = Stv.EquityUnderlier, isInternal = true) String underlier) {
		
		//For Equity:Options use EquityUnderlier tag
		if(Constants.EquityOption.equals(eqProductType) && ( StringUtils.contains(upi, Constants.SingleIndex) || StringUtils.contains(upi, Constants.SingleName) || StringUtils.contains(upi, Constants.Basket )))
			return underlier;	
		
		ArrayList<String> array = new ArrayList<String>();
		if (!Utils.IsListNullOrEmpty(typelist)) {
			for (int i = 0; i < typelist.size(); i++) {
				array.add(typelist.get(i));
			}
		}
		return Utils.convertListToDelimitedString(array, Constants.SEMICOLON);
	}
}
