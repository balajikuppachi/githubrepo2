package com.wf.df.sdr.calc.xasset;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;


@Component
public class ShouldWeCreateFeeTradeCalc {

	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	DTCCUtils dtccUtil;
	
	@Calculation(value = Calc.shouldWeCreateFeeTradeCalc, isPrototype = false)
	public boolean calcAction(
			@DerivedFrom(value = Stv.MarketType, isInternal = true) String marketType,
			@DerivedFrom(value = Stv.FeeTypeList, isInternal = true) List<String> feeTypeList,
			@DerivedFrom(value = Stv.NCActivity, isInternal = true) String ncActivity,
			@DerivedFrom(value = Stv.CalypsoDocStatus, isInternal = true) String docStatus,
			@DerivedFrom(value = Constants.TradeType123_456, isInternal = true) String tradeType123_456,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String assetClass,
			@DerivedFrom(value = Stv.FEE_REPORTING_PARTY, isInternal = true) String feeRepParty,
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String leiUS) {
		
		if(Utils.IsNullOrBlank(marketType)) {
			return false;
		}
		
		if(Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
			return createRatesNovation(marketType, feeTypeList, docStatus, feeRepParty, leiUS);
		else if(Constants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass))
			return createCreditNovation(marketType, feeTypeList, tradeType123_456, ncActivity, docStatus, feeRepParty, leiUS);
		
		return false;
	}

	private boolean createRatesNovation(String marketType,
			List<String> feeTypeList, String docStatus, String feeRepParty, String leiUS) {
		if(!Utils.IsNullOrBlank(marketType) && (
			(Constants.Novation_EE.equals(marketType) && (Constants.PENDING.equals(docStatus) || Constants.DAY_PENDING.equals(docStatus)) )
				|| (Constants.Novation_OR.equals(marketType) && (Constants.ASSIGNED.equals(docStatus) || Constants.DAY_ASSIGNED.equals(docStatus)))
				||	(Constants.PartialNovation_OR.equals(marketType) && (Constants.PENDING.equals(docStatus) || Constants.DAY_PENDING.equals(docStatus)))		
		)  &&  (StringUtils.containsIgnoreCase(feeRepParty, Constants.Us) || StringUtils.containsIgnoreCase(feeRepParty, leiUS))  ){
			if(!Utils.IsListNullOrEmpty(feeTypeList)){
					for(int i=0; i<feeTypeList.size(); i++){
						if(Constants.FeeType_NovationFee.equalsIgnoreCase(feeTypeList.get(i)))
							return true;
					}
				}	
			}			
		return false;
	}
	
	private boolean createCreditNovation(String marketType,
			List<String> feeTypeList, String tradeType123_456, String ncActivity, String docStatus, String feeRepParty, String leiUS) {
		if(Constants.Reportable123.equals(tradeType123_456) && StringUtils.containsIgnoreCase(marketType, Constants.Novation) && 
				 (StringUtils.containsIgnoreCase(feeRepParty, Constants.Us) || StringUtils.containsIgnoreCase(feeRepParty, leiUS))) {
			if(!Utils.IsListNullOrEmpty(feeTypeList)){
					for(int i=0; i<feeTypeList.size(); i++){
						if(Constants.Novation.equalsIgnoreCase(feeTypeList.get(i)))
							return true;
						else if(Constants.Cancel.equalsIgnoreCase(ncActivity) && /*Constants.Upfront.equalsIgnoreCase(feeTypeList.get(i))*/
								Constants.TRADE_STATUS_VERIFIED.equalsIgnoreCase(docStatus))
							return true;
					}
			}	
		}			
		
		//Create Fee Trade in case of Cancel Scenarios
		if (Constants.Reportable123.equals(tradeType123_456) &&   (StringUtils.containsIgnoreCase(feeRepParty, Constants.Us) || StringUtils.containsIgnoreCase(feeRepParty, leiUS))) {
			if (Constants.Credit_Novation_OR.equals(marketType) || Constants.Credit_Partial_Novation_OR.equals(marketType)) {
				if (Constants.TRADE_STATUS_VERIFIED.equalsIgnoreCase(docStatus) && Constants.Cancel.equalsIgnoreCase(ncActivity))
					return true;
			} 
			else if (Constants.Credit_Novation_EE.equals(marketType)) {
				if (Constants.TRADE_STATUS_NC_CANCELED.equalsIgnoreCase(docStatus) && Constants.Cancel.equalsIgnoreCase(ncActivity))
					return true;
			}
		}
		return false;
	}
}