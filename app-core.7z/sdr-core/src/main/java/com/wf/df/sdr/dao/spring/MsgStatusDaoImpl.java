package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.MsgStatusDao;
import com.wf.df.sdr.dto.MsgStatus;
import com.wf.df.sdr.exception.dao.MsgStatusDaoException;
import com.wf.df.sdr.util.Constants;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class MsgStatusDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MsgStatus>, MsgStatusDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(MsgStatus dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, msg_type, create_datetime, msg_timestamp, status, asset_class,transmit_id, sdr_repository ) VALUES ( ?, ?, ?, ?, ?, ? , ?, ?)",dto.getSendId(),dto.getMsgType(),dto.getCreateDatetime(),dto.getMsgTimestamp(),dto.getStatus(),dto.getAssetClass(),dto.getTransmitId(),dto.getSdrRepository());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return MsgStatus
	 */
	public MsgStatus mapRow(ResultSet rs, int row) throws SQLException
	{
		MsgStatus dto = new MsgStatus();
		dto.setSendId( rs.getBigDecimal("send_id"));
		dto.setMsgType( rs.getString("msg_type"));
		dto.setCreateDatetime( rs.getTimestamp("create_datetime"));
		dto.setMsgTimestamp( rs.getTimestamp("msg_timestamp"));
		dto.setStatus( rs.getString("status"));
		dto.setAssetClass( rs.getString("asset_class"));
		dto.setTransmitId(rs.getBigDecimal("transmit_id"));
		dto.setSdrRepository(rs.getString("sdr_repository"));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "msg_status";
	}

	/** 
	 * Returns all rows from the msg_status table that match the criteria ''.
	 */
	@Transactional
	public List<MsgStatus> findAll() throws MsgStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<MsgStatus> findWhereSendIdEquals(BigDecimal sendId) throws MsgStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + " WHERE send_id = ? ", this,sendId);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<MsgStatus> findWhereMsgTypeEquals(String msgType) throws MsgStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + " WHERE msg_type = ? ", this,msgType);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<MsgStatus> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + " WHERE create_datetime = ? ", this,createDatetime);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'msg_timestamp = :msgTimestamp'.
	 */
	@Transactional
	public List<MsgStatus> findWhereMsgTimestampEquals(Date msgTimestamp) throws MsgStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + " WHERE msg_timestamp = ? ", this,msgTimestamp);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'status = :status'.
	 */
	@Transactional
	public List<MsgStatus> findWhereStatusEquals(String status) throws MsgStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + " WHERE status = ? ", this,status);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'asset_class = :assetClass'.
	 */
	@Transactional
	public List<MsgStatus> findWhereAssetClassEquals(String assetClass) throws MsgStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + " WHERE asset_class = ? ", this,assetClass);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	@Transactional
	public List<MsgStatus> findWhereSdrRepositoryEquals(String sdrRepository)
			throws MsgStatusDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, msg_timestamp, status, asset_class, transmit_id, sdr_repository FROM " + getTableName() + " WHERE sdr_repository = ? ", this,sdrRepository);
		}
		catch (Exception e) {
			throw new MsgStatusDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}

}
