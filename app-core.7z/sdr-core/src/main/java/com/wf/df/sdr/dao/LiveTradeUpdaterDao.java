package com.wf.df.sdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.OpenTradesBuffer;

@Repository
public class LiveTradeUpdaterDao {
Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Transactional
	public List<OpenTradesBuffer> findBufferLiveTradeList(String reportingType){
		
		String repquery="select t.send_id, t.src_asset_class, t.party2_lei, e.msg_buffer from temp_open_trade_details t, eod_buffer_store e where e.send_id = t.send_id"
				+ " and t.reporting_type = ? and e.msg_type = 'Snapshot' and t.src_asset_class in ('InterestRate','Credit','Equity')";
		String nrrepquery="select t.send_id, t.src_asset_class, t.party2_lei,  e.msg_buffer from temp_open_trade_details t, not_reportable_msg_store e where e.send_id = t.send_id"
				+ " and t.reporting_type = ? and e.msg_type = 'Snapshot_NR' and t.src_asset_class in ('InterestRate','Credit')";
		String query = null;
		
		if(reportingType.equalsIgnoreCase("REPORTABLE")){
			query = repquery;
		}else {
			query = nrrepquery;
		}
		
		List<OpenTradesBuffer> usiList = jdbcTemplate.query(query, new Object[]{reportingType},	new RowMapper<OpenTradesBuffer>(){
					@Override
					public OpenTradesBuffer mapRow(ResultSet rs, int arg1) throws SQLException {
						OpenTradesBuffer ot = new OpenTradesBuffer();
						ot.setSendId(Integer.parseInt(rs.getString(1)));
						ot.setsrcAssetClass(rs.getString(2));
						ot.setParty2Lei(rs.getString(3));
						ot.setmsgBuffer(rs.getString(4));
						return ot;
					}
				});
		return usiList;
		
	}
	
	@Transactional
	public List<OpenTradesBuffer> findBuffers()
	{
		String query = "SELECT t.send_id, t.src_asset_class, i.buffer_id FROM input_msg_store i, temp_open_trade_details t WHERE i.send_id = t.send_id and t.bus_acc_id is null";
		List<OpenTradesBuffer> tradesList = new ArrayList<OpenTradesBuffer>();
		
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
		
		for(Map<String, Object> row : rows)
		{
			OpenTradesBuffer ot = new OpenTradesBuffer();
				ot.setSendId((Integer)row.get("send_id"));
				ot.setsrcAssetClass((String)row.get("src_asset_class"));
				ot.setBufferID((Long)row.get("buffer_id"));
				tradesList.add(ot);
		}
		
		
		return tradesList;
	}

	@Transactional
	public int updateLEI(String lei, int sendID) 
	{
		String leiUpdateQuery="UPDATE temp_open_trade_details SET party2_lei = ? where send_id = ?";
		return jdbcTemplate.update(leiUpdateQuery, lei, sendID ) ;
	}
	
	@Transactional
	public void updateBusAccSql(String busAcc, int sendID){
		//jdbcTemplate.update("UPDATE temp_open_trade_details set bus_acc_id =? where send_id=?",busA, sendID);
		jdbcTemplate.update("UPDATE input_msg_store set bus_acc_id =? where send_id=?",busAcc, sendID);
	}
	
	@Transactional
	public List<OpenTradesBuffer> getAllLiveTrades(){
		String query = "SELECT src_trade_id, src_asset_class, party1_lei, party2_lei, bus_acc_id, ultimate_cpty_id, usi, uti from temp_open_trade_details";
		List<OpenTradesBuffer> tradesList = new ArrayList<OpenTradesBuffer>();
		
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
		
		for(Map<String, Object> row : rows)
		{
			OpenTradesBuffer ot = new OpenTradesBuffer();
				ot.setSrcTradeId((String)row.get("src_trade_id"));
				ot.setsrcAssetClass((String)row.get("src_asset_class"));
				ot.setParty1Lei((String)row.get("party1_lei"));
				ot.setParty2Lei((String)row.get("party2_lei"));
				ot.setBusAIdC((String)row.get("bus_acc_id"));
				ot.setultimateCptyId((String)row.get("ultimate_cpty_id"));
				ot.setUsi((String)row.get("usi"));
				ot.setUti((String)row.get("uti"));
				tradesList.add(ot);
		}
			
		return tradesList;
	}

}
