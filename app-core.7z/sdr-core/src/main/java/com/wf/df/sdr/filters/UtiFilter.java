package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Utils;

@Component
public class UtiFilter {

	@Autowired
	NotEligblePersister nep;
	
	Logger log = Logger.getLogger(getClass());

	public boolean isUTIAvailable(UnitOfWork uow) {
		log.debug("Uti filter Called");
		CalculationContext cc = uow.getCalculationContext();
		String uti = cc.getValue(Calc.calypsoComputedUTICalc, String.class);
		Boolean isEmirTrade = cc.getValue(Calc.isEmirTradeCalc, Boolean.class);
	
		
		if(Utils.IsNullOrBlank(uti) && isEmirTrade){
			log.debug("UTI Cannot be computed, IS NULL");
			// Save it in NotSendPersister
			nep.save(uow, NotEligblePersister.UTI);
			return false;
		}			
		
		
		return true;
	}
	
}
