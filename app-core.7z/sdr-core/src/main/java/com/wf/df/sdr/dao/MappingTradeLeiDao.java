package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MappingTradeLei;
import com.wf.df.sdr.exception.dao.MappingTradeLeiDaoException;

// TODO: Auto-generated Javadoc
/**
 * The Interface MappingTradeLeiDao.
 */
public interface MappingTradeLeiDao
{
	
	/**
	 * Method 'insert'.
	 *
	 * @param dto the dto
	 */
	public void insert(MappingTradeLei dto);
	

	/**
	 * Method 'updateLei'.
	 *
	 * @param dto the dto
	 */
	public void updateCurrentLei(MappingTradeLei dto);

	
	/**
	 * Update new lei to current lei.
	 *
	 * @param MappingTradeLei the trades lei mapping
	 * @return the int
	 */
	public void updateNewLeiToCurrentLei(MappingTradeLei MappingTradeLei);
	/**
	 * Save or update trades mapping.
	 *
	 * @param dto the dto
	 */
	public void saveOrUpdateTradesMapping(MappingTradeLei dto);
		
	/** 
	 * Returns all rows from the mapping_trade_lei table that match the criteria ''.
	 *
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findAll() throws MappingTradeLeiDaoException;

	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'src_system = :src_system'.
	 *
	 * @param srcSystem the src system
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereSrcSystemEquals(String srcSystem) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'trade_id = :trade_id'.
	 *
	 * @param tradeId the trade id
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereTradeIDEquals(String tradeId) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'usi = :usi'.
	 *
	 * @param usi the usi
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereUsiEquals(String usi) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'cpty_shortname = :cpty_shortname'.
	 *
	 * @param cptySname the cpty sname
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereCptyShortnameEquals(String cptySname) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'current_lei = :current_lei'.
	 *
	 * @param cueLei the cue lei
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereCurrentLeiEquals(String cueLei) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'alternate_id = :alternate_id'.
	 *
	 * @param busacctid the busacctid
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereAlternateIDEquals(String busacctid) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'new_lei = :new_lei'.
	 *
	 * @param newLei the new lei
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereNewLeiEquals(String newLei) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'create_date_time = :create_date_time'.
	 *
	 * @param datetime the datetime
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereCreateDateTimeEquals(Date datetime) throws MappingTradeLeiDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei table that match the criteria 'update_date_time = :update_date_time'.
	 *
	 * @param datetime the datetime
	 * @return the list
	 * @throws MappingTradeLeiDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLei> findWhereUpdateDateTimeEquals(Date datetime) throws MappingTradeLeiDaoException;


	public void updateUsiForSendId(String string, String usi);
	
	



}
