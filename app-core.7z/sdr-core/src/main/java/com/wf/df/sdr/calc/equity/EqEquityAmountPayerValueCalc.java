package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EqEquityAmountPayerValueCalc {

	@Calculation(value = Calc.eqEquityAmountPayerValueCalc, isPrototype = false)
	public String valuationDate(
			@DerivedFrom(value = Calc.eqIsWFBuyerCalc, isInternal = true) Boolean isWFBuyer,
			@DerivedFrom(value = Calc.eqUnderlyngAssetCptyParticipantIdCalc, isInternal = true) String cpty,
			@DerivedFrom(value = Calc.eqUnderlyngAssetWFParticipantIdCalc, isInternal = true) String us) {

		if(isWFBuyer)
			return cpty; //if WF is buyer, then Cpty is payer
		else
			return us;
				
	}
	
}
