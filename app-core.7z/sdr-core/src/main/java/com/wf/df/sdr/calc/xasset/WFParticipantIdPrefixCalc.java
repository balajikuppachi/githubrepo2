package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class WFParticipantIdPrefixCalc {

	@Calculation(value = Calc.wfParticipantIdPrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.DTCCOurParticipantId, isInternal = true) String participantId,
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String wellsFargoLEI		
			) {
		
		if (!Utils.IsNullOrNone(wellsFargoLEI)) {
			return (StringUtils.substringBefore(wellsFargoLEI, Constants.COLON));
		}
	
		if(!Utils.IsNullOrNone(participantId) && participantId.startsWith(Constants.DTCC)) 	
			return Constants.DTCC;
		
		throw new CalculationException("LEIFNF", "Fields not defined : [" + Stv.LEI_US + "] and [" + Stv.DTCCOurParticipantId + "]");
	}
}
