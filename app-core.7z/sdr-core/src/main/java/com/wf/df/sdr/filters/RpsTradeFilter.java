package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class RpsTradeFilter {
	@Autowired 
	DTCCUtils dtccUtils;
	
	@Autowired
	NotEligblePersister nep;
	
	Logger logger = Logger.getLogger(getClass());

	public boolean isRpsTrade(UnitOfWork uow) {
		logger.debug("RpsTradeFilter Called");
		CalculationContext cc = uow.getCalculationContext();
		Boolean isRpsTrade = cc.getValue(Calc.isRateReportedAsCreditCalc, Boolean.class);
		
		
		if(!isRpsTrade) {
			String srcProdType = cc.getString(Stv.CalypsoProductType);
			isRpsTrade = Constants.PRODUCT_TYPE_RISK_PARTICIPATION_SWAP.equals(srcProdType);
		}
			
				
		if(isRpsTrade){
			nep.save(uow, NotEligblePersister.RPS);
			//nep.deleteEODBuffer(uow.getUSI());
			logger.info("RPS trade not reportable");
			return false;
		}		
		return true;
	}
}