package com.wf.df.sdr.util;

import org.apache.commons.lang.StringUtils;

public final class GalaxyUtil {
	
	public final static String BASKET = "Basket";
	
	public static String getPeriodFromString (String periodWithTenor ) {
		String period = Constants.EMPTY_STRING;
		
		char[] charArr;
		if (!Utils.IsNullOrBlank(periodWithTenor)) {
			charArr = periodWithTenor.toCharArray();
			for (int i = 0; i < charArr.length; i++) {
				if (Character.isLetter(charArr[i]))
					period += charArr[i];
			}
		}
		return period;
	}
	
	public static String getTenorFromString (String periodWithTenor ) {
		String tenor = Constants.EMPTY_STRING;
		
		char[] charArr;
		if (!Utils.IsNullOrBlank(periodWithTenor)) {
			charArr = periodWithTenor.toCharArray();
			for (int i = 0; i < charArr.length; i++) {
				if (Character.isDigit(charArr[i]))
					tenor += charArr[i];
			}
		}
		return tenor;
	}
	
	
	public static boolean isWellsFargo(String value ) {
		
		String [] WFList = { "WBNA", "Wells Fargo", "WellsFargo", "WSIL" };

		if (!Utils.IsNullOrBlank(value)) {
			
			for (int x=0; x < WFList.length; x++) {
				if (StringUtils.containsIgnoreCase(value, WFList[x]))
					return true;
			}
		}
		return false;
	}
	
	public static String getDummyUSI(String tradeId){
		
		return "SDR_GENERATED_DUMMY_USI_" + tradeId;
		
	}
	
}
