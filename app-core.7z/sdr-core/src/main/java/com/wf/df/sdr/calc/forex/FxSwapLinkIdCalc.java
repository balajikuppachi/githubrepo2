package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class FxSwapLinkIdCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxSwapLinkIdCalc, isPrototype = false)
	public String calculate (
			@DerivedFrom(value=Constants.FOREX_SWAP_LEG, isInternal=true) String legType,
			@DerivedFrom(value=Constants.CALYPSO_TRADE_ID, isInternal=true) String tradeId){

		if (!Utils.IsNullOrBlank(legType)) {
			return tradeId;
		}
		
		return Constants.EMPTY_STRING;
	}

}
