package com.wf.df.sdr.calc.commodity.marshaller;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "boResponseDTO",
    "boPersistDTO"
})
@XmlRootElement(name = "bo_wrapper")
public class BoWrapperDTO {

	@XmlElementRef
    protected BoResponseDTO boResponseDTO;

    @XmlElementRef
    protected BoPersistDTO boPersistDTO;

	public BoResponseDTO getBoResponseDTO() {
		return boResponseDTO;
	}

	public void setBoResponseDTO(BoResponseDTO boResponseDTO) {
		this.boResponseDTO = boResponseDTO;
	}

	public BoPersistDTO getBoPersistDTO() {
		return boPersistDTO;
	}

	public void setBoPersistDTO(BoPersistDTO boPersistDTO) {
		this.boPersistDTO = boPersistDTO;
	}

    
}
