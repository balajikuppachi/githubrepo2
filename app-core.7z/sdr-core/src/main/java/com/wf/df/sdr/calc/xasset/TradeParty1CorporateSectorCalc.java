package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class TradeParty1CorporateSectorCalc {
	
	@Autowired
	DTCCUtils utils;
	
	@Calculation(value=Calc.tradeParty1CorporateSectorCalc, isPrototype=false)
	public String calcTradeParty1CorporateSector(@DerivedFrom(value=Stv.EMIR_US_TAXANOMY , isInternal = true) String emirUsTaxonomy)
	{
		if (!Utils.IsNullOrBlank(emirUsTaxonomy)) {
			String ret = utils.getEmirUsTaxonomy(emirUsTaxonomy.toUpperCase());
			
			if (null != ret)
				return ret;
		}
		return Constants.EMPTY_STRING;
	}
}
