package com.wf.df.sdr.calc.equity;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Utils;


@Component
public class EqSubmitterPrefixCalc {
	Logger logger = Logger.getLogger(this.getClass());

	@Value("${wf.lei.prefix}") String wfLEIPrefix;
	@Value("${party1.id.Equity}") String party1Id;
	
	@Calculation(value= Calc.eqSubmitterPrefixCalc, isPrototype = false)
	public String wFPartyCalc()	{
		
		//For Qa
		if (!Utils.IsNullOrBlank(party1Id)) {
			return party1Id.substring(0,4);
		}
		
		return wfLEIPrefix;
	}			
}
