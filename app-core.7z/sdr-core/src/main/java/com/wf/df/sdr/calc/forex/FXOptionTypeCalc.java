package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FXOptionTypeCalc {
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.fxOptionTypeCalc,isPrototype=true)
	public String calcOptionsellerPrefixCalc(
			@DerivedFrom(value = Stv.FXOptionIsBuyFlag, isInternal=false) String optionFlag)	{
		
		if(!Utils.IsNullOrBlank(optionFlag))
		{
			if(Constants.TRUE.equalsIgnoreCase(optionFlag))
				return Constants.PMINUS;
			else
				return Constants.CMINUS;
		}
		return Constants.EMPTY_STRING;
	}
}
