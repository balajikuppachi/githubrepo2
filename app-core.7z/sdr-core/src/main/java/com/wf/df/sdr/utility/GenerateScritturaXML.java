package com.wf.df.sdr.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

public class GenerateScritturaXML {

	private static String dbURL = "jdbc:sybase:Tds:170.13.182.44:12000/sdr";
	private static String user = "sdr_ro";
	private static String password = "";
	private static String tableName = "scrittura_msg";
	private static String tradeList = "5316415,5316416,5316460,5316462,5316487,5316519,8942649,8942650,8942651,9566221,9585624,9617538,9625300,9638776,9658122,9658123,9658124,9660493,9660494,9671198,9677072,9688890,9689741,9692022,9697192,9703993,9704794,9709411,9714291,9714441,9716083,9728466,9729214,9732618,9736596,9736803,9743701,9749291,9749300,9754031,9755491,9755516,9756360,9756494,9757203,9757238,9758725,9760577,9760954,9760988,9761076,9761093,9761846,9761847,9761867,9761892,9761923,9761998,9763544,9763610,9763625,9763651,9763666,9763670,9763681,9763684,9763686,9763692,9763698,9763705,9763710,9764401,9764413,9765101,9766538,9766584,9766586,9768117,9768150,9768151";
	private static Connection conn = null;
	private static Statement stmt = null;

	public static void main(String[] args) {
		//tradeId = JOptionPane.showInputDialog("Enter Trade Id :"); // Input
		
		createConnection();
		String[] tradeArr = tradeList.split(Constants.COMMA);
		for(String tradeId : tradeArr){
			selectTradeVersion(tradeId);
		}
		shutdown();
	}

	private static void shutdown() {
		try {
			if (stmt != null) 
				stmt.close();
			if (conn != null) {
				DriverManager.getConnection(dbURL + ";shutdown=true");
				conn.close();
			}
		} catch (SQLException sqlExcept) {

		}
	}
	
	private static void createConnection() {
		try {
			Class.forName("com.sybase.jdbc3.jdbc.SybDriver").newInstance();
			// Get a connection
			conn = DriverManager.getConnection(dbURL, user, password);
		} catch (Exception except) {
			except.printStackTrace();
		}
	}
	
	private static void selectTradeVersion(String tradeId) {
		try {
			stmt = conn.createStatement();
			ResultSet results = stmt.executeQuery("SELECT TOP 1 trade_id,trade_version,source_system,msg FROM "
					+ tableName + " WHERE trade_id = '" + tradeId + "' ORDER BY id DESC");

			//ResultSetMetaData rsmd = results.getMetaData();
			//int numberCols = rsmd.getColumnCount();
			String msg = null;
			while (results.next()) {
				String tradeVersion = results.getString("trade_version");
				String sysName = results.getString("source_system");
				msg = results.getString("msg");
				
				System.out.println(tradeId+"."+tradeVersion + "\t\t"+ sysName + "\t\t" );
			}
			
			if(!Utils.IsNullOrBlank(msg))
				createFile(msg, tradeId);
				
			results.close();
			stmt.close();
		} catch (SQLException sqlExcept) {
			sqlExcept.printStackTrace();
		}
	}

	private static void createFile(String bufferData, String tradeId) {
		try {
			
			String fileName = tradeId + ".xml";
			File f = new File(fileName);
			int len = bufferData.length();
			if (!f.exists()) {
				f.createNewFile();
				// f.createTempFile(tradeId, currentTimestamp.toString(), f1);
				FileWriter fstream = new FileWriter(fileName);
				BufferedWriter out = new BufferedWriter(fstream);
				out.write(bufferData, 0, len);
				out.close();
				System.out.println("File created successfully. "+fileName);
			}

			// JOptionPane.showMessageDialog(null, bufferData); //Output
		} catch (Exception except) {
			except.printStackTrace();
		}

	}
		
	
}
