package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EqBuyerPrefixCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqBuyerPrefixCalc, isPrototype = false)
	public String buyer(
			@DerivedFrom(value = Calc.eqIsWFBuyerCalc, isInternal = true) Boolean isWFBuyer,
			@DerivedFrom(value = Calc.eqCptyParticipantIdPrefixCalc, isInternal = true) String cpty,
			@DerivedFrom(value = Calc.eqWFParticipantIdPrefixCalc, isInternal = true) String us) {

		if(isWFBuyer)
			return us; 
		else
			return cpty;		
	}
}
