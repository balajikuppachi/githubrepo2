package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class ReportingPartyCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.reportingPartyCalc, isPrototype = false)
	public boolean isReportingPartyValid(
			@DerivedFrom(value = Stv.REPORTING_PARTY, isInternal = true) String reportingParty,
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String wellsFargoLEI,
			@DerivedFrom(value = Calc.isEmirTradeCalc, isInternal = true) boolean isEmirTrade) {
		
		if (Utils.IsNullOrBlank(reportingParty) || "NONE".equalsIgnoreCase(reportingParty)) {		
			logger.info("ReportingPartyInvalid: Reporting Party is missing or not known");
			return false;
		}
		
		if (Utils.IsNullOrBlank(wellsFargoLEI) || "NONE".equalsIgnoreCase(wellsFargoLEI)) {		
			logger.info("STV.LEI_US is missing: WellsFargoLEI is missing or not known");
			return false;
		}
		if (reportingParty.equalsIgnoreCase(wellsFargoLEI)) {
			// We are the reporting party continue processing
			logger.debug("Wells the reporting Party. Its to be reported by " + reportingParty);
			return true;
		}
		if(isEmirTrade){
			// We are the Not reporting party, but continue processing for EMIR trade
			logger.debug("Wells the not reporting Party For this trade, but it is EMIR trade. Its to be reported by " + reportingParty);
			return true;
		}
			
		
		return false;
	}
}
