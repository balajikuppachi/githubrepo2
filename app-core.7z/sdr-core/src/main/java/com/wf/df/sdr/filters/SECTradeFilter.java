package com.wf.df.sdr.filters;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;

@Component(value="secFilter")
public class SECTradeFilter {
	@Autowired 
	DTCCUtils dtccUtils;
	
	@Autowired
	NotEligblePersister nep;
	
	Logger logger = Logger.getLogger(getClass());

	public boolean isSECTrade(UnitOfWork uow) {
		logger.debug("SECTradeFilter Called");
		CalculationContext cc = uow.getCalculationContext();
		String assetClass = cc.getValue(Calc.dtccAssetClassCalc, String.class);
		String upi=null;
		
		if(Constants.ASSET_CLASS_CREDIT.equals(assetClass))
			upi = cc.getValue(Calc.crProductCalc, String.class);
		
		if(Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
			upi = cc.getValue(Calc.productCalc, String.class);
		
		String jurisdiction = dtccUtils.getJurisdiction(upi);
		//SEC trade shouldn't be reported
		if(StringUtils.contains(jurisdiction, "SEC")){
			nep.save(uow, NotEligblePersister.SEC);
			//nep.deleteEODBuffer(uow.getUSI());
			logger.debug("SEC trade not reportable");
			return false;
		}	
		
		return true;
	}
}
