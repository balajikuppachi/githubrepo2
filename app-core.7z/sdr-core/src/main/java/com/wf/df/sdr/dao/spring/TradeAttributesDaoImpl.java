package com.wf.df.sdr.dao.spring;


import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.TradeAttributesDao;
import com.wf.df.sdr.dto.TradeAttributes;
import com.wf.df.sdr.exception.dao.TradeAttributesDaoException;

public class TradeAttributesDaoImpl extends AbstractDAO implements ParameterizedRowMapper<TradeAttributes>, TradeAttributesDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(TradeAttributes dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status	,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,? )",dto.getSendId(),dto.getTradeId(),dto.getTradeVersion(),dto.getAction(),dto.getAssetClass(),dto.getUpi(),dto.getNotionalCurrency(),dto.getNotionalAmount(),dto.getConfirmationDatetime(),dto.getUsi(),dto.getReportingSdr(),dto.getReportingJurisdiction(),dto.getEconfirmFlag(),dto.getConfirmStatus(),dto.getConfirmBuyer(),dto.getConfirmSeller(),dto.getUpdateDatetime(), dto.getUti(), dto.getFcmCpty(), dto.getFeeFcmCpty(),dto.getSrcExecDatetime(),dto.getTlcEventExecDatetime(),dto.getTradeUpdateDatetime(),dto.getMsgUpdateDatetime(),dto.getCptyClassification());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return TradeAttributes
	 */
	public TradeAttributes mapRow(ResultSet rs, int row) throws SQLException
	{
		TradeAttributes dto = new TradeAttributes();
		dto.setSendId( rs.getBigDecimal( 1 ) );
		dto.setTradeId( rs.getString( 2 ) );
		dto.setTradeVersion( rs.getString( 3 ) );
		dto.setAction( rs.getString( 4 ) );
		dto.setAssetClass( rs.getString( 5 ) );
		dto.setUpi( rs.getString( 6 ) );
		dto.setNotionalCurrency( rs.getString( 7 ) );
		dto.setNotionalAmount( rs.getString( 8 ) );
		dto.setConfirmationDatetime( rs.getTimestamp(9 ) );
		dto.setUsi( rs.getString( 10 ) );
		dto.setReportingSdr( rs.getString( 11 ) );
		dto.setReportingJurisdiction( rs.getString( 12 ) );
		dto.setEconfirmFlag(rs.getString( 13 ) );
		dto.setConfirmStatus(rs.getString( 14 ) );
		dto.setConfirmBuyer( rs.getString( 15 ) );
		dto.setConfirmSeller(rs.getString( 16 ) );
		dto.setUpdateDatetime( rs.getTimestamp(17 ) );
		dto.setUti( rs.getString(18 ) );
		dto.setFcmCpty( rs.getString(19));
		dto.setFeeFcmCpty( rs.getString(20));
		dto.setSrcExecDatetime( rs.getTimestamp(21));
		dto.setTlcEventExecDatetime( rs.getTimestamp(22));
		dto.setTradeUpdateDatetime( rs.getTimestamp(23));
		dto.setMsgUpdateDatetime( rs.getTimestamp(24));
		dto.setCptyClassification(rs.getString(25));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "trade_attributes";
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria ''.
	 */
	@Transactional
	public List<TradeAttributes> findAll() throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereSendIdEquals(long sendId) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'trade_id = :tradeId'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereTradeIdEquals(String tradeId) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE trade_id = ? ORDER BY trade_id", this,tradeId);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'trade_version = :tradeVersion'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereTradeVersionEquals(String tradeVersion) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE trade_version = ? ORDER BY trade_version", this,tradeVersion);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'action = :action'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereActionEquals(String action) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE action = ? ORDER BY action", this,action);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'asset_class = :assetClass'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereAssetClassEquals(String assetClass) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE asset_class = ? ORDER BY asset_class", this,assetClass);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'upi = :upi'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereUpiEquals(String upi) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE upi = ? ORDER BY upi", this,upi);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'notional_currency = :notionalCurrency'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereNotionalCurrencyEquals(String notionalCurrency) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE notional_currency = ? ORDER BY notional_currency", this,notionalCurrency);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'notional_amount = :notionalAmount'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereNotionalAmountEquals(float notionalAmount) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE notional_amount = ? ORDER BY notional_amount", this,notionalAmount);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirmation_datetime = :confirmationDatetime'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereConfirmationDatetimeEquals(Date confirmationDatetime) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE confirmation_datetime = ? ORDER BY confirmation_datetime", this,confirmationDatetime);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereUsiEquals(String usi) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'reporting_sdr = :reportingSdr'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereReportingSdrEquals(String reportingSdr) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE reporting_sdr = ? ORDER BY reporting_sdr", this,reportingSdr);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'reporting_jurisdiction = :reportingJurisdiction'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereReportingJurisdictionEquals(String reportingJurisdiction) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE reporting_jurisdiction = ? ORDER BY reporting_jurisdiction", this,reportingJurisdiction);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereUpdateDatetimeEquals(Date updateDatetime) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE update_datetime = ? ORDER BY update_datetime", this,updateDatetime);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	@Transactional
	public List<TradeAttributes> findPreviousRecordsForTrade(String tradeId, String assetClass, String sdrRepository) throws TradeAttributesDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE trade_id = ? and asset_class= ? and reporting_sdr = ? ORDER BY send_id DESC", this, tradeId, assetClass, sdrRepository);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
	}
	
	@Transactional
	public List<TradeAttributes> findPreviousRecordsForUSI(String usi, String assetClass) throws TradeAttributesDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE usi = ? and asset_class= ? ORDER BY send_id DESC", this, usi, assetClass);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
	}

	@Transactional
	public void updateUsiForSendId(BigDecimal sendId, String newUsi){
		
		String query = "UPDATE  "+getTableName()+" SET usi = ? WHERE send_id = ?";
		jdbcTemplate.update(query, newUsi, sendId) ;
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'econfirm_flag = :econfirmFlag'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereEconfirmFlag(boolean econfirmFlag)throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE econfirm_flag = ? ORDER BY econfirm_flag", this,econfirmFlag);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirm_status = :confirmStatus'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereConfirmStatus(String confirmStatus) throws TradeAttributesDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE confirm_status = ? ORDER BY confirm_status", this,confirmStatus);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirm_buyer = :confirmBuyer'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereConfirmBuyer(String confirmBuyer)	throws TradeAttributesDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE confirm_buyer = ? ORDER BY confirm_buyer", this,confirmBuyer);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirm_seller = :confirmSeller'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereConfirmSeller(String confirmSeller) throws TradeAttributesDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE confirm_seller = ? ORDER BY confirm_seller", this,confirmSeller);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'uti = :uti'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereUtiEquals(String uti) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE uti = ? ORDER BY uti", this,uti);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'fcmCpty = :fcmCpty'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereFcmCptyEquals(String fcmCpty) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE fcm_cpty = ? ORDER BY fcm_cpty", this,fcmCpty);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'fcmCpty = :fcmCpty'.
	 */
	@Transactional
	public List<TradeAttributes> findWhereFeeFcmCptyEquals(String feeFcmCpty) throws TradeAttributesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trade_id, trade_version, action, asset_class, upi, notional_currency, notional_amount, confirmation_datetime, usi, reporting_sdr, reporting_jurisdiction, econfirm_flag	,confirm_status		,confirm_buyer	,confirm_seller	,update_datetime, uti, fcm_cpty , fee_fcm_cpty,src_exec_datetime,tlc_event_exec_datetime,trade_update_datetime,message_update_dateTime, cpty_classification  FROM " + getTableName() + " WHERE fee_fcm_cpty = ? ORDER BY fee_fcm_cpty", this,feeFcmCpty);
		}
		catch (Exception e) {
			throw new TradeAttributesDaoException("Query failed", e);
		}
		
	}
}
