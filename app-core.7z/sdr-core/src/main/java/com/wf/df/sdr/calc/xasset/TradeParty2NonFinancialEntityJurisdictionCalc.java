package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class TradeParty2NonFinancialEntityJurisdictionCalc {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value =  Calc.tradeParty2NonFinancialEntityJurisdictionCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value=Stv.EMIR_CP_FINANCIALENTITY, isInternal = true) String emirCPFinEntity,
			@DerivedFrom(value=Stv.LEI_CP_FINANCIALENTITY, isInternal = true) String leiCpFinEntity,
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
            @DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
            @DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable){
				
		if (isDtccDelegatedTrade||isEmirDelegatedTrade||isEmirReportable){
			if(Constants.FALSE.equals(emirCPFinEntity))
				return Constants.ESMA;
		}
			
		 return Constants.EMPTY_STRING;

	}

}
