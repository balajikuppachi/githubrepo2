package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxSrcTLCEventCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value=Calc.fxSrcTLCEventCalc, isPrototype=false)
	public String srcEvent (
		@DerivedFrom(value=Calc.srcTLCEventCalc, isInternal=true) String srcTLCEvent)
	{
			return srcTLCEvent;
	}
}
