package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.support.SybasePagingQueryProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Repository
public class HistoricalBufferStoreExtnDao 
{
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	@Qualifier("simulatorJdbcTemplate")
	private JdbcTemplate simulatorJdbcTemplate;
	
	private String selectClause="SELECT s.send_id";
	private String cftcFromClause="FROM eod_buffer_store s, input_msg_store i";
	private String nonCftcFromClause="FROM eod_buffer_store_emir s, input_msg_store i";
	
	private String cftcWhereClause="WHERE s.send_id = i.send_id AND s.usi = i.usi AND datalength(s.msg_buffer) > 0 and i.send_id >= ? and i.send_id <= ? AND "
			+ "src_trade_status in ('VERIFIED','DAY_VERIFIED','PENDING','DAY_PENDING','CH_TOBE_VER','TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','DAY_FO_REVIEW','FO_REVIEW','MO_REVIEW','DAY_MO_REVIEW','DAY_AMENDED') "
			+ "AND i.src_asset_class = ? AND ( msg_type='Snapshot' OR msg_type='Valuation') AND s.sdr_repository = ?";
	
		
	private static String cftcGalaxyWhereClause =  "WHERE i.src_tlc_event NOT IN ('Full Unwind','Cancelled') AND "
			+ "s.send_id = i.send_id AND s.usi = i.usi and i.send_id>= ? and i.send_id<= ? AND datalength(s.msg_buffer) > 0	AND i.src_asset_class = ? AND ( msg_type='Snapshot' OR msg_type='Valuation') and i.sdr_repository=?";

	private static String emirWhereClause=  "WHERE s.send_id = i.send_id AND s.uti = i.uti AND s.is_duplicate=0 AND s.is_buffer_eligible=1 and i.send_id>= ? and i.send_id<= ? AND datalength(s.msg_buffer) > 0 "
			+ "AND src_trade_status in ('VERIFIED','DAY_VERIFIED','PENDING','CH_TOBE_VER','TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','DAY_FO_REVIEW','FO_REVIEW','DAY_PENDING','MO_REVIEW','DAY_MO_REVIEW','TRADER_REVIEW','DAY_TRADER_REVIEW','PARTIAL_TERM','TERMINATED','TERMINATED_SLET','SHADOW_TERM','ASSIGNED','DAY_ASSIGNED','NC_PENDING','DAY_TERMINATED','DAY_AMENDED','DAY_TRADER_REV') "
			+ "AND NOT EXISTS (select * from input_msg_store ims where ims.src_trade_id = s.trade_id and src_trade_status in ('PARTIAL_ASSIGNED','DAY_PARTASSIGNED','CANCEL_SDR')) AND i.src_asset_class = ? AND ( msg_type='Snapshot' OR msg_type='Valuation') AND s.sdr_repository = ?";
			

	private static String cadWhereClause=" WHERE s.send_id = i.send_id AND s.uti = i.usi AND s.is_duplicate=0 AND s.is_buffer_eligible=1 AND datalength(s.msg_buffer) > 0 and i.send_id>= ? and i.send_id<= ?	"
			+ "AND src_trade_status in ('VERIFIED','DAY_VERIFIED','PENDING','CH_TOBE_VER','TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','DAY_FO_REVIEW','FO_REVIEW','DAY_PENDING','MO_REVIEW','DAY_MO_REVIEW','TRADER_REVIEW','DAY_TRADER_REVIEW','PARTIAL_TERM','TERMINATED','TERMINATED_SLET','SHADOW_TERM','ASSIGNED','DAY_ASSIGNED','NC_PENDING','DAY_TRADER_REV') "
			+ "AND NOT EXISTS (select * from input_msg_store ims where ims.src_trade_id = s.trade_id and src_trade_status in ('PARTIAL_ASSIGNED','DAY_PARTASSIGNED','CANCEL_SDR'))	AND i.src_asset_class = ? AND ( msg_type='Snapshot' OR msg_type='Valuation') AND s.sdr_repository = ?";


	private static String cadGalaxyWhereClause="WHERE i.src_tlc_event NOT IN ('Full Unwind','Cancelled') AND s.send_id = i.send_id AND s.uti = i.usi AND s.is_duplicate=0 AND s.is_buffer_eligible=1  AND datalength(s.msg_buffer) > 0	and i.send_id>= ? and i.send_id<= ? "
			+ "AND i.src_asset_class = ?  AND ( msg_type='Snapshot' OR msg_type='Valuation')	and s.sdr_repository = ?";	
					
	private String sortKey="s.send_id";
	
	
	public List<String> findLiveTrades(String assetClass,String repository, String start_sendid, String end_sendid) 
	{
		logger.info("Entered findLiveTrades() method , AssetClass:"+assetClass+", SdrRepository:"+repository);
		
		JdbcPagingItemReader<String> itemReader = null;
		List<String>  xmlList=new ArrayList<String>();
		try 
		{
			int fetchsize=10;
			SybasePagingQueryProvider  queryProvider = new SybasePagingQueryProvider(); 
			queryProvider.setSelectClause(selectClause);
			queryProvider.setSortKey(sortKey);
			queryProvider.setAscending(true);
		
			if((Constants.DTCC.equalsIgnoreCase(repository)|| Constants.CME.equalsIgnoreCase(repository)) && !Constants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass))
			{
				queryProvider.setFromClause(cftcFromClause);
				queryProvider.setWhereClause(cftcWhereClause);
			}else	
			if((Constants.DTCC.equalsIgnoreCase(repository) || Constants.CME.equalsIgnoreCase(repository)) && Constants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass))
			{
				queryProvider.setFromClause(cftcFromClause);
				queryProvider.setWhereClause(cftcGalaxyWhereClause );
			}else 
			if(Constants.CAD.equalsIgnoreCase(repository) && !Constants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass))
			{
	
				queryProvider.setFromClause(nonCftcFromClause);
				queryProvider.setWhereClause(cadWhereClause );
			}else			
			if(Constants.CAD.equalsIgnoreCase(repository) && Constants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass))
			{
	
				queryProvider.setFromClause(nonCftcFromClause);
				queryProvider.setWhereClause(cadGalaxyWhereClause);
			}else	
			if(Constants.EMIR.equalsIgnoreCase(repository) )
			{
				queryProvider.setFromClause(nonCftcFromClause);
				queryProvider.setWhereClause(emirWhereClause);
			}
			
		
			Map<String, Object> paramMap = new  HashMap<String, Object>();
			paramMap.put("1", new BigDecimal(start_sendid));
			paramMap.put("2", new BigDecimal(end_sendid));
			paramMap.put("3", assetClass);
			paramMap.put("4", repository);
			
			itemReader=new JdbcPagingItemReader<String>();
			itemReader.setParameterValues(paramMap);
			itemReader.setDataSource(simulatorJdbcTemplate.getDataSource());
			itemReader.setPageSize(fetchsize);
			itemReader.setFetchSize(fetchsize);
			itemReader.setQueryProvider(queryProvider);
			itemReader.setRowMapper(new DataRowMapper());
			itemReader.afterPropertiesSet();
			
			
			ExecutionContext ec=new ExecutionContext();
			itemReader.open(ec);
		
			Object obj=new Object();
			while(!Utils.IsNullOrBlank(obj))
			{
				obj=itemReader.read();
				if(!Utils.IsNullOrBlank(obj))
					xmlList.add((String)obj);
				
			}
			
		} catch (UnexpectedInputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			itemReader.close();
			xmlList=new ArrayList<String>(new HashSet<String>(xmlList));
		}
		
		return xmlList;
	}
	
	
	class DataRowMapper implements RowMapper<String> {
		

		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			return String.valueOf(rs.getBigDecimal(1));
		}
	}	
}
