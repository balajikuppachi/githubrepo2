package com.wf.df.sdr.filters;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.exception.FilterException;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class ReportingPartyFilter {

	@Autowired
	NotEligblePersister nep;
	@Value("${reporting.party}") String defaultReportingParty;
	@Value("${wf.affiliatebank.leis}") String affliateBankLEIs;
	
	Logger log = Logger.getLogger(getClass());

	public boolean isTradeEligible(UnitOfWork uow) {
		
		CalculationContext cc = uow.getCalculationContext();
		boolean isClearTrade = cc.getValue(Calc.clearedTradeCalc, Boolean.class);
		String leiUs = cc.getValue(Stv.LEI_US, String.class);
		
		leiUs=Utils.getElementAtIndex(leiUs, 1, Constants.COLON);
		
		// Check for Cleared Trades first
		if (isClearTrade) 
			return true;
		
		// Check for reportable trades
		String reportingParty = cc.getValue(Stv.REPORTING_PARTY, String.class);
		if (Utils.IsNullOrBlank(reportingParty))
			throw new FilterException("ReportingPartyInvalid", "Reporting Party is missing or not known");
		
		boolean isReportableByWells = cc.getValue(Calc.reportingPartyCalc, Boolean.class);
		// Reportable party is wells
		if (isReportableByWells){
			
			if(!StringUtils.contains(affliateBankLEIs, leiUs))
				throw new FilterException("ReportingPartyInvalid", "LEI_US value is not Bank or Affiliate LEI. Cannot be reported.");
			return true;
			
		}
			

		// Save it in NotSendPersister
		nep.save(uow, NotEligblePersister.WFNRP);		
		//nep.deleteEODBuffer(uow.getUSI());		
		return false;
	}
	
	/**
	 * 
	 * @param uow
	 * @return
	 */
	public boolean isNotReportableTradeEligible(UnitOfWork uow){
		
		CalculationContext cc = uow.getCalculationContext();
		
		// Check for reportable trades
		String reportingParty = cc.getValue(Stv.REPORTING_PARTY, String.class);
		
		reportingParty = (!Utils.IsNullOrBlank(reportingParty) ? reportingParty : cc.getValue(Stv.LEI_CP, String.class));
		if(Utils.IsNullOrBlank(reportingParty))
				reportingParty = defaultReportingParty.trim();
			
		
		if (Utils.IsNullOrBlank(reportingParty.trim()))
			throw new FilterException("ReportingPartyInvalid", "Reporting Party is missing or not known");
		
		boolean isReportableByWells = cc.getValue(Calc.reportingPartyCalc, Boolean.class);
		// Reportable party is not wells
		if (!isReportableByWells)
			return true;

		
		// Save it in NotSendPersister
		//nep.save(uow, NotEligblePersister.WFNRP);		
		//nep.deleteEODNotReportingBuffer(uow.getUSI());		
		return false;
	}
	
}
