package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.EndurValuationStore;
import com.wf.df.sdr.exception.dao.EndurValuationStoreDaoException;

public interface EndurValuationStoreDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(EndurValuationStore dto);

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria ''.
	 */
	public List<EndurValuationStore> findAll() throws EndurValuationStoreDaoException;

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'send_id = :sendId'.
	 */
	public List<EndurValuationStore> findWhereSendIdEquals(BigDecimal sendId) throws EndurValuationStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'buffer_id = :bufferId'.
	 */
	public List<EndurValuationStore> findWhereBufferIdEquals(BigDecimal bufferId) throws EndurValuationStoreDaoException;	

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'valuation_type = :valuationType'.
	 */
	public List<EndurValuationStore> findWhereValuationTypeEquals(String valuationType) throws EndurValuationStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'valuation_date = :valuationDate'.
	 */
	public List<EndurValuationStore> findWhereValuationDateEquals(String valuationDate) throws EndurValuationStoreDaoException;

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<EndurValuationStore> findWhereCreateDatetimeEquals(Date createDatetime) throws EndurValuationStoreDaoException;

}
