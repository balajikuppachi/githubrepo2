package com.wf.df.sdr.calc.commodity;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.meta.CollateralService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class CmCollateralizedCalc {

	@Autowired
	CollateralService collateralService;
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value=Calc.cmCollateralizedCalc, isPrototype = false)
	public String clearingHouse(
			@DerivedFrom(value=Stv.DCO_GIVEUP, isInternal=true) String dco,
			@DerivedFrom(value=Stv.CounterpartyShortName, isInternal=true) String shortName,
			@DerivedFrom(value=Stv.BusinessAccountId, isInternal=true) String businessAccountId,
			@DerivedFrom(value=Stv.CID_ID, isInternal=true) String equityCidId,		
			@DerivedFrom(value=Calc.clearedTradeCalc,isInternal=true) boolean clearTrade,
			@DerivedFrom(value=Calc.dtccAssetClassCalc,isInternal=true) String assetClass, 
			@DerivedFrom(value=Stv.TradeId,isInternal=true) String tradeID ){
		//TODO- Instead of clearTrade, if  DCO_GIVEUP, default to FullyCollateralized
		if(!Utils.IsNullOrNone(dco))
			return Constants.FullyCollateralized;
		// If its ONLY CLEARED! then its FullyCollateralized
		if(clearTrade){
			return Constants.FullyCollateralized;
		}
		else {			
			return collateralService.getDTCCCollaterlizedValue(equityCidId,shortName,businessAccountId,assetClass, tradeID);			
		}
		
	}
}