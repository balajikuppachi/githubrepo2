package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqReportingJurisdictionCalc {
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqReportingJurisdictionCalc, isPrototype = false)
	public String compute(@DerivedFrom(value = Calc.currentReportingJurisdictionCalc, isInternal = true) String diction,
			@DerivedFrom(value = Stv.Reporting_Jurisdiction, isInternal = true) String olddiction) {
		
		if(Utils.IsNullOrBlank(diction))
			diction=olddiction;
		
		if(diction !=null && (diction.contains("CFTC") || diction.contains("CA.")))
			return diction;	

		
		
		
		return Constants.EMPTY_STRING;
	
	}
}
