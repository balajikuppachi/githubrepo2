package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class FxMasterAgreementDateCalc {


	@Calculation(value = Calc.fxMasterAgreementDateCalc, isPrototype=false)
	public String calcAgreementDate(
			@DerivedFrom(value=Calc.intragroupCalc, isInternal=true) String intraGroup) {
		
		/*if(Constants.TRUE.equalsIgnoreCase(intraGroup))
			return Constants.AGREEMNT_DATE_2002;*/
		
		return Constants.EMPTY_STRING;
		
		
	}
}
