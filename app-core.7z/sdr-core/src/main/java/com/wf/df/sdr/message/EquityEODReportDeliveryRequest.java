package com.wf.df.sdr.message;

import java.io.File;

public class EquityEODReportDeliveryRequest {

	private EquityEODReportGenerationRequest generationRequest;
	private File file;

	public EquityEODReportDeliveryRequest(EquityEODReportGenerationRequest generationRequest, File file) {
		this.generationRequest = generationRequest;
		this.file = file;
	}

	public EquityEODReportGenerationRequest getReportGenerationRequest() {
		return generationRequest;
	}

	public File getFile() {
		return file;
	}
	
}
