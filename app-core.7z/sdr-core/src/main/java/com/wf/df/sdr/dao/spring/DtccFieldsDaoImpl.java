package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.DtccFieldsDao;
import com.wf.df.sdr.dto.DtccFields;
import com.wf.df.sdr.exception.dao.DtccFieldsDaoException;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class DtccFieldsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<DtccFields>, DtccFieldsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(DtccFields dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( field_id, field_name, field_comments, field_type, create_datetime ) VALUES ( ?, ?, ?, ?, ? )",dto.getFieldId(),dto.getFieldName(),dto.getFieldComments(),dto.getFieldType(),dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return DtccFields
	 */
	public DtccFields mapRow(ResultSet rs, int row) throws SQLException
	{
		DtccFields dto = new DtccFields();
		dto.setFieldId( new Integer( rs.getInt(1) ) );
		dto.setFieldName( rs.getString( 2 ) );
		dto.setFieldComments( rs.getString( 3 ) );
		dto.setFieldType( rs.getString( 4 ) );
		dto.setCreateDatetime( rs.getTimestamp(5 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "dtcc_fields";
	}

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria ''.
	 */
	@Transactional
	public List<DtccFields> findAll() throws DtccFieldsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT field_id, field_name, field_comments, field_type, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new DtccFieldsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_id = :fieldId'.
	 */
	@Transactional
	public List<DtccFields> findWhereFieldIdEquals(Integer fieldId) throws DtccFieldsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT field_id, field_name, field_comments, field_type, create_datetime FROM " + getTableName() + " WHERE field_id = ? ORDER BY field_id", this,fieldId);
		}
		catch (Exception e) {
			throw new DtccFieldsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_name = :fieldName'.
	 */
	@Transactional
	public List<DtccFields> findWhereFieldNameEquals(String fieldName) throws DtccFieldsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT field_id, field_name, field_comments, field_type, create_datetime FROM " + getTableName() + " WHERE field_name = ? ORDER BY field_name", this,fieldName);
		}
		catch (Exception e) {
			throw new DtccFieldsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_comments = :fieldComments'.
	 */
	@Transactional
	public List<DtccFields> findWhereFieldCommentsEquals(String fieldComments) throws DtccFieldsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT field_id, field_name, field_comments, field_type, create_datetime FROM " + getTableName() + " WHERE field_comments = ? ORDER BY field_comments", this,fieldComments);
		}
		catch (Exception e) {
			throw new DtccFieldsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_type = :fieldType'.
	 */
	@Transactional
	public List<DtccFields> findWhereFieldTypeEquals(String fieldType) throws DtccFieldsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT field_id, field_name, field_comments, field_type, create_datetime FROM " + getTableName() + " WHERE field_type = ? ORDER BY field_type", this,fieldType);
		}
		catch (Exception e) {
			throw new DtccFieldsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<DtccFields> findWhereCreateDatetimeEquals(Date createDatetime) throws DtccFieldsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT field_id, field_name, field_comments, field_type, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new DtccFieldsDaoException("Query failed", e);
		}
		
	}

}
