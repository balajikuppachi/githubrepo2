package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component(value = "isInternalTradeFilter")
public class IsInternalTradeFilter {

	@Autowired
	NotEligblePersister nep;

	Logger log = Logger.getLogger(getClass());

	public boolean isNotInternalTrade(UnitOfWork uow) {
		CalculationContext cc = uow.getCalculationContext();

		String ourLEI = cc.getValue(Stv.LEI_US, String.class);
		String cptyLEI = cc.getValue(Stv.LEI_CP, String.class);

		if (!Utils.IsNullOrNone(ourLEI) && !Utils.IsNullOrNone(cptyLEI)) {
			if (ourLEI.equalsIgnoreCase(cptyLEI)) {
				log.info("LEI_US & LEI_CP are same : US->" + ourLEI + ", CP->"+ cptyLEI);
				nep.save(uow, NotEligblePersister.SDRInternalTrade);
				//nep.deleteEODBuffer(uow.getUSI());
				return false;
			}
		}
		return true;
	}
}
