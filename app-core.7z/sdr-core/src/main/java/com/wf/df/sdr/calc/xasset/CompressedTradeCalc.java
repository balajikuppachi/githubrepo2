package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class CompressedTradeCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value = Calc.compressedTradeCalc, isPrototype=false)
	public String calcCompressedTrade(
			@DerivedFrom(value = Stv.PORTFOLIO_COMPRESSION, isInternal=true)String compression,
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable) {
		
		
		logger.debug("calling------------ CompressedTradeCalc ");
		if(isDtccDelegatedTrade||isEmirDelegatedTrade||isEmirReportable){
			if(!Utils.IsNullOrBlank(compression))
			{
				return Constants.TRUE;
			}
			
			return Constants.FALSE;	
			
	}
		return Constants.EMPTY_STRING;
	}
}
