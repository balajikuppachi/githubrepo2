package com.wf.df.sdr.filters.utility;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.utility.UtilityNotEligblePersister;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component(value="utilitySdrEligibleFilter")
public class UtilitySDREligibleFilter {

	@Autowired
	UtilityNotEligblePersister nep;
	
	Logger log = Logger.getLogger(getClass());

	public boolean isSDREligible(UnitOfWork uow) {
		CalculationContext cc = uow.getCalculationContext();
		String sdrEligibleFlag = cc.getValue(Stv.SDR_ELIGIBLE, String.class);
		
		if(Constants.FALSE.equalsIgnoreCase(sdrEligibleFlag)){
			log.debug("SDR Eligible came in as :" + sdrEligibleFlag);
			// Save it in NotSendPersister
			nep.save(uow, UtilityNotEligblePersister.SDRNonEligible);
			//nep.deleteEODBuffer(uow.getUSI());
			return false;
		} 
		return true;
	}
	
}
