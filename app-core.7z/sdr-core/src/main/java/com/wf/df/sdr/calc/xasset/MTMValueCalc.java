package com.wf.df.sdr.calc.xasset;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class MTMValueCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.mtmValueCalc, isPrototype = false)
	public String mtmValue(
			@DerivedFrom(value = Stv.SdrNPVAmount, isInternal=true) String value){
		
		if(!Utils.IsNullOrBlank(value)){
			
			try {
				return formatter.formatDecimal(parser.parseNumber(value));
			} catch (ParseException e) {
				throw new CalculationException("Parse Exception", Stv.SdrNPVAmount + " can not be null. This is an injected value by Valuation Process");
			}
		}
		else {

			// This field wll be populated at EOD with latest data from CDBO
			return Constants.ALLOW_EMPTY_ON_REQD;
			// Required for Valuation, should throw an exception
			//throw new CalculationException("RFNF", Stv.SdrNPVAmount + " can not be null. This is an injected value by Valuation Process");
		}
	}
}
