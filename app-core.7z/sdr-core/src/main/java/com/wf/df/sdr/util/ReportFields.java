package com.wf.df.sdr.util;

public class ReportFields {

	public static final String ACTION = "Action";
	public static final String TradeParty1TransactionId = "Trade Party 1 Transaction Id";
	public static final String EventId = "Event ID";
	public static final String TransactionType = "Transaction Type";
	public static final String AsOfDateTime = "As of Date Time";
	public static final String MtmValue = "MTM Value";
	public static final String MtmCurrency = "MTM Currency";
	public static final String ValuationDateTime = "Valuation Datetime";
	public static final String TradeDate = "Trade Date";
	public static final String Leg1NotionalCurrency = "Notional Currency - leg 1";
	public static final String Leg1NotionalAmount = "Notional Amount - leg 1 or Notional Amount (FRA)";
	public static final String Leg2NotionalCurrency = "Notional Currency - leg 2";
	public static final String Leg2NotionalAmount = "Notional Amount - leg 2";
	public static final String ProductIDValue = "Product ID Value";
	public static final String NotionalAmount = "Notional Amount 1";
	public static final String Leg1ExoticNotionalAmount = "Exotic - Notional amount - leg1";
	public static final String Leg2ExoticNotionalAmount = "Exotic - Notional amount - leg2";	
	public static final String DocumentID = "Document ID";
	public static final String SendTo = "sendTo";
	public static final String IRLastSSField="Data Submitter Message Id";
	public static final String CRLastSSField="Data Submitter Message ID";
	public static final String FxLastSSField ="Trade Party 2 CFTC Financial Entity Status";
	
	public static final String IRLastValField="Additional Comments";
	public static final String CRLastValField="Additional Comments";
	public static final String FxLastValField ="Trade Party 2 CFTC Financial Entity Status";
	public static final String LifeCycleEvent="Lifecycle Event";
	public static final String ReconProductIdValue="Product ID Prefix:Product ID Value";
	public static final String AgreementDate = "Agreement Date";
	public static final String TradeParty1TransactionIdOutref = "Trade Party 1 Transaction Id (OurRef)";
	public static final String Party1TransactionID="Party 1 Transaction ID";
	
	
	public static final String CmeMtm = "MTM";
	public static final String CmeMtmCurrency = "MTMCurrency";
	public static final String CmeValuationDateTime = "ValuationDate";
	public static final String CmeComment = "*Comment";
	
	public static final String party1LEI="Trade Party 1 Value";
	public static final String party2LEI="Trade Party 2 Value";
	public static final String collateralized="Collateralized";
	public static final String collPortfolioCode="Collateral portfolio code Party 1";
	public static final String reportingJurisdiction="Reporting Jurisdiction";
	public static final String tradeParty2NonFinEntJuridiction="Trade Party 2 Non-financial Entity Jurisdiction";
	public static final String ReportingJurisdiction="Reporting Jurisdiction";
	
	
}
