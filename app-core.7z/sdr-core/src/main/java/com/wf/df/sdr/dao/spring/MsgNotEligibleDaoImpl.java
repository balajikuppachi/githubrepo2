package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.MsgNotEligibleDao;
import com.wf.df.sdr.dto.MsgNotEligible;
import com.wf.df.sdr.exception.dao.MsgNotEligibleDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class MsgNotEligibleDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MsgNotEligible>, MsgNotEligibleDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(MsgNotEligible dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, create_datetime, rule_code, rule_desc ) VALUES ( ?, ?, ?, ? )",dto.getSendId(),dto.getCreateDatetime(),dto.getRuleCode(),dto.getRuleDesc());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return MsgNotEligible
	 */
	public MsgNotEligible mapRow(ResultSet rs, int row) throws SQLException
	{
		MsgNotEligible dto = new MsgNotEligible();
		dto.setSendId( rs.getBigDecimal(1));
		dto.setCreateDatetime( rs.getTimestamp(2 ) );
		dto.setRuleCode( rs.getString( 3 ) );
		dto.setRuleDesc( rs.getString( 4 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "msg_not_eligible";
	}

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria ''.
	 */
	@Transactional
	public List<MsgNotEligible> findAll() throws MsgNotEligibleDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, create_datetime, rule_code, rule_desc FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MsgNotEligibleDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<MsgNotEligible> findWhereSendIdEquals(BigDecimal sendId) throws MsgNotEligibleDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, create_datetime, rule_code, rule_desc FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new MsgNotEligibleDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<MsgNotEligible> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgNotEligibleDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, create_datetime, rule_code, rule_desc FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new MsgNotEligibleDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'rule_code = :ruleCode'.
	 */
	@Transactional
	public List<MsgNotEligible> findWhereRuleCodeEquals(String ruleCode) throws MsgNotEligibleDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, create_datetime, rule_code, rule_desc FROM " + getTableName() + " WHERE rule_code = ? ORDER BY rule_code", this,ruleCode);
		}
		catch (Exception e) {
			throw new MsgNotEligibleDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'rule_desc = :ruleDesc'.
	 */
	@Transactional
	public List<MsgNotEligible> findWhereRuleDescEquals(String ruleDesc) throws MsgNotEligibleDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, create_datetime, rule_code, rule_desc FROM " + getTableName() + " WHERE rule_desc = ? ORDER BY rule_desc", this,ruleDesc);
		}
		catch (Exception e) {
			throw new MsgNotEligibleDaoException("Query failed", e);
		}
		
	}

}
