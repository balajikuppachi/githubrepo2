package com.wf.df.sdr.dao;

import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MappingSdrEndur;
import com.wf.df.sdr.exception.dao.MappingSdrEndurDaoException;

public interface MappingSdrEndurDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(MappingSdrEndur dto);
	
	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria ''.
	 */
	public List<MappingSdrEndur> findAll() throws MappingSdrEndurDaoException;

	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'endur_id = :endurId'.
	 */
	public List<MappingSdrEndur> findWhereEndurIdEquals(String endurId) throws MappingSdrEndurDaoException;


	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'sender_trade_ref_id = :senderTradeRefId'.
	 */
	public List<MappingSdrEndur> findWheresenderTradeRefIdEquals(String senderTradeRefId) throws MappingSdrEndurDaoException;


	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MappingSdrEndur> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingSdrEndurDaoException;
	
	/** 
	*Remove entry from mapping_sdr_enconnect table based on sender_trade_ref_id
	*/
	public int updateMappingSdrEndur(String endur_trade_id, String sender_trade_ref_id, String dateStr )  throws MappingSdrEndurDaoException;
	
	
}
