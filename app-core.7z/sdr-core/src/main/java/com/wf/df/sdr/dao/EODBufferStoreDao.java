package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.EODBufferStoreDao;
import com.wf.df.sdr.dto.EODBufferStore;
import com.wf.df.sdr.exception.dao.EODBufferStoreDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface EODBufferStoreDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(EODBufferStore dto);

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria ''.
	 */
	public List<EODBufferStore> findAll() throws EODBufferStoreDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'usi = :usi'.
	 */
	public List<EODBufferStore> findWhereUsiEquals(String usi) throws EODBufferStoreDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'usi = :usi'.
	 */
	public List<EODBufferStore> findWhereUsiAndMsgTypeEquals(String usi, String msgType,String sdrRepository) throws EODBufferStoreDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'asset_class = :assetClass'.
	 */
	public List<EODBufferStore> findWhereAssetClassEquals(String assetClass) throws EODBufferStoreDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'send_id = :sendId'.
	 */
	public List<EODBufferStore> findWhereSendIdEquals(BigDecimal sendId) throws EODBufferStoreDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'msg_buffer = :msgBuffer'.
	 */
	public List<EODBufferStore> findWhereMsgBufferEquals(String msgBuffer) throws EODBufferStoreDaoException;

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	public List<EODBufferStore> findWhereUpdateDatetimeEquals(Date updateDatetime) throws EODBufferStoreDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'template_id = :templateId'.
	 */
	public List<EODBufferStore> findWhereTemplateIdEquals(String templateId) throws EODBufferStoreDaoException;
	
	
	
		
	public int deleteBuffersForUSI(String usi) throws EODBufferStoreDaoException;
	
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<EODBufferStore> findWhereSdrRepositoryEquals(String sdrRepository) throws EODBufferStoreDaoException;

}