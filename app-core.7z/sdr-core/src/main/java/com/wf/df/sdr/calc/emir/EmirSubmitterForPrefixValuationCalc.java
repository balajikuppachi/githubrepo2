package com.wf.df.sdr.calc.emir;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class EmirSubmitterForPrefixValuationCalc {

	@Calculation(value = Calc.emirSubmitterForPrefixValuationCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.isDelegatedTradeCalc, isInternal = true) boolean isDelegated,
			@DerivedFrom(value=Stv.EMIR_CP_CLASSIFICATION, isInternal = true) String emirCpClassification) {
		
		if(Constants.NFC.equalsIgnoreCase(emirCpClassification))
			return Constants.EMPTY_STRING;
		
		if(isDelegated)
			return Constants.BOTH;
		
		return Constants.EMPTY_STRING;

	}
		
}
