package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;


@Component
public class FxConfirmationTypeCalc {
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxConfirmationTypeCalc, isPrototype = false)
	public String calcAction(
			@DerivedFrom(value=Constants.PAPER_FLAG, isInternal=true) Boolean paperFlag,
			@DerivedFrom(value=Calc.intragroupCalc, isInternal=true) String intraGroup) {

		
		if(Constants.TRUE.equalsIgnoreCase(intraGroup))
			return Constants.NOT_CONFIRMED ;
		
		if(!Utils.IsNullOrBlank(paperFlag) && paperFlag)
			return "Non-Electronic";
		return "Electronic";

	}
}