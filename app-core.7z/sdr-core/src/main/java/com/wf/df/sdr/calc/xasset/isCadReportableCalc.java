package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class isCadReportableCalc 
{
	@Calculation(value=Calc.isCadReportableCalc, isPrototype=false)
	public boolean sdrRepositoryCalc(
			@DerivedFrom(value=Constants.REPORTABLE_TO,isInternal = true) String isCadReportable)
	{
		
		if(Constants.REPORTABLE_TO_CAD.equals(isCadReportable))
			return true;
		return false;
	}
	
}
