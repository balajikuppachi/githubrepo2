package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.MsgSendErrorsDao;
import com.wf.df.sdr.dto.MsgSendErrors;
import com.wf.df.sdr.exception.dao.MsgSendErrorsDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class MsgSendErrorsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MsgSendErrors>, MsgSendErrorsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(MsgSendErrors dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository ) VALUES ( ?, ?, ?, ?, ?, ? )",dto.getSendId(),dto.getMsgType(),dto.getCreateDatetime(),dto.getErrorCode(),dto.getErrorDesc(),dto.getSdrRepository());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return MsgSendErrors
	 */
	public MsgSendErrors mapRow(ResultSet rs, int row) throws SQLException
	{
		MsgSendErrors dto = new MsgSendErrors();
		dto.setSendId( rs.getBigDecimal(1));
		dto.setMsgType( rs.getString( 2 ) );
		dto.setCreateDatetime( rs.getTimestamp(3 ) );
		dto.setErrorCode( rs.getString( 4 ) );
		dto.setErrorDesc( rs.getString( 5 ) );
		dto.setSdrRepository(rs.getString( 6 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "msg_send_errors";
	}

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria ''.
	 */
	@Transactional
	public List<MsgSendErrors> findAll() throws MsgSendErrorsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MsgSendErrorsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<MsgSendErrors> findWhereSendIdEquals(BigDecimal sendId) throws MsgSendErrorsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new MsgSendErrorsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<MsgSendErrors> findWhereMsgTypeEquals(String msgType) throws MsgSendErrorsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msgType);
		}
		catch (Exception e) {
			throw new MsgSendErrorsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<MsgSendErrors> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgSendErrorsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new MsgSendErrorsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'error_code = :errorCode'.
	 */
	@Transactional
	public List<MsgSendErrors> findWhereErrorCodeEquals(String errorCode) throws MsgSendErrorsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository FROM " + getTableName() + " WHERE error_code = ? ORDER BY error_code", this,errorCode);
		}
		catch (Exception e) {
			throw new MsgSendErrorsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'error_desc = :errorDesc'.
	 */
	@Transactional
	public List<MsgSendErrors> findWhereErrorDescEquals(String errorDesc) throws MsgSendErrorsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository FROM " + getTableName() + " WHERE error_desc = ? ORDER BY error_desc", this,errorDesc);
		}
		catch (Exception e) {
			throw new MsgSendErrorsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'sdr_repository = :sdrRepository'
	 */
	@Transactional
	public List<MsgSendErrors> findWhereSdrRepositoryEquals(String sdrRepository) throws MsgSendErrorsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, error_code, error_desc, sdr_repository FROM " + getTableName() + " WHERE sdr_repository = ? ORDER BY sdr_repository", this,sdrRepository);
		}
		catch (Exception e) {
			throw new MsgSendErrorsDaoException("Query failed", e);
		}
	}

}
