package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class IsSefTradeCalc {

	@Calculation(value = Calc.isSefTradeCalc, isPrototype = false)
	public Boolean executionVenue(
			@DerivedFrom(value = Stv.ReportingVenue, isInternal = true) String venue,
		    @DerivedFrom(value = Stv.ReportingExecutionVenueType, isInternal = true) String venueType,
		    @DerivedFrom(value = Stv.ExecutionVenueType, isInternal = true) String exeVenueType){
		
		 if (!Utils.IsNullOrBlank(exeVenueType) && exeVenueType.equalsIgnoreCase(Constants.SEF)) 
		       return true;

		 if (!Utils.IsNullOrBlank(venue) && venue.equalsIgnoreCase(Constants.SEF))		
			 return true;
		 
		 if (!Utils.IsNullOrBlank(venueType) && venueType.equalsIgnoreCase(Constants.SEF)) 
		       return true;
		 
		
		 return false;

	}
	
}
