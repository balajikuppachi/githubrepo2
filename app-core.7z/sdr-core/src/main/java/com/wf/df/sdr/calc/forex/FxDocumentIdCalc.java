package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class FxDocumentIdCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxDocumentIdCalc, isPrototype = false)
	public String calculate (@DerivedFrom(value=Constants.CONFIRM_DOCUMENT_ID, isInternal = true) String documentId){

		return documentId;
	}

}
