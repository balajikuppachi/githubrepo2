package com.wf.df.sdr.calc.commodity.marshaller;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="bo_persist")
public class BoPersistDTO {
	
	@XmlElement(name = "bo_msgType", required = true)
	private String msgType;
	
	@XmlElement(name = "bo_recvXml", required = true)
	private String recvXml;
	
	@XmlElement(name = "bo_usi", required = true)	
	private String usi;
	
	@XmlElement(name = "bo_sendId", required = true)
	private String sendId;
	
	@XmlElement(name = "bo_assetClass", required = true)
	private String assetClass;
	
	@XmlElement(name = "bo_prevUsi", required = true)
	private String prevUsi;
	
	private String responseType;
	private String publishStatus;

	/**
	 * @return the publishStatus
	 */
	public String getPublishStatus() {
		return publishStatus;
	}

	/**
	 * @param publishStatus the publishStatus to set
	 */
	public void setPublishStatus(String publishStatus) {
		this.publishStatus = publishStatus;
	}

	public String getResponseType() {
		return responseType;
	}

	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}

	public BoPersistDTO() {
	}
	
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getRecvXml() {
		return recvXml;
	}
	public void setRecvXml(String recvXml) {
		this.recvXml = recvXml;
	}
	public String getUsi() {
		return usi;
	}
	public void setUsi(String usi) {
		this.usi = usi;
	}
	public String getSendId() {
		return sendId;
	}
	public void setSendId(String sendId) {
		this.sendId = sendId;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getPrevUsi() {
		return prevUsi;
	}
	public void setPrevUsi(String prevUsi) {
		this.prevUsi = prevUsi;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((assetClass == null) ? 0 : assetClass.hashCode());
		result = prime * result + ((msgType == null) ? 0 : msgType.hashCode());
		result = prime * result + ((prevUsi == null) ? 0 : prevUsi.hashCode());
		result = prime * result + ((recvXml == null) ? 0 : recvXml.hashCode());
		result = prime * result + ((sendId == null) ? 0 : sendId.hashCode());
		result = prime * result + ((usi == null) ? 0 : usi.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BoPersistDTO other = (BoPersistDTO) obj;
		if (assetClass == null) {
			if (other.assetClass != null)
				return false;
		} else if (!assetClass.equals(other.assetClass))
			return false;
		if (msgType == null) {
			if (other.msgType != null)
				return false;
		} else if (!msgType.equals(other.msgType))
			return false;
		if (prevUsi == null) {
			if (other.prevUsi != null)
				return false;
		} else if (!prevUsi.equals(other.prevUsi))
			return false;
		if (recvXml == null) {
			if (other.recvXml != null)
				return false;
		} else if (!recvXml.equals(other.recvXml))
			return false;
		if (sendId == null) {
			if (other.sendId != null)
				return false;
		} else if (!sendId.equals(other.sendId))
			return false;
		if (usi == null) {
			if (other.usi != null)
				return false;
		} else if (!usi.equals(other.usi))
			return false;
		return true;
	}
	
}
