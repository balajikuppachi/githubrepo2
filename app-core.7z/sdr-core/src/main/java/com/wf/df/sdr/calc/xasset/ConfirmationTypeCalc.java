package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;


@Component
public class ConfirmationTypeCalc {
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value = Calc.confirmationTypeCalc, isPrototype = false)
	public String calcAction(
			@DerivedFrom(value=Constants.PAPER_FLAG, isInternal=true) Boolean paperFlag,
			@DerivedFrom(value=Constants.MESSAGE_TYPE, isInternal=true) String msg,
			@DerivedFrom(value=Calc.sdrRepositoryCalc, isInternal=true) String repository,
			@DerivedFrom(value=Calc.intragroupCalc, isInternal=true) String intraGroup) {

		if(Constants.TRUE.equalsIgnoreCase(intraGroup))
			return Constants.NOT_CONFIRMED;
		
		if(!Utils.IsNullOrBlank(paperFlag) && paperFlag)
			return "Non-Electronic";
		return "Electronic";		
		
	}
}