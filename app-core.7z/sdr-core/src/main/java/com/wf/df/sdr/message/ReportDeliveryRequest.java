package com.wf.df.sdr.message;

import java.io.File;


public class ReportDeliveryRequest {
	private ReportGenerationRequest generationRequest;
	private File file;

	public ReportDeliveryRequest(ReportGenerationRequest generationRequest, File file) {
		this.generationRequest = generationRequest;
		this.file = file;
	}

	public ReportGenerationRequest getReportGenerationRequest() {
		return generationRequest;
	}

	public File getFile() {
		return file;
	}
}
