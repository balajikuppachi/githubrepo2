package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class ClearingStatusCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;

	@Calculation(value = Calc.clearingStatusCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.clearedTradeCalc, isInternal = true) boolean clearedTrade,
			@DerivedFrom(value = Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
			@DerivedFrom(value = Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
			@DerivedFrom(value = Calc.isEmirTradeCalc, isInternal = true) boolean isEmirReportable) {

		if (isDtccDelegatedTrade || isEmirDelegatedTrade || isEmirReportable) {
			if (clearedTrade)
				return Constants.TRUE;
			else
				return Constants.FALSE;
		}
		return Constants.EMPTY_STRING;
	}
}
