package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class TradeParty2DomicileCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	
	
	@Calculation(value = Calc.tradeParty2DomicileCalc, isPrototype=false)
	public String calcTrdParty2Domicile(
			@DerivedFrom(value = Stv.CptyStreet, isInternal=true)String cptyStreet,
			@DerivedFrom(value = Stv.CptyCity, isInternal=true)String cptyCity,
			@DerivedFrom(value = Stv.CptyState, isInternal=true)String cptyState,			
			@DerivedFrom(value = Stv.CptyZip, isInternal=true)String cptyZip,
			@DerivedFrom(value = Stv.CptyCountry, isInternal=true)String cptyCountry,
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable) {
		
		
		logger.debug("calling------------ TradeParty2Domicile ");
		if(isDtccDelegatedTrade||isEmirDelegatedTrade||isEmirReportable)
		{
		 String address = null;
	      if(!Utils.IsNullOrBlank(cptyStreet))
	    	  address=cptyStreet;       
	      if(!Utils.IsNullOrBlank(cptyCity))
	    	  address=address+Constants.COMMA+cptyCity;
	      if(!Utils.IsNullOrBlank(cptyState))
	    	  address=address+Constants.COMMA+cptyState;
	      if(!Utils.IsNullOrBlank(cptyZip))
	    	  address=address+Constants.COMMA+cptyZip;
	      if(!Utils.IsNullOrBlank(cptyCountry))
	    	  address=address+Constants.COMMA+cptyCountry;
	      
	      if(!Utils.IsNullOrBlank(address))
	      	return address.replaceAll("[\n\r]", Constants.SPACE);
	      
	      return Constants.EMPTY_STRING;
		}
		return Constants.EMPTY_STRING;
		//return cptyStreet+Constants.COMMA+cptyCity+Constants.COMMA+cptyState+Constants.COMMA+cptyZip+Constants.COMMA+cptyCountry;	
		
	}
}
