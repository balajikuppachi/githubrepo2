package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.BufferGenerationRequest;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component(value="sendPetRuleFilter")
public class SendPetRuleFilter {
	
		Logger logger = Logger.getLogger(getClass());
	
	public Boolean isToSendPet(BufferGenerationRequest bg){	
		logger.debug("SendPetRuleCalc Called");
		
		CalculationContext cc = bg.getCalculationContext();
		String marketType = cc.getValue(Stv.MarketType, String.class);
		boolean isCadTrade = cc.getValue(Calc.isCadReportableCalc, Boolean.class);
		String msgType = cc.getValue(Constants.MESSAGE_TYPE,String.class);
		
			if(isCadTrade && Constants.MESSAGE_TYPE_PET.equals(msgType)) 
			{
				if(Constants.NEW_DEAL.equals(marketType))
					return true;
				
				return false;
			}
								
		return true;
	}
	
}
