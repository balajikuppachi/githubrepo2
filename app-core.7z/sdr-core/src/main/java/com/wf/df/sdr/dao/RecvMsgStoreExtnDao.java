package com.wf.df.sdr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class RecvMsgStoreExtnDao {
	
	//private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Long findMaxRecvIdInRange(Long from, Long to) {
		List<Long> maxIdList = jdbcTemplate.queryForList("SELECT MAX(recv_id) FROM recv_msg_store WHERE recv_id >= ? AND recv_id <= ?", Long.class, from, to);
		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null) {
			return null;
		} else {
			return maxIdList.get(0);
		}
	}
}
