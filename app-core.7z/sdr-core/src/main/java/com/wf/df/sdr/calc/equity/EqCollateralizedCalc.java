package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.meta.CollateralService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqCollateralizedCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	CollateralService collateralService;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.eqCollateralizedCalc, isPrototype=false)
	public Object calculate(
			@DerivedFrom(value=Stv.BusinessAccountId) String businessAccountId,
			@DerivedFrom(value=Stv.OTCProductID,isInternal=true) String tradeID) 
	{
		if (!Utils.IsNullOrBlank(businessAccountId) || !Utils.IsNullOrBlank(tradeID)) {
			String collateralizedValue =  collateralService.getDTCCCollaterlizedValue(Constants.NOT_APPLICABLE,
					Constants.NOT_APPLICABLE,businessAccountId,Constants.ASSET_CLASS_EQUITY, tradeID);
			
			if(Constants.PartiallyCollateralized.equals(collateralizedValue))
				return Constants.Partially;
			else if(Constants.FullyCollateralized.equals(collateralizedValue))
				return Constants.Fully;
			else if(Constants.OneWayCollateralized.equals(collateralizedValue))
				return Constants.OneWay;
			else 
				return collateralizedValue;
		}
		return Constants.EMPTY_STRING;
	}
}
