package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;

@Component
public class EqParty2RoleCalc {

	@Calculation(value = Calc.eqParty2RoleCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.Df_ETSD_equityderivatives_Cp, isInternal = true) String etsdEquityderivativesCp,
			@DerivedFrom(value = Stv.Df_ETMSP_equityderivatives_Cp, isInternal = true) String etmspEquityderivativesCp)	{
		
		if("Y".equalsIgnoreCase(etsdEquityderivativesCp))
			return "SD";
		
		if("Y".equalsIgnoreCase(etmspEquityderivativesCp))
			return "MSP";
		
		return "non-SD/MSP";
	
	}
	
}
