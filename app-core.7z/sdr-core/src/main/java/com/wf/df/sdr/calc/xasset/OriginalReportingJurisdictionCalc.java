package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class OriginalReportingJurisdictionCalc 
{
	

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.originalReportingJurisdictionCalc, isPrototype = false)
	public String compute(
			@DerivedFrom(value = Stv.Reporting_Jurisdiction, isInternal = true) String diction
			) {
		
		if(!Utils.IsNullOrBlank(diction) && Constants.NONE.equalsIgnoreCase(diction))
				return diction;


		if(!Utils.IsNullOrBlank(diction))
			return StringUtils.replace(diction, Constants.PIPE, Constants.SEMICOLON);
		
		
		if(Utils.IsNullOrBlank(diction))
			return Constants.NONE;
				
		return diction;
	
	}


}
