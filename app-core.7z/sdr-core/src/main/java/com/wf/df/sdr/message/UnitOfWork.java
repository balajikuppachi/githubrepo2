package com.wf.df.sdr.message;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

/**
 * 
 * @author GShankar
 *
 * This is the basic Unit of Work that will be used to pass around data as context in all handlers. Please add attributes in here
 * to flow through a chain
 */

public class UnitOfWork {
	
	Logger logger = Logger.getLogger(this.getClass());
	private CalculationContext calcCtx;
	
	public boolean shouldWeCreateFeeTrade() {
		return getCalculationContext().getValue(Calc.shouldWeCreateFeeTradeCalc, Boolean.class);
	}
	
	public UnitOfWork(CalculationContext calcCtx) {
		this.calcCtx = calcCtx;
	}
	
	public String getUSI(){
		return getCalculationContext().getValue(Calc.computedUSICalc, String.class);
	}
	
	public String getDtccAssetClass() {
		return getCalculationContext().getValue(Calc.dtccAssetClassCalc, String.class);
	}
	
	public String getMessageType() {
		return calcCtx.getValue(Constants.MESSAGE_TYPE, String.class);
	}
	
	public String getBook() {
		return calcCtx.getValue(Stv.Book, String.class);
	}
	
	public BigDecimal getSendId() {
		return calcCtx.getValue(Constants.SEND_ID, BigDecimal.class);
	}
	
	public CalculationContext getCalculationContext() {
		return calcCtx;
	}
	
	public String getString(String name) {
		return calcCtx.getString(name);
	}
	
	public Boolean getBoolean(String name) {
		return calcCtx.getBoolean(name);
	}
	
	public Boolean isReportableReportingParty() {
		return calcCtx.getValue(Calc.reportingPartyCalc, Boolean.class);
	}
	
	public String getSrcTLCEvent(){
		return calcCtx.getValue(Calc.srcTLCEventCalc, String.class);
	}
	
	@Override
	public String toString() {
		return "Unit of work #" + getSendId();
	}
	
}
