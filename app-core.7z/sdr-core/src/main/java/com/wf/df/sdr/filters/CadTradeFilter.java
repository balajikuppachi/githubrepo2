package com.wf.df.sdr.filters;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component(value = "cadTradeFilter")
public class CadTradeFilter {

	@Autowired
	NotEligblePersister nep;

	Logger log = Logger.getLogger(getClass());

	public boolean tradeNotEligible(UnitOfWork uow) {
		CalculationContext cc = uow.getCalculationContext();

		String calDocStatus = cc.getValue(Stv.CalypsoDocStatus, String.class);

		if (StringUtils.equalsIgnoreCase(Constants.SETTLED, calDocStatus) || 
				StringUtils.equalsIgnoreCase(Constants.NETTED, calDocStatus) || 
						StringUtils.equalsIgnoreCase(Constants.Exercise, calDocStatus)||
						StringUtils.equalsIgnoreCase(Constants.MATURED, calDocStatus)) {
			
				log.info("Ineligible Trade: " + calDocStatus);
				nep.updateCadEODBufferForTradeId(cc.getValue(Stv.TradeId, String.class));				
				return false;
		}
		return true;
	}
}
