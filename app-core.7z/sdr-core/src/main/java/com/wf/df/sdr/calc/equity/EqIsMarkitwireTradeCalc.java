package com.wf.df.sdr.calc.equity;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;

/**
 * @author u293876
 *
 */
@Component
public class EqIsMarkitwireTradeCalc {
	 
	String eqProcessedBySystem = "MarkitWire";
	String eqVerificationType = "ELECTRONIC";

	@Calculation(value = Calc.eqIsMarkitwireTradeCalc, isPrototype = false)
	public Boolean calculate(
			@DerivedFrom(value = Stv.ProcessedBySystem, isInternal = true) String eqProcessType,
			@DerivedFrom(value = Stv.VerificationType, isInternal = true) String eqVerification) {
		if (StringUtils.contains(eqProcessedBySystem, eqProcessType)&& StringUtils.contains(eqVerificationType, eqVerification))
			return true;
		return false;

	}

}
