package com.wf.df.sdr.dao;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class SimulatorBufferStoreExtnDao 
{
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	@Qualifier("simulatorJdbcTemplate")
	private JdbcTemplate simulatorJdbcTemplate;
	
	
	/*
	 * query fetches all the eligible stvs data from trade attribute for tradeId and product type
	 * 
	 **/
	public List<Map<String, Object>> findAllStvBufferForTradeId( String srcProductType,String tradeId) 
	{
		logger.info("Entered findAllStvBufferForTradeId() method , Product:"+srcProductType+", tradeId :"+tradeId);
		
		//String query = "select bs.buffer_data from input_msg_store ims,buffer_store bs ,trade_attributes ta where ims.buffer_id=bs.buffer_id and ims.src_tlc_event not in('None') and ims.send_id=ta.send_id and" +
		//		" ims.src_prod_type=? and ims.src_trade_id=? order by ims.send_id asc";

		//String query = "select bs.buffer_data from input_msg_store ims,buffer_store bs ,trade_attributes ta where ims.buffer_id=bs.buffer_id and ims.send_id=ta.send_id and" +
		//		" ims.src_prod_type='" + srcProductType + "' and ims.src_trade_id='" + tradeId + "' order by ims.send_id asc";

		String query = "select ims.send_id,bs.buffer_data from input_msg_store ims, buffer_store bs where ims.buffer_id=bs.buffer_id and" +
				" ims.src_prod_type='" + srcProductType + "' and ims.src_trade_id='" + tradeId + "' order by ims.send_id asc";

		logger.info("findAllStvBufferForTradeId() :: SQL : "+query);

		//List<String> bufferList = jdbcTemplate.queryForList(query, String.class, srcProductType, tradeId);
		List<Map<String, Object>> bufferListMap = simulatorJdbcTemplate.queryForList(query);
		
		if (bufferListMap == null || bufferListMap.isEmpty() || bufferListMap.get(0) == null) 
		{
			return null;
		} 
		else 
		{
			return bufferListMap;
		}
	}
	
	/*
	 * query fetches all the eligible stvs  data from  trade attribute for  product type  and number of days 
	 * 
	 * */
	public List<Map<String, Object>> findAllStvBufferForProductByNoOfDays( String srcProductType,Integer noOfDays) 
	{
		logger.info("Entered findAllStvBufferForProduct() method , Product:"+srcProductType+"; NoOfDays :"+noOfDays);
		
		//String query = "select bs.buffer_data from input_msg_store ims,buffer_store bs ,trade_attributes ta where ims.buffer_id=bs.buffer_id and ims.src_tlc_event not in('None') and ims.send_id=ta.send_id and ims.src_prod_type in(?) and "+
		//				" CONVERT (DATE,ims.create_datetime, 101) = DATEADD(day,?,CONVERT (DATE, GETDATE(), 101)) order by ims.send_id asc ";

		String query = "select ims.send_id, bs.buffer_data from input_msg_store ims,buffer_store bs ,trade_attributes ta where ims.buffer_id=bs.buffer_id "
				+ "and ims.send_id=ta.send_id and ims.src_prod_type in(" + srcProductType + ") and "+
				" CONVERT (DATE,ims.create_datetime, 101) >= DATEADD(day," + noOfDays.intValue() + ",CONVERT (DATE, GETDATE(), 101)) order by ims.send_id asc ";

		//String query = "select bs.buffer_data from input_msg_store ims,buffer_store bs ,trade_attributes ta where ims.buffer_id=bs.buffer_id and ims.src_tlc_event not in('None') and ims.send_id=ta.send_id and ims.src_prod_type in('Swaption','XCcySwap', 'FXForward', 'FXSwap', 'FXOption') and "+
		//		" CONVERT (DATE,ims.create_datetime, 101) = DATEADD(day,-131,CONVERT (DATE, GETDATE(), 101)) order by ims.send_id asc ";
		
		logger.info("findAllStvBufferForProduct() :: SQL : "+query);

		//List<String> bufferList = jdbcTemplate.queryForList(query, String.class, srcProductType, noOfDays.intValue());
		List<Map<String, Object>> bufferListMap = simulatorJdbcTemplate.queryForList(query);
		if (bufferListMap == null || bufferListMap.isEmpty() || bufferListMap.get(0) == null) 
		{
			return null;
		} 
		else 
		{
			return bufferListMap;
		}
		
	}
	
	/*
	 * query fetches all the eligible stvs  data from  trade attribute for  product type  and date range 
	 * 
	 * */
	public List<Map<String, Object>> findAllStvBufferForProductByDateRange( String srcProductType, String date1, String date2) 
	{
		logger.info("Entered findAllStvBufferForProduct() method , Product:"+srcProductType+"; Date1 :"+date1+"; Date2 :"+date2);
		
		//String query = "select bs.buffer_data from input_msg_store ims,buffer_store bs ,trade_attributes ta where ims.buffer_id=bs.buffer_id "
		//		+ " and ims.send_id=ta.send_id and ims.src_prod_type in(" + srcProductType + ") "
		//		+ " and CONVERT (DATE,ims.create_datetime, 101) >= CONVERT (DATE, '" + date1 + "', 101) "
		//		+ " and CONVERT (DATE,ims.create_datetime, 101) <= CONVERT (DATE, '" + date2 + "', 101) "
		//		+ " order by ims.send_id asc ";

		String query = "select ims.send_id,bs.buffer_data from input_msg_store ims,buffer_store bs where ims.buffer_id=bs.buffer_id "
				+ " and ims.src_prod_type in(" + srcProductType + ") "
				+ " and CONVERT (DATE,ims.create_datetime, 101) >= CONVERT (DATE, '" + date1 + "', 101) "
				+ " and CONVERT (DATE,ims.create_datetime, 101) <= CONVERT (DATE, '" + date2 + "', 101) "
				+ " order by ims.send_id asc ";
		
		logger.info("findAllStvBufferForProductByDateRange() :: SQL : "+query);
		
		List<Map<String, Object>> bufferListMap = simulatorJdbcTemplate.queryForList(query);

		if (bufferListMap == null || bufferListMap.isEmpty() || bufferListMap.get(0) == null) 
		{
			return null;
		} 
		else 
		{
			return bufferListMap;
		}
	}
	
	public List<String> findScritturaXMLForTradeId(String srcProductType, String tradeId) {
		
		List<String> xmlList = null;
		
		String query = "select smsg.msg from input_msg_store ims, scrittura_msg smsg where ims.src_trade_id = smsg.trade_id and" +
		" ims.src_prod_type='" + srcProductType + "' and ims.src_trade_id='" + tradeId + "'";
		
		logger.info("findScritturaXMLForTradeId() :: SQL : "+query);

		xmlList = simulatorJdbcTemplate.queryForList(query, String.class);
		
		
		return xmlList;
	}
	
	public List<String> findScritturaXMLForProduct( String srcProductType,Integer noOfDays) 
	{
		List<String> xmlList = null;
		logger.info("Entered findScritturaXMLForProduct() method , Product:"+srcProductType+"; NoOfDays :"+noOfDays);
		String query = "select smsg.msg from input_msg_store ims, scrittura_msg smsg where ims.src_trade_id = smsg.trade_id and" +
						" ims.src_prod_type in(" + srcProductType + ") and "+
				" CONVERT (DATE,ims.create_datetime, 101) >= DATEADD(day," + noOfDays.intValue() + ",CONVERT (DATE, GETDATE(), 101)) order by ims.send_id asc ";
		
		logger.info("findScritturaXMLForProduct() :: SQL : "+query);
		 xmlList = simulatorJdbcTemplate.queryForList(query, String.class);
		 return xmlList;
	}
	
	public List<String> findScritturaXMLForProductByDateRange( String srcProductType, String date1, String date2) 
	{
		
		List<String> xmlList = null;
		logger.info("Entered findScritturaXMLForProductByDateRange() method , Product:"+srcProductType+"; Date1 :"+date1+"; Date2 :"+date2);
		
		String query = "select smsg.msg from input_msg_store ims, scrittura_msg smsg where ims.src_trade_id = smsg.trade_id and" +
						" ims.src_prod_type in(" + srcProductType + ") and "
						+ " and CONVERT (DATE,ims.create_datetime, 101) >= CONVERT (DATE, '" + date1 + "', 101) "
						+ " and CONVERT (DATE,ims.create_datetime, 101) <= CONVERT (DATE, '" + date2 + "', 101) "
						+ " order by ims.send_id asc ";

		logger.info("findAllStvBufferForProductByDateRange() :: SQL : "+query);

		xmlList = simulatorJdbcTemplate.queryForList(query, String.class);
		return xmlList;
	}

}
