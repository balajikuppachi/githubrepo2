package com.wf.df.sdr.message;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@Component
@XmlRootElement(name="getFileAsAttachment", namespace="http://com.webservice/Scrittura")
public class GetFileAsAttachment {
	
	@XmlElement(name="string")
	public String string;

	public void setString(String string) {
		this.string = string;
	}
	
	public String toString() {
		return new String ("<getFileAsAttachment><string>" + string + "</string></getFileAsAttachment>");
	}
	
}