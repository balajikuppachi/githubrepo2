package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.BufferStoreDao;
import com.wf.df.sdr.dto.BufferStore;
import com.wf.df.sdr.exception.dao.BufferStoreDaoException;

public class BufferStoreDaoImpl extends AbstractDAO implements ParameterizedRowMapper<BufferStore>, BufferStoreDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(BufferStore dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( buffer_id, buffer_data, buffer_src, create_datetime ) VALUES ( ?, ?, ?, ? )",dto.getBufferId(),dto.getBufferData(),dto.getBufferSrc(),dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return BufferStore
	 */
	public BufferStore mapRow(ResultSet rs, int row) throws SQLException
	{
		BufferStore dto = new BufferStore();
		dto.setBufferId( rs.getBigDecimal(1));
		dto.setBufferData( rs.getString( 2 ) );
		dto.setBufferSrc( rs.getString( 3 ) );
		dto.setCreateDatetime( rs.getTimestamp(4 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "buffer_store";
	}

	/** 
	 * Returns all rows from the buffer_store table that match the criteria ''.
	 */
	@Transactional
	public List<BufferStore> findAll() throws BufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new BufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'buffer_id = :bufferId'.
	 */
	@Transactional
	public List<BufferStore> findWhereBufferIdEquals(BigDecimal bufferId) throws BufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE buffer_id = ? ORDER BY buffer_id", this,bufferId);
		}
		catch (Exception e) {
			throw new BufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'buffer_data = :bufferData'.
	 */
	@Transactional
	public List<BufferStore> findWhereBufferDataEquals(String bufferData) throws BufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE buffer_data = ? ORDER BY buffer_data", this,bufferData);
		}
		catch (Exception e) {
			throw new BufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'buffer_src = :bufferSrc'.
	 */
	@Transactional
	public List<BufferStore> findWhereBufferSrcEquals(String bufferSrc) throws BufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE buffer_src = ? ORDER BY buffer_src", this,bufferSrc);
		}
		catch (Exception e) {
			throw new BufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<BufferStore> findWhereCreateDatetimeEquals(Date createDatetime) throws BufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT buffer_id, buffer_data, buffer_src, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new BufferStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns buffer for Credit Novation OR Fee trade
	 */
	@Transactional
	public List<BufferStore> findBufferForFeeTrade(String tradeId, String marketType) throws BufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT b.buffer_id, b.buffer_data, b.buffer_src, b.create_datetime FROM buffer_store b, input_msg_store i WHERE b.buffer_id = i.buffer_id and i.src_trade_id = ? " +
					"and i.sdr_repository='DTCC' and i.src_tlc_event = ? and i.src_trade_status = 'NC_PENDING' ORDER BY create_datetime desc", this, tradeId, marketType);
		}
		catch (Exception e) {
			throw new BufferStoreDaoException("Query failed", e);
		}
		
	}

}
