package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.EndurMsgStore;
import com.wf.df.sdr.exception.dao.EndurMsgStoreDaoException;

public interface EndurMsgStoreDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(EndurMsgStore dto);

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria ''.
	 */
	public List<EndurMsgStore> findAll() throws EndurMsgStoreDaoException;

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'trace_id = :trace_id'.
	 */
	public List<EndurMsgStore> findWhereTraceIdEquals(String trace_id) throws EndurMsgStoreDaoException;

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'trade_ref_id = :trade_ref_id'.
	 */
	public List<EndurMsgStore> findWhereTradeRefIdEquals(String trade_ref_id) throws EndurMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'usi = :usi'.
	 */
	public List<EndurMsgStore> findWhereUsiEquals(String usi) throws EndurMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'product_id = :product_id'.
	 */
	public List<EndurMsgStore> findWhereProductIdEquals(String product_id) throws EndurMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'status = :status'.
	 */
	public List<EndurMsgStore> findWhereStatusEquals(String status) throws EndurMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'status_desc = :status_desc'.
	 */
	public List<EndurMsgStore> findWhereStatusDescEquals(String status_desc) throws EndurMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'confirm_status = :confirm_status'.
	 */
	public List<EndurMsgStore> findWhereConfirmStatusEquals(String confirm_status) throws EndurMsgStoreDaoException;

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'msg_type = :msg_type'.
	 */
	public List<EndurMsgStore> findWhereMsgTypeEquals(String msg_type) throws EndurMsgStoreDaoException;

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<EndurMsgStore> findWhereCreateDatetimeEquals(Date createDatetime) throws EndurMsgStoreDaoException;
	
	/** 
	 * Get the latest record for a given sender trader ref id.
	 */

	public List<EndurMsgStore> findLatestICERecordForTrade(String senderTradeRefId) throws EndurMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'buffer_id = :buffer_id'.
	 */
	public List<EndurMsgStore> findWhereBufferIdEquals(BigDecimal buffer_id) throws EndurMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'is_wells_seller = :is_wells_seller'.
	 */

	public List<EndurMsgStore> findWhereIsWellsSellerEquals(String isWellsSeller) throws EndurMsgStoreDaoException;

}
