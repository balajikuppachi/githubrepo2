package com.wf.df.sdr.calc.xasset;

import javax.net.ssl.HostnameVerifier;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.HttpsUrlConnectionMessageSender;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.message.GetFileAsAttachment;
import com.wf.df.sdr.message.GetFileAsAttachmentResponse;
import com.wf.df.sdr.message.SkipHostNameVerifier;
import com.wf.df.sdr.service.MailSenderService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class DocumentCalc {

	@Value("${file.scrittura.tempFolder}")
	String filePath;
	@Value("${file.scrittura.extension}")
	String fileExtn;

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	WebServiceTemplate webServiceTemplate;
	
	@Autowired
	MailSenderService mailSender;
	
	@Value("${scrittura.bypass.security}") String bypassSecurity;
	
	boolean hostnameVerifierFlag;

	@Calculation(value = Calc.documentCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Constants.CONFIRM_DOCUMENT_ID, isInternal = true) String documentId,
			@DerivedFrom(value = Calc.documentIdCalc, isInternal = true) String documentModifiedFileName,
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String tradeId,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String assetClass,
			@DerivedFrom(value = Stv.Book, isInternal = true) String book) {
		
		GetFileAsAttachment message = new GetFileAsAttachment();
		message.setString(documentId);
		GetFileAsAttachmentResponse response = null;
		
		try{
		
			/* START Bypass Security - Host name verification */
			if (!hostnameVerifierFlag && "true".equalsIgnoreCase(bypassSecurity)) {
				HostnameVerifier verifier = new SkipHostNameVerifier();
				HttpsUrlConnectionMessageSender sender = new HttpsUrlConnectionMessageSender();
				sender.setHostnameVerifier(verifier);
				webServiceTemplate.setMessageSender(sender);
				hostnameVerifierFlag = true;
			}
			/* END Bypass Security - Host name verification */
			
		if ((response = (GetFileAsAttachmentResponse) webServiceTemplate.marshalSendAndReceive((message))) != null) {
		
			String FQFN = filePath + documentModifiedFileName + fileExtn;
			if (response.saveFile(FQFN)) {
				logger.info("Saved a file @ location[" + FQFN + "]");
					return (documentModifiedFileName+fileExtn);
			}
		}
		if ((null == response) || response.isDocumentEmpty()) {
			sendErrorMesage(assetClass, documentModifiedFileName, tradeId , book);
			throw new CalculationException("SCR-WS","Failed to fetch Document[" + documentModifiedFileName + "]");
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new CalculationException("SCR-WS", e.getMessage());
		}
		return null;//removing this will make the annotated Calculation un-happy.
	}
	
	private void sendErrorMesage(String assetClass, String documentModifiedFileName, String tradeId,String book ) {
		StringBuffer msgToMail = new StringBuffer();
		msgToMail.append("Asset Class : "+ assetClass);
		msgToMail.append("\n");
		msgToMail.append("Document ID : " + documentModifiedFileName);
		msgToMail.append("\n");
		msgToMail.append("Trade Id : " + tradeId);
		msgToMail.append("\n");
		msgToMail.append("Book : " + book);
		msgToMail.append("\n");
		msgToMail.append("DocumentCalc: Document returned EMPTY, while retrieve from Scrittura");
		msgToMail.append("\n");
		if(Constants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(assetClass)){
			mailSender.sendRatesExceptionMail("Error in document message <" + book +Constants.HYPHEN + assetClass + Constants.HYPHEN , msgToMail.toString(), null);
		}else if(Constants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass)){
			mailSender.sendCreditExceptionMail("Error in document message <" +book +Constants.HYPHEN + assetClass + Constants.HYPHEN , msgToMail.toString(), null);
		}else if(Constants.ASSET_CLASS_EQUITY.equalsIgnoreCase(assetClass)){
			mailSender.sendEquityExceptionMail("Error in document message <" +book +Constants.HYPHEN + assetClass + Constants.HYPHEN , msgToMail.toString(), null);
		}

	}

}