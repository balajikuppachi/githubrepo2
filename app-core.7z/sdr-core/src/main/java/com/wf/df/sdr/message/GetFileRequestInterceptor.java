package com.wf.df.sdr.message;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.xml.transform.StringSource;

import com.wf.df.sdr.utility.SecureDBPwdHelper;

@Component
public class GetFileRequestInterceptor implements ClientInterceptor {
	
	@Value("${scrittura.username}") String username;
	@Value("${scrittura.password}") String password;
	
	private Logger logger = Logger.getLogger(this.getClass().getName());


	public boolean handleFault(MessageContext context)
			throws WebServiceClientException {
		return true;
	}

	public boolean handleRequest(MessageContext context)
			throws WebServiceClientException {
		enrichHeaders(context);
		logger.info(context.getRequest().toString());
		return true;
	}

	public boolean handleResponse(MessageContext context)
			throws WebServiceClientException {

		return true;
	}
	
	private void enrichHeaders(MessageContext context) {
		
		SecureDBPwdHelper secureDBPwdHelper = new SecureDBPwdHelper();
              
        String decodedPassword = secureDBPwdHelper.decrypt(password);

		SoapMessage soapMessage = (SoapMessage) context.getRequest();
		SoapHeader soapHeader = soapMessage.getSoapHeader();
		try {
			StringSource additionalHeader = new StringSource(
					"<Header1>"+
					"<authHeader1/>" +
					"<id>" + username + "</id>" + 
					"<password>" + decodedPassword + "</password>" + 
					"</Header1>"	);
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(additionalHeader, soapHeader.getResult());		
		} catch (Exception e) {
			logger.error(e);
		}
	}
}
