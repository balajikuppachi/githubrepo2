package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxExchangeRateBasisCurrency2Calc {

	Logger logger = Logger.getLogger(this.getClass());


	@Calculation(value = Calc.fxExchangeRateBasisCurrency2Calc, isPrototype=false)
	public String calcAction(
			@DerivedFrom(value = Stv.FXQuotingCurrency, isInternal = true) String fxQuotingCurrency,
			@DerivedFrom(value = Stv.FXOptionQuotingCurrency, isInternal = true) String fxOptionQuotingCurrency) {
		
		if (!Utils.IsNullOrBlank(fxQuotingCurrency)) {
			return fxQuotingCurrency;
		}
		
		if (!Utils.IsNullOrBlank(fxOptionQuotingCurrency)) {
			return fxOptionQuotingCurrency;
		}
	
		return Constants.EMPTY_STRING;

	}
}