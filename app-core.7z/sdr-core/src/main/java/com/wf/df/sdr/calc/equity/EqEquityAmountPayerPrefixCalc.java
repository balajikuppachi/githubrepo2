package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EqEquityAmountPayerPrefixCalc {

	@Calculation(value = Calc.eqEquityAmountPayerPrefixCalc, isPrototype = false)
	public String valuationDate(
			@DerivedFrom(value = Calc.eqIsWFBuyerCalc, isInternal = true) Boolean isWFBuyer,
			@DerivedFrom(value = Calc.eqUnderlyngAssetCptyParticipantIdPrefixCalc, isInternal = true) String cpty,
			@DerivedFrom(value = Calc.eqUnderlyngAssetWFParticipantIdPrefixCalc, isInternal = true) String us) {
		
		if(isWFBuyer)
			return cpty; //if WF is buyer, then Cpty is payer
		else
			return us;
		
		
	}
	
}