package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqStrikePriceCalc {

	@Calculation(value = Calc.eqStrikePriceCalc, isPrototype=false)
	public String calculate(
			@DerivedFrom(value = Stv.StrikePrice, isInternal = true) String strikePrice,
			@DerivedFrom(value = Stv.SellerStrikePrice, isInternal = true) String sellerStrikePrice,
			@DerivedFrom(value = Stv.EquityProductType, isInternal = true) String eqProductType,
			@DerivedFrom(value = Stv.AssetType, isInternal = true) String assetType,
			@DerivedFrom(value = Stv.PutStrikePrice, isInternal = true) String putStrike,
			@DerivedFrom(value = Stv.CallStrikePrice, isInternal = true) String callStrike){

		if(Constants.EquityOption.equals(eqProductType)&&Constants.STRADDLE.equalsIgnoreCase(assetType))
			{
				if(!Utils.IsNullOrBlank(putStrike)||!Utils.IsNullOrBlank(callStrike))
				return (putStrike!=null)?putStrike:callStrike;
			}
		
		if (!Utils.IsNullOrBlank(strikePrice))
			return strikePrice;
		else
			if(!Utils.IsNullOrBlank(sellerStrikePrice))
				return sellerStrikePrice;
		
		return Constants.EMPTY_STRING;
		
	}
}
