package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import com.wf.df.sdr.dao.DtccFieldsTransactionMappingsDao;
import com.wf.df.sdr.dto.DtccFieldsTransactionMappings;
import com.wf.df.sdr.exception.dao.DtccFieldsTransactionMappingsDaoException;

public class DtccFieldsTransactionMappingsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<DtccFieldsTransactionMappings>, DtccFieldsTransactionMappingsDao {

	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return DtccFieldsTransactionMappings
	 */
	public DtccFieldsTransactionMappings mapRow(ResultSet rs, int row) throws SQLException
	{
		DtccFieldsTransactionMappings dto = new DtccFieldsTransactionMappings();
		dto.setFieldId( new Integer( rs.getInt( 1 ) ) );
		dto.setDtccAssetClass( rs.getString( 2 ) );
		dto.setFieldName( rs.getString( 3 ) );
		dto.setTransactionType( rs.getString( 4 ) );
		dto.setSdrRepository(rs.getString(5));
		return dto;
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(DtccFieldsTransactionMappings dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( field_id, dtcc_asset_class, field_name, transaction_type,sdr_repository) VALUES ( ?, ?, ?, ?, ?)",dto.getFieldId(),dto.getDtccAssetClass(),dto.getFieldName(),dto.getTransactionType(),dto.getSdrRepository());
	}

	@Override
	public List<DtccFieldsTransactionMappings> findAll() throws DtccFieldsTransactionMappingsDaoException {
		try {
			return jdbcTemplate.query("SELECT field_id, dtcc_asset_class, field_name, transaction_type, sdr_repository FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new DtccFieldsTransactionMappingsDaoException("Query failed", e);
		}
	}
	
	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "dtcc_fields_transaction_mappings";
	}


}
