package com.wf.df.sdr.dao.spring;

import java.io.*;
import java.sql.*;

/**
 * Generic Base class for DAO classes.
 * 
 */
public class AbstractDAO {

	public byte[] getBlobColumn(ResultSet rs, int columnIndex)
			throws SQLException {
		try {
			Blob blob = rs.getBlob(columnIndex);
			if (blob == null) {
				return null;
			}

			InputStream is = blob.getBinaryStream();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();

			if (is == null) {
				return null;
			} else {
				byte buffer[] = new byte[64];
				int c = is.read(buffer);
				while (c > 0) {
					bos.write(buffer, 0, c);
					c = is.read(buffer);
				}
				return bos.toByteArray();
			}
		} catch (IOException e) {
			throw new SQLException(
					"Failed to read BLOB column due to IOException: "
							+ e.getMessage());
		}
	}

	public void setBlobColumn(PreparedStatement stmt, int parameterIndex,
			byte[] value) throws SQLException {
		if (value == null) {
			stmt.setNull(parameterIndex, Types.BLOB);
		} else {
			stmt.setBinaryStream(parameterIndex,
					new ByteArrayInputStream(value), value.length);
		}
	}
	
	/**
	 * Using override since, Sybase does not have a CLOB datatype
	 * @param rs
	 * @param columnIndex
	 * @return
	 * @throws SQLException
	 */

	public String getClobColumn(ResultSet rs, int columnIndex)
			throws SQLException {
		return rs.getString(columnIndex);
	}

	public void setClobColumn(PreparedStatement stmt, int parameterIndex,
			String value) throws SQLException {
		if (value == null) {
			stmt.setNull(parameterIndex, Types.CLOB);
		} else {
			stmt.setAsciiStream(parameterIndex,
					new ByteArrayInputStream(value.getBytes()), value.length());
		}
	}
}
