package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.IceRule;
import com.wf.df.sdr.exception.dao.DaoException;

public interface IceRulesDao {

	
	public List<IceRule> findAll() throws DaoException;
	
	public List<IceRule> executeRule(String msgType,String prvsStatus,String currentStatus,String prevEconfirm,String currEconfirm,String prevRequestType,String prevRequestAction,String error) throws DaoException;
}
;