package com.wf.df.sdr.filters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class ForexFilter {

	@Autowired
	NotEligblePersister nep;

	// SPOT products to be filter out (dtccProduct)
	public boolean isForexEligible(UnitOfWork uow) {

		CalculationContext cc = uow.getCalculationContext();
		String prod = (String) cc.getValue(Stv.CalypsoProductType, String.class);

		// Only if its FXCash do the check
		if (Constants.PRODUCT_TYPE_FXCASH.equalsIgnoreCase(prod)) {
			// Check for IS_FORWARD = true., then continue reporting
			String val = (String) cc.getValue(Stv.IS_FORWARD, String.class);
			if (Constants.TRUE.equalsIgnoreCase(val))
				return true;
			nep.save(uow, NotEligblePersister.PNRE);
			return (false);
		}
		
		// default for InterestRate products and others just return true
		return true;
	}
}
