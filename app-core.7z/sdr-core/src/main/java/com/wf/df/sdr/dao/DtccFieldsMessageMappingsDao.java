package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.DtccFieldsMessageMappingsDao;
import com.wf.df.sdr.dto.DtccFieldsMessageMappings;
import com.wf.df.sdr.exception.dao.DtccFieldsMessageMappingsDaoException;

import java.util.Date;
import java.util.List;

public interface DtccFieldsMessageMappingsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(DtccFieldsMessageMappings dto);

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria ''.
	 */
	public List<DtccFieldsMessageMappings> findAll() throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'id = :id'.
	 */
	public List<DtccFieldsMessageMappings> findWhereIdEquals(Integer id) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_csv_seq = :fieldCsvSeq'.
	 */
	public List<DtccFieldsMessageMappings> findWhereFieldCsvSeqEquals(Integer fieldCsvSeq) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_optionality = :fieldOptionality'.
	 */
	public List<DtccFieldsMessageMappings> findWhereFieldOptionalityEquals(String fieldOptionality) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'dtcc_asset_class = :dtccAssetClass'.
	 */
	public List<DtccFieldsMessageMappings> findWhereDtccAssetClassEquals(String dtccAssetClass) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'dtcc_prod_type = :dtccProdType'.
	 */
	public List<DtccFieldsMessageMappings> findWhereDtccProdTypeEquals(String dtccProdType) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'dtcc_sub_prod_type = :dtccSubProdType'.
	 */
	public List<DtccFieldsMessageMappings> findWhereDtccSubProdTypeEquals(String dtccSubProdType) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'msg_type = :msgType'.
	 */
	public List<DtccFieldsMessageMappings> findWhereMsgTypeEquals(String msgType) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'transaction_type = :transactionType'.
	 */
	public List<DtccFieldsMessageMappings> findWhereTransactionTypeEquals(String transactionType) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_name = :fieldName'.
	 */
	public List<DtccFieldsMessageMappings> findWhereFieldNameEquals(String fieldName) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_id = :fieldId'.
	 */
	public List<DtccFieldsMessageMappings> findWhereFieldIdEquals(Integer fieldId) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_rule = :fieldRule'.
	 */
	public List<DtccFieldsMessageMappings> findWhereFieldRuleEquals(String fieldRule) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'src_field = :srcField'.
	 */
	public List<DtccFieldsMessageMappings> findWhereSrcFieldEquals(String srcField) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'default_value = :defaultValue'.
	 */
	public List<DtccFieldsMessageMappings> findWhereDefaultValueEquals(String defaultValue) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_xpath = :fieldXpath'.
	 */
	public List<DtccFieldsMessageMappings> findWhereFieldXpathEquals(String fieldXpath) throws DtccFieldsMessageMappingsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<DtccFieldsMessageMappings> findWhereCreateDatetimeEquals(Date createDatetime) throws DtccFieldsMessageMappingsDaoException;
	
	public List<DtccFieldsMessageMappings> findFieldsInCSVSeq() throws DtccFieldsMessageMappingsDaoException;
	
	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<DtccFieldsMessageMappings> findWhereSdrRepositoryEquals(String sdrRepository) throws DtccFieldsMessageMappingsDaoException;
}

