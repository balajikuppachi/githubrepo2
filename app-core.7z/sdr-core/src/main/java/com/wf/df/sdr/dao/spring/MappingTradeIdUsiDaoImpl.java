package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.MappingTradeIdUsiDao;
import com.wf.df.sdr.dto.MappingTradeIdUsi;
import com.wf.df.sdr.exception.dao.MappingTradeIdUsiDaoException;

public class MappingTradeIdUsiDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MappingTradeIdUsi>, MappingTradeIdUsiDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 *
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 *
	 * @param dto
	 */
	@Transactional
	public void insert(MappingTradeIdUsi dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( src_trade_id, asset_class, usi, create_datetime) VALUES ( ?, ?, ?, ?)",dto.getSrcTradeId(), dto.getAssetClass() , dto.getUsi(), dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 *
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return MappingTradeIdUsiMapping
	 */
	public MappingTradeIdUsi mapRow(ResultSet rs, int row) throws SQLException
	{
		MappingTradeIdUsi dto = new MappingTradeIdUsi();
		dto.setSrcTradeId( rs.getString( 1 ) );
		dto.setAssetClass( rs.getString( 2 ) );
		dto.setUsi( rs.getString( 3 ) );
		dto.setCreateDatetime( rs.getDate( 4 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 *
	 * @return String
	 */
	public String getTableName()
	{
		return "mapping_tradeid_usi_nr";
	}

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria ''.
	 */
	@Transactional
	public List<MappingTradeIdUsi> findAll() throws MappingTradeIdUsiDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_trade_id, asset_class, usi, create_datetime FROM " + getTableName() + " ORDER BY src_trade_id, asset_class", this);
		}
		catch (Exception e) {
			throw new MappingTradeIdUsiDaoException("Query failed", e);
		}

	}

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'src_trade_id = :srcTradeId'.
	 */
	@Transactional
	public List<MappingTradeIdUsi> findWhereSrcTradeIdEquals(String srcTradeId) throws MappingTradeIdUsiDaoException {
		try {
			return jdbcTemplate.query("SELECT src_trade_id, asset_class, usi, create_datetime FROM " + getTableName() + " WHERE src_trade_id = ? ORDER BY src_trade_id", this,srcTradeId);
		}
		catch (Exception e) {
			throw new MappingTradeIdUsiDaoException("Query failed", e);
		}
	}

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'asset_class = :assetClass'.
	 */
	@Transactional
	public List<MappingTradeIdUsi> findWhereAssetClassEquals(String assetClass) throws MappingTradeIdUsiDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_trade_id, asset_class, usi, create_datetime FROM " + getTableName() + " WHERE asset_class = ? ORDER BY asset_class", this,assetClass);
		}
		catch (Exception e) {
			throw new MappingTradeIdUsiDaoException("Query failed", e);
		}

	}

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<MappingTradeIdUsi> findWhereUsiEquals(String usi) throws MappingTradeIdUsiDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_trade_id, asset_class, usi, create_datetime FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new MappingTradeIdUsiDaoException("Query failed", e);
		}

	}

	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'create_datetime = :createDatetime'.
	 */
		@Transactional
		public List<MappingTradeIdUsi> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingTradeIdUsiDaoException
		{
			try {
				return jdbcTemplate.query("SELECT src_trade_id, asset_class, usi, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY createDatetime", this,createDatetime);
			}
			catch (Exception e) {
				throw new MappingTradeIdUsiDaoException("Query failed", e);
			}

	}


	/**
	 * Returns all rows from the mapping_tradeid_usi table that match the criteria 'src_trade_id = :srcTradeId and asset_class = :assetClass'.
	 */
	@Transactional
	public List<MappingTradeIdUsi> findWhereSrcTradeIdAssetClassEquals(String srcTradeId, String assetClass) throws MappingTradeIdUsiDaoException {
		try {
			return jdbcTemplate.query("SELECT src_trade_id, asset_class, usi, create_datetime FROM " + getTableName() + " WHERE src_trade_id = ? and asset_class = ? ORDER BY src_trade_id, asset_class", this,srcTradeId,assetClass);
		}
		catch (Exception e) {
			throw new MappingTradeIdUsiDaoException("Query failed", e);
		}
	}

	/**
	 * Returns cacheSize rows from the mapping_tradeid_usi table that match the criteria ''.
	 */
	public List<MappingTradeIdUsi> findAll(String cacheSize) {

		try {
			return jdbcTemplate.query("SELECT TOP "+cacheSize+" src_trade_id, asset_class, usi, create_datetime FROM " + getTableName() + " ORDER BY src_trade_id, asset_class", this);
		}
		catch (Exception e) {
			throw new MappingTradeIdUsiDaoException("Query failed", e);
		}

	
	}


}
