package com.wf.df.sdr.calc.equity;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqOptionsExpirationDateCalc {

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.eqOptionsExpirationDateCalc, isPrototype=false)
	public String compute(
			@DerivedFrom(value = Stv.ExpirationDate, isInternal = true) String expdate) {
		
		if(!Utils.IsNullOrBlank(expdate)){	
			try {
				return formatter.formatDateUTC(parser.parseDate(expdate));
			} catch (ParseException e) {
				throw new CalculationException("DateParse", "Field '" + Stv.ExpirationDate + "' = '" + expdate + "' cannot be interpreted as date");
			}
		}
		return Constants.EMPTY_STRING;
	}
	
}
