package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MsgToReport;
import com.wf.df.sdr.dto.MsgToReportStatus;
import com.wf.df.sdr.exception.dao.MsgToReportDaoException;

public interface MsgToReportDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(MsgToReport dto);

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria ''.
	 */
	public List<MsgToReport> findAll() throws MsgToReportDaoException;

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'send_id = :sendId'.
	 */
	public List<MsgToReport> findWhereSendIdEquals(BigDecimal sendId) throws MsgToReportDaoException;

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'msg_type = :msgType'.
	 */
	public List<MsgToReport> findWhereMsgTypeEquals(String msgType) throws MsgToReportDaoException;

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MsgToReport> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgToReportDaoException;

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'asset_class = :assetClass'.
	 */
	public List<MsgToReport> findWhereAssetClassEquals(String assetClass) throws MsgToReportDaoException;

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'out_msg_data = :outMsgData'.
	 */
	public List<MsgToReport> findWhereOutMsgDataEquals(String outMsgData) throws MsgToReportDaoException;
	
	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'usi = :usi'.
	 */
	public List<MsgToReport> findWhereUsiEquals(String usi) throws MsgToReportDaoException;

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'prev_usi = :prevUsi'.
	 */
	public List<MsgToReport> findWherePrevUsiEquals(String prevUsi) throws MsgToReportDaoException;
	
	/***
	 * Return max transmit Id from the msg_to_report table 
	 */
	public Long findMaxTransmitId(Long from, Long to);
	/**
	 * Return count of rows matching the sendId and USI
	 * 
	 */
	public Integer findMatchingRecords(String usi, BigDecimal sendId);
	/**
	 * Quey to check, if same buffer has already been created, used by BuffferComparator, to eliminate DUPLICATE buffer upload
	 * @param tradeId
	 * @param tlcEvent
	 * @param msgType
	 * @param assetClass
	 * @param usi
	 * @param status
	 * @return
	 * @throws MsgToReportDaoException
	 */
	public List<MsgToReport> findExistingTrade(String tradeId, String tlcEvent,String msgType, String assetClass, String usi, String status)
			throws MsgToReportDaoException;
	
	public List<MsgToReportStatus> findExistingTradeWithStatus(String tradeId, String tlcEvent,String msgType, String assetClass, String usi,String sdrRepo)
	throws MsgToReportDaoException;
	
	public List<MsgToReport> findExistingUSITrade(String tlcEvent,String msgType, String assetClass, String usi, String status)
	throws MsgToReportDaoException;
	
	public List<MsgToReportStatus> findExistingUSITradeWithStatus(String tlcEvent,String msgType, String assetClass, String usi)
	throws MsgToReportDaoException;

	public void updateUsiForSendId(BigDecimal sendId, String usi);
	
	public List<MsgToReport> findPaperConfirmTradeDetails(BigDecimal sendId) throws MsgToReportDaoException;
	
	public List<MsgToReport> findLastSubmittedMessage(String msgType, String assetClass, String usi, String status) throws MsgToReportDaoException;
	
	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<MsgToReport> findWhereSdrRepositoryEquals(String sdrRepository) throws MsgToReportDaoException;
	
	public List<MsgToReport> findRtPetWhereSendidEquals(BigDecimal sendId) throws MsgToReportDaoException;
	
	public List<MsgToReport> findExistingTradeByUsi(String tlcEvent,String msgType, String assetClass, String usi, String status)
	throws MsgToReportDaoException;
	
	
	//For retrieving submitted message based on Trace Id for ICE
	public List<MsgToReport> findLastSubmitedByTraceId(String traceId,String msgType);
	
}
