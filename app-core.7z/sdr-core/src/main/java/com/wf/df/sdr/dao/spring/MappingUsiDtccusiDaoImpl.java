package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.MappingUsiDtccusiDao;
import com.wf.df.sdr.dto.MappingUsiDtccusi;
import com.wf.df.sdr.exception.dao.MappingUsiDtccusiDaoException;
import com.wf.df.sdr.util.Constants;

public class MappingUsiDtccusiDaoImpl extends AbstractDAO implements MappingUsiDtccusiDao,ParameterizedRowMapper<MappingUsiDtccusi>{

	
	protected DataSource dataSource;
	protected SimpleJdbcTemplate jdbcTemplate;
	
	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return MappingUsiDtccusi
	 */
	public MappingUsiDtccusi mapRow(ResultSet result, int arg1) throws SQLException {
		MappingUsiDtccusi dto=new MappingUsiDtccusi();
		
		dto.setSendId(result.getBigDecimal(1));
		dto.setUsi(result.getString(2));
		dto.setDtccUsi(result.getString(3));
		dto.setCreateDatetime(result.getDate(4));
		dto.setUpdateDatetime(result.getDate(5));
		
		return dto;
	}
	private String getTableName() {
		return "mapping_usi_dtccusi";
	}

	/**
	 * insert.
	 *
	 * @param sendId the send id
	 * @param dtccUsi the dtcc usi
	 */
	@Transactional
	public void insert(MappingUsiDtccusi dto) {
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id,usi,dtccusi,create_datetime ,update_datetime) VALUES ( ?, ?, ?, ? ,?)",dto.getSendId(),dto.getUsi(),dto.getDtccUsi(),dto.getCreateDatetime(),dto.getUpdateDatetime());
		
	}

	/**
	 * Update dtcc usi for send id.
	 *
	 * @param sendId the send id
	 * @param dtccUsi the dtcc usi
	 */
	@Transactional
	public void updateDtccUsiForSendId(BigDecimal sendId, String dtccUsi) 
	{
		jdbcTemplate.update("UPDATE  "+getTableName()+" SET dtccusi = ?,update_datetime=? WHERE send_id = ?",dtccUsi,new Date(),sendId);
	}
	
	
	/**
	 * Method to insert new record. If a record already exists, update the existing one
	 * @param dto
	 */
	@Transactional
	public void saveOrUpdateMappingUsiDtccusi(MappingUsiDtccusi dto) {
		List<MappingUsiDtccusi> usiList;
			usiList = findWhereUsiEquals(dto.getUsi());
				if (usiList == null || usiList.size() == 0 || usiList.get(0) == null) {
					// add new record for usi
					insert(dto);
				} else {
					// update the existing row for usi
					updateMsgBufferForUSI(dto);
				}
	}
	@Transactional
	public void updateMsgBufferForUSI(MappingUsiDtccusi dto) 
	{
		jdbcTemplate.update("UPDATE "+getTableName()+" SET send_id = ?,update_datetime=? WHERE usi = ?",dto.getSendId(),new Date(),dto.getUsi());
		
	}

	@Transactional
	public List<MappingUsiDtccusi> findAll() throws MappingUsiDtccusiDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id,usi,dtccusi,create_datetime ,update_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MappingUsiDtccusiDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}

	@Transactional
	public List<MappingUsiDtccusi> findWhereSendIdEquals(BigDecimal sendId)throws MappingUsiDtccusiDaoException{
		try {
			return jdbcTemplate.query("SELECT send_id,usi,dtccusi,create_datetime ,update_datetime FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new MappingUsiDtccusiDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}

	@Transactional
	public List<MappingUsiDtccusi> findWhereUsiEquals(String usi)
			throws MappingUsiDtccusiDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id,usi,dtccusi,create_datetime ,update_datetime FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new MappingUsiDtccusiDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}

	@Transactional
	public List<MappingUsiDtccusi> findWhereDtccUsiEquals(String dtccUsi)
			throws MappingUsiDtccusiDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id,usi,dtccusi,create_datetime ,update_datetime FROM " + getTableName() + " WHERE dtccusi = ? ORDER BY send_id", this,dtccUsi);
		}
		catch (Exception e) {
			throw new MappingUsiDtccusiDaoException(Constants.EXCEPTION+"Query failed", e);
		}

	}

	@Transactional
	public List<MappingUsiDtccusi> findWhereUpdateDatetimeEquals(Date updateDatetime)
			throws MappingUsiDtccusiDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id,usi,dtccusi,create_datetime ,update_datetime FROM " + getTableName() + " WHERE update_datetime = ? ORDER BY update_datetime", this,updateDatetime);
		}
		catch (Exception e) {
			throw new MappingUsiDtccusiDaoException(Constants.EXCEPTION+"Query failed", e);
		}

	}

	@Transactional
	public List<MappingUsiDtccusi> findWhereCreateDatetimeEquals(Date createDatetime)
			throws MappingUsiDtccusiDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id,usi,dtccusi,create_datetime ,update_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new MappingUsiDtccusiDaoException(Constants.EXCEPTION+"Query failed", e);
		}

	}

	
}
