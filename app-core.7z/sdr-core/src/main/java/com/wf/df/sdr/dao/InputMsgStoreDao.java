package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.InputMsgStore;
import com.wf.df.sdr.exception.dao.InputMsgStoreDaoException;

public interface InputMsgStoreDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(InputMsgStore dto);

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria ''.
	 */
	public List<InputMsgStore> findAll() throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'send_id = :sendId'.
	 */
	public List<InputMsgStore> findWhereSendIdEquals(BigDecimal sendId) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_version = :srcTradeVersion'.
	 */
	public List<InputMsgStore> findWhereSrcTradeVersionEquals(String srcTradeVersion) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_system_name = :srcSystemName'.
	 */
	public List<InputMsgStore> findWhereSrcSystemNameEquals(String srcSystemName) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_id = :srcTradeId'.
	 */
	public List<InputMsgStore> findWhereSrcTradeIdEquals(String srcTradeId) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_asset_class = :srcAssetClass'.
	 */
	public List<InputMsgStore> findWhereSrcAssetClassEquals(String srcAssetClass) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_prod_type = :srcProdType'.
	 */
	public List<InputMsgStore> findWhereSrcProdTypeEquals(String srcProdType) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_sub_prod_type = :srcSubProdType'.
	 */
	public List<InputMsgStore> findWhereSrcSubProdTypeEquals(String srcSubProdType) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_date = :srcTradeDate'.
	 */
	public List<InputMsgStore> findWhereSrcTradeDateEquals(Date srcTradeDate) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_mat_date = :srcMatDate'.
	 */
	public List<InputMsgStore> findWhereSrcMatDateEquals(Date srcMatDate) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_tlc_event = :srcTlcEvent'.
	 */
	public List<InputMsgStore> findWhereSrcTlcEventEquals(String srcTlcEvent) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_status = :srcTradeStatus'.
	 */
	public List<InputMsgStore> findWhereSrcTradeStatusEquals(String srcTradeStatus) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_cparty_name = :srcCpartyName'.
	 */
	public List<InputMsgStore> findWhereSrcCpartyNameEquals(String srcCpartyName) throws InputMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_exec_datetime = :srcExecDatetime'.
	 */
	public List<InputMsgStore> findWhereSrcExecDatetimeEquals(Date srcExecDatetime) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_clearing_venue = :srcClearingVenue'.
	 */
	public List<InputMsgStore> findWhereSrcClearingVenueEquals(String srcClearingVenue) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_clearing_datetime = :srcClearingDatetime'.
	 */
	public List<InputMsgStore> findWhereSrcClearingDatetimeEquals(Date srcClearingDatetime) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_conf_platform = :srcConfPlatform'.
	 */
	public List<InputMsgStore> findWhereSrcConfPlatformEquals(String srcConfPlatform) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_conf_datetime = :srcConfDatetime'.
	 */
	public List<InputMsgStore> findWhereSrcConfDatetimeEquals(Date srcConfDatetime) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_conf_id = :srcConfId'.
	 */
	public List<InputMsgStore> findWhereSrcConfIdEquals(String srcConfId) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'usi = :usi'.
	 */
	public List<InputMsgStore> findWhereUsiEquals(String usi) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_msg_data = :srcMsgData'.
	 */
	//public List<InputMsgStore> findWhereSrcMsgDataEquals(String srcMsgData) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<InputMsgStore> findWhereCreateDatetimeEquals(Date createDatetime) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'prev_usi = :prevUsi'.
	 */
	public List<InputMsgStore> findWherePrevUsiEquals(String prevUsi) throws InputMsgStoreDaoException;

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'rep_party = :repParty'.
	 */
	public List<InputMsgStore> findWhereRepPartyEquals(String repParty)
			throws InputMsgStoreDaoException;

	public List<InputMsgStore> findWhereIsBackloadEquals(String isBackload)
			throws InputMsgStoreDaoException;

	List<InputMsgStore> findWhereParty1LEIEquals(String party1LEI)
			throws InputMsgStoreDaoException;

	List<InputMsgStore> findWhereParty2LEIEquals(String party2LEI)
			throws InputMsgStoreDaoException;

	@Deprecated
	public String findActionType(String assetClass, String msgType, String usi,
			String eventType, String tradeId) throws InputMsgStoreDaoException;

	public List<InputMsgStore> findTradesForValuation(String query,
			String assetClass) throws InputMsgStoreDaoException;
	
	public Integer countMatchingRecords(String tradeId, String tlcEvent, String usi) 
		throws InputMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<InputMsgStore> findWhereSdrRepositoryEquals(String sdrRepository)
			throws InputMsgStoreDaoException;

	public List<InputMsgStore> findWhereUtiEquals(String uti)
			throws InputMsgStoreDaoException;

	public List<InputMsgStore> findWhereUtiPreviousEquals(String utiPrevious)
			throws InputMsgStoreDaoException;

	public List<InputMsgStore> findWhereIsDelegatedEquals(Boolean isDelegated)
			throws InputMsgStoreDaoException;
	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'bus_acc_id = :busAccId'.
	 */
	public List<InputMsgStore> findWhereBusAccIdEquals(String busAccId) throws InputMsgStoreDaoException;

}
