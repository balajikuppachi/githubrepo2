package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class CollTradePartyPrefixCalc {

	@Value("${collateral.valuation.principlaIds.emir}") String principalIds;
	@Value("${collateral.valuation.leis.emir}") String leis;
	
	
	@Calculation(value = Calc.collTradePartyPrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value=Constants.COLLATERAL_PRINCIPAL_ID, isInternal=true) String principalId) {
		
			String[] vals = principalIds.split(Constants.COMMA);
			
			int index = 0;
			for(String val : vals) {
				if(principalId != null & principalId.equals(val)) {
					return (leis.split(Constants.COMMA)[index].split(Constants.COLON)[0]);
				}
				
				index++;
			}
			
			return null;
	}
	
}
