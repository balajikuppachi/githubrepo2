package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.ProductsMappingDao;
import com.wf.df.sdr.dto.ProductsMapping;
import com.wf.df.sdr.exception.dao.ProductsMappingDaoException;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class ProductsMappingDaoImpl extends AbstractDAO implements ParameterizedRowMapper<ProductsMapping>, ProductsMappingDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(ProductsMapping dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getSrcAssetClass(),dto.getSrcProdType(),dto.getSrcSubProdType(),dto.getDtccAssetClass(),dto.getDtccProdType(),dto.getDtccSubProdType(),dto.getDtccTransactionType(),dto.getKeyType(),dto.getKeyTypeDesc(),dto.getJurisdiction(),dto.getCreateDatetime(),dto.getMappingType());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return ProductsMapping
	 */
	public ProductsMapping mapRow(ResultSet rs, int row) throws SQLException
	{
		ProductsMapping dto = new ProductsMapping();
		dto.setSrcAssetClass( rs.getString( 1 ) );
		dto.setSrcProdType( rs.getString( 2 ) );
		dto.setSrcSubProdType( rs.getString( 3 ) );
		dto.setDtccAssetClass( rs.getString( 4 ) );
		dto.setDtccProdType( rs.getString( 5 ) );
		dto.setDtccSubProdType( rs.getString( 6 ) );
		dto.setDtccTransactionType( rs.getString( 7 ) );
		dto.setKeyType( rs.getString( 8 ) );
		dto.setKeyTypeDesc( rs.getString( 9 ) );
		dto.setJurisdiction( rs.getString( 10 ) );
		dto.setCreateDatetime( rs.getTimestamp(11 ) );
		dto.setMappingType( rs.getString( 12 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "products_mapping";
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria ''.
	 */
	@Transactional
	public List<ProductsMapping> findAll() throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'src_asset_class = :srcAssetClass'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereSrcAssetClassEquals(String srcAssetClass) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE src_asset_class = ? ORDER BY src_asset_class", this,srcAssetClass);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'src_prod_type = :srcProdType'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereSrcProdTypeEquals(String srcProdType) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE src_prod_type = ? ORDER BY src_prod_type", this,srcProdType);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'src_sub_prod_type = :srcSubProdType'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereSrcSubProdTypeEquals(String srcSubProdType) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE src_sub_prod_type = ? ORDER BY src_sub_prod_type", this,srcSubProdType);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_asset_class = :dtccAssetClass'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereDtccAssetClassEquals(String dtccAssetClass) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE dtcc_asset_class = ? ORDER BY dtcc_asset_class", this,dtccAssetClass);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_prod_type = :dtccProdType'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereDtccProdTypeEquals(String dtccProdType) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE dtcc_prod_type = ? ORDER BY dtcc_prod_type", this,dtccProdType);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_sub_prod_type = :dtccSubProdType'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereDtccSubProdTypeEquals(String dtccSubProdType) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE dtcc_sub_prod_type = ? ORDER BY dtcc_sub_prod_type", this,dtccSubProdType);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_transaction_type = :dtccTransactionType'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereDtccTransactionTypeEquals(String dtccTransactionType) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE dtcc_transaction_type = ? ORDER BY dtcc_transaction_type", this,dtccTransactionType);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'key_type = :keyType'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereKeyTypeEquals(String keyType) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE key_type = ? ORDER BY key_type", this,keyType);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'key_type_desc = :keyTypeDesc'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereKeyTypeDescEquals(String keyTypeDesc) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE key_type_desc = ? ORDER BY key_type_desc", this,keyTypeDesc);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'jurisdiction = :jurisdiction'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereJurisdictionEquals(String jurisdiction) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE jurisdiction = ? ORDER BY jurisdiction", this,jurisdiction);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereCreateDatetimeEquals(Date createDatetime) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'mapping_type = :mappingType'.
	 */
	@Transactional
	public List<ProductsMapping> findWhereMappingTypeEquals(String mappingType) throws ProductsMappingDaoException
	{
		try {
			return jdbcTemplate.query("SELECT src_asset_class, src_prod_type, src_sub_prod_type, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, dtcc_transaction_type, key_type, key_type_desc, jurisdiction, create_datetime, mapping_type FROM " + getTableName() + " WHERE mapping_type = ? ORDER BY mapping_type", this,mappingType);
		}
		catch (Exception e) {
			throw new ProductsMappingDaoException("Query failed", e);
		}
		
	}

}
