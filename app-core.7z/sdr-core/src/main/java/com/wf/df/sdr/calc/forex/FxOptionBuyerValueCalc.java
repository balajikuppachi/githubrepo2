package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxOptionBuyerValueCalc {
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.fxOptionBuyerValueCalc)
	public String fxOptionBuyerValueCalc(
			@DerivedFrom(value=Calc.fxWfParticipantIdCalc) String wfValue,
			@DerivedFrom(value=Calc.fxCptyParticipantIdCalc) String cptyValue,
			@DerivedFrom(value = Stv.FXOptionIsBuyFlag) String optionIsBuyFlag)	{
		if(!Utils.IsNullOrBlank(optionIsBuyFlag)  )
		{
		
			if(Constants.TRUE.equals(optionIsBuyFlag) && !Utils.IsNullOrBlank(wfValue))
			{	 return wfValue;
			}else if(Constants.FALSE.equals(optionIsBuyFlag) && !Utils.IsNullOrBlank(cptyValue))
			{  	 return cptyValue;
			}
			
		}
		return Constants.EMPTY_STRING;
	}
}
