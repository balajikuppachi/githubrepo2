package com.wf.df.sdr.calc.commodity;


/**
 * @author u250429
 *
 */
public class LifecycleStatusQueryResponseBO {
	
	private PendingRequestsBO pr;
	private InboundRequestsBO ir;
	/**
	 * @return the pr
	 */
	public PendingRequestsBO getPr() {
		return pr;
	}
	/**
	 * @param pr the pr to set
	 */
	public void setPr(PendingRequestsBO pr) {
		this.pr = pr;
	}
	/**
	 * @return the ir
	 */
	public InboundRequestsBO getIr() {
		return ir;
	}
	/**
	 * @param ir the ir to set
	 */
	public void setIr(InboundRequestsBO ir) {
		this.ir = ir;
	}
}
