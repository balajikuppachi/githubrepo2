package com.wf.df.sdr.calc.xasset;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class CollDataSubmitterMsgIdCalc {

	@Calculation(value = Calc.collDataSubmitterMsgIdCalc, isPrototype = false)
	public String wFTransId(
			@DerivedFrom(value=Constants.TRANSMIT_ID, isInternal=true) BigDecimal transmitId,
			@DerivedFrom(value=Constants.SEND_ID, isInternal=true) BigDecimal sendId)	{
		
		return Constants.TRANS_ID_SEPARATOR + Constants.TRANS_ID_SEPARATOR + sendId.toString() + Constants.TRANS_ID_SEPARATOR
				+ transmitId.toString();  
	
	}
	
}
