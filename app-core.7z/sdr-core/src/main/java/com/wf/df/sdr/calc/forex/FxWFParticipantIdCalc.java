package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxWFParticipantIdCalc {

	@Calculation(value= Calc.fxWfParticipantIdCalc, isPrototype = false)
	public String wFPartyCalc(@DerivedFrom(value = Calc.wfParticipantIdCalc, isInternal = true) String wfParticipantId)	{
		return wfParticipantId;
		}
}
