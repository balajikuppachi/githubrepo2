package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

	@Component(value="sdrReportableFilter")
	public class SDRReportableFilter {
		
		@Autowired
		NotEligblePersister nep;
		
		Logger log = Logger.getLogger(getClass());

		public boolean isSDRReportable(UnitOfWork uow) {
			CalculationContext cc = uow.getCalculationContext();
			String sdrReportableFlag = cc.getValue(Stv.SDR_REPORTABLE, String.class);
			
			if(Constants.FALSE.equalsIgnoreCase(sdrReportableFlag)){
				log.debug("SDR Reportable came in as :" + sdrReportableFlag);
				// Save it in NotSendPersister
				nep.save(uow, NotEligblePersister.SDRNonReportable);
				//nep.deleteEODBuffer(uow.getUSI());
				return false;
			} 
			return true;
		}
	}

