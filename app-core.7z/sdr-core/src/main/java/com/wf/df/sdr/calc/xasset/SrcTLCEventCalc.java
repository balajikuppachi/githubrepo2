package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class SrcTLCEventCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value=Calc.srcTLCEventCalc, isPrototype=false)
	public String srcEvent (
		@DerivedFrom(value=Calc.srcAssetClassCalc, isInternal=true) String srcAssetClass,
		@DerivedFrom(value=Calc.isSwapswireTradeCalc , isInternal=true) Boolean mwTrade,
		@DerivedFrom(value=Stv.MarketType, isInternal=true) String marketType,
		@DerivedFrom(value=Stv.LifecycleEvent , isInternal=true) String equityEventType/*,
		@DerivedFrom(value=Stv.DocAction, isInternal=true) String docAction*/)
	{
		if (Constants.ASSET_CLASS_INTEREST_RATE.equals(srcAssetClass) || Constants.ASSET_CLASS_CREDIT.equals(srcAssetClass)) {
			if (mwTrade && Utils.IsNullOrBlank(marketType))
				return Constants.NONE;
			return marketType;
		} /*else if (Constants.ASSET_CLASS_CREDIT.equals(srcAssetClass)){
			if(Constants.Amendment.equals(marketType))
				return marketType;
			return docAction;
		} */else if (Constants.ASSET_CLASS_EQUITY.equals(srcAssetClass)) {
			return equityEventType;
		}
		else {
			return Constants.NOT_FOUND;
		}
	}
}
