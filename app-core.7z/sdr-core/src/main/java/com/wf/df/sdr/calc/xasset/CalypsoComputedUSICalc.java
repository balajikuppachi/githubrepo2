package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.InputMsgStoreExtnDao;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class CalypsoComputedUSICalc {

	Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	InputMsgStoreExtnDao dao;

	@Calculation(value = Calc.calypsoComputedUSICalc, isPrototype = false)
	public String usi(@DerivedFrom(value = Stv.USI_CURRENT, isInternal = true) String usi,
			@DerivedFrom(value=Calc.sdrRepositoryCalc, isInternal = true) String sdrRepository,
			@DerivedFrom(value=Calc.calypsoComputedUTICalc, isInternal = true) String uti,
			@DerivedFrom(value = Stv.TLCRootTradeId, isInternal = true) String tlcRootId,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String assetClass) {
		
		if(StringUtils.equals(sdrRepository, Constants.EMIR) && !Utils.IsNullOrBlank(uti)){
			return uti;
		} 
		
		if (!StringUtils.equals(sdrRepository, Constants.EMIR) && !Utils.IsNullOrBlank(usi))
		{
				return usi;
		}
		
			return Constants.EMPTY_STRING;
	}
}
