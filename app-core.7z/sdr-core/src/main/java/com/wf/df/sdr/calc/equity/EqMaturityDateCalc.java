package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class EqMaturityDateCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqMaturityDateCalc, isPrototype = false)
	public String buyer(
			@DerivedFrom(value = Calc.eqTerminationDateCalc, isInternal = true) String terminationDate,
			@DerivedFrom(value = Calc.eqFinalValuationDateCalc, isInternal = true) String valuationDate,
			@DerivedFrom(value = Calc.eqUpiTemplateCalc, isInternal = true) String template) {
				
		if(Constants.EqTemplate_StructuredProduct.equals(template)){
			return terminationDate;
		}		
		
		return valuationDate;
	}
}
