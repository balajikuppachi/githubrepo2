package com.wf.df.sdr.calc.equity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class EqUpiTemplateCalc {

	@Autowired DTCCUtils dtccUtil;
		
	@Calculation(value = Calc.eqUpiTemplateCalc, isPrototype = false)
	public String buyer(
			@DerivedFrom(value = Stv.UPI, isInternal = true) String upi) {

		return dtccUtil.getEquityTemplateForUpi(upi);
		
	}
	
}
