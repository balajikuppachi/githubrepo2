package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.CollateralAgreementTradeLevel;
import com.wf.df.sdr.exception.dao.CollateralAgreementsDaoException;

public interface CollateralAgreementTradeLevelDao  {

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(CollateralAgreementTradeLevel dto);

	/** 
	 * Returns all rows from the trade_collateralization table that match the criteria ''.
	 */
	public List<CollateralAgreementTradeLevel> findAll() throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the trade_collateralization table that match the criteria 'trade_id = :trade_id'.
	 */
	public List<CollateralAgreementTradeLevel> findWhereTradeIdEquals(String trade_id) throws CollateralAgreementsDaoException;
	
	/** 
	 * Returns all rows from the trade_collateralization table that match the criteria 'trade_id = :trade_id' and source system.
	 */
	public List<CollateralAgreementTradeLevel> findWhereTradeIdSourceEquals(String trade_id, String srcSystem) throws CollateralAgreementsDaoException;
	
	/** 
	 * Returns all rows from the trade_collateralization table that match the criteria 'trade_id = :trade_id' and source system.
	 */
	public List<CollateralAgreementTradeLevel> findWhereEQTickerIDSourceEquals(String tickerID, String srcSystem) throws CollateralAgreementsDaoException;
	
}
