package com.wf.df.sdr.calc.xasset;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.EODBufferStoreEmirDao;
import com.wf.df.sdr.dto.EODBufferStoreEmir;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;


@Component
public class DoesEmirBufferExistCalc {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	EODBufferStoreEmirDao eODBufferStoreEmirDao;
	
	
	@Calculation(value = Calc.doesEmirBufferExistCalc, isPrototype = false)
	public boolean compute(
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String tradeId,
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String tlcEvent,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType,
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass,
			@DerivedFrom(value = Calc.calypsoComputedUTICalc, isInternal = true) String uti,
			@DerivedFrom(value = Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isDelegated) {

		logger.debug("Compute called :" + " TradeId = " + tradeId + " TlcEvent = " + tlcEvent + " Message Type= " + msgType
				+ " Asset class = " + assetClass + " UTI = " + uti);

		List<EODBufferStoreEmir> bufferList = eODBufferStoreEmirDao.findExistingTrade(assetClass, msgType, tradeId, uti, tlcEvent, isDelegated);
		if (!Utils.IsListNullOrEmpty(bufferList)) {
				return true;
		}

		return false;
	}
	
}
