package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component(value = "delegatedTradeFilter")
public class DelegatedTradeFilter {

	@Autowired
	NotEligblePersister nep;
	
	@Value("${enable.delegate.reporting}") String delegateEnabled;

	Logger log = Logger.getLogger(getClass());

	public boolean isDelegatedEligible(UnitOfWork uow) {
		CalculationContext cc = uow.getCalculationContext();

		boolean isDelegated  = cc.getValue(Calc.isDelegatedTradeCalc, Boolean.class);
		
		if(isDelegated && Constants.FALSE.equalsIgnoreCase(delegateEnabled)) {
			log.info("Delegated Trade not eligible: ");
			nep.save(uow, NotEligblePersister.EmirDelegatedTrade);
			
			return false;
		}
		
		return true;
	}
}
