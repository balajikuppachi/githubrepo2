package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.EODBufferEmirRecord;
import com.wf.df.sdr.dto.EODBufferRecord;
import com.wf.df.sdr.dto.EODBufferStore;
import com.wf.df.sdr.dto.EODBufferStoreEmir;
import com.wf.df.sdr.dto.MappingTradeLei;
import com.wf.df.sdr.exception.dao.EODBufferStoreDaoException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Repository
public class EODBufferStoreExtnDao {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	EODBufferStoreDao snapshotDao;
	
	@Autowired
	FormatterService formatterService;
	
	@Value("${eod.report.query}")	String eodQuery;
	
	@Value("${eod.report.query.emir}")	String eodQueryEmir;
	
	@Value("${eod.report.query.cad}")	String eodQueryCad;
	
	@Value("${eod.report.query.galaxy}")	String eodQueryGalaxy;
	
	@Value("${eod.report.cad.query.galaxy}")	String eodCADQueryGalaxy;
	
	@Value("${eod.incremental.report.query}")	String eodIncReportQuery;
	
	@Value("${eod.incremental.report.query.emir}")	String eodIncEmirReportQuery;
	
	@Value("${eod.incremental.report.query.cad}")	String eodIncCadReportQuery;
	
	@Value("${eod.find.unique.usi.list.cftc}") String eodFindUniqueCftcUsiQuery;
	
	@Value("${eod.find.unique.usi.list.emir.cad}") String eodFindUniqueEmirCadUsiQuery;
	
	@Value("${eod.report.max.query.emir}") String eodFindMaxSendId;	
	
	@Value("${eod.report.max.query.cad}") String eodFindCadMaxSendId;
	
	private static String eodUpdateQuery = "UPDATE eod_buffer_store SET msg_buffer = ? , update_datetime = ? , send_id = ? , template_id=?  WHERE usi = ? AND msg_type = ?";
	
	@Transactional
	public void updateMsgBufferForUSI(EODBufferStore dto) {
		int recordUpdated = jdbcTemplate.update(eodUpdateQuery,new Object[] { dto.getMsgBuffer(), new Date(),dto.getSendId(), dto.getTemplateId(),dto.getUsi(), dto.getMsgType() });
	}
	
/**
 * Method to insert new record. If a record already exists, update the existing one
 * @param dto
 */
	@Transactional
	public void saveOrUpdateEODBuffer(EODBufferStore dto) {
		List<EODBufferStore> usiList;
		try {
			usiList = snapshotDao.findWhereUsiAndMsgTypeEquals(dto.getUsi(), dto.getMsgType(),dto.getSdrRepository());
				if (usiList == null || usiList.size() == 0 || usiList.get(0) == null) {
					// add new record for usi
					snapshotDao.insert(dto);
				} else {
					// update the existing row for usi
					updateMsgBufferForUSI(dto);
				}
		} catch (EODBufferStoreDaoException e) {
			logger.info(e.getMessage(), e);
		}
	}
	
	
	@Transactional
	public List<EODBufferRecord> fetchEODTradeforReport(String assetClass, String msgType, String sdrRepository) {
		List<EODBufferRecord> rsList = jdbcTemplate.query(eodQuery,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						m.setUsi(rs.getString("usi"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<EODBufferRecord> fetchGalaxyEODTradeforReport(String assetClass, String msgType,String sdrRepo) {
		List<EODBufferRecord> rsList = jdbcTemplate.query(eodQueryGalaxy,new Object[] {assetClass, msgType,sdrRepo}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						
						String templateId = rs.getString("template_id");
						
						m.setUsi(rs.getString("usi"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setTemplateId(templateId);
						m.setSdrRepository(rs.getString("sdr_repository"));
						
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						record.setTemplateId(templateId);
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	
	
	
	@Transactional
	public List<EODBufferRecord> fetchEODIncrementalTradeforReport(String assetClass, String msgType,String sdrRepository) {
		List<EODBufferRecord> rsList = jdbcTemplate.query(eodIncReportQuery,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						m.setUsi(rs.getString("usi"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public void removeBuffers(String usiString) {
		logger.warn("Deleting buffers for the list of USI  :"+ usiString);
		String query = "DELETE FROM eod_buffer_store where usi in (" + usiString + ")";		
		jdbcTemplate.execute(query);

		removeTradeLeiMapping(usiString);
	}
	
	@Transactional
	public void removeBuffersForUsi(String usi) {
		logger.warn("Deleting EOD buffers for the USI  :"+ usi);
		String query = "DELETE FROM eod_buffer_store where usi = ?";		
		jdbcTemplate.update(query, usi );

		removeTradeLeiMapping("'"+usi+"'");
	}
	
	private void removeTradeLeiMapping(String usiString) {
		logger.warn("Deleting trade LEI mapping for the list of USI  :"+ usiString);
		String query = "DELETE FROM mapping_trade_lei where usi in (" + usiString + ")";		
		jdbcTemplate.execute(query);

	}
	
	@Transactional
	public int updateMsgBufferForNewLEI(final MappingTradeLei dto) 
	{
		String leiUpdateQuery="update eod_buffer_store set msg_buffer = str_replace (convert(varchar(16384), msg_buffer),?,?) where send_id=?";
		return jdbcTemplate.update(leiUpdateQuery,dto.getCurrentLei().replace(":", ","), dto.getNewLei().replace(":", ","),dto.getSendId() ) ;
	}
	
	@Transactional
	public int updateMsgBufferForResponseUSI(String reportedUsi, String responseUsi, BigDecimal sendId) 
	{
		String usiUpdateQuery="update eod_buffer_store set msg_buffer = str_replace (convert(varchar(16384), msg_buffer),?,?) where send_id=?";
		return jdbcTemplate.update(usiUpdateQuery, reportedUsi, responseUsi,sendId ) ;
	}
	
	@Transactional
	public int updateMsgBufferForResponseUSI(String reportedUsi, String responseUsi, String tradeUsi) 
	{
		String usiUpdateQuery="update eod_buffer_store set msg_buffer = str_replace (convert(varchar(16384), msg_buffer),?,?) where usi=?";
		return jdbcTemplate.update(usiUpdateQuery, reportedUsi, responseUsi, tradeUsi ) ;
	}
	
	@Transactional
	public int updateEodMsgBuffer(String buffer, String usi, String msgType) 
	{
		String usiUpdateQuery="UPDATE eod_buffer_store SET msg_buffer = ?, update_datetime = getDate() where usi = ? AND msg_type = ?";
		return jdbcTemplate.update(usiUpdateQuery, buffer, usi, msgType ) ;
	}
	
	@Transactional
	public int removeGlobalCancelTrades() 
	{
		String query="delete from eod_buffer_store where msg_buffer like '%?%'";
		return jdbcTemplate.update(query, Constants.GLOBAL_CANCEL ) ;
	}
	
	@Transactional
	public int removeMaturedTrades(String assetClass, String msgType, Date date) 
	{
		String dateString = formatterService.formatDateUTC(date);
		logger.info("Removing matured trades for "+assetClass+":"+msgType+" and Repository : DTCC");
		String query="DELETE FROM eod_buffer_store FROM eod_buffer_store ebs, input_msg_store ims where ims.send_id = ebs.send_id and ebs.asset_class = ? and ebs.msg_type = ? and ims.src_mat_date < ?";
		return jdbcTemplate.update(query, assetClass, msgType, dateString);
	}
	

	
	public List<String> findDistinctUsi(String msgType, String sdrRepository, String assetClass) 
	{
		List<String> usiLst= null;
		if(Constants.DTCC.equalsIgnoreCase(sdrRepository))
		{
			logger.info("findDistinctUsi "+assetClass+":"+msgType+" and Repository :"+sdrRepository);
			logger.info("query--"+eodFindUniqueCftcUsiQuery);
			usiLst=jdbcTemplate.queryForList(eodFindUniqueCftcUsiQuery,String.class,assetClass,msgType,sdrRepository);
		}
		if(Constants.EMIR.equalsIgnoreCase(sdrRepository) || Constants.CAD.equalsIgnoreCase(sdrRepository))
		{
			logger.info("findDistinctUsi "+assetClass+":"+msgType+" and Repository :"+sdrRepository);
			logger.info("query--"+eodFindUniqueEmirCadUsiQuery);
			usiLst=jdbcTemplate.queryForList(eodFindUniqueEmirCadUsiQuery,String.class,assetClass,msgType,sdrRepository);
		}
		return  usiLst;
	}
						

					
	/*
     * Remove all send id matching in EOD for Msg_Type
     * 
     * */
	@Transactional
    public int removeAllBuffersForTradeId(String tradeId, String msgType){
						
		logger.warn("Deleting "+msgType+" messages from eod for trade_id: "+tradeId);
		String query = "DELETE FROM eod_buffer_store where send_id IN ( select send_id from input_msg_store where src_trade_id = '"+tradeId+"') and msg_type= '"+msgType+"'";
		try {
			return jdbcTemplate.update(query);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
						}
					}


	@Transactional
    public int deleteBuffersForUSITradeId(String usi , String tradeId){
						
		logger.warn("Deleting RP messages from eod_buffer_store for trade_id: "+tradeId +" , usi :"+usi);
		String query = "DELETE FROM eod_buffer_store FROM eod_buffer_store e, input_msg_store ims WHERE ims.send_id=e.send_id and ims.usi=?  and ims.src_trade_id=? ";
		try {
			return jdbcTemplate.update(query,usi,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
						}
		}
	

} 