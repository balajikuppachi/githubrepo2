package com.wf.df.sdr.filters.utility;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.utility.UtilityNotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class UtilityTrade123Filter {

	@Autowired
	UtilityNotEligblePersister nep;
	
	Logger logger = Logger.getLogger(getClass());
	
	public boolean is123TradeEligible(UnitOfWork uow) {
		logger.debug("Trade123Filter Called");
		
		CalculationContext cc = uow.getCalculationContext();
		String tradeType123_456 = cc.getValue(Constants.TradeType123_456, String.class);
		String docStatus = cc.getValue(Stv.CalypsoDocStatus, String.class);
		String usi = cc.getValue(Calc.computedUSICalc, String.class);
		String usiPrevious = cc.getValue(Stv.USI_PREVIOUS, String.class);
		String marketType = cc.getString(Calc.srcTLCEventCalc);
		String calypsoDocStatus = cc.getValue(Stv.CalypsoDocStatus, String.class);
		boolean isSwapswireTrade = cc.getValue(Calc.isSwapswireTradeCalc, Boolean.class);
		String tradeId = cc.getValue(Stv.TradeId, String.class);
		String tradeVer = cc.getValue(Stv.TradeVersion, String.class);
		
		//Swapswire Trade not to be filtered
		if(isSwapswireTrade)
			return true;
		
		//Deleting the USI buffers for Full Novation OR & RP
		//Related to QC 3383
		//Credit Novation OR
		if(Constants.NonReportable123.equals(tradeType123_456) && Constants.NC_ACCEPTED_OR.equals(docStatus)) {
			logger.info("Deleting EOD buffers for Credit_Novation_OR:USI  :"+ usi);
			logger.info("ME_Msg: " + tradeId + "~" + tradeVer + " ~ " + usi + "~" + usiPrevious + "~" + marketType + "~" + calypsoDocStatus + "~" + "Credit_Novation_OR");
			if(usi!=null && StringUtils.isNotBlank(usi)){
				nep.deleteEODBufferForAllSendId(tradeId);
				nep.deleteEODNotReportingBufferForAllSendId(tradeId);
			}
		}
		//Rates Novation OR
		else if(Constants.Novation_OR.equals(marketType) && (Constants.ASSIGNED.equals(docStatus) || Constants.DAY_ASSIGNED.equals(docStatus))){
			logger.info("Deleting EOD buffers for Novation_OR:USI  :"+ usi);
			logger.info("ME_Msg: " + tradeId + "~" + tradeVer + " ~ " + usi + "~" + usiPrevious + "~" + marketType + "~" + calypsoDocStatus + "~" + "Novation_OR");
			if(usi!=null && StringUtils.isNotBlank(usi)){
				nep.deleteEODBufferForAllSendId(tradeId);
				nep.deleteEODNotReportingBufferForAllSendId(tradeId);
			}
		}
		//Credit Full Novation RP
		else if(Constants.NonReportable123.equals(tradeType123_456) && Constants.Credit_Novation_RP.equals(marketType) 
				&& Constants.TRADE_STATUS_VERIFIED.equals(docStatus)) {
			logger.info("Deleting EOD buffers for Credit_Novation_RP:USI  :"+ usi);
			logger.info("ME_Msg: " + tradeId + "~" + tradeVer + " ~ " + usi + "~" + usiPrevious + "~" + marketType + "~" + calypsoDocStatus + "~" + "Credit_Novation_RP");
			if(usi!=null && StringUtils.isNotBlank(usi)){
				nep.deleteEODBufferForAllSendId(tradeId);
				nep.deleteEODNotReportingBufferForAllSendId(tradeId);
			}
		}
		//Rates Full Novation RP
		else if(Constants.NonReportable123.equals(tradeType123_456) && Constants.Novation_RP.equals(marketType) 
				&& (Constants.ASSIGNED.equals(docStatus) || Constants.DAY_ASSIGNED.equals(docStatus))) {
			logger.info("Deleting EOD buffers for Novation_RP:USI  :"+ usi);
			logger.info("ME_Msg: " + tradeId + "~" + tradeVer + " ~ " + usi + "~" + usiPrevious + "~" + marketType + "~" + calypsoDocStatus + "~" + "Novation_RP");
			if(usi!=null && StringUtils.isNotBlank(usi)){
				nep.deleteEODBufferForAllSendId(tradeId);
				nep.deleteEODNotReportingBufferForAllSendId(tradeId);
			}
		}
		
		//123 trade shouldn't be reported
		if(Constants.NonReportable123.equals(tradeType123_456)){
			nep.save(uow, UtilityNotEligblePersister.NonReportable123);			
			logger.debug("123 trade not to be processed");
			return false;
		}	
		if(Constants.NonReportable456.equals(tradeType123_456)){
			nep.save(uow, UtilityNotEligblePersister.NonReportable456);			
			logger.debug("456 trade not to be processed");
			return false;
		}
		
		return true;
	}
	
}
