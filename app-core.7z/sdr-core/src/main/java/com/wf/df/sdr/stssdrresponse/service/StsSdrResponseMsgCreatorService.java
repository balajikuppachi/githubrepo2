package com.wf.df.sdr.stssdrresponse.service;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.dao.InputMsgStoreDao;
import com.wf.df.sdr.dto.InputMsgStore;
import com.wf.df.sdr.stsfeed.dto.StsXmlFeed;
import com.wf.df.sdr.stsresponse.bo.MessageType;
import com.wf.df.sdr.stsresponse.bo.RegRepResponse;
import com.wf.df.sdr.stsresponse.bo.ResponseCodeEnum;
import com.wf.df.sdr.stssdrresponse.bo.SdrResponse;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

/**
 * @author u235720
 *
 */
@Component
public class StsSdrResponseMsgCreatorService {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	InputMsgStoreDao inputMsgStoreDao;
	
	@Value("${config.env}")
	private String sdrEnvironment;
	
	private JAXBContext jaxbContext = null;
	private  Marshaller jaxbMarshaller = null;
	
	@PostConstruct
	public void initialize()
	{
		try {
			
			jaxbContext = JAXBContext.newInstance(SdrResponse.class);
			jaxbMarshaller = jaxbContext.createMarshaller();
		} catch (JAXBException e) {
			 logger.warn("#### Error while creating sts response XML marshaller for STS "+ e.getClass().getName(), e.fillInStackTrace());
		}
		
	}
	
	
	public StsXmlFeed createSdrResponseMsg(RegRepResponse rm)
	{
		// Constructing Sdr Response
		
		InputMsgStore ims=LookUpTradeInSDR(rm);
		
		StsXmlFeed dto = new StsXmlFeed();
		if(!Utils.IsNullOrBlank(ims))
		{
			logger.info("Creating Response message for the tradeId:"+ims.getSrcTradeId() +", SendId"+ims.getSendId());
			SdrResponse sdrResponse = new SdrResponse();
			
			String foMessageId=StringUtils.split(rm.getMessageId(),Constants.COLON)[3];
			
			sdrResponse.setFoMessageId(foMessageId);
			sdrResponse.setFoSystem(ims.getSrcSystemName());
			sdrResponse.setFoTradeId(ims.getSrcTradeId());
			
			String reportingJurisdiction = getFormattedRepJurisdiction(rm.getReportingJurisdiction());
			
			sdrResponse.setReportingJurisdiction(reportingJurisdiction);
			
			ResponseCodeEnum responseCode = rm.getResponseCode();
			if(responseCode == ResponseCodeEnum.VALIDATION_ERROR){
				responseCode = ResponseCodeEnum.NACK;
			}
			
			sdrResponse.setResponseCode(responseCode.value());
			sdrResponse.setResponseTimestamp(Utils.getGregorianCurrentDate());
			sdrResponse.setSdrMessageId(rm.getMessageId());
			sdrResponse.setSdrSystem(sdrEnvironment);
			
			/** STR-328 ACK/NACK Issues*/
			sdrResponse.setResponseInternal(rm.isResponseInternal());
			
			List<MessageType> messageTypes = rm.getMessage();
			for(MessageType regRepResponseMessageType : messageTypes){
				
				com.wf.df.sdr.stssdrresponse.bo.MessageType sdrResponseMessageType = new com.wf.df.sdr.stssdrresponse.bo.MessageType();
				if (!Utils.IsNullOrBlank(regRepResponseMessageType.getDescription()) && regRepResponseMessageType.getDescription().startsWith(Constants.GTR)	&& regRepResponseMessageType.getDescription().contains(Constants.USI)){
					
					sdrResponseMessageType.setValue(null != regRepResponseMessageType.getValue() ? StringUtils.remove(regRepResponseMessageType.getValue(),Constants.COLON) : responseCode.value());
					sdrResponseMessageType.setDescription(regRepResponseMessageType.getDescription());
						
				}else
				{
					sdrResponseMessageType.setValue(null != regRepResponseMessageType.getValue() ? regRepResponseMessageType.getValue() : responseCode.value());
					sdrResponseMessageType.setDescription(regRepResponseMessageType.getDescription());
						
				}
				sdrResponse.getMessage().add(sdrResponseMessageType);
			}
			
			// Marshalling Sdr Response
			String foXml = getMarshalledResponse(sdrResponse);
			
			// TODO : Mapping has to be validated/corrected.
			dto = prepareStsXmlFeedObjectToPersist(rm, ims, foXml);
		}
		
		return dto;
	}

	private String getFormattedRepJurisdiction(String reportingJurisdiction) {
		
		String formattedJurisdiction = null;
		
		if(null != reportingJurisdiction && reportingJurisdiction.contains(";")){
			String[] inputArr = reportingJurisdiction.split(";");
			
			Set<String> jurisdictionSet = new LinkedHashSet((Arrays.asList(inputArr)));
			
			String[] outoutArr = (String[])jurisdictionSet.toArray(new String[jurisdictionSet.size()]);
			
			formattedJurisdiction = StringUtils.join(outoutArr, ';');
			
		}else{
			formattedJurisdiction = reportingJurisdiction;
		}
		
		return formattedJurisdiction;
	}

	private StsXmlFeed prepareStsXmlFeedObjectToPersist(RegRepResponse rm,
			InputMsgStore ims, String foXml) {
		StsXmlFeed dto = new StsXmlFeed();
		dto.setAssetClass(ims.getSrcAssetClass());
		dto.setMsgBuffer(foXml);
		String sendId=StringUtils.split(rm.getMessageId(),Constants.COLON)[2];
		dto.setSendId(new BigDecimal(sendId));
		
		String usi = (null != ims.getUsi() ? ims.getUsi() : ims.getUti());
		
		dto.setUsi(usi);
		dto.setUpdateDatetime(new Date());
		dto.setMsgType(Constants.STSRESPONSE);
		dto.setSdrRepository(ims.getSdrRepository());
		dto.setTradeId(ims.getSrcTradeId());
		dto.setInputBufferId(ims.getBufferId());
		dto.setValidXml(true);
		return dto;
	}

	private InputMsgStore LookUpTradeInSDR(RegRepResponse rm) {
		
		InputMsgStore imsRet= null;
		String messageID[]=StringUtils.split(rm.getMessageId(),Constants.COLON);
		
		if(!Utils.IsNullOrBlank(messageID) && messageID.length>1)
		{
			String sendId=StringUtils.split(rm.getMessageId(),Constants.COLON)[2];
			List<InputMsgStore> imsList=inputMsgStoreDao.findWhereSendIdEquals(new BigDecimal(sendId));
			if(!Utils.IsListNullOrEmpty(imsList))
				imsRet=imsList.get(0);
			return imsRet;
		}
		logger.warn("Could find the trades in SDR for MessageID : "+rm.getMessageId());
		return null;
	}
	
	private String getMarshalledResponse(SdrResponse sdrResponse) {
		
		String foXml = null;
		try 
		{ 
			StringWriter writer = new StringWriter();
			
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			jaxbMarshaller.marshal(sdrResponse, writer);

			
			foXml = writer.toString();

		 } catch (JAXBException e) {
			 logger.error(e.getMessage());
	     }
		return foXml;
	}
	
}
