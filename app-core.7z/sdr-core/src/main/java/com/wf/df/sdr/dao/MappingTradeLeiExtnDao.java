package com.wf.df.sdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.wf.df.sdr.dto.MappingTradeLei;

@Repository
public class MappingTradeLeiExtnDao {
	
private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	

	@Value("${trades.busacct.lei.mapping.update}") String updateNewLeiQuery;
	@Value("${trades.newlei.details.query}") String newLeiDetailsQuery;
	

	public int updateLeiInTradesLeiMapping( ) {
		logger.debug("updateLeiInTradesLeiMapping");
		int cnt=jdbcTemplate.update(updateNewLeiQuery);
		logger.debug("updateLei In MappingTradeLei: No. of rows updated:"+cnt);
		return cnt;
	}
	public List<MappingTradeLei> findNewLeiDetails() {
		logger.debug("findNewLeiDetails");
		List<MappingTradeLei> resultLst=jdbcTemplate.query(newLeiDetailsQuery, new RowMapper() {			
			public Object mapRow(ResultSet rs, int arg1) throws SQLException {
				MappingTradeLei  dto=new MappingTradeLei();
				dto.setSendId(rs.getBigDecimal(1));
				dto.setTradeId(rs.getString(2));
				dto.setCurrentLei(rs.getString(3));
				dto.setNewLei(rs.getString(4));
				return dto;
			}
		});
		logger.debug("findNewLeiDetails: result set size->"+resultLst.size());
		return resultLst;
	}
}
