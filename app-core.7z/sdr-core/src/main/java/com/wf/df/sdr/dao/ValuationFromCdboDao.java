package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.ValuationFromCdbo;
import com.wf.df.sdr.exception.dao.ValuationFromCdboDaoException;

public interface ValuationFromCdboDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(ValuationFromCdbo dto);

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria ''.
	 */
	public List<ValuationFromCdbo> findAll() throws ValuationFromCdboDaoException;

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'fo_trade_id = :foTradeId'.
	 */
	public List<ValuationFromCdbo> findWhereFoTradeIdEquals(String foTradeId) throws ValuationFromCdboDaoException;

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'source_system = :sourceSystem'.
	 */
	public List<ValuationFromCdbo> findWhereSourceSystemEquals(String sourceSystem) throws ValuationFromCdboDaoException;

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'status = :status'.
	 */
	public List<ValuationFromCdbo> findWhereStatusEquals(String status) throws ValuationFromCdboDaoException;

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'npv_value = :npvValue'.
	 */
	public List<ValuationFromCdbo> findWhereNpvValueEquals(BigDecimal npvValue) throws ValuationFromCdboDaoException;

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'npv_date = :npvDate'.
	 */
	public List<ValuationFromCdbo> findWhereNpvDateEquals(Date npvDate) throws ValuationFromCdboDaoException;

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'npv_currrency = :npvCurrrency'.
	 */
	public List<ValuationFromCdbo> findWhereNpvCurrrencyEquals(String npvCurrrency) throws ValuationFromCdboDaoException;
	
	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'notional_current = :notionalCurrent'.
	 */
	public List<ValuationFromCdbo> findWhereNotionalCurrentEquals(String notionalCurrent) throws ValuationFromCdboDaoException;
	
	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'pay_notional = :payNotional'.
	 */
	public List<ValuationFromCdbo> findWherePayNotionalEquals(String payNotional) throws ValuationFromCdboDaoException;
	
	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'recv_notional = :recvNotional'.
	 */
	public List<ValuationFromCdbo> findWhereRecvNotionalEquals(String recvNotional) throws ValuationFromCdboDaoException;
	
	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'pay_Currency = :payCurrency'.
	 */
	public List<ValuationFromCdbo> findWherePayCurrencyEquals(String payCurrency) throws ValuationFromCdboDaoException;
	
	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'recv_Currency = :recvCurrency'.
	 */
	public List<ValuationFromCdbo> findWhereRecvCurrencyEquals(String recvCurrency) throws ValuationFromCdboDaoException;

}
