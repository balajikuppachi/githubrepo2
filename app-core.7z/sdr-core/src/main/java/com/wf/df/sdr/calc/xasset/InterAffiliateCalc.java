package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class InterAffiliateCalc {

	@Value("${wf.affiliate.leis}")  String wfAffiliates;
	
	@Calculation(value = Calc.interAffiliateCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean party1,
			@DerivedFrom(value = Stv.LEI_CP, isInternal = true) String party2,
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String leiUS){
		String returnValue = "false";			
		
		party2=Utils.getElementAtIndex(party2, 1, Constants.COLON);
		leiUS=Utils.getElementAtIndex(leiUS, 1, Constants.COLON);

		/**REVERTED :STR-394 and STR-396 */
		/** if(StringUtils.contains(wfAffiliates, party2) || party1.booleanValue() || StringUtils.contains(wfAffiliates, leiUS))*/
		
		 if(StringUtils.contains(wfAffiliates, party2) && party1.booleanValue())
			returnValue = "true";
		
		return returnValue;
	}
	
}
