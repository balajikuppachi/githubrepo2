package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EventIDCalc {
	
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eventIDCalc, isPrototype = false)
	public String applyRule(
			MethodCalculationDefinition def,
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String tradeId,
			@DerivedFrom(value = Stv.TradeVersion, isInternal = true) String tradeVersion,
			@DerivedFrom(value = Calc.calypsoTransactionTypeCalc, isInternal = true) String txnType,
			@DerivedFrom(value = Stv.KW_TransferDate, isInternal = true) String transferDate,
			@DerivedFrom(value = Stv.Parent_KW_TerminationTradeDate, isInternal = true) String parentTerminationTradeDate,
			@DerivedFrom(value = Stv.KW_TerminationTradeDate, isInternal = true) String terminationTradeDate,
			@DerivedFrom(value = Stv.UnwindTradeDate, isInternal = true) String unwindTradeDate,
			@DerivedFrom(value = Stv.TerminationTradeDate, isInternal = true) String terminationDate,
			@DerivedFrom(value = Stv.KW_AmendmentDate, isInternal = true) String  amendmentDate,
	 		@DerivedFrom(value = Stv.NovationDate, isInternal = true) String  novationDate){
		
		String date = null;
		
		if (!Utils.IsNullOrBlank(parentTerminationTradeDate))
			date = parentTerminationTradeDate;	
		else if(!Utils.IsNullOrBlank(terminationTradeDate))
			date = terminationTradeDate;
		else if (!Utils.IsNullOrBlank(amendmentDate))
			date = amendmentDate;
		else if (!Utils.IsNullOrBlank(novationDate))
			date = novationDate;
		else if(!Utils.IsNullOrBlank(transferDate))
			date = transferDate;
		
		if(!Utils.IsNullOrBlank(txnType) && 
				(StringUtils.containsIgnoreCase(txnType,Constants.Termination) || 
						StringUtils.containsIgnoreCase(txnType,Constants.Amendment) || 
							StringUtils.containsIgnoreCase(txnType,Constants.Novation))){
			if(!Utils.IsNullOrBlank(date)){
							
					return txnType+"-"+date;					 				 
				
			}
			throw new CalculationException("EventIdCalc", "EventId calculation: Lifecycle Date needed but came in as [" + date + "]");
		}
		return Constants.EMPTY_STRING;
		
	}
}
