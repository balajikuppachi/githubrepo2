package com.wf.df.sdr.calc.equity;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.TradeAttributesDao;
import com.wf.df.sdr.dto.TradeAttributes;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqVegaNotionalTotalAmountCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	ParserService parser;	
	@Autowired
	FormatterService formatter;
	@Autowired
	TradeAttributesDao dao;
	
	@Calculation(value = Calc.eqVegaNotionalTotalAmountCalc, isPrototype = false)
	public String notional(
			@DerivedFrom(value = Stv.VegaNotionalAmount, isInternal = true) String vegaNotional,			
			@DerivedFrom(value =  Calc.eqTransactionTypeCalc, isInternal = true) String transactionType,
			@DerivedFrom(value = Calc.eqComputedUSICalc, isInternal = true) String usi){	
			
		if(Utils.IsNullOrBlank(vegaNotional))
			return Constants.EMPTY_STRING;
		
		String notional = null;
				
		
		if(Constants.Increase.equals(transactionType)){
			//Assuming we are getting increase (+ve change) in notional for Increase i.e AddOn
			notional = getTotalNotional(vegaNotional, usi);
		}else if(Constants.Termination.equals(transactionType)){
			//Assuming we are getting decrease (-ve change) in notional for Termination i.e  Full Unwind or Partial Unwind
			notional = getRemainingNotional(vegaNotional, usi);
		} else {
			//Assuming for all other types we are getting total notional
			
			notional = formatter.parseAndFormatNumber(vegaNotional);
		}
				
		return notional;
				
	}
	
	private String getTotalNotional(String current, String usi) {
		String ret = current;
		List<TradeAttributes> trade = dao.findPreviousRecordsForUSI(usi, Constants.ASSET_CLASS_EQUITY);
		if (trade.size() > 0) {
			String original = trade.get(0).getNotionalAmount();
			try {
				BigDecimal total = Utils.addNumberString(original,current);
				
				return formatter.formatDecimalDEC(total);
			} catch (Exception ee) {
				logger.info("Total Notional Failed, Returning the value as is.", ee);
			}
		}
		try {
			BigDecimal bd;
			bd = parser.parseBigDecimal(ret);
			bd = bd.abs();
			return formatter.formatDecimalDEC(bd);
		} catch (ParseException e) {
			throw new CalculationException("AmountNotParsed", "Amount string " + ret	+ " could not be parsed. " + Constants.ERROR_MSG_SEPARATOR+e.getMessage());				
		}
	}
	
	private String getRemainingNotional(String current, String usi) {
		String ret = current;
		List<TradeAttributes> trade = dao.findPreviousRecordsForUSI(usi, Constants.ASSET_CLASS_EQUITY);
		if (trade.size() > 0) {
			String original = trade.get(0).getNotionalAmount();
			try {
				BigDecimal remaining = Utils.subtractNumberString(original,current);
				
				return formatter.formatDecimalDEC(remaining);
			} catch (Exception ee) {
				logger.info("Remaining Notional Failed, Returning the value as is.", ee);
			}
		}
		try {
			BigDecimal bd;
			bd = parser.parseBigDecimal(ret);
			bd = bd.abs();
			return formatter.formatDecimalDEC(bd);
		} catch (ParseException e) {
			throw new CalculationException("AmountNotParsed", "Amount string " + ret	+ " could not be parsed. " + Constants.ERROR_MSG_SEPARATOR+e.getMessage());				
		}
	}
	
}
