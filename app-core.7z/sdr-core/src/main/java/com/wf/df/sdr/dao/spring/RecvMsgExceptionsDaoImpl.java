package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.RecvMsgExceptionsDao;
import com.wf.df.sdr.dto.RecvMsgExceptions;
import com.wf.df.sdr.exception.dao.RecvMsgExceptionsDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class RecvMsgExceptionsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<RecvMsgExceptions>, RecvMsgExceptionsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(RecvMsgExceptions dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( recv_id, msg_type, error_code, error_desc, create_datetime, usi ) VALUES ( ?, ?, ?, ?, ?, ? )",dto.getRecvId(),dto.getMsgType(),dto.getErrorCode(),dto.getErrorDesc(),dto.getCreateDatetime(),dto.getUsi());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return RecvMsgExceptions
	 */
	public RecvMsgExceptions mapRow(ResultSet rs, int row) throws SQLException
	{
		RecvMsgExceptions dto = new RecvMsgExceptions();
		dto.setRecvId( rs.getBigDecimal(1));
		dto.setMsgType( rs.getString( 2 ) );
		dto.setErrorCode( rs.getString( 3 ) );
		dto.setErrorDesc( rs.getString( 4 ) );
		dto.setCreateDatetime( rs.getTimestamp(5 ) );
		dto.setUsi( rs.getString( 6 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recv_msg_exceptions";
	}

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria ''.
	 */
	@Transactional
	public List<RecvMsgExceptions> findAll() throws RecvMsgExceptionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, error_code, error_desc, create_datetime, usi FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new RecvMsgExceptionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'recv_id = :recvId'.
	 */
	@Transactional
	public List<RecvMsgExceptions> findWhereRecvIdEquals(BigDecimal recvId) throws RecvMsgExceptionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, error_code, error_desc, create_datetime, usi FROM " + getTableName() + " WHERE recv_id = ? ORDER BY recv_id", this,recvId);
		}
		catch (Exception e) {
			throw new RecvMsgExceptionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<RecvMsgExceptions> findWhereMsgTypeEquals(String msgType) throws RecvMsgExceptionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, error_code, error_desc, create_datetime, usi FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msgType);
		}
		catch (Exception e) {
			throw new RecvMsgExceptionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'error_code = :errorCode'.
	 */
	@Transactional
	public List<RecvMsgExceptions> findWhereErrorCodeEquals(String errorCode) throws RecvMsgExceptionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, error_code, error_desc, create_datetime, usi FROM " + getTableName() + " WHERE error_code = ? ORDER BY error_code", this,errorCode);
		}
		catch (Exception e) {
			throw new RecvMsgExceptionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'error_desc = :errorDesc'.
	 */
	@Transactional
	public List<RecvMsgExceptions> findWhereErrorDescEquals(String errorDesc) throws RecvMsgExceptionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, error_code, error_desc, create_datetime, usi FROM " + getTableName() + " WHERE error_desc = ? ORDER BY error_desc", this,errorDesc);
		}
		catch (Exception e) {
			throw new RecvMsgExceptionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<RecvMsgExceptions> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvMsgExceptionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, error_code, error_desc, create_datetime, usi FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new RecvMsgExceptionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<RecvMsgExceptions> findWhereUsiEquals(String usi) throws RecvMsgExceptionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, error_code, error_desc, create_datetime, usi FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new RecvMsgExceptionsDaoException("Query failed", e);
		}
		
	}

}
