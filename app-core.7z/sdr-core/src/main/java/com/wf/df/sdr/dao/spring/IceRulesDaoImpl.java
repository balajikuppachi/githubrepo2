package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.IceRulesDao;
import com.wf.df.sdr.dto.IceRule;
import com.wf.df.sdr.exception.dao.DaoException;

public class IceRulesDaoImpl extends AbstractDAO implements ParameterizedRowMapper<IceRule>, IceRulesDao {

	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	@Override
	public IceRule mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		IceRule dto = new IceRule();
		dto.setMessageType(rs.getString(1));
		dto.setPrevStatus(rs.getString(2));
		dto.setCurrentStatus(rs.getString(3));
		dto.setPrevEconfirm(rs.getString(4));
		dto.setCurrentEconfirm(rs.getString(5));
		dto.setPrevRequestType(rs.getString(6));
		dto.setPrevRequestAction(rs.getString(7));
		dto.setNewRequestType(rs.getString(8));
		dto.setNewRequestAction(rs.getString(9));
		dto.setUpdate_datetime(rs.getDate(10));
		
		return dto;
	}

	@Transactional
	public List<IceRule> findAll() throws DaoException {
		
		try {
			return jdbcTemplate.query("SELECT msg_type, prev_status, current_status, prev_econfirm, curr_econfirm, prev_request_type, prev_request_action, new_request_type, new_request_action, update_datetime  FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new DaoException("Query failed", e);
		}
	}
	
	
	@Transactional
	public List<IceRule> executeRule(String msgType,String prvsStatus,String currentStatus,String prevEconfirm,String currEconfirm,String prevRequestType,String prevRequestAction,String error) throws DaoException
	{
		try {
			return jdbcTemplate.query("SELECT msg_type, prev_status, current_status, prev_econfirm, curr_econfirm, prev_request_type, prev_request_action, new_request_type, new_request_action, update_datetime  FROM " + getTableName() + " WHERE msg_type = ? and "
					+ "  prev_status=? and  current_status = ? and prev_econfirm=? and curr_econfirm=? and prev_request_type=? and prev_request_action=? and error_desc=? ",
			this,msgType,prvsStatus,currentStatus,prevEconfirm,currEconfirm, prevRequestType, prevRequestAction,error);
		}
		catch (Exception e) {
			throw new DaoException("Query failed", e);
		}
		
	}
	
	public String getTableName()
	{
		return "ice_rules";
	}



}
