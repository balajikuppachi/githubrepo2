package com.wf.df.sdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.PagingQueryProvider;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.wf.df.sdr.dto.RecvBufferStore;

@Repository
public class RecvBufferStoreExtnDao {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Value("${recv.buffer.store.archive.query}")
	String bufferRetrievalQuery;
	
	@Value("${min.max.bufferId.retrival.query}")
	String minMaxBufferIdRetrivalQuery;
	
	@Value("${recv.buffer.store.archive.selectclause.query}")
	String bufferRetrievalSelectClauseQuery;
	
	@Value("${recv.buffer.store.archive.fromclause.query}")
	String bufferRetrievalFromClauseQuery;
	
	@Value("${recv.buffer.store.archive.whereclause.query}")
	String bufferRetrievalWhereClauseQuery;
	
	@Value("${recv.buffer.store.archive.sortkey.query}")
	String bufferRetrievalSortKey;
	
	@Value("${batch_size}") Integer noOfRecords;

	public Long findMaxBufferIdInRange(Long from, Long to) {
		
		List<Long> maxIdList = jdbcTemplate
				.queryForList("SELECT MAX(buffer_id) FROM recv_buffer_store WHERE buffer_id >= ? AND buffer_id <= ?",Long.class, from, to);
		if (maxIdList == null || maxIdList.isEmpty()
				|| maxIdList.get(0) == null) {
			return null;
		} else {
			return maxIdList.get(0);
		}
	}

	public List<Integer> findMinMaxBufferId(int noOfDays) {
		final List<Integer> bufferIds =new ArrayList<Integer>();
		jdbcTemplate.query(minMaxBufferIdRetrivalQuery,new Object[] { noOfDays },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {				
				bufferIds.add(rs.getInt(1));
				bufferIds.add(rs.getInt(2));
				return null;
			}			
		});		
		return bufferIds;
	}
	
	public List<RecvBufferStore> getRecievedBufferStoreRecords(	Integer minBufferID, Integer maxBufferID) {
		logger.info("Start getRecievedBufferStoreRecords : minBufferID ="+ minBufferID + ", maxBufferID =" + maxBufferID);
		
		List<RecvBufferStore> recvBufferStores = new ArrayList<RecvBufferStore>();
		
		SqlPagingQueryProviderFactoryBean queryProvider = new SqlPagingQueryProviderFactoryBean(); 
		queryProvider.setSelectClause(bufferRetrievalSelectClauseQuery);
		queryProvider.setFromClause(bufferRetrievalFromClauseQuery);
		queryProvider.setWhereClause(bufferRetrievalWhereClauseQuery);
		queryProvider.setDataSource(jdbcTemplate.getDataSource());
		queryProvider.setSortKey(bufferRetrievalSortKey);
		
		JdbcPagingItemReader itemReader = new JdbcPagingItemReader(); 
		
		try {
			Map<String, Integer> paramMap = new  HashMap<String, Integer>();
			paramMap.put("1", minBufferID);
			paramMap.put("2", maxBufferID);
			
			itemReader.setParameterValues(paramMap);
			itemReader.setDataSource(jdbcTemplate.getDataSource());
			itemReader.setQueryProvider((PagingQueryProvider) queryProvider.getObject());
			itemReader.setPageSize(noOfRecords);
			itemReader.setRowMapper(new DataRowMapper());
			itemReader.afterPropertiesSet();

			ExecutionContext executionContext = new ExecutionContext();
			itemReader.open(executionContext);
			int counter = 0;
			Object recvObj = new Object();			
			while (null != recvObj) {
				logger.info("Calling Read :");
				recvObj = itemReader.read();				
				if(null != recvObj){
					logger.info("Buffer ID :" + ((RecvBufferStore)recvObj).getBufferId());
					recvBufferStores.add((RecvBufferStore)recvObj);
				}	
				if(counter != noOfRecords && null != recvObj)
				{
					counter++;
				}
				if(counter == noOfRecords || null == recvObj){
					counter = 0;
					break;
				}
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return recvBufferStores;
	}
}
class DataRowMapper implements RowMapper {
	

	public RecvBufferStore mapRow(ResultSet rs, int rowNum) throws SQLException {
		//logger.info("===============Row num ================"+ rowNum);
		RecvBufferStore recvBufferStore = new RecvBufferStore();
		recvBufferStore.setBufferId(rs.getBigDecimal(1));
		recvBufferStore.setBufferData(rs.getString(2));
		recvBufferStore.setBufferSrc(rs.getString(3));
		recvBufferStore.setCreateDatetime(rs.getDate(4));
		return recvBufferStore;
	}
}