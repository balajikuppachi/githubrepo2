package com.wf.df.sdr.util;

public class ConstantsNR {

	public final static String CFTC = "CFTC";
	

}
