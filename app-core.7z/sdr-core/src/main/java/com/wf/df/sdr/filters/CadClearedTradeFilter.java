package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;

@Component
public class CadClearedTradeFilter {
	
	@Autowired
	NotEligblePersister nep;
	Logger logger = Logger.getLogger(getClass());
	
	public boolean checkEligibility(UnitOfWork uow)
	{
		logger.debug("CAD ClearedTradeFilter Called");
		CalculationContext cc = uow.getCalculationContext();
		
		boolean isClearedTrade = cc.getBoolean(Calc.clearedTradeCalc);
		String tradeId = cc.getValue(Stv.TradeId, String.class);
		
		if(isClearedTrade){
			/*Delete Snapshot*/
			logger.warn("Updating EOD buffers for the Trade Id : "+ tradeId);
			//nep.save(uow, NotEligblePersister.Cleared);
			nep.updateCadEODBufferForTradeId(tradeId);
		}
		return true;
	}
}
