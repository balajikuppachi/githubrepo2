package com.wf.df.sdr.calc.xasset;

import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class IsTradeExecutedTodayCalc {

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.isTradeExecutedTodayCalc, isPrototype = false)
	public Boolean execTime(
			@DerivedFrom(value = Stv.EXECUTION_DATETIME, isInternal = true) String executionDate,
			@DerivedFrom(value=Calc.currentDateCalc, isInternal=true) Date curDate){
		
		if (!Utils.IsNullOrBlank(executionDate)) {
			Date dt;
			try {
				dt = parser.parseDate(executionDate);
				
				return Utils.isSameDay(curDate, dt);
				
			} catch (ParseException e) {
				throw new CalculationException("DateParse", "Date 'EXECUTION_DATETIME' "+executionDate+" can not be parsed");
			}
		}
		return false;
	}
	
}
