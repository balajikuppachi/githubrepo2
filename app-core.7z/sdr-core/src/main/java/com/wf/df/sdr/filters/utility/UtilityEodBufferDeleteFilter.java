package com.wf.df.sdr.filters.utility;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.utility.UtilityNotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class UtilityEodBufferDeleteFilter {

	@Autowired
	UtilityNotEligblePersister nep;
	
	Logger logger = Logger.getLogger(getClass());
	
	public boolean deleteEODBuffer(UnitOfWork uow) {
		logger.debug("EodBufferDeleteFilter Called");
		
		CalculationContext cc = uow.getCalculationContext();
		String marketType = cc.getValue(Calc.srcTLCEventCalc, String.class);
		String tradeId = cc.getValue(Stv.TradeId, String.class);
					
		if(StringUtils.equalsIgnoreCase(Constants.Exercise_Physical, marketType)) {
			if(!Utils.IsNullOrBlank(tradeId)){
				nep.save(uow, UtilityNotEligblePersister.ExercisePhysical);
				nep.deleteEODBufferForOldSendId(tradeId);
				nep.deleteEODNotReportingBufferForOldSendId(tradeId);
			}
		} else if (StringUtils.equalsIgnoreCase(Constants.Bilateral_Cleared, marketType)){
			//Removing any instance saved in EOD store for this bilatereal trade
			logger.info("Ineligible Market Type: " + marketType);
			nep.save(uow, UtilityNotEligblePersister.BilateralCleared);
			nep.deleteEODBufferForAllSendId(tradeId);
			return false;
		}
		
		return true;
	}
	
}
