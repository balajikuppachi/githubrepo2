package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.CollateralFieldsMessageMappingsDao;
import com.wf.df.sdr.dto.DtccFieldsMessageMappings;
import com.wf.df.sdr.exception.dao.CollFieldsMessageMappingsDaoException;

public class CollateralFieldsMessageMappingsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<DtccFieldsMessageMappings>, CollateralFieldsMessageMappingsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return DtccFieldsMessageMappings
	 */
	public DtccFieldsMessageMappings mapRow(ResultSet rs, int row) throws SQLException
	{
		DtccFieldsMessageMappings dto = new DtccFieldsMessageMappings();
		dto.setId( new Integer( rs.getInt(1) ) );
		dto.setFieldCsvSeq( new Integer( rs.getInt(2) ) );
		if (rs.wasNull()) {
			dto.setFieldCsvSeq( null );
		}
		
		dto.setFieldOptionality( rs.getString( 3 ) );
		dto.setDtccAssetClass( rs.getString( 4 ) );
		dto.setDtccProdType( rs.getString( 5 ) );
		dto.setDtccSubProdType( rs.getString( 6 ) );
		dto.setMsgType( rs.getString( 7 ) );
		dto.setTransactionType( rs.getString( 8 ) );
		dto.setFieldName( rs.getString( 9 ) );
		dto.setFieldId( new Integer( rs.getInt(10) ) );
		dto.setFieldRule( rs.getString( 11 ) );
		dto.setSrcField( rs.getString( 12 ) );
		dto.setDefaultValue( rs.getString( 13 ) );
		dto.setFieldXpath( rs.getString( 14 ) );
		dto.setCreateDatetime( rs.getTimestamp(15 ) );
		dto.setSdrRepository(rs.getString(16));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "coll_fields_message_mappings";
	}

	/** 
	 * Returns all rows from the coll_fields_message_mappings table that match the criteria ''.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findAll() throws CollFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, coll_asset_class, coll_prod_type, coll_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new CollFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/**
	 * Additional Implementation added to support the CSV in seq fetch Query
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findFieldsInCSVSeq() throws CollFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT DISTINCT msg_type, coll_asset_class, field_id, field_name, field_csv_seq, sdr_repository FROM " + getTableName() + " ORDER BY field_csv_seq ASC", new CollCustomRowMapper());
		}
		catch (Exception e) {
			throw new CollFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}
	
	
	private class CollCustomRowMapper implements ParameterizedRowMapper<DtccFieldsMessageMappings> {

		@Override
		public DtccFieldsMessageMappings mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			
			DtccFieldsMessageMappings dto = new DtccFieldsMessageMappings();
			
			dto.setMsgType( rs.getString( 1 ) );			
			dto.setDtccAssetClass( rs.getString( 2 ) );	
			dto.setFieldId( rs.getInt( 3 ) );
			dto.setFieldName( rs.getString( 4 ) );
			dto.setFieldCsvSeq( rs.getInt( 5 ) );
			dto.setSdrRepository(rs.getString(6));
			return dto;
			
		}
		
	}


}
