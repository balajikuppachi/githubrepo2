package com.wf.df.sdr.message;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class ResponseMessage {

	private String msgType;
	private String usiPrefix;
	private String creationTimestamp;
	private String usiValue;
	private String msgStatus;
	private String recvXml;
	private Map<String,String> errors = new HashMap<String, String>();
	private String reportingParty;
	private String sendMsgBuffer;
	private String sendId;
	private String tradeId;
	private String tradeVersion;
	private String assetClass;
	private BigDecimal bufferId;
	private String upi;
	private String action;
	private String sdrRepository;
	private String sdrTransmitId;
	
	
	public void addErrors(String key, String value){
		errors.put(key, value);
	}
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getMsgType() {
		return msgType;
	}
	public String getUsiPrefix() {
		return usiPrefix;
	}
	public String getCreationTimestamp() {
		return creationTimestamp;
	}
	public String getUsiValue() {
		return usiValue;
	}
	public String getMsgStatus() {
		return msgStatus;
	}
	public String getRecvXml() {
		return recvXml;
	}
	
	public String getReportingParty() {
		return reportingParty;
	}
	public String getSendMsgBuffer() {
		return sendMsgBuffer;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public void setUsiPrefix(String usiPrefix) {
		this.usiPrefix = usiPrefix;
	}
	public void setCreationTimestamp(String creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}
	public void setUsiValue(String usiValue) {
		this.usiValue = usiValue;
	}
	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}
	public void setRecvXml(String recvXml) {
		this.recvXml = recvXml;
	}
	
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}
	public void setSendMsgBuffer(String sendMsgBuffer) {
		this.sendMsgBuffer = sendMsgBuffer;
	}
	public String getSendId() {
		return sendId;
	}
	public String getTradeId() {
		return tradeId;
	}
	public String getTradeVersion() {
		return tradeVersion;
	}
	public void setSendId(String sendId) {
		this.sendId = sendId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public void setTradeVersion(String tradeVersion) {
		this.tradeVersion = tradeVersion;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public Map<String, String> getErrors() {
		return errors;
	}

	public BigDecimal getBufferId() {
		return bufferId;
	}

	public void setBufferId(BigDecimal bufferId) {
		this.bufferId = bufferId;
	}

	public String getUpi() {
		return upi;
	}

	public void setUpi(String upi) {
		this.upi = upi;
	}

	/**
	 * @return the sdrRepository
	 */
	public String getSdrRepository() {
		return sdrRepository;
	}

	/**
	 * @param sdrRepository the sdrRepository to set
	 */
	public void setSdrRepository(String sdrRepository) {
		this.sdrRepository = sdrRepository;
	}

	public String getSdrTransmitId() {
		return sdrTransmitId;
	}

	public void setSdrTransmitId(String sdrTransmitId) {
		this.sdrTransmitId = sdrTransmitId;
	}
	
}
