package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class uSIPrefixForNRCalc {

	@Calculation(value=Calc.uSIPrefixForNRCalc)
	public String usi (
			@DerivedFrom(value = Calc.computedUSICalc) String calypsoUsi,
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliateTrade,
			@DerivedFrom(value = Calc.affiliateUsiCalc, isInternal = true) String affiliateUsi) {
			
		if(!Utils.IsNullOrNone(calypsoUsi)){
			if (calypsoUsi.startsWith(Constants.DTCC))
				return Constants.DTCC;;
			//for all USI not starting with DTCC prefix is 10
			return calypsoUsi.substring(0,10);
		}	
		return Constants.EMPTY_STRING;
				
	}
	
}
