package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.BatchDetailsDao;
import com.wf.df.sdr.dto.BatchDetails;
import com.wf.df.sdr.exception.dao.BatchDetailsDaoException;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;

public interface BatchDetailsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(BatchDetails dto);

	/** 
	 * Returns all rows from the batch_details table that match the criteria ''.
	 */
	public List<BatchDetails> findAll() throws BatchDetailsDaoException;

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<BatchDetails> findWhereCreateDatetimeEquals(Date createDatetime) throws BatchDetailsDaoException;

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'fq_filename = :fqFilename'.
	 */
	public List<BatchDetails> findWhereFqFilenameEquals(String fqFilename) throws BatchDetailsDaoException;

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'send_id = :sendId'.
	 */
	public List<BatchDetails> findWhereSendIdEquals(BigDecimal sendId) throws BatchDetailsDaoException;

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'msg_type = :msgType'.
	 */
	public List<BatchDetails> findWhereMsgTypeEquals(String msgType) throws BatchDetailsDaoException;

}
