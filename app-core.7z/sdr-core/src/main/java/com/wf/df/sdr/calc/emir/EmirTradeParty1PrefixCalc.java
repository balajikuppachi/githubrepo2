package com.wf.df.sdr.calc.emir;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EmirTradeParty1PrefixCalc {


	@Calculation(value = Calc.emirTradeParty1PrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.tradeParty1PrefixCalc, isInternal = true) String wellsPrefix,
			@DerivedFrom(value = Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegated,
			@DerivedFrom(value = Calc.cptyParticipantIdPrefixCalc, isInternal = true) String cptyPrefix) 
	{
			
		if(isEmirDelegated)
		{
			return cptyPrefix;
		}else
		{
			return wellsPrefix;	
		}

	}
	
}
