package com.wf.df.sdr.util;


public enum PeriodEnum 
{
	D(1),W(2),M(3),Y(4),T(5);
	
	private final Integer value;

	PeriodEnum(int num)
	{
		value=num;
	}
	
	public int getValue() {
		return value;
	}
	
	 public static Integer enumValue(String v) {
		 
		 if(!Utils.IsNullOrBlank(v))
		 {
	        for (PeriodEnum c: PeriodEnum.values()) {
	            if (v.equals(c.toString())) {
	                return c.value;
	            }
	        }
	        
		 } 
	        throw new IllegalArgumentException(v);
	    }
}
