package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.RecvMsgMatchedDao;
import com.wf.df.sdr.dto.RecvMsgMatched;
import com.wf.df.sdr.exception.dao.RecvMsgMatchedDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class RecvMsgMatchedDaoImpl extends AbstractDAO implements ParameterizedRowMapper<RecvMsgMatched>, RecvMsgMatchedDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(RecvMsgMatched dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( recv_id, msg_type, usi, send_id, match_status, create_datetime ) VALUES ( ?, ?, ?, ?, ?, ? )",dto.getRecvId(),dto.getMsgType(),dto.getUsi(),dto.getSendId(),dto.getMatchStatus(),dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return RecvMsgMatched
	 */
	public RecvMsgMatched mapRow(ResultSet rs, int row) throws SQLException
	{
		RecvMsgMatched dto = new RecvMsgMatched();
		dto.setRecvId( rs.getBigDecimal(1));
		dto.setMsgType( rs.getString( 2 ) );
		dto.setUsi( rs.getString( 3 ) );
		dto.setSendId( rs.getBigDecimal(4));
		dto.setMatchStatus( rs.getString( 5 ) );
		dto.setCreateDatetime( rs.getTimestamp(6 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recv_msg_matched";
	}

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria ''.
	 */
	@Transactional
	public List<RecvMsgMatched> findAll() throws RecvMsgMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, usi, send_id, match_status, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new RecvMsgMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'recv_id = :recvId'.
	 */
	@Transactional
	public List<RecvMsgMatched> findWhereRecvIdEquals(BigDecimal recvId) throws RecvMsgMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, usi, send_id, match_status, create_datetime FROM " + getTableName() + " WHERE recv_id = ? ORDER BY recv_id", this,recvId);
		}
		catch (Exception e) {
			throw new RecvMsgMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<RecvMsgMatched> findWhereMsgTypeEquals(String msgType) throws RecvMsgMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, usi, send_id, match_status, create_datetime FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msgType);
		}
		catch (Exception e) {
			throw new RecvMsgMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<RecvMsgMatched> findWhereUsiEquals(String usi) throws RecvMsgMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, usi, send_id, match_status, create_datetime FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new RecvMsgMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<RecvMsgMatched> findWhereSendIdEquals(BigDecimal sendId) throws RecvMsgMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, usi, send_id, match_status, create_datetime FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new RecvMsgMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'match_status = :matchStatus'.
	 */
	@Transactional
	public List<RecvMsgMatched> findWhereMatchStatusEquals(String matchStatus) throws RecvMsgMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, usi, send_id, match_status, create_datetime FROM " + getTableName() + " WHERE match_status = ? ORDER BY match_status", this,matchStatus);
		}
		catch (Exception e) {
			throw new RecvMsgMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<RecvMsgMatched> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvMsgMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, usi, send_id, match_status, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new RecvMsgMatchedDaoException("Query failed", e);
		}
		
	}

}
