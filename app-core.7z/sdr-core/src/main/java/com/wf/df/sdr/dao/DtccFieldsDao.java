package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.DtccFieldsDao;
import com.wf.df.sdr.dto.DtccFields;
import com.wf.df.sdr.exception.dao.DtccFieldsDaoException;

import java.util.Date;
import java.util.List;

public interface DtccFieldsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(DtccFields dto);

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria ''.
	 */
	public List<DtccFields> findAll() throws DtccFieldsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_id = :fieldId'.
	 */
	public List<DtccFields> findWhereFieldIdEquals(Integer fieldId) throws DtccFieldsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_name = :fieldName'.
	 */
	public List<DtccFields> findWhereFieldNameEquals(String fieldName) throws DtccFieldsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_comments = :fieldComments'.
	 */
	public List<DtccFields> findWhereFieldCommentsEquals(String fieldComments) throws DtccFieldsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'field_type = :fieldType'.
	 */
	public List<DtccFields> findWhereFieldTypeEquals(String fieldType) throws DtccFieldsDaoException;

	/** 
	 * Returns all rows from the dtcc_fields table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<DtccFields> findWhereCreateDatetimeEquals(Date createDatetime) throws DtccFieldsDaoException;

}
