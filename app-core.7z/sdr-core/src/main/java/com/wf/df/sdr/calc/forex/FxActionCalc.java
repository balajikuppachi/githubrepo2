package com.wf.df.sdr.calc.forex;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.MsgToReportDao;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class FxActionCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	MsgToReportDao msgToReportDao;

	@Calculation(value = Calc.fxActionCalc, isPrototype=false)
	public String calcAction(
			@DerivedFrom(value = Calc.calypsoTransactionTypeCalc, isInternal = true) String transactionType,
			@DerivedFrom(value = Stv.CalypsoDocStatus, isInternal = true) String calypsoDocStatus,
			@DerivedFrom(value = Calc.isActionNewOrModifyCalc, isInternal=true)String computedAction,
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String marketType,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType) {
		
		if(Constants.TRADE_STATUS_CANCELED.equals(calypsoDocStatus))
			return Constants.Cancel;
		
		if(Constants.Cancellation.equalsIgnoreCase(marketType) && !Constants.MESSAGE_TYPE_SNAPSHOT.equals(msgType))
			return Constants.Cancel;
		
		if(StringUtils.containsIgnoreCase(transactionType, Constants.Trade))
			return computedAction;
		
		return Constants.New;

	}
}