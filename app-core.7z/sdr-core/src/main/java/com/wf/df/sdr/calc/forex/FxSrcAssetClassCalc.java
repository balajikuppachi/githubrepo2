package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxSrcAssetClassCalc {

	@Calculation(value=Calc.fxSrcAssetClassCalc, isPrototype=false)
	public String assetClassCalc(
			@DerivedFrom(value=Calc.srcAssetClassCalc, isInternal=true) String srcAssetClassCalc)
	{
		return srcAssetClassCalc;
	}
}
