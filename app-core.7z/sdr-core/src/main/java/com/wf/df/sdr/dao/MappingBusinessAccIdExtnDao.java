package com.wf.df.sdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Repository
@Component
public class MappingBusinessAccIdExtnDao {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	
	private static String legalIdData= " select distinct legal_id,lei,bus_acc_id,legal_name from mapping_bussaccid_lei ";
	
	final Map<String, String> resultMap =new HashMap<String, String>();
	final Map<String, String> resultMapLei =new HashMap<String, String>();
	final Map<String, String> resultMapLeiBusLegalName =new HashMap<String, String>();
	final Map<String, String> resultMapLeiLegalName =new HashMap<String, String>();
	
	
	@PostConstruct
	public void initialize(){
		fetchImsDataForComm();
		}
	
	@Transactional
	public Map<String, String> fetchImsDataForComm() {
		jdbcTemplate.query(legalIdData,new Object[] { },new RowMapper()
		{
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {	
				
				resultMap.put(rs.getString(2)+Constants.HYPHEN+rs.getString(3), rs.getString(1));
				resultMapLei.put(rs.getString(2), rs.getString(1));
				resultMapLeiBusLegalName.put(rs.getString(2)+Constants.HYPHEN+rs.getString(3), rs.getString(4));
				resultMapLeiLegalName.put(rs.getString(2), rs.getString(4));
				return null;
			}			
		});		
		return resultMap;
	}
	
	public String getLegalId(String LEI,String busAccId)
	{
		logger.info("Lookup for LegalId, Lei:"+LEI+", BusAccID:"+busAccId);
		String returnValue=null;
	
		if (!Utils.IsNullOrBlank(LEI) && LEI.contains(Constants.COLON))
		{
			String leiValueArr[]=Utils.IsNullOrBlank(LEI)?null:LEI.split(Constants.COLON);
			if(!Utils.IsNullOrBlank(leiValueArr) && leiValueArr.length>1)
			{
				String leiValue=leiValueArr[1];
				returnValue= resultMap.get(leiValue+Constants.HYPHEN+busAccId);
				
				if(Utils.IsNullOrBlank(returnValue))
					returnValue=resultMapLei.get(leiValue);
			}
		} 
		else {
		if(!Utils.IsNullOrBlank(LEI) && LEI.length()>1)
		{
			returnValue= resultMap.get(LEI+Constants.HYPHEN+busAccId);
		if(Utils.IsNullOrBlank(returnValue))
			returnValue=resultMapLei.get(LEI);
		}
	}
		return returnValue;
	}
	
	public String getLegalName(String LEI,String busAccId,String legalName)
	{
		
		logger.debug("Lookup for LegalId, Lei:"+LEI+", BusAccID:"+busAccId+", old legalName:"+legalName);
		String returnValue=null;
		
		if (!Utils.IsNullOrBlank(LEI) &&  LEI.contains(Constants.COLON))
		{
			String leiValueArr[]=Utils.IsNullOrBlank(LEI)?null:LEI.split(Constants.COLON);
			
			if(!Utils.IsNullOrBlank(leiValueArr) && leiValueArr.length>1)
			{
				String leiValue =leiValueArr[1];
				returnValue= resultMapLeiBusLegalName.get(leiValue+Constants.HYPHEN+busAccId);
				
				if(Utils.IsNullOrBlank(returnValue))
					returnValue=resultMapLeiLegalName.get(leiValue);
					
				if(Utils.IsNullOrBlank(returnValue))
				 	returnValue=legalName;
				
			}
		} 
		else
		{
			if(!Utils.IsNullOrBlank(LEI) && LEI.length()>1)
			{
				returnValue= resultMapLeiBusLegalName.get(LEI+Constants.HYPHEN+busAccId);

				if(Utils.IsNullOrBlank(returnValue))
					returnValue=resultMapLeiLegalName.get(LEI);

				if(Utils.IsNullOrBlank(returnValue))
					returnValue=legalName;
			}
		}
		return returnValue;
	}
}
