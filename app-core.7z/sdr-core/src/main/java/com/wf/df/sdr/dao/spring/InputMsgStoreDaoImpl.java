package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.InputMsgStoreDao;
import com.wf.df.sdr.dto.InputMsgStore;
import com.wf.df.sdr.exception.dao.InputMsgStoreDaoException;

public class InputMsgStoreDaoImpl extends AbstractDAO implements ParameterizedRowMapper<InputMsgStore>, InputMsgStoreDao
{
	
	@Autowired
	private org.springframework.jdbc.core.JdbcTemplate springJdbcTemplate;
	protected SimpleJdbcTemplate jdbcTemplate;
	protected DataSource dataSource;
	protected ActionTypeSP actionTypeSp;
	
	Logger logger = Logger.getLogger(this.getClass());

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
		actionTypeSp = new ActionTypeSP(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(InputMsgStore dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?,?,?, ?)",dto.getSendId(),dto.getSrcTradeVersion(),dto.getSrcSystemName(),dto.getSrcTradeId(),dto.getSrcAssetClass(),dto.getSrcProdType(),dto.getSrcSubProdType(),dto.getSrcTradeDate(),dto.getSrcMatDate(),dto.getSrcTlcEvent(),dto.getSrcTradeStatus(),dto.getSrcCpartyName(),dto.getSrcExecDatetime(),dto.getSrcClearingVenue(),dto.getSrcClearingDatetime(),dto.getSrcConfPlatform(),dto.getSrcConfDatetime(),dto.getSrcConfId(),dto.getUsi(),dto.getBufferId(),dto.getCreateDatetime(),dto.getPrevUsi(),dto.getRepParty(),dto.getParty1LEI(),dto.getParty2LEI(), dto.isBackload(), dto.getLegsAssociated(), dto.getSdrRepository(),dto.getUti(),dto.getUtiPrevious(),dto.getIsDelegated(),dto.getBusAccId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return InputMsgStore
	 */
	public InputMsgStore mapRow(ResultSet rs, int row) throws SQLException
	{
		InputMsgStore dto = new InputMsgStore();
		dto.setSendId( rs.getBigDecimal(1));
		dto.setSrcTradeVersion( rs.getString( 2 ) );
		dto.setSrcSystemName( rs.getString( 3 ) );
		dto.setSrcTradeId( rs.getString( 4 ) );
		dto.setSrcAssetClass( rs.getString( 5 ) );
		dto.setSrcProdType( rs.getString( 6 ) );
		dto.setSrcSubProdType( rs.getString( 7 ) );
		dto.setSrcTradeDate( rs.getDate(8 ) );
		dto.setSrcMatDate( rs.getDate(9 ) );
		dto.setSrcTlcEvent( rs.getString( 10 ) );
		dto.setSrcTradeStatus( rs.getString( 11 ) );
		dto.setSrcCpartyName( rs.getString( 12 ) );		
		dto.setSrcExecDatetime( rs.getTimestamp(13 ) );
		dto.setSrcClearingVenue( rs.getString( 14 ) );
		dto.setSrcClearingDatetime( rs.getTimestamp(15 ) );
		dto.setSrcConfPlatform( rs.getString( 16 ) );
		dto.setSrcConfDatetime( rs.getDate(17 ) );
		dto.setSrcConfId( rs.getString( 18 ) );
		dto.setUsi( rs.getString( 19 ) );
		dto.setBufferId( rs.getBigDecimal(20 ));
		dto.setCreateDatetime( rs.getTimestamp(21 ) );
		dto.setPrevUsi( rs.getString( 22 ) );
		dto.setRepParty( rs.getString( 23 ) );
		dto.setParty1LEI( rs.getString( 24 ) );
		dto.setParty2LEI( rs.getString( 25 ) );
		dto.setIsBackload( rs.getString( 26 ) );
		dto.setLegsAssociated( rs.getInt( 27 ) );
		dto.setSdrRepository(rs.getString(28));
		dto.setUti(rs.getString(29));
		dto.setUtiPrevious(rs.getString(30));
		dto.setIsDelegated(rs.getBoolean(31));
		dto.setBusAccId(rs.getString(32));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "input_msg_store";
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria ''.
	 */
	@Transactional
	public List<InputMsgStore> findAll() throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository ,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSendIdEquals(BigDecimal sendId) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_version = :srcTradeVersion'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcTradeVersionEquals(String srcTradeVersion) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_trade_version = ? ORDER BY src_trade_version", this,srcTradeVersion);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_system_name = :srcSystemName'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcSystemNameEquals(String srcSystemName) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_system_name = ? ORDER BY src_system_name", this,srcSystemName);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_id = :srcTradeId'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcTradeIdEquals(String srcTradeId) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_trade_id = ? ORDER BY src_trade_id", this,srcTradeId);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_asset_class = :srcAssetClass'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcAssetClassEquals(String srcAssetClass) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_asset_class = ? ORDER BY src_asset_class", this,srcAssetClass);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_prod_type = :srcProdType'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcProdTypeEquals(String srcProdType) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_prod_type = ? ORDER BY src_prod_type", this,srcProdType);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_sub_prod_type = :srcSubProdType'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcSubProdTypeEquals(String srcSubProdType) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_sub_prod_type = ? ORDER BY src_sub_prod_type", this,srcSubProdType);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_date = :srcTradeDate'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcTradeDateEquals(Date srcTradeDate) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_trade_date = ? ORDER BY src_trade_date", this,srcTradeDate);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_mat_date = :srcMatDate'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcMatDateEquals(Date srcMatDate) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_mat_date = ? ORDER BY src_mat_date", this,srcMatDate);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_tlc_event = :srcTlcEvent'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcTlcEventEquals(String srcTlcEvent) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_tlc_event = ? ORDER BY src_tlc_event", this,srcTlcEvent);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_trade_status = :srcTradeStatus'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcTradeStatusEquals(String srcTradeStatus) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_trade_status = ? ORDER BY src_trade_status", this,srcTradeStatus);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_cparty_name = :srcCpartyName'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcCpartyNameEquals(String srcCpartyName) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party FROM, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_cparty_name = ? ORDER BY src_cparty_name", this,srcCpartyName);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_exec_datetime = :srcExecDatetime'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcExecDatetimeEquals(Date srcExecDatetime) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_exec_datetime = ? ORDER BY src_exec_datetime", this,srcExecDatetime);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_clearing_venue = :srcClearingVenue'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcClearingVenueEquals(String srcClearingVenue) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_clearing_venue = ? ORDER BY src_clearing_venue", this,srcClearingVenue);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_clearing_datetime = :srcClearingDatetime'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcClearingDatetimeEquals(Date srcClearingDatetime) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_clearing_datetime = ? ORDER BY src_clearing_datetime", this,srcClearingDatetime);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_conf_platform = :srcConfPlatform'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcConfPlatformEquals(String srcConfPlatform) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_conf_platform = ? ORDER BY src_conf_platform", this,srcConfPlatform);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_conf_datetime = :srcConfDatetime'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcConfDatetimeEquals(Date srcConfDatetime) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_conf_datetime = ? ORDER BY src_conf_datetime", this,srcConfDatetime);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'src_conf_id = :srcConfId'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereSrcConfIdEquals(String srcConfId) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE src_conf_id = ? ORDER BY src_conf_id", this,srcConfId);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereUsiEquals(String usi) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE usi = ? ORDER BY create_datetime DESC", this,usi);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereCreateDatetimeEquals(Date createDatetime) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'prev_usi = :prevUsi'.
	 */
	@Transactional
	public List<InputMsgStore> findWherePrevUsiEquals(String prevUsi) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE prev_usi = ? ORDER BY prev_usi", this,prevUsi);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'rep_party = :repParty'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereRepPartyEquals(String repParty) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE rep_party = ? ORDER BY rep_party", this,repParty);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'party1_lei = :party1LEI'.
	 */
	@Transactional
	public List<InputMsgStore> findWhereParty1LEIEquals(String party1LEI) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE party1_lei = ? ORDER BY rep_party", this,party1LEI);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'party2_lei = :party2LEI'
	 */
	@Transactional
	public List<InputMsgStore> findWhereParty2LEIEquals(String party2LEI) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE party1_lei = ? ORDER BY rep_party", this,party2LEI);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'is_backload = :isBackload'
	 */
	@Transactional
	public List<InputMsgStore> findWhereIsBackloadEquals(String isBackload) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE is_backload = ? ORDER BY is_backload", this,isBackload);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	
	
	
	
			
	@Transactional
	public List<InputMsgStore> findTradesForValuation(String query, String assetClass) throws InputMsgStoreDaoException
	{
		try {					
			return jdbcTemplate.query(query,this,assetClass);			
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	@Override
	public Integer countMatchingRecords(String tradeId, String tlcEvent,
			String usi) throws InputMsgStoreDaoException {
		List<Integer> records = springJdbcTemplate.queryForList("SELECT COUNT(1) FROM "+ getTableName()+ " WHERE src_trade_id = ? AND src_tlc_event = ? AND usi =?",
						Integer.class, tradeId, tlcEvent, usi);
		if (records == null || records.isEmpty() || records.get(0) == null) {
			return null;
		} else {
			return records.get(0);
		}
	}

	@Deprecated
	@Transactional
	public String findActionType(String assetClass, String msgType, String usi, String eventType, String tradeId) throws InputMsgStoreDaoException{
		
		try {	
					
	        String result = actionTypeSp.executeSP(assetClass, msgType, usi, eventType, tradeId);
	        return result; 			
		}
		catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new InputMsgStoreDaoException("Query failed", e);
		}
	}
	
	private class ActionTypeSP extends StoredProcedure{
		
		private String  ASSET_CLASS = "assetClass";
		private String  MSG_TYPE = "msgType";
		private String  USI = "usi";
		private String  EVENT_TYPE = "eventType";
		private String  TRADE_ID = "tradeId";
		private String  ACTION_TYPE = "actionType";
		
		String spName = "sp_action_type";
		
		protected ActionTypeSP(DataSource dataSource) {
			JdbcTemplate spJdbcTemplate = new JdbcTemplate(dataSource);
			spJdbcTemplate.setSkipUndeclaredResults(true);
			setJdbcTemplate(spJdbcTemplate);
			setSql(spName);
			declareParameter(new SqlParameter(ASSET_CLASS, Types.VARCHAR));
			declareParameter(new SqlParameter(MSG_TYPE, Types.VARCHAR));
			declareParameter(new SqlParameter(USI, Types.VARCHAR));
			declareParameter(new SqlParameter(EVENT_TYPE, Types.VARCHAR));
			declareParameter(new SqlParameter(TRADE_ID, Types.VARCHAR));
			declareParameter(new SqlOutParameter(ACTION_TYPE, Types.VARCHAR));
			compile();
		}
				
		 private String executeSP(String assetClass, String msgType, String usi, String eventType, String tradeId) {
			 
			 Map<String,String> inputParams = new HashMap<String, String>();
			 inputParams.put(ASSET_CLASS, assetClass);
			 inputParams.put(MSG_TYPE, msgType);
			 inputParams.put(USI, usi);
			 inputParams.put(EVENT_TYPE, eventType);
			 inputParams.put(TRADE_ID, tradeId);
	            
	         Map<String, Object> results = execute(inputParams);	            
	         String result = (String) results.get(ACTION_TYPE);
	         return result;    
	     }
		
	}

	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'sdr_repository = :sdrRepository'
	 */
	@Transactional
	public List<InputMsgStore> findWhereSdrRepositoryEquals(String sdrRepository)
			throws InputMsgStoreDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE sdr_repository = ? ORDER BY sdr_repository", this,sdrRepository);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
	}
	
	@Transactional
	public List<InputMsgStore> findWhereUtiEquals(String uti) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE uti = ? ORDER BY create_datetime DESC", this,uti);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	@Transactional
	public List<InputMsgStore> findWhereUtiPreviousEquals(String utiPrevious) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE uti_previous = ? ORDER BY create_datetime DESC", this,utiPrevious);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	@Transactional
	public List<InputMsgStore> findWhereIsDelegatedEquals(Boolean isDelegated) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE is_delegated = ? ORDER BY create_datetime DESC", this,isDelegated);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the input_msg_store table that match the criteria 'bus_acc_id = :busAccId'
	 */
	@Transactional
	public List<InputMsgStore> findWhereBusAccIdEquals(String busAccId) throws InputMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, buffer_id, create_datetime, prev_usi, rep_party, party1_lei, party2_lei, is_backload, legs_associated, sdr_repository,uti,uti_previous,is_delegated, bus_acc_id FROM " + getTableName() + " WHERE bus_acc_id = ? ORDER BY bus_acc_id", this,busAccId);
		}
		catch (Exception e) {
			throw new InputMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	

}
