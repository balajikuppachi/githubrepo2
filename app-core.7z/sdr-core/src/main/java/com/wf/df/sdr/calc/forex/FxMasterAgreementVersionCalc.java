package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxMasterAgreementVersionCalc {

	@Autowired
	DTCCUtils dtccUtils;
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxMasterAgreementVersionCalc, isPrototype = false)
	public String compute(
			@DerivedFrom(value=Stv.LegalAgreementDate, isInternal=true) String legalDate,
			@DerivedFrom(value=Calc.intragroupCalc, isInternal=true) String intraGroup)
	{
		if(Constants.TRUE.equalsIgnoreCase(intraGroup))
			return Constants.AGREEMNT_DATE_2002;
		
		if(!Utils.IsNullOrBlank(legalDate))
		{
			//Considering in stv format is {LegalAgreementDate}=March 05, 2012
			String yr= legalDate.substring(legalDate.length()-4, legalDate.length());
			return yr;
		}
		/**STR-531- Master Agreement Type and Version - CAD reporting */
		return Constants.AGREEMENT_DATE_1900;
	}
}
