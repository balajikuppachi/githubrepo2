package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.wf.df.sdr.dao.MessageStatusCheckDao;
import com.wf.df.sdr.dto.MessageStatusCheck;
import com.wf.df.sdr.exception.dao.MessageStatusCheckDaoException;

public class MessageStatusCheckDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MessageStatusCheck>, MessageStatusCheckDao
{
	protected SimpleJdbcTemplate jdbcTemplate;
	@Value("${msg.ready.to.send.query}") String msgToReportQuery;
	@Value("${msg.ready.to.send.for.template.query}") String msgToReportForTemplateQuery;
	@Value("${msg.ready.to.send.for.template.eod.query}") String msgToReportForTemplateEODQuery;
	@Value("${msg.ready.to.send.per.msgtype.query}") String msgToReportPerMsgTypeQuery;
	@Value("${coll.msg.ready.to.send.query}") String collMsgToReportQuery;
	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	public List<MessageStatusCheck> execute(String templateName, String status) throws MessageStatusCheckDaoException
	{
		try {
//			return jdbcTemplate.query("SELECT msg_to_report.send_id, msg_to_report.out_msg_data, msg_status.status, msg_to_report.asset_class, msg_status.transmit_id FROM msg_to_report , msg_status WHERE  msg_to_report.transmit_id = msg_status.transmit_id AND msg_to_report.template_name = ? AND msg_status.status= ? AND NOT EXISTS (SELECT * FROM batch_details WHERE batch_details.transmit_id = msg_status.transmit_id) ", this, templateName, status);
			return jdbcTemplate.query(msgToReportForTemplateQuery, this, templateName, status);
		}
		catch (Exception e) {
			throw new MessageStatusCheckDaoException("Query failed", e);
		}
		
	}
	
	public List<MessageStatusCheck> fetchMsgForEquityEODReport(String templateName, String msg_type, String status, String repository) throws MessageStatusCheckDaoException
	{
		try {
//			return jdbcTemplate.query("SELECT msg_to_report.send_id, msg_to_report.out_msg_data, msg_status.status, msg_to_report.asset_class, msg_status.transmit_id FROM msg_to_report , msg_status WHERE  msg_to_report.transmit_id = msg_status.transmit_id AND msg_to_report.template_name = ? AND msg_status.status= ? AND NOT EXISTS (SELECT * FROM batch_details WHERE batch_details.transmit_id = msg_status.transmit_id) ", this, templateName, status);
			return jdbcTemplate.query(msgToReportForTemplateEODQuery, this, templateName, msg_type, status, repository);
		}
		catch (Exception e) {
			throw new MessageStatusCheckDaoException("Query failed", e);
		}
		
	}

	@Override
	public  List<MessageStatusCheck> fetchMsgForCollReport(String messageType, String status, String sdrRepository) throws MessageStatusCheckDaoException {
		try {
			return jdbcTemplate.query(collMsgToReportQuery, this, messageType, status, sdrRepository);
		} catch (Exception e) {
			throw new MessageStatusCheckDaoException("Query failed", e);
		}
		
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return MessageStatusCheck
	 */
	public MessageStatusCheck mapRow(ResultSet rs, int row) throws SQLException
	{
		MessageStatusCheck dto = new MessageStatusCheck();
		dto.setSend_id( rs.getBigDecimal(1));
		dto.setMsg_data( super.getClobColumn(rs, 2 ) );
		dto.setStatus( rs.getString( 3 ) );
		dto.setAssetClass( rs.getString( 4 ) );
		dto.setMessageType( rs.getString( 5 ) );
		dto.setTransmitId( rs.getBigDecimal(6));
		dto.setParty1LEI( rs.getString(7));
		dto.setSdrRepository(rs.getString(8));
		return dto;
				
	}

	@Override
	public  List<MessageStatusCheck> fetchMsgForCalypsoReport(String assetClass, String messageType, String status, String sdrRepository) throws MessageStatusCheckDaoException {
		try {
			
			if(assetClass == null)
				return jdbcTemplate.query(msgToReportPerMsgTypeQuery, this, messageType, status, sdrRepository);
			else 
				return jdbcTemplate.query(msgToReportQuery, this, assetClass, messageType, status, sdrRepository);
		}
		catch (Exception e) {
			throw new MessageStatusCheckDaoException("Query failed", e);
		}
		
	}

}
