package com.wf.df.sdr.filters.utility;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.exception.FilterException;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.utility.UtilityNotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Utils;

@Component(value="utilityUsiFilter")
public class UtilityUSIFilter {
	
	@Value("${dummy.usi}")  String dummyUSI;	
	
	@Autowired
	UtilityNotEligblePersister nep;
	
	Logger log = Logger.getLogger(getClass());

	public boolean isUSIAvailable(UnitOfWork uow) {
		log.debug("USI filter Called");
		CalculationContext cc = uow.getCalculationContext();
		String usi = cc.getValue(Calc.computedUSICalc, String.class);
		
				
		Boolean affliateTrade = cc.getValue(Calc.isAffiliateTradeCalc, Boolean.class);
		Boolean isEmirTrade = cc.getValue(Calc.isEmirTradeCalc, Boolean.class);
		
		//For affiliate trades USI will come as blank
		if(affliateTrade && Utils.IsNullOrBlank(usi)){
			return true;
		}
		
		if(Utils.IsNullOrBlank(usi) && !isEmirTrade){
			log.debug("USI Cannot be computed, IS NULL");
			// Save it in NotSendPersister
			nep.save(uow, UtilityNotEligblePersister.USI);
			return false;
		}	
		
		if(dummyUSI.contains(usi) && !isEmirTrade)
			throw new FilterException("DummyUSI", "Trade received with dummy USI "+usi);
		
		return true;
	}
}
