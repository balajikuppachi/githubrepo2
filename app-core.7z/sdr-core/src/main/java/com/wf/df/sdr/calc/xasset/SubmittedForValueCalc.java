package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class SubmittedForValueCalc {

	@Calculation(value = Calc.submittedForValueCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliateTrade,
			@DerivedFrom(value = Calc.tradeParty1ValueCalc, isInternal = true) String tradeparty1Value,
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade) {
		
		if(isDtccDelegatedTrade)
			return Constants.BOTH;
		
		if(isAffiliateTrade)
			return tradeparty1Value;
		
		/**Return wellsfargo by default*/
		return tradeparty1Value;

	}
	
}
