package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.ScritturaMsgDao;
import com.wf.df.sdr.dto.ScritturaMsg;
import com.wf.df.sdr.exception.dao.ScritturaMsgDaoException;

public class ScritturaMsgDaoImpl extends AbstractDAO implements ParameterizedRowMapper<ScritturaMsg>, ScritturaMsgDao
{
	protected SimpleJdbcTemplate jdbcTemplate;
	@Autowired
	private JdbcTemplate springJdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(ScritturaMsg dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getCrId(),dto.getConfirmDatetime(),dto.getConfirmPlatform(),dto.getMsg(),dto.getDocId(),dto.getCreateDatetime(), dto.getPaperFlag(), dto.getSourceSystem(), dto.getTradeVersion(), dto.getTradeId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return ScritturaMsg
	 */
	public ScritturaMsg mapRow(ResultSet rs, int row) throws SQLException
	{
		ScritturaMsg dto = new ScritturaMsg();
		dto.setId( rs.getBigDecimal(1));
		dto.setCrId( rs.getString( 2 ) );
		dto.setConfirmDatetime( rs.getTimestamp(3 ) );
		dto.setConfirmPlatform( rs.getString( 4 ) );
		dto.setMsg( rs.getString( 5 ) );
		dto.setDocId( rs.getString( 6 ) );
		dto.setCreateDatetime( rs.getTimestamp(7 ) );
		dto.setPaperFlag( rs.getBoolean(8) );
		dto.setSourceSystem( rs.getString(9) );
		dto.setTradeVersion( rs.getString(10) );
		dto.setTradeId( rs.getString(11) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "scrittura_msg";
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria ''.
	 */
	@Transactional
	public List<ScritturaMsg> findAll() throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'id = :id'.
	 */
	@Transactional
	public List<ScritturaMsg> findWhereIdEquals(BigDecimal id) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE id = ? ORDER BY id", this,id);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'cr_id = :crId'.
	 */
	@Transactional
	public List<ScritturaMsg> findWhereCrIdEquals(String crId) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE cr_id = ? ORDER BY cr_id", this,crId);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'confirm_datetime = :confirmDatetime'.
	 */
	@Transactional
	public List<ScritturaMsg> findWhereConfirmDatetimeEquals(Date confirmDatetime) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE confirm_datetime = ? ORDER BY confirm_datetime", this,confirmDatetime);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'confirm_platform = :confirmPlatform'.
	 */
	@Transactional
	public List<ScritturaMsg> findWhereConfirmPlatformEquals(String confirmPlatform) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE confirm_platform = ? ORDER BY confirm_platform", this,confirmPlatform);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'msg = :msg'.
	 */
	@Transactional
	public List<ScritturaMsg> findWhereMsgEquals(String msg) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE msg = ? ORDER BY msg", this,msg);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'doc_id = :docId'.
	 */
	@Transactional
	public List<ScritturaMsg> findWhereDocIdEquals(String docId) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE doc_id = ? ORDER BY doc_id", this,docId);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<ScritturaMsg> findWhereCreateDatetimeEquals(Date createDatetime) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}
	
	@Override
	public Integer findTradeIdCount(String tradeId, String  tradeVersion) {
		List<Integer> countList = springJdbcTemplate.queryForList("SELECT COUNT(1) FROM " + getTableName() + " WHERE trade_id = ? AND trade_version <= ?", Integer.class, tradeId, tradeVersion);
		
		if (countList == null || countList.isEmpty() || countList.get(0) == null) {
			return 0;
		} else {
			return countList.get(0);
		}
	}
	
	@Transactional
	public List<ScritturaMsg> findWhereTradeIdEquals(String tradeId) throws ScritturaMsgDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, cr_id, confirm_datetime, confirm_platform, msg, doc_id, create_datetime, paper_flag, source_system , trade_version, trade_id FROM " + getTableName() + " WHERE trade_id = ? ORDER BY id", this,tradeId);
		}
		catch (Exception e) {
			throw new ScritturaMsgDaoException("Query failed", e);
		}
		
	}


}
