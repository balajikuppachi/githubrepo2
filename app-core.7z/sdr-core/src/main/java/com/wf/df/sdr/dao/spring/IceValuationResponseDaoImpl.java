package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.IceValuationResponseDao;
import com.wf.df.sdr.dto.IceValuationResponse;

public class IceValuationResponseDaoImpl extends AbstractDAO implements ParameterizedRowMapper<IceValuationResponse>, IceValuationResponseDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(IceValuationResponse dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( recv_id, file_name, send_id, status, total_records, success_records, failed_records, create_datetime ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?)",
				dto.getRecvId(), dto.getFileName(), dto.getSendId(), dto.getStatus(), dto.getTotalRecords(), 
				dto.getSuccessRecords(), dto.getFailedRecords(), dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return IceValuationResponse
	 */
	public IceValuationResponse mapRow(ResultSet rs, int row) throws SQLException
	{
		IceValuationResponse dto = new IceValuationResponse();
		dto.setRecvId(rs.getBigDecimal(1));
		dto.setFileName(rs.getString(2));
		dto.setSendId(rs.getBigDecimal(3));
		dto.setStatus(rs.getString(4));
		dto.setTotalRecords(rs.getInt(5));
		dto.setSuccessRecords(rs.getInt(6));
		dto.setFailedRecords(rs.getInt(7));
		dto.setCreateDatetime(rs.getTimestamp(8));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "ice_valuation_response";
	}
}
