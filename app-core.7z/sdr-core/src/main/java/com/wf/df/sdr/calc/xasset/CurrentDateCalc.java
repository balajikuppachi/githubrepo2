package com.wf.df.sdr.calc.xasset;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;

//TODO: AZ - should rather have a current date as one of the source fields

@Component
public class CurrentDateCalc {
	@Calculation(value=Calc.currentDateCalc, isPrototype=false)
	public Date currentDate() {
		return new Date();
	}
}
