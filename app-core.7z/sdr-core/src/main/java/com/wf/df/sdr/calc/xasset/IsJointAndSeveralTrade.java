package com.wf.df.sdr.calc.xasset;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class IsJointAndSeveralTrade {

	@Calculation(value=Calc.isJointAndSeveralTrade,isPrototype=false)
	public boolean calculate(
			@DerivedFrom(value=Stv.LEI_CP_Other_LEIsList) List<String> cpLEIOtherList,
			@DerivedFrom(value=Stv.LEI_US_Other_LEIsList) List<String> usLEIOtherList)
	{
		
		if(!Utils.IsListNullOrEmpty(cpLEIOtherList) || !Utils.IsListNullOrEmpty(usLEIOtherList))
		{
			List<String> combinedList=new ArrayList<String>();
			if(!Utils.IsListNullOrEmpty(cpLEIOtherList))
				combinedList.addAll(cpLEIOtherList);
			if(!Utils.IsListNullOrEmpty(usLEIOtherList))
					combinedList.addAll(usLEIOtherList);
			for (String lei : combinedList) {
				if(!Utils.IsNullOrBlank(lei) && !Utils.IsNullOrNone(lei))
					return true;
			}
		}
		return false;
	}
}
