package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class IsEmirTradeCalc {

	@Calculation(value = Calc.isEmirTradeCalc, isPrototype = false)
	public boolean compute(
						@DerivedFrom(value=Calc.isEmirPrincipalTradeCalc, isInternal = true) boolean isEmirPrincipalTrade,
						@DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade) {
		
		if(isEmirPrincipalTrade || isEmirDelegatedTrade)
			return true;
						
		return false;
	
	}
	
}
