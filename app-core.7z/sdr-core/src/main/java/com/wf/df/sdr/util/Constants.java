package com.wf.df.sdr.util;


/**
 * Class contains constants used across the application
 * 
 * @author U168247
 * 
 */
public class Constants {

	// Terms
	public final static String STS = "Standard Terms Supplement";
	public final static String DTCC_STS_VALUE = "StandardTermsSupplement";
	public final static String AsSpecifiedInStandardTermsSupplement = "AsSpecifiedInStandardTermsSupplement";
	public final static String AsSpecifiedInMasterAgreement = "AsSpecifiedInMasterAgreement";

	// asset type and report type
	public static final String ASSET_CLASS_INTEREST_RATE = "InterestRate";
	public static final String ASSET_CLASS_CREDIT = "Credit";
	public static final String ASSET_CLASS_EQUITY = "Equity";
	public static final String ASSET_CLASS_FOREX = "ForeignExchange";
	public static final String FX = "FX";
	public static final String ASSET_CLASS_COMMODITY = "Commodity";

	public static final String RATE = "RATE";
	public static final String MESSAGE_TYPE_RT = "RT";
	public static final String MESSAGE_TYPE_PET = "PET";
	public static final String MESSAGE_TYPE_CONF = "Confirm";
	public static final String MESSAGE_TYPE_SNAPSHOT = "Snapshot";
	public static final String MESSAGE_TYPE_VALUATION = "Valuation";
	public static final String MESSAGE_TYPE_DOCUMENT = "Document";
	public static final String MESSAGE_TYPE_SNAPSHOTBACKLOAD = "SnapshotBackload";
	public static final String MESSAGE_TYPE_DEFAULT = "Default";
	public static final String MESSAGE_TYPE_SNAPSHOT_NR = "Snapshot_NR";
	public static final String MESSAGE_TYPE_VALUATION_NR = "Valuation_NR";
	public static final String ERROR_MSG_SEPARATOR = "|||";
	public static final String SRC_FIELD_SEPARATOR = "\\|";
	public static final String TRANS_ID_SEPARATOR = ":";
	public static final String SINGLE_FORWARD_SLASH = "\\";
	public static final String DOUBLE_FORWARD_SLASH = "\\\\";
	public static final String BACKSLASH = "/";
	public static final String MESSAGE_TYPE_SNAPSHOT_TO = "Snapshot_TO";
	public static final String MESSAGE_TYPE_SNAPSHOT_REC = "Snapshot_REC";
	public static final String MESSAGE_TYPE_COLLATERAL_VALUE = "CollateralValue";

	// Use comma as a separator;
	// Only those commas are treated as separators that have an even or zero
	// number of quotes to the right of them
	// This is to ignore those commas that are part of the data and thus are
	// surrounded with quotes.
	public static final String COMMA_SEPARATOR_REGEX = ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";

	// public static final String T_TRADE = "trade";
	public static final String NEW_LINE = "\n";
	public static final String COMMA = ",";
	public static final String SPACE = " ";
	public static final String PIPE = "|";
	public static final String COLON = ":";
	public static final String PERCENTAGE = "%";
	public static final String EMPTY_STRING = "";
	public static final String ALLOW_EMPTY_ON_REQD = "ALLOW_EMPTY_ON_REQD";
	public static final String STOP_EMPTY_ON_COND = "STOP_EMPTY_ON_COND";

	public static final String PERIOD = ".";
	public static final String HYPHEN = "-";
	public static final String EXCEPTION = "***EXCEPTION***";
	public static final String VALUE_NA = "";
	public static final String NONE = "NONE";
	public final static String NOT_FOUND = "NOT FOUND";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String YES = "yes";
	public static final String NEGATIVE_ONE = "-1";

	public static final String WELLS = "WFARGO";
	public static final String WELLS_FARGO = "Wells Fargo";
	public static final String WELLSFARGO = "WellsFargo";

	// Additional source fields that we use internally
	public static final String SEND_ID = "sendId";
	public static final String BUFFER_ID = "bufferId";
	public static final String MESSAGE_TYPE = "messageType";
	public static final String MESSAGE_ORIGIN = "messageOrigin";
	public static final String TRANSMIT_ID = "transmitId";
	public static final String CAD_REPORTING_PARTY = "CAD_REPORTING_PARTY";

	// Document msg variables
	public static final String PAPER_FLAG = "PaperFlag";

	// Confirm field names
	public static final String CONFIRM_DATETIME = "confirmDateTime";
	public static final String CONFIRM_PLATFORM = "confirmPlatform";
	public static final String CONFIRM_DOCUMENT_ID = "confirmDocumentId";

	// Confirm platform
	public static final String CONFIRM_PLATFORM_SCRITTURA = "Scrittura";

	// Message origin
	public static final String MESSAGE_ORIGIN_SCRITTURA_RATES = "ScritturaRates";
	public static final String MESSAGE_ORIGIN_SCRITTURA_CREDIT = "ScritturaCredit";
	public static final String MESSAGE_ORIGIN_SCRITTURA_GALAXY = "ScritturaGalaxy";
	public static final String MESSAGE_ORIGIN_SCRITTURA_ENDUR = "ScritturaEndur";
	public static final String MESSAGE_ORIGIN_CALYPSO_RATES = "CalypsoRates";
	public static final String MESSAGE_ORIGIN_CALYPSO_CREDIT = "CalypsoCredit";
	public static final String MESSAGE_ORIGIN_ENDUR_COMMODITY = "EndurCommodity";
	public static final String MESSAGE_ORIGIN_GALAXY = "Galaxy";
	public static final String MESSAGE_ORIGIN_CDBO = "CDBO";

	// Message status
	public static final String MSG_STATUS_READY_TO_SEND = "READY_TO_SEND";
	public static final String MSG_STATUS_NOT_TO_SEND = "NOT_TO_SEND";
	public static final String MSG_STATUS_FEE_TRADE_NOT_TO_SEND = "FEE_TRADE_NOT_TO_SEND";
	public static final String MSG_STATUS_ADDED_TO_CSV = "ADDED_TO_CSV";
	public static final String MSG_STATUS_RESENT = "RESENT";
	public static final String MSG_STATUS_ACCEPTED = "ACCEPTED";
	public static final String MSG_STATUS_REJECTED = "REJECTED";
	public static final String MSG_STATUS_DUPLICATE = "DUPLICATE";
	public static final String MSG_STATUS_PUBLISHED = "PUBLISHED";
	public static final String MSG_STATUS_NOT_PUBLISHED = "NOT_PUBLISHED";
	public static final String MSG_STATUS_TRACE_ID_NOT_FOUND = "TRACE_ID_NOT_FOUND";
	public static final String MSG_STATUS_NOT_ADDED_TO_MQ = "NOT_ADDED_TO_MQ";
	public static final String MSG_STATUS_WARNING = "WARNING";

	public static final String DEFAULT = "DEFAULT";
	public static final String FREQUENCY_PA = "PA";
	public static final String FREQUENCY_MTH = "MTH";
	public static final String FREQUENCY_SA = "SA";
	public static final String FREQUENCY_QTR = "QTR";
	public static final String FREQUENCY_WK = "WK";
	public static final String FREQUENCY_BIWK = "BIWK";
	public static final String FREQUENCY_BIM = "BIM";
	public static final String FREQUENCY_DLY = "DLY";
	public static final String FREQUENCY_ZC = "ZC";
	public static final String FREQUENCY_LUN = "LUN";
	public static final String FREQUENCY_5W = "5W";
	public static final String FREQUENCY_13W = "13W";
	public static final String FREQUENCY_26W = "26W";

	// Constants being used in rules
	public static final String DTCC = "DTCC";
	public static final String ICE = "ICE";
	public static final String CME = "CME";
	public static final String Chicago_Mercantile_Exchange = "Chicago Mercantile Exchange";
	public static final String VCON_Chicago_Mercantile_Exchange = "VCON Chicago Mercantile Exchange";
	public static final String WFS_WFBNA_TRUEEX = "WFS_WFBNA_TRUEEX";
	public static final String WFS_WFBNA_VCON = "WFS_WFBNA_VCON";

	public static final String INTERNAL = "Internal";
	public static final String LEG_FIXED = "Fixed";
	public static final String LEG_FLOATING = "Floating";

	public static final String FIELD_REQUIRED = "R";
	public static final String FIELD_CONDITIONAL = "C";
	public static final String FIELD_OPTIONAL = "O";
	public static final String FIELD_NOT_APPLICABLE = "NA";

	public static final String PRODUCT_TYPE_CAPFLOOR = "CapFloor";
	public static final String PRODUCT_TYPE_EXOTIC = "Exotic";
	public static final String PRODUCT_TYPE_FRA = "FRA";
	public static final String PRODUCT_TYPE_FPA = "FPA";
	public static final String PRODUCT_TYPE_TREASURY_LOCK = "TreasuryLock";
	public static final String PRODUCT_TYPE_CANCELLABLE_SWAP = "CancellableSwap";
	public static final String PRODUCT_TYPE_LCDS = "LCDS";
	public static final String PRODUCT_TYPE_CDS = "CDS";
	public static final String PRODUCT_TYPE_CDX = "CDX";
	public static final String PRODUCT_TYPE_RECOVERY_LOCK = "Recovery Lock";
	public static final String PRODUCT_TYPE_FIXED_REOCVERY = "Fixed Recovery";
	public static final String PRODUCT_TYPE_TOTAL_RETURN_SWAP = "TotalReturnSwap";
	public static final String PRODUCT_TYPE_STRUCTURED_PRODUCT = "StructuredProduct";
	public static final String PRODUCT_TYPE_STRUCTURED_MUNI = "StructuredMuni";
	public static final String PRODUCT_TYPE_RISK_PARTICIPATION_SWAP = "RiskParticipationSwap";
	public static final String SOVEREIGN = "Sovereign";
	public static final String PRODUCT_TYPE_XCCY = "CrossCurrency";
	public static final String PRODUCT_TYPE_CDSIndexOption = "CDSIndexOption";
	public static final String PRODUCT_TYPE_MMD_RATE_LOCK = "MMDRateLock";
	public static final String PRODUCT_TYPE_CDSStructProd = "CDSStructProd";
	public static final String PRODUCT_TYPE_CreditDefaultSwapLoan="CreditDefaultSwapLoan";
	public static final String PRODUCT_TYPE_CDSIndexTranche="CDSIndexTranche";
	public static final String PRODUCT_TYPE_SpreadCapFloorCMS="SpreadCapFloorCMS";


	public static final String PRODUCT_SUB_TYPE_CORRIDOR = "Corridor";

	public static final String SWAPTION_EXERCISE_BERMUDAN = "Bermudan";
	public static final String SWAPTION_EXERCISE_EUROPEAN = "European";
	public static final String SWAPTION_EXERCISE_AMERICAN = "American";
	public static final String RTP = "RTP";
	public static final String RTR = "RTR";
	public static final String PARTY2 = "party2";
	public static final String PARTY1 = "party1";
	public static final String OPTION_STRADDLE = "Straddle";
	public static final String OPTION_COLLAR = "Collar";
	public static final String OPTION_CALL = "Call";
	public static final String OPTION_PUT = "Put";

	public static final String COUNTERPARTY = "Counterparty";
	// trade status values
	public static final String TRADE_STATUS_TO_BE_VER = "TO_BE_VER";
	public static final String TRADE_STATUS_TOBE_VER = "TOBE_VER";
	public static final String TRADE_STATUS_TOBE_ASSIGNED = "TOBE_ASSIGNED";
	public static final String DAY_ASSIGNED = "DAY_ASSIGNED";
	public static final String DAY_PENDING = "DAY_PENDING";

	public static final String TRADE_STATUS_TO_BE_MAT = "TO_BE_MAT";
	public static final String TRADE_STATUS_ECN_EARLY_RISK = "ECN_EARLY_RISK";
	public static final String TRADE_STATUS_BOOKED = "BOOKED";
	public static final String TRADE_STATUS_PRE_BOOKED = "PRE_BOOKED";
	public static final String TRADE_STATUS_CH_TO_BE_VER = "CH_TO_BE_VER";
	// public static final String TRADE_STATUS_DAY_INVALID = "DAY_INVALID";
	public static final String TRADE_STATUS_CANCELED = "CANCELED";
	public static final String TRADE_STATUS_SHADOW_TERM = "SHADOW_TERM";
	public static final String TRADE_STATUS_PRE_NOVATED = "PRE_NOVATED";
	public static final String TRADE_STATUS_EXERCISED = "EXERCISED";
	public static final String TRADE_STATUS_MATURED = "MATURED";
	public static final String TRADE_STATUS_VERIFIED = "VERIFIED";
	public static final String TRADE_STATUS_NC_PENDING = "NC_PENDING";
	public static final String TRADE_STATUS_PENDING = "PENDING";
	public static final String TRADE_STATUS_NC_CONSENT_PEND = "NC_CONSENT_PEND";
	public static final String TRADE_STATUS_NC_CANCELED = "NC_CANCELED";
	public static final String TRADE_STATUS_TRADER_REVIEW = "TRADER_REVIEW";
	public static final String TRADE_STATUS_PARTIAL_ASSIGNED = "PARTIAL_ASSIGNED";

	public static final String Percentage = "Percentage";
	public static final String Buy = "Buy";
	public static final String Sell = "Sell";
	public static final String LEI_PREFIX = "DTCC";

	// DTCC Doc Action and Transaction Values
	public static final String Novation = "Novation";
	public static final String Unwind = "Unwind";
	public static final String Exercise = "Exercise";
	public static final String Exercise_Physical = "Exercise - Physical";
	public static final String Amendment = "Amendment";
	public static final String Increase = "Increase";
	public static final String Termination = "Termination";
	public static final String Exit = "Exit";
	public static final String Confirmation = "Confirmation";
	public static final String Trade = "Trade";
	public static final String Cancel = "Cancel";
	public static final String APPLICABLE = "Applicable";
	public static final String New = "New";
	public static final String Modify = "Modify";
	public static final String NOT_APPLICABLE = "Not Applicable";
	public static final String Cancellation = "Cancellation";
	public static final String Backload = "Backload";
	public static final String Historical = "Historical";
	public static final String CorporateAction = "CorporateAction";
	public static final String Origination = "Origination";
	public static final String GLOBAL_CANCEL = "GlobalCancel";

	public static final String CashPrice_Alternate = "Cash Price - Alternate";
	public static final String CashPrice = "Cash Price";
	public static final String CashPrice_PerYieldCurve = "Par Yield Curve - unadj.";
	public static final String Cash = "Cash";
	public static final String CashPrice_CrossCurrency = "Cross Currency";

	public static final String UnCollateralized = "Uncollateralized";
	public static final String FullyCollateralized = "FullyCollateralized";
	public static final String PartiallyCollateralized = "PartiallyCollateralized";
	public static final String OneWayCollateralized = "One-WayCollateralized";
	public static final String Fully = "Fully";
	public static final String Partially = "Partially";
	public static final String OneWay = "OneWay";
	public static final String Variation = "Variation";
	public static final String Initial = "Initial";
	public static final String Exchange = "Exchange";
	public static final String Bilateral = "BILATERAL";
	public static final String ISDA = "ISDA";
	public static final String ALL = "All";
	public static final String TBD = "TBD";
	public static final String Novation_Trade = "Novation-Trade";
	public static final String NovationTrade = "NovationTrade";
	public static final String NovationTradeForCredit = "Novation Trade";

	// Market type values
	public static final String Novation_EE = "Novation - EE";
	public static final String Novation_OR = "Novation - OR";
	public static final String Novation_RP = "Novation - RP";
	public static final String PartialNovation_OR = "Partial Novation - OR";
	public static final String PartialNovation_RP = "Partial Novation - RP";
	public static final String Termination_Voluntary = "Termination - Voluntary";
	public static final String Termination_Involuntary = "Termination - Involuntary";
	public static final String Partial_Term_Voluntary = "Partial Term - Voluntary";
	public static final String NovationWFRole_Transferee = "Transferee";
	public static final String NovationWFRole_Transferor = "Transferor";
	public static final String NovationWFRole_RemainingParty = "Remaining Party";
	public static final String WachoviaRole_EE = "EE";
	public static final String WachoviaRole_OR = "OR";
	public static final String WachoviaRole_RP = "RP";
	public static final String Credit_Novation_OR = "Credit Novation - OR";
	public static final String Credit_Novation_EE = "Credit Novation - EE";
	public static final String Credit_Novation_RP = "Credit Novation - RP";
	public static final String Credit_Partial_Novation_OR = "Credit Partial Novation - OR";
	public static final String Credit_Partial_Novation_EE = "Credit Partial Novation - EE";
	public static final String Credit_Partial_Novation_RP = "Credit Partial Novation - RP";
	public static final String Compressed_Term = "Compressed - Term";
	public static final String Compressed_PartialTerm = "Compressed - Partial Term";
	public static final String Compressed_New = "Compressed - New";
	public static final String Compressed_Amend = "Compressed - Amend";
	public static final String Undo_Term = "Undo - Term";
	public static final String Undo_Partial_Term = "Undo - Partial Term";
	public static final String Undo_Amend = "Undo - Amend";
	public static final String Amendment_Price_Forming = "Amendment (Price Forming)";
	public static final String Amendment_Non_Price_Forming = "Amendment (Non Price Forming)";
	public static final String Bilateral_Cleared = "Bilateral - Cleared";
	public static final String FeeType_Fee = "FEE";
	public static final String FeeType_TerminationFee = "TERMINATION_FEE";
	public static final String FeeType_Termination = "TERMINATION";
	public static final String FeeType_NovationFee = "NOVATION_FEE";
	public static final String FeeType_Premium = "PREMIUM";

	public static final String BLOCK_TRADE = "Block Trade";
	public static final String BACKLOAD_LIVE = "live";
	public static final String BACKLOAD_DEAD = "dead";
	public static final String HISTORICAL_LIVE = "historical-live";
	public static final String HISTORICAL_DEAD = "historical-dead";
	public static final String CFTC = "CFTC";

	public static final String OLD_USI_PREFIX = "1031234567";
	public static final String WELLS_USI_PREFIX = "1030399337";
	public static final CharSequence RATES_EXOTIC = "InterestRate:Exotic";
	public static final String EmbeddedOptionOnSwap = "EmbeddedOptionOnSwap";
	public static final String SEMICOLON = ";";
	public static final String Unverified = "Unverified";

	/** Forex **/

	public static final String MESSAGE_TYPE_FX_HISTORYSNAPSHOT = "Historical Snapshot";
	public static final String FOREX_OPTION = "Option";
	public static final String FOREX_FORWARD = "Forward";
	public static final String PRODUCT_TYPE_FXCASH = "FXCash";
	public static final String PRODUCT_TYPE_FXSWAP = "FXSwap"; 
	public static final String FOREX_SWAP_LEG = "ForexSwapLegType";
	public static final String FOREX_SWAP_LEG_NEAR = "NL";
	public static final String FOREX_SWAP_LEG_FAR = "FL";
	public static final String FOREX_SWAP_LEG_INDEX = "ForexSwapLegIndex";
	public static final String PRODUCT_TYPE_FXFORWARD="FXForward";
	public static final String PRODUCT_TYPE_FXOPTION="FXOption";
	

	public static final String UNDERSCORE = "_";

	// Equity Templates
	public static final String EqTemplate_Document = "Equity-Document";
	public static final String EqTemplate_VS = "Equity-VS";
	public static final String EqTemplate_ES_PSA_CFD = "Equity-ES_PSA_CFD";
	public static final String EqTemplate_StructuredProduct = "Equity-StructuredProduct";
	public static final String EqTemplate_FWD = "Equity-FWD";
	public static final String Equity_Valuation = "Equity-Valuation";
	public static final String EqTemplate_OPT = "Equity-OPT";

	public static final String EquitySwap="EquitySwap";
	public static final String EquityForward="EquityForward";
	public static final String EquityOption="EquityOption";
	public static final String XX = "XX";
	public static final String PMINUS = "P-";
	public static final String CMINUS = "C-";
	public static final String YY = "YY";
	public static final String USNY = "USNY";

	
	public static final String SDR_REPORTABLE_TRUE = "TRUE";

	// Commodities stuff
	public final static String SDRMessageID = "tradeConfirmUId";
	public final static String ICEMessageType = "ICEMessageType";
	public static final String ICEMessageAction = "ICEMessageAction";
	public static final String SenderTradeRefId = "SenderTradeRefId";
	public static final String ConfirmationFile = "ConfirmationFile";
	public static final String ConfirmationTime = "ConfirmationTime";
	public static final String CollateralizationType = "CollateralizationType";
	public static final String InternalAffLongName = "InternalAffiliateLongName";
	public final static String ICEMessageTypeKey = "{ICEMessageType}=";
	public final static String SDRMessagekey = "{tradeConfirmUId}=";
	public static final String ICEMessageActionKey = "{ICEMessageAction}=";
	public static final String SenderTradeRefIdKey = "{SenderTradeRefId}=";
	public static final String ConfirmationFileKey = "{ConfirmationFile}=";
	public static final String ConfirmationTimeKey = "{ConfirmationTime}=";
	public static final String CollateralizationTypeKey = "{CollateralizationType}=";
	public static final String ConfirmationBufferId = "{ConfirmationBufferId}=";
	
	public static final String ICELifecycleStatusDate = "{ICELifecycleStatusDate}=";
	public static final String InternalAffiliateLongName = "{InternalAffiliateLongName}=";

	public static final String SwaptionDealReferenceUniqueID = "SwaptionDealReferenceUniqueID";
	public static final String SwaptionDealReferenceUniqueIDKey = "{SwaptionDealReferenceUniqueID}=";
	public static final String AffiliateDefaultDate = "AffiliateDefaultDate";
	public static final String IsWellsSeller = "IsWellsSeller";
	public static final String AffiliateDefaultDateKey = "{AffiliateDefaultDate}=";

	public static final String IsWellsSellerKey = "{IsWellsSeller}=";

	public static final String BO_STATUS = "bo_status";
	public static final String BO_STATUS_DESC = "bo_status_desc";
	public static final String BO_CONFIRM_BUYER_INDEX = "bo_confirm_buyer_index";
	public static final String BO_CONFIRM_SELLER_INDEX = "bo_confirm_seller_index";
	public static final String BO_CONFIRM_REFERENCE_PRICE = "bo_confirm_reference_price";

	public static final String STATUS = "Status";
	public static final String TRACEID = "TraceId";
	public static final String SENDID = "SendId";
	public static final String TRADE_CONFIRM_UID = "tradeConfirmUId";
	public static final String MESSAGETYPE = "MessageType";
	public static final String CREATIONTIMESTAMP = "CreationTimestamp";

	public static final String ECONFIRM_SELLER = "econfirm_seller";
	public static final String ECONFIRM_SENDER_TRADE_REF_ID = "econfirm_senderTradeRefId";
	public static final String ECONFIRM_BROKER = "econfirm_broker";
	public static final String ECONFIRM_TRADEDATE = "econfirm_tradeDate";
	public static final String ECONFIRM_BUYER_US_REGULATORY_DESIGNATION = "econfirm_buyerUSRegulatoryDesignation";
	public static final String ECONFIRM_US_REPORTING_ENTITY_CONTINUATION_DATA = "econfirm_usReportingEntityContinuationData";
	public static final String ECONFIRM_US_REPORTING_ENTITY_PET_DATA = "econfirm_usReportingEntityPETData";
	public static final String ECONFIRM_COUNTER_PARTY_STATUS = "econfirm_counterpartyStatus";
	public static final String ECONFIRM_USI = "econfirm_usi";
	public static final String ECONFIRM_US_REPORTING_ENTITY_VALUATION_DATA = "econfirm_usReportingEntityValuationData";
	public static final String ECONFIRM_TRACEID = "econfirm_traceId";
	public static final String ECONFIRM_SELLER_US_REGULATORY_DESIGNATION = "econfirm_sellerUSRegulatoryDesignation";
	public static final String ECONFIRM_BUYER = "econfirm_buyer";
	public static final String ECONFIRM_COUNTER_PARTY_STATUS_DATE = "econfirm_counterpartyStatusDate";
	public static final String ECONFIRM_SUBMISSION_COMPANY = "econfirm_submissionCompany";
	public static final String ECONFIRM_SELLER_LEI = "econfirm_sellerLEI";
	public static final String ECONFIRM_FIRST_REPORTED_SDR = "econfirm_firstReportedSDR";
	public static final String ECONFIRM_STATUS = "econfirm_status";
	public static final String ECONFIRM_TYPE = "econfirm_type";
	public static final String ECONFIRM_DESCRIPTION = "econfirm_description";
	public static final String ECONFIRM_CODE = "econfirm_code";
	public static final String ECONFIRM_STATUSDATE = "econfirm_statusDate";
	public static final String COMM_PHYS = "COMM-PHYS";

	// ICE Message Types
	public final static String ICE_SUBMIT_TRADE = "2";
	public final static String ICE_CANCEL_DISPUTE_TRADE = "5";
	public final static String ICE_PAPER_CONFIRM = "39";
	public final static String ICE_LIFECYCLE_EVENT = "37";
	public final static String ICE_VALUATION = "35";
	public final static String ICE_BACKLOADED = "31";
	public static final String ENCONNECT = "Enconnect";
	public static final String MATCHED = "MATCHED";
	public static final String PENDING = "PENDING";
	public static final String PMATCHED = "PMATCHED";
	public static final String PPENDING = "PPENDING";
	public static final String UNMATCHED = "UNMATCHED";
	public static final String ERROR = "ERROR";
	public static final String ECONFIRM_TYPE_EXCEPTION = "Exception";
	public static final String SUCCESS = "SUCCESS";
	public static final String ASSIGNED = "ASSIGNED";
	public static final String PCANCELED = "PCANCELED";
	public static final String CANCELED = "CANCELED";

	// ICE MEssage Actions
	public static final String SUBMIT = "SUBMIT";
	public static final String CORRECT_ERRORS_DISPUTE = "CORRECT ERRORS(DISPUTE)";
	public static final String UNDO_CORRECT_ERRORS_UNDISPUTE = "UNDO CORRECT ERRORS(UNDISPUTE)";
	public static final String UNDO_CORRECT_ERRORS = "UNDO CORRECT ERRORS";
	public static final String REQUEST_TO_CORRECT_ERRORS_DISPUTE = "REQUEST TO CORRECT ERRORS(DISPUTE)";
	public static final String REQUEST_TO_MODIFY_TERMS = "REQUEST TO MODIFY TERMS";
	public static final String REQUEST_TO_NOVATE = "REQUEST TO NOVATE";
	public static final String NOVATE_STEP_IN_SUBMIT = "NOVATESTEPINSUBMIT";
	public static final String REQUEST_TO_OPTION_EXERCISE = "REQUEST TO OPTION EXERCISE";
	public static final String REQUEST_TO_BUST = "REQUEST TO BUST";
	public static final String REQUEST_TO_EARLY_TERMINATE = "REQUEST TO EARLY TERMINATE";
	public static final String BOOKED = "BOOKED";
	public static final String AMEND = "AMEND";
	public static final String NOVATION = "NOVATION";
	public static final String EXERCISE = "EXERCISE";
	public static final String BUYOUT = "BUYOUT";
	public static final String SIMPLE = "SIMPLE";
	public static final String SAME = "SAME";
	public static final String Same_Profile = "Same Profile";
	public static final String CANCEL = "CANCEL";
	public static final String CANCEL_TRADE = "CANCEL_TRADE";
	public static final String REQUEST_TO_DCO_GIVEUP = "REQUEST TO DCO GIVEUP";
	public static final String NC_ACCEPTED_OR = "NC_ACCEPTED_OR";

	public static final String PREFIX_ASTERISK = "**";
	public static final String REFERENCE_PRICE = "ReferencePrice";
	public static final String SELLER_PAY_INDEX = "SellerPayIndex";
	public static final String BUYER_PAY_INDEX = "BuyerPayIndex";

	public final static String GTRCREATE = "GTRCREATE";
	public static final String PostAllocation = "PostAllocation";
	public static final String PreAllocation = "PreAllocation";

	public static final String STV_STRING = "StvString";
	public static final String ECONFIRM_VALUATIONTYPE = "econfirm_valuationType";
	public static final String ECONFIRM_VALUATIONDATE = "econfirm_valuationDate";
	public static final String VALUATION_NOTIFICATION_EMAIL_CONTENT = "Status: {0} out of {1} records succeeded.{2}Valuation file {3} has been submitted to ICE. {4}Response from ICE can be found at:{5}{6}Please contact G=Global Commodities Support <GlobalCommoditiesSupport@wellsfargo.com> with any questions.{7}*Please do not reply to this email, SDRBridgeICENotification email account cannot receive emails and is used for sending ICE notification emails only*.{8}This email is subject to a disclaimer, please click on the following link or cut and paste the link into the address bar of your browser.{9}https://www.wellsfargo.com/com/disclaimer/ged5";
	public static final String VALUATION_NOTIFICATION_EMAIL_SUBJECT = "Notification from Endur environment {0} : Submission of valuation xml {1} resulted in {2} out of {3} records succeeded.";
	public static final String LEGS_ASSOCIATED = "legs_associated";
	public static final String VALIDATE = "VALIDATE";

	public static final String PAYER = "Payer";
	public static final String RECEIVER = "Receiver";
	public static final String FREEFORMATTEXT = "FREEFORMATTEXT";
	public static final String FAFFIL = "FAFFIL";
	public static final String AFFIL = "AFFIL";
	public static final String AFFILIATEEXEMPTION = "AFFILIATEEXEMPTION";

	public static final String CALYPSO_CANCELED = "CANCELED_TRADE";
	public static final String CREDITDEFAULTSWAP = "CreditDefaultSwap";

	public static final String NON_AFFILIATE_TRADE = "NON_AFFILIATE_TRADE";
	public static final String Notional_Amount = "Notional_Amount";
	public static final String Notional_Currency = "Notional_Currency";
	public static final String UPI = "UPI";
	public static final String ENC_RECON = "ENC_RECON";
	public static final String OFFFACILITY = "Off-Facility";
	public static final String SEF = "SEF";

	public static final String Reportable123 = "Reportable123";
	public static final String NonReportable123 = "NonReportable123";
	public static final String Reportable456 = "Reportable456";
	public static final String NonReportable456 = "NonReportable456";

	public static final String TradeType123_456 = "TradeType123_456";
	public static final String Upfront = "UPFRONT";
	public static final String Compressed = "Compressed";
	public static final String CALYPSO_USI = "CALYPSO_USI";
	public static final String CALYPSO_TRADE_ID = "CALYPSO_TRADE_ID";
	public static final String CALYPSO_USI_PREVIOUS = "CALYPSO_USI_PREVIOUS";
	public static final String CALYPSO_ASSET_CLASSES = "CALYPSO_ASSET_CLASSES";
	public static final String Undo = "Undo";

	// EMIR calculation constants
	public static final String DTCCUS = "DTCCUS";
	public static final String DTCCEU = "DTCCEU";
	public static final String ESMA = "ESMA";
	// public static final String
	public static final String EEA = "EEA";
	public static final String NonEEA = "nonEEA";
	public static final String PRINCIPAL = "Principal";
	public static final String EMIR = "EMIR";
	public static final String EMIR_DELEGATED_FULL = "Full";
	public static final String EMIR_DELEGATED_INDEPENDENT = "Independent";

	public static final String REPORTABLE_TO = "REPORTABLE_TO";
	public static final String REPORTABLE_TO_DTCC = "REPORTABLE_TO_DTCC";
	public static final String REPORTABLE_TO_EMIR = "REPORTABLE_TO_EMIR";
	public static final String REPORTABLE_TO_CAD = "REPORTABLE_TO_CAD";
	public static final String DELEGATE_REPORTABLE_TO_EMIR = "DELEGATE_REPORTABLE_TO_EMIR";
	public static final String DELEGATE_REPORTABLE_TO_DTCC = "DELEGATE_REPORTABLE_TO_DTCC";

	public static final String TEMP_UTI_PREFIX = "SDRGeneratedUTI_";
	public static final String LifeCycleEvent_Error = "Error";
	public static final String LifeCycleEvent_Modify = "Modify";
	public static final String NOT_CONFIRMED = "NotConfirmed";
	public static final String AGREEMNT_DATE_2002 = "2002";
	public static final String CALYPSO_UTI = "CALYPSO_UTI";
	public static final String CALYPSO_UTI_PREVIOUS = "CALYPSO_UTI_PREVIOUS";
	
	public static final String DataSubmitterMessageID = "Data Submitter Message ID";
	public static final String DataSubmitterMessageId = "Data Submitter Message Id";
	public static final String BOTH = "BOTH";
	
	public static final String TO_REPOSITORY_IDENTIFIER = "_Repository_";
	public static final String EMIR_SRC_TLC_EVENT_DO_NOT_REPORT = "Novation - RP,Novation - OR";
	public static final String EMIR_SRC_TRADE_STATUS_DO_NOT_REPORT = "ASSIGNED,DAY_ASSIGNED";
	public static final String EMIR_SRC_TRADE_STATUS_DO_NOT_REPORT_TERMINATION = "TERMINATED,TERMINATED_SLET";
	public static final String RECON = "Recon";
	//Commodity-TO
	public static final String PAYLEG = "CommoditySwapPayLegType";
	public static final String RECLEG = "CommoditySwapRecLegType";
	public static final String BUYSELL = "econfirm_buySell";
	public static final String RECLEGID = "CommoditySwapRecLegID"; 
	public static final String PAYLEGID = "CommoditySwapPayLegID";
	public static final String PRODTYPE = "ProductProxyType";
	public static final String COMMSWAP = "commSwap";
	public static final String COMMTRSWAP = "CommodityTRSwap";
	public static final String NEW_DEAL = "New Deal";
	
	
	public static final String COLLATERAL_TOTAL = "COLLATERAL_TOTAL";
	public static final String COLLATERAL_PORTFOLIO_CODE = "COLLATERAL_PORTFOLIO_CODE";
	public static final String COLLATERAL_PRINCIPAL_ID = "COLLATERAL_PRINCIPAL_ID";
	public static final String COLLATERAL_CACCY = "COLLATERAL_CACCY";
	public static final String COLLATERAL_COLL_PORTFOLIO = "COLLATERAL_COLL_PORTFOLIO";
	//For report generation purpose
	public static final String ASSET_CLASS_COLLATERAL = "COLLATERAL";
	
	public static final String MONTHLY = "Monthly";
	public static final String WEEKLY = "Weekly";
	public static final String DAILY = "Daily";
	public static final String REJECTED="REJECTED";
	public static final String ACCEPTED="ACCEPTED";
	
	

	public static final String SHORT_FIRST="SHORT FIRST";
	public static final String LONG_FIRST="LONG FIRST";
	public static final String SPECIFIC_FIRST="SPECIFIC FIRST";
	public static final String SHORT_LAST="SHORT LAST";
	public static final String LONG_LAST="LONG LAST";
	public static final String SPECIFIC_LAST="SPECIFIC LAST";
    public static final String STSXML = "STSXML";	
    public static final String BasisPoints = "Basis Points";
	public static final String SRC_PRODUCT_TYPE_SWAP = "Swap";
	public static final String SRC_PRODUCT_TYPE_SWAPTION = "Swaption";
	public static final String SRC_PRODUCT_TYPE_CAP = "Cap";
	public static final String SRC_PRODUCT_TYPE_FLOOOR = "Floor";
	public static final String NON_SD_NON_MSP="non-SD/MSP";
	public static final String CAD = "CAD";
	public static final String Bloomberg = "Bloomberg";
	public static final String ISDACreditMonolineInsurers ="ISDACreditMonolineInsurers";
	public static final String LC = "LC"; 
	public static final String CORPCDS="CORPCDS";
	public static final String CAD_US = "CAD.Us";
	public static final String CAD_THEM = "CAD.Them";
	public static final String CAD_BOTH = "CAD.BOTH";
	public static final String Us = "Us";
	public static final String CFTC_US = "CFTC.Us";
	public static final String CFTC_Them = "CFTC.Them";
	public static final String EMIR_US = "EMIR.Us";
	public static final String CA = "CAD.";
	
	
	public static final String FEDFUNDS = "FEDFUNDS";
	public static final String QTR = "QTR";
	public static final String CA_PERIOD = "CA.";
	public static final String SETTLED = "SETTLED";
	public static final String NETTED = "NETTED";
	public static final String MATURED = "MATURED";
	public static final String SEC = "SEC";
	public static final String SingleIndex = "SingleIndex";
	public static final String SingleName = "SingleName";
	public static final String Basket = "Basket";
	public static final String NFC = "NFC";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String List = "List";
	public static final String STSRESPONSE = "STSRESPONSE";	
	
	public static final String BUYSELL_ORG = "econfirm_buySell_org";
	public static final String STRADDLE = "Straddle";
	
	public static final String GTR = "GTR";
	public static final String REGREP = "REG REP";
	public static final String ACK = "ACK";
	public static final String NACK = "NACK";
	public static final String WACK = "WACK";
	public static final String USI = "USI";
	public static final String RATEFIX = "RateFix";
	public static final String COMM_PRODUCT_2600 = "2600";
	
	public static final String Test = "Test";
	public static final String PRODUCT_TYPE_ELCDS = "ELCDS";
	public static final String CDSonLeveragedLoans = "CDSonLeveragedLoans";
	public static final String PRODUCT_TYPE_EMBS = "EMBS";
	public static final String EuropeanCMBS="EuropeanCMBS";	
	public static final String PRODUCT_TYPE_IOS="IOS";	
	public static final String PRODUCT_TYPE_MBS="MBS";	
	public static final String StandardTermsSupplement="StandardTermsSupplement";	

	public static final String AFFILIATE = "Affiliate";	
	public static final String CreditIndex ="2003CreditIndex";
	public static final String IMAGINE4 = "IMAGINE4";
	public static final String STIERS_ENDUR = "STIERS_ENDUR";
	public static final String STIERS_CALYPSO_CALRATES = "STIERS_CALYPSO_CALRATES";
	public static final String PC = "PC";
	public static final String OW = "OW";
	public static final String FC = "FC";
	public static final String UC = "UC";
	public static final String PRODUCT_TYPE_MBX = "MBX";
	public static final String One_Way = "One-Way";
	public static final String PRODUCT_SUB_TYPE_Cappedperiodicswap = "Capped periodic swap";
	public static final String PRODUCT_SUB_TYPE_Cappedswap="Capped swap";
	public static final String PRODUCT_SUB_TYPE_Convertibleswap="Convertible swap";
	public static final String PRODUCT_SUB_TYPE_Inflation="Inflation";
	public static final String PRODUCT_SUB_TYPE_KnockOut="KnockOut";
	public static final String PRODUCT_SUB_TYPE_KnockOutHedge="KnockOutHedge";
	public static final String PRODUCT_SUB_TYPE_ParticipatingSwap="ParticipatingSwap";
	public static final String PRODUCT_SUB_TYPE_PeriodicSwap="Periodic Swap";
	public static final String PRODUCT_SUB_TYPE_SP_CapFloor="SP_CapFloor";
	public static final String PRODUCT_SUB_TYPE_SP_Other="SP_Other";
	public static final String PRODUCT_SUB_TYPE_StructuredExotic="Structured Exotic";

	public static final String US="Us";
	public static final String INDEX="Index";
	
	public static final String COMMCAPFLOOR = "CommodityCapFloor";
	public static final String COMMSWAPTION = "commSwaption";
	public static final String FIXED = "FIXED";
	public static final String FLOAT = "FLOAT";
	public static final String CALL = "CALL";
	public static final String PUT = "PUT";
	public static final String QUATERLY = "QUATERLY";
	public static final String YEARLY = "YEARLY";
	public static final String COMMODITYTRSWAP = "CommodityTRSwap";
	public static final String COMMODITYSWAP = "CommoditySwap";
	public static final String Physical = "Physical";
	public static final String CommoditySwaption = "CommoditySwaption";
	public static final String SwapDealer = "Swap Dealer";
	public static final String SD = "SD";
	public static final String NonSDMSP = "Non-SD/MSP";
	public static final String MSP = "MSP";
	public static final String NONSDNONMSP = "NON_SD_NON_MSP";
	public static final String MajorSwapParticipant = "Major Swap Participant";
	public static final String COMMODITYFORWARD = "COMMODITYFORWARD";
	
	public static final String PRODUCT_SUB_TYPE_EquityExotic="EquityExotic";
	public static final String DEFAULT_UNDERLYINGASSET_INSTRUMENT_ID_BASKET="Basket";
	public static final String NO_SIGNED_AGREEMENT="no signed agreement";
	public static final String AGREEMENT_DATE_1900="1900";
	public static final String JointAndSeveral="JointAndSeveral";

}
