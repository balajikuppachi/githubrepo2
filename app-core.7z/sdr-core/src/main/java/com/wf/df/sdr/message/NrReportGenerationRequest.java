package com.wf.df.sdr.message;

import java.util.List;

import com.wf.df.sdr.dto.MessageStatusCheck;


// TODO: Auto-generated Javadoc
/**
 * The Class NrReportGenerationRequest.
 */
public class NrReportGenerationRequest extends ReportGenerationRequest{
	
	/** The msg list. */
	List<MessageStatusCheck> msgList;

	/**
	 * Instantiates a new nr report generation request.
	 *
	 * @param messageType the message type
	 * @param assetClass the asset class
	 * @param sdrRepository the sdr repository
	 * @param msgList the msg list
	 */
	public NrReportGenerationRequest(String messageType, String assetClass,String sdrRepository,List<MessageStatusCheck> msgList) {
		super(messageType, assetClass, sdrRepository);
		this.msgList=msgList;
	}


	/**
	 * Gets the msg list.
	 *
	 * @return the msg list
	 */
	public List<MessageStatusCheck> getMsgList() {
		return msgList;
	}

	

	
	
}
