package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.MsgNotEligibleDao;
import com.wf.df.sdr.dto.MsgNotEligible;
import com.wf.df.sdr.exception.dao.MsgNotEligibleDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface MsgNotEligibleDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(MsgNotEligible dto);

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria ''.
	 */
	public List<MsgNotEligible> findAll() throws MsgNotEligibleDaoException;

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'send_id = :sendId'.
	 */
	public List<MsgNotEligible> findWhereSendIdEquals(BigDecimal sendId) throws MsgNotEligibleDaoException;

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MsgNotEligible> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgNotEligibleDaoException;

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'rule_code = :ruleCode'.
	 */
	public List<MsgNotEligible> findWhereRuleCodeEquals(String ruleCode) throws MsgNotEligibleDaoException;

	/** 
	 * Returns all rows from the msg_not_eligible table that match the criteria 'rule_desc = :ruleDesc'.
	 */
	public List<MsgNotEligible> findWhereRuleDescEquals(String ruleDesc) throws MsgNotEligibleDaoException;

}
