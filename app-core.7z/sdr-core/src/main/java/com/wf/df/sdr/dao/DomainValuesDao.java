package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.DomainValuesDao;
import com.wf.df.sdr.dto.DomainValues;
import com.wf.df.sdr.exception.dao.DomainValuesDaoException;

import java.util.Date;
import java.util.List;

public interface DomainValuesDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(DomainValues dto);

	/** 
	 * Returns all rows from the domain_values table that match the criteria ''.
	 */
	public List<DomainValues> findAll() throws DomainValuesDaoException;

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'domain = :domain'.
	 */
	public List<DomainValues> findWhereDomainEquals(String domain) throws DomainValuesDaoException;

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'dtcc_code = :dtccCode'.
	 */
	public List<DomainValues> findWhereDtccCodeEquals(String dtccCode) throws DomainValuesDaoException;

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'dtcc_desc = :dtccDesc'.
	 */
	public List<DomainValues> findWhereDtccDescEquals(String dtccDesc) throws DomainValuesDaoException;

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'src_code = :srcCode'.
	 */
	public List<DomainValues> findWhereSrcCodeEquals(String srcCode) throws DomainValuesDaoException;

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'src_desc = :srcDesc'.
	 */
	public List<DomainValues> findWhereSrcDescEquals(String srcDesc) throws DomainValuesDaoException;

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<DomainValues> findWhereCreateDatetimeEquals(Date createDatetime) throws DomainValuesDaoException;

}
