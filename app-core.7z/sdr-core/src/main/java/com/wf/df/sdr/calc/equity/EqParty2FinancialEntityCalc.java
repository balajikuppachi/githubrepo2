package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class EqParty2FinancialEntityCalc {

	@Calculation(value = Calc.eqParty2FinancialEntityCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.Df_ETEU_EndUserType_Cp, isInternal = true) String endUserTypeCp)	{
		
		if("Financial Entity".equalsIgnoreCase(endUserTypeCp))
			return Constants.TRUE;
		
		if("Non-Financial Entity".equalsIgnoreCase(endUserTypeCp))
			return Constants.FALSE;
		
		return Constants.EMPTY_STRING;
	
	}
	
}
