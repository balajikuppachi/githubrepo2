package com.wf.df.sdr.message;


public class EODBufferUpdateRequest {
	private String usi;
	private String msgType;
	private String sdrRepository;
	private String assetClass;
	
	public EODBufferUpdateRequest(String usi,String assetClass, String msgType, String sdrRepository) {
		
		this.usi = usi;
		this.msgType = msgType;
		this.sdrRepository = sdrRepository;
		this.assetClass = assetClass;
	}
	

	public String getUsi() {
		return usi;
	}
	
	public String getMsgType() {
		return msgType;
	}
	public String getSdrRepository() {
		return sdrRepository;
	}


	public String getAssetClass() {
		return assetClass;
	}

	
}
