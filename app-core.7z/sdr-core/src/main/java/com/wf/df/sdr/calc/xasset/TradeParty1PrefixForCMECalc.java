package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Utils;

/**
 * 
 * @author u250429
 * 
 */

@Component
public class TradeParty1PrefixForCMECalc {

	@Calculation(value = Calc.tradeParty1PrefixForCMECalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.wfParticipantIdPrefixCalc, isInternal = true) String wellsPrefix,
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass) {

		if (!Utils.IsNullOrBlank(wellsPrefix))
			return wellsPrefix;

		return wellsPrefix;

	}

}
