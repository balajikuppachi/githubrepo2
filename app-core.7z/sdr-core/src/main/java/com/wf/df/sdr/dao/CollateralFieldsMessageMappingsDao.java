package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.DtccFieldsMessageMappings;
import com.wf.df.sdr.exception.dao.CollFieldsMessageMappingsDaoException;

public interface CollateralFieldsMessageMappingsDao
{

	/** 
	 * Returns all rows from the coll_fields_message_mappings table that match the criteria ''.
	 */
	public List<DtccFieldsMessageMappings> findAll() throws CollFieldsMessageMappingsDaoException;

	public List<DtccFieldsMessageMappings> findFieldsInCSVSeq() throws CollFieldsMessageMappingsDaoException;
	
}

