package com.wf.df.sdr.util;

import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public class ErrorMessages {
	
	private static final String MSG_BUNDLE_RESOURCE_NAME = "/error-messages-bundle.properties";
	
	static ResourceBundle resourceBundle;
	
	static {
		try {
			resourceBundle = new PropertyResourceBundle(ErrorMessages.class.getResourceAsStream(MSG_BUNDLE_RESOURCE_NAME));
		} catch (Throwable e) {
			throw new RuntimeException("Couldn't load " + MSG_BUNDLE_RESOURCE_NAME, e);
		}
	}
	
	public static String getMessage(String key, Object... args) {
		
	
		return String.format(resourceBundle.getString(key), args);
	}
}
