package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.MappingTradeLeiNrDao;
import com.wf.df.sdr.dto.MappingTradeLeiNr;
import com.wf.df.sdr.exception.dao.MappingTradeLeiNrDaoException;

public class MappingTradeLeiNrDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MappingTradeLeiNr>, MappingTradeLeiNrDao {

	/** The jdbc template. */
	protected SimpleJdbcTemplate jdbcTemplate;

	/** The data source. */
	protected DataSource dataSource;
	
	/** The logger. */
	Logger logger = Logger.getLogger(this.getClass());

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	public MappingTradeLeiNr mapRow(ResultSet rs, int row)	throws SQLException {
		MappingTradeLeiNr dto=new MappingTradeLeiNr();
		dto.setSource(rs.getString(1));
		dto.setTradeId(rs.getString(2));
		dto.setUsiCurrent(rs.getString(3));
		dto.setCptyShortName(rs.getString(4));
		dto.setCurrentLei(rs.getString(5));
		dto.setBusinessAccountId(rs.getString(6));
		dto.setNewLei(rs.getString(7));
		dto.setLeiUpdateFlag(rs.getInt(8));
		dto.setCreateDate(rs.getDate(9));
		dto.setUpdateDate(rs.getDate(10));
		dto.setSendId(rs.getBigDecimal(11));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "mapping_trade_lei_nr";
	}
	
	@Transactional
	public void insert(MappingTradeLeiNr dto) {
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag, create_date_time, update_date_time,send_id) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?,?, ?,?)",dto.getSource(),dto.getTradeId(),dto.getUsiCurrent(),dto.getCptyShortName(),dto.getCurrentLei(),dto.getBusinessAccountId(),dto.getNewLei(),dto.getLeiUpdateFlag(),dto.getCreateDate(),dto.getUpdateDate(),dto.getSendId());
		
	}
	
	@Transactional
	public void updateCurrentLei(MappingTradeLeiNr dto) {
		// TODO Auto-generated method stub
		
		jdbcTemplate.update("UPDATE " + getTableName() + " SET current_lei=?,lei_update_flag=?,update_date_time=?,send_id=?,new_lei=null WHERE trade_id=? AND usi=? AND alternate_id=?",dto.getCurrentLei(),dto.getLeiUpdateFlag(),dto.getUpdateDate(),dto.getSendId(),dto.getTradeId(),dto.getUsiCurrent(),dto.getBusinessAccountId());
	}
	
	/**
	 * Method to insert new record. If a record already exists, update the existing one
	 * @param dto
	 */
	@Transactional
	public void saveOrUpdateTradesMapping(MappingTradeLeiNr dto) {
		logger.debug("Called saveOrUpdateTradesMapping");
		List<MappingTradeLeiNr> usiList;
	
		usiList = findWhereTradeidAndUsiAndBusActidEquals(dto.getTradeId(), dto.getUsiCurrent(),dto.getBusinessAccountId());
			if (usiList == null || usiList.size() == 0 || usiList.get(0) == null) {
				// add new record for usi
				logger.debug("SaveOrUpdateTradesMapping: New record found, inserting to table");
				insert(dto);
			} else {
				
				logger.debug("SaveOrUpdateTradesMapping: Old record found, updating table");
				// update the existing row for usi
				updateCurrentLei(dto);
			}
	}
	
	/**
	 * Find where tradeid and usi and bus actid equals.
	 *
	 * @param tradeId the trade id
	 * @param usiCurrent the usi current
	 * @param businessAccountId the business account id
	 * @return the list
	 */
	@Transactional
	public List<MappingTradeLeiNr> findWhereTradeidAndUsiAndBusActidEquals(String tradeId, String usiCurrent, String businessAccountId) {
		logger.debug("Called findWhereTradeidAndUsiAndBusActidEquals with tradeid->"+tradeId+", usi->"+usiCurrent+", Busactid->"+businessAccountId);
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE trade_id = ? AND usi=? AND alternate_id=?", this,tradeId,usiCurrent,businessAccountId);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findAll() throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereSrcSystemEquals(String srcSystem) throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE src_system = ? ORDER BY src_system", this,srcSystem);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereTradeIDEquals(String tradeId) throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE trade_id = ? ORDER BY trade_id", this,tradeId);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereUsiEquals(String usi) throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereCptyShortnameEquals(String cptySname) throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE cpty_shortname = ? ORDER BY cpty_shortname", this,cptySname);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereCurrentLeiEquals(String cueLei)	throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE current_lei = ? ORDER BY current_lei", this,cueLei);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereAlternateIDEquals(String busacctid)	throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE alternate_id = ? ORDER BY alternate_id", this,busacctid);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereNewLeiEquals(String newLei)	throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE new_lei = ? ORDER BY new_lei", this,newLei);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereCreateDateTimeEquals(Date datetime)
			throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE create_date_time = ? ORDER BY create_date_time", this,datetime);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<MappingTradeLeiNr> findWhereUpdateDateTimeEquals(Date datetime)
			throws MappingTradeLeiNrDaoException {
		try {
			return jdbcTemplate.query("SELECT src_system , trade_id , usi , cpty_shortname, current_lei , alternate_id , new_lei ,lei_update_flag,create_date_time, update_date_time,send_id FROM " + getTableName() + " WHERE update_date_time = ? ORDER BY update_date_time", this,datetime);
		}
		catch (Exception e) {
			throw new MappingTradeLeiNrDaoException("Query failed", e);
		}
	}

	@Transactional
	public void updateNewLeiToCurrentLei(MappingTradeLeiNr dto) {
		
		logger.debug("updateNewLeiToCurrentLeiNr: updating current_lei with new_lei");
		String query="UPDATE mapping_trade_lei_nr SET current_lei=? WHERE trade_id=? and send_id=?";
		
		jdbcTemplate.update(query,dto.getNewLei(),dto.getTradeId(),dto.getSendId());
		
		
	}

	@Transactional
	public void updateUsiForSendId(String tradeId, String newUsi) 
	{
		String query = "UPDATE  "+getTableName()+" SET usi = ? WHERE trade_id = ?";
		jdbcTemplate.update(query, newUsi, tradeId) ;
		
	}


}
