package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.EndurValuationStoreDao;
import com.wf.df.sdr.dto.EndurValuationStore;
import com.wf.df.sdr.exception.dao.EndurValuationStoreDaoException;

public class EndurValuationStoreDaoImpl extends AbstractDAO implements ParameterizedRowMapper<EndurValuationStore>, EndurValuationStoreDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(EndurValuationStore dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, buffer_id, valuation_type, valuation_date, create_datetime ) VALUES ( ?, ?, ?, ?, ? )",
				dto.getSendId(), dto.getBufferId(), dto.getValuationType(), dto.getValuationDate(), dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return EndurValuationStore
	 */
	public EndurValuationStore mapRow(ResultSet rs, int row) throws SQLException
	{
		EndurValuationStore dto = new EndurValuationStore();
		dto.setSendId( rs.getBigDecimal(1) );
		dto.setBufferId( rs.getBigDecimal(2) );
		dto.setValuationType( rs.getString( 3 ) );
		dto.setValuationDate( rs.getString( 4 ) );
		dto.setCreateDatetime( rs.getTimestamp( 5 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "endur_valuation_store";
	}

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria ''.
	 */
	@Transactional
	public List<EndurValuationStore> findAll() throws EndurValuationStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, buffer_id, valuation_type, valuation_date, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new EndurValuationStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<EndurValuationStore> findWhereSendIdEquals(BigDecimal sendId) throws EndurValuationStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, buffer_id, valuation_type, valuation_date, create_datetime FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new EndurValuationStoreDaoException("Query failed", e);
		}
		
	}
	
	
	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'buffer_id = :bufferId'.
	 */
	@Transactional
	public List<EndurValuationStore> findWhereBufferIdEquals(BigDecimal bufferId) throws EndurValuationStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, buffer_id, valuation_type, valuation_date, create_datetime FROM " + getTableName() + " WHERE buffer_id = ? ORDER BY buffer_id", this,bufferId);
		}
		catch (Exception e) {
			throw new EndurValuationStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'valuation_type = :valuationType'.
	 */
	@Transactional
	public List<EndurValuationStore> findWhereValuationTypeEquals(String valuationType) throws EndurValuationStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, buffer_id, valuation_type, valuation_date, create_datetime FROM " + getTableName() + " WHERE valuation_type = ? ORDER BY valuation_type", this,valuationType);
		}
		catch (Exception e) {
			throw new EndurValuationStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'valuation_date = :valuationDate'.
	 */
	@Transactional
	public List<EndurValuationStore> findWhereValuationDateEquals(String valuationDate) throws EndurValuationStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, buffer_id, valuation_type, valuation_date, create_datetime FROM " + getTableName() + " WHERE valuation_date = ? ORDER BY valuation_date", this,valuationDate);
		}
		catch (Exception e) {
			throw new EndurValuationStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_valuation_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<EndurValuationStore> findWhereCreateDatetimeEquals(Date createDatetime) throws EndurValuationStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, buffer_id, valuation_type, valuation_date, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new EndurValuationStoreDaoException("Query failed", e);
		}
		
	}

}
