package com.wf.df.sdr.message;

public class EquityEODReportGenerationRequest {

	private String templateName;
	
	private String msgType;
	
	private String sdrRepository;

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	
	public EquityEODReportGenerationRequest(String templateName, String msgType) {
		this.templateName = templateName;
		this.msgType = msgType;
	}
	
	public EquityEODReportGenerationRequest(String templateName, String msgType, String sdrRepository) {
		this.templateName = templateName;
		this.msgType = msgType;
		this.sdrRepository = sdrRepository;
	}

	public String getTemplateName() {
		return templateName;
	}
	
	public String getRepository() {
		return sdrRepository;
	}

	public void setRepository(String sdrRepository) {
		this.sdrRepository = sdrRepository;
	}
	
}
