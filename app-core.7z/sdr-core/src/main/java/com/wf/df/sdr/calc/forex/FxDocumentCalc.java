package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxDocumentCalc {
	@Calculation(value = Calc.fxDocumentCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.documentCalc, isInternal = true) String document) {
		return document;
	}
}