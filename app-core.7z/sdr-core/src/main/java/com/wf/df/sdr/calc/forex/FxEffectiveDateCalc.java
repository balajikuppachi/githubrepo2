package com.wf.df.sdr.calc.forex;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;



@Component
public class FxEffectiveDateCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value=Calc.fxEffectiveDateCalc)
	public String compute(
						@DerivedFrom("Date") String date) 
	{
			if(!Utils.IsNullOrBlank(date))
				try {
					return formatter.formatDateUTC(parser.parseDate(date));
				} catch (ParseException e) {
					logger.error("Error in FxEffectiveDateCalc: "+e.getMessage());
					throw new CalculationException("DateNotParsed", "Date string " + date	+ " could not be parsed" + Constants.ERROR_MSG_SEPARATOR+e.getMessage());
				}
			
			return Constants.EMPTY_STRING;
				
	}
}
