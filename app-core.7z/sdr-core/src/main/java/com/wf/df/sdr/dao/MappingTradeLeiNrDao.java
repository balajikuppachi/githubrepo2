package com.wf.df.sdr.dao;

import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MappingTradeLeiNr;
import com.wf.df.sdr.exception.dao.MappingTradeLeiNrDaoException;

public interface MappingTradeLeiNrDao {


	/**
	 * Method 'insert'.
	 *
	 * @param dto the dto
	 */
	public void insert(MappingTradeLeiNr dto);
	

	/**
	 * Method 'updateLei'.
	 *
	 * @param dto the dto
	 */
	public void updateCurrentLei(MappingTradeLeiNr dto);

	
	/**
	 * Update new lei to current lei.
	 *
	 * @param MappingTradeLeiNr the trades lei mapping
	 * @return the int
	 */
	public void updateNewLeiToCurrentLei(MappingTradeLeiNr MappingTradeLeiNr);
	/**
	 * Save or update trades mapping.
	 *
	 * @param dto the dto
	 */
	public void saveOrUpdateTradesMapping(MappingTradeLeiNr dto);
		
	/** 
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria ''.
	 *
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findAll() throws MappingTradeLeiNrDaoException;

	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'src_system = :src_system'.
	 *
	 * @param srcSystem the src system
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereSrcSystemEquals(String srcSystem) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'trade_id = :trade_id'.
	 *
	 * @param tradeId the trade id
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereTradeIDEquals(String tradeId) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'usi = :usi'.
	 *
	 * @param usi the usi
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereUsiEquals(String usi) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'cpty_shortname = :cpty_shortname'.
	 *
	 * @param cptySname the cpty sname
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereCptyShortnameEquals(String cptySname) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'current_lei = :current_lei'.
	 *
	 * @param cueLei the cue lei
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereCurrentLeiEquals(String cueLei) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'alternate_id = :alternate_id'.
	 *
	 * @param busacctid the busacctid
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereAlternateIDEquals(String busacctid) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'new_lei = :new_lei'.
	 *
	 * @param newLei the new lei
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereNewLeiEquals(String newLei) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'create_date_time = :create_date_time'.
	 *
	 * @param datetime the datetime
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereCreateDateTimeEquals(Date datetime) throws MappingTradeLeiNrDaoException;
	
	/**
	 * Returns all rows from the mapping_trade_lei_nr table that match the criteria 'update_date_time = :update_date_time'.
	 *
	 * @param datetime the datetime
	 * @return the list
	 * @throws MappingTradeLeiNrDaoException the trades lei mapping dao exception
	 */
	public List<MappingTradeLeiNr> findWhereUpdateDateTimeEquals(Date datetime) throws MappingTradeLeiNrDaoException;


	public void updateUsiForSendId(String string, String usi);
	
	



}
