package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.BufferStoreDao;
import com.wf.df.sdr.dto.BufferStore;
import com.wf.df.sdr.exception.dao.BufferStoreDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface BufferStoreDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(BufferStore dto);

	/** 
	 * Returns all rows from the buffer_store table that match the criteria ''.
	 */
	public List<BufferStore> findAll() throws BufferStoreDaoException;

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'buffer_id = :bufferId'.
	 */
	public List<BufferStore> findWhereBufferIdEquals(BigDecimal bufferId) throws BufferStoreDaoException;

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'buffer_data = :bufferData'.
	 */
	public List<BufferStore> findWhereBufferDataEquals(String bufferData) throws BufferStoreDaoException;

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'buffer_src = :bufferSrc'.
	 */
	public List<BufferStore> findWhereBufferSrcEquals(String bufferSrc) throws BufferStoreDaoException;

	/** 
	 * Returns all rows from the buffer_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<BufferStore> findWhereCreateDatetimeEquals(Date createDatetime) throws BufferStoreDaoException;
	
	public List<BufferStore> findBufferForFeeTrade(String tradeId, String marketType) throws BufferStoreDaoException;

}
