package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EqFloatingAmountPayerValueCalc {

	@Calculation(value = Calc.eqFloatingAmountPayerValueCalc, isPrototype = false)
	public String valuationDate(
			@DerivedFrom(value = Calc.eqIsWFBuyerCalc, isInternal = true) Boolean isWFBuyer,
			@DerivedFrom(value = Calc.eqUnderlyngAssetCptyParticipantIdCalc, isInternal = true) String cpty,
			@DerivedFrom(value = Calc.eqUnderlyngAssetWFParticipantIdCalc, isInternal = true) String us) {

		if(isWFBuyer)
			return us; //if WF is buyer, then wf is floating amount payer
		else
			return cpty;
		
	}
	
}
