package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MsgStatus;
import com.wf.df.sdr.exception.dao.MsgStatusDaoException;

public interface MsgStatusDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(MsgStatus dto);

	/** 
	 * Returns all rows from the msg_status table that match the criteria ''.
	 */
	public List<MsgStatus> findAll() throws MsgStatusDaoException;

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'send_id = :sendId'.
	 */
	public List<MsgStatus> findWhereSendIdEquals(BigDecimal sendId) throws MsgStatusDaoException;

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'msg_type = :msgType'.
	 */
	public List<MsgStatus> findWhereMsgTypeEquals(String msgType) throws MsgStatusDaoException;

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MsgStatus> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgStatusDaoException;

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'msg_timestamp = :msgTimestamp'.
	 */
	public List<MsgStatus> findWhereMsgTimestampEquals(Date msgTimestamp) throws MsgStatusDaoException;

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'status = :status'.
	 */
	public List<MsgStatus> findWhereStatusEquals(String status) throws MsgStatusDaoException;

	/** 
	 * Returns all rows from the msg_status table that match the criteria 'asset_class = :assetClass'.
	 */
	public List<MsgStatus> findWhereAssetClassEquals(String assetClass) throws MsgStatusDaoException;
	
	/** 
	 * Returns all rows from the msg_status table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<MsgStatus> findWhereSdrRepositoryEquals(String sdrRepository) throws MsgStatusDaoException;

}
