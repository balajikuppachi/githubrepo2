package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxCptyParticipantIdCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxCptyParticipantIdCalc, isPrototype=false)
	public String counterParty(
			@DerivedFrom(value = Calc.cptyParticipantIdCalc, isInternal = true) String cpty) {
		return cpty;
	}
}
