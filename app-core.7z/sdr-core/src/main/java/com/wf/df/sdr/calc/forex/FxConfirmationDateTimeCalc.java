package com.wf.df.sdr.calc.forex;

import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class FxConfirmationDateTimeCalc {

	@Autowired
	ParserService parser;

	@Autowired
	FormatterService formatter;

	@Calculation(value = Calc.fxConfirmationDateTimeCalc, isPrototype=false)
	public String calculate(
			@DerivedFrom(value = Constants.CONFIRM_DATETIME, isInternal = true) Date confDateTime,
			@DerivedFrom(value = Calc.isSwapswireTradeCalc, isInternal = true) Boolean isECNTrade,
			@DerivedFrom(value = Stv.CounterpartyAffirmedTimestamp, isInternal = true) String counterpartyAffirmedTimestamp,
			@DerivedFrom(value=Calc.intragroupCalc, isInternal=true) String intraGroup) {

		if(Constants.TRUE.equalsIgnoreCase(intraGroup))
			return Constants.EMPTY_STRING;
		
		if(confDateTime != null){
			return formatter.formatDateTimeUTC(confDateTime);
		}else if(isECNTrade){
			try {
				return formatter.formatDateTimeUTC(parser.parseDate(counterpartyAffirmedTimestamp));
			} catch (ParseException e) {
				throw new CalculationException("DateNotParsed", "Date string " + counterpartyAffirmedTimestamp	+ " could not be parsed" + Constants.ERROR_MSG_SEPARATOR+ e.getMessage());

			}
		}

		return null;

	}

}
