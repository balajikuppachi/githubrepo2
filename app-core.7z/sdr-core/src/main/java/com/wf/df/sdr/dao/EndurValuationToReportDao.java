package com.wf.df.sdr.dao;

import com.wf.df.sdr.dto.EndurValuationToReport;

public interface EndurValuationToReportDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(EndurValuationToReport dto);
	
}
