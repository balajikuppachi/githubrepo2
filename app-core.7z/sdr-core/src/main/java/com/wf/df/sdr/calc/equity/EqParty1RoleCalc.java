package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;

@Component
public class EqParty1RoleCalc {

	@Calculation(value = Calc.eqParty1RoleCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.Df_ETSD_equityderivatives_Us, isInternal = true) String etsdEquityderivativesUs,
			@DerivedFrom(value = Stv.Df_ETMSP_equityderivatives_Us, isInternal = true) String etmspEquityderivativesUs)	{
		
		if("Y".equalsIgnoreCase(etsdEquityderivativesUs))
			return "SD";
		
		if("Y".equalsIgnoreCase(etmspEquityderivativesUs))
			return "MSP";
		
		return "non-SD/MSP";
	
	}
	
}
