package com.wf.df.sdr.message;


public class ResponseUnitOfWork {
	private String assetClass;
	private String sendId;
	private String recvId;
	private String msgType;
	private String usi;
	private String reportingParty;
	private String recvMsgBuffer;
	private String responseStatus;
	private String errorCode;
	private String upi;
	private String tradeId;
	private String tradePartyReference;
	private String action;
	private String tradeDate;
	private String maturityDate;
	private String executionDatetime;
	private String submitter;
	private String tradeParty1;
	private String tradeParty2;
	private String notionalAmount;
	private String notionalCurrency;
	private String submissionDatetime;
	
	public String getTradePartyReference() {
		return tradePartyReference;
	}
	public String getAction() {
		return action;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public String getMaturityDate() {
		return maturityDate;
	}
	public String getExecutionDatetime() {
		return executionDatetime;
	}
	public String getSubmitter() {
		return submitter;
	}
	public String getTradeParty1() {
		return tradeParty1;
	}
	public String getTradeParty2() {
		return tradeParty2;
	}
	public String getNotionalAmount() {
		return notionalAmount;
	}
	public String getNotionalCurrency() {
		return notionalCurrency;
	}
	public String getSubmissionDatetime() {
		return submissionDatetime;
	}
	public void setTradePartyReference(String tradePartyReference) {
		this.tradePartyReference = tradePartyReference;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}
	public void setExecutionDatetime(String executionDatetime) {
		this.executionDatetime = executionDatetime;
	}
	public void setSubmitter(String submitter) {
		this.submitter = submitter;
	}
	public void setTradeParty1(String tradeParty1) {
		this.tradeParty1 = tradeParty1;
	}
	public void setTradeParty2(String tradeParty2) {
		this.tradeParty2 = tradeParty2;
	}
	public void setNotionalAmount(String notionalAmount) {
		this.notionalAmount = notionalAmount;
	}
	public void setNotionalCurrency(String notionalCurrency) {
		this.notionalCurrency = notionalCurrency;
	}
	public void setSubmissionDatetime(String submissionDatetime) {
		this.submissionDatetime = submissionDatetime;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public String getSendId() {
		return sendId;
	}
	public String getRecvId() {
		return recvId;
	}
	public String getMsgType() {
		return msgType;
	}
	public String getUsi() {
		return usi;
	}
	public String getReportingParty() {
		return reportingParty;
	}
	public String getRecvMsgBuffer() {
		return recvMsgBuffer;
	}
	public String getResponseStatus() {
		return responseStatus;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public String getUpi() {
		return upi;
	}
	public String getTradeId() {
		return tradeId;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public void setSendId(String sendId) {
		this.sendId = sendId;
	}
	public void setRecvId(String recvId) {
		this.recvId = recvId;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public void setUsi(String usi) {
		this.usi = usi;
	}
	public void setReportingParty(String reportingParty) {
		this.reportingParty = reportingParty;
	}
	public void setRecvMsgBuffer(String recvMsgBuffer) {
		this.recvMsgBuffer = recvMsgBuffer;
	}
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public void setUpi(String upi) {
		this.upi = upi;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	
	
}
