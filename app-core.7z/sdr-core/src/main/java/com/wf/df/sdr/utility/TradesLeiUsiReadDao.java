package com.wf.df.sdr.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class TradesLeiUsiReadDao {
	
	private TradesLeiUsiReadDao() {
	
	}
	
	private static Connection prodConn=null; 
	private static PreparedStatement prodStmt; 
	private static String prodDbURL="jdbc:sybase:Tds:170.13.137.164:12000/sdruat";
	
	/**********************************Production Data Base Start**********************************************************/
	
	public static Connection createConnection() throws ClassNotFoundException, SQLException
	{
		if(prodConn==null)
		{
			Class.forName("com.sybase.jdbc3.jdbc.SybDriver");
			prodConn =DriverManager.getConnection(prodDbURL,"sdr_rw","sdruatrw1");
		
		}
		return prodConn;
	}
	
	public static void closeConn() throws SQLException 
	{
		
		if (prodStmt != null) 
			prodStmt.close();
		if (prodConn != null) {
			prodConn.close();
		}
}
	
	public static List<String> readBufferData(List<String> tempList) throws SQLException, ClassNotFoundException
	{
		String inClause=generateInClause(tempList);
		//String query="select b.buffer_data  from buffer_store b,input_msg_store i WHERE b.buffer_id = i.buffer_id AND i.send_id in (select  e.send_id from eod_buffer_store e where e.usi=i.usi) and i.src_trade_id "+tradeIDs;
		String query="SELECT b.buffer_data FROM buffer_store b, eod_buffer_store s, input_msg_store i WHERE s.send_id = i.send_id  AND s.usi = i.usi  AND datalength(s.msg_buffer) > 0  AND i.src_trade_status in ('TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','PENDING','CH_TOBE_VER')  AND msg_type = 'Snapshot' AND b.buffer_id = i.buffer_id and i.src_trade_id IN ("+ inClause +")";
		//String query="SELECT b.buffer_data FROM buffer_store b, eod_buffer_store s, input_msg_store i WHERE s.send_id = i.send_id  AND b.buffer_id = i.buffer_id  AND s.usi = i.usi  AND (s.msg_type = 'Snapshot' or  s.msg_type = 'Valuation')  AND datalength(s.msg_buffer) > 0    AND i.src_trade_id IN ("+ inClause +")";
		List<String> resultList=new ArrayList<String>();
	
		prodConn=createConnection();
		prodStmt=prodConn.prepareStatement(query);
		for (int i = 0; i < tempList.size(); i++) {
			prodStmt.setString(i+1, tempList.get(i));	
		}
		ResultSet result= prodStmt.executeQuery();
		result.setFetchSize(1000);
		while (result.next()) {
			resultList.add(result.getString(1));
		}
	
		return resultList;
	}
	
	public static List<String> readTradeID() throws SQLException
	{
		//String query="SELECT distinct i.src_trade_id FROM input_msg_store i , eod_buffer_store e , buffer_store b WHERE b.buffer_id = i.buffer_id AND i.send_id = e.send_id AND e.usi=i.usi";
		//String query="SELECT i.src_trade_id FROM buffer_store b, eod_buffer_store s, input_msg_store i WHERE s.send_id = i.send_id  AND s.usi = i.usi  AND datalength(s.msg_buffer) > 0  AND i.src_trade_status in ('TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','PENDING','CH_TOBE_VER')  AND msg_type = 'Snapshot' AND b.buffer_id = i.buffer_id";
		//String query="SELECT distinct i.src_trade_id FROM buffer_store b, eod_buffer_store s, input_msg_store i WHERE s.send_id = i.send_id  AND b.buffer_id = i.buffer_id  AND s.usi = i.usi  AND (s.msg_type = 'Snapshot' or  s.msg_type = 'Valuation')  AND datalength(s.msg_buffer) > 0";
		String query="select trade_id from mapping_trade_lei";
		List<String> resultList=new ArrayList<String>();
		prodStmt=prodConn.prepareStatement(query);
		ResultSet result= prodStmt.executeQuery();
		while (result.next()) {
			resultList.add(result.getString(1));
		}
	return resultList;
	}
	
	
	/**
	 * Generate in clause.
	 *
	 * @param lst the lst
	 * @return the string
	 */
	private static String generateInClause(List< ? extends Object> lst)
	{
		StringBuilder inClause = new StringBuilder();

		for (int i=0; i < lst.size(); i++) {
		  inClause.append('?');
		  if ( i!=lst.size()-1 ) {
		    inClause.append(',');
		  }
		}

		return inClause.toString();
	}
	/***************************************Production Data Base End*****************************************************/
	

}
