package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class CalypsoComputedUTICalc {

	@Calculation(value = Calc.calypsoComputedUTICalc, isPrototype = false)
	public String usi(
			@DerivedFrom(value=Calc.isEmirTradeCalc, isInternal = true) boolean isEmirTrade,
			@DerivedFrom(value=Stv.UTI_CURRENT, isInternal = true) String uti,
			@DerivedFrom(value=Stv.EMIR_REPORTING_PARTY, isInternal = true) String repParty,
			@DerivedFrom(value=Stv.LEI_CP, isInternal = true) String leiCP,
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String tradeID) {
		
		if (isEmirTrade && !Utils.IsNullOrBlank(leiCP) && leiCP.equalsIgnoreCase(repParty) && Utils.IsNullOrBlank(uti)){
			return generateUsi(tradeID);
		}
				
		return uti;
		
		
	}
	
	// The method generates an usi, if it's null/blank
		private String generateUsi(String srcTradeID) {
			String generatedUSI = "SDRGeneratedUTI_" + srcTradeID;		
			return generatedUSI;
		}
	
}
