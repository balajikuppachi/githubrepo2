package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.CollateralAgreementsDao;
import com.wf.df.sdr.dto.CollateralAgreements;
import com.wf.df.sdr.exception.dao.CollateralAgreementsDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class CollateralAgreementsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<CollateralAgreements>, CollateralAgreementsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(CollateralAgreements dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )",dto.getAgreementId(),dto.getAgreementType(),dto.getShortname(),dto.getMarginType(),dto.getMarketValue(),dto.getExtAgreementType(),dto.getCidLegal(),dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return CollateralAgreements
	 */
	public CollateralAgreements mapRow(ResultSet rs, int row) throws SQLException
	{
		CollateralAgreements dto = new CollateralAgreements();
		dto.setAgreementId( rs.getString( 1 ) );
		dto.setAgreementType( rs.getString( 2 ) );
		dto.setShortname( rs.getString( 3 ) );
		dto.setMarginType( rs.getString( 4 ) );
		dto.setMarketValue( rs.getBigDecimal(5));
		dto.setExtAgreementType( rs.getString( 6 ) );
		dto.setCidLegal( rs.getString(7) );
		if (rs.wasNull()) {
			dto.setCidLegal( null );
		}
		
		dto.setCreateDatetime( rs.getTimestamp(8 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "collateral_agreements";
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria ''.
	 */
	@Transactional
	public List<CollateralAgreements> findAll() throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'agreement_id = :agreementId'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereAgreementIdEquals(String agreementId) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE agreement_id = ? ORDER BY agreement_id", this,agreementId);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'agreement_type = :agreementType'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereAgreementTypeEquals(String agreementType) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE agreement_type = ? ORDER BY agreement_type", this,agreementType);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'shortname = :shortname'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereShortnameEquals(String shortname) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE shortname = ? ORDER BY shortname", this,shortname);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'margin_type = :marginType'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereMarginTypeEquals(String marginType) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE margin_type = ? ORDER BY margin_type", this,marginType);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'market_value = :marketValue'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereMarketValueEquals(BigDecimal marketValue) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE market_value = ? ORDER BY market_value", this,marketValue);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'ext_agreement_type = :extAgreementType'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereExtAgreementTypeEquals(String extAgreementType) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE ext_agreement_type = ? ORDER BY ext_agreement_type", this,extAgreementType);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'cid_legal = :cidLegal'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereCidLegalEquals(Integer cidLegal) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE cid_legal = ? ORDER BY cid_legal", this,cidLegal);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<CollateralAgreements> findWhereCreateDatetimeEquals(Date createDatetime) throws CollateralAgreementsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT agreement_id, agreement_type, shortname, margin_type, market_value, ext_agreement_type, cid_legal, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
		
	}

}
