package com.wf.df.sdr.message;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SkipHostNameVerifier implements HostnameVerifier {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	public boolean verify(String hostname, SSLSession session) {
		  logger.warn("**WARNING** Skipping Hostname Verification..");
	      return true;
	}

}
