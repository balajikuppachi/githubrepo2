package com.wf.df.sdr.calc.xasset;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.MsgToReportDao;
import com.wf.df.sdr.dto.MsgToReportStatus;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class IsTraderReviewEligibleCalc {

	private Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	MsgToReportDao msgToReportDao;
	
	@Calculation(value = Calc.isTraderReviewEligibleCalc, isPrototype = false)
	public Boolean isEligible(
			@DerivedFrom(value = Stv.CalypsoDocStatus, isInternal=true) String calypsoDocStatus,
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String tradeId,
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String tlcEvent,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType,
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass,
			@DerivedFrom(value = Calc.computedUSICalc, isInternal = true) String usi,
			@DerivedFrom(value = Constants.SEND_ID, isInternal = true) BigDecimal sendId,
			@DerivedFrom(value = Calc.sdrRepositoryCalc, isInternal = true) String sdrRepo){
		
		if(!Constants.TRADE_STATUS_TRADER_REVIEW.equals(calypsoDocStatus)) {
			//logger.info(sendId + " -> Received unexpected Status " + calypsoDocStatus);
			return false;
		}
		
		//No PET for Amendment
		if(!Utils.IsNullOrBlank(tlcEvent) && tlcEvent.equals(Constants.Amendment_Price_Forming)) { 
			if(Constants.MESSAGE_TYPE_RT.equalsIgnoreCase(msgType))
				return true;
			else {
				logger.info(sendId + " --> Amendment Ineligible.  " + msgType + "|" + tlcEvent + " | " + calypsoDocStatus);
				return false;
			}
		}
			
		List<MsgToReportStatus> msgToReportList = msgToReportDao.findExistingTradeWithStatus(tradeId, tlcEvent, msgType, assetClass, usi,sdrRepo);
		//True if we have already sent a message
		if (!Utils.IsListNullOrEmpty(msgToReportList)) 
			return true;
			
		logger.info(sendId + " --> Ineligible. No original message found " + msgType + "|" + tlcEvent + " | " + calypsoDocStatus);
		
		return false;
	}
	
}
