package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MappingUsiDtccusi;
import com.wf.df.sdr.exception.dao.MappingUsiDtccusiDaoException;

// TODO: Auto-generated Javadoc
/**
 * The Interface MappingUsiDtccusiDao.
 */
public interface MappingUsiDtccusiDao 
{

	/**
	 * Method 'insert'.
	 *
	 * @param dto the dto
	 */
	public void insert(MappingUsiDtccusi dto);

	/**
	 * Returns all rows from the mapping_usi_dtccusi table that match the criteria ''.
	 *
	 * @return the list
	 * @throws MappingUsiDtccusiDaoException the mapping usi dtccusi dao exception
	 */
	public List<MappingUsiDtccusi> findAll() throws MappingUsiDtccusiDaoException;

	/**
	 * Returns all rows from the mapping_usi_dtccusi table that match the criteria 'send_id = :sendId'.
	 *
	 * @param sendId the send id
	 * @return the list
	 * @throws MappingUsiDtccusiDaoException the mapping usi dtccusi dao exception
	 */
	public List<MappingUsiDtccusi> findWhereSendIdEquals(BigDecimal sendId) throws MappingUsiDtccusiDaoException;
	
	/**
	 * Returns all rows from the mapping_usi_dtccusi table that match the criteria 'usi = :usi'.
	 *
	 * @param usi the usi
	 * @return the list
	 * @throws MappingUsiDtccusiDaoException the mapping usi dtccusi dao exception
	 */
	public List<MappingUsiDtccusi> findWhereUsiEquals(String usi) throws MappingUsiDtccusiDaoException;

	/**
	 * Returns all rows from the mapping_usi_dtccusi table that match the criteria 'dtccUsi = :dtccUsi'.
	 *
	 * @param dtccUsi the dtcc usi
	 * @return the list
	 * @throws MappingUsiDtccusiDaoException the mapping usi dtccusi dao exception
	 */
	public List<MappingUsiDtccusi> findWhereDtccUsiEquals(String dtccUsi) throws MappingUsiDtccusiDaoException;

	/**
	 * Returns all rows from the mapping_usi_dtccusi table that match the criteria 'create_datetime = :createDatetime'.
	 *
	 * @param updateDatetime the update datetime
	 * @return the list
	 * @throws MappingUsiDtccusiDaoException the mapping usi dtccusi dao exception
	 */
	public List<MappingUsiDtccusi> findWhereUpdateDatetimeEquals(Date updateDatetime) throws MappingUsiDtccusiDaoException;
	
	/**
	 * Returns all rows from the mapping_usi_dtccusi table that match the criteria 'create_datetime = :createDatetime'.
	 *
	 * @param createDatetime the create datetime
	 * @return the list
	 * @throws MappingUsiDtccusiDaoException the mapping usi dtccusi dao exception
	 */
	public List<MappingUsiDtccusi> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingUsiDtccusiDaoException;

	
	/**
	 * Update dtcc usi for send id.
	 *
	 * @param sendId the send id
	 * @param dtccUsi the dtcc usi
	 */
	public void updateDtccUsiForSendId(BigDecimal sendId, String dtccUsi);

	/**
	 * Method to insert new record. If a record already exists, update the existing one
	 * @param dto
	 */
	public void saveOrUpdateMappingUsiDtccusi(MappingUsiDtccusi dto);


}
