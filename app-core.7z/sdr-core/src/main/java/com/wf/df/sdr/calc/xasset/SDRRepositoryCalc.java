package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class SDRRepositoryCalc 
{
	@Calculation(value=Calc.sdrRepositoryCalc, isPrototype=false)
	public String sdrRepositoryCalc(
			@DerivedFrom(value=Calc.isCMEReportableTradeCalc,isInternal=true )boolean isCmeReportable,
			@DerivedFrom(value=Calc.srcAssetClassCalc,isInternal=true )String srcAssetClass,
			@DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable,
			@DerivedFrom(value=Calc.isCadReportableCalc,isInternal = true) boolean isCadReportable)
	{
		
		
		if(Constants.ASSET_CLASS_COMMODITY.equals(srcAssetClass))
			return Constants.ICE;

		if(isCmeReportable)
			return Constants.CME;
		else if(isEmirReportable)
			return Constants.EMIR;
		else if(isCadReportable)
			return Constants.CAD;
		else
			return Constants.DTCC;
	}

}
