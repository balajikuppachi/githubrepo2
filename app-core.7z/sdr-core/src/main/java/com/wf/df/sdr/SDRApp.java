package com.wf.df.sdr;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.impl.StaticLoggerBinder;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;

public class SDRApp {
	
	FileOutputStream lockFileOutputStream;
//	FileLock fileLock;
	Logger logger = LoggerFactory.getLogger(Main.class);
	private ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext();
	
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:META-INF/com/wf/df/sdr/application-context.xml";

	void launchSDR() {
		try {
			try {
				init();
			} catch (Exception e) {
				logger.error("Could not initialize SDR application - shutting down", e);
				System.exit(1);
			}
			
			context.setConfigLocation(APPLICATION_CONTEXT_CONFIG_LOCATION);
			context.registerShutdownHook();
			try {
				context.refresh();
			} catch (Throwable e) {
				logger.error("Could not start application context - shutting down", e);
				System.exit(2);
			}
			
			Object lock = new Object();
			while (true) {
				synchronized (lock) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
					}
				}
			}
		} finally {
			if (lockFileOutputStream != null) {
				try {
					lockFileOutputStream.close();
				} catch (IOException e) {
					// ignore
				}
			}
			
//			if (fileLock != null) {
//				try {
//					fileLock.release();
//				} catch (IOException e) {
//					// ignore
//				}
//			}
		}
	}
	
	private void init() throws Exception {
		RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
		String name = runtime.getName();
		int index = name.indexOf("@");
		String processId = name.substring(0, index);
		
		String userDirPath = System.getProperty("user.dir");
		String sdrHomePath = System.getProperty("SDR_HOME");
		File sdrHome;
		if (sdrHomePath == null) {
			sdrHome = new File(userDirPath).getParentFile();
			sdrHomePath = sdrHome.getCanonicalPath();
			System.setProperty("SDR_HOME", sdrHomePath);
		} else {
			sdrHome = new File(sdrHomePath);
		}
		
		String logbackCfgFilePath = System.getProperty("logback.configurationFile");
		if (logbackCfgFilePath == null) {
			File logbackCfgFile = new File(new File(sdrHome, "config"), "logback.xml");
			if (logbackCfgFile.isFile()) {
				logbackCfgFilePath = logbackCfgFile.getCanonicalPath();
				System.setProperty("logback.configurationFile", logbackCfgFilePath);
				initializeLogback(logbackCfgFile);
			}
		}
		
		String tempDirPath = System.getProperty("java.io.tmpdir");
		String lockFileName = "start.pid";
		
		File lockFile = new File(new File(sdrHome, "bin"), lockFileName);
		
		lockFileOutputStream = new FileOutputStream(lockFile);
		FileChannel lockFileChannel = lockFileOutputStream.getChannel();
		
//		fileLock = lockFileChannel.tryLock(0, Long.MAX_VALUE, false);
//		if (fileLock == null) {
//			logger.error("Couldn't aquire a lock on " + lockFile.getAbsolutePath() + " - the application is already started (pid=" + processId + ")");
//			System.exit(4);
//		}
		
		lockFileChannel.write(ByteBuffer.wrap(processId.getBytes()));
		lockFileChannel.force(true);
		
		lockFile.deleteOnExit();
		
		logger.info("================= Starting SDR ===================");
		logger.info("PID=" + processId);
		logger.info("user.dir=" + userDirPath);
		logger.info("SDR_HOME=" + sdrHomePath);
		logger.info("java.io.tmpdir=" + tempDirPath);
		logger.info("logback.configurationFile=" + logbackCfgFilePath);
	}
	
	private void initializeLogback(File logbackCfgFile) {
		StaticLoggerBinder loggerBinder = StaticLoggerBinder.getSingleton();
		LoggerContext loggerContext = (LoggerContext) loggerBinder.getLoggerFactory();
		loggerContext.reset();
		JoranConfigurator configurator = new JoranConfigurator();
		configurator.setContext(loggerContext);
		try {
			configurator.doConfigure(logbackCfgFile);
		} catch (Exception e) {
			System.err.println("Couldn't configure logging (using " + logbackCfgFile.getAbsolutePath() + "):");
			e.printStackTrace(System.err);
			throw new RuntimeException("Couldn't configure logging", e);
		}
	}
}
