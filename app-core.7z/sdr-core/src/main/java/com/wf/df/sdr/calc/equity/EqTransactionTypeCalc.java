package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class EqTransactionTypeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	DTCCUtils dtccUtils;

	@Calculation(value = Calc.eqTransactionTypeCalc, isPrototype = false)
	public String transactionType(
			@DerivedFrom(value = Stv.LifecycleEvent, isInternal = true) String txnType,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType,
			@DerivedFrom(value = Calc.sendBackloadCalc, isInternal = true) boolean backload,
			@DerivedFrom(value = Stv.SDR_BACKLOAD, isInternal = true) String backloadkeyword) {
		
		if (backload) {			
			if(Constants.BACKLOAD_DEAD.equalsIgnoreCase(backloadkeyword))
				return Constants.Historical;			
			return Constants.Backload;
		} else if(Constants.MESSAGE_TYPE_SNAPSHOT.equals(msgType) || Constants.MESSAGE_TYPE_VALUATION.equals(msgType) ||Constants.MESSAGE_TYPE_SNAPSHOT_TO.equals(msgType)){
			return Constants.Trade;
		}
		
		if (txnType != null) {
			return dtccUtils.getEquityTransactionType(txnType);
		}
		return Constants.EMPTY_STRING;
	}
}