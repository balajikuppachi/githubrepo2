package com.wf.df.sdr.message;


public class ReportGenerationRequest {
	private String messageType;
	private String assetClass;
	private String sdrRepository;

	public ReportGenerationRequest(String messageType, String sdrRepository) {
		this.messageType = messageType;
		this.sdrRepository = sdrRepository;
	}
		
	public ReportGenerationRequest(String messageType, String assetClass,String sdrRepository) {
		this.messageType = messageType;
		this.assetClass = assetClass;
		this.sdrRepository = sdrRepository;
	}

	public String getMessageType() {
		return messageType;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public String getSdrRepository() {
		return sdrRepository;
	}
}
