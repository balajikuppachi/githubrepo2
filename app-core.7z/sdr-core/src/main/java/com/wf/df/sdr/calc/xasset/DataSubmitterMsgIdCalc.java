package com.wf.df.sdr.calc.xasset;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class DataSubmitterMsgIdCalc {
	
	@Calculation(value = Calc.dataSubmitterMsgIdCalc, isPrototype = false)
	public String calculate (@DerivedFrom(value=Constants.CONFIRM_DOCUMENT_ID, isInternal = true) String documentId,
			 @DerivedFrom(value = Constants.SEND_ID, isInternal = true) BigDecimal sendId) {

		// Appending SendId to all the PDF names, since 
		String docId = documentId + Constants.UNDERSCORE + sendId;
		return docId;
		
	}
}
