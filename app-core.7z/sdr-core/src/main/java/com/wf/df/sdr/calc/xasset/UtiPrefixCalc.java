package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class UtiPrefixCalc {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value =  Calc.utiPrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value=Calc.computedUSICalc) String uti){
		
				
		if(Utils.IsNullOrBlank(uti) || StringUtils.contains(uti, Constants.TEMP_UTI_PREFIX)){
			
			return Constants.EMPTY_STRING;
			
		}
					
		return uti.substring(0,10);
	}

}
