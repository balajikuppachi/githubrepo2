package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxReportingPartyCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxReportingPartyCalc, isPrototype = false)
	public boolean isReportingPartyValid(
			@DerivedFrom(value = Calc.reportingPartyCalc, isInternal = true) boolean reportingParty) {
		return reportingParty;
	}
}
