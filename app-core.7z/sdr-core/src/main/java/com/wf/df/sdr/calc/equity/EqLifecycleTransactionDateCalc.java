package com.wf.df.sdr.calc.equity;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class EqLifecycleTransactionDateCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Autowired
	DTCCUtils dtccUtil;
	
	@Calculation(value = Calc.eqLifecycleTransactionDateCalc, isPrototype=false)
	public String calculate(
			@DerivedFrom(value = Stv.TradeDate, isInternal = true) String tradeDate,
			@DerivedFrom(value = Stv.LifecycleEvent, isInternal = true) String lifecycleEvent,
			@DerivedFrom(value = Stv.TerminationTradeDate, isInternal = true) String terminationTradeDate,
			@DerivedFrom(value = Stv.AmendmentTradeDate, isInternal = true) String amendmentTradeDate,
			@DerivedFrom(value = Stv.NovationTradeDate, isInternal = true) String novationTradeDate) {
		
		String transType = dtccUtil.getEquityTransactionType(lifecycleEvent);
		
		String date = null;
		
		if(Constants.Amendment.equals(transType) || Constants.Increase.equals(transType) || Constants.CorporateAction.equals(transType)){
			date = 	amendmentTradeDate;	
		} else if(Constants.Novation.equals(transType)){
			date = 	novationTradeDate;	
		} else if(Constants.Termination.equals(transType)){
			date = 	terminationTradeDate;		
		} // else date = tradeDate;
				
		if(date != null){
			
			try {
				return formatter.formatDateUTC(parser.parseDate(tradeDate));
			} catch (ParseException e) {
				logger.error("Error in lifecycleDateCalc: "+e.getMessage());
				throw new CalculationException("DateNotParsed", "Date string " + date	+ " could not be parsed" + Constants.ERROR_MSG_SEPARATOR+e.getMessage());		
			}
			
		}
				
		return Constants.EMPTY_STRING;
		
	}
	
}
