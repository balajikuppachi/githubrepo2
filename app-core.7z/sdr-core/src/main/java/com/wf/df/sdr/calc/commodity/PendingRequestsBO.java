package com.wf.df.sdr.calc.commodity;

import java.util.List;

/**
 * @author u250429
 *
 */
public class PendingRequestsBO {
	
	private List<EConfirmTradeUpdateBO> eConfirmList;

	public List<EConfirmTradeUpdateBO> geteConfirmList() {
		return eConfirmList;
	}

	public void seteConfirmList(List<EConfirmTradeUpdateBO> eConfirmList) {
		this.eConfirmList = eConfirmList;
	}

	
	
}
