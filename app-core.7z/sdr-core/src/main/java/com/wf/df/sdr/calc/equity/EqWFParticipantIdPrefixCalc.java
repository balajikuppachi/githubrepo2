package com.wf.df.sdr.calc.equity;


import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqWFParticipantIdPrefixCalc {
	
	@Value("${equity.mode.qa}") String equityInQA;
	@Value("${party1.id.Equity}") String party1Id;
	@Value("${eq.hardcode.cici}") String eqHardcodeCICI;
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value= Calc.eqWFParticipantIdPrefixCalc, isPrototype = false)
	public String wFPartyCalc(
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String leiUs)	{
		
		//For Qa
		if (!Utils.IsNullOrBlank(party1Id)) {
			return party1Id.substring(0, 4);
		}
		
		if (!Utils.IsNullOrNone(leiUs)) {
			//Temporary fix, until galaxy start sending CICI value instead of LEI			
			if("true".equalsIgnoreCase(eqHardcodeCICI))			
				return "CICI";
			return(StringUtils.substringBefore(leiUs, Constants.COLON)).toUpperCase();
		}
		throw new CalculationException("LEIFNF", "Fields not defined : [" + Stv.LEI_US + "]");
	}			
}
