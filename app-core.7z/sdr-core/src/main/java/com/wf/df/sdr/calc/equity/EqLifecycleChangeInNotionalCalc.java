package com.wf.df.sdr.calc.equity;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.TradeAttributesDao;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;


@Component
public class EqLifecycleChangeInNotionalCalc {

	@Autowired
	ParserService parser;	
	@Autowired
	FormatterService formatter;
	@Autowired
	TradeAttributesDao dao;
	
	
	@Calculation(value = Calc.eqLifecycleChangeInNotionalCalc, isPrototype = false)
	public String notional(
			@DerivedFrom(value = Stv.EquityNotionalAmount, isInternal = true) String equityNotional,
			@DerivedFrom(value = Stv.VegaNotionalAmount, isInternal = true) String vegaNotional,
			@DerivedFrom(value = Stv.EquityBasketNotionalAmountList, isInternal = true) List<String> equityBasketNotionalAmountList,
			@DerivedFrom(value = Calc.eqComputedUSICalc, isInternal = true) String usi,
			@DerivedFrom(value = Stv.UnderlyngAssetIdentifierTypeList, isInternal = true) List<String> typelist,
			@DerivedFrom(value = Calc.templateCalc, isInternal = true) String templateName){	
			
		if(Utils.IsNullOrBlank(equityNotional) && Utils.IsNullOrBlank(vegaNotional))
			return Constants.EMPTY_STRING;
		
		String notional = null;
				
		
		if(Constants.EqTemplate_ES_PSA_CFD.equals(templateName)){
			if(usi != null) {
				
				ArrayList<String> array = new ArrayList<String>();
				if (!Utils.IsListNullOrEmpty(equityBasketNotionalAmountList)) {
					for (int i = 0; i < equityBasketNotionalAmountList.size(); i++) {
						notional = formatter.parseAndFormatNumber(equityBasketNotionalAmountList.get(i));												
						array.add(notional);
					}
				}
				return Utils.convertListToDelimitedString(array, Constants.SEMICOLON);
							
				//notional = getChangeInNotional(equityNotional, usi);
				//return repeatPerUnderlyingAsset(notional, typelist);
			}
		}
				
		
		if(Constants.EqTemplate_VS.equals(templateName))
			notional = vegaNotional;
		else
			notional = equityNotional;
		
		return formatter.parseAndFormatNumber(notional);
		//return repeatPerUnderlyingAsset(notional, typelist);
						
				
	}
	
	private String repeatPerUnderlyingAsset(String notional, List<String> typelist){
	
		ArrayList<String> array = new ArrayList<String>();
		if (!Utils.IsListNullOrEmpty(typelist)) {
			for (int i = 0; i < typelist.size(); i++) {
				array.add(notional);
			}
		}
		return Utils.convertListToDelimitedString(array, Constants.SEMICOLON);
		
		
	}
	
	
	
}
