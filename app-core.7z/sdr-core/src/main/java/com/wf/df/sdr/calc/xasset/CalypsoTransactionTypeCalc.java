package com.wf.df.sdr.calc.xasset;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class CalypsoTransactionTypeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	DTCCUtils dtccUtils;

	@Calculation(value = Calc.calypsoTransactionTypeCalc, isPrototype = false)
	public String transactionType(
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String marketType,
			@DerivedFrom(value = Calc.isSwapswireTradeCalc,  isInternal = true) Boolean mwTrade,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType,
			@DerivedFrom(value = Stv.FeeTypeList, isInternal = true) List<String> feeTypeList,
			//@DerivedFrom(value = Stv.CalypsoDocStatus, isInternal = true) String calypsoDocStatus,
			//@DerivedFrom(value = Stv.DocAction, isInternal = true) String docAction,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String srcAssetClass,
			@DerivedFrom(value = Calc.sendBackloadCalc, isInternal = true) boolean backload,
			@DerivedFrom(value = Stv.SDR_BACKLOAD, isInternal = true) String backloadkeyword,
			@DerivedFrom(value = Calc.isRateReportedAsForexCalc, isInternal = true) boolean isForex,
			@DerivedFrom(value = Calc.isRateReportedAsCreditCalc, isInternal = true) boolean rateReportsCredit) {
		
		if (backload) {
				if(Constants.BACKLOAD_DEAD.equalsIgnoreCase(backloadkeyword))
					return Constants.Historical;
				
			return Constants.Backload;
		} else if(Constants.MESSAGE_TYPE_SNAPSHOT.equals(msgType) || Constants.MESSAGE_TYPE_VALUATION.equals(msgType) || Constants.MESSAGE_TYPE_SNAPSHOT_TO.equals(msgType)){
			return Constants.Trade;
		}
/*		if (Utils.IsNullOrNone(calypsoDocStatus)) {
			throw new CalculationException(Stv.CalypsoDocStatus,"CalypsoDocStatus is " + calypsoDocStatus);
		}
*/		String transType = null;
		if (Constants.ASSET_CLASS_CREDIT.equals(srcAssetClass)) {

			transType = getCreditTransactionType(/*calypsoDocStatus, docAction, */msgType, marketType);
			/*if (transType == null)
				throw new CalculationException(Stv.DocAction,"Credit transaction type not found for "+ calypsoDocStatus + Constants.PERIOD+ docAction);*/
			if (transType == null)
				throw new CalculationException(Stv.MarketType,"Credit transaction type not found "+ marketType);
			
		} else if (Constants.ASSET_CLASS_INTEREST_RATE.equals(srcAssetClass)){
			if(isForex){
				return getForexTransactionType(marketType, feeTypeList);
			}
			if (mwTrade && Utils.IsNullOrNone(marketType))
				return Constants.NOT_APPLICABLE;
			transType = getRatesTransactioType(marketType, feeTypeList,rateReportsCredit);
			transType = setTxnTypeForRT(msgType, transType, srcAssetClass, marketType);
			if (transType == null)
				throw new CalculationException(Stv.MarketType,"Rate transaction type not found for " + marketType);
		}

		return transType;
	}

	/**
	 * For Forex products, reported by Rates System
	 * @param marketType
	 * @param feeTypeList
	 * @return
	 */
	public String getForexTransactionType(String marketType, List<String> feeTypeList) {

		String transType = null;
		
		if (Utils.IsNullOrNone(marketType)) {
			throw new CalculationException(Stv.MarketType, "MarketType is "+ marketType);
		}
		if (!Utils.IsListNullOrEmpty(feeTypeList)) {

			for (int i = 0; i < feeTypeList.size(); i++) {
				if (feeTypeList.get(i) != null &&  StringUtils.containsIgnoreCase(feeTypeList.get(i), Constants.Novation)) {
					transType = Constants.Novation_Trade;
				}
				if (feeTypeList.get(i) != null &&  StringUtils.containsIgnoreCase(feeTypeList.get(i), Constants.Termination) && Constants.Amendment.equalsIgnoreCase(marketType)) {
					transType = Constants.Termination;
				}
			}
		}
		if (transType == null)
			transType = dtccUtils.getForexTransactionType(marketType.trim());
		return transType;
	}
	public String getRatesTransactioType(String marketType, List<String> feeTypeList,boolean rateReportsCredit) {

		String transType = null;
		
		if (Utils.IsNullOrNone(marketType)) {
			throw new CalculationException(Stv.MarketType, "MarketType is "+ marketType);
		}
		if (!Utils.IsListNullOrEmpty(feeTypeList)) {

			for (int i = 0; i < feeTypeList.size(); i++) {
				if (feeTypeList.get(i) != null &&  StringUtils.containsIgnoreCase(feeTypeList.get(i), Constants.Novation)) {
					transType = Constants.Novation_Trade;
				}
				if (feeTypeList.get(i) != null &&  StringUtils.containsIgnoreCase(feeTypeList.get(i), Constants.Termination) && Constants.Amendment.equalsIgnoreCase(marketType)) {
					transType = Constants.Termination;
				}
			}
		}
		if (transType == null)
			transType = dtccUtils.getRatesTransactionType(marketType.trim());
		//Check for cross product trades
		if(rateReportsCredit)
		{
			//if cross product update the transaction type
			String crTxnType=dtccUtils.getRateReportedAsCreditTxn(transType);
			if(!Utils.IsNullOrBlank(crTxnType))
				transType=crTxnType;
		}
		return transType;
	}

	private String getCreditTransactionType(/*String calypsoDocStatus, String docAction,*/ String msgType, String marketType) {
		String transType = null;//String key = null;
		/*
		if (Utils.IsNullOrNone(marketType)) {
			throw new CalculationException(Stv.DocAction, "DocAction is "+ docAction);
		}
		
		//Handling special case for tobe_assigned
		if(Constants.TRADE_STATUS_TOBE_ASSIGNED.equals(calypsoDocStatus) && Constants.Confirmation.equals(docAction))
			return Constants.Novation;
		
		// docstatus  = TOBE_VER/PRE_BOOKED/PRE_NOVATED, docAction = 'Novation' msgtype !='RT',return NovationTrade
		if( (Constants.TRADE_STATUS_TOBE_VER.equals(calypsoDocStatus) || Constants.TRADE_STATUS_PRE_BOOKED.equals(calypsoDocStatus) || Constants.TRADE_STATUS_PRE_NOVATED.equals(calypsoDocStatus))
				&& !Constants.MESSAGE_TYPE_RT.equals(msgType) && Constants.Novation.equals(docAction))
			return Constants.NovationTrade;
		
		if(Constants.Amendment.equals(marketType))
			key =  marketType;
		else 
			key =  docAction;
		*/
		if (Utils.IsNullOrNone(marketType)) {
			throw new CalculationException(Stv.MarketType, "MarketType is "+ marketType);
		}
		transType = dtccUtils.getCreditTransactionType(marketType.trim());
		transType = setTxnTypeForRT(msgType, transType, Constants.ASSET_CLASS_CREDIT, marketType);		
		return transType;
	}

	private String setTxnTypeForRT(String msgType, String transType, String assetClass, String marketType) {
		
		if (transType != null && StringUtils.containsIgnoreCase(transType,Constants.Novation)) {
			if(Constants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(assetClass)) {
				if (Constants.MESSAGE_TYPE_RT.equals(msgType))
					transType = Constants.Novation;
				else 
					transType = Constants.Novation_Trade;
			} else if(Constants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass)) {
				if (Constants.MESSAGE_TYPE_RT.equals(msgType))
					transType = Constants.Novation;
				else
					transType = Constants.NovationTrade;
			}
		}
		return transType;
	}
}
