package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.DtccFieldsTransactionMappings;
import com.wf.df.sdr.exception.dao.DtccFieldsTransactionMappingsDaoException;

public interface DtccFieldsTransactionMappingsDao {

	/** 
	 * Returns all rows from the dtcc_fields_transaction_mappings table that match the criteria ''.
	 */
	public List<DtccFieldsTransactionMappings> findAll() throws DtccFieldsTransactionMappingsDaoException;

	
}
