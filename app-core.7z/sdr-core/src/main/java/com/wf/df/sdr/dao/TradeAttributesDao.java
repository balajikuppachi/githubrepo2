package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.TradeAttributes;
import com.wf.df.sdr.exception.dao.TradeAttributesDaoException;

public interface TradeAttributesDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(TradeAttributes dto);

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria ''.
	 */
	public List<TradeAttributes> findAll() throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'send_id = :sendId'.
	 */
	public List<TradeAttributes> findWhereSendIdEquals(long sendId) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'trade_id = :tradeId'.
	 */
	public List<TradeAttributes> findWhereTradeIdEquals(String tradeId) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'trade_version = :tradeVersion'.
	 */
	public List<TradeAttributes> findWhereTradeVersionEquals(String tradeVersion) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'action = :action'.
	 */
	public List<TradeAttributes> findWhereActionEquals(String action) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'asset_class = :assetClass'.
	 */
	public List<TradeAttributes> findWhereAssetClassEquals(String assetClass) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'upi = :upi'.
	 */
	public List<TradeAttributes> findWhereUpiEquals(String upi) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'notional_currency = :notionalCurrency'.
	 */
	public List<TradeAttributes> findWhereNotionalCurrencyEquals(String notionalCurrency) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'notional_amount = :notionalAmount'.
	 */
	public List<TradeAttributes> findWhereNotionalAmountEquals(float notionalAmount) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirmation_datetime = :confirmationDatetime'.
	 */
	public List<TradeAttributes> findWhereConfirmationDatetimeEquals(Date confirmationDatetime) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'usi = :usi'.
	 */
	public List<TradeAttributes> findWhereUsiEquals(String usi) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'reporting_sdr = :reportingSdr'.
	 */
	public List<TradeAttributes> findWhereReportingSdrEquals(String reportingSdr) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'reporting_jurisdiction = :reportingJurisdiction'.
	 */
	public List<TradeAttributes> findWhereReportingJurisdictionEquals(String reportingJurisdiction) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	public List<TradeAttributes> findWhereUpdateDatetimeEquals(Date updateDatetime) throws TradeAttributesDaoException;
	
	/**
	 * 
	 * Returns all rows from the trade_attributes table that match the criteria 'trade Id and asset class = rates'
	 */
	public List<TradeAttributes> findPreviousRecordsForTrade(String tradeId, String assetClass, String sdrRepository) throws TradeAttributesDaoException;
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'usi and asset class = rates'.
	 */
		
	public List<TradeAttributes> findPreviousRecordsForUSI(String usi, String assetClass) throws TradeAttributesDaoException;

	public void updateUsiForSendId(BigDecimal sendId, String usi);
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'econfirm_flag = :econfirmFlag'.
	 */
	public List<TradeAttributes> findWhereEconfirmFlag	 (boolean econfirmFlag) throws TradeAttributesDaoException;
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirm_status = :confirmStatus'.
	 */
	public List<TradeAttributes> findWhereConfirmStatus	(String confirmStatus) throws TradeAttributesDaoException;
	
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirm_buyer = :confirmBuyer'.
	 */
	public List<TradeAttributes> findWhereConfirmBuyer	(String confirmBuyer) throws TradeAttributesDaoException;
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'confirm_seller = :confirmSeller'.
	 */
	public List<TradeAttributes> findWhereConfirmSeller	(String confirmSeller) throws TradeAttributesDaoException;
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'uti = :uti'.
	 */
	public List<TradeAttributes> findWhereUtiEquals(String uti) throws TradeAttributesDaoException;

	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'fcmCpty = :fcmCpty'.
	 */
	public List<TradeAttributes> findWhereFcmCptyEquals(String fcmCpty) throws TradeAttributesDaoException;
	
	/** 
	 * Returns all rows from the trade_attributes table that match the criteria 'feeFcmCpty = :feeFcmCpty'.
	 */
	public List<TradeAttributes> findWhereFeeFcmCptyEquals(String feeFcmCpty) throws TradeAttributesDaoException;
}
