package com.wf.df.sdr.calc.forex;

import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxQuotingAmountCalc {
	
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.fxQuotingAmountCalc)
	public String calcQuoteAmt(
			@DerivedFrom(value=Stv.FXOptionQuotingAmount) String optionFxQuoteAmount,
			@DerivedFrom(value=Stv.FXQuotingAmountList) List<String> fXQuotingAmountList,
			@DerivedFrom(value = Calc.dtccProductTypeCalc) String dtccProductType,
			@DerivedFrom(value = Constants.FOREX_SWAP_LEG_INDEX, isInternal = true) Integer swapLegIndex)	{
		if(!Utils.IsNullOrBlank(dtccProductType) )
		{
			try {
				if(dtccProductType.equals(Constants.FOREX_FORWARD) && !Utils.IsListNullOrEmpty(fXQuotingAmountList))
				{
					if(!Utils.IsNullOrBlank(swapLegIndex))
						return formatter.formatDecimal(parser.parseBigDecimal(fXQuotingAmountList.get(swapLegIndex)).abs());
					
					for(int i=0; i<fXQuotingAmountList.size(); i++){
						if(!Utils.IsNullOrBlank(fXQuotingAmountList.get(i)))
							return formatter.formatDecimal(parser.parseBigDecimal(fXQuotingAmountList.get(i)).abs());
					}
					
				}else if(dtccProductType.equals(Constants.FOREX_OPTION)&& !Utils.IsNullOrBlank(optionFxQuoteAmount))
				{  	 return formatter.formatDecimal(parser.parseBigDecimal(optionFxQuoteAmount).abs());
				}
			} catch (ParseException e) {
				throw new CalculationException("Parse Exception", Stv.FXOptionQuotingAmount +" OR "+ Stv.FXQuotingAmountList + " is in wrong format. ");
			}
		}
		return Constants.EMPTY_STRING;
	}
}
