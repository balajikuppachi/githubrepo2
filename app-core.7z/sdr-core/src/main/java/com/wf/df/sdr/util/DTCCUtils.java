package com.wf.df.sdr.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.wf.df.sdr.dao.DomainValuesDao;
import com.wf.df.sdr.dao.InputMsgStoreExtnDao;
import com.wf.df.sdr.dao.MappingUsiDtccusiDao;
import com.wf.df.sdr.dto.DomainValues;
import com.wf.df.sdr.dto.MappingUsiDtccusi;
import com.wf.df.sdr.dto.ProductsMapping;

/**
 * 
 * @author U163442
 * 
 *         All the DTCC name values pairs are managed from this file. The values
 *         will be loaded from DB or maintained in static maps here.
 * 
 */

@Component
@ManagedResource(description="Manages metadata from \"domain_values\" table")
public class DTCCUtils {

	protected Logger logger = Logger.getLogger(DTCCUtils.class);

	@Autowired
	DomainValuesDao domainValuesDao;


	@Autowired
	InputMsgStoreExtnDao inputMsgStoreExtnDao; 
	
	@Autowired
	MappingUsiDtccusiDao mappingUsiDtccusiDao; 
	
	@Value("${wf.affiliatebank.leis}") String affliateBankLEIs;
	@Value("${wf.affiliate.leis}") String affliateLEIs;
	@Value("${rates.swapswire.source}") String swapSwireSource ;

	private final String SEPARATOR = "$#$";
	private final String COMPOUNDING_METHOD = "CMD";
	private final String DAY_COUNT = "DCF";
	private final String FREQUENCY_PERIOD = "PRD";
	private final String PERIOD_MULTIPLIER = "PML";
	private final String BUSINESS_DAY_CONVENTION = "BDC";
	private final String MARKET_TYPE = "Market Type";
	private final String FRA_DISCOUNTING = "FDI";
	private final String PERIOD_ROLL = "RLC";
	private final String DATE_RELATIVE_TO = "DRT";
	private final String ACTION = "Action";
	private final String CR_ACTION = "CreditAction";
	private final String CR_TXN = "CreditTxn";
	private final String EQ_TXN = "EquityTxn";
	private final String FX_TXN = "ForexTxn";
	private final String RT_TXN = "RatesTxn";
	private final String EQ_TEMPLATE = "EquityUpiTemplate";
	private final String INFLATION_RATE_SOURCE = "ISC";
	private final String DAY_TYPE = "DTY";
	private final String INTERPOLATION_METHOD = "IMD";
	private final String INFLATION_MAIN_PUBLICATION = "IMP";
	private final String DESIGNATED_PRIORITY = "DP";
	private final String ROUNDING_DIRECTION = "RND";
	private final String REGION = "RGN";
	private final String BASKET_INDEX_NAME = "BINDEX";
	private final String DUMMY_CUSIP = "DCUSIP";
	private final String MASTER_AGREEMENT = "MasterAgreement";
	private final String LEGAL_AGREEMENT = "LegalAgreement";
	private final String ASSET_CLASS_PREFIX = "ASSET_CLASS_PREFIX";
	private final String AMD = "AMD";
	private final String JURISDICTION = "JURISDICTION";
	private final String MATT = "MATT";
	private final String SMATT = "SMATT";
	private final String MTT = "MTT";
	private final String SMTT = "SMTT";
	private final String CDX_SECTOR = "CDXSector";
	private final String ISO_CURRENCY_EXCEPTION = "ISOCurrencyException";
	private final String FLOATING_RATE_IDX="FloatingRateIndex";
	private final String CashSettlement = "CashSettlement";
	private final String PRODUCT_EXCEPTIONS = "ProductExceptions";
	private final String FX_OPTION_STYLE = "FxOptionStyle";
	private final String FX_TZ_NAME = "FxTZName";
	private final String BUSINESS_CENTER = "BusinessCenter";
	private final String PRIMARY_ASSET_CLASS="PrimaryAssetClass";
	private final String RATE_REPORTED_AS_CREDIT = "RateReportedAsCredit";
	private final String CLEARING_EXCEPTION_PRODUCT = "ClearingExceptionProduct";
	private final String EMIR_CP_Taxonomy = "EmirCpTaxonomy";
	private final String EMIR_US_Taxonomy = "EmirUsTaxonomy";
	private final String CR_LCE = "CreditLCE";
	private final String FX_LCE = "ForexLCE";
	private final String RT_LCE = "RatesLCE";
	private final String TO_FLOATING_RATE_IDX="ToFloatingRateIndex";
	private final String CAD_PROVINCES="cadProvinces";
	private final String ACTION_TYPE_SS="ACTION_TYPE_SS";
	

	private static Map<String, String> domainMap;
	
	private static Map<String, String> usiDtccUsiMap;
	private static Map<String, String> tradeIdDtccUsiMap;
		
	public String getBusinessCenterCode(String bus) {
		
		String domainkey = BUSINESS_CENTER + SEPARATOR + bus;
		String businessCenter = (String) domainMap.get(domainkey);
		
		//String businessCenter = businessCentersMap.get(bus);
	
		if(businessCenter != null)
			return businessCenter;
		
		return bus;
	}

	@PostConstruct
	@ManagedOperation(description="Reloads the metadata from \"domain_values\" table")
	public void initialize() {

		populateDomainMap();
		populateUsiDtccUsiMap();
		populateTradeIdDtccUsiMap();
	}
	
	private void populateDomainMap(){
		
		List<DomainValues> domainValuesList = domainValuesDao.findAll();
		domainMap = new HashMap<String, String>();

		String key = null;
		for (DomainValues domainValue : domainValuesList) {
			if (domainValue.getSrcCode() == null)
				continue;
			key = domainValue.getDomain() + SEPARATOR
					+ domainValue.getSrcCode();

			domainMap.put(key, domainValue.getDtccCode());
		}
		
	}

	private void populateUsiDtccUsiMap(){
		
		List<MappingUsiDtccusi> mappingUsiDtccusiList = mappingUsiDtccusiDao.findAll();
		usiDtccUsiMap = new HashMap<String, String>();

		for (MappingUsiDtccusi mappingUsiDtccusi : mappingUsiDtccusiList) 			
			usiDtccUsiMap.put(mappingUsiDtccusi.getUsi(), mappingUsiDtccusi.getDtccUsi());
				
	}
	
	private void populateTradeIdDtccUsiMap(){
		
		 tradeIdDtccUsiMap= inputMsgStoreExtnDao.findListOfTradeIdDtccUsi();
				
	}
	public String getDtccUsiFromTradeId(String tradeId){
		return !Utils.IsNullOrBlank(tradeIdDtccUsiMap.get(tradeId))?tradeIdDtccUsiMap.get(tradeId):Constants.EMPTY_STRING;
	}
	
	public void updateDtccUsiFromTradeId(String tradeId, String dtccUsi){
		tradeIdDtccUsiMap.put(tradeId, dtccUsi);
	}
	
	public void updateUsiDtccUsiMap(String usi, String dtccUsi){
		usiDtccUsiMap.put(usi, dtccUsi);
	}
	
	public String getDtccUsi(String usi){
		//return usiDtccUsiMap.get(usi);
		return !Utils.IsNullOrBlank(usiDtccUsiMap.get(usi))?usiDtccUsiMap.get(usi):(usiDtccUsiMap.containsValue(usi)?usi:Constants.EMPTY_STRING);
	}
	
	public boolean isDummyCusip(String stvCusip) {
		String domainkey = DUMMY_CUSIP + SEPARATOR + stvCusip;
		String val = (String) domainMap.get(domainkey);
		return (null != val ? true : false);
	}

	public boolean isStandardBasketName(String stvBasketName) {
		String domainkey = BASKET_INDEX_NAME + SEPARATOR + stvBasketName;
		String val = (String) domainMap.get(domainkey);
		return (null != val ? true : false);
	}

	public String getRegion(String stvRegion) {
		String domainkey = REGION + SEPARATOR + stvRegion;
		return ((String) domainMap.get(domainkey));
	}

	public String getDayCount(String calypsoKey) {
		String domainkey = DAY_COUNT + SEPARATOR + calypsoKey;
		return ((String) domainMap.get(domainkey));
	}

	public String getAction(String asset, String act) {
		String prefix = ACTION;
		if ((asset != null) && asset.contains("Credit")) {
			prefix = CR_ACTION;
		}
		String domainKey = prefix + SEPARATOR + act;
		return ((String) domainMap.get(domainKey));
	}

	public String getCreditTransactionType(String docStatus) {
		String domainkey = CR_TXN + SEPARATOR + docStatus;
		return ((String) domainMap.get(domainkey));
	}

	public String getBusinessDayConvention(String bussDay) {
		String domainkey = BUSINESS_DAY_CONVENTION + SEPARATOR + bussDay;
		return ((String) domainMap.get(domainkey));
	}

	public String getRatesTransactionType(String mktType) {
		String domainkey = RT_TXN + SEPARATOR + mktType;
		return ((String) domainMap.get(domainkey));
	}

	public String getFrequencyPeriod(String frequency) {
		String domainkey = FREQUENCY_PERIOD + SEPARATOR + frequency;
		return ((String) domainMap.get(domainkey));
	}

	public String getFRADiscounting(String srcFRADiscounting) {
		String domainkey = FRA_DISCOUNTING + SEPARATOR + srcFRADiscounting;
		return ((String) domainMap.get(domainkey));
	}

	public String getFrequencyPeriodNumber(String frequency) {
		// return frequencyPeriodNumberMap.get(frequency);
		String domainkey = PERIOD_MULTIPLIER + SEPARATOR + frequency;
		return ((String) domainMap.get(domainkey));
	}

	public String getRollingConvention(String periodRoll) {
		String domainkey = PERIOD_ROLL + SEPARATOR + periodRoll;
		return ((String) domainMap.get(domainkey));
	}

	public String getDateRelativeTo(String flag) {
		String domainKey = DATE_RELATIVE_TO + SEPARATOR + flag;
		return ((String) domainMap.get(domainKey));
	}

	public String getCompoundingMethod(String cm) {
		String domainKey = COMPOUNDING_METHOD + SEPARATOR + cm;
		return ((String) domainMap.get(domainKey));
	}

	public String getInflationRateSource(String idx) {
		String domainKey = INFLATION_RATE_SOURCE + SEPARATOR + idx;
		return ((String) domainMap.get(domainKey));
	}

	public String getInterpolationMethod(String idx) {
		String domainKey = INTERPOLATION_METHOD + SEPARATOR + idx;
		return ((String) domainMap.get(domainKey));
	}

	public String getInflationMainPublicaton(String idx) {
		String domainKey = INFLATION_MAIN_PUBLICATION + SEPARATOR + idx;
		return ((String) domainMap.get(domainKey));
	}

	public String getDesignatedPriority(String idx) {
		String domainKey = DESIGNATED_PRIORITY + SEPARATOR + idx;
		return ((String) domainMap.get(domainKey));
	}

	public String getRoundingDirection(String rnd) {
		String domainKey = ROUNDING_DIRECTION + SEPARATOR + rnd;
		return ((String) domainMap.get(domainKey));
	}

	public String getDayType(String dayType) {
		String domainkey = DAY_TYPE + SEPARATOR + dayType;
		return ((String) domainMap.get(domainkey));
	}

	public String getLegalAgreement(String legalAgreement) {
		String domainkey = LEGAL_AGREEMENT + SEPARATOR + legalAgreement;
		return ((String) domainMap.get(domainkey));
	}

	public String getMasterAgreement(String masterAgreement) {
		String domainkey = MASTER_AGREEMENT + SEPARATOR + masterAgreement;
		return ((String) domainMap.get(domainkey));
	}

	public String getAssetClassPrefix(String assetClass) {
		String prefix = ASSET_CLASS_PREFIX + SEPARATOR + assetClass;
		return ((String) domainMap.get(prefix));
	}

	public String getMATT(String region) {
		String prefix = MATT + SEPARATOR + region;
		return ((String) domainMap.get(prefix));
	}

	public String getSMATT(String region) {
		String prefix = SMATT + SEPARATOR + region;
		return ((String) domainMap.get(prefix));
	}

	public String getMTT(String region) {
		String prefix = MTT + SEPARATOR + region;
		return ((String) domainMap.get(prefix));
	}

	public String getSMTT(String region) {
		String prefix = SMTT + SEPARATOR + region;
		return ((String) domainMap.get(prefix));
	}
	
	public String getCDXSector(String src){
		String domainkey = CDX_SECTOR + SEPARATOR + src;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getJurisdiction(String upi) {
		String domainkey = JURISDICTION + SEPARATOR + upi;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getAveragingMethod(String averagingType) {
		String domainkey = AMD + SEPARATOR + averagingType;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getFloatingRateIndex(String floatingRateIdx) {
		String domainkey =FLOATING_RATE_IDX + SEPARATOR + floatingRateIdx;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getISOCurrency(String currencyCode) {
		String domainkey = ISO_CURRENCY_EXCEPTION + SEPARATOR + currencyCode;
		String ret = ((String) domainMap.get(domainkey));
		return ((ret != null) ? ret : currencyCode);
	}
	
	public String getCashSettlement(String cashSettlementMethod) {
		String domainkey = CashSettlement + SEPARATOR + cashSettlementMethod;
		String val = ((String) domainMap.get(domainkey));
		return ((val != null) ? val : cashSettlementMethod);
	}

	public String getEquityTransactionType(String txnType) {
		String domainkey = EQ_TXN + SEPARATOR + txnType;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getForexTransactionType(String txnType) {
		String domainkey = FX_TXN + SEPARATOR + txnType;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getEquityTemplateForUpi(String upi) {
		String domainkey = EQ_TEMPLATE + SEPARATOR + upi;
		return ((String) domainMap.get(domainkey));
	}

	public String getFxOptionStyle(String optionStyle) {
		String domainkey = FX_OPTION_STYLE + SEPARATOR + optionStyle;
		return ((String) domainMap.get(domainkey));
	}
	
	
	public ProductsMapping isAnExceptionProduct (ProductsMapping genericProduct, String subProdType) {
		String domainkey = PRODUCT_EXCEPTIONS+ SEPARATOR + genericProduct.getMappingType() + SEPARATOR + 
				genericProduct.getSrcAssetClass() + SEPARATOR + 
				genericProduct.getSrcProdType();
		String extKey = domainkey+ SEPARATOR + subProdType;
		// lookup by subproduct
		String value = domainMap.get(extKey);
		if (value == null)
			// lookup by Product
			value = domainMap.get(domainkey);
		if (value != null) {
			String arr[] = StringUtils.split(value, SEPARATOR);
			ProductsMapping pmret  = new ProductsMapping();
			pmret.setDtccAssetClass(arr[0]);
			pmret.setDtccProdType(arr[1]);
			if ((arr.length > 2) && (arr[2] != null))
				pmret.setDtccSubProdType(arr[2]);
			else 
				pmret.setDtccSubProdType(null);
			pmret.setKeyType(genericProduct.getKeyType());
			pmret.setMappingType(genericProduct.getMappingType());
			pmret.setSrcAssetClass(genericProduct.getSrcAssetClass());
			pmret.setSrcProdType(genericProduct.getSrcProdType());
			pmret.setSrcSubProdType(subProdType);
			return pmret;
		}
		return null;
	}

	public String getTZDisplayName(String timeZoneDisplayName) {
		String domainkey = FX_TZ_NAME + SEPARATOR + timeZoneDisplayName;
		return ((String) domainMap.get(domainkey));		

	}
	
	
	public boolean isBothPartiesAffiliate(String us, String cp, boolean includeBank) {
		
		boolean usAffiliate  = false;
		boolean cpAffiliate  = false;
		
		String leiList2Check = null;

		if (Utils.IsNullOrNone(cp) ||  Utils.IsNullOrBlank(us))
			return false;
		
		leiList2Check = (includeBank) ? affliateBankLEIs : affliateLEIs;
		
		usAffiliate = org.apache.commons.lang.StringUtils.containsIgnoreCase(leiList2Check, us);
		cpAffiliate = org.apache.commons.lang.StringUtils.containsIgnoreCase(leiList2Check, cp);
		
		if (usAffiliate && cpAffiliate)
			return true;
		
		return false;
	}
	
	public String getRateReportedAsCreditTxn(String rateTxn) {
		String domainkey = RATE_REPORTED_AS_CREDIT + SEPARATOR + rateTxn;
		return ((String) domainMap.get(domainkey));	
	}
	
	
	public String getPrimaryAssetClass(String srcProduct) {
		String domainkey = PRIMARY_ASSET_CLASS + SEPARATOR + srcProduct;
		return ((String) domainMap.get(domainkey));
	}
	
	

	public boolean isSwapswireTrade(String ecnSource){
		if(org.apache.commons.lang.StringUtils.contains(swapSwireSource, ecnSource))
			return true;
		return false;
	}
	public Boolean isClearingExceptionProduct(String product) {
		String domainkey = CLEARING_EXCEPTION_PRODUCT + SEPARATOR + product;
		String value = ((String) domainMap.get(domainkey));
		if(!Utils.IsNullOrBlank(value) && Constants.TRUE.equalsIgnoreCase(value))
			return true;		
		return false;
	}
	
	//newly added for EMIR
	public String getEmirCpTaxonomy(String EmirCpTaxonomy) {
		String domainkey = EMIR_CP_Taxonomy + SEPARATOR + EmirCpTaxonomy;
		return ((String) domainMap.get(domainkey));
	}

	public String getEmirUsTaxonomy(String EmirUsTaxonomy) {
		String domainkey = EMIR_US_Taxonomy + SEPARATOR + EmirUsTaxonomy;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getCreditLifeCycleEvent(String marketType) {
		String domainkey = CR_LCE + SEPARATOR + marketType;
		return ((String) domainMap.get(domainkey));
	}

	public String getRatesLifeCycleEvent(String marketType) {
		String domainkey = RT_LCE + SEPARATOR + marketType;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getForexLifeCycleEvent(String marketType) {
		String domainkey = FX_LCE + SEPARATOR + marketType;
		return ((String) domainMap.get(domainkey));
	}
	public String getToFloatingRateIndex(String floatingRateIdx) {
		String domainkey =TO_FLOATING_RATE_IDX + SEPARATOR + floatingRateIdx;
		return ((String) domainMap.get(domainkey));
	}
	
	public String getCanadianProvinces(String province) {
		String domainkey =CAD_PROVINCES + SEPARATOR + province;
		return ((String) domainMap.get(domainkey));
	}

	public String getActionType(String key) {
		String domainkey =ACTION_TYPE_SS + SEPARATOR + key;
		return ((String) domainMap.get(domainkey));
	}
}