package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class EqCurrentUSIPrefixCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqCurrentUSIPrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.eqComputedUSICalc, isInternal = true) String usi,
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliateTrade,
			@DerivedFrom(value = Calc.affiliateUsiCalc, isInternal = true) String affiliateUsi) {
		
		if(isAffiliateTrade){			
			if(Utils.IsNullOrBlank(affiliateUsi))
				return Constants.GTRCREATE;
			usi = affiliateUsi;			
		}
			
		
		if (!Utils.IsNullOrNone(usi)) {
			if (usi.startsWith(Constants.DTCC))
				return Constants.DTCC;
			else
				if(usi.length()>10)
					// First 10 positions of USI is the prefix
					return usi.substring(0, 10);
				
				
		}
		throw new CalculationException("USINF", "USI not found or less than 10 characters.");
	}
}
