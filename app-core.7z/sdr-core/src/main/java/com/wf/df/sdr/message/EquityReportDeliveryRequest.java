package com.wf.df.sdr.message;

import java.io.File;


public class EquityReportDeliveryRequest {
	private EquityReportGenerationRequest generationRequest;
	private File file;

	public EquityReportDeliveryRequest(EquityReportGenerationRequest generationRequest, File file) {
		this.generationRequest = generationRequest;
		this.file = file;
	}

	public EquityReportGenerationRequest getReportGenerationRequest() {
		return generationRequest;
	}

	public File getFile() {
		return file;
	}
}
