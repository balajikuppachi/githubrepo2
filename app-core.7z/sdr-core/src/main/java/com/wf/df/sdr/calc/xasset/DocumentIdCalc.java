package com.wf.df.sdr.calc.xasset;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.MsgToReportDao;
import com.wf.df.sdr.dto.MsgToReport;
import com.wf.df.sdr.dto.MsgToReportStatus;
import com.wf.df.sdr.service.meta.FieldsMessageMappingLoader;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.ReportFields;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

import edu.emory.mathcs.backport.java.util.Collections;

@Component
public class DocumentIdCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	MsgToReportDao msgToReportDao;
	@Autowired
	FieldsMessageMappingLoader mappingLoader;
	
	@Calculation(value = Calc.documentIdCalc, isPrototype = false)
	public String calculate (@DerivedFrom(value = Constants.CONFIRM_DOCUMENT_ID, isInternal = true) String documentId,
							 @DerivedFrom(value = Constants.SEND_ID, isInternal = true) BigDecimal sendId,
							 @DerivedFrom(value = Stv.TradeId, isInternal = true) String tradeId,
							 @DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String tlcEvent,
							 @DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType,
							 @DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass,
							 @DerivedFrom(value = Calc.computedUSICalc, isInternal = true) String usi,
							 @DerivedFrom(value = Calc.sdrRepositoryCalc, isInternal = true) String sdrRepo) {
		
		//Copying ActionCalc code
		List<MsgToReportStatus> msgToReportList = msgToReportDao
					.findExistingTradeWithStatus(tradeId, tlcEvent, msgType, assetClass, usi,sdrRepo);
		
		if (!Utils.IsListNullOrEmpty(msgToReportList)) {
			
			Collections.sort(msgToReportList, new RecordsComparator());

			String status = msgToReportList.get(0).getStatus();

			if (Constants.MSG_STATUS_ACCEPTED.equals(status)) {
				
				//We have to report Old document ID for a modify action
				MsgToReport prevDocMsg = msgToReportList.get(0).getMsgToReport();
				
				Integer indexOfDocumentId = mappingLoader.getSeqNoForField(sdrRepo,msgType, assetClass, ReportFields.DocumentID) -1 ;				
				
				String[] prevDocMsgTokens = prevDocMsg.getOutMsgData().split(Constants.COMMA_SEPARATOR_REGEX, -1);	
				
				String prevDocumentId = prevDocMsgTokens[indexOfDocumentId];
				
				return prevDocumentId;
				
			}

		}	
		
		// Appending SendId to all the PDF names, since 
		String docId = documentId + Constants.UNDERSCORE + sendId;
		return docId;
	}
	
	private class RecordsComparator implements Comparator<MsgToReportStatus> {

		@Override
		public int compare(MsgToReportStatus o1, MsgToReportStatus o2) {
			
			if(o1.getMsgToReport().getCreateDatetime().after(o2.getMsgToReport().getCreateDatetime()))
				return 1;
			
			return 0;
		}
		
		
		
	}
	
}
