package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.RecvMsgStore;
import com.wf.df.sdr.exception.dao.RecvMsgStoreDaoException;

public interface RecvMsgStoreDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(RecvMsgStore dto);

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria ''.
	 */
	public List<RecvMsgStore> findAll() throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'recv_id = :recvId'.
	 */
	public List<RecvMsgStore> findWhereRecvIdEquals(BigDecimal recvId) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'msg_type = :msgType'.
	 */
	public List<RecvMsgStore> findWhereMsgTypeEquals(String msgType) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<RecvMsgStore> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'fq_filename = :fqFilename'.
	 */
	public List<RecvMsgStore> findWhereFqFilenameEquals(String fqFilename) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_src_msg_recv_time = :dtccSrcMsgRecvTime'.
	 */
	public List<RecvMsgStore> findWhereDtccSrcMsgRecvTimeEquals(Date dtccSrcMsgRecvTime) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_msg_resp_time = :dtccMsgRespTime'.
	 */
	public List<RecvMsgStore> findWhereDtccMsgRespTimeEquals(Date dtccMsgRespTime) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_reference_id = :dtccReferenceId'.
	 */
	public List<RecvMsgStore> findWhereDtccReferenceIdEquals(String dtccReferenceId) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_response_status = :dtccResponseStatus'.
	 */
	public List<RecvMsgStore> findWhereDtccResponseStatusEquals(String dtccResponseStatus) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'in_msg_buffer = :inMsgBuffer'.
	 */
	public List<RecvMsgStore> findWhereInMsgBufferEquals(BigDecimal bufferId) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'send_id = :sendId'.
	 */
	public List<RecvMsgStore> findWhereSendIdEquals(BigDecimal sendId) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'usi = :usi'.
	 */
	public List<RecvMsgStore> findWhereUsiEquals(String usi) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'prev_usi = :prevUsi'.
	 */
	public List<RecvMsgStore> findWherePrevUsiEquals(String prevUsi) throws RecvMsgStoreDaoException;

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'rep_party = :repParty'.
	 */
	public List<RecvMsgStore> findWhereRepPartyEquals(String repParty) throws RecvMsgStoreDaoException;
	/** 
	 * Returns count of rows from the RecvMsgStore table that match the criteria 'usi & msg_type'.
	 */
	public Integer checkTradeAccepted(String usi, String  msgType);
	
	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<RecvMsgStore> findWhereSdrRepositoryEquals(String sdrRepository) throws RecvMsgStoreDaoException;
	
	public List<RecvMsgStore> findWhereTransmitIdEquals(BigDecimal transmitId) throws RecvMsgStoreDaoException;

}
