package com.wf.df.sdr.calc.equity;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqActionTypeCalc 
{
	@Autowired
	DTCCUtils dtccUtils;

	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.eqActionTypeCalc ,isPrototype=false)
	public String computeActionType(@DerivedFrom(value=Calc.srcTLCEventCalc,isInternal=true) String marketType,
			@DerivedFrom(value=Calc.dtccAssetClassCalc,isInternal=true) String assetClass,
			@DerivedFrom(value=Calc.actionCalc,isInternal=true) String actionType,
			@DerivedFrom(value=Stv.LifecycleEventSubType,isInternal=true) String lifecycleEventSubType
			)
		{
		
			String returnActionType=null;
			String action_type_domain_key=null;
			action_type_domain_key=StringUtils.join(new String[]{assetClass,actionType,marketType,lifecycleEventSubType},  Constants.UNDERSCORE);
			returnActionType=dtccUtils.getActionType(action_type_domain_key);
			
			logger.info("eqActionTypeCalc: Action type - "+returnActionType);
			if(Utils.IsNullOrBlank(returnActionType))
			{
				logger.warn("eqActionTypeCalc: Action type calculation failed");
			}
			return returnActionType;
		}
}
