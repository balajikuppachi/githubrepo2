package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class IsAffiliateTradeCalc {

	@Value("${wf.affiliate.leis}")  String wfAffiliates;	
	
	@Calculation(value = Calc.isAffiliateTradeCalc, isPrototype = false)
	public Boolean calculate(
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String leiUs,
			@DerivedFrom(value = Stv.CPTY_CLASSIFICATION, isInternal = true) String cptyClassification ) {
		
		/*if(StringUtils.equalsIgnoreCase(Constants.AFFILIATE, cptyClassification))
			return true;*/
		leiUs=Utils.getElementAtIndex(leiUs, 1, Constants.COLON);
		
		if(StringUtils.contains(wfAffiliates, leiUs))
			return true;		
		return false;
	}
	
}
