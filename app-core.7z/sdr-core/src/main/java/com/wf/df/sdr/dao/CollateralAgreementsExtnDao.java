package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Repository
public class CollateralAgreementsExtnDao {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	@Qualifier("collateralJdbcTemplate")
	protected JdbcTemplate colJdbcTemplate;
	
	@Autowired
	@Qualifier("namedParamJdbcTemplate")
	protected NamedParameterJdbcTemplate namedParamJdbcTemplate;
	
	@Value("${cid.legal.query}") String collateralQuery;
	
	@Value("${collateral.valuation.query}") String collateralValuationQuery;
	
	@Value("${collateral.details.query}") String collateralDetailsQuery;
	
	
	public String findCidLegalId(String systemName, Long businessAccounId  ) {
		List<String> IdList = colJdbcTemplate.queryForList(collateralQuery, String.class, systemName, businessAccounId);
		if (IdList == null || IdList.isEmpty() || IdList.get(0) == null) {
			return null;
		} else {
			logger.info("Query PLBATCHQA DB");
			return IdList.get(0);
		}
	}
	
	
	public List<Map<String, Object>> findCollateralVals(String[] principalIds) {
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		
		List<String> principalIdlist = new ArrayList<String>();
		for(String principalId : principalIds) {
			principalIdlist.add(principalId);
		}
		
		parameters.addValue("principalIds", principalIdlist);
				
		List<Map<String, Object>> list = namedParamJdbcTemplate.query(collateralValuationQuery, parameters, 
				new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(final ResultSet rs, final int rowNum) throws SQLException {
				
				Map<String, Object> map = new HashMap<String, Object>();
				
				String colValueStr=rs.getString("total");
					BigDecimal colvalueDec = new BigDecimal(colValueStr);
				if(colvalueDec.compareTo(BigDecimal.ZERO)==0)
					colValueStr="0";
				map.put(Constants.COLLATERAL_TOTAL, colValueStr);
				map.put(Constants.COLLATERAL_PORTFOLIO_CODE, rs.getString("portfolio_code"));
				map.put(Constants.COLLATERAL_PRINCIPAL_ID, rs.getString("principal_id"));
				
				map.put(Constants.COLLATERAL_CACCY, rs.getString("ca_ccy"));
				String collPortfolioIndicator = rs.getString("collateral_portfolio");
				
				if(StringUtils.equalsIgnoreCase("Y", collPortfolioIndicator)) 
					collPortfolioIndicator = Constants.TRUE;
				else 
					collPortfolioIndicator = Constants.FALSE;
				
				map.put(Constants.COLLATERAL_COLL_PORTFOLIO, collPortfolioIndicator);
				
				return map;
			}
		});
		
		return list;
		
	}
	
	public List<String[]> findCollateralDetails(String[] principalIds, String lei,String lei2, final String assetClass) {
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		
		List<String> principalIdlist = new ArrayList<String>();
		for(String principalId : principalIds) {
			principalIdlist.add(principalId);
		}
		
		parameters.addValue("principalIds", principalIdlist);
		parameters.addValue("lei", lei);
		parameters.addValue("lei2", lei2);
				
		List<String[]> list = namedParamJdbcTemplate.query(collateralDetailsQuery, parameters, 
				new RowMapper<String[]>() {
			public String[] mapRow(final ResultSet rs, final int rowNum) throws SQLException {
				
				String[] result = new String[2];
				result[0] = rs.getString("portfolio_code");
				String collateralization = rs.getString("collateralization");
				
				if(!Utils.IsNullOrBlank(collateralization) && !Constants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)) {
					if("PC".equals(collateralization)) 
						collateralization = Constants.PartiallyCollateralized;
					else if("FC".equals(collateralization)) 
						collateralization = Constants.FullyCollateralized;
					else if("OC".equals(collateralization)) 
						collateralization = Constants.OneWayCollateralized;
					else 
						collateralization = Constants.UnCollateralized;
				}
				if(!Utils.IsNullOrBlank(collateralization) && Constants.ASSET_CLASS_FOREX.equalsIgnoreCase(assetClass)) {
					if("PC".equals(collateralization)) 
						collateralization = Constants.Partially;
					else if("FC".equals(collateralization)) 
						collateralization = Constants.Fully;
					else if("OC".equals(collateralization)) 
						collateralization = Constants.OneWay;
					else 
						collateralization = Constants.UnCollateralized;
				}
				
				result[1] = collateralization;
				
				return result;
			}
		});
		
		return list;
		
	}
	
	
}
