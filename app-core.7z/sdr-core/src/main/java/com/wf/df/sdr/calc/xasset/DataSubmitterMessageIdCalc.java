package com.wf.df.sdr.calc.xasset;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class DataSubmitterMessageIdCalc {

	@Calculation(value = Calc.dataSubmitterMessageIdCalc, isPrototype = false)
	public String wFTransId(
			@DerivedFrom(value=Constants.SEND_ID, isInternal=true) BigDecimal sendId,
			@DerivedFrom(value=Stv.TradeId, isInternal=true) String tradeId,
			@DerivedFrom(value=Stv.TradeVersion, isInternal=true) String tradeVersion)	{
		
		return tradeId + Constants.TRANS_ID_SEPARATOR + tradeVersion + Constants.TRANS_ID_SEPARATOR + sendId.toString();  
	
	}
	
}
