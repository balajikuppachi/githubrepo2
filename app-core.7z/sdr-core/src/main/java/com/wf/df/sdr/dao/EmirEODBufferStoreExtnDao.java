package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.EODBufferEmirRecord;
import com.wf.df.sdr.dto.EODBufferStoreEmir;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Repository
public class EmirEODBufferStoreExtnDao {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	
	@Autowired
	FormatterService formatterService;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${eod.report.query.emir}")	String eodQueryEmir;
	
	@Value("${eod.report.query.cad}")	String eodQueryCad;

	@Value("${eod.incremental.report.query.emir}")	String eodIncEmirReportQuery;
	
	@Value("${eod.incremental.report.query.cad}")	String eodIncCadReportQuery;
	
	@Value("${eod.report.max.query.emir}") String eodFindMaxSendId;	
	
	@Value("${eod.report.max.query.cad}") String eodFindCadMaxSendId;
	
	@Value("${eod.report.query.cad.galaxy}")	String eodQueryCadGalaxy;
	
	@Value("${eod.report.max.query.cad.galaxy}") String eodFindEquityCadMaxSendId;
	
	

	
	@Transactional
	public List<EODBufferEmirRecord> fetchEODTradeforEmirReport(String assetClass, String msgType, String sdrRepository) {
		List<EODBufferEmirRecord> rsList = jdbcTemplate.query(eodQueryEmir,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferEmirRecord record = new EODBufferEmirRecord();
						final EODBufferStoreEmir m = new EODBufferStoreEmir();
						m.setUti(rs.getString("uti"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						m.setTradeId(rs.getString("trade_id"));
						m.setInputBufferId(rs.getBigDecimal("input_buffer_id"));
						m.setIsDuplicate(rs.getBoolean("is_duplicate"));
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						
						String tradeDate = rs.getString("src_trade_date");
					
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setSrcTlcEvent(rs.getString("src_tlc_event"));
						record.setSrcTradeStatus(rs.getString("src_trade_status"));
						record.setEodBufferStoreEmir(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<EODBufferEmirRecord> fetchEODTradeforCadReport(String assetClass, String msgType, String sdrRepository) {
		List<EODBufferEmirRecord> rsList = jdbcTemplate.query(eodQueryCad,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferEmirRecord record = new EODBufferEmirRecord();
						final EODBufferStoreEmir m = new EODBufferStoreEmir();
						m.setUti(rs.getString("uti"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						m.setTradeId(rs.getString("trade_id"));
						m.setInputBufferId(rs.getBigDecimal("input_buffer_id"));
						m.setIsDuplicate(rs.getBoolean("is_duplicate"));
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						
						String tradeDate = rs.getString("src_trade_date");
					
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setSrcTlcEvent(rs.getString("src_tlc_event"));
						record.setSrcTradeStatus(rs.getString("src_trade_status"));
						record.setEodBufferStoreEmir(m);
						return record;
					}
				});
		return rsList;

	}
	

	@Transactional
	public List<EODBufferEmirRecord> fetchEODIncrementalTradeforEmirReport(String assetClass, String msgType,String sdrRepository) {
		List<EODBufferEmirRecord> rsList = jdbcTemplate.query(eodIncEmirReportQuery,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferEmirRecord record = new EODBufferEmirRecord();
						final EODBufferStoreEmir m = new EODBufferStoreEmir();
						m.setUti(rs.getString("uti"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						m.setIsDuplicate(rs.getBoolean("is_duplicate"));
						m.setTradeId(rs.getString("src_trade_id"));
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						record.setSrcTlcEvent(rs.getString("src_tlc_event"));
						record.setEodBufferStoreEmir(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<EODBufferEmirRecord> fetchEODIncrementalTradeforCadReport(String assetClass, String msgType,String sdrRepository) {
		List<EODBufferEmirRecord> rsList = jdbcTemplate.query(eodIncCadReportQuery,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferEmirRecord record = new EODBufferEmirRecord();
						final EODBufferStoreEmir m = new EODBufferStoreEmir();
						m.setUti(rs.getString("uti"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						m.setIsDuplicate(rs.getBoolean("is_duplicate"));
						m.setTradeId(rs.getString("src_trade_id"));
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						record.setSrcTlcEvent(rs.getString("src_tlc_event"));
						record.setEodBufferStoreEmir(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<Map<String,BigDecimal>> fetchEmirTradesMaxSendId(String assetClass, String msgType,String sdrRepository) {
		
		List<Map<String,BigDecimal>> rsList = jdbcTemplate.query(eodFindMaxSendId,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					
			Map<String,BigDecimal> maxList= new HashMap<String,BigDecimal>();
			public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						maxList.put(rs.getString("src_trade_id"),rs.getBigDecimal("send_id"));
						return maxList;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<Map<String,BigDecimal>> fetchCadTradesMaxSendId(String assetClass, String msgType,String sdrRepository) {
		
		List<Map<String,BigDecimal>> rsList = jdbcTemplate.query(eodFindCadMaxSendId,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					
			Map<String,BigDecimal> maxList= new HashMap<String,BigDecimal>();
			public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						maxList.put(rs.getString("src_trade_id"),rs.getBigDecimal("send_id"));
						return maxList;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<Map<String,BigDecimal>> fetchEquityCadTradesMaxSendId(String assetClass, String msgType,String sdrRepository) {
		
		List<Map<String,BigDecimal>> rsList = jdbcTemplate.query(eodFindEquityCadMaxSendId,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					
			Map<String,BigDecimal> maxList= new HashMap<String,BigDecimal>();
			public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						maxList.put(rs.getString("src_trade_id"),rs.getBigDecimal("send_id"));
						return maxList;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<EODBufferEmirRecord> fetchEquityEODTradeforCadReport(String assetClass, String msgType, String sdrRepository) {
		List<EODBufferEmirRecord> rsList = jdbcTemplate.query(eodQueryCadGalaxy,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferEmirRecord record = new EODBufferEmirRecord();
						final EODBufferStoreEmir m = new EODBufferStoreEmir();
						m.setUti(rs.getString("uti"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						m.setTradeId(rs.getString("trade_id"));
						m.setInputBufferId(rs.getBigDecimal("input_buffer_id"));
						m.setIsDuplicate(rs.getBoolean("is_duplicate"));
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						
						String tradeDate = rs.getString("src_trade_date");
					
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setSrcTlcEvent(rs.getString("src_tlc_event"));
						record.setSrcTradeStatus(rs.getString("src_trade_status"));
						record.setEodBufferStoreEmir(m);
						record.setTemplateId(rs.getString("template_id"));
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public int removeCADMaturedTrades(String assetClass, String msgType, Date date) 
	{
		String dateString = formatterService.formatDateUTC(date);
		logger.info("Removing matured trades for "+assetClass+":"+msgType+" and Repository : CAD");
		String query="DELETE FROM eod_buffer_store_emir FROM eod_buffer_store_emir ebs, input_msg_store ims where ims.send_id = ebs.send_id and ebs.asset_class = ? and ebs.msg_type = ? and ims.src_mat_date < ?";
		return jdbcTemplate.update(query, assetClass, msgType, dateString);
	
	}

} 