package com.wf.df.sdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wf.df.sdr.dto.BufferStore;

public class HistoricalDataRowMapper implements RowMapper<BufferStore>
{
	@Override
	public BufferStore mapRow(ResultSet rs, int arg1) throws SQLException {
		BufferStore dto = new BufferStore();
		dto.setBufferId( rs.getBigDecimal(1));
		dto.setBufferData( rs.getString( 2 ) );
		dto.setCreateDatetime( rs.getTimestamp(3 ) );
		dto.setBufferSrc(rs.getString(4 ) );
		return dto;
	}
	
}

