package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxVerificationTypeCalc {

	@Calculation(value = Calc.fxVerificationTypeCalc)
	public String compute(
			@DerivedFrom(Stv.ECNTrade) String ecnTrade,
			@DerivedFrom(value = Stv.CalypsoDocStatus, isInternal = true) String calypsoDocStatus) {

		String value = null;

		if (!Utils.IsNullOrBlank(calypsoDocStatus) && (calypsoDocStatus.equals(Constants.TRADE_STATUS_TO_BE_VER)
				|| calypsoDocStatus.equals(Constants.TRADE_STATUS_CH_TO_BE_VER)
				|| calypsoDocStatus.equals(Constants.TRADE_STATUS_ECN_EARLY_RISK))) {
			return "Unverified";
		}else if (ecnTrade != null) {
			if (Constants.TRUE.equalsIgnoreCase(ecnTrade)) {
				value = "Electronic";
			} else
				value = "Unverified";
		}
		return value;

	}

}
