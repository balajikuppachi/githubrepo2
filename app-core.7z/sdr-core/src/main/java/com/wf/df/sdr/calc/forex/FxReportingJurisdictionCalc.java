package com.wf.df.sdr.calc.forex;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class FxReportingJurisdictionCalc {
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxReportingJurisdictionCalc, isPrototype = true)
	public String compute(@DerivedFrom(value = Calc.fxReportingPartyCalc, isInternal = false) boolean isWellsReportingParty,
			@DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable,
			@DerivedFrom(value=Calc.isCadReportableCalc,isInternal = true) boolean isCadReportable,
			@DerivedFrom(value = Stv.Reporting_Jurisdiction, isInternal = true) String diction,
			@DerivedFrom(value = Stv.REPORTING_PARTY_ORIGINAL, isInternal = true) String repo) {
		
		if(isEmirReportable)
			return Constants.ESMA;
		
		if(isCadReportable){
			
			StringBuffer sb =new StringBuffer();
			if(StringUtils.containsIgnoreCase(diction, Constants.CFTC) && !StringUtils.containsIgnoreCase(repo, Constants.CFTC_Them))
				sb.append(Constants.CFTC+";");
			if(StringUtils.containsIgnoreCase(diction, "CAD.ON"))
				sb.append("CA.ON.OSC"+";");
			if(StringUtils.containsIgnoreCase(diction, "CAD.QC"))
				sb.append("CA.QC.AMF"+";");
			if(StringUtils.containsIgnoreCase(diction, "CAD.MB"))
				sb.append("CA.MB.MSC"+";");
			
			String returnString=sb.toString();
			if(returnString.contains(";"))
				returnString=returnString.substring(0,returnString.length()-1);
				
				return returnString;
		}
		if(isWellsReportingParty)
			return Constants.CFTC;
		
		return Constants.EMPTY_STRING;
	
	}
}
