package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.EndurMsgStoreDao;
import com.wf.df.sdr.dto.EndurMsgStore;
import com.wf.df.sdr.exception.dao.EndurMsgStoreDaoException;

public class EndurMsgStoreDaoImpl extends AbstractDAO implements ParameterizedRowMapper<EndurMsgStore>, EndurMsgStoreDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(EndurMsgStore dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?)",
				dto.getTraceId(),dto.getTradeRefId(),dto.getUsi(),dto.getProductId(), dto.getStatus(), dto.getStatusDesc(),
				dto.getConfirmStatus(), dto.getMsgType(),dto.getCreateDatetime(), dto.getBufferId(), dto.getIsWellsSeller());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return EndurMsgStore
	 */
	public EndurMsgStore mapRow(ResultSet rs, int row) throws SQLException
	{
		EndurMsgStore dto = new EndurMsgStore();
		dto.setTraceId(rs.getString(1));
		dto.setTradeRefId(rs.getString(2));
		dto.setUsi(rs.getString(3));
		dto.setProductId(rs.getString(4));
		dto.setStatus(rs.getString(5));
		dto.setStatusDesc(rs.getString(6));
		dto.setConfirmStatus(rs.getString(7));
		dto.setMsgType(rs.getString(8));
		dto.setCreateDatetime(rs.getTimestamp(9));
		dto.setBufferId(rs.getBigDecimal(10));
		dto.setIsWellsSeller(rs.getString(11));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "endur_msg_store";
	}

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria ''.
	 */
	@Transactional
	public List<EndurMsgStore> findAll() throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'trace_id = :trace_id'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereTraceIdEquals(String trace_id) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE trace_id = ? ORDER BY trace_id", this,trace_id);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'trade_ref_id = :trade_ref_id'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereTradeRefIdEquals(String trade_ref_id) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE trade_ref_id = ? ORDER BY trade_ref_id", this,trade_ref_id);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereUsiEquals(String usi) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'product_id = :product_id'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereProductIdEquals(String product_id) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE product_id = ? ORDER BY product_id", this,product_id);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'status = :status'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereStatusEquals(String status) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE status = ? ORDER BY status", this,status);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'status_desc = :status_desc'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereStatusDescEquals(String status_desc) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE status_desc = ? ORDER BY status_desc", this,status_desc);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'confirm_status = :confirm_status'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereConfirmStatusEquals(String confirm_status) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE confirm_status = ? ORDER BY confirm_status", this,confirm_status);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'msg_type = :msg_type'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereMsgTypeEquals(String msg_type) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msg_type);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereCreateDatetimeEquals(Date createDatetime) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Get the latest record for a given sender trader ref id.
	 */
	@Transactional
	public List<EndurMsgStore> findLatestICERecordForTrade(String senderTradeRefId) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE trade_ref_id = ? AND confirm_status in ('PENDING', 'PPENDING', 'MATCHED', 'PMATCHED','UNMATCHED','PCANCELED','CANCELED') ORDER BY create_datetime desc", this,senderTradeRefId);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'buffer_id = :buffer_id'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereBufferIdEquals(BigDecimal buffer_id) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE buffer_id = ? ORDER BY buffer_id", this,buffer_id);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the endur_msg_store table that match the criteria 'is_wells_seller = :is_wells_seller'.
	 */
	@Transactional
	public List<EndurMsgStore> findWhereIsWellsSellerEquals(String isWellsSeller) throws EndurMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT trace_id, trade_ref_id, usi, product_id, status, status_desc, confirm_status, msg_type, create_datetime, buffer_id, is_wells_seller  FROM " + getTableName() + " WHERE is_wells_seller = ? ORDER BY is_wells_seller", this,isWellsSeller);
		}
		catch (Exception e) {
			throw new EndurMsgStoreDaoException("Query failed", e);
		}
		
	}
}
