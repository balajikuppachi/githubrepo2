package com.wf.df.sdr.calc.forex;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxNotationPriceCalc 
{
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value=Calc.fxNotationPriceCalc)
	public String calcNotationPrice(
			@DerivedFrom(value=Stv.FXOptionStrike) String optionStrike,
			@DerivedFrom(value=Stv.FXRateFinalList) List<String> fXRateList,
			@DerivedFrom(value=Calc.dtccProductTypeCalc) String dtccProductType,
			@DerivedFrom(value = Constants.FOREX_SWAP_LEG_INDEX, isInternal = true) Integer swapLegIndex)
	{
		
		if(!Utils.IsNullOrBlank(dtccProductType))
		try {
			if(dtccProductType.equals(Constants.FOREX_OPTION) && !Utils.IsNullOrBlank(optionStrike))
			{	 return formatter.formatDecimal8(parser.parseNumber(optionStrike));
			}else if(dtccProductType.equals(Constants.FOREX_FORWARD) && !Utils.IsListNullOrEmpty(fXRateList))
			{ 
				if(!Utils.IsNullOrBlank(swapLegIndex))
					return formatter.formatDecimal8(parser.parseNumber(fXRateList.get(swapLegIndex)));		
				
				for(int i=0; i<fXRateList.size(); i++){
					if(!Utils.IsNullOrBlank(fXRateList.get(i)))
						return	formatter.formatDecimal8(parser.parseNumber(fXRateList.get(i)));					
					}
				
			}
		} catch (ParseException e) {
			throw new CalculationException("Parse Exception", Stv.FXOptionStrike +" OR "+Stv.FXRateList +" is in wrong format.");
		}
		return Constants.EMPTY_STRING;
	
	}
}
