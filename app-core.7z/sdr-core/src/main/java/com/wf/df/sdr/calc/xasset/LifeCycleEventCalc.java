package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class LifeCycleEventCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	DTCCUtils dtccUtils;
	
	
	@Calculation(value = Calc.lifeCycleEventCalc, isPrototype=false)
	public String calcLifeCycleEvent(
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String tlcEvent,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String srcAssetClass,
			@DerivedFrom(value = Calc.isRateReportedAsForexCalc, isInternal = true) boolean isForex,
			@DerivedFrom(value = Calc.isRateReportedAsCreditCalc, isInternal = true) boolean rateReportsCredit,
			@DerivedFrom(value = Calc.doesEmirBufferExistCalc, isInternal = true) boolean bufferAlreadyExist,
			@DerivedFrom(value = Constants.TradeType123_456, isInternal = true) String tradeType123_456,
			@DerivedFrom(value = Stv.CalypsoDocStatus, isInternal = true) String docStatus,
			@DerivedFrom(value = Calc.sendBackloadCalc, isInternal = true) boolean backload) {
		
		
		logger.debug("calling------------ LifeCycleEventCalc ");
		
		if(backload)
			return Constants.Backload;
		
		//Modify
		if(bufferAlreadyExist) 
			return Constants.LifeCycleEvent_Modify;
		
		
		//Novation cases
		if(StringUtils.containsIgnoreCase(tlcEvent, Constants.Novation))
			return getNovationLC(srcAssetClass, tlcEvent, isForex, rateReportsCredit, tradeType123_456, docStatus);
		
		
		//Undo
		if(StringUtils.containsIgnoreCase(tlcEvent, "Undo"))
			return Constants.LifeCycleEvent_Error;
		
		//Cancellation
		if(StringUtils.containsIgnoreCase(tlcEvent, Constants.Cancellation))
			return Constants.EMPTY_STRING;
		
		
		//Others. Retrieve from domain mapping table
		String lifeCycleEvent = getLceFromDomainMapping(srcAssetClass, tlcEvent, isForex, rateReportsCredit);
		
		if(lifeCycleEvent == null) {
			lifeCycleEvent = Constants.EMPTY_STRING;
		}
		
		return lifeCycleEvent;
	}
	
	private String getLceFromDomainMapping(String srcAssetClass, String tlcEvent, boolean isForex, boolean rateReportsCredit) {
		
		String lifeCycleEvent = Constants.EMPTY_STRING;
		
		if (Constants.ASSET_CLASS_CREDIT.equals(srcAssetClass)) {
			lifeCycleEvent = dtccUtils.getCreditLifeCycleEvent(tlcEvent);
		}
		else if (Constants.ASSET_CLASS_INTEREST_RATE.equals(srcAssetClass)) {
			if(isForex){
				lifeCycleEvent = dtccUtils.getForexLifeCycleEvent(tlcEvent);
			} 
			else if (rateReportsCredit) {
				lifeCycleEvent = dtccUtils.getCreditLifeCycleEvent(tlcEvent);
			}
			else {
				lifeCycleEvent = dtccUtils.getRatesLifeCycleEvent(tlcEvent);
			}
		}
		
		return lifeCycleEvent;
	}
	
	private String getNovationLC(String srcAssetClass, String tlcEvent, boolean isForex, boolean rateReportsCredit,
			String tradeType123_456, String docStatus) {

		if (Constants.NonReportable123.equals(tradeType123_456) && Constants.Novation_RP.equals(tlcEvent)
				&& (Constants.ASSIGNED.equals(docStatus) || Constants.DAY_ASSIGNED.equals(docStatus))) {
			return Constants.Termination;
		}
		
		if (Constants.Reportable456.equals(tradeType123_456) && Constants.PartialNovation_RP.equals(tlcEvent)) {
			return Constants.Termination;
		}
		
		return getLceFromDomainMapping(srcAssetClass, tlcEvent, isForex, rateReportsCredit);
	}
}