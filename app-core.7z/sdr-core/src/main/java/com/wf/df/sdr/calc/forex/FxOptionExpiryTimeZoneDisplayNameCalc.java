package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxOptionExpiryTimeZoneDisplayNameCalc {
	
	@Autowired
	DTCCUtils utils;
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.fxOptionExpiryTimeZoneDisplayNameCalc)
	public String calcTimeZone(
			@DerivedFrom(value=Stv.FXOptionExpiryTimeZoneId) String timeZoneDisplayName)	
			
	{
		if(!Utils.IsNullOrBlank(timeZoneDisplayName) )
		{
			String ret = utils.getTZDisplayName(timeZoneDisplayName);
			if (ret == null)
				return Constants.USNY;
			
		}
		return Constants.USNY;
	}
}
