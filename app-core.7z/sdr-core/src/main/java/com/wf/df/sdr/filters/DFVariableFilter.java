package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component(value="dFVariableFilter")
public class DFVariableFilter {

	@Autowired
	NotEligblePersister nep;
	
	Logger log = Logger.getLogger(getClass());
	
	public boolean isVariableAvailable(UnitOfWork uow)
	{
		
		//String usi=uow.getCalculationContext().getString(Stv.USI_CURRENT);
		String reportingParty=uow.getCalculationContext().getString(Stv.REPORTING_PARTY);
		String sdrEligible=uow.getCalculationContext().getString(Stv.SDR_ELIGIBLE);
		String sdrReportable=uow.getCalculationContext().getString(Stv.SDR_REPORTABLE);
		
		/** Return false, if all four variable values are not available */
		if(/*Utils.IsNullOrBlank(usi) &&*/ Utils.IsNullOrBlank(reportingParty) && Utils.IsNullOrBlank(sdrEligible) && Utils.IsNullOrBlank(sdrReportable))
		{
			log.debug("DFVariableFilter : Mandatory variables are not available");
			nep.save(uow, NotEligblePersister.DFVariableIsNull);
			return false;
		}
			
	
		return true;
	}
}
