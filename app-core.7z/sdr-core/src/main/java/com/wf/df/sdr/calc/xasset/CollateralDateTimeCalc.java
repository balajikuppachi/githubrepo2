package com.wf.df.sdr.calc.xasset;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Utils;

@Component
public class CollateralDateTimeCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.collateralDateTimeCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.currentDateCalc, isInternal = true) Date curDate) {
		
		return formatter.formatDateTimeUTC(Utils.yesterday());	
				
	}
}