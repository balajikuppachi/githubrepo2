package com.wf.df.sdr.calc.xasset;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class SrcAssetClassCalc {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@SuppressWarnings("serial")
	private static Map<String, String> originToAssetClass = new HashMap<String, String>() {{
		put(Constants.MESSAGE_ORIGIN_CALYPSO_CREDIT, Constants.ASSET_CLASS_CREDIT);
		put(Constants.MESSAGE_ORIGIN_CALYPSO_RATES, Constants.ASSET_CLASS_INTEREST_RATE);
		put(Constants.MESSAGE_ORIGIN_GALAXY, Constants.ASSET_CLASS_EQUITY);
		put(Constants.MESSAGE_ORIGIN_SCRITTURA_CREDIT, Constants.ASSET_CLASS_CREDIT);
		put(Constants.MESSAGE_ORIGIN_SCRITTURA_RATES, Constants.ASSET_CLASS_INTEREST_RATE);
		put(Constants.MESSAGE_ORIGIN_SCRITTURA_GALAXY, Constants.ASSET_CLASS_EQUITY);
		put(Constants.MESSAGE_ORIGIN_ENDUR_COMMODITY, Constants.ASSET_CLASS_COMMODITY);
		put(Constants.MESSAGE_ORIGIN_SCRITTURA_ENDUR, Constants.ASSET_CLASS_COMMODITY);
		
	}};
	
	@Calculation(value=Calc.srcAssetClassCalc, isPrototype=false)
	public String assetClassCalc(
			@DerivedFrom(value=Constants.MESSAGE_ORIGIN, isInternal=true) String messageOrigin)
	{
		if (messageOrigin == null) {
			throw new CalculationException("BadOrigin", "Message origin is not set");
		}
		
		String assetClass = originToAssetClass.get(messageOrigin);
		if (assetClass == null) {
			throw new CalculationException("BadOrigin", "Message origin invalid: " + messageOrigin);
		}
		
		return assetClass;
	}
}
