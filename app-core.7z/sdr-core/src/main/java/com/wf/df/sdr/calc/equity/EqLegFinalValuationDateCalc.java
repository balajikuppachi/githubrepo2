package com.wf.df.sdr.calc.equity;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqLegFinalValuationDateCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	FormatterService formatter;
	
	@Autowired
	ParserService parser;
	
	@Calculation(value = Calc.eqLegFinalValuationDateCalc, isPrototype = false)
	public String valuationDate(
			@DerivedFrom(value = Stv.EquityValuationDateList, isInternal = true) List<String> valuationDateList,
			@DerivedFrom(value = Stv.EquityLegValuationFrequencyPeriod, isInternal = true) String equityLegValuationFrequencyPeriod) {

		String dateString = null;
		
		if (!Utils.IsListNullOrEmpty(valuationDateList) && Utils.IsNullOrBlank(equityLegValuationFrequencyPeriod)) {
			
			List<String> dateStringList=new ArrayList<String>();
			try{
				for(String dateStr:valuationDateList)
					dateStringList.add(formatter.formatDateUTC(parser.parseDate(dateStr)));

				return Utils.convertListToDelimitedString(dateStringList, Constants.SEMICOLON);
			}catch (ParseException e) {
				logger.error("Error in EqFinalValuationDateCalc: "+e.getMessage());
				throw new CalculationException("DateNotParsed", "Date string " + dateString	+ " could not be parsed" + Constants.ERROR_MSG_SEPARATOR+e.getMessage());				
			}		
			
		}		
		return null;
		
	}
	
}
