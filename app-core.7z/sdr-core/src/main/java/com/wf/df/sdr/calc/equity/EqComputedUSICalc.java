package com.wf.df.sdr.calc.equity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqComputedUSICalc {
	
	private Logger logger = LoggerFactory.getLogger(getClass());


	@Calculation(value = Calc.eqComputedUSICalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.USI_Current, isInternal = true) String usiCurrent,
			@DerivedFrom(value = Stv.USI_CURRENT, isInternal = true) String usiCURRENT,
			@DerivedFrom(value=Stv.UTI_CURRENT, isInternal = true) String uti,
			@DerivedFrom(value=Calc.isEmirTradeCalc, isInternal = true) boolean isEmirtrade) {
		
		if(isEmirtrade && !Utils.IsNullOrNone(uti)){
			return uti;
		}
		else if (!Utils.IsNullOrNone(usiCURRENT)) {
			return usiCURRENT;
		} else if(!Utils.IsNullOrNone(usiCurrent)){
			return usiCurrent;
		} else {
			logger.info("USINF", "Value of ["+ Stv.USI_CURRENT + "]" + ":" + usiCURRENT + " and ["+ Stv.USI_Current + "]" + ":" + usiCurrent);
			return Constants.EMPTY_STRING;
		}

	}
	
}
