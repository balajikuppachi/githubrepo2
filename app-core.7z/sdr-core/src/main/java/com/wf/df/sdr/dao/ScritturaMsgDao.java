package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.ScritturaMsg;
import com.wf.df.sdr.exception.dao.ScritturaMsgDaoException;

public interface ScritturaMsgDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(ScritturaMsg dto);

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria ''.
	 */
	public List<ScritturaMsg> findAll() throws ScritturaMsgDaoException;

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'id = :id'.
	 */
	public List<ScritturaMsg> findWhereIdEquals(BigDecimal id) throws ScritturaMsgDaoException;

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'cr_id = :crId'.
	 */
	public List<ScritturaMsg> findWhereCrIdEquals(String crId) throws ScritturaMsgDaoException;

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'confirm_datetime = :confirmDatetime'.
	 */
	public List<ScritturaMsg> findWhereConfirmDatetimeEquals(Date confirmDatetime) throws ScritturaMsgDaoException;

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'confirm_platform = :confirmPlatform'.
	 */
	public List<ScritturaMsg> findWhereConfirmPlatformEquals(String confirmPlatform) throws ScritturaMsgDaoException;

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'msg = :msg'.
	 */
	public List<ScritturaMsg> findWhereMsgEquals(String msg) throws ScritturaMsgDaoException;

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'doc_id = :docId'.
	 */
	public List<ScritturaMsg> findWhereDocIdEquals(String docId) throws ScritturaMsgDaoException;

	/** 
	 * Returns all rows from the scrittura_msg table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<ScritturaMsg> findWhereCreateDatetimeEquals(Date createDatetime) throws ScritturaMsgDaoException;

	/** 
	 * Returns count of rows from the scrittura_msg table that match the criteria 'tradeId & tradeVersion'.
	 */
	public Integer findTradeIdCount(String tradeId, String  tradeVersion);
	
	public List<ScritturaMsg> findWhereTradeIdEquals(String tradeId) throws ScritturaMsgDaoException;
}
