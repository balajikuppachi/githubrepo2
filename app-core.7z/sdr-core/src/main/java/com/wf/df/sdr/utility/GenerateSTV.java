package com.wf.df.sdr.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

/**
 * 
 * @author U228102 This class accesses SDR DEV Database, pulls out the latest
 *         version of a trade from input_msg_store table and dumps the
 *         corresponding buffer from buffer_store table into a file.
 */

public class GenerateSTV {
	private static String dbURL = "jdbc:sybase:Tds:170.13.137.164:12000/EMIR";
	private static String tableName = "input_msg_store";
	private static String sendList ="1002807,1002809,1002815,1002817,1002781,1002782,1002806,1002808,1002814,1002816,1002828,1002834,1002851,1002853,1002857,1002867,1002848,1002852,1002854,1002866,1002868,1002870,1002872,1002874,1002876,1002878,1002880,1002882,1002884,1002869,1002871,1002873,1002875,1002877,1002879,1002881,1002883,1002885,1002933,1002972,1002974,1002976,1002886,1002887,1002888,1002889,1002890,1002891,1002892,1002893,1002894,1002895,1002896,1002897,1002898,1002899,1002900,1002901,1002902,1002903,1002904,1002905,1002906,1002907,1002916,1002917,1002918,1002919,1002920,1002921,1002922,1002923,1002924,1002925,1002926,1002927,1002928,1002929,1002930,1002931,1002932,1002934,1002935,1002936,1002937,1002938,1002939,1002940,1002953,1002954,1002973,1002975,1002977,1002987,1002993,1002994,1003020,1003028";
	private static String tradeList = "11449486,11492710,11893412,11526806,10197850,10197840,10206860,11836106,11573897,11446310,11203567";
	private static Connection conn = null;
	private static Statement stmt = null;

	public static void main(String[] args) {
		//tradeId = JOptionPane.showInputDialog("Enter Trade Id :"); // Input
		
		createConnection();
		String[] tradeArr = tradeList.split(Constants.COMMA);
		for(String tradeId : tradeArr){
			selectTradeVersion(tradeId);
		}
		shutdown();
	}

	private static void createConnection() {
		try {
			Class.forName("com.sybase.jdbc3.jdbc.SybDriver").newInstance();
			// Get a connection
			conn = DriverManager.getConnection(dbURL, "sdr_rw", "sdruatrw1");
		} catch (Exception except) {
			except.printStackTrace();
		}
	}

	private static void shutdown() {
		try {
			if (stmt != null) 
				stmt.close();
			if (conn != null) {
				DriverManager.getConnection(dbURL + ";shutdown=true");
				conn.close();
			}
		} catch (SQLException sqlExcept) {

		}
	}
	private static void selectTradeVersion(String tradeId) {
		try {
			stmt = conn.createStatement();
			ResultSet results = stmt.executeQuery("SELECT TOP 1 send_id,src_trade_version,src_system_name,buffer_id FROM "
					+ tableName + " WHERE src_trade_id = '" + tradeId + "' ORDER BY send_id DESC");

			//ResultSetMetaData rsmd = results.getMetaData();
			//int numberCols = rsmd.getColumnCount();
			int selectBufferId = 0;

			while (results.next()) {
				int id = results.getInt("send_id");
				String tradeVersion = results.getString("src_trade_version");
				String sysName = results.getString("src_system_name");
				selectBufferId = results.getInt("buffer_id");

				System.out.println(id + "\t\t" + tradeId+"."+tradeVersion + "\t\t"+ sysName + "\t\t" + selectBufferId);
			}

			String buffer = selectBuffer(selectBufferId);
			if(!Utils.IsNullOrBlank(buffer))
				resendMsg(buffer, tradeId);
				
			results.close();
			stmt.close();
		} catch (SQLException sqlExcept) {
			sqlExcept.printStackTrace();
		}
	}

	
	private static String selectBuffer(int bufferId) {
		try {
			stmt = conn.createStatement();
			ResultSet results = stmt.executeQuery("SELECT buffer_data FROM buffer_store" + " WHERE buffer_id = " + bufferId);

			while (results.next()) {
				return results.getString("buffer_data");
			}
			

		} catch (Exception except) {
			except.printStackTrace();
		}
		return null;
	}

	private static void resendMsg(String bufferData, String tradeId) {
		try {
			
			String fileName = tradeId + ".stv";
			File f = new File(fileName);
			int len = bufferData.length();
			if (!f.exists()) {
				f.createNewFile();
				// f.createTempFile(tradeId, currentTimestamp.toString(), f1);
				FileWriter fstream = new FileWriter(fileName);
				BufferedWriter out = new BufferedWriter(fstream);
				out.write(bufferData, 0, len);
				out.close();
				System.out.println("File created successfully. "+fileName);
			}

			// JOptionPane.showMessageDialog(null, bufferData); //Output
		} catch (Exception except) {
			except.printStackTrace();
		}

	}
}
