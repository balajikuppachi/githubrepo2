package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class ThirdPtyParticipantIdCalc {

	@Calculation(value = Calc.thirdPtyParticipantIdCalc, isPrototype=false)
	public String calculate(
			@DerivedFrom(value = Stv.LEI_THIRD_PARTY, isInternal=true) String participantId)
	{
		String[] leiArray = null;
		if(participantId != null && ((leiArray = participantId.split(Constants.TRANS_ID_SEPARATOR)).length > 1))
				return leiArray[1];
		return null;
		
	}
	
}
