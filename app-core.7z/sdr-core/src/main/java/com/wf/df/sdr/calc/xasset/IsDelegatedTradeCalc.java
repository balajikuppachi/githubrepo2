package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class IsDelegatedTradeCalc {

	@Calculation(value = Calc.isDelegatedTradeCalc, isPrototype = false)
	public boolean compute(
						@DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
						@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade) {
		
		if(isEmirDelegatedTrade || isDtccDelegatedTrade)
			return true;
						
		return false;
	
	}
	
}
