package com.wf.df.sdr.calc.forex;
import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class FxExpirationDateCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;

	@Autowired
	FormatterService formatter;

	@Calculation(value=Calc.fxExpirationDateCalc)
	public String compute(
			@DerivedFrom(Stv.SwaptionExpiryDate) String swaptionExpiryDate,
			@DerivedFrom(Stv.CancellableSwapOptionToDate) String cancellableSwapOptionToDate){

		String expiryDate = null;
		try {
			if(swaptionExpiryDate != null){
				expiryDate = formatter.formatDateUTC(parser.parseDate(swaptionExpiryDate));
			}else if(cancellableSwapOptionToDate != null){
				expiryDate = formatter.formatDateUTC(parser.parseDate(cancellableSwapOptionToDate));
			}

		} catch (ParseException e) {
				logger.error("Error in ExpirationDateCalc: "+e.getMessage());
				throw new CalculationException("DateNotParsed", "Date string " + swaptionExpiryDate	+ " could not be parsed" + Constants.ERROR_MSG_SEPARATOR+e.getMessage());
		}

		return expiryDate;
	}
}
