package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.GalaxyUtil;
import com.wf.df.sdr.util.Stv;


@Component
public class EqFloatingLegDesignatedMaturityPeriodMultiplierCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqFloatingLegDesignatedMaturityPeriodMultiplierCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.FloatingDesignatedMaturity, isInternal = true) String maturityWithPeriod) {
		return GalaxyUtil.getTenorFromString(maturityWithPeriod);
	}
}
