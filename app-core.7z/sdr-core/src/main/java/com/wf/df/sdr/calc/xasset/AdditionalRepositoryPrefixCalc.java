package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class AdditionalRepositoryPrefixCalc {

	@Calculation(value = Calc.additionalRepositoryPrefixCalc, isPrototype = false)
	public String compute (
			@DerivedFrom(value = Calc.isCadReportableCalc, isInternal = true) boolean isCadReportableCalc
			) {
		
		if(isCadReportableCalc){			
			
			return "INTERNAL";
		}			
			
		return Constants.EMPTY_STRING;
	}
}
