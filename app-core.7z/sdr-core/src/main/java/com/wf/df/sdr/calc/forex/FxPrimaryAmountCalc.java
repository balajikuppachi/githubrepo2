package com.wf.df.sdr.calc.forex;

import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxPrimaryAmountCalc {
	
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.fxPrimaryAmountCalc)
	public String calcPrimaryAmt(
			@DerivedFrom(value=Stv.FXOptionPrimaryAmount) String optionFxAmount,
			@DerivedFrom(value=Stv.FXPrimaryAmountList) List<String> fXPrimaryAmountList,
			@DerivedFrom(value = Calc.dtccProductTypeCalc) String dtccProductType,
			@DerivedFrom(value = Constants.FOREX_SWAP_LEG_INDEX, isInternal = true) Integer swapLegIndex)	{
		if(!Utils.IsNullOrBlank(dtccProductType) )
		{
			try {
												
				if(dtccProductType.equals(Constants.FOREX_FORWARD) && !Utils.IsListNullOrEmpty(fXPrimaryAmountList))
				{	
					if(!Utils.IsNullOrBlank(swapLegIndex))
						return formatter.formatDecimal(parser.parseBigDecimal(fXPrimaryAmountList.get(swapLegIndex)).abs());
					
					for(int i=0; i<fXPrimaryAmountList.size(); i++){
						if(!Utils.IsNullOrBlank(fXPrimaryAmountList.get(i)))
							return formatter.formatDecimal(parser.parseBigDecimal(fXPrimaryAmountList.get(i)).abs());
					} 
				}else if(dtccProductType.equals(Constants.FOREX_OPTION) && !Utils.IsNullOrBlank(optionFxAmount)){  	
					return formatter.formatDecimal(parser.parseBigDecimal(optionFxAmount).abs());
				}
			} catch (ParseException e) {
				throw new CalculationException("Parse Exception", Stv.FXOptionPrimaryAmount +" OR "+ Stv.FXPrimaryAmountList + " is in wrong format. ");
			}
		}
		return Constants.EMPTY_STRING;
	}
}
