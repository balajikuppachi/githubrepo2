package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dto.ProductsMapping;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.meta.ProductMapper;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
/**
 * @author U168247
 *
 */
@Component
public class FxProductCalc {

	Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	ProductMapper productMapper;
	
	@Calculation(value = Calc.fxProductCalc, isPrototype = false)
	public String product(
			@DerivedFrom(value = Calc.fxSrcAssetClassCalc, isInternal = true) String srcAssetClass,
			@DerivedFrom(value = Stv.CalypsoProductType, isInternal = true) String calypsoProductType,
			@DerivedFrom(value = Stv.CalypsoProductSubType, isInternal = true) String calypsoProductSubType)
	{
		ProductsMapping isdaProduct = productMapper.getISDAProductValue(srcAssetClass, calypsoProductType, calypsoProductSubType);
		
		if(isdaProduct == null){
			throw new CalculationException("ISDA Product Value","ISDA Product Mapping is null");
		}
		
		StringBuilder sb = new StringBuilder(100);
		sb.append(isdaProduct.getDtccAssetClass()).append(Constants.COLON).append(isdaProduct.getDtccProdType());
		
		return sb.toString();
		
	}
}