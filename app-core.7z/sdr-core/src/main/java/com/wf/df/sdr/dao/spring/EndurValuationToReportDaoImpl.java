package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.EndurValuationToReportDao;
import com.wf.df.sdr.dto.EndurValuationToReport;

public class EndurValuationToReportDaoImpl extends AbstractDAO implements ParameterizedRowMapper<EndurValuationToReport>, EndurValuationToReportDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(EndurValuationToReport dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( recv_id, file_name, trade_ref_id, create_datetime ) VALUES ( ?, ?, ?, ?)",
				dto.getRecvId(), dto.getFileName(), dto.getTradeRefId(), dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return EndurValuationToReport
	 */
	public EndurValuationToReport mapRow(ResultSet rs, int row) throws SQLException
	{
		EndurValuationToReport dto = new EndurValuationToReport();
		dto.setRecvId(rs.getBigDecimal(1));
		dto.setFileName(rs.getString(2));
		dto.setTradeRefId(rs.getString(3));
		dto.setCreateDatetime( rs.getTimestamp(4));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "endur_valuation_to_report";
	}
}
