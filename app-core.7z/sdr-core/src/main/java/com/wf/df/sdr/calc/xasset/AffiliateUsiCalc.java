package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class AffiliateUsiCalc {

	@Autowired
	DTCCUtils dtccUtil;
	
	@Calculation(value = Calc.affiliateUsiCalc, isPrototype = false)
	public String usi (
			@DerivedFrom(value = Calc.computedUSICalc, isInternal = true) String usi,
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliateTrade,
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String tradeId) {
		
		if(isAffiliateTrade){			
			return dtccUtil.getDtccUsiFromTradeId(tradeId);			
		}			
			
		return Constants.EMPTY_STRING;
	}
	
}