package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class HasFeeTradeEmbeddedCalc {

	Logger logger = Logger.getLogger(this.getClass());

/*	@Value("${sourcesystems.Credit}")
	private String srcSystemCredit;*/

	@Calculation(value = Calc.hasFeeTradeEmbeddedCalc, isPrototype = false)
	public boolean calculate(
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String srcAssetClass,
			@DerivedFrom(value = Calc.crWachoviaNovationRoleCalc, isInternal = true) String wachoviaRole,
			@DerivedFrom(value = Stv.FEE_USI_CURRENT, isInternal = true) String feeUSI,
			@DerivedFrom(value = Stv.FEE_REPORTING_PARTY, isInternal = true) String feeRP,
			@DerivedFrom(value = Stv.LEI_THIRD_PARTY, isInternal = true) String feeCounterParty) {
		
		if (!Utils.IsNullOrNone(wachoviaRole) 
				&& !Utils.IsNullOrNone(srcAssetClass)
				&& !Utils.IsNullOrNone(feeUSI)
				&& !Utils.IsNullOrNone(feeRP)
				&& !Utils.IsNullOrNone(feeCounterParty)) {
			// Check if its a credit Novation and the role is OR / EE
			if (StringUtils.containsIgnoreCase( Constants.ASSET_CLASS_CREDIT, srcAssetClass)
					&& (Constants.WachoviaRole_OR.equals(wachoviaRole) || Constants.WachoviaRole_EE.equals(wachoviaRole))) {
								
				return true;
			}
		}
		return false;
	}
}
