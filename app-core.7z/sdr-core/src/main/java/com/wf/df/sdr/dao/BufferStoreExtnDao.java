package com.wf.df.sdr.dao;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BufferStoreExtnDao 
{
	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Value("${lookup.stv.buffer.usi.query}") private String bufferLookUpQuery;
	
	public Long findMaxBufferIdInRange(Long from, Long to) {
		List<Long> maxIdList = jdbcTemplate.queryForList("SELECT MAX(buffer_id) FROM buffer_store WHERE buffer_id >= ? AND buffer_id <= ?", Long.class, from, to);
		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null) {
			return null;
		} else {
			return maxIdList.get(0);
		}
	}
	
	public Map<String,Object> findStvBufferForUsi(String usi)
	{
		Map<String,Object> bufferListMap  = jdbcTemplate.queryForMap(bufferLookUpQuery,new String[]{  usi, usi});
		if (bufferListMap == null || bufferListMap.isEmpty() || bufferListMap.get("buffer_data") == null) {
			return null;
		} else {
			return bufferListMap;
		}
		
	}

	public Map<String,Object> findLatestStvBufferForTradeId(String msgType, String assetClass, String usi,String sdrRepo) {
		String query = "select send_id,buffer_data from buffer_store b,input_msg_store i where i.buffer_id=b.buffer_id and b.buffer_id = ("+
		"select max(buffer_id) from input_msg_store where src_trade_id in "+ 
		"(select ims.src_trade_id from input_msg_store ims , not_reportable_msg_store nrm where ims.send_id=nrm.send_id and  nrm.asset_class = ? and nrm.usi = ? and ims.sdr_repository = ?))";
		
		Map<String,Object> bufferListMap = jdbcTemplate.queryForMap(query, new String[]{ assetClass, usi,sdrRepo});
		if (bufferListMap == null || bufferListMap.isEmpty() ||  bufferListMap.get("buffer_data") == null) {
			return null;
		} else {
			return bufferListMap;
		}
	}
}
