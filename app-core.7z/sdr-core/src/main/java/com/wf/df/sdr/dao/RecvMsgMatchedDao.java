package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.RecvMsgMatchedDao;
import com.wf.df.sdr.dto.RecvMsgMatched;
import com.wf.df.sdr.exception.dao.RecvMsgMatchedDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface RecvMsgMatchedDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(RecvMsgMatched dto);

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria ''.
	 */
	public List<RecvMsgMatched> findAll() throws RecvMsgMatchedDaoException;

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'recv_id = :recvId'.
	 */
	public List<RecvMsgMatched> findWhereRecvIdEquals(BigDecimal recvId) throws RecvMsgMatchedDaoException;

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'msg_type = :msgType'.
	 */
	public List<RecvMsgMatched> findWhereMsgTypeEquals(String msgType) throws RecvMsgMatchedDaoException;

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'usi = :usi'.
	 */
	public List<RecvMsgMatched> findWhereUsiEquals(String usi) throws RecvMsgMatchedDaoException;

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'send_id = :sendId'.
	 */
	public List<RecvMsgMatched> findWhereSendIdEquals(BigDecimal sendId) throws RecvMsgMatchedDaoException;

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'match_status = :matchStatus'.
	 */
	public List<RecvMsgMatched> findWhereMatchStatusEquals(String matchStatus) throws RecvMsgMatchedDaoException;

	/** 
	 * Returns all rows from the recv_msg_matched table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<RecvMsgMatched> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvMsgMatchedDaoException;

}
