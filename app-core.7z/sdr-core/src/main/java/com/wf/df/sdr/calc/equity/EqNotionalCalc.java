package com.wf.df.sdr.calc.equity;

import java.math.BigDecimal;
import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.TradeAttributesDao;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqNotionalCalc {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	ParserService parser;	
	@Autowired
	FormatterService formatter;
	@Autowired
	TradeAttributesDao dao;
	
	@Calculation(value = Calc.eqNotionalCalc, isPrototype = false)
	public String notional(
			@DerivedFrom(value = Stv.EquityNotionalAmount, isInternal = true) String equityNotional,
			@DerivedFrom(value = Calc.eqVegaNotionalTotalAmountCalc, isInternal = true) String vegaNotional,
			@DerivedFrom(value = Calc.templateCalc, isInternal = true) String templateName,
			@DerivedFrom(value = Stv.NumberOfOptions, isInternal = true) String numberOfOptions ){	
			
		if(Utils.IsNullOrBlank(equityNotional) && Utils.IsNullOrBlank(vegaNotional))
			return Constants.EMPTY_STRING;		
		
		if(Constants.EqTemplate_VS.equals(templateName))
			return vegaNotional;

		if(Constants.EqTemplate_OPT.equals(templateName) && Utils.IsNullOrBlank(numberOfOptions))
		      return Constants.EMPTY_STRING;
		
		if(Constants.EqTemplate_StructuredProduct.equals(templateName))
		      return Constants.EMPTY_STRING;

		try {
			BigDecimal bd = parser.parseBigDecimal(equityNotional);
			bd = bd.abs();
			return formatter.formatDecimalDEC(bd);
		} catch (ParseException e) {
			logger.error("Error in EqNotionalCalc: "+e.getMessage());
			throw new CalculationException("AmountNotParsed", "Notional Amount string " + equityNotional	+ " could not be parsed" + Constants.ERROR_MSG_SEPARATOR+e.getMessage());				
		}
				
	}
	
		
}
