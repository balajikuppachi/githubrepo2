package com.wf.df.sdr.calc.commodity;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class CmResponseMessage {

	private String boStatus;
	private String boStatusDesc;
	private String boConfirmBuyerIndex;
	private String boConfirmSellerIndex;
	private String boConfirmReferencePrice;
	private String recvXml;
	private Map<String,String> errors = new HashMap<String, String>();
	private String sendId;
	private String tradeId;
	private BigDecimal bufferId;		

	// For Non ACK NAK and ACK NAK responses
	private String traceId;
	private String tradeRefId;
	private String usi;
	private String productId;
	private String status;	
	private String statusDesc;	
	private String confirmStatus;	
	private String msgType;
	private String creationTimestamp;
	
	private String seller;
	private String broker;
	private String tradeDate;
	private String buyerUsRegulatoryDesignation;
	private String usReportingEntityContinuationData;
	private String usReportingEntityPetData;
	private String counterPartyStatus;
	private String usReportingEntityValuationData;	
	private String sellerUsRegulatoryDesignation;
	private String buyer;
	
	private String counterPartyStatusDate;
	private String submissionCompany;
	private String sellerLEI;
	private String firstReportedSDR;	
	private String type;
	private String code;
	private String statusDate;
	
	// Required for msg_to_report and msg_status
	private String assetClass;
	private String prevUsi;
	
	//check for amend
	private boolean ammendCheck;
	//if amend then new buffer comes here
	private String dataToSend;
	
	
	
	
	
	public String getDataToSend() {
		return dataToSend;
	}
	public void setDataToSend(String newDataToSend) {
		this.dataToSend = newDataToSend;
	}
	public boolean isAmmendCheck() {
		return ammendCheck;
	}
	public void setAmmendCheck(boolean ammendCheck) {
		this.ammendCheck = ammendCheck;
	}
	
	public String getRecvXml() {
		return recvXml;
	}	
	public void setRecvXml(String recvXml) {
		this.recvXml = recvXml;
	}
	
	public void addErrors(String key, String value){
		errors.put(key, value);
	}
	public Map<String, String> getErrors() {
		return errors;
	}
	
	public String getSendId() {
		return sendId;
	}
	public void setSendId(String sendId) {
		this.sendId = sendId;
	}
	
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public BigDecimal getBufferId() {
		return bufferId;
	}
	public void setBufferId(BigDecimal bufferId) {
		this.bufferId = bufferId;
	}
	
	public String getBoStatus() {
		return boStatus;
	}
	public void setBoStatus(String boStatus) {
		this.boStatus = boStatus;
	}
	
	public String getBoStatusDesc() {
		return boStatusDesc;
	}
	public void setBoStatusDesc(String boStatusDesc) {
		this.boStatusDesc = boStatusDesc;
	}
	
	public String getBoConfirmBuyerIndex() {
		return boConfirmBuyerIndex;
	}
	
	public void setBoConfirmBuyerIndex(String boConfirmBuyerIndex) {
		this.boConfirmBuyerIndex = boConfirmBuyerIndex;
	}
	
	public String getBoConfirmSellerIndex() {
		return boConfirmSellerIndex;
	}
	
	public void setBoConfirmSellerIndex(String boConfirmSellerIndex) {
		this.boConfirmSellerIndex = boConfirmSellerIndex;
	}
	
	public String getBoConfirmReferencePrice() {
		return boConfirmReferencePrice;
	}
	
	public void setBoConfirmReferencePrice(String boConfirmReferencePrice) {
		this.boConfirmReferencePrice = boConfirmReferencePrice;
	}
	public String getTraceId() {
		return traceId;
	}
	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getCreationTimestamp() {
		return creationTimestamp;
	}
	public void setCreationTimestamp(String creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTradeRefId() {
		return tradeRefId;
	}
	public void setTradeRefId(String tradeRefId) {
		this.tradeRefId = tradeRefId;
	}
	public String getUsi() {
		return usi;
	}
	public void setUsi(String usi) {
		this.usi = usi;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getConfirmStatus() {
		return confirmStatus;
	}
	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getBroker() {
		return broker;
	}
	public void setBroker(String broker) {
		this.broker = broker;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public String getBuyerUsRegulatoryDesignation() {
		return buyerUsRegulatoryDesignation;
	}
	public void setBuyerUsRegulatoryDesignation(String buyerUsRegulatoryDesignation) {
		this.buyerUsRegulatoryDesignation = buyerUsRegulatoryDesignation;
	}
	public String getUsReportingEntityContinuationData() {
		return usReportingEntityContinuationData;
	}
	public void setUsReportingEntityContinuationData(
			String usReportingEntityContinuationData) {
		this.usReportingEntityContinuationData = usReportingEntityContinuationData;
	}
	public String getUsReportingEntityPetData() {
		return usReportingEntityPetData;
	}
	public void setUsReportingEntityPetData(String usReportingEntityPetData) {
		this.usReportingEntityPetData = usReportingEntityPetData;
	}
	public String getCounterPartyStatus() {
		return counterPartyStatus;
	}
	public void setCounterPartyStatus(String counterPartyStatus) {
		this.counterPartyStatus = counterPartyStatus;
	}
	public String getUsReportingEntityValuationData() {
		return usReportingEntityValuationData;
	}
	public void setUsReportingEntityValuationData(
			String usReportingEntityValuationData) {
		this.usReportingEntityValuationData = usReportingEntityValuationData;
	}
	public String getSellerUsRegulatoryDesignation() {
		return sellerUsRegulatoryDesignation;
	}
	public void setSellerUsRegulatoryDesignation(
			String sellerUsRegulatoryDesignation) {
		this.sellerUsRegulatoryDesignation = sellerUsRegulatoryDesignation;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public String getCounterPartyStatusDate() {
		return counterPartyStatusDate;
	}
	public void setCounterPartyStatusDate(String counterPartyStatusDate) {
		this.counterPartyStatusDate = counterPartyStatusDate;
	}
	public String getSubmissionCompany() {
		return submissionCompany;
	}
	public void setSubmissionCompany(String submissionCompany) {
		this.submissionCompany = submissionCompany;
	}
	public String getSellerLEI() {
		return sellerLEI;
	}
	public void setSellerLEI(String sellerLEI) {
		this.sellerLEI = sellerLEI;
	}
	public String getFirstReportedSDR() {
		return firstReportedSDR;
	}
	public void setFirstReportedSDR(String firstReportedSDR) {
		this.firstReportedSDR = firstReportedSDR;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getStatusDate() {
		return statusDate;
	}
	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getPrevUsi() {
		return prevUsi;
	}
	public void setPrevUsi(String prevUsi) {
		this.prevUsi = prevUsi;
	}
	
}
