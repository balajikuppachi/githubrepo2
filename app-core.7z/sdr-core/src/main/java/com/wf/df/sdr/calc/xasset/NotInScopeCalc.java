package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class NotInScopeCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value=Calc.notInScopeCalc, isPrototype=false)
	public String notInScope() {
		
		// for now use the Product Mapping asset class itself. 
		return Constants.EMPTY_STRING;
	}
}
