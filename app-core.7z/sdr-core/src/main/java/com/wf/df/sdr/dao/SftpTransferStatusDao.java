package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.SftpTransferStatusDao;
import com.wf.df.sdr.dto.SftpTransferStatus;
import com.wf.df.sdr.exception.dao.SftpTransferStatusDaoException;

import java.util.Date;
import java.util.List;

public interface SftpTransferStatusDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(SftpTransferStatus dto);

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria ''.
	 */
	public List<SftpTransferStatus> findAll() throws SftpTransferStatusDaoException;

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<SftpTransferStatus> findWhereCreateDatetimeEquals(Date createDatetime) throws SftpTransferStatusDaoException;

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'fq_filename = :fqFilename'.
	 */
	public List<SftpTransferStatus> findWhereFqFilenameEquals(String fqFilename) throws SftpTransferStatusDaoException;

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'status = :status'.
	 */
	public List<SftpTransferStatus> findWhereStatusEquals(String status) throws SftpTransferStatusDaoException;

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'direction = :direction'.
	 */
	public List<SftpTransferStatus> findWhereDirectionEquals(String direction) throws SftpTransferStatusDaoException;

}
