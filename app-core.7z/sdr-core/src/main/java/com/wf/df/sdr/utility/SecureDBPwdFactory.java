package com.wf.df.sdr.utility;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
public class SecureDBPwdFactory {


    private static final Logger LOG = Logger.getLogger(SecureDBPwdFactory.class);

    @Value("${sdr.dataSource.password.security.enabled}")
    private boolean encryptionEnabled;
    private String passPhrase = null;
    private String password = null;

    private SecureDBPwdHelper pwdHelper;

    public void setEncryptionEnabled(final boolean encryptionEnabled) 
    {
        this.encryptionEnabled = encryptionEnabled;
    }

    public void setPassPhrase(final String passPhrase) 
    {
        this.passPhrase = passPhrase;
    }

    public void setPassword(final String password) 
    {
        this.password = password;
    }

    public void init() 
    {
        LOG.info("SecureDBPwdFactory is being initialised with encryptionEnabled: " + encryptionEnabled);
        
        if (encryptionEnabled) 
        {
            LOG.info("Instatiating instance of password encoder, passphrase was " + (passPhrase == null ? "not provided" : "provided"));
            pwdHelper = new SecureDBPwdHelper(passPhrase);
        }
    }

    public String getPassword() 
    {
    	String returnPassword = "";
    	if (encryptionEnabled) 
        {
            LOG.debug("Returning decrypted password...");
            returnPassword = pwdHelper.decrypt(password);
        }
    	else {
    		LOG.debug("Returning password without decryption...");
    		returnPassword = password;
    	}
        
        
        return returnPassword;
    }
    
    public String getPassword(String passwordToDecrypt) 
    {
        String returnPassword = "";
    	if (encryptionEnabled) 
        {
            LOG.debug("Returning decrypted password...");
            returnPassword = pwdHelper.decrypt(passwordToDecrypt); 
            
        }
    	else {
    		LOG.debug("Returning password without decryption...");
    		returnPassword = passwordToDecrypt;
    	}
        
        
        return returnPassword;
    }

}
