package com.wf.df.sdr.calc.emir;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.DTCCUtils;

@Component
public class EmirDelegatedFieldsValueCalc {

	@Autowired
	DTCCUtils dtccUtils;
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.emirDelegatedFieldsValueCalc)
		public String compute(
			@DerivedFrom(value = "party1Value") String party1Value,
			@DerivedFrom(value = "party2Value") String party2Value,
			@DerivedFrom(value = Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegated)
			 {
		
		if (isEmirDelegated) {
			return party2Value;
		} else {
			return party1Value;
		}

	}
}
