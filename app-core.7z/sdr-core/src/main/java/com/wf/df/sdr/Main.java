package com.wf.df.sdr;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Main {	

	private Main() {
	}

	Logger logger = LoggerFactory.getLogger(Main.class);

	public static void main(final String... args) {
		//System.setProperty("javax.net.ssl.keyStore","C:/SDR_HOME/sdr/src/main/resources/config/2ECT.CLIENT.jks");
		//System.setProperty("javax.net.ssl.keyStore","/home/calypso_qa/Calypso/cdcbqa/sdr/config/2ECT.CLIENT.jks");
		//System.setProperty("javax.net.ssl.keyStorePassword","2ECTClient");
		new SDRApp().launchSDR();		
		
	}
	
}
