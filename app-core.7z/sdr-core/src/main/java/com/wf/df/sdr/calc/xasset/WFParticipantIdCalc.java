package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class WFParticipantIdCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	
	@Calculation(value= Calc.wfParticipantIdCalc, isPrototype = false)
	public String wFPartyCalc(
			@DerivedFrom(value = Stv.DTCCOurParticipantId, isInternal = true) String participantId,
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String wellsFargoLEI,			
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass)	{
		
		if (!Utils.IsNullOrNone(wellsFargoLEI)) {
			String lei =  (StringUtils.substringAfter(wellsFargoLEI, Constants.COLON));
			return lei.startsWith(Constants.DTCC)?lei.substring(4):lei;
		}
	
		if(!Utils.IsNullOrNone(participantId) && participantId.startsWith(Constants.DTCC)) 	
			return participantId.substring(4);
		
		throw new CalculationException("LEIFNF", "Fields not defined : [" + Stv.LEI_US + "] and [" + Stv.DTCCOurParticipantId + "]");
	}			
}
