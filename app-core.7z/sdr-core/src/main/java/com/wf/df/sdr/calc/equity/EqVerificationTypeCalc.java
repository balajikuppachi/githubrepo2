package com.wf.df.sdr.calc.equity;

import org.apache.commons.lang.WordUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqVerificationTypeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqVerificationTypeCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.VerificationType, isInternal = true) String vType) {
		char delimit[]  = {'-', ' ', '.' };
		if (!Utils.IsNullOrNone(vType)) {
			String temp =  WordUtils.capitalizeFully(vType,delimit);
			return org.apache.commons.lang.StringUtils.remove(temp, Constants.HYPHEN);
		}
		return Constants.Unverified; 
	}
}
