package com.wf.df.sdr.calc.equity;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.TradeAttributesDao;
import com.wf.df.sdr.dto.TradeAttributes;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqLifecycleChangeInDealNotionalCalc {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	ParserService parser;	
	@Autowired
	FormatterService formatter;
	@Autowired
	TradeAttributesDao dao;
	
	@Calculation(value = Calc.eqLifecycleChangeInDealNotionalCalc, isPrototype = false)
	public String notional(
			@DerivedFrom(value = Calc.eqComputedUSICalc, isInternal = true) String usi,
			@DerivedFrom(value = Stv.EquityNotionalAmount, isInternal = true) String equityNotional){	
			
		if(Utils.IsNullOrBlank(equityNotional))
			return Constants.EMPTY_STRING;
				
		return getChangeInNotional(equityNotional, usi);				
						
	}	
	
	private String getChangeInNotional(String current, String usi) {
		String ret = current;
		List<TradeAttributes> trade = dao.findPreviousRecordsForUSI(usi, Constants.ASSET_CLASS_EQUITY);
		if (trade.size() > 0) {
			String original = trade.get(0).getNotionalAmount();
			try {
				
				BigDecimal change = Utils.subtractNumberString(current, original);
				return formatter.formatDecimalDEC(change);
				
			} catch (Exception ee) {
				logger.info("Remaining Notional Failed, Returning the value as is.", ee);
			}
		}
		return formatter.parseAndFormatNumber(ret);
	}
	
	
	
}
