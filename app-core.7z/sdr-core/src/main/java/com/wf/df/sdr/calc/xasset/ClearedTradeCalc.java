package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class ClearedTradeCalc {
	@Value("${valuation.rp}") private String valuationRP;
	/*@Value("${snapshot.rp}") private String snapshotRP;
	@Value("${clearingHouse.rp}") private String clearingHouseRP;
	*/
	Logger logger = Logger.getLogger(this.getClass());

	
	@Calculation(value = Calc.clearedTradeCalc, isPrototype = false)
	public boolean isReportingPartyValid(
			@DerivedFrom(value = Stv.FCM_CPTY, isInternal = true) String fcmCpty,
			@DerivedFrom(value = Stv.FEE_FCM_CPTY, isInternal = true) String feeFCMCpty,
			@DerivedFrom(value = Stv.CC_ClearingTradeId, isInternal = true) String clearingTradeId,
			@DerivedFrom(value = Stv.LEI_CP, isInternal = true) String cpLEI,
			@DerivedFrom(value = Stv.KW_CCPClearedDate, isInternal = true) String clearingDateTime,
			@DerivedFrom(value = Stv.KW_CCPTradeID, isInternal = true) String ccpTradeID,
			@DerivedFrom(value = Stv.KW_CCP, isInternal = true) String ccp,
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String marketType,
			@DerivedFrom(value = Stv.CC_ClearingHouse, isInternal = true) String clearingHouse) {
		
		
		
		if(!Utils.IsNullOrBlank(clearingDateTime))
			return true;
		
		if(!Utils.IsNullOrBlank(ccpTradeID))
			return true;

		/** STR-492	CME Valuations should be suppressed using LEI KWD instead of CC_ClearingHouse KWD*/
		String cpLeiValue=Utils.getElementAtIndex(cpLEI, 1, Constants.COLON);
		if(!Utils.IsNullOrBlank(cpLeiValue) && StringUtils.contains(valuationRP, cpLeiValue))
			return true;
	
		
		/*
		if(!Utils.IsNullOrBlank(clearingDateTime))
			return true;
		
		if(!Utils.IsNullOrBlank(ccpTradeID))
			return true;
		
		if(Constants.TRUE.equalsIgnoreCase(feeFCMCpty) || Constants.TRUE.equalsIgnoreCase(fcmCpty)|| StringUtils.contains(clearingHouseRP, clearingHouse))
			return true;
		
		if(!Utils.IsNullOrBlank(cpLEI) && StringUtils.contains(valuationRP, cpLEI)){
			return true;
		}
		for(String lei : snapshotRP.split(","))
		{
			if(StringUtils.contains(cpLEI,lei)){
			return true;
		}
			}
	   */
		return false;
	}
}
