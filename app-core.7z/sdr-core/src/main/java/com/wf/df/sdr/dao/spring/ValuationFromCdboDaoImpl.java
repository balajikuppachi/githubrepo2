package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.ValuationFromCdboDao;
import com.wf.df.sdr.dto.ValuationFromCdbo;
import com.wf.df.sdr.exception.dao.ValuationFromCdboDaoException;

public class ValuationFromCdboDaoImpl extends AbstractDAO implements ParameterizedRowMapper<ValuationFromCdbo>, ValuationFromCdboDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(ValuationFromCdbo dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,?)",dto.getFoTradeId(),dto.getSourceSystem(),dto.getStatus(),dto.getNpvValue(),dto.getNpvDate(),dto.getNpvCurrrency(),dto.getNotionalCurrent(),dto.getPayNotional(),dto.getRecvNotional(),dto.getPayCurrency(),dto.getRecvCurrency());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return ValuationFromCdbo
	 */
	public ValuationFromCdbo mapRow(ResultSet rs, int row) throws SQLException
	{
		ValuationFromCdbo dto = new ValuationFromCdbo();
		dto.setFoTradeId( rs.getString( 1 ) );
		dto.setSourceSystem( rs.getString( 2 ) );
		dto.setStatus( rs.getString( 3 ) );
		dto.setNpvValue( rs.getBigDecimal(4));
		dto.setNpvDate( rs.getTimestamp(5 ) );
		dto.setNpvCurrrency( rs.getString( 6 ) );
		dto.setNotionalCurrent( rs.getString( 7 ) );
		dto.setPayNotional( rs.getString( 8 ) );
		dto.setRecvNotional( rs.getString( 9 ) );
		dto.setPayCurrency( rs.getString( 10 ) );
		dto.setRecvCurrency( rs.getString( 11 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "valuation_from_cdbo";
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria ''.
	 */
	@Transactional
	public List<ValuationFromCdbo> findAll() throws ValuationFromCdboDaoException
	{
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'fo_trade_id = :foTradeId'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereFoTradeIdEquals(String foTradeId) throws ValuationFromCdboDaoException
	{
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE fo_trade_id = ? ORDER BY fo_trade_id", this,foTradeId);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'source_system = :sourceSystem'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereSourceSystemEquals(String sourceSystem) throws ValuationFromCdboDaoException
	{
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE source_system = ? ORDER BY source_system", this,sourceSystem);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'status = :status'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereStatusEquals(String status) throws ValuationFromCdboDaoException
	{
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE status = ? ORDER BY status", this,status);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'npv_value = :npvValue'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereNpvValueEquals(BigDecimal npvValue) throws ValuationFromCdboDaoException
	{
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE npv_value = ? ORDER BY npv_value", this,npvValue);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'npv_date = :npvDate'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereNpvDateEquals(Date npvDate) throws ValuationFromCdboDaoException
	{
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE npv_date = ? ORDER BY npv_date", this,npvDate);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'npv_currrency = :npvCurrrency'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereNpvCurrrencyEquals(String npvCurrrency) throws ValuationFromCdboDaoException
	{
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE npv_currrency = ? ORDER BY npv_currrency", this,npvCurrrency);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}
	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'notional_current = :notionalCurrent'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereNotionalCurrentEquals(String notionalCurrent) throws ValuationFromCdboDaoException {
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE notional_current = ? ORDER BY notional_current", this,notionalCurrent);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'pay_notional = :payNotional'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWherePayNotionalEquals(String payNotional)throws ValuationFromCdboDaoException {
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional ,pay_currency,recv_currency FROM " + getTableName() + " WHERE pay_notional = ? ORDER BY pay_notional", this,payNotional);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'recv_notional = :recvNotional'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereRecvNotionalEquals(	String recvNotional) throws ValuationFromCdboDaoException {
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE recv_notional = ? ORDER BY recv_notional", this,recvNotional);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'pay_Currency = :payCurrency'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWherePayCurrencyEquals(String payCurrency)throws ValuationFromCdboDaoException {
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional ,pay_currency,recv_currency FROM " + getTableName() + " WHERE pay_currency = ? ORDER BY pay_currency", this,payCurrency);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the valuation_from_cdbo table that match the criteria 'recv_Currency = :recvCurrency'.
	 */
	@Transactional
	public List<ValuationFromCdbo> findWhereRecvCurrencyEquals(	String recvCurrency) throws ValuationFromCdboDaoException {
		try {
			return jdbcTemplate.query("SELECT fo_trade_id, source_system, status, npv_value, npv_date, npv_currrency,notional_current, pay_notional, recv_notional,pay_currency,recv_currency FROM " + getTableName() + " WHERE recv_currency = ? ORDER BY recv_currency", this,recvCurrency);
		}
		catch (Exception e) {
			throw new ValuationFromCdboDaoException("Query failed", e);
		}
		
	}

}
