package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class FxCalypsoTransactionTypeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	DTCCUtils dtccUtils;

	@Calculation(value = Calc.fxCalypsoTransactionTypeCalc, isPrototype = false)
	public String transactionType(
			@DerivedFrom(value = Calc.calypsoTransactionTypeCalc, isInternal = true) String transactionType,
			@DerivedFrom(value = Stv.CalypsoDocStatus, isInternal = true) String calypsoDocStatus,
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String tlcEvent,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType)
	{
		//For Snapshot
		if(Constants.MESSAGE_TYPE_SNAPSHOT.equals(msgType) &&  
				(Constants.Cancellation.equalsIgnoreCase(tlcEvent) || Constants.TRADE_STATUS_EXERCISED.equals(calypsoDocStatus)))
			return Constants.Exit;
		
		//For Snapshot
		if(Constants.MESSAGE_TYPE_SNAPSHOT.equals(msgType) && 
				(Constants.Termination_Voluntary.equalsIgnoreCase(tlcEvent) || Constants.Termination_Involuntary.equalsIgnoreCase(tlcEvent)) )
			if(Constants.TRADE_STATUS_TOBE_VER.equals(calypsoDocStatus) || Constants.TRADE_STATUS_PRE_BOOKED.equals(calypsoDocStatus)) 
					return Constants.Exit;
		
		//for non Snapshot & Valuation
		if(Constants.TRADE_STATUS_EXERCISED.equals(calypsoDocStatus))
			return Constants.Exercise;
		
		return transactionType;

	}
}	
