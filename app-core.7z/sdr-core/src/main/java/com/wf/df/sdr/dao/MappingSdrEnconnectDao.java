package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MappingSdrEnconnect;
import com.wf.df.sdr.exception.dao.MappingSdrEnconnectDaoException;

public interface MappingSdrEnconnectDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(MappingSdrEnconnect dto);

	/** 
	 * Returns all rows from the sdr_enconnect_mapping table that match the criteria ''.
	 */
	public List<MappingSdrEnconnect> findAll() throws MappingSdrEnconnectDaoException;

	/** 
	 * Returns all rows from the sdr_enconnect_mapping table that match the criteria 'send_id = :send_id'.
	 */
	public List<MappingSdrEnconnect> findWhereSendIdEquals(BigDecimal send_id) throws MappingSdrEnconnectDaoException;

	/** 
	 * Returns all rows from the sdr_enconnect_mapping table that match the criteria 'trace_id = :trace_id'.
	 */
	public List<MappingSdrEnconnect> findWhereTraceIdEquals(String trace_id) throws MappingSdrEnconnectDaoException;

	/** 
	 * Returns all rows from the sdr_enconnect_mapping table that match the criteria 'status = :status'.
	 */
	public List<MappingSdrEnconnect> findWhereStatusEquals(String status) throws MappingSdrEnconnectDaoException;

	/** 
	 * Returns all rows from the sdr_enconnect_mapping table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MappingSdrEnconnect> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingSdrEnconnectDaoException;
	
	/** 
	 * Returns all rows from the sdr_enconnect_mapping table that match the criteria 'buffer_id = :buffer_id'.
	 */
	public List<MappingSdrEnconnect> findWhereBufferIdEquals(BigDecimal buffer_id) throws MappingSdrEnconnectDaoException;
	
	/** 
	 * Returns all rows from the sdr_enconnect_mapping table that match the criteria 'msg_type = :msg_type'.
	 */
	public List<MappingSdrEnconnect> findWhereMsgTypeEquals(String msgType) throws MappingSdrEnconnectDaoException;

}
