package com.wf.df.sdr.calc.equity;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.GalaxyUtil;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqProcessTimeCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	FormatterService format;

	@Calculation(value = Calc.eqProcessTimeCalc, isPrototype = false)
	public String buyer(
			@DerivedFrom(value = Stv.EXECUTION_DATETIME, isInternal = true) String notused) {

			// returns the time this was processed by SDR. Assuming this would preserve the order in which messages are recieved
			return format.formatDateTimeUTC(Calendar.getInstance().getTime());
	}
}
