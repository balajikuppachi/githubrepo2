package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.ReconNotMatched;
import com.wf.df.sdr.exception.dao.ReconNotMatchedDaoException;

public interface ReconNotMatchedDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(ReconNotMatched dto);

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria ''.
	 */
	public List<ReconNotMatched> findAll() throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'id = :id'.
	 */
	public List<ReconNotMatched> findWhereIdEquals(BigDecimal id) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'action = :action'.
	 */
	public List<ReconNotMatched> findWhereActionEquals(String action) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'msg_type = :msgType'.
	 */
	public List<ReconNotMatched> findWhereMsgTypeEquals(String msgType) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'asset_class = :assetClass'.
	 */
	public List<ReconNotMatched> findWhereAssetClassEquals(String assetClass) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'usi = :usi'.
	 */
	public List<ReconNotMatched> findWhereUsiEquals(String usi) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'upi = :upi'.
	 */
	public List<ReconNotMatched> findWhereUpiEquals(String upi) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'trade_date = :tradeDate'.
	 */
	public List<ReconNotMatched> findWhereTradeDateEquals(Date tradeDate) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'exec_datetime = :execDatetime'.
	 */
	public List<ReconNotMatched> findWhereExecDatetimeEquals(Date execDatetime) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'maturity_date = :maturityDate'.
	 */
	public List<ReconNotMatched> findWhereMaturityDateEquals(Date maturityDate) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'submission_datetime = :submissionDatetime'.
	 */
	public List<ReconNotMatched> findWhereSubmissionDatetimeEquals(Date submissionDatetime) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'submitter = :submitter'.
	 */
	public List<ReconNotMatched> findWhereSubmitterEquals(String submitter) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'notional_ccy = :notionalCcy'.
	 */
	public List<ReconNotMatched> findWhereNotionalCcyEquals(String notionalCcy) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'notional_amt = :notionalAmt'.
	 */
	public List<ReconNotMatched> findWhereNotionalAmtEquals(String notionalAmt) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'party1 = :party1'.
	 */
	public List<ReconNotMatched> findWhereParty1Equals(String party1) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'party2 = :party2'.
	 */
	public List<ReconNotMatched> findWhereParty2Equals(String party2) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'party1_reference = :party1Reference'.
	 */
	public List<ReconNotMatched> findWhereParty1ReferenceEquals(String party1Reference) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'status = :status'.
	 */
	public List<ReconNotMatched> findWhereStatusEquals(String status) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'sdr_name = :sdrName'.
	 */
	public List<ReconNotMatched> findWhereSdrNameEquals(String sdrName) throws ReconNotMatchedDaoException;

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<ReconNotMatched> findWhereCreateDatetimeEquals(Date createDatetime) throws ReconNotMatchedDaoException;

}
