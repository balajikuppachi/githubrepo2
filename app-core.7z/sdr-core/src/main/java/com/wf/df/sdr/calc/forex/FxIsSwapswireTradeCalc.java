package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxIsSwapswireTradeCalc {

	@Calculation(value = Calc.fxIsSwapswireTradeCalc, isPrototype = false)
	public Boolean calculate(
			@DerivedFrom(value = Calc.isSwapswireTradeCalc, isInternal = true) Boolean isSwapswireTrade){
		
		return isSwapswireTrade;

	}
}
