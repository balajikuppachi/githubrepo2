package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqConfirmationTypeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqConfirmationTypeCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Constants.PAPER_FLAG, isInternal = true) Boolean paperFlag) {

		if(!Utils.IsNullOrBlank(paperFlag)) {
			if (paperFlag)
				return "NonElectronic";
			else
				return "Electronic";	
		}
		return Constants.EMPTY_STRING;
	}
}
