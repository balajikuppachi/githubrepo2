package com.wf.df.sdr.calc.forex;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxOptionPremiumPayerValueCalc {

	@Calculation(value = Calc.fxOptionPremiumPayerValueCalc,isPrototype=false )
	public String compute(
			@DerivedFrom(value = Calc.premiumIndexCalc, isInternal = true) Integer premiumIndex,
			@DerivedFrom(value = Stv.FeePayerList,isInternal=true) List<String> feePayerList,
			@DerivedFrom(value = Calc.isPremiumAttachedCalc, isInternal = true) boolean isPremiumAttached,
			@DerivedFrom(value = Calc.calypsoTransactionTypeCalc, isInternal = true) String txnType,
			@DerivedFrom(value = Stv.CounterpartyName, isInternal = true) String counterPartyName,
			@DerivedFrom(value = Stv.FeeLegalEntityList, isInternal = true) List<String> feeLegalEntityList,
			@DerivedFrom(value = Stv.CounterpartyShortName, isInternal = true) String counterShortPartyName,
			@DerivedFrom(value = Stv.OurContactName, isInternal = true) String ourName,
			@DerivedFrom(value = Calc.fxWfParticipantIdCalc,isInternal=true) String wfValue,
			@DerivedFrom(value = Calc.fxCptyParticipantIdCalc,isInternal = true) String cptyValue
			) {

		if (StringUtils.containsIgnoreCase(txnType, Constants.Termination))
			return Constants.ALLOW_EMPTY_ON_REQD;

		String premiumPayer = null;

		if (isPremiumAttached) {
			if (Utils.IsListNullOrEmpty(feePayerList))
				throw new CalculationException("FNF","Fee Payer for type 'PREMIUM' not found");
			try {
				premiumPayer = feePayerList.get(premiumIndex);
				
				if(Utils.IsNullOrNone(premiumPayer)){					
					premiumPayer = feeLegalEntityList.get(premiumIndex);					
				}					
				
				
			} catch (ArrayIndexOutOfBoundsException ae) {
				throw new CalculationException("FNF","Fee Payer for type 'PREMIUM' not found");
			}

			if (premiumPayer == null)
				throw new CalculationException("FNF","Fee Payer for type 'PREMIUM' not found");
			
			
			if(premiumPayer.equals(counterPartyName) || premiumPayer.equals(counterShortPartyName))
				return cptyValue;
			if(premiumPayer.equals(ourName) )
				return wfValue;
			
			return Constants.ALLOW_EMPTY_ON_REQD;
		} else
			return Constants.ALLOW_EMPTY_ON_REQD;

	}

}
