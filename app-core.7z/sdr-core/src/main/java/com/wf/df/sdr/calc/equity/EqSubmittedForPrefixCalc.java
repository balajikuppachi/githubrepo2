package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class EqSubmittedForPrefixCalc {

	@Calculation(value = Calc.eqSubmittedForPrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliateTrade,
			@DerivedFrom(value = Calc.eqWFParticipantIdPrefixCalc, isInternal = true) String eqWFParticipantIdPrefix) {
		
		if(isAffiliateTrade)
			return eqWFParticipantIdPrefix;
		return eqWFParticipantIdPrefix;

	}
	
}
