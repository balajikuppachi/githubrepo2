package com.wf.df.sdr.calc.xasset;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.ISODateUtil;
import com.wf.df.sdr.util.Stv;




@Component
public class ClearingTimestampCalc {
	Logger logger = Logger.getLogger(this.getClass());
	

	@Calculation(value = Calc.clearingTimestampCalc, isPrototype = false)
	public String calcClearingTimestamp(
			@DerivedFrom(value = Calc.clearedTradeCalc, isInternal = true) boolean clearedTrade,
			@DerivedFrom(value = Stv.CC_ClearedDateTime, isInternal = true) String clearedDateTime) {
		
		logger.debug("calling------------ ClearingTimestampCalc ");
		if(clearedTrade==true)
		{
			try {
				return ISODateUtil.toString(ISODateUtil.parse(clearedDateTime));
			} catch (ParseException e) {
				// TODO Auto-generated catclo
				logger.info("error in parsing the date" +clearedDateTime);
				
			}	
		}
		return Constants.EMPTY_STRING;
	}
	}

