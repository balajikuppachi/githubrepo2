package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class CollEmirSubmitterValueCalc {

	@Value("${party1.id.Collateral}") String party1IdCollateral;
	@Value("${wfEur.lei}") String wfEurLEI;
	
	@Calculation(value = Calc.collEmirSubmitterValueCalc, isPrototype = false)
	public String calculate() {
		
		if(Utils.IsNullOrBlank(party1IdCollateral))
			return (wfEurLEI.split(Constants.COMMA)[0]);	
		
		// UAT only
		if(party1IdCollateral.startsWith(Constants.DTCC)) 	
			return party1IdCollateral.substring(4);
		
		return Constants.EMPTY_STRING;
	}
	
}
