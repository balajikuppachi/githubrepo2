package com.wf.df.sdr.calc.equity;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class EqConfirmationDateTimeCalc {

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.eqConfirmationDateTimeCalc, isPrototype=false)
	public String calculate(
			@DerivedFrom(value = Constants.CONFIRM_DATETIME, isInternal = true) Date confDateTime) {
		
		if(confDateTime != null){			
			return formatter.formatDateTimeUTC(confDateTime);			
		}
		else
			return Constants.EMPTY_STRING;
		
	}
	
}
