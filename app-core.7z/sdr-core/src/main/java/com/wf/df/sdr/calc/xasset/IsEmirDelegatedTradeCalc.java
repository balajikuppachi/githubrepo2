package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class IsEmirDelegatedTradeCalc {

	@Calculation(value = Calc.isEmirDelegatedTradeCalc, isPrototype = false)
	public boolean compute(
						@DerivedFrom(value=Constants.REPORTABLE_TO, isInternal = true) String reportableTo) {
		
		if(StringUtils.equalsIgnoreCase(reportableTo, Constants.DELEGATE_REPORTABLE_TO_EMIR))
			return true;
						
		return false;
	
	}
	
}
