package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.RecvMsgStoreDao;
import com.wf.df.sdr.dto.RecvMsgStore;
import com.wf.df.sdr.exception.dao.RecvMsgStoreDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class RecvMsgStoreDaoImpl extends AbstractDAO implements ParameterizedRowMapper<RecvMsgStore>, RecvMsgStoreDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;
	@Autowired
	private JdbcTemplate springJdbcTemplate;
	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(RecvMsgStore dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party,upi,action,sdr_repository,transmit_id ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,? )",dto.getRecvId(),dto.getMsgType(),dto.getCreateDatetime(),dto.getFqFilename(),dto.getDtccSrcMsgRecvTime(),dto.getDtccMsgRespTime(),dto.getDtccReferenceId(),dto.getDtccResponseStatus(),dto.getBufferId(),dto.getSendId(),dto.getUsi(),dto.getPrevUsi(),dto.getRepParty(),dto.getUpi(),dto.getAction(),dto.getSdrRepository(),dto.getTransmitId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return RecvMsgStore
	 */
	public RecvMsgStore mapRow(ResultSet rs, int row) throws SQLException
	{
		RecvMsgStore dto = new RecvMsgStore();
		dto.setRecvId( rs.getBigDecimal(1));
		dto.setMsgType( rs.getString( 2 ) );
		dto.setCreateDatetime( rs.getTimestamp(3 ) );
		dto.setFqFilename( rs.getString( 4 ) );
		dto.setDtccSrcMsgRecvTime( rs.getTimestamp(5 ) );
		dto.setDtccMsgRespTime( rs.getTimestamp(6 ) );
		dto.setDtccReferenceId( rs.getString( 7 ) );
		dto.setDtccResponseStatus( rs.getString( 8 ) );
		dto.setBufferId( rs.getBigDecimal( 9 ) );
		dto.setSendId( rs.getBigDecimal(10));
		dto.setUsi( rs.getString( 11 ) );
		dto.setPrevUsi( rs.getString( 12 ) );
		dto.setRepParty( rs.getString( 13 ) );
		dto.setUpi(rs.getString(14));
		dto.setAction(rs.getString(15));
		dto.setSdrRepository(rs.getString(16));
		dto.setTransmitId(rs.getBigDecimal(17));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recv_msg_store";
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria ''.
	 */
	@Transactional
	public List<RecvMsgStore> findAll() throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'recv_id = :recvId'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereRecvIdEquals(BigDecimal recvId) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE recv_id = ? ORDER BY recv_id", this,recvId);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereMsgTypeEquals(String msgType) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msgType);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'fq_filename = :fqFilename'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereFqFilenameEquals(String fqFilename) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE fq_filename = ? ORDER BY fq_filename", this,fqFilename);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_src_msg_recv_time = :dtccSrcMsgRecvTime'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereDtccSrcMsgRecvTimeEquals(Date dtccSrcMsgRecvTime) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE dtcc_src_msg_recv_time = ? ORDER BY dtcc_src_msg_recv_time", this,dtccSrcMsgRecvTime);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_msg_resp_time = :dtccMsgRespTime'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereDtccMsgRespTimeEquals(Date dtccMsgRespTime) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE dtcc_msg_resp_time = ? ORDER BY dtcc_msg_resp_time", this,dtccMsgRespTime);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_reference_id = :dtccReferenceId'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereDtccReferenceIdEquals(String dtccReferenceId) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE dtcc_reference_id = ? ORDER BY dtcc_reference_id", this,dtccReferenceId);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'dtcc_response_status = :dtccResponseStatus'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereDtccResponseStatusEquals(String dtccResponseStatus) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE dtcc_response_status = ? ORDER BY dtcc_response_status", this,dtccResponseStatus);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'buffer_id = :buffer_id'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereInMsgBufferEquals(BigDecimal bufferId) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE buffer_id = ? ORDER BY buffer_id", this,bufferId);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereSendIdEquals(BigDecimal sendId) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereUsiEquals(String usi) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'prev_usi = :prevUsi'.
	 */
	@Transactional
	public List<RecvMsgStore> findWherePrevUsiEquals(String prevUsi) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE prev_usi = ? ORDER BY prev_usi", this,prevUsi);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'rep_party = :repParty'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereRepPartyEquals(String repParty) throws RecvMsgStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE rep_party = ? ORDER BY rep_party", this,repParty);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
		
	}
	
	@Override
	public Integer checkTradeAccepted(String usi, String  msgType) {
		List<Integer> countList = springJdbcTemplate.queryForList("SELECT COUNT(1) FROM " + getTableName() + " WHERE usi = ? AND msg_type = ? AND dtcc_response_status = 'ACCEPTED' ", Integer.class, usi, msgType);
		
		if (countList == null || countList.isEmpty() || countList.get(0) == null) {
			return 0;
		} else {
			return countList.get(0);
		}
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereSdrRepositoryEquals(String sdrRepository)
			throws RecvMsgStoreDaoException {
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE sdr_repository = ? ORDER BY sdr_repository", this,sdrRepository);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
	}

	/** 
	 * Returns all rows from the recv_msg_store table that match the criteria 'transmit_id = :transmitId'.
	 */
	@Transactional
	public List<RecvMsgStore> findWhereTransmitIdEquals(BigDecimal transmitId)
			throws RecvMsgStoreDaoException {
		try {
			return jdbcTemplate.query("SELECT recv_id, msg_type, create_datetime, fq_filename, dtcc_src_msg_recv_time, dtcc_msg_resp_time, dtcc_reference_id, dtcc_response_status, buffer_id, send_id, usi, prev_usi, rep_party, upi, action, sdr_repository,transmit_id FROM " + getTableName() + " WHERE transmit_id = ? ORDER BY transmit_id", this,transmitId);
		}
		catch (Exception e) {
			throw new RecvMsgStoreDaoException("Query failed", e);
		}
	}

	
	
}
