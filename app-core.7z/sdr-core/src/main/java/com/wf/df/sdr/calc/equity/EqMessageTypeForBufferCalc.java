package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class EqMessageTypeForBufferCalc {

	@Calculation(value = Calc.eqMessageTypeForBufferCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType,
			@DerivedFrom(value=Calc.sendBackloadCalc, isInternal=true) boolean sendBackload) {

		if (sendBackload) 
			return Constants.MESSAGE_TYPE_SNAPSHOT; 
		return msgType;
	}
	
}
