package com.wf.df.sdr.calc.forex;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxCallNotionalAmountCalc 
{
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.fxCallNotionalAmountCalc )
	public String calcNotionalAmt(
			@DerivedFrom(value=Stv.FXOptionPrimaryAmount) String optionFxAmount,
			@DerivedFrom(value=Stv.FXOptionQuotingAmount) String optionFxQuoteAmount,
			@DerivedFrom(value = Stv.FXOptionIsPutFlag) String optionIsPutFlag)	{
		if(!Utils.IsNullOrBlank(optionIsPutFlag)  )
		{
			try {
				if(Constants.TRUE.equals(optionIsPutFlag) && !Utils.IsNullOrBlank(optionFxQuoteAmount))
				{	 return formatter.formatDecimal(parser.parseNumber(optionFxQuoteAmount));
				}else if(Constants.FALSE.equals(optionIsPutFlag) && !Utils.IsNullOrBlank(optionFxAmount))
				{  	 return formatter.formatDecimal(parser.parseNumber(optionFxAmount));
				}
			} catch (ParseException e) {
				throw new CalculationException("Parse Exception", Stv.FXOptionPrimaryAmount +" OR "+ Stv.FXOptionQuotingAmount + " is in wrong format. ");
			}
		}
		return Constants.EMPTY_STRING;
	}
}
