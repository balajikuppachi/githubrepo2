package com.wf.df.sdr.message;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

/**
 * 
 * @author GShankar
 *
 * This is the basic Unit of Work that will be used to pass around data as context in all handlers. Please add attributes in here
 * to flow through a chain
 */

public class BufferGenerationRequest {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	private CalculationContext calcCtx;
	
	private String dataToSend;
	
	private Boolean msgDuplicateFlag;
	
	private BigDecimal msgDuplicateSendId;
	
	public Boolean isMsgDuplicateFlag() {
		return msgDuplicateFlag == null ? false : msgDuplicateFlag;
	}

	public void setMsgDuplicateFlag(Boolean msgDuplicateFlag) {
		this.msgDuplicateFlag = msgDuplicateFlag;
	}

	public BufferGenerationRequest(CalculationContext calcCtx) {
		this.calcCtx = calcCtx;
	}
	
	public String getDtccAssetClass() {
		return getCalculationContext().getValue(Calc.dtccAssetClassCalc, String.class);
	}
	
	public String getMessageType() {
		return calcCtx.getValue(Constants.MESSAGE_TYPE, String.class);
	}
	
	public BigDecimal getSendId() {
		return calcCtx.getValue(Constants.SEND_ID, BigDecimal.class);
	}
	
	public String getBook() {
		return calcCtx.getValue(Stv.Book, String.class);
	}
	
	public String getDataToSend() {
		return dataToSend;
	}

	public void setDataToSend(String dataToSend) {
		this.dataToSend = dataToSend;
	}		
	
	public CalculationContext getCalculationContext() {
		return calcCtx;
	}
	
	public String getString(String name) {
		return calcCtx.getString(name);
	}
	
	public Boolean getBoolean(String name) {
		return calcCtx.getBoolean(name);
	}
	
	
	
	public BigDecimal getMsgDuplicateSendId() {
		return msgDuplicateSendId;
	}

	public void setMsgDuplicateSendId(BigDecimal msgDuplicateSendId) {
		this.msgDuplicateSendId = msgDuplicateSendId;
	}

	@Override
	public String toString() {
		return "Buffer generation request #" + getSendId() + "-" + getMessageType();
	}
	
}
