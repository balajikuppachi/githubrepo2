package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class USIPreviousValueCalc {

	@Calculation(value=Calc.uSIPreviousValueCalc, isPrototype = false)
	public String usi(
			@DerivedFrom(value = Stv.USI_PREVIOUS, isInternal = true) String usiPrevious) {
		
			if (!Utils.IsNullOrNone(usiPrevious)) {
				if (usiPrevious.startsWith(Constants.DTCC))
					return usiPrevious.substring(4);
				// for all USI not starting with DTCC prefix is 10
				return usiPrevious.substring(10);
			}
		return Constants.EMPTY_STRING;

	}
}
