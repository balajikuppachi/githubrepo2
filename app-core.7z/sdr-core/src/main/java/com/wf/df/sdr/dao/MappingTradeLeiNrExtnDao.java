package com.wf.df.sdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.wf.df.sdr.dto.MappingTradeLeiNr;

@Repository
public class MappingTradeLeiNrExtnDao {
	
private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	

	@Value("${trades.busacct.lei.nr.mapping.update}") String updateNewLeiQuery;
	@Value("${trades.newlei.nr.details.query}") String newLeiDetailsQuery;
	

	public int updateLeiInTradesLeiNrMapping( ) {
		logger.debug("updateLeiInTradesLeiNrMapping");
		int cnt=jdbcTemplate.update(updateNewLeiQuery);
		logger.debug("updateLei In MappingTradeLeiNr: No. of rows updated:"+cnt);
		return cnt;
	}
	
	
	public List<MappingTradeLeiNr> findNewLeiNrDetails() {
		logger.debug("findNewLeiNrDetails");
		List<MappingTradeLeiNr> resultLst=jdbcTemplate.query(newLeiDetailsQuery, new RowMapper() {			
			public Object mapRow(ResultSet rs, int arg1) throws SQLException {
				MappingTradeLeiNr  dto=new MappingTradeLeiNr();
				dto.setSendId(rs.getBigDecimal(1));
				dto.setTradeId(rs.getString(2));
				dto.setCurrentLei(rs.getString(3));
				dto.setNewLei(rs.getString(4));
				return dto;
			}
		});
		logger.debug("findNewLeiNrDetails: result set size->"+resultLst.size());
		return resultLst;
	}
}
