package com.wf.df.sdr.calc.equity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqUnderlyngAssetCptyParticipantIdPrefixCalc {

	@Calculation(value = Calc.eqUnderlyngAssetCptyParticipantIdPrefixCalc, isPrototype = false)
	public String calcAction(
			@DerivedFrom(value = Stv.UnderlyngAssetIdentifierTypeList, isInternal = true) List<String> typelist,
			@DerivedFrom(value = Calc.eqCptyParticipantIdPrefixCalc, isInternal = true) String cptyParticipantIdPrefix) {
		
		ArrayList<String> array = new ArrayList<String>();
		if (!Utils.IsListNullOrEmpty(typelist)) {
			for (int i = 0; i < typelist.size(); i++) {
				array.add(cptyParticipantIdPrefix);
			}
		}
		return Utils.convertListToDelimitedString(array, Constants.SEMICOLON);
	}
	
}
