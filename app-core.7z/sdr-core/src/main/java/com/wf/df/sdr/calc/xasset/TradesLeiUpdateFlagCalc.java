package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;

@Component
public class TradesLeiUpdateFlagCalc {

	@Calculation(value=Calc.tradesLeiUpdateFlagCalc,isPrototype=false)
	public int isLeiUpdateNeedCalc(@DerivedFrom(value=Stv.Book, isInternal=true) String book )
	{
		if("IRD_SPURS_WFB".equals(book))
			return 0;
		
		return 1;
	}
}
