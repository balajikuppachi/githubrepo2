package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.MappingTradeIdUsiService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class ComputedUSIForNRCalc {
	Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	MappingTradeIdUsiService mappingTradeIdUsiService;

	@Calculation(value = Calc.computedUSIForNRCalc, isPrototype = false)
	public String usi(
			@DerivedFrom(value = Calc.computedUSICalc, isInternal = true) String usi,			
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String srcTradeID,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String assetClass) {		
		
		if(!Utils.IsNullOrNone(usi))			
			return usi;
			
		if(Utils.IsNullOrNone(usi))
			usi = mappingTradeIdUsiService.queryUsiService(srcTradeID, assetClass);		
		
		if(Utils.IsNullOrNone(usi))
			usi = generateUsi(srcTradeID);		
		
		return usi;
	}

	// The method generates an usi, if it's null/blank
	private String generateUsi(String srcTradeID) {
		String generatedUSI = "SDRGeneratedUSI_" + srcTradeID;		
		return generatedUSI;
	}
}
