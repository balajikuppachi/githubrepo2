package com.wf.df.sdr.calc.emir;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class EmirSubmittedForValueCalc {

	@Calculation(value = Calc.emirSubmittedForValueCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.isDelegatedTradeCalc, isInternal = true) boolean isDelegated,			
			@DerivedFrom(value = Calc.emirTradeParty1ValueCalc, isInternal = true) String emirTradeParty1Value) {
		
		if(isDelegated)
			return Constants.BOTH;
		
		return Constants.EMPTY_STRING;

	}
	
}
