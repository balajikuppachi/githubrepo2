package com.wf.df.sdr.message;

public class EODErrorLoadRequest {
	private String assetClass;
	private String msgType;
	private String sdrRepository;
	private String noOfDays;

	public EODErrorLoadRequest(String assetClass, String msgType,String sdrRepository, String noOfDays) {
		this.assetClass = assetClass;
		this.msgType = msgType;
		this.sdrRepository = sdrRepository;
		this.noOfDays = noOfDays;
	}

	/**
	 * @return the assetClass
	 */
	public String getAssetClass() {
		return assetClass;
	}

	/**
	 * @return the msgType
	 */
	public String getMsgType() {
		return msgType;
	}

	/**
	 * @return the sdrRepository
	 */
	public String getSdrRepository() {
		return sdrRepository;
	}

	/**
	 * @return the noOfDays
	 */
	public String getNoOfDays() {
		return noOfDays;
	}

}
