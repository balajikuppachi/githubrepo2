package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class CollEmirSubmitterPrefixCalc {

	@Value("${party1.id.Collateral}") String party1IdCollateral;
	@Value("${wfEur.lei.prefix}") String wfEurLEI;
	
	@Calculation(value = Calc.collEmirSubmitterPrefixCalc, isPrototype = false)
	public String calculate() {
		
		if(Utils.IsNullOrBlank(party1IdCollateral))
				return wfEurLEI;	
		
		// UAT only
		return Constants.DTCC;
	}
	
}
