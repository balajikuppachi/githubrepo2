package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.EODBufferStoreDao;
import com.wf.df.sdr.dao.EODBufferStoreEmirDao;
import com.wf.df.sdr.dto.EODBufferStore;
import com.wf.df.sdr.dto.EODBufferStoreEmir;
import com.wf.df.sdr.exception.dao.EODBufferStoreDaoException;
import com.wf.df.sdr.exception.dao.EODBufferStoreEmirDaoException;
import com.wf.df.sdr.exception.dao.MsgToReportDaoException;
import com.wf.df.sdr.util.Constants;

public class EODBufferStoreEmirDaoImpl extends AbstractDAO implements ParameterizedRowMapper<EODBufferStoreEmir>, EODBufferStoreEmirDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private static String eodUpdateQuery = "UPDATE eod_buffer_store_emir SET msg_buffer = ? , update_datetime = ? , send_id = ? , template_id=?  WHERE uti = ? AND msg_type = ? AND sdr_repository = ?";
	

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(EODBufferStoreEmir dto)
	{		
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id,sdr_repository,trade_id,input_buffer_id,is_duplicate,is_buffer_eligible ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,? )",dto.getUti(),dto.getAssetClass(),dto.getSendId(),dto.getMsgBuffer(),dto.getUpdateDatetime(),dto.getMsgType(),dto.getTemplateId(),dto.getSdrRepository(),dto.getTradeId(),dto.getInputBufferId(),dto.getIsDuplicate(),dto.getIsBufferEligible());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return SnapshotUsiMsgMapping
	 */
	public EODBufferStoreEmir mapRow(ResultSet rs, int row) throws SQLException
	{
		EODBufferStoreEmir dto = new EODBufferStoreEmir();
		dto.setUti( rs.getString( 1 ) );
		dto.setAssetClass( rs.getString( 2 ) );
		dto.setSendId( rs.getBigDecimal(3));
		dto.setMsgBuffer( rs.getString( 4 ) );
		dto.setUpdateDatetime( rs.getTimestamp(5 ) );
		dto.setMsgType( rs.getString( 6 ) );
		dto.setTemplateId( rs.getString( 7 ) );
		dto.setSdrRepository(rs.getString( 8 ) );
		dto.setTradeId(rs.getString(9));
		dto.setInputBufferId(rs.getBigDecimal(10));
		dto.setIsDuplicate(rs.getBoolean(11));
		dto.setIsBufferEligible(rs.getBoolean(12));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "eod_buffer_store_emir";
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria ''.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findAll() throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'uti = :uti'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereUtiEquals(String uti) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE uti = ? ORDER BY uti", this,uti);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'uti = :uti'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereUtiAndMsgTypeEquals(String uti, String msgType,String sdrRepository) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE uti = ? and msg_type = ? and sdr_repository = ? ORDER BY uti", this, uti, msgType,sdrRepository);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'asset_class = :assetClass'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereAssetClassEquals(String assetClass) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE asset_class = ? ", this,assetClass);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereSendIdEquals(BigDecimal sendId) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'msg_buffer = :msgBuffer'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereMsgBufferEquals(String msgBuffer) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE msg_buffer = ? ORDER BY msg_buffer", this,msgBuffer);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereUpdateDatetimeEquals(Date updateDatetime) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE update_datetime = ? ORDER BY update_datetime", this,updateDatetime);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'uti = :uti'.
	 */
	@Transactional
	public int deleteBuffersForUTI(String uti) throws EODBufferStoreEmirDaoException
	{
		try {			
			return jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE uti = ?", uti);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'template_id = :templateId'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereTemplateIdEquals(String templateId) throws EODBufferStoreEmirDaoException {
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE template_id = ? ORDER BY template_id", this,templateId);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereSdrRepositoryEquals(String sdrRepository) throws EODBufferStoreEmirDaoException {
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE sdr_repository = ? ORDER BY sdr_repository", this,sdrRepository);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
	}

	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'tradeId = :tradeId'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereTradeIdEquals(String tradeId) throws EODBufferStoreEmirDaoException {
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE trade_id = ? ORDER BY trade_id", this,tradeId);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
	}

	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'tradeId = :tradeId'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findWhereInputBufferIdEquals(String inputBufferId) throws EODBufferStoreEmirDaoException {
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE input_buffer_id = ? ORDER BY input_buffer_id", this,inputBufferId);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
	}
	
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'tradeId, msgType,assetClass,uti'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findExistingTrade(String assetClass,  String msgType, String tradeId, String uti) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE  asset_class=? and msg_type=? and  trade_id=?  and uti=? and datalength(msg_buffer) > 0 ORDER BY send_id DESC", this, assetClass,  msgType, tradeId, uti);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store_emir table that match the criteria 'tradeId, msgType,assetClass,uti'.
	 */
	@Transactional
	public List<EODBufferStoreEmir> findExistingTrade(String assetClass,  String msgType, String tradeId, String uti, String marketType, Boolean isDelegated) throws EODBufferStoreEmirDaoException
	{
		try {
			return jdbcTemplate.query("select e.uti, e.asset_class, e.send_id, e.msg_buffer, e.update_datetime, e.msg_type, e.template_id, e.sdr_repository, e.trade_id, e.input_buffer_id,e.is_duplicate,is_buffer_eligible FROM " + getTableName() + " e, input_msg_store i WHERE e.send_id = i.send_id and e.is_duplicate=0 and e.is_buffer_eligible=1 and e.asset_class=? and e.msg_type=? and  e.trade_id=?  and e.uti=? and i.src_tlc_event=? and i.is_delegated = ? ORDER BY send_id DESC", this, assetClass,  msgType, tradeId, uti, marketType, isDelegated);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
		
	}

	@Override
	public List<EODBufferStoreEmir> findWhereIsDuplicateEquals(String isDuplicate) throws EODBufferStoreEmirDaoException {

		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE is_duplicate = ? ORDER BY is_duplicate", this,isDuplicate);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
	}

	@Transactional
	public void updateIsBufferEligible(BigDecimal sendID, String msgType) throws EODBufferStoreEmirDaoException {
			 jdbcTemplate.update("UPDATE " + getTableName() + " SET is_buffer_eligible =0 WHERE send_id=? AND msg_type=?",sendID,msgType);
		
	}

	@Transactional
	public List<EODBufferStoreEmir> findWhereIsBufferEligibleEquals(
			String isBufferEligible) throws EODBufferStoreEmirDaoException {
		try {
			return jdbcTemplate.query("SELECT uti, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id, sdr_repository,trade_id,input_buffer_id, is_duplicate,is_buffer_eligible FROM " + getTableName() + " WHERE is_buffer_eligible = ? ORDER BY is_buffer_eligible", this,isBufferEligible);
		}
		catch (Exception e) {
			throw new EODBufferStoreEmirDaoException("Query failed", e);
		}
	}
	
	/**
	 * Method to insert new record. If a record already exists, update the existing one
	 * @param dto
	 */
		@Transactional
		public void saveOrUpdateEODBuffer(EODBufferStoreEmir dto) {
			List<EODBufferStoreEmir> utiList;
			try {
				utiList = findWhereUtiAndMsgTypeEquals(dto.getUti(), dto.getMsgType(),dto.getSdrRepository());
					if (utiList == null || utiList.size() == 0 || utiList.get(0) == null) {
						// add new record for usi
						insert(dto);
					} else {
						// update the existing row for usi
						updateMsgBufferForUSI(dto);
					}
			} catch (EODBufferStoreDaoException e) {
				logger.info(e.getMessage(), e);
			}
		}
		
		@Transactional
		public void updateMsgBufferForUSI(EODBufferStoreEmir dto) {
			int recordUpdated = jdbcTemplate.update(eodUpdateQuery,new Object[] { dto.getMsgBuffer(), new Date(),dto.getSendId(), dto.getTemplateId(),dto.getUti(), dto.getMsgType(), dto.getSdrRepository() });
		}
		
		@Transactional
		public int deleteBuffersForUSI(String usi) throws EODBufferStoreEmirDaoException
		{
			try {			
				return jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE uti = ?", usi);
			}
			catch (Exception e) {
				throw new EODBufferStoreEmirDaoException("Query failed", e);
			}
			
		}

		@Transactional
		public int updateIsbufferEligibleForUsiPrev(String usi) {
			try {			
				return jdbcTemplate.update("UPDATE " + getTableName() + " SET is_buffer_eligible =0 WHERE uti=?",usi);
			}
			catch (Exception e) {
				throw new EODBufferStoreEmirDaoException("Query failed", e);
			}
		}

		@Transactional
		public int updateIsbufferEligibleForTradeId(String tradeId) {
			try {			
				return jdbcTemplate.update("UPDATE " + getTableName() + " SET is_buffer_eligible =0 WHERE trade_id=?",tradeId);
			}
			catch (Exception e) {
				throw new EODBufferStoreEmirDaoException("Query failed", e);
			}
		}
	
		@Transactional
		public void updateIsDuplicate(BigDecimal sendID, String msgType) throws EODBufferStoreEmirDaoException {
				 jdbcTemplate.update("UPDATE " + getTableName() + " SET is_duplicate=1 WHERE send_id=? AND msg_type=?",sendID,msgType);
			
		}

		@Transactional
		public int updateIsbufferEligibleForTradeIdUsi(String tradeId,	String usi) {

			try {			
				return jdbcTemplate.update("UPDATE " + getTableName() + " SET is_buffer_eligible =0 WHERE trade_id=? and uti=?",tradeId,usi);
			}
			catch (Exception e) {
				throw new EODBufferStoreEmirDaoException("Query failed", e);
			}
		}

}
