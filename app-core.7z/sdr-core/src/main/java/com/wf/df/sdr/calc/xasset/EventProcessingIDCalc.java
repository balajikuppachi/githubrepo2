package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EventProcessingIDCalc {

	@Calculation(value = Calc.eventProcessingIDCalc, isPrototype=false)
	public String calcAction(
			@DerivedFrom(value = Stv.PORTFOLIO_COMPRESSION, isInternal = true) String portfolioComp) {
	
		if(!Utils.IsNullOrNone(portfolioComp)){
			return portfolioComp;
		} 
		return Constants.EMPTY_STRING;
	}
}
