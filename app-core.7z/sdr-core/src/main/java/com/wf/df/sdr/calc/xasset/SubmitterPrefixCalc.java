package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class SubmitterPrefixCalc {
	
	@Value("${party1.id.Credit}") String party1IdCredit;
	@Value("${party1.id.Forex}") String party1IdForex;
	@Value("${party1.id.InterestRate}") String party1IdInterestRate;
	@Value("${wf.lei.prefix}") String wfLEIPrefix;

	@Calculation(value = Calc.submitterPrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass	) {
		
		if(	(Constants.ASSET_CLASS_CREDIT.equals(assetClass) && Utils.IsNullOrBlank(party1IdCredit))
				|| (Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass) && Utils.IsNullOrBlank(party1IdInterestRate))
				|| (Constants.ASSET_CLASS_FOREX.equals(assetClass) && Utils.IsNullOrBlank(party1IdForex))	)
			return wfLEIPrefix;
		
		// QA only
		return Constants.DTCC;	

	}
}
