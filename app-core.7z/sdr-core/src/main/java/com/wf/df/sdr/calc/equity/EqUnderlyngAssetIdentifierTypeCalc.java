package com.wf.df.sdr.calc.equity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqUnderlyngAssetIdentifierTypeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqUnderlyngAssetIdentifierTypeCalc, isPrototype = false)
	public String calcAction(
			@DerivedFrom(value = Stv.UnderlyngAssetIdentifierTypeList, isInternal = true) List<String> typelist) {
		
		ArrayList<String> array = new ArrayList<String>();
		if (!Utils.IsListNullOrEmpty(typelist)) {
			String value = null;
			for (int i = 0; i < typelist.size(); i++) {
				
				value = typelist.get(i);
				if("BASKET".equalsIgnoreCase(value)){
					value = toProperCase(value);
				}
				if("SHARE".equalsIgnoreCase(value) ||"INDEX".equalsIgnoreCase(value))
					value="RIC";
				array.add(value);
			}
		}
		return Utils.convertListToDelimitedString(array, Constants.SEMICOLON);
	}
	
	private String toProperCase(String s) {
	    return s.substring(0, 1).toUpperCase() +
	               s.substring(1).toLowerCase();
	}
}
