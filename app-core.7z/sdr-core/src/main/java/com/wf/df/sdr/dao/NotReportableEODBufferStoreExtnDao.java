package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.CollateralizationType;
import com.wf.df.sdr.dto.EODBufferRecord;
import com.wf.df.sdr.dto.EODBufferStore;
import com.wf.df.sdr.dto.MappingTradeLei;
import com.wf.df.sdr.dto.MappingTradeLeiNr;
import com.wf.df.sdr.exception.dao.EODBufferStoreDaoException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Repository
public class NotReportableEODBufferStoreExtnDao {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	NotReportableEODBufferStoreDao notReportableEODBufferStoreDao ;	
	
	@Autowired
	FormatterService formatterService;
	
	@Value("${eod.nrp.report.query}")	String eodNrpQuery;
	
	@Value("${eod.recon.report.query}")	String eodReconQuery;
	
	@Value("${eod.recon.emir.report.query}")	String eodEmirReconQuery;
	@Value("${eod.recon.report.query.galaxy}")	String eodEqReconQuery;
				
	private static String eodReportingUpdateQuery = "UPDATE not_reportable_msg_store SET msg_buffer = ? , update_datetime = ? , send_id = ? ,template_id=? WHERE usi = ? AND msg_type = ?";
	private static String eodReportingUpdateSendIdUsiQuery = "UPDATE not_reportable_msg_store SET msg_buffer = ? , update_datetime = ? , send_id = ? ,template_id=? WHERE usi = ? AND msg_type = ? and send_id=?";
	
	@Value("${trade.level.collateralization}")	String collQuery;
	
	@Transactional
	public void updateMsgBufferForUSI(EODBufferStore dto) {
		int recordUpdated = jdbcTemplate.update(eodReportingUpdateQuery,new Object[] { dto.getMsgBuffer(), new Date(),dto.getSendId(),dto.getTemplateId(), dto.getUsi(), dto.getMsgType() });
	}
	
	@Transactional
	public void updateMsgBufferForUSISendId(EODBufferStore dto,BigDecimal sendID) {
		int recordUpdated = jdbcTemplate.update(eodReportingUpdateSendIdUsiQuery,new Object[] { dto.getMsgBuffer(), new Date(),dto.getSendId(),dto.getTemplateId(), dto.getUsi(), dto.getMsgType(),sendID });
	}
/**
 * Method to insert new record. If a record already exists, update the existing one
 * @param dto
 * @param tradeId 
 */
	@Transactional
	public void saveOrUpdateEODBuffer(EODBufferStore dto) {
		List<EODBufferStore> usiList;
		try {
			usiList = notReportableEODBufferStoreDao.findWhereUsiAndMsgTypeEquals(dto.getUsi(), dto.getMsgType());
				if (usiList == null || usiList.size() == 0 || usiList.get(0) == null) {
					// add new record for usi
					notReportableEODBufferStoreDao.insert(dto);
				} else {
					// update the existing row for usi
					updateMsgBufferForUSI(dto);
				}
		} catch (EODBufferStoreDaoException e) {
			logger.info(e.getMessage(), e);
		}
	}
	
	
	/**
	 * Method to insert new record. If a record already exists, update the existing one
	 * @param dto
	 * @param tradeId 
	 */
		@Transactional
		public void saveOrUpdateEODBufferTradeId(EODBufferStore dto, String tradeId) {
			List<EODBufferRecord> tradeList;
			try {
				tradeList = findWhereTradeIdAndMsgTypeEquals(tradeId, dto.getMsgType());
					if (tradeList == null || tradeList.size() == 0 || tradeList.get(0) == null) {
						// add new record for usi
						notReportableEODBufferStoreDao.insert(dto);
					} else {
						
						if(tradeList.size()>=1)
						{
							for (EODBufferRecord eodBufferRecord : tradeList) {
								EODBufferStore eodBufferStore=eodBufferRecord.getEodBufferStore();
								
								/**if either of usi in current drop or previous drop is null, the delete current & insert new record.*/
								deleteEODBuffersForSendId(eodBufferStore.getSendId(),dto.getMsgType());
							
								/*if(Utils.IsNullOrBlank(eodBufferStore.getUsi()) || dto.getUsi().contains("SDRGenerated") )
								{
									deleteEODBuffersForSendId(eodBufferStore.getSendId(),dto.getMsgType());
									notReportableEODBufferStoreDao.insert(dto);
								}else
								{
									// update the existing row for usi
									//updateMsgBufferForUSISendId(dto,eodBufferStore.getSendId());
									//update is changed to delete as STR-283 was not working
									deleteEODBuffersForSendId(eodBufferStore.getSendId(),dto.getMsgType());
									notReportableEODBufferStoreDao.insert(dto);
									
								}*/
							}
							notReportableEODBufferStoreDao.insert(dto);
						}
						
					}
			} catch (EODBufferStoreDaoException e) {
				logger.info(e.getMessage(), e);
			}
		}
		
		
	@Transactional
	public List<EODBufferRecord> fetchNRpEODTradeforReport(String assetClass, String msgType, String sdrRepo) {
		List<EODBufferRecord> rsList = jdbcTemplate.query(eodNrpQuery,new Object[] {assetClass, msgType,sdrRepo}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						int i=1;
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						m.setUsi(rs.getString(i++)); //"usi"
						m.setSendId(rs.getBigDecimal(i++)); //"send_id"
						m.setMsgBuffer(rs.getString(i++)); //"msg_buffer"
						m.setSdrRepository(rs.getString(i++)); //sdr_repository
						m.setParty1LEI(rs.getString(i++)); //party1_lei
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<EODBufferRecord> fetchReconTradeforReport(String assetClass, String msgType, String sdrRepo) {
		String query=sdrRepo.equals(Constants.EMIR)?eodEmirReconQuery:eodReconQuery;
		List<EODBufferRecord> rsList = jdbcTemplate.query(query,new Object[] {assetClass, msgType,sdrRepo}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						int i=1;
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						m.setUsi(rs.getString(i++)); //"usi"
						m.setSendId(rs.getBigDecimal(i++)); //"send_id"
						m.setMsgBuffer(rs.getString(i++)); //"msg_buffer"
						m.setSdrRepository(rs.getString(i++)); //sdr_repository
						m.setParty1LEI(rs.getString(i++)); //party1_lei
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setParty2LEI(rs.getString("party2_lei"));
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setTradeId(rs.getString("src_trade_id"));
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<EODBufferRecord> fetchGalaxyReconTradeforReport(String assetClass, String msgType,String sdrRepo) {
		List<EODBufferRecord> rsList = jdbcTemplate.query(eodEqReconQuery,new Object[] {assetClass, msgType,sdrRepo}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						
						String templateId = rs.getString("template_id");
						
						m.setUsi(rs.getString("usi"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setTemplateId(templateId);
						m.setSdrRepository(rs.getString("sdr_repository"));
						
						m.setParty1LEI(rs.getString("party1_lei"));
						m.setParty2LEI(rs.getString("party2_lei"));
						
						record.setTradeId(rs.getString("src_trade_id"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						record.setTemplateId(templateId);
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	@Transactional
	public int removeMaturedTrades(String assetClass, String msgType, Date date) 
	{
		String dateString = formatterService.formatDateUTC(date);
		logger.info("Removing matured trades for "+assetClass+":"+msgType);
		String query="DELETE FROM not_reportable_msg_store FROM not_reportable_msg_store nebs, input_msg_store ims where ims.send_id = nebs.send_id and nebs.asset_class = ? and nebs.msg_type = ? and ims.src_mat_date < ?";
		return jdbcTemplate.update(query, assetClass, msgType, dateString);
	}
	
	@Transactional
	public int updateNotReportableEodMsgBuffer(String buffer, String usi, String msgType) 
	{
		String usiUpdateQuery="UPDATE not_reportable_msg_store SET msg_buffer = ?, update_datetime = getDate() where usi = ? AND msg_type = ?";
		return jdbcTemplate.update(usiUpdateQuery, buffer, usi, msgType ) ;
	}
	
	
	public List<String> findDistinctUsi(String assetClass, String msgType) 
	{
		String usiQuery="SELECT DISTINCT usi FROM not_reportable_msg_store WHERE asset_class = ? AND msg_type=? AND datalength(msg_buffer) > 0 ORDER BY usi ASC";
		List<String> usiLst= jdbcTemplate.queryForList(usiQuery,String.class,new Object[] {assetClass,msgType});
		return  usiLst;
	}
	
	public List<String> findDistinctUsi(String assetClass, String msgType,String sdrRepo) 
	{
		String usiQuery="SELECT DISTINCT n.usi FROM not_reportable_msg_store n,input_msg_store i WHERE i.send_id=n.send_id and i.sdr_repository=? and n.asset_class = ? AND datalength(msg_buffer) > 0 ORDER BY n.usi ASC";
		List<String> usiLst= jdbcTemplate.queryForList(usiQuery,String.class,new Object[] {sdrRepo,assetClass});
		return  usiLst;
	}
	
	
	/**
	 * Method to remove the buffer for all Cancelled Origination Trades - Snapshot_TO
	 * @param usi
	 * @param msgType
	 */
	
	@Transactional
	public void removeBuffersForUsi(String usi, String msgType) {
		logger.warn("Deleting EOD buffers for the USI  :"+ usi);
		String query = "DELETE FROM not_reportable_msg_store where usi = ? and msg_type= ?";		
		jdbcTemplate.update(query, usi, msgType );

	}
	
	/**
	 * Method to remove the buffer for all Filter Failed Trades - Snapshot_TO
	 * @param usi
	 * @param msgType
	 */
	
	@Transactional
	public int removeFilterFailedBuffersForUsi(String usi, String msgType) {
		logger.warn("Deleting EOD buffers for the USI  :"+ usi);
		int count = 0;
		
		String query = "DELETE FROM not_reportable_msg_store where usi = ? and msg_type= ?";		
		count = jdbcTemplate.update(query, usi, msgType );
		return count;
	}
	@Transactional
	public int updateNotReportableEodMsgBuffer(String buffer, String usi, String msgType, boolean isaffliateTrade) 
	{
		int count =0;
		String usiUpdateQuery="UPDATE not_reportable_msg_store SET msg_buffer = ?, update_datetime = getDate(), usi = ? where usi = ? AND msg_type = ?";
		
		count= jdbcTemplate.update(usiUpdateQuery, buffer, usi,usi, msgType ) ;
		if(count==0 && isaffliateTrade){
			String usiAff=usi.replace("_aff", "");
			count= jdbcTemplate.update(usiUpdateQuery, buffer, usi,usiAff, msgType ) ;
		}
		return count;
	}
	
	/*
     * Remove all send id matching in not_reportable for SS-NR/SS_TO
     * 
     * */
	@Transactional
    public int removeAllNRBuffersForTradeId(String tradeId){
		logger.warn("Deleting all NR/TO messages from not_reportable for trade_id: "+tradeId);
		String query = "DELETE FROM not_reportable_msg_store where send_id IN ( select send_id from input_msg_store where src_trade_id = ?) and msg_type IN('"+Constants.MESSAGE_TYPE_SNAPSHOT_NR+"','"+Constants.MESSAGE_TYPE_SNAPSHOT_TO+"')";		
		try {
			return jdbcTemplate.update(query,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}
	
	/*
     * Remove all send id 
     * 
     * */
	@Transactional
	public int deleteOldEODBuffersForTradeId(String tradeId) {
		logger.warn("Deleting  SS/Val messages for below max sendId from eod_buffer_store for trade_id: "+tradeId);
		String query = "DELETE FROM eod_buffer_store where send_id IN ( select send_id from input_msg_store where src_trade_id = ? group by src_trade_id having send_id <max(send_id)) ";		
		try {
			return jdbcTemplate.update(query,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}
	@Transactional
	public int deleteOldNRPBuffersForTradeId(String tradeId) {
		logger.warn("Deleting  NR/TO messages for below max sendId from not_reportable for trade_id: "+tradeId);
		String query = "DELETE FROM not_reportable_msg_store where send_id IN ( select send_id from input_msg_store where src_trade_id = ? group by src_trade_id having send_id <max(send_id)) ";		
		try {
			return jdbcTemplate.update(query,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}
	@Transactional
	public int deleteAllEODBuffersForTradeId(String tradeId) {
		logger.warn("Deleting all SS/Val messages from eod_buffer_store for trade_id: "+tradeId);
		String query = "DELETE FROM eod_buffer_store where send_id IN ( select send_id from input_msg_store where src_trade_id = ?) ";		
		try {
			return jdbcTemplate.update(query,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}
	@Transactional
	public int deleteAllEODNRPBuffersForTradeId(String tradeId) {
		logger.warn("Deleting all NR/TO messages from not_reportable for trade_id: "+tradeId);
		String query = "DELETE FROM not_reportable_msg_store where send_id IN ( select send_id from input_msg_store where src_trade_id = ?) ";		
		try {
			return jdbcTemplate.update(query,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}
	@Transactional
	public int deleteEODNRBuffersForTradeId(String tradeId) {
		logger.warn("Deleting all NR messages from not_reportable for trade_id: "+tradeId);
		String query = "DELETE FROM not_reportable_msg_store where send_id IN ( select send_id from input_msg_store where src_trade_id = ?) and msg_type IN('"+Constants.MESSAGE_TYPE_SNAPSHOT_NR+"')";		
		try {
			return jdbcTemplate.update(query,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}
	
	
	@Transactional
	public int updateMsgBufferForNewLEINr(final MappingTradeLeiNr dto) 
	{
		String leiUpdateQuery="update not_reportable_msg_store set msg_buffer = str_replace (convert(varchar(16384), msg_buffer),?,?) where send_id=?";
		return jdbcTemplate.update(leiUpdateQuery,dto.getCurrentLei().replace(":", ","), dto.getNewLei().replace(":", ","),dto.getSendId() ) ;
	}
	
	

	@Transactional
	private List<EODBufferRecord> findWhereTradeIdAndMsgTypeEquals(String tradeId, String msgType) throws EODBufferStoreDaoException
	{
		
		String query="SELECT ims.usi, asset_class, nrp.send_id FROM not_reportable_msg_store nrp,input_msg_store ims WHERE ims.send_id=nrp.send_id and  ims.src_trade_id =? and msg_type = ? ORDER BY src_trade_id desc";
		List<EODBufferRecord> rsList = jdbcTemplate.query(query,new Object[] {tradeId, msgType}, new RowMapper() {
			public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
				int i=1;
				final EODBufferRecord record = new EODBufferRecord();
				final EODBufferStore m = new EODBufferStore();
				m.setUsi(rs.getString(i++)); 
				m.setAssetClass(rs.getString(i++)); 
				m.setSendId(rs.getBigDecimal(i++));
				
				record.setEodBufferStore(m);
				return record;
			}
		});
		return rsList;
	}
	
	@Transactional
	public int deleteEODBuffersForSendId(BigDecimal send_id, String msgType) {
		logger.warn("Deleting all "+ msgType +" messages from not_reportable_msg_store for send_id: "+send_id);
		String query = "DELETE FROM not_reportable_msg_store where send_id =? and msg_type=? ";		
		try {
			return jdbcTemplate.update(query,send_id,msgType);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}
	
	@Transactional
	public int deleteEODNRBuffersForTradeId(String usi,String tradeId) {
		logger.warn("Deleting all NR messages from not_reportable for trade_id: "+tradeId +" , usi :"+usi);
		String query = "DELETE FROM not_reportable_msg_store where send_id IN ( select send_id from input_msg_store where src_trade_id = ?) and msg_type IN('"+Constants.MESSAGE_TYPE_SNAPSHOT_NR+"')";		
		try {
			return jdbcTemplate.update(query,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	}

	
	@Transactional
	public int deleteNRBuffersForUSITradeID(String usi,String tradeId)
	{
		logger.warn("Deleting NR messages from not_reportable for trade_id: "+tradeId +" , usi :"+usi);
		String query = "DELETE FROM not_reportable_msg_store FROM not_reportable_msg_store nrm, input_msg_store ims WHERE ims.send_id=nrm.send_id and ims.usi=? and ims.src_trade_id=?  and nrm.msg_type IN ('"+Constants.MESSAGE_TYPE_SNAPSHOT_NR+"')";		
		try {
			return jdbcTemplate.update(query,usi,tradeId);
		} catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}

		
	}
	
	@Transactional
	public List<CollateralizationType> fetchCollateralizationType(String assetClass, String repository, String msgType) {
		List<CollateralizationType> collateral= jdbcTemplate.query(collQuery,new Object[] {assetClass,msgType,repository}, new RowMapper() {
			public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
				final CollateralizationType c = new CollateralizationType();
				c.setSendID(rs.getBigDecimal("send_id"));
				c.setcollateralizationType(rs.getString("collateralizationType"));
				return c;
		} });
	return collateral;
	}
	
	@Transactional
	public String fetchCollateralizationTypeFX(String tradeID ) {
		String collQueryFX = "select collateralizationType from trade_collateralization where trade_id = ?  and srcSystem = 'STIERS_CALYPSO_CALRATES' ";
		List<String> collateral = jdbcTemplate.queryForList(collQueryFX,String.class,new Object[]{tradeID});
		if (collateral == null || collateral.size() == 0 || collateral.get(0) == null) {
			return null;
		}
		else return collateral.get(0);
	}
}