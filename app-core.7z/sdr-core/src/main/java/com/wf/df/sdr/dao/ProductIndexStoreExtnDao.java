package com.wf.df.sdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class ProductIndexStoreExtnDao {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	@Qualifier("encJdbcTemplate")
	protected JdbcTemplate productIndxJdbcTemplate;
	
	@Value("${product.retrieve.query}") String encICEQuery;
	
	@Value("${ice.data.mapping.query}") String encICEMappingQuery;
	
	public List<List<String>> retrieveICEProductsByProductID() {
		logger.info("Loading ICE ProductID.");
		List <List<String>>iceProducts=productIndxJdbcTemplate.query(encICEQuery, new RowMapper() {

			public Object mapRow(ResultSet result, int arg1) throws SQLException {
				List<String> retList=new ArrayList<String>();
				retList.add(result.getString(1));
				retList.add(result.getString(2));
				return retList;
			}
		});
		//return productIndxJdbcTemplate.queryForList(encICEQuery, String.class, productID);
		return iceProducts;
	}
	
	
	public List<List<String>> findReferencePrice() {
		logger.info("Loading ICE ReferencePrice for ProductID.");
		//return productIndxJdbcTemplate.queryForList(encICEMappingQuery, String.class, productId, srcValue);	
		List <List<String>>iceReferencePrice=productIndxJdbcTemplate.query(encICEMappingQuery, new RowMapper() {

			public Object mapRow(ResultSet result, int arg1) throws SQLException {
				List<String> retList=new ArrayList<String>();
				retList.add(result.getString(1));
				retList.add(result.getString(2));
				retList.add(result.getString(3));
				return retList;
			}
		});
		return iceReferencePrice;
	}
	
}
