package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.InputMsgStoreExtnDao;
import com.wf.df.sdr.util.Calc;

@Component
public class FxCalypsoComputedUSICalc {

	Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	InputMsgStoreExtnDao dao;

	@Calculation(value = Calc.fxCalypsoComputedUSICalc, isPrototype = false)
	public String usi(@DerivedFrom(value=Calc.calypsoComputedUSICalc, isInternal = true) String usi	) {
		return usi;
	}
}
