package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class EqParty1USPersonCalc {

	@Calculation(value = Calc.eqParty1USPersonCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.UsPersonEntity_Us, isInternal = true) String usPersonEntity)	{
		
		if("Y".equalsIgnoreCase(usPersonEntity))
			return Constants.TRUE;
		
		if("N".equalsIgnoreCase(usPersonEntity))
			return Constants.FALSE;
		
		return Constants.EMPTY_STRING;
	
	}
	
}
