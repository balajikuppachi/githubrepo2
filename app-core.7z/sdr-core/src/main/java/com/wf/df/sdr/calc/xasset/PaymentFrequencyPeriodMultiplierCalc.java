package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Utils;

@Component
public class PaymentFrequencyPeriodMultiplierCalc {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	DTCCUtils dtccUtil;	

	@Calculation(value = Calc.paymentFrequencyPeriodMultiplierCalc)
	public String calcAction(
			MethodCalculationDefinition def,
			@DerivedFrom(value = "frequency") String frequency)
	{
		if(Utils.IsNullOrBlank(frequency)){
			throw new CalculationException("error code?", "Field '" + def.getDependencyNames()[0] + "' must not be blank");
		} else {
			String value = dtccUtil.getFrequencyPeriodNumber(frequency);
			if (value == null) {
				throw new CalculationException("error code?", "Unexpected value '" + def.getDependencyNames()[0] + "' = '" + value + "'");
			} else {
				return value;
			}
		}
	}

}
