package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Component
public class TradeParty1PrefixCalc {

	@Value("${party1.id.Credit}") String party1IdCredit;
	@Value("${party1.id.Forex}") String party1IdForex;
	@Value("${party1.id.InterestRate}") String party1IdInterestRate;

	@Calculation(value = Calc.tradeParty1PrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.wfParticipantIdPrefixCalc, isInternal = true) String wellsPrefix,
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass	) {
		
		if(Constants.ASSET_CLASS_CREDIT.equals(assetClass) && Utils.IsNullOrBlank(party1IdCredit))
			return wellsPrefix;
		
		if(Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass) && Utils.IsNullOrBlank(party1IdInterestRate))
			return wellsPrefix;
		
		if(Constants.ASSET_CLASS_FOREX.equals(assetClass) && Utils.IsNullOrBlank(party1IdForex))
			return wellsPrefix;
		
		// QA only
		return Constants.DTCC;	

	}
	
}
