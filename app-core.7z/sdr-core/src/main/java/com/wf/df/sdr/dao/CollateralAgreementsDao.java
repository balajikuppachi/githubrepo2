package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.CollateralAgreementsDao;
import com.wf.df.sdr.dto.CollateralAgreements;
import com.wf.df.sdr.exception.dao.CollateralAgreementsDaoException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface CollateralAgreementsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(CollateralAgreements dto);

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria ''.
	 */
	public List<CollateralAgreements> findAll() throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'agreement_id = :agreementId'.
	 */
	public List<CollateralAgreements> findWhereAgreementIdEquals(String agreementId) throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'agreement_type = :agreementType'.
	 */
	public List<CollateralAgreements> findWhereAgreementTypeEquals(String agreementType) throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'shortname = :shortname'.
	 */
	public List<CollateralAgreements> findWhereShortnameEquals(String shortname) throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'margin_type = :marginType'.
	 */
	public List<CollateralAgreements> findWhereMarginTypeEquals(String marginType) throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'market_value = :marketValue'.
	 */
	public List<CollateralAgreements> findWhereMarketValueEquals(BigDecimal marketValue) throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'ext_agreement_type = :extAgreementType'.
	 */
	public List<CollateralAgreements> findWhereExtAgreementTypeEquals(String extAgreementType) throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'cid_legal = :cidLegal'.
	 */
	public List<CollateralAgreements> findWhereCidLegalEquals(Integer cidLegal) throws CollateralAgreementsDaoException;

	/** 
	 * Returns all rows from the collateral_agreements table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<CollateralAgreements> findWhereCreateDatetimeEquals(Date createDatetime) throws CollateralAgreementsDaoException;

}
