package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.MsgToReportDao;
import com.wf.df.sdr.dto.MsgToReport;
import com.wf.df.sdr.dto.MsgToReportStatus;
import com.wf.df.sdr.exception.dao.InputMsgStoreDaoException;
import com.wf.df.sdr.exception.dao.MsgToReportDaoException;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class MsgToReportDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MsgToReport>, MsgToReportDao
{
	protected SimpleJdbcTemplate jdbcTemplate;
	protected DataSource dataSource;
	@Autowired
	private org.springframework.jdbc.core.JdbcTemplate springJdbcTemplate;
	
	@Value("${buffer.comparison.query}") String bufferComparisonQuery;
	@Value("${buffer.comparison.query.EQ}") String bufferComparisonQueryEq;
	@Value("${buffer.comparison.query.status}") String bufferComparisonQueryWithStatus;
	@Value("${buffer.comparison.query.status.EQ}") String bufferComparisonQueryWithStatusEq;	
	@Value("${last.submitted.message.query}") String lastSubmittedMessageQuery;	
	
	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(MsgToReport dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getSendId(),dto.getMsgType(),dto.getCreateDatetime(),dto.getAssetClass(),dto.getOutMsgData(), dto.getUsi(), dto.getPrevUsi(), dto.getTemplateName(), dto.getTransmitId(), dto.getSdrRepository());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return MsgToReport
	 */
	public MsgToReport mapRow(ResultSet rs, int row) throws SQLException
	{
		MsgToReport dto = new MsgToReport();
		dto.setSendId( rs.getBigDecimal("send_id"));
		dto.setMsgType( rs.getString("msg_type"));
		dto.setCreateDatetime( rs.getTimestamp("create_datetime"));
		dto.setAssetClass( rs.getString("asset_class"));
		dto.setOutMsgData( rs.getString("out_msg_data"));
		dto.setUsi( rs.getString("usi") );
		dto.setPrevUsi( rs.getString("prev_usi"));
		dto.setTemplateName( rs.getString("template_name"));
		dto.setTransmitId(rs.getBigDecimal("transmit_id"));
		dto.setSdrRepository(rs.getString("sdr_repository"));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "msg_to_report";
	}

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria ''.
	 */
	@Transactional
	public List<MsgToReport> findAll() throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<MsgToReport> findWhereSendIdEquals(BigDecimal sendId) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE send_id = ? ", this,sendId);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<MsgToReport> findWhereMsgTypeEquals(String msgType) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi , template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE msg_type = ? ", this,msgType);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<MsgToReport> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE create_datetime = ? ", this,createDatetime);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'asset_class = :assetClass'.
	 */
	@Transactional
	public List<MsgToReport> findWhereAssetClassEquals(String assetClass) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE asset_class = ? ", this,assetClass);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'out_msg_data = :outMsgData'.
	 */
	@Transactional
	public List<MsgToReport> findWhereOutMsgDataEquals(String outMsgData) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE out_msg_data = ? ", this,outMsgData);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}
	
	
	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<MsgToReport> findWhereUsiEquals(String usi) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE usi = ? ", this,usi);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'prev_usi = :prevUsi'.
	 */
	@Transactional
	public List<MsgToReport> findWherePrevUsiEquals(String prevUsi) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE prev_usi = ? ", this,prevUsi);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	@Override
	public Long findMaxTransmitId(Long from, Long to) {
		List<Long> maxIdList = springJdbcTemplate.queryForList("SELECT MAX(transmit_id) FROM " + getTableName() + " WHERE transmit_id >= ? AND transmit_id <= ?", Long.class, from, to);
		
		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null) {
			return null;
		} else {
			return maxIdList.get(0);
		}
	}

	@Override
	public Integer findMatchingRecords(String usi, BigDecimal sendId) {
		List<Integer> records = springJdbcTemplate.queryForList("SELECT COUNT(1) FROM " + getTableName() + " WHERE usi = ? AND send_id = ?", Integer.class, usi	, sendId);
		if (records == null || records.isEmpty() || records.get(0) == null) {
			return null;
		} else {
			return records.get(0);
		}
	}

	
	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'prev_usi = :prevUsi'.
	 */
	@Transactional
	public List<MsgToReport> findExistingTrade(String tradeId, String tlcEvent,String msgType, String assetClass, String usi, String status) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query(bufferComparisonQuery, this, tradeId, tlcEvent, msgType, assetClass, usi,status);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}
	
	@Transactional
	public List<MsgToReportStatus> findExistingTradeWithStatus(String tradeId, String tlcEvent,String msgType, String assetClass, String usi,String sdrRepo) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query(bufferComparisonQueryWithStatus, new RowMapperWithStatus(), tradeId, tlcEvent, msgType, assetClass, usi,sdrRepo);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	
	
	@Transactional
	public List<MsgToReport> findExistingUSITrade(String tlcEvent,String msgType, String assetClass, String usi, String status)	throws MsgToReportDaoException{
		try {
			return jdbcTemplate.query(bufferComparisonQueryEq, this, tlcEvent, msgType, assetClass, usi, status);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	@Transactional
	public List<MsgToReportStatus> findExistingUSITradeWithStatus(String tlcEvent,String msgType, String assetClass, String usi)	throws MsgToReportDaoException{
		try {
			return jdbcTemplate.query(bufferComparisonQueryWithStatusEq, new RowMapperWithStatus(), tlcEvent, msgType, assetClass, usi);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}
	
	@Transactional
	public void updateUsiForSendId(BigDecimal sendId, String newUsi) {
		String query = "UPDATE  "+getTableName()+" SET usi = ? WHERE send_id = ?";
		jdbcTemplate.update(query, newUsi, sendId) ;
		
	}
	
	@Transactional
	public List<MsgToReport> findPaperConfirmTradeDetails(BigDecimal sendId) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi, template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE send_id = ? and msg_type NOT IN ('39','ICEMessageType')", this,sendId);
		}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}
	
	
	@Transactional
	public List<MsgToReport> findLastSubmittedMessage(String msgType, String assetClass, String usi, String status) throws MsgToReportDaoException
	{
		try {
			return jdbcTemplate.query(lastSubmittedMessageQuery, this, msgType, assetClass, usi, status);
			}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}
	
	
	/** 
	 * Returns all rows from the msg_to_report table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	@Transactional
	public List<MsgToReport> findWhereSdrRepositoryEquals(String sdrRepository)
			throws MsgToReportDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi , template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE sdr_repository = ? ORDER BY sdr_repository", this,sdrRepository);
			}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}
	
	@Transactional
	public List<MsgToReport> findRtPetWhereSendidEquals(BigDecimal sendId)
			throws MsgToReportDaoException {
		try {
			return jdbcTemplate.query("SELECT send_id, msg_type, create_datetime, asset_class, out_msg_data, usi, prev_usi , template_name, transmit_id, sdr_repository FROM " + getTableName() + " WHERE msg_type in ('RT', 'PET') and send_id = ? ORDER BY send_id", this, sendId);
			}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}
	
	@Transactional
	public List<MsgToReport> findExistingTradeByUsi(String tlcEvent,String msgType, String assetClass, String usi, String status)
			throws MsgToReportDaoException {
		try {
			return jdbcTemplate.query("SELECT mtr.send_id, mtr.msg_type, mtr.create_datetime, mtr.asset_class, mtr.out_msg_data, mtr.usi, mtr.prev_usi, mtr.template_name, mtr.transmit_id, mtr.sdr_repository " +
					"FROM input_msg_store ims, msg_to_report mtr, msg_status ms WHERE ims.send_id = mtr.send_id AND mtr.asset_class = ms.asset_class AND " +
					"mtr.msg_type = ms.msg_type AND mtr.send_id = ms.send_id AND ims.src_tlc_event= ? AND mtr.msg_type = ? AND  " +
					"mtr.asset_class = ? AND  ims.usi = ? AND ms.status = ? ORDER BY mtr.send_id DESC",this, tlcEvent, msgType, assetClass, usi, status);
			}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}
	
	
	@Transactional
	public List<MsgToReport> findLastSubmitedByTraceId(String traceId,String msgType)
			throws MsgToReportDaoException {
		try {
			return jdbcTemplate.query("SELECT mtr.send_id, mtr.msg_type, mtr.create_datetime, mtr.asset_class, mtr.out_msg_data, mtr.usi, mtr.prev_usi, mtr.template_name, mtr.transmit_id, mtr.sdr_repository FROM msg_to_report mtr, mapping_sdr_enconnect enc"
					+ " where mtr.send_id=enc.send_id and enc.trace_id=? and mtr.msg_type not in ('ICEMessageType', ?) having mtr.create_datetime = max(mtr.create_datetime) order by create_datetime desc"
					,this, traceId,msgType);
			}
		catch (Exception e) {
			throw new MsgToReportDaoException(Constants.EXCEPTION+"Query failed", e);
		}
	}
	
	
	
	private class RowMapperWithStatus implements ParameterizedRowMapper<MsgToReportStatus>{

		@Override
		public MsgToReportStatus mapRow(ResultSet rs, int rowNum) throws SQLException {
			MsgToReportStatus dtoStatus = new MsgToReportStatus();
			
			MsgToReport dto = new MsgToReport();
			dto.setSendId( rs.getBigDecimal("send_id"));
			dto.setMsgType( rs.getString("msg_type"));
			dto.setCreateDatetime( rs.getTimestamp("create_datetime"));
			dto.setAssetClass( rs.getString("asset_class"));
			dto.setOutMsgData( rs.getString("out_msg_data"));
			dto.setUsi( rs.getString("usi") );
			dto.setPrevUsi( rs.getString("prev_usi"));
			dto.setTemplateName( rs.getString("template_name"));
			dto.setTransmitId(rs.getBigDecimal("transmit_id"));
			
			dtoStatus.setStatus(rs.getString("status"));
			dtoStatus.setMsgToReport(dto);			
			return dtoStatus;
			
		}
		
	}
}
