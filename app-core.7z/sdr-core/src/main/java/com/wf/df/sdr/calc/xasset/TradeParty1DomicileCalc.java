package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class TradeParty1DomicileCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	
	
	@Calculation(value = Calc.tradeParty1DomicileCalc, isPrototype=false)
	public String calcTrdParty1Domicile(
			@DerivedFrom(value = Stv.OurStreet, isInternal=true)String ourStreet,
			@DerivedFrom(value = Stv.OurCity, isInternal=true)String ourCity,
			@DerivedFrom(value = Stv.OurState, isInternal=true)String ourState,			
			@DerivedFrom(value = Stv.OurZip, isInternal=true)String ourZip,
			@DerivedFrom(value = Stv.OurCountry, isInternal=true)String ourCountry) {

      logger.debug("calling------------ TradeParty1Domicile ");
      String address = null;
      if(!Utils.IsNullOrBlank(ourStreet))
    	  address=ourStreet;       
      if(!Utils.IsNullOrBlank(ourCity))
    	  address=address+Constants.COMMA+ourCity;
      if(!Utils.IsNullOrBlank(ourState))
    	  address=address+Constants.COMMA+ourState;
      if(!Utils.IsNullOrBlank(ourZip))
    	  address=address+Constants.COMMA+ourZip;
      if(!Utils.IsNullOrBlank(ourCountry))
    	  address=address+Constants.COMMA+ourCountry;
    	  
      if(!Utils.IsNullOrBlank(address))
	      	return address.replaceAll("[\n\r]", Constants.SPACE);
	      
	      return Constants.EMPTY_STRING;
	      
      //return ourStreet+Constants.COMMA+ourCity+Constants.COMMA+ourState+Constants.COMMA+ourZip+Constants.COMMA+ourCountry;
		
	}
}
