package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class AdditionalRepository3ValueCalc {
	
	@Calculation(value = Calc.additionalRepository3ValueCalc, isPrototype = false)
	public String compute (
			@DerivedFrom(value = Calc.isCadReportableCalc, isInternal = true) boolean isCadReportableCalc,
			@DerivedFrom(value = Calc.currentReportingJurisdictionCalc, isInternal = true) String juridiction
			) {
		
		if(isCadReportableCalc){			
			
			String reString="";
			String [] juridictions = juridiction.split(";");
			for(String j :juridictions){
				if(!reString.isEmpty())
					reString=reString+";";
				if(!StringUtils.containsIgnoreCase(j, Constants.CFTC))
					reString=reString+"NRP:"+j;
			}
			return reString;
		}			
			
		return Constants.EMPTY_STRING;
	}

}
