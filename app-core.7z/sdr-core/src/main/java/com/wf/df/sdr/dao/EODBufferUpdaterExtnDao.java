package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.EODBufferRecord;
import com.wf.df.sdr.dto.EODBufferStore;
import com.wf.df.sdr.util.Utils;

@Repository
public class EODBufferUpdaterExtnDao {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	EODBufferStoreDao snapshotDao;
	
	
	String  bufferUpdateFxQuery = "SELECT s.usi , s.asset_class , s.send_id, s.msg_buffer, s.update_datetime, s.msg_type, i.src_trade_id, i.src_system_name, i.sdr_repository, i.src_trade_date,i.src_trade_version FROM eod_buffer_store s, input_msg_store i "+
				" WHERE s.send_id = i.send_id AND s.usi = i.usi AND datalength(s.msg_buffer) > 0 AND s.update_datetime = CONVERT (DATE, GETDATE(), 101) " + 
				" AND (i.src_tlc_event = 'Cancellation' OR i.src_trade_status in ('VERIFIED','DAY_VERIFIED','PENDING','DAY_PENDING','CH_TOBE_VER','TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','DAY_FO_REVIEW','FO_REVIEW')) AND s.asset_class = ? AND s.msg_type = ? AND s.sdr_repository = ? ";
						
				
	
	String bufferUpdateQuery = "SELECT s.usi , s.asset_class , s.send_id, s.msg_buffer, s.update_datetime, s.msg_type, i.src_trade_id, i.src_system_name, i.sdr_repository, i.src_trade_date,i.src_trade_version FROM eod_buffer_store s, input_msg_store i "+
				" WHERE s.send_id = i.send_id AND s.usi = i.usi AND datalength(s.msg_buffer) > 0 " +
				" AND src_trade_status in ('VERIFIED','DAY_VERIFIED','PENDING','DAY_PENDING','CH_TOBE_VER','TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','DAY_FO_REVIEW','FO_REVIEW') AND s.asset_class = ? AND s.msg_type = ? AND s.sdr_repository = ? ";
	
	String eodFindUniqueCMEUsiQuery=" SELECT DISTINCT s.usi FROM eod_buffer_store s, input_msg_store i " +
			" WHERE s.send_id = i.send_id AND s.usi = i.usi AND datalength(s.msg_buffer) > 0 " +
			" AND src_trade_status in ('VERIFIED','DAY_VERIFIED','PENDING','DAY_PENDING','CH_TOBE_VER','TOBE_VER', 'PRE_BOOKED', 'BOOKED', 'SHADOW_SDR','DAY_FO_REVIEW','FO_REVIEW') AND asset_class = ? AND msg_type = ? AND s.sdr_repository = ? ";
	
	String bufferLookUpQuery= " SELECT TOP 1 buffer_data,ims.send_id FROM input_msg_store ims, eod_buffer_store nrm,buffer_store bs WHERE  ims.send_id=nrm.send_id AND ims.buffer_id=bs.buffer_id AND nrm.usi  = ? ORDER BY bs.buffer_id DESC ";
	
	@Transactional
	public List<EODBufferRecord> fetchEODIncrementalBufferUpdatedTradeforReport(String assetClass, String msgType,String sdrRepository) {
		List<EODBufferRecord> rsList = jdbcTemplate.query(bufferUpdateFxQuery,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						m.setUsi(rs.getString("usi"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						record.setTradeId(rs.getString("src_trade_id")+":"+rs.getString("src_trade_version"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<EODBufferRecord> fetchEODTradeBufferUpdateforReport(String assetClass, String msgType, String sdrRepository) {
		List<EODBufferRecord> rsList = jdbcTemplate.query(bufferUpdateQuery,new Object[] {assetClass, msgType,sdrRepository}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final EODBufferRecord record = new EODBufferRecord();
						final EODBufferStore m = new EODBufferStore();
						m.setUsi(rs.getString("usi"));
						m.setAssetClass(rs.getString("asset_class"));
						m.setMsgBuffer(rs.getString("msg_buffer"));
						m.setSendId(rs.getBigDecimal("send_id"));
						m.setUpdateDatetime(rs.getDate("update_datetime"));
						m.setMsgType(rs.getString("msg_type"));
						m.setSdrRepository(rs.getString("sdr_repository"));
						
						record.setTradeId(rs.getString("src_trade_id")+":"+rs.getString("src_trade_version"));
						record.setSrcSystemName(rs.getString("src_system_name"));
						
						String tradeDate = rs.getString("src_trade_date");						
						if(!Utils.IsNullOrBlank(tradeDate) && !"null".equalsIgnoreCase(tradeDate)){
							record.setTradeDate(tradeDate);
						}
						
						record.setEodBufferStore(m);
						return record;
					}
				});
		return rsList;

	}
	
	@Transactional
	public List<String> findDistinctCMEUsi(String assetClass, String msgType, String sdrRepository) 
	{
		List<String> usiLst= jdbcTemplate.queryForList(eodFindUniqueCMEUsiQuery,String.class,assetClass,msgType,sdrRepository);
		return  usiLst;
	}
	
	@Transactional
	public Map<String,Object> findStvBufferForUsi(String usi)
	{
		Map<String,Object> bufferMap = jdbcTemplate.queryForMap(bufferLookUpQuery, usi);
		if (bufferMap == null || bufferMap.isEmpty() || bufferMap.get("buffer_data") == null) {
			return null;
		} else {
			return bufferMap;
		}
		
	}
	
	@Transactional
	public int updateEodMsgBuffer(String buffer, String sdrRepository, String usi, String msgType) 
	{
		String usiUpdateQuery="UPDATE eod_buffer_store SET msg_buffer = ?, update_datetime = getDate(), sdr_repository=? where usi = ? AND msg_type = ?";
		return jdbcTemplate.update(usiUpdateQuery, buffer, sdrRepository, usi, msgType ) ;
	}
	
	@Transactional
	public int updateImsData(String usi,String sdrRepository,String msgType)
	{
		String usiUpdateImsQuery=" UPDATE input_msg_store SET sdr_repository = ? where send_id in (SELECT nrm.send_id FROM input_msg_store ims, eod_buffer_store nrm WHERE  ims.send_id=nrm.send_id AND nrm.sdr_repository='CME' and nrm.usi  = ? and nrm.msg_type  = ?) ";
		
		return jdbcTemplate.update(usiUpdateImsQuery, sdrRepository,  usi,msgType ) ;
	}

	@Transactional
	public int updateEodMsgBufferEmir(String dataToSend, String usi,String msgType, String sdrRepository) 
	{
		String usiUpdateQuery="UPDATE eod_buffer_store_emir SET msg_buffer = ?, update_datetime = getDate() where  msg_type = ? and send_id = (select max(send_id) from eod_buffer_store_emir where is_duplicate=0 and is_buffer_eligible=1 and uti = ?  AND sdr_repository = ? )"; 
		return jdbcTemplate.update(usiUpdateQuery, dataToSend,msgType, usi, sdrRepository ) ;
	}
} 