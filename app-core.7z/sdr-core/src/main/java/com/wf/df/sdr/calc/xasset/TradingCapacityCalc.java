package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class TradingCapacityCalc {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value =  Calc.tradingCapacityCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable,
			@DerivedFrom(value=Stv.EMIR_US_TRADING_CAPACITY,isInternal = true) String tradingCapacity){
				
		if(isDtccDelegatedTrade||isEmirDelegatedTrade||isEmirReportable){
			if(!Utils.IsNullOrBlank(tradingCapacity))
				return tradingCapacity;
		else
			throw new CalculationException(Stv.EMIR_US_TRADING_CAPACITY,"is Not a Valid Value " + tradingCapacity);
				
				
			
		}
						
		return Constants.EMPTY_STRING;
	
	}

}
