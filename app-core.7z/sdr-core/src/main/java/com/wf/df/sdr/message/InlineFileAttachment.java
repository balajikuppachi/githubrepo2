package com.wf.df.sdr.message;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAttachmentRef;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.wf.df.sdr.exception.InputOutputException;

@XmlRootElement(name = "result")
public class InlineFileAttachment {

	private Logger logger = Logger.getLogger(this.getClass().getName());
	
	
	private boolean emptyDocument;

	@XmlAttachmentRef()
	@XmlAttribute(name = "href")
	public DataHandler result;

	public DataHandler getResult() {
		return result;
	}
	
	public boolean isDocumentEmpty() {
		return emptyDocument;
	}
	
	public byte[] getDocumentAsByteArray() {

		ByteArrayOutputStream os = null;
		byte[] buffer = new byte[4096];
		try {
			emptyDocument = true;
			InputStream is = result.getInputStream();
			if (is != null) {
				if (is.available() < 1) {
					logger.info("Error reading WS Response, 0 bytes to read.");
					return null;
				}
				os = new ByteArrayOutputStream(buffer.length);
				while (is.read(buffer) != -1) {
					os.write(buffer);
				}
				os.flush();
				emptyDocument=false;
				return os.toByteArray();
			}
		} catch (IOException e) {
			logger.error("Error reading WS Response", e);
			throw new InputOutputException("Error reading WS Response", e);
		}

		return null;
	}

	public boolean saveDocument(String fileName) {

		FileOutputStream os = null;
		byte[] buffer = new byte[4096];

		try {
			emptyDocument = true;
			InputStream is = result.getInputStream();
			if (is != null) {
				// Check for empty files SG
				if (is.available() < 1) {
					logger.info("Error reading WS Response, 0 bytes to read.");
					return false;
				}
				os = new FileOutputStream(fileName);
				while (is.read(buffer) != -1) {
					os.write(buffer);
				}
				os.flush();
				emptyDocument = false;
				return true;
			}
		} catch (IOException e) {
			logger.error("Error reading WS Response", e);
			throw new InputOutputException("Error reading WS Response", e);
		}
		finally {
			if (os != null) {
				try {
					os.close();
				} catch (IOException ee) {
					logger.error("Error closing file in  WS Response", ee);
					throw new InputOutputException("Error closing file", ee);
				}
			}
		}
		return false;
	}
}
