package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class IsCMEReportableTradeCalc {

	@Value("${cme.valuation.rp}")
	String cmeValuationLEI;
	
	@Calculation(value = Calc.isCMEReportableTradeCalc, isPrototype = false)
	public boolean calculate(
			@DerivedFrom(value = Stv.CC_ClearingHouse, isInternal = true) String clearingHouse,
			@DerivedFrom(value = Stv.LEI_CP, isInternal = true) String cpLEI) {
					
		/*if(StringUtils.equalsIgnoreCase(clearingHouse, Constants.CME) || StringUtils.equalsIgnoreCase(clearingHouse, Constants.Chicago_Mercantile_Exchange) || 
				StringUtils.equalsIgnoreCase(clearingHouse,Constants.VCON_Chicago_Mercantile_Exchange))
			return true;	*/	
		/** STR-492	CME Valuations should be suppressed using LEI KWD instead of CC_ClearingHouse KWD*/
		String cpLeiValue=Utils.getElementAtIndex(cpLEI, 1, Constants.COLON);
		if(StringUtils.contains(cmeValuationLEI, cpLeiValue))
			return true;
		return false;
	}
	
}
