package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.exception.FilterException;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EmirReportingPartyFilter {

	Logger log = Logger.getLogger(getClass());
	@Autowired
	NotEligblePersister nep;

	public boolean isTradeEligible(UnitOfWork uow) {
		
		CalculationContext cc = uow.getCalculationContext();
		boolean isClearTrade = cc.getValue(Calc.clearedTradeCalc, Boolean.class);
		
		// Check for Cleared Trades first
		if (isClearTrade) 
			return true;
		
		// Check for reportable trades
		String reportingParty = cc.getValue(Stv.REPORTING_PARTY, String.class);
		if (Utils.IsNullOrBlank(reportingParty)) {
			nep.save(uow, NotEligblePersister.InvalidEmirRepParty);		
			throw new FilterException("ReportingPartyInvalid", "EMIR_REPORTING_PARTY is missing or not known");
		}
		else 
			return true;
		
	}
	
}
