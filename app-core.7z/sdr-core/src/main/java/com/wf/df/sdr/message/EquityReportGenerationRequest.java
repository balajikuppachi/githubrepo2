package com.wf.df.sdr.message;


public class EquityReportGenerationRequest {
	private String templateName;

	public EquityReportGenerationRequest(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplateName() {
		return templateName;
	}
}
