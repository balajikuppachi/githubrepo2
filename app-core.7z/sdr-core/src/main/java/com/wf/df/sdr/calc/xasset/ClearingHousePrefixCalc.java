package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class ClearingHousePrefixCalc {

	@Calculation(value = Calc.clearingHousePrefixCalc)
	public String clearingHousePrefix(
			@DerivedFrom(Stv.CC_ClearingHouse) String value)
	{
		// Until the LEI is revolved send it as empty
		// Clearing DCO Value is sent as True or False
		return Constants.EMPTY_STRING;
	}

}
