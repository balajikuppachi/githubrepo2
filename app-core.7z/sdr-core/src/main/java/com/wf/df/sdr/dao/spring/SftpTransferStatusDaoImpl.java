package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.SftpTransferStatusDao;
import com.wf.df.sdr.dto.SftpTransferStatus;
import com.wf.df.sdr.exception.dao.SftpTransferStatusDaoException;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class SftpTransferStatusDaoImpl extends AbstractDAO implements ParameterizedRowMapper<SftpTransferStatus>, SftpTransferStatusDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(SftpTransferStatus dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( create_datetime, fq_filename, status, direction ) VALUES ( ?, ?, ?, ? )",dto.getCreateDatetime(),dto.getFqFilename(),dto.getStatus(),dto.getDirection());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return SftpTransferStatus
	 */
	public SftpTransferStatus mapRow(ResultSet rs, int row) throws SQLException
	{
		SftpTransferStatus dto = new SftpTransferStatus();
		dto.setCreateDatetime( rs.getTimestamp(1 ) );
		dto.setFqFilename( rs.getString( 2 ) );
		dto.setStatus( rs.getString( 3 ) );
		dto.setDirection( rs.getString( 4 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "sftp_transfer_status";
	}

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria ''.
	 */
	@Transactional
	public List<SftpTransferStatus> findAll() throws SftpTransferStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, status, direction FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new SftpTransferStatusDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<SftpTransferStatus> findWhereCreateDatetimeEquals(Date createDatetime) throws SftpTransferStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, status, direction FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new SftpTransferStatusDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'fq_filename = :fqFilename'.
	 */
	@Transactional
	public List<SftpTransferStatus> findWhereFqFilenameEquals(String fqFilename) throws SftpTransferStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, status, direction FROM " + getTableName() + " WHERE fq_filename = ? ORDER BY fq_filename", this,fqFilename);
		}
		catch (Exception e) {
			throw new SftpTransferStatusDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'status = :status'.
	 */
	@Transactional
	public List<SftpTransferStatus> findWhereStatusEquals(String status) throws SftpTransferStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, status, direction FROM " + getTableName() + " WHERE status = ? ORDER BY status", this,status);
		}
		catch (Exception e) {
			throw new SftpTransferStatusDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the sftp_transfer_status table that match the criteria 'direction = :direction'.
	 */
	@Transactional
	public List<SftpTransferStatus> findWhereDirectionEquals(String direction) throws SftpTransferStatusDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, status, direction FROM " + getTableName() + " WHERE direction = ? ORDER BY direction", this,direction);
		}
		catch (Exception e) {
			throw new SftpTransferStatusDaoException("Query failed", e);
		}
		
	}

}
