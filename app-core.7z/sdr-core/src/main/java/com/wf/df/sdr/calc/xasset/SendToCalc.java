package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class SendToCalc {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value =  Calc.sendToCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value=Calc.sdrRepositoryCalc, isInternal = true) String sdrRepository,
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade){
					
		if(isDtccDelegatedTrade)
			return Constants.DTCCUS + Constants.SEMICOLON + Constants.DTCCEU;
		
		if(isEmirDelegatedTrade)
			return Constants.DTCCEU + Constants.SEMICOLON + Constants.DTCCEU;
		
		if(StringUtils.equals(sdrRepository, Constants.DTCC) || StringUtils.equals(sdrRepository, Constants.CAD))
			return Constants.DTCCUS;

		if(StringUtils.equals(sdrRepository, Constants.EMIR))
			return Constants.DTCCEU;
		
		return Constants.EMPTY_STRING;
	}

}
