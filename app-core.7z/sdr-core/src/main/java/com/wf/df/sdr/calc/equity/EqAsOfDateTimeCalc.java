package com.wf.df.sdr.calc.equity;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.util.Calc;

@Component
public class EqAsOfDateTimeCalc {

	@Autowired
	FormatterService formatter;
	
	@Calculation(value=Calc.eqAsOfDateTimeCalc, isPrototype=false)
		public String calculate(
			@DerivedFrom(value = Calc.currentDateCalc, isInternal = true) Date curDate) {
		
		return formatter.formatDateTimeUTC(curDate);	
				
	}
	
}
