package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EmirSubmitterValueCalc {

	@Value("${party1.id.Credit}") String party1IdCredit;
	@Value("${party1.id.Forex}") String party1IdForex;
	@Value("${party1.id.InterestRate}") String party1IdInterestRate;
	@Value("${wf.lei}") String wfLEI;
	@Value("${wfEur.lei}") String wfEurLEI;
	
	@Calculation(value = Calc.emirSubmitterValueCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass,
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String leiUs) {
		
		if(	(Constants.ASSET_CLASS_CREDIT.equals(assetClass) && Utils.IsNullOrBlank(party1IdCredit))
				|| (Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass) && Utils.IsNullOrBlank(party1IdInterestRate))
				|| (Constants.ASSET_CLASS_FOREX.equals(assetClass) && Utils.IsNullOrBlank(party1IdForex))	){
			
			if(!Utils.IsNullOrBlank(wfEurLEI) && !Utils.IsNullOrBlank(leiUs)){
				if(StringUtils.contains(wfEurLEI, Utils.getElementAtIndex(leiUs, 1, Constants.COLON)))
					return Utils.getElementAtIndex(leiUs, 1, Constants.COLON);
			}
				
			return wfLEI;	
		
		}
		
		String participantId = null;
		// QA Only
		if (Constants.ASSET_CLASS_CREDIT.equals(assetClass)) {
			if (!Utils.IsNullOrBlank(party1IdCredit)) {
				participantId = party1IdCredit;
			}
		} else if (Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass)) {
			if (!Utils.IsNullOrBlank(party1IdInterestRate)) {
				participantId = party1IdInterestRate;
			}
		}else if (Constants.ASSET_CLASS_FOREX.equals(assetClass)) {
			if (!Utils.IsNullOrBlank(party1IdForex)) {
				participantId = party1IdForex;
			}
		}
		
		if(!Utils.IsNullOrNone(participantId) && participantId.startsWith(Constants.DTCC)) 	
			return participantId.substring(4);
		
		return participantId;
				
				

	}
	
}
