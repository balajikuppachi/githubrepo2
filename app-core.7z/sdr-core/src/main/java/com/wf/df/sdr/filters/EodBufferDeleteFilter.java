package com.wf.df.sdr.filters;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EodBufferDeleteFilter {

	@Autowired
	NotEligblePersister nep;
	
	Logger logger = Logger.getLogger(getClass());
	
	public boolean deleteEODBuffer(UnitOfWork uow) {
		logger.debug("EodBufferDeleteFilter Called");
		
		CalculationContext cc = uow.getCalculationContext();
		String marketType = cc.getValue(Calc.srcTLCEventCalc, String.class);
		String usiPrevious = cc.getValue(Stv.USI_PREVIOUS, String.class);
		String usi = cc.getValue(Calc.computedUSICalc, String.class);
					
		if(StringUtils.equalsIgnoreCase(Constants.Exercise_Physical, marketType)) {
			if(!Utils.IsNullOrBlank(usiPrevious))
				nep.deleteEODBuffer(usiPrevious);
		} else if (StringUtils.equalsIgnoreCase(Constants.Bilateral_Cleared, marketType)){
			//Removing any instance saved in EOD store for this bilatereal trade
			logger.info("Ineligible Market Type: " + marketType);
			nep.save(uow, NotEligblePersister.BilateralCleared);
			nep.deleteEODBuffer(usi);
			return false;
		}
		
		return true;
	}
	
}
