package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class EqParty2USPersonCalc {

	@Calculation(value = Calc.eqParty2USPersonCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.UsPersonEntity_Cp, isInternal = true) String usPersonEntity)	{
		
		if("Y".equalsIgnoreCase(usPersonEntity))
			return Constants.TRUE;
		
		if("N".equalsIgnoreCase(usPersonEntity))
			return Constants.FALSE;
		
		return Constants.EMPTY_STRING;
	
	}
	
}
