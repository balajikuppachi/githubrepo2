package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;

@Component
public class EmirCalypsoTransactionTypeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	DTCCUtils dtccUtils;

	@Calculation(value = Calc.emirCalypsoTransactionTypeCalc, isPrototype = false)
	public String transactionType(
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String marketType,
			@DerivedFrom(value = Calc.sendBackloadCalc, isInternal = true) boolean backload) {
		
		if(backload)
			return Constants.Trade;
		
		if(StringUtils.equals(marketType, Constants.Novation_OR) || StringUtils.equals(marketType, Constants.Credit_Novation_OR) ||
				StringUtils.contains(marketType, Constants.Undo))
			return Constants.Exit;
		else 
			return Constants.Trade;

	}
}
