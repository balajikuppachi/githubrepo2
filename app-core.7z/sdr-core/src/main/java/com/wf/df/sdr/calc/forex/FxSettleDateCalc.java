package com.wf.df.sdr.calc.forex;

import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxSettleDateCalc {

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;

	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value = Calc.fxSettleDateCalc)
	public String calcSettleDate(
			@DerivedFrom(value = Stv.FXOptionSettleDate) String optionFxSettleDate,
			@DerivedFrom(value = Stv.FXSettleDateList) List<String> fxSettleDateList,
			@DerivedFrom(value = Calc.dtccProductTypeCalc) String dtccProductType,
			@DerivedFrom(value = Constants.FOREX_SWAP_LEG_INDEX, isInternal = true) Integer swapLegIndex)
		{		
		
		if(!Utils.IsNullOrBlank(dtccProductType))
		try {
			if(dtccProductType.equals(Constants.FOREX_OPTION) && !Utils.IsNullOrBlank(optionFxSettleDate))
			{	 return formatter.formatDateUTC(parser.parseDate(optionFxSettleDate));
			}else if(dtccProductType.equals(Constants.FOREX_FORWARD) && !Utils.IsListNullOrEmpty(fxSettleDateList))
			{ 
				if(!Utils.IsNullOrBlank(swapLegIndex))
					return formatter.formatDateUTC(parser.parseDate(fxSettleDateList.get(swapLegIndex)));		
				
				for(int i=0; i<fxSettleDateList.size(); i++){
					if(!Utils.IsNullOrBlank(fxSettleDateList.get(i)))
						return formatter.formatDateUTC(parser.parseDate(fxSettleDateList.get(i)));					
				}
				
			}
		} catch (ParseException e) {
			throw new CalculationException("Parse Exception", Stv.FXOptionSettleDate +"is in wrong format.");
		}
		return Constants.EMPTY_STRING;
	}
	
}
