package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;


@Component
public class FxUSIPrefixCalc {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Value("${usiPrefix}")
	private String usiPrefixOverride;

	@Calculation(value=Calc.fxUSIPrefixCalc)
	public String usi (@DerivedFrom(value = Calc.fxCalypsoComputedUSICalc) String calypsoUsi,
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliateTrade,
			@DerivedFrom(value = Calc.affiliateUsiCalc, isInternal = true) String affiliateUsi) {
		
		if(isAffiliateTrade){
			if(Utils.IsNullOrBlank(affiliateUsi))
				return Constants.GTRCREATE;
			calypsoUsi = affiliateUsi;
		}
		
		if (!Utils.IsNullOrBlank(usiPrefixOverride)) {
			return usiPrefixOverride;
		} else if (Utils.IsNullOrBlank(calypsoUsi)) {
			return Constants.WELLS;
		}else if (calypsoUsi.startsWith(Constants.DTCC)){
			return Constants.DTCC;
		}
		else {
			// First 10 positions of USI is the prefix
			return calypsoUsi.substring(0,10);
		}
	}
}