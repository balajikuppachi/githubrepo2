package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Utils;

@Component
public class DayCountCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	DTCCUtils dtccUtils;
	
	@Calculation(value = Calc.dayCountCalc)
	public String dayCount(
			MethodCalculationDefinition def,
			@DerivedFrom("field0") String value) {

		if (Utils.IsNullOrBlank(value)) {
			throw new CalculationException("error code?", "Field '" + def.getDependencyNames()[0] + "' must not be blank");
		}
		
		String dayCount = dtccUtils.getDayCount(value);
		if (dayCount != null) {
			return dayCount;
		} else {
			throw new CalculationException("error code?", "Unexpected value '" + def.getDependencyNames()[0] + "' = '" + value + "'");
		}
	}

}
