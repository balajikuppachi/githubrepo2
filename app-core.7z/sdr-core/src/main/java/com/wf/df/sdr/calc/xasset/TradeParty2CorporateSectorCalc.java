package com.wf.df.sdr.calc.xasset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class TradeParty2CorporateSectorCalc {
	
	@Autowired
	DTCCUtils utils;
	
	@Calculation(value=Calc.tradeParty2CorporateSectorCalc, isPrototype=false)
	public String calcTradeParty2CorporateSector(
			@DerivedFrom(value=Stv.EMIR_CP_TAXANOMY, isInternal = true) String emirCpTaxonomy,
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
            @DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
            @DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable){
		
		if (isDtccDelegatedTrade||isEmirDelegatedTrade||isEmirReportable){
			if (!Utils.IsNullOrBlank(emirCpTaxonomy)) {
				String ret = utils.getEmirCpTaxonomy(emirCpTaxonomy.toUpperCase());
					if (null != ret)
						return ret;
			}
			}
		return Constants.EMPTY_STRING;
	}
}
