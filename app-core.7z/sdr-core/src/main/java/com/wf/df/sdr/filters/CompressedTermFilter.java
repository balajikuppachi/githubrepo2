package com.wf.df.sdr.filters;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component(value = "compressedTermFilter")
public class CompressedTermFilter {

	@Autowired
	NotEligblePersister nep;

	Logger log = Logger.getLogger(getClass());

	public boolean isCompressedEligible(UnitOfWork uow) {
		CalculationContext cc = uow.getCalculationContext();

		String marketType = cc.getValue(Stv.MarketType, String.class);

		if (StringUtils.equalsIgnoreCase(Constants.Compressed_Term, marketType) || 
				StringUtils.equalsIgnoreCase(Constants.Compressed_PartialTerm, marketType)) {
				log.info("Ineligible Market Type: " + marketType);
				nep.save(uow, NotEligblePersister.CompressedTerm);
				//nep.deleteEODBuffer(uow.getUSI());
				return false;
		}
		return true;
	}
}
