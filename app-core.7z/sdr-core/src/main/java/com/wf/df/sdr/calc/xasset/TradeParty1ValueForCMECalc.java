package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Utils;

/**
 * 
 * @author u250429
 *
 */

@Component
public class TradeParty1ValueForCMECalc {

	@Calculation(value = Calc.tradeParty1ValueForCMECalc, isPrototype = false)
	public String wFPartyCalc(
			@DerivedFrom(value = Calc.wfParticipantIdCalc, isInternal = true) String wellsF) {

		if (!Utils.IsNullOrBlank(wellsF))
			return wellsF;

		return wellsF;

	}

}
