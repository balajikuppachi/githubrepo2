package com.wf.df.sdr.calc.forex;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxExchangedCurrency1PayerPrefixCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Calculation(value=Calc.fxExchangedCurrency1PayerPrefixCalc)
	public String fxOptionBuyerPrefixCalc(
			@DerivedFrom(value=Calc.fxWfParticipantIdPrefixCalc) String wfPrefix,
			@DerivedFrom(value=Calc.fxCptyParticipantIdPrefixCalc) String cptyPrefix,
			@DerivedFrom(value=Stv.WeBuySell) String buySellIndicator,
			@DerivedFrom(value=Constants.FOREX_SWAP_LEG, isInternal=true) String legType) 	{
		
		if (!Utils.IsNullOrBlank(buySellIndicator) && !Utils.IsNullOrBlank(legType)) {
			// The buySellIndicator comes in as Buy/Sell Meaning-> Wells is Buy in NearLeg and Sell in FarLeg
			// nearFar array 0th index is Near and 1th index is Far value ALWAYS! 
			String nearFar[] = StringUtils.split(buySellIndicator, Constants.BACKSLASH);
			if ( (nearFar.length > 1 )) {
				if (Constants.FOREX_SWAP_LEG_NEAR.equalsIgnoreCase(legType)) {
					return Constants.Buy.equalsIgnoreCase(nearFar[0]) ? cptyPrefix : wfPrefix;
				}
				else if (Constants.FOREX_SWAP_LEG_FAR.equalsIgnoreCase(legType)) {
					return Constants.Buy.equalsIgnoreCase(nearFar[1]) ? cptyPrefix : wfPrefix;
				}
			} 
		}
		//For the case of regular Forward not FXSwap
		else if(!Utils.IsNullOrBlank(buySellIndicator)  && Utils.IsNullOrBlank(legType))
		{
			
			boolean isBuyer = Constants.Buy.equalsIgnoreCase(buySellIndicator);
			
			if(isBuyer && !Utils.IsNullOrBlank(cptyPrefix))
			{	 return cptyPrefix;
			}else if(!isBuyer && !Utils.IsNullOrBlank(wfPrefix))
			{  	 return wfPrefix;
			}
			
		}
		return Constants.EMPTY_STRING;
	}
}
