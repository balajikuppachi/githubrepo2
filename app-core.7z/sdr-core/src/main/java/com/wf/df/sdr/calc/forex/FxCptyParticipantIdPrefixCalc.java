package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxCptyParticipantIdPrefixCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxCptyParticipantIdPrefixCalc, isPrototype=false)
	public String counterPartyPrefix(
			@DerivedFrom(value = Calc.cptyParticipantIdPrefixCalc, isInternal = true) String cptyPrefix) {
			return cptyPrefix;
	}
}
