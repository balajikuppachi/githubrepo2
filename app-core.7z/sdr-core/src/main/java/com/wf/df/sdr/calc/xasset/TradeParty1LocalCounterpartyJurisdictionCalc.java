package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class TradeParty1LocalCounterpartyJurisdictionCalc {
	
	
	@Value("${wf.lei}") String wfLEI;
	
	@Calculation(value = Calc.tradeParty1LocalCounterpartyJurisdictionCalc, isPrototype = false)
	public String compute (
			@DerivedFrom(value = Calc.isCadReportableCalc, isInternal = true) boolean isCadReportableCalc,
			@DerivedFrom(value = Calc.currentReportingJurisdictionCalc, isInternal = true) String jurisdiction,
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String party1,
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliate) {
		
		//check if party 1 is not Wells Fargo or its affiliates
		//if not put the jurisdictions there
			party1=Utils.getElementAtIndex(party1, 1, Constants.COLON);

		if(isCadReportableCalc && !StringUtils.equalsIgnoreCase(wfLEI,party1)  && !isAffiliate.booleanValue()){			
			
			String reString="";
			String [] juridictions = jurisdiction.split(";");
			for(String j :juridictions){
				if(!reString.isEmpty())
					reString=reString+";";
				if(!StringUtils.containsIgnoreCase(j, Constants.CFTC))
					reString=reString + j;
			}
			return reString;
		}			
			
		return  Constants.EMPTY_STRING;
	}

}
