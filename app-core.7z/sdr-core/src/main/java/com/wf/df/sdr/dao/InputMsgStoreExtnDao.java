package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.spring.InputMsgStoreDaoImpl;
import com.wf.df.sdr.dto.InputMsgStore;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Utils;

@Repository
public class InputMsgStoreExtnDao {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private ParameterizedRowMapper<InputMsgStore> inputMsgStoreRowMapper = new InputMsgStoreDaoImpl();
	
	@Value("${undo.amend.rates.query}") String undoAmendRatesQuery;
	@Value("${undo.amend.credit.query}") String undoAmendCreditQuery;
	@Value("${undo.term.rates.query}") String undoTermRatesQuery;
	@Value("${undo.term.credit.query}") String undoTermCreditQuery;
	@Value("${undo.partial.term.rates.query}") String undoPartialTermRatesQuery;
	@Value("${undo.partial.term.credit.query}") String undoPartialTermCreditQuery;
	
	private static String dtccTradeIdQuery=" SELECT i.src_trade_id, m.dtccusi FROM input_msg_store i, mapping_usi_dtccusi m WHERE m.send_id=i.send_id ";
	
	public Long findMaxSendIdInRange(Long from, Long to) {
		List<Long> maxIdList = jdbcTemplate.queryForList("select max(send_id) from input_msg_store where send_id >= ? and send_id <= ?", Long.class, from, to);
		if (maxIdList == null || maxIdList.isEmpty() || maxIdList.get(0) == null) {
			return null;
		} else {
			return maxIdList.get(0);
		}
	}
	
	public InputMsgStore findLatestTradeMessage(String sourceSystem, String tradeId, String tradeVersion) {
		List<InputMsgStore> list = jdbcTemplate.query("SELECT top 1 send_id, src_trade_version, src_system_name, src_trade_id, src_asset_class, src_prod_type, src_sub_prod_type, src_trade_date, src_mat_date, src_tlc_event, src_trade_status, src_cparty_name, src_exec_datetime, src_clearing_venue, src_clearing_datetime, src_conf_platform, src_conf_datetime, src_conf_id, usi, i.buffer_id, i.create_datetime, prev_usi, rep_party, party1_lei, party2_lei,is_backload,legs_associated,sdr_repository,uti,uti_previous,is_delegated, bus_acc_id   " +
				"from input_msg_store i where " +
				"i.src_system_name = ? and " +
				"i.src_trade_id = ? " +
				/** Patched: because Scrittura version - mismatch with SDR and Calypso 
				"i.src_trade_version = ? " +
				**/
				/*"i.sdr_repository = 'DTCC' " +*/
				"order by i.send_id desc",
				inputMsgStoreRowMapper,
				sourceSystem, tradeId);

		if (list == null || list.isEmpty() || list.get(0) == null) {
			return null;
		} else {
			return list.get(0);
		}
	}
	
	public String findUSIforTradeId(String assetClass, String tradeId) {
		logger.debug("fetch USI for trade id");
		List<String> list = jdbcTemplate.queryForList("SELECT TOP 1 usi FROM input_msg_store WHERE " +
				"src_asset_class = ? and src_trade_id = ? order by create_datetime desc", String.class, assetClass, tradeId);
		if (list == null || list.isEmpty() || list.get(0) == null) {
			return null;
		} else {
			return list.get(0);
		}
	}
	
	public String findUSIforSendId(BigDecimal sendId) {
		logger.debug("fetch USI for send id");
		List<String> list = jdbcTemplate.queryForList("SELECT usi FROM input_msg_store WHERE " +
				"send_id = ? ", String.class, sendId);
		if (list == null || list.isEmpty() || list.get(0) == null) {
			return null;
		} else {
			return list.get(0);
		}
	}

	public Integer findMatchingRecords(String usi, BigDecimal sendId) {
		List<Integer> records = jdbcTemplate.queryForList("SELECT COUNT(1) FROM input_msg_store WHERE usi = ? AND send_id = ?", Integer.class, usi	, sendId);
		if (records == null || records.isEmpty() || records.get(0) == null) {
			return null;
		} else {
			return records.get(0);
		}
	}
	
	public void updateUsiForSendId(BigDecimal sendId, String usi) {
		
		String query = "update  input_msg_store set usi = ? where send_id = ?";
		jdbcTemplate.update(query, usi, sendId) ;
		
	}
	
	public String[] findUsiAndLeiforSendId(BigDecimal sendId) {
		logger.debug("fetch USI for send id");
		List<String[]>  list = jdbcTemplate.query("SELECT src_trade_id,usi, party1_lei,uti FROM input_msg_store WHERE send_id = ? ", 
				new ParameterizedRowMapper<String[]>() {
					@Override
					public String[] mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						String[] arr = new String[4];
						arr[0] = rs.getString("src_trade_id");
						arr[1] = rs.getString("usi");
						arr[2] = rs.getString("party1_lei");
						arr[3] = rs.getString("uti");
						return arr;
					}
				
				}, sendId);
		if (list == null || list.isEmpty() || list.get(0) == null) {
			return null;
		} else {
			return list.get(0);
		}
	}
	
	public BigDecimal getUndoLCSendId(String usi, String assetClass, String marketType) {
		
		String query = null;
		
		if(assetClass == null || marketType == null)
			return null;
		
		if(Constants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(assetClass)) {
			if(Constants.Undo_Amend.equals(marketType))
				query = undoAmendRatesQuery;
			else if (Constants.Undo_Term.equals(marketType))
				query = undoTermRatesQuery;
			else if (Constants.Undo_Partial_Term.equals(marketType))
				query = undoPartialTermRatesQuery;
		} else if(Constants.ASSET_CLASS_CREDIT.equalsIgnoreCase(assetClass)) {
			if(Constants.Undo_Amend.equals(marketType))
				query = undoAmendCreditQuery;
			else if (Constants.Undo_Term.equals(marketType))
				query = undoTermCreditQuery;
			else if (Constants.Undo_Partial_Term.equals(marketType))
				query = undoPartialTermCreditQuery;
		}
		
		if(query == null)
			return null;
		
		String[] arr = new String[1];
		arr[0] = usi;
		
		BigDecimal sendId = jdbcTemplate.queryForObject(query, arr, BigDecimal.class);
		return sendId;
	}

	public List<String> findLatestTrade(String tradeId) 
	{
		logger.debug("fetch USI for trade id");
		List<String> list = jdbcTemplate.queryForList("SELECT distinct usi FROM input_msg_store i WHERE src_trade_id = ? and  not exists (select 1 from msg_not_eligible m where i.send_id=m.send_id and m.rule_code='USIPREVIOUS') order by send_id desc", String.class, tradeId);
		if(!Utils.IsListNullOrEmpty(list) && list.size()>1)
			list.remove(0);
		return list;
	}
	
	
	@Transactional
	public Map<String,String> findListOfTradeIdDtccUsi() {

		final Map<String,String> tradeIdDtccUsiMap=new ConcurrentHashMap<String, String>();
	
		jdbcTemplate.query(dtccTradeIdQuery,new RowMapper() {
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				tradeIdDtccUsiMap.put(rs.getString(1),rs.getString(2));
				return null;
			}
			});
		return tradeIdDtccUsiMap;
	}
}