package com.wf.df.sdr.calc.xasset;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class ExecTimeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.execTimeCalc)
	public Object execTime(
			MethodCalculationDefinition def,
			@DerivedFrom("execDatetime") String execTime,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String msgType,
			@DerivedFrom(value = Calc.calypsoTransactionTypeCalc, isInternal = true) String txnType,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String srcAssetClass,
			@DerivedFrom(value = Stv.TLC_EVENT_EXECUTION_DATETIME, isInternal=true) String tlcExecTime,
			@DerivedFrom(value = Constants.TradeType123_456, isInternal=true) String tradeType123_456,
			@DerivedFrom(value = Stv.TradeUpdateDatetime, isInternal=true) String tradeUpdateDatetime)
	{
		if(!Utils.IsNullOrBlank(srcAssetClass) && 
				(Constants.ASSET_CLASS_CREDIT.equals(srcAssetClass) || 
						Constants.ASSET_CLASS_INTEREST_RATE.equals(srcAssetClass))) {
			
			if(!Utils.IsNullOrBlank(msgType) && 
					(StringUtils.containsIgnoreCase(msgType,Constants.MESSAGE_TYPE_RT) || 
							StringUtils.containsIgnoreCase(msgType,Constants.MESSAGE_TYPE_PET) || 
								StringUtils.containsIgnoreCase(msgType,Constants.MESSAGE_TYPE_CONF))) {
				
				if(!Utils.IsNullOrBlank(txnType) && 
						StringUtils.containsIgnoreCase(txnType,Constants.Termination) ||
							StringUtils.containsIgnoreCase(txnType,Constants.Amendment) ||
								StringUtils.containsIgnoreCase(txnType,Constants.Novation) ) {
					
					if(Constants.Reportable123.equals(tradeType123_456)){
						if(!Utils.IsNullOrBlank(tlcExecTime))
							execTime = tlcExecTime;
						else
							throw new CalculationException("ExecTimeCalc", "ExecTimeCalc calculation: TLC_EVENT_EXECUTION_DATETIME unavailable");
					} 
					else if (!Utils.IsNullOrBlank(tlcExecTime))
							execTime = tlcExecTime; //If TLCExec Time is there, use that. 
				}	
			}
		}
	/*	if(Utils.IsNullOrBlank(execTime))
			execTime=tradeUpdateDatetime;*/
		
		// TODO keyword to be provided by front office
		logger.debug("Value of ExecTimeCalc " + execTime);
		if (!Utils.IsNullOrBlank(execTime)) {
			Date dt;
			try {
				dt = parser.parseDateISOFirst(execTime);
				return formatter.formatDateTimeUTC(dt);
			} catch (Exception e) {
				throw new CalculationException("DateParse", "Field '" + def.getDependencyNames()[0] + "' = '" + execTime + "' cannot be interpreted as date");
			}
		}else{
			throw new CalculationException("ExecTimeCalc", "ExecTimeCalc calculation: Either TLC_EVENT_EXECUTION_DATETIME/EXECUTION_DATETIME unavailable.");
		}
		//return Constants.EMPTY_STRING;
	}

}
