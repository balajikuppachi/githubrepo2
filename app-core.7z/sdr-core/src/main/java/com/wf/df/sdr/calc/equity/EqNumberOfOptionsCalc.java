package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqNumberOfOptionsCalc {


	@Calculation(value = Calc.eqNumberOfOptionsCalc, isPrototype=false)
	public String calculate(
			@DerivedFrom(value = Stv.NumberOfOptions, isInternal = true) String numberOfoptions) {

		if (!Utils.IsNullOrBlank(numberOfoptions))
			return numberOfoptions;
		return Constants.EMPTY_STRING;
		
	}
}
