package com.wf.df.sdr.calc.forex;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxExecTimeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;

	@Autowired
	FormatterService formatter;

	@Calculation(value = Calc.fxExecTimeCalc)
	public Object execTime(
			MethodCalculationDefinition def,
			@DerivedFrom("execDatetime") String execTime,
			@DerivedFrom(value = Stv.TradeUpdateDatetime, isInternal=true) String tradeUpdateDatetime)
	{
		
		/*if(Utils.IsNullOrBlank(execTime))
			execTime=tradeUpdateDatetime;*/

		// TODO keyword to be provided by front office
		logger.debug("Value of ExecTimeCalc " + execTime);
		if (!Utils.IsNullOrBlank(execTime)) {
			Date dt;
			try {
				dt = parser.parseDateISOFirst(execTime);
				return formatter.formatDateTimeUTC(dt);
			} catch (Exception e) {
				throw new CalculationException("DateParse", "Field '" + def.getDependencyNames()[0] + "' = '" + execTime + "' cannot be interpreted as date");
			}
		}
		return Constants.EMPTY_STRING;
	}

}
