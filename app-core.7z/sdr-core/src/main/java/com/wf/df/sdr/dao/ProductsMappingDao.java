package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.ProductsMappingDao;
import com.wf.df.sdr.dto.ProductsMapping;
import com.wf.df.sdr.exception.dao.ProductsMappingDaoException;
import java.util.Date;
import java.util.List;

public interface ProductsMappingDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(ProductsMapping dto);

	/** 
	 * Returns all rows from the products_mapping table that match the criteria ''.
	 */
	public List<ProductsMapping> findAll() throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'src_asset_class = :srcAssetClass'.
	 */
	public List<ProductsMapping> findWhereSrcAssetClassEquals(String srcAssetClass) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'src_prod_type = :srcProdType'.
	 */
	public List<ProductsMapping> findWhereSrcProdTypeEquals(String srcProdType) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'src_sub_prod_type = :srcSubProdType'.
	 */
	public List<ProductsMapping> findWhereSrcSubProdTypeEquals(String srcSubProdType) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_asset_class = :dtccAssetClass'.
	 */
	public List<ProductsMapping> findWhereDtccAssetClassEquals(String dtccAssetClass) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_prod_type = :dtccProdType'.
	 */
	public List<ProductsMapping> findWhereDtccProdTypeEquals(String dtccProdType) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_sub_prod_type = :dtccSubProdType'.
	 */
	public List<ProductsMapping> findWhereDtccSubProdTypeEquals(String dtccSubProdType) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'dtcc_transaction_type = :dtccTransactionType'.
	 */
	public List<ProductsMapping> findWhereDtccTransactionTypeEquals(String dtccTransactionType) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'key_type = :keyType'.
	 */
	public List<ProductsMapping> findWhereKeyTypeEquals(String keyType) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'key_type_desc = :keyTypeDesc'.
	 */
	public List<ProductsMapping> findWhereKeyTypeDescEquals(String keyTypeDesc) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'jurisdiction = :jurisdiction'.
	 */
	public List<ProductsMapping> findWhereJurisdictionEquals(String jurisdiction) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<ProductsMapping> findWhereCreateDatetimeEquals(Date createDatetime) throws ProductsMappingDaoException;

	/** 
	 * Returns all rows from the products_mapping table that match the criteria 'mapping_type = :mappingType'.
	 */
	public List<ProductsMapping> findWhereMappingTypeEquals(String mappingType) throws ProductsMappingDaoException;

}
