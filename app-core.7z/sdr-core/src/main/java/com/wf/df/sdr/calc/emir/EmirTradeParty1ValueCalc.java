package com.wf.df.sdr.calc.emir;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EmirTradeParty1ValueCalc {
	
	@Calculation(value= Calc.emirTradeParty1ValueCalc, isPrototype = false)
	public String wFPartyCalc(
			@DerivedFrom(value = Calc.tradeParty1ValueCalc, isInternal = true) String wellsValue,
			@DerivedFrom(value = Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegated,
			@DerivedFrom(value = Calc.cptyParticipantIdCalc, isInternal = true) String cptyValue)	{
		
		if(isEmirDelegated)
		{
			return cptyValue;
		}else
		{
			return wellsValue;	
		}

	}			
	
}
