package com.wf.df.sdr.dao;

import com.wf.df.sdr.dto.IceValuationResponse;

public interface IceValuationResponseDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(IceValuationResponse dto);
	
}
