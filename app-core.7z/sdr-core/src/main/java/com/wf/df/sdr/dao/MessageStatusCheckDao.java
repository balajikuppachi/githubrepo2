package com.wf.df.sdr.dao;

import java.util.List;

import com.wf.df.sdr.dto.MessageStatusCheck;
import com.wf.df.sdr.exception.dao.MessageStatusCheckDaoException;

public interface MessageStatusCheckDao
{
	/**
	 * Method 'execute'
	 * 
	 * @param msg_type
	 * @param status
	 * @param asset
	 * @throws MessageStatusCheckDaoException
	 * @return List<MessageStatusCheck>
	 */
	public List<MessageStatusCheck> execute(String templateName, String status) throws MessageStatusCheckDaoException;
	public List<MessageStatusCheck> fetchMsgForEquityEODReport(String templateName, String msg_type, String status, String repository) throws MessageStatusCheckDaoException;
	public List<MessageStatusCheck> fetchMsgForCalypsoReport(java.lang.String assetClass, String messageType, String status, String sdrRepository) throws MessageStatusCheckDaoException;
	List<MessageStatusCheck> fetchMsgForCollReport(String messageType,String status, String sdrRepository) throws MessageStatusCheckDaoException;
	

}
