package com.wf.df.sdr.calc.equity;


import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqCptyParticipantIdPrefixCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	
	@Calculation(value= Calc.eqCptyParticipantIdPrefixCalc, isPrototype = false)
	public String wFPartyCalc(
			@DerivedFrom(value = Stv.LEI_CP, isInternal = true) String wellsFargoLEI)	{
		
		if (!Utils.IsNullOrNone(wellsFargoLEI)) {
			return (StringUtils.substringBefore(wellsFargoLEI, Constants.COLON)).toUpperCase();
		}
		throw new CalculationException("LEIFNF", "Fields not defined : [" + Stv.LEI_CP + "]");
	}			
}
