package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;

@Component
public class FxExecutionVenueCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxExecutionVenueCalc)
	public String executionVenue(
			@DerivedFrom(Stv.ECN_Source) String ecn,
			@DerivedFrom(Stv.CC_SendForClearing) String sent,
			@DerivedFrom(Stv.CC_ClearedDateTime) String date)
	{
		return "Off-Facility";

	}
}
