package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.MappingSdrIceDao;
import com.wf.df.sdr.dto.MappingSdrIce;
import com.wf.df.sdr.exception.dao.MappingSdrIceDaoException;

public class MappingSdrIceDaoImpl extends AbstractDAO implements
		ParameterizedRowMapper<MappingSdrIce>, MappingSdrIceDao {
	
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName() {
		return "mapping_sdr_ice";
	}
	

	/**
	 *  {@inheritDoc} 
	 */
	@Transactional
	public void insert(MappingSdrIce dto) throws MappingSdrIceDaoException {
		try {
			jdbcTemplate.update("INSERT INTO " + getTableName() + " (sender_trade_ref_id, upi, ice_status, create_datetime) " 
					+ "VALUES (?, ?, ?, ?)", dto.getSenderTradeRefId(), dto.getUpi(), dto.getIceStatus(), dto.getCreateDatetime());
		} catch (Exception e) {
			throw new MappingSdrIceDaoException("Query failed", e);
		}
	}
	
	/**
	 *  {@inheritDoc} 
	 */
	@Transactional
	public void update(MappingSdrIce dto) throws MappingSdrIceDaoException {
		try {
			jdbcTemplate.update("UPDATE " + getTableName() + " set upi=?, update_datetime=?, ice_status=? where sender_trade_ref_id=?",
					dto.getUpi(), dto.getUpdateDatetime(), dto.getIceStatus(), dto.getSenderTradeRefId());
		} catch (Exception e) {
			throw new MappingSdrIceDaoException("Query failed", e);
		}
	}
	
	/**
	 *  {@inheritDoc} 
	 */
	@Transactional
	public List<MappingSdrIce> findAll() throws MappingSdrIceDaoException {
		try {
			return jdbcTemplate.query("SELECT sender_trade_ref_id, upi, ice_status, create_datetime, update_datetime FROM " + getTableName(), this);
		} catch (Exception e) {
			throw new MappingSdrIceDaoException("Query failed", e);
		}
	}
	
	/**
	 *  {@inheritDoc} 
	 */
	@Transactional
	public List<MappingSdrIce> findWhereSenderTradeRefIdEquals(String senderTradeRefId) throws MappingSdrIceDaoException {
		try {
			return jdbcTemplate.query("SELECT sender_trade_ref_id, upi, ice_status, create_datetime, update_datetime FROM " 
					+ getTableName() + " WHERE sender_trade_ref_id = ? ORDER BY sender_trade_ref_id", this, senderTradeRefId);
		}
		catch (Exception e) {
			throw new MappingSdrIceDaoException("Query failed", e);
		}
	}
	
	/**
	 *  {@inheritDoc} 
	 */
	@Transactional
	public List<MappingSdrIce> findWhereUpiIdEquals(String upi) throws MappingSdrIceDaoException {
		try {
			return jdbcTemplate.query("SELECT sender_trade_ref_id, upi, ice_status, create_datetime, update_datetime FROM " 
					+ getTableName() + " WHERE upi = ? ORDER BY upi", this, upi);
		}
		catch (Exception e) {
			throw new MappingSdrIceDaoException("Query failed", e);
		}
	}

	/**
	 *  {@inheritDoc} 
	 */
	@Transactional
	public List<MappingSdrIce> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingSdrIceDaoException {
		try {
			return jdbcTemplate.query("SELECT sender_trade_ref_id, upi, ice_status, create_datetime, update_datetime FROM " 
					+ getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this, createDatetime);
		}
		catch (Exception e) {
			throw new MappingSdrIceDaoException("Query failed", e);
		}
	}
	
	/**
	 *  {@inheritDoc} 
	 */
	@Transactional
	public List<MappingSdrIce> findWhereUpdateDatetimeEquals(Date updateDatetime) throws MappingSdrIceDaoException {
		try {
			return jdbcTemplate.query("SELECT sender_trade_ref_id, upi, ice_status, create_datetime, update_datetime FROM " 
					+ getTableName() + " WHERE update_datetime = ? ORDER BY update_datetime", this, updateDatetime);
		}
		catch (Exception e) {
			throw new MappingSdrIceDaoException("Query failed", e);
		}
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return RecvBufferStore
	 */
	public MappingSdrIce mapRow(ResultSet rs, int row) throws SQLException {
		MappingSdrIce dto = new MappingSdrIce();
		int i = 1;
		dto.setSenderTradeRefId(rs.getString(i++));
		dto.setUpi(rs.getString(i++));
		dto.setIceStatus(rs.getString(i++));
		dto.setCreateDatetime(rs.getTimestamp(i++));
		dto.setUpdateDatetime(rs.getTimestamp(i++));
		return dto;
	}

}
