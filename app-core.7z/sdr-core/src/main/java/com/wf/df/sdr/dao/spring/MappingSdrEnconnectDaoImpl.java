package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.MappingSdrEnconnectDao;
import com.wf.df.sdr.dto.MappingSdrEnconnect;
import com.wf.df.sdr.exception.dao.MappingSdrEnconnectDaoException;

public class MappingSdrEnconnectDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MappingSdrEnconnect>, MappingSdrEnconnectDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(MappingSdrEnconnect dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( send_id, trace_id, status, create_datetime, buffer_id ,msg_type) " +
				"VALUES ( ?, ?, ?, ?, ?,? )",dto.getSendId(),dto.getTraceId(),dto.getStatus(),dto.getCreateDatetime(), dto.getBufferId(),dto.getMsgType());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return RecvBufferStore
	 */
	public MappingSdrEnconnect mapRow(ResultSet rs, int row) throws SQLException
	{
		MappingSdrEnconnect dto = new MappingSdrEnconnect();
		dto.setSendId(rs.getBigDecimal(1));
		dto.setTraceId(rs.getString(2));
		dto.setStatus(rs.getString(3));
		dto.setCreateDatetime(rs.getTimestamp(4));
		dto.setBufferId(rs.getBigDecimal(5));
		dto.setMsgType(rs.getString(6));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "mapping_sdr_enconnect";
	}

	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria ''.
	 */
	@Transactional
	public List<MappingSdrEnconnect> findAll() throws MappingSdrEnconnectDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trace_id, status, create_datetime, buffer_id, msg_type FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MappingSdrEnconnectDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'send_id = :send_id'.
	 */
	@Transactional
	public List<MappingSdrEnconnect> findWhereSendIdEquals(BigDecimal send_id) throws MappingSdrEnconnectDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trace_id, status, create_datetime, buffer_id, msg_type FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,send_id);
		}
		catch (Exception e) {
			throw new MappingSdrEnconnectDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'trace_id = :trace_id'.
	 */
	@Transactional
	public List<MappingSdrEnconnect> findWhereTraceIdEquals(String trace_id) throws MappingSdrEnconnectDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trace_id, status, create_datetime, buffer_id, msg_type FROM " + getTableName() + " WHERE trace_id = ? ORDER BY trace_id", this,trace_id);
		}
		catch (Exception e) {
			throw new MappingSdrEnconnectDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'status = :status'.
	 */
	@Transactional
	public List<MappingSdrEnconnect> findWhereStatusEquals(String status) throws MappingSdrEnconnectDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trace_id, status, create_datetime, buffer_id, msg_type FROM " + getTableName() + " WHERE status = ? ORDER BY status", this,status);
		}
		catch (Exception e) {
			throw new MappingSdrEnconnectDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<MappingSdrEnconnect> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingSdrEnconnectDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trace_id, msg_type, create_datetime, buffer_id, msg_type FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new MappingSdrEnconnectDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'buffer_id = :buffer_id'.
	 */
	@Transactional
	public List<MappingSdrEnconnect> findWhereBufferIdEquals(BigDecimal buffer_id) throws MappingSdrEnconnectDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trace_id, msg_type, create_datetime, buffer_id, msg_type FROM " + getTableName() + " WHERE buffer_id = ? ORDER BY buffer_id", this,buffer_id);
		}
		catch (Exception e) {
			throw new MappingSdrEnconnectDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the mapping_sdr_enconnect table that match the criteria 'buffer_id = :buffer_id'.
	 */
	@Transactional
	public List<MappingSdrEnconnect> findWhereMsgTypeEquals(String msgType) throws MappingSdrEnconnectDaoException
	{
		try {
			return jdbcTemplate.query("SELECT send_id, trace_id, msg_type, create_datetime, buffer_id, msg_type FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msgType);
		}
		catch (Exception e) {
			throw new MappingSdrEnconnectDaoException("Query failed", e);
		}
		
	}

}
