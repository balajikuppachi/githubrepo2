package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.MappingSdrEndurDao;
import com.wf.df.sdr.dto.MappingSdrEndur;
import com.wf.df.sdr.exception.dao.MappingSdrEndurDaoException;

public class MappingSdrEndurDaoImpl extends AbstractDAO implements ParameterizedRowMapper<MappingSdrEndur>, MappingSdrEndurDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(MappingSdrEndur dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( endur_id, sender_trade_ref_id, create_datetime) " +
				"VALUES ( ?, ?, ? )",dto.getEndurId(),dto.getSenderTradeRefId(),dto.getCreateDatetime());
	}
	
	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return RecvBufferStore
	 */
	public MappingSdrEndur mapRow(ResultSet rs, int row) throws SQLException
	{
		MappingSdrEndur dto = new MappingSdrEndur();
		dto.setEndurId(rs.getString(1));
		dto.setSenderTradeRefId(rs.getString(2));
		dto.setCreateDatetime(rs.getTimestamp(3));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "mapping_sdr_endur";
	}

	/** 
	 * Returns all rows from the mapping_sdr_endur table that match the criteria ''.
	 */
	@Transactional
	public List<MappingSdrEndur> findAll() throws MappingSdrEndurDaoException
	{
		try {
			return jdbcTemplate.query("SELECT endur_id, sender_trade_ref_id, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new MappingSdrEndurDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the mapping_sdr_endur table that match the criteria 'endur_id = :endurId'.
	 */
	@Transactional
	public List<MappingSdrEndur> findWhereEndurIdEquals(String endurId)	throws MappingSdrEndurDaoException {
		try {
			return jdbcTemplate.query("SELECT endur_id, sender_trade_ref_id, create_datetime FROM " + getTableName() + " WHERE endur_id = ? ORDER BY endur_id", this,endurId);
		}
		catch (Exception e) {
			throw new MappingSdrEndurDaoException("Query failed", e);
		}
		
	}
	/** 
	 * Returns all rows from the mapping_sdr_endur table that match the criteria 'sender_trade_ref_id = :senderTradeRefId'.
	 */
	@Transactional
	public List<MappingSdrEndur> findWheresenderTradeRefIdEquals(String senderTradeRefId) throws MappingSdrEndurDaoException {
		try {
			return jdbcTemplate.query("SELECT endur_id, sender_trade_ref_id, create_datetime FROM " + getTableName() + " WHERE sender_trade_ref_id = ? ORDER BY sender_trade_ref_id", this,senderTradeRefId);
		}
		catch (Exception e) {
			throw new MappingSdrEndurDaoException("Query failed", e);
		}

	}

	/** 
	 * Returns all rows from the mapping_sdr_endur table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<MappingSdrEndur> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingSdrEndurDaoException
	{
		try {
			return jdbcTemplate.query("SELECT endur_id, sender_trade_ref_id, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new MappingSdrEndurDaoException("Query failed", e);
		}
		
	}
	
	@Transactional
	public int updateMappingSdrEndur(String endur_trade_id, String sender_trade_ref_id, String dateStr) {
		
		String newEndurID = null;
		String newSenderRefID = null;
		
		newEndurID = endur_trade_id + "_OLD_" + dateStr;
		newSenderRefID = sender_trade_ref_id + "_OLD_" + dateStr;
		
		try {			
			return jdbcTemplate.update("UPDATE " + getTableName() + " SET endur_id = ?, sender_trade_ref_id = ? WHERE endur_id =? and sender_trade_ref_id = ?", newEndurID, newSenderRefID ,endur_trade_id,sender_trade_ref_id);
		}
		catch (Exception e) {
			throw new MappingSdrEndurDaoException("Query failed", e);
		}
	}
}
