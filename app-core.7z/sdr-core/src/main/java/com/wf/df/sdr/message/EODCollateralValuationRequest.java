package com.wf.df.sdr.message;


public class EODCollateralValuationRequest {
	private String msgType;
	private String sdrRepository;
	
	public EODCollateralValuationRequest(String msgType, String sdrRepository) {
		this.msgType = msgType;
		this.sdrRepository = sdrRepository;
	}

	public String getMsgType() {
		return msgType;
	}

	/**
	 * @return the sdrRepository
	 */
	public String getSdrRepository() {
		return sdrRepository;
	}

}
