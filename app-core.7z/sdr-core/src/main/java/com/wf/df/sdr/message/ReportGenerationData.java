package com.wf.df.sdr.message;

import java.util.List;
import java.util.Map;

import com.wf.df.sdr.dto.MessageStatusCheck;

public class ReportGenerationData {

	
	private Map<String, List<MessageStatusCheck>> leiMap;
	
	private ReportGenerationRequest reportGenerationRequest;

	public Map<String, List<MessageStatusCheck>> getLeiMap() {
		return leiMap;
	}

	public void setLeiMap(Map<String, List<MessageStatusCheck>> leiMap) {
		this.leiMap = leiMap;
	}

	public ReportGenerationRequest getReportGenerationRequest() {
		return reportGenerationRequest;
	}
	
	public void setReportGenerationRequest(ReportGenerationRequest reportGenerationRequest) {
		this.reportGenerationRequest = reportGenerationRequest;
	}
	
}
