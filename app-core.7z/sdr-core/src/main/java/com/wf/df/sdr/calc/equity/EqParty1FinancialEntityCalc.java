package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class EqParty1FinancialEntityCalc {

	@Calculation(value = Calc.eqParty1FinancialEntityCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Stv.Df_ETEU_EndUserType_Us, isInternal = true) String endUserType)	{
		
		if("Financial Entity".equalsIgnoreCase(endUserType))
			return Constants.TRUE;
		
		if("Non-Financial Entity".equalsIgnoreCase(endUserType))
			return Constants.FALSE;
		
		return Constants.EMPTY_STRING;
	
	}	
}
