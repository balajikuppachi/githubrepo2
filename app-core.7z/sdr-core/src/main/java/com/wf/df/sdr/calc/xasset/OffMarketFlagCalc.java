package com.wf.df.sdr.calc.xasset;

import java.text.ParseException;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class OffMarketFlagCalc {

	@Autowired
	FormatterService formatter;
	
	@Autowired
	ParserService parser;
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	
	@Calculation(value = Calc.offMarketFlagCalc, isPrototype = false)
	public String calculate(			
			@DerivedFrom(value = Stv.FeeAmountList, isInternal = true) List<String> feeAmountList,
			@DerivedFrom(value = Stv.FeeTypeList, isInternal = true) List<String> feeTypeList,
			@DerivedFrom(value = Calc.srcTLCEventCalc, isInternal = true) String marketType,
			@DerivedFrom(value = Constants.MESSAGE_TYPE, isInternal = true) String messageType) {
	
		//Set the OffMarketFlag as 'true' for RT-Termination, if TerminationFee is not there or the fee is zero.
		
		if(StringUtils.containsIgnoreCase(marketType, Constants.Termination) && 
				 Constants.MESSAGE_TYPE_RT.equalsIgnoreCase(messageType)) {
			
			String feeAmount = getTermFeeAmount(feeTypeList, feeAmountList);
			if(!Utils.IsNullOrBlank(feeAmount)) {
				try {
					Number fee = parser.parseNumber(feeAmount);
					if(fee.doubleValue() == 0) {
						return Constants.TRUE;
					} else {
						return Constants.EMPTY_STRING;
					}
				} catch (ParseException e) {
					logger.error("Error while parsing fee " + feeAmount, e);
					return Constants.EMPTY_STRING;
				}
			}
			return Constants.TRUE;
		}
		
		return Constants.EMPTY_STRING;
	}
	
	private String getTermFeeAmount(List<String> feeTypeList, List<String> feeAmountList){
		
		int index = -1;
		String feeAmount = null;
		
		if(!Utils.IsListNullOrEmpty(feeTypeList)) {
			for(int i = 0; i < feeTypeList.size(); i++){
				if(Constants.FeeType_TerminationFee.equalsIgnoreCase(feeTypeList.get(i))){
					index = i;
					break;
				}
			}
		}
		
		if(!Utils.IsListNullOrEmpty(feeAmountList) && index >= 0 && feeAmountList.size() > index) {
			feeAmount = feeAmountList.get(index);
		}
		
		return feeAmount;
		
	}
	
}
