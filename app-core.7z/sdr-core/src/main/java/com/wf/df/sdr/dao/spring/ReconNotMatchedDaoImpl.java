package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.ReconNotMatchedDao;
import com.wf.df.sdr.dto.ReconNotMatched;
import com.wf.df.sdr.exception.dao.ReconNotMatchedDaoException;

public class ReconNotMatchedDaoImpl extends AbstractDAO implements ParameterizedRowMapper<ReconNotMatched>, ReconNotMatchedDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(ReconNotMatched dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getAction(),dto.getMsgType(),dto.getAssetClass(),dto.getUsi(),dto.getUpi(),dto.getTradeDate(),dto.getExecDatetime(),dto.getMaturityDate(),dto.getSubmissionDatetime(),dto.getSubmitter(),dto.getNotionalCcy(),dto.getNotionalAmt(),dto.getParty1(),dto.getParty2(),dto.getParty1Reference(),dto.getStatus(),dto.getSdrName(),dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return ReconNotMatched
	 */
	public ReconNotMatched mapRow(ResultSet rs, int row) throws SQLException
	{
		ReconNotMatched dto = new ReconNotMatched();
		dto.setId( rs.getBigDecimal(1));
		dto.setAction( rs.getString( 2 ) );
		dto.setMsgType( rs.getString( 3 ) );
		dto.setAssetClass( rs.getString( 4 ) );
		dto.setUsi( rs.getString( 5 ) );
		dto.setUpi( rs.getString( 6 ) );
		dto.setTradeDate( rs.getDate(7 ) );
		dto.setExecDatetime( rs.getTimestamp(8 ) );
		dto.setMaturityDate( rs.getDate(9 ) );
		dto.setSubmissionDatetime( rs.getTimestamp(10 ) );
		dto.setSubmitter( rs.getString( 11 ) );
		dto.setNotionalCcy( rs.getString( 12 ) );
		dto.setNotionalAmt( rs.getString( 13 ) );
		dto.setParty1( rs.getString( 14 ) );
		dto.setParty2( rs.getString( 15 ) );
		dto.setParty1Reference( rs.getString( 16 ) );
		dto.setStatus( rs.getString( 17 ) );
		dto.setSdrName( rs.getString( 18 ) );
		dto.setCreateDatetime( rs.getTimestamp(19 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "recon_not_matched";
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria ''.
	 */
	@Transactional
	public List<ReconNotMatched> findAll() throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'id = :id'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereIdEquals(BigDecimal id) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE id = ? ORDER BY id", this,id);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'action = :action'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereActionEquals(String action) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE action = ? ORDER BY action", this,action);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereMsgTypeEquals(String msgType) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msgType);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'asset_class = :assetClass'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereAssetClassEquals(String assetClass) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE asset_class = ? ORDER BY asset_class", this,assetClass);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereUsiEquals(String usi) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'upi = :upi'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereUpiEquals(String upi) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE upi = ? ORDER BY upi", this,upi);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'trade_date = :tradeDate'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereTradeDateEquals(Date tradeDate) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE trade_date = ? ORDER BY trade_date", this,tradeDate);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'exec_datetime = :execDatetime'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereExecDatetimeEquals(Date execDatetime) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE exec_datetime = ? ORDER BY exec_datetime", this,execDatetime);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'maturity_date = :maturityDate'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereMaturityDateEquals(Date maturityDate) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE maturity_date = ? ORDER BY maturity_date", this,maturityDate);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'submission_datetime = :submissionDatetime'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereSubmissionDatetimeEquals(Date submissionDatetime) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE submission_datetime = ? ORDER BY submission_datetime", this,submissionDatetime);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'submitter = :submitter'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereSubmitterEquals(String submitter) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE submitter = ? ORDER BY submitter", this,submitter);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'notional_ccy = :notionalCcy'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereNotionalCcyEquals(String notionalCcy) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE notional_ccy = ? ORDER BY notional_ccy", this,notionalCcy);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'notional_amt = :notionalAmt'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereNotionalAmtEquals(String notionalAmt) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE notional_amt = ? ORDER BY notional_amt", this,notionalAmt);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'party1 = :party1'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereParty1Equals(String party1) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE party1 = ? ORDER BY party1", this,party1);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'party2 = :party2'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereParty2Equals(String party2) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE party2 = ? ORDER BY party2", this,party2);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'party1_reference = :party1Reference'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereParty1ReferenceEquals(String party1Reference) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE party1_reference = ? ORDER BY party1_reference", this,party1Reference);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'status = :status'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereStatusEquals(String status) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE status = ? ORDER BY status", this,status);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'sdr_name = :sdrName'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereSdrNameEquals(String sdrName) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE sdr_name = ? ORDER BY sdr_name", this,sdrName);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the recon_not_matched table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<ReconNotMatched> findWhereCreateDatetimeEquals(Date createDatetime) throws ReconNotMatchedDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, action, msg_type, asset_class, usi, upi, trade_date, exec_datetime, maturity_date, submission_datetime, submitter, notional_ccy, notional_amt, party1, party2, party1_reference, status, sdr_name, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new ReconNotMatchedDaoException("Query failed", e);
		}
		
	}

}
