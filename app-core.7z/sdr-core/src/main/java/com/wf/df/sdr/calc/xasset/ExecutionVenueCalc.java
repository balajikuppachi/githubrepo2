package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class ExecutionVenueCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.executionVenueCalc, isPrototype = false)
	public String executionVenue(
			@DerivedFrom(value = Calc.isSefTradeCalc, isInternal = true) Boolean sefTrade){

		 if (sefTrade)		
			 return Constants.SEF; 

		 return Constants.OFFFACILITY;

	}

}
