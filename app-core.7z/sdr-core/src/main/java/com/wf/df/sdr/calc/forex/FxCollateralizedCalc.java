package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.meta.CollateralService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class FxCollateralizedCalc {

	@Autowired
	CollateralService collateralService;
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(Calc.fxCollateralizedCalc)
	public String clearingHouse(
			@DerivedFrom(value=Stv.CC_ClearingHouse) String chValue,
			@DerivedFrom(value=Stv.CC_ClearedDateTime) String value,
			@DerivedFrom(value=Stv.CounterpartyShortName) String shortName,
			@DerivedFrom(value=Stv.BusinessAccountId) String businessAccountId,
			@DerivedFrom(value=Stv.CID_ID, isInternal=true) String equityCidId,		
			@DerivedFrom(value=Calc.clearedTradeCalc,isInternal=true) boolean clearTrade,
			@DerivedFrom(value=Calc.dtccAssetClassCalc,isInternal=true) String assetClass,
			@DerivedFrom(value=Stv.TradeId,isInternal=true) String tradeID){
		
		// If its ONLY CLEARED! then its FullyCollateralized
		if(clearTrade){
			return Constants.FullyCollateralized;
		}
		else {	
			tradeID = tradeID.replace("NL", "").replace("FL","");
						
			String calculatedValue = collateralService.getDTCCCollaterlizedValue(equityCidId,shortName,businessAccountId,assetClass, tradeID);
			
			if(Constants.FullyCollateralized.equals(calculatedValue))
				return "Fully";
			else if(Constants.PartiallyCollateralized.equals(calculatedValue))
				return "Partially";
			else if (Constants.OneWayCollateralized.equals(calculatedValue))
				return "One-Way";
			return calculatedValue;
		}
				
	}
}