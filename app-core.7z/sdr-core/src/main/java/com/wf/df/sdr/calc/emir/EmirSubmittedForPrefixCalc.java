package com.wf.df.sdr.calc.emir;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class EmirSubmittedForPrefixCalc {

	@Calculation(value = Calc.emirSubmittedForPrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.isDelegatedTradeCalc, isInternal = true) boolean isDelegated) {
		
		if(isDelegated)
			return Constants.BOTH;
		
		return Constants.EMPTY_STRING;

	}
		
}
