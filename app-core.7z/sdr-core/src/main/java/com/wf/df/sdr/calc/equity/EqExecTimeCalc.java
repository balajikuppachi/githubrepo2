package com.wf.df.sdr.calc.equity;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqExecTimeCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;
	
	@Calculation(value = Calc.eqExecTimeCalc, isPrototype=false)
	public Object execTime(
			@DerivedFrom(value = Stv.EXECUTION_DATETIME) String execTime) {
		if (!Utils.IsNullOrBlank(execTime)) {
			Date dt;
			try {
				dt = parser.parseDateISOFirst(execTime);
				return formatter.formatDateTimeUTC(dt);
			} catch (Exception e) {
				throw new CalculationException("DateParse", "Field '" + Stv.EXECUTION_DATETIME + "' = '" + execTime + "' cannot be interpreted as date");
			}
		}
		throw new CalculationException("DateParse", "Field '" + Stv.EXECUTION_DATETIME + "' = '" + execTime + "' cannot be NULL");
	}
}
