package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component(value="eqSECTradeFilter")
public class EqSECTradeFilter {
	
	@Autowired
	NotEligblePersister nep;
	
	Logger logger = Logger.getLogger(getClass());
	
	/**
	 * The function returns true OR false to indicate to the Spring Router (Filter) whether to continue processing OR not.
	 */

	public boolean isSECTrade(UnitOfWork uow) {
		logger.debug("Eq SECTradeFilter Called");
		CalculationContext cc = uow.getCalculationContext();
		
		String jurisdiction = cc.getValue(Stv.Reporting_Jurisdiction, String.class);
		
		if(!Utils.IsNullOrBlank(jurisdiction) && (jurisdiction.contains(Constants.CFTC) || jurisdiction.contains(Constants.CAD)))
			return true;	

		else {
			//Non CFTC trade shouldn't be reported
			nep.save(uow, NotEligblePersister.CFTC);
			nep.deleteEODBuffer(uow.getUSI());
			logger.debug("Trade not reportable As Reporting_Jurisdiction Is"+jurisdiction);
			return false;
		}	
		
	}
}
