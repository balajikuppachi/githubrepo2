package com.wf.df.sdr.calc;

import java.io.IOException;
import java.io.InputStream;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationRegistry;
import com.wf.df.sdr.calc.core.rule.CalculationDefinitionBuilder;
import com.wf.df.sdr.service.ApplicationCacheRefresh;
import com.wf.df.sdr.util.Calc;

@Component
public class ExtendedCalcs implements ApplicationCacheRefresh{
	
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	CalculationRegistry calculationRegistry;
	
	@Autowired
	CalculationDefinitionBuilder defBuilder;
	

	@PostConstruct
	public void initialize() throws IOException {
		registerRuleFromFile(Calc.sendRtRule, "/com/wf/df/sdr/calc/rule/rt_send_rules.txt");
		registerRuleFromFile(Calc.sendPetRule, "/com/wf/df/sdr/calc/rule/pet_send_rules.txt");
		registerRuleFromFile(Calc.sendConfirmRule, "/com/wf/df/sdr/calc/rule/confirm_send_rules.txt");
		registerRuleFromFile(Calc.sendDocumentRule,"/com/wf/df/sdr/calc/rule/document_send_rules.txt");
		registerRuleFromFile(Calc.galaxySendRtPetRule,"/com/wf/df/sdr/calc/rule/galaxy_send_rt_pet_rules.txt");
		registerRuleFromFile(Calc.galaxySendConfirmDocumentRule,"/com/wf/df/sdr/calc/rule/galaxy_send_confirm_document_rules.txt");
	}

	private void registerRuleFromFile(String calculationName, String ruleFilePath) throws IOException {
		
		InputStream inputStream = getClass().getResourceAsStream(ruleFilePath);
		try {
			calculationRegistry.addDefinition(defBuilder.createRuleFromFile(calculationName, inputStream));
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
		}
	}

}
