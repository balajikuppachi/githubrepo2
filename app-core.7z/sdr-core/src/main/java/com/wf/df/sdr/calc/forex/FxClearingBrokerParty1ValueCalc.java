package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class FxClearingBrokerParty1ValueCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value=Calc.fxClearingBrokerParty1ValueCalc, isPrototype=false)
	public String calculate() {

		//TODO : Add logic, waiting for FO
		return Constants.VALUE_NA;
	}

}
