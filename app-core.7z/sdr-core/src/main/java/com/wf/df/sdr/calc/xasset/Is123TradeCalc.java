package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class Is123TradeCalc {

	@Calculation(value = Calc.is123TradeCalc, isPrototype = false)
	public Boolean execTime(
			@DerivedFrom(value=Constants.TradeType123_456, isInternal=true) String tradeType123_456){
		
		if (Constants.NonReportable123.equals(tradeType123_456) || Constants.Reportable123.equals(tradeType123_456))
			return true;
		else
			return false;
	}
	
}
