package com.wf.df.sdr.dao;

import com.wf.df.sdr.dao.RecvMsgExceptionsDao;
import com.wf.df.sdr.dto.RecvMsgExceptions;
import com.wf.df.sdr.exception.dao.RecvMsgExceptionsDaoException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface RecvMsgExceptionsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(RecvMsgExceptions dto);

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria ''.
	 */
	public List<RecvMsgExceptions> findAll() throws RecvMsgExceptionsDaoException;

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'recv_id = :recvId'.
	 */
	public List<RecvMsgExceptions> findWhereRecvIdEquals(BigDecimal recvId) throws RecvMsgExceptionsDaoException;

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'msg_type = :msgType'.
	 */
	public List<RecvMsgExceptions> findWhereMsgTypeEquals(String msgType) throws RecvMsgExceptionsDaoException;

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'error_code = :errorCode'.
	 */
	public List<RecvMsgExceptions> findWhereErrorCodeEquals(String errorCode) throws RecvMsgExceptionsDaoException;

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'error_desc = :errorDesc'.
	 */
	public List<RecvMsgExceptions> findWhereErrorDescEquals(String errorDesc) throws RecvMsgExceptionsDaoException;

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<RecvMsgExceptions> findWhereCreateDatetimeEquals(Date createDatetime) throws RecvMsgExceptionsDaoException;

	/** 
	 * Returns all rows from the recv_msg_exceptions table that match the criteria 'usi = :usi'.
	 */
	public List<RecvMsgExceptions> findWhereUsiEquals(String usi) throws RecvMsgExceptionsDaoException;

}
