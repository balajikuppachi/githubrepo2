package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dto.CmTradeRecord;

@Repository
public class InputMsgStoreAndTradeAttributesExtnDao {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${endur.data.by.sendid.query}")	String dataRetrievalBySendIDQuery;
	
	@Value("${endur.data.by.tradeid.query}")	String dataRetrievalByTradeIDQuery;
	@Value("${endur.scrittura.confirm.data.query}")	String confirmDataRetrievalQuery;	
	@Transactional
	public List<CmTradeRecord> fetchEndurMsgDetailsBySendID(String sendID) {
		BigDecimal sendId = new BigDecimal(sendID);
		List<CmTradeRecord> rsList = jdbcTemplate.query(dataRetrievalBySendIDQuery,new Object[] {sendId}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final CmTradeRecord m = new CmTradeRecord();
						
						m.setSendID(rs.getBigDecimal(1));
						m.setSrcSystemName(rs.getString(2));
						m.setSrcTradeId(rs.getString(3));
						m.setSrcConfId(rs.getString(4));
						m.setSrcExecDatetime(rs.getDate(5));
						m.setUsi(rs.getString(6));
						m.setUpi(rs.getString(7));
						m.setConfirmBuyer(rs.getString(8));
						m.setConfirmSeller(rs.getString(9));
						m.setPrevUsi(rs.getString(10));
						m.setEconfirmFlag(rs.getString(11));
						m.setProductType(rs.getString(12));
						m.setLegsAssociated(rs.getInt(13));
						return m;
					}
				});
		return rsList;
	}
	
	@Transactional
	public List<CmTradeRecord> fetchEndurConfirmMsgDetails(String tradeID) {
		
		List<CmTradeRecord> rsList = jdbcTemplate.query(confirmDataRetrievalQuery,new Object[] {tradeID}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final CmTradeRecord m = new CmTradeRecord();
						m.setSendID(rs.getBigDecimal(1));
						m.setSrcConfId(rs.getString(2));
						m.setSrcTradeId(rs.getString(3));
						m.setUsi(rs.getString(4));
						m.setPrevUsi(rs.getString(5));
						m.setConfirmBuyer(rs.getString(6));
						return m;
					}
				});
		return rsList;
	}
	
	@Transactional
	public List<CmTradeRecord> fetchEndurMsgDetailsByTradeID(String tradeID) {
		List<CmTradeRecord> rsList = jdbcTemplate.query(dataRetrievalByTradeIDQuery,new Object[] {tradeID}, new RowMapper() {
					public Object mapRow(final ResultSet rs, final int rowNum) throws SQLException {
						final CmTradeRecord m = new CmTradeRecord();
						
						m.setSendID(rs.getBigDecimal(1));
						m.setSrcSystemName(rs.getString(2));
						m.setSrcTradeId(rs.getString(3));
						m.setSrcConfId(rs.getString(4));
						m.setSrcExecDatetime(rs.getDate(5));
						m.setUsi(rs.getString(6));
						m.setUpi(rs.getString(7));
						m.setConfirmBuyer(rs.getString(8));
						m.setConfirmSeller(rs.getString(9));
						m.setPrevUsi(rs.getString(10));
						m.setEconfirmFlag(rs.getString(11));
						m.setProductType(rs.getString(12));
						m.setLegsAssociated(rs.getInt(13));
						return m;
					}
				});
		return rsList;
	}
}