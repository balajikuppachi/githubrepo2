package com.wf.df.sdr.calc.commodity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author u250429
 *
 */
public class EConfirmTradeUpdateBO {
	
	private String RequestDate;
	private String Counterparty;
	private String USI;
	private String SenderTradeRefId;
	private String Action;
/*	private String recvXml;
	private Map<String,String> errors = new HashMap<String, String>();
	private BigDecimal bufferId;
*/	
	/**
	 * @return the recvXml
	 *//*
	public String getRecvXml() {
		return recvXml;
	}
	*//**
	 * @param recvXml the recvXml to set
	 *//*
	public void setRecvXml(String recvXml) {
		this.recvXml = recvXml;
	}
	*//**
	 * @return the errors
	 *//*
	public Map<String, String> getErrors() {
		return errors;
	}
	*//**
	 * @param errors the errors to set
	 *//*
	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}
	*//**
	 * @return the bufferId
	 *//*
	public BigDecimal getBufferId() {
		return bufferId;
	}
	*//**
	 * @param bufferId the bufferId to set
	 *//*
	public void setBufferId(BigDecimal bufferId) {
		this.bufferId = bufferId;
	}*/
	public String getRequestDate() {
		return RequestDate;
	}
	public void setRequestDate(String requestDate) {
		RequestDate = requestDate;
	}
	public String getCounterparty() {
		return Counterparty;
	}
	public void setCounterparty(String counterparty) {
		Counterparty = counterparty;
	}
	public String getUSI() {
		return USI;
	}
	public void setUSI(String uSI) {
		USI = uSI;
	}
	public String getSenderTradeRefId() {
		return SenderTradeRefId;
	}
	public void setSenderTradeRefId(String senderTradeRefId) {
		SenderTradeRefId = senderTradeRefId;
	}
	public String getAction() {
		return Action;
	}
	public void setAction(String action) {
		Action = action;
	}
	
}
