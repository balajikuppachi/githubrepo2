package com.wf.df.sdr.calc.equity;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;



@Component
public class EqPremiumCalc {

	
	@Autowired
	private FormatterService formatterService;
	
	@Calculation(value = Calc.eqPremiumCalc, isPrototype=false)
	public String calculate(
			@DerivedFrom(value = Stv.Premium, isInternal = true) String premium) {

		if (!Utils.IsNullOrBlank(premium)){
			/*		//do not use float or double may error out in results
			if(premium.contains("-"))
				premium =premium.replace("-", "");*/
			return formatterService.parseAndFormatNumber(premium);
		}
		return Constants.EMPTY_STRING;
		
	}
}
