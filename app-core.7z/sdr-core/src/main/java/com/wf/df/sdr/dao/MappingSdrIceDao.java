package com.wf.df.sdr.dao;

import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MappingSdrIce;
import com.wf.df.sdr.exception.dao.MappingSdrIceDaoException;

public interface MappingSdrIceDao {
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(MappingSdrIce dto) throws MappingSdrIceDaoException;
	
	/**
	 * Method 'update'
	 * 
	 * @param dto
	 */
	public void update(MappingSdrIce dto) throws MappingSdrIceDaoException;
	
	/** 
	 * Returns all rows from the mapping_sdr_ice table that match the criteria ''.
	 */
	public List<MappingSdrIce> findAll() throws MappingSdrIceDaoException;

	/** 
	 * Returns all rows from the mapping_sdr_ice table that match the criteria 'sender_trade_ref_id = :senderTradeRefId'.
	 */
	public List<MappingSdrIce> findWhereSenderTradeRefIdEquals(String senderTradeRefId) throws MappingSdrIceDaoException;
	
	/** 
	 * Returns all rows from the mapping_sdr_ice table that match the criteria 'upi = :upi'.
	 */
	public List<MappingSdrIce> findWhereUpiIdEquals(String upi) throws MappingSdrIceDaoException;

	/** 
	 * Returns all rows from the mapping_sdr_ice table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MappingSdrIce> findWhereCreateDatetimeEquals(Date createDatetime) throws MappingSdrIceDaoException;
	
	/** 
	 * Returns all rows from the mapping_sdr_ice table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	public List<MappingSdrIce> findWhereUpdateDatetimeEquals(Date updateDatetime) throws MappingSdrIceDaoException;
	
}
