package com.wf.df.sdr.util;


public class CalcNR {
	public static final String crMandatoryClearingIndicatorNRCalc = "crMandatoryClearingIndicatorNRCalc";
}

