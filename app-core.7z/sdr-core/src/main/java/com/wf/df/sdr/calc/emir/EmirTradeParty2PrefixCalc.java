package com.wf.df.sdr.calc.emir;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EmirTradeParty2PrefixCalc {


	@Calculation(value = Calc.emirTradeParty2PrefixCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value = Calc.tradeParty1PrefixCalc, isInternal = true) String wellsPrefix,
			@DerivedFrom(value = Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegated,
			@DerivedFrom(value = Calc.cptyParticipantIdPrefixCalc, isInternal = true) String cptyPrefix) 
	{
			
		if(isEmirDelegated)
		{
			return wellsPrefix;
		}else
		{
			return cptyPrefix;	
		}

	}
	
}
