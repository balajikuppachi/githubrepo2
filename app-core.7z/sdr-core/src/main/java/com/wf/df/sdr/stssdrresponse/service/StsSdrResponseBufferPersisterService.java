package com.wf.df.sdr.stssdrresponse.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.stsfeed.dao.StsXmlFeedDao;
import com.wf.df.sdr.stsfeed.dto.StsXmlFeed;
import com.wf.df.sdr.util.Constants;

/**
 * @author u235720
 *
 */
@Component
public class StsSdrResponseBufferPersisterService {
	
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	StsXmlFeedDao stsXmlFeedDao;

	public void persist(StsXmlFeed dto)
	{
		logger.info("STS SDR Response XML persisting initiated...");
		
		stsXmlFeedDao.insert(dto);
			
		logger.info(dto.getAssetClass()+Constants.COLON+dto.getMsgType()+" STS SDR Response Buffer persisted in sts_xml_feed, sendId=" + dto.getSendId());
		
		
		
	}
}
