package com.wf.df.sdr.calc.commodity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

public class MapBO {

	private LifecycleStatusQueryResponseBO lifecycleStatusQueryResponseBO;

	/**
	 * @return the lifecycleStatusQueryResponseBO
	 */
	public LifecycleStatusQueryResponseBO getLifecycleStatusQueryResponseBO() {
		return lifecycleStatusQueryResponseBO;
	}

	/**
	 * @param lifecycleStatusQueryResponseBO the lifecycleStatusQueryResponseBO to set
	 */
	public void setLifecycleStatusQueryResponseBO(
			LifecycleStatusQueryResponseBO lifecycleStatusQueryResponseBO) {
		this.lifecycleStatusQueryResponseBO = lifecycleStatusQueryResponseBO;
	}

	
	
	
}
