package com.wf.df.sdr.calc.xasset;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class USIPreviousPrefixCalc {

	@Calculation(value=Calc.uSIPreviousPrefixCalc, isPrototype = false)
	public String usi (
			@DerivedFrom(value = Stv.USI_PREVIOUS, isInternal = true) String usiPrevious) {
		
		if(!Utils.IsNullOrNone(usiPrevious)){
			if (usiPrevious.startsWith(Constants.DTCC))
				return Constants.DTCC;
			//fFirst 10 positions of USI is the prefix
			return usiPrevious.substring(0,10);
		}
		return Constants.EMPTY_STRING;
	}
}
