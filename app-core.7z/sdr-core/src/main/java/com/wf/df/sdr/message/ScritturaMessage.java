package com.wf.df.sdr.message;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

//TODO: AZ - Add schema validation
@XmlRootElement(name="ScritturaConfirmAck")
public class ScritturaMessage {
	
	@XmlElement(name="TradeId")
	private String tradeId;
	
	@XmlElement(name="CRID")
	private String crId;
	
	@XmlElement(name="TradeVersion")
	private String tradeVersion;
	
	@XmlElement(name="USI")
	private String usi;
	
	@XmlElement(name="UTI")
	private String uti;
	
	@XmlElement(name="MessageDateTime")
	private Date messageDateTime;
	
	
	private Date confirmDateTime;
	
	@XmlElement(name="DocId")
	private String docId;
	
	@XmlElement(name="SourceSystem")
	private String sourceSystem;
	
	@XmlElement(name="PaperFlag")
	private Boolean paperFlag;
	

	private Date confirmDateTimeToCpty;
	
	public String getTradeId() {
		return tradeId;
	}
	
	public String getTradeVersion() {
		return tradeVersion;
	}

	public String getCrId() {
		return crId;
	}

	public String getUsi() {
		return usi;
	}

	public Date getMessageDateTime() {
		return messageDateTime;
		
		/*try {
			return Utils.parseDate(messageDateTime);
		} catch (ParseException e) {
			throw new CalculationException("XML Date Parsing Error", "Error parsing MessageDateTime : "+e.getMessage(), e);			
		}*/
	}

	@XmlElement(name="ConfirmDateTime")
	public Date getConfirmDateTime() {
		/*try {
			return Utils.parseDate(confirmDateTime);
		} catch (ParseException e) {
			throw new CalculationException("XML Date Parsing Error", "Error parsing ConfirmDateTime : "+e.getMessage(), e);			
		}*/
		return confirmDateTime;
	}

	public String getDocId() {
		return docId;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}
	
	public Boolean getPaperFlag() {
		return paperFlag == null ? false : paperFlag;
	}

	/**
	 * @return the confirmDateTimeToCpty
	 */
	@XmlElement(name="ConfirmSentTimeToCpty")
	public Date getConfirmDateTimeToCpty() {
		return confirmDateTimeToCpty;
	}


	public String getUti() {
		return uti;
	}

	public void setConfirmDateTime(Date confirmDateTime) {
		this.confirmDateTime = confirmDateTime;
	}

	public void setConfirmDateTimeToCpty(Date confirmDateTimeToCpty) {
		this.confirmDateTimeToCpty = confirmDateTimeToCpty;
	}
	
	
	
	
	
}
