package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;

@Component
public class EmptyValueCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value=Calc.emptyValueCalc, isPrototype=false)
	public String dtccAssetClass() {
		
		// Explicitly set on those fields that will not be filled by Wells Fargo in Phase 1 
		// It includes Optional and Conditional fields that may not be mapped.
		return Constants.EMPTY_STRING;
	}
	
}
