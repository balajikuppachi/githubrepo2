package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.MappingTradeIdUsiService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class USIForNRCalc{
	
	@Autowired
	MappingTradeIdUsiService mappingTradeIdUsiService;

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value=Calc.uSIForNRCalc, isPrototype=false)
	public String usi (
			@DerivedFrom(value = Calc.computedUSICalc, isInternal = true) String usi,
			@DerivedFrom(value = Calc.isAffiliateTradeCalc, isInternal = true) Boolean isAffiliateTrade,
			@DerivedFrom(value = Calc.affiliateUsiCalc, isInternal = true) String affiliateUsi,
			@DerivedFrom(value = Stv.TradeId, isInternal = true) String srcTradeID,
			@DerivedFrom(value = Calc.srcAssetClassCalc, isInternal = true) String assetClass) {
			
		
		if(!Utils.IsNullOrNone(usi)){
			if (usi.startsWith(Constants.DTCC))
				return usi.substring(4);
			//for all USI not starting with DTCC prefix is 10
			if (usi.length()>10)
				return usi.substring(10);
			
			return usi;
		}	
		return Constants.EMPTY_STRING;
		
	}

	
}
