package com.wf.df.sdr.calc.xasset;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.calc.core.def.MethodCalculationDefinition;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class CptyParticipantIdPrefixCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.cptyParticipantIdPrefixCalc, isPrototype=false)
	public String counterPartyPrefix(
			MethodCalculationDefinition def,
			@DerivedFrom(value = Stv.DTCCCtyParticipantId, isInternal = true) String cptyParticipantId,
			@DerivedFrom(value = Stv.LEI_CP, isInternal = true) String cptyLEI,						
			@DerivedFrom(value = Stv.BusinessAccountId, isInternal = true) String businessAccountId,
			@DerivedFrom(value = Stv.CounterpartyShortName, isInternal = true) String cptyShortName,
			@DerivedFrom(value = Stv.CounterpartyName, isInternal = true) String cptyName) {
		
		if (!Utils.IsNullOrNone(cptyLEI))
			return (StringUtils.substringBefore(cptyLEI, Constants.COLON)).toUpperCase();
		
		if(!Utils.IsNullOrNone(cptyParticipantId) && cptyParticipantId.startsWith(Constants.DTCC)) 	
			return Constants.DTCC;
		
		if (!Utils.IsNullOrNone(businessAccountId))
			return Constants.INTERNAL.toUpperCase();
		
		if (!Utils.IsNullOrNone(cptyShortName))
			return Constants.INTERNAL.toUpperCase();

	
		throw new CalculationException("LEIFNF", "None of the fields are defined LEI:[" + Stv.LEI_US + "] ,  " +
				"BusAcct:[" + businessAccountId + "], sname:[" + cptyShortName + "], DTCC:[" + Stv.DTCCCtyParticipantId + "]");
	}
}
