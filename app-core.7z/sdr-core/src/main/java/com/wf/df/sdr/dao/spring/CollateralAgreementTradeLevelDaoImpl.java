package com.wf.df.sdr.dao.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.CollateralAgreementTradeLevelDao;
import com.wf.df.sdr.dto.CollateralAgreementTradeLevel;
import com.wf.df.sdr.exception.dao.CollateralAgreementsDaoException;

public class CollateralAgreementTradeLevelDaoImpl extends AbstractDAO implements ParameterizedRowMapper<CollateralAgreementTradeLevel>, CollateralAgreementTradeLevelDao {
	
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;
	

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(CollateralAgreementTradeLevel dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( trade_id, legal_id, srcSystem, productType,collateralizationType, tickerID ) VALUES ( ?, ?, ?, ?, ?,?)",dto.getTradeID(),dto.getlegalID(),dto.getsrcSystem(),dto.getproductType(),dto.getcollateralizationType(), dto.getTickerID());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return CollateralAgreementTradeLevel
	 */
	public CollateralAgreementTradeLevel mapRow(ResultSet rs, int row) throws SQLException
	{
		CollateralAgreementTradeLevel dto = new CollateralAgreementTradeLevel();
		dto.setTradeID( rs.getString( 1 ) );
		dto.setlegalID( rs.getString( 2 ) );
		dto.setproductType( rs.getString( 3 ) );
		dto.setsrcSystem( rs.getString( 4 ) );
		dto.setcollateralizationType( rs.getString(5));
		dto.setTickerID(rs.getString(6));
	
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "trade_collateralization";
	}

	
	@Transactional
	public List<CollateralAgreementTradeLevel> findAll() throws CollateralAgreementsDaoException {
		try {
			return jdbcTemplate.query("SELECT  trade_id, legal_id, srcSystem, productType, collateralizationType, tickerID FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
	}

	@Transactional
	public List<CollateralAgreementTradeLevel> findWhereTradeIdEquals(String trade_id) throws CollateralAgreementsDaoException {
		try {
			return jdbcTemplate.query("SELECT trade_id, legal_id, srcSystem, productType, collateralizationType, tickerID FROM " + getTableName() + " WHERE trade_id = ? ORDER BY trade_id", this,trade_id);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
	}
	
	@Transactional
	public List<CollateralAgreementTradeLevel> findWhereTradeIdSourceEquals(String trade_id, String srcSystem) throws CollateralAgreementsDaoException {
		try {
			return jdbcTemplate.query("SELECT trade_id, legal_id, srcSystem, productType, collateralizationType, tickerID FROM " + getTableName() + " WHERE trade_id = ? and srcSystem = ? ORDER BY trade_id", this,trade_id, srcSystem);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
	}
	
	@Transactional
	public List<CollateralAgreementTradeLevel> findWhereEQTickerIDSourceEquals(String tickerID, String srcSystem) throws CollateralAgreementsDaoException {
		try {
			return jdbcTemplate.query("SELECT trade_id, legal_id, srcSystem, productType, collateralizationType, tickerID FROM " + getTableName() + " WHERE tickerID = ? and srcSystem = ? ORDER BY trade_id", this,tickerID, srcSystem);
		}
		catch (Exception e) {
			throw new CollateralAgreementsDaoException("Query failed", e);
		}
	}


}
