package com.wf.df.sdr.calc.forex;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxClearingHouseCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(Calc.fxClearingHouseCalc)
	public String clearingHouse(
			@DerivedFrom(Stv.CC_ClearingHouse) String value)

	{
		if(Constants.NONE.equalsIgnoreCase(value) || Utils.IsNullOrBlank(value)){
			return Constants.FALSE;
		}
		else {
			return Constants.TRUE;
		}
	}
}
