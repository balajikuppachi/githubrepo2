package com.wf.df.sdr.dao.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wf.df.sdr.dao.NotReportableEODBufferStoreDao;
import com.wf.df.sdr.dto.EODBufferStore;
import com.wf.df.sdr.exception.dao.EODBufferStoreDaoException;

public class NotReportableEODBufferStoreDaoImpl extends AbstractDAO implements ParameterizedRowMapper<EODBufferStore>, NotReportableEODBufferStoreDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(EODBufferStore dto)
	{		
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id ) VALUES ( ?, ?, ?, ?, ?, ?,? )",dto.getUsi(),dto.getAssetClass(),dto.getSendId(),dto.getMsgBuffer(),dto.getUpdateDatetime(),dto.getMsgType(),dto.getTemplateId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return SnapshotUsiMsgMapping
	 */
	public EODBufferStore mapRow(ResultSet rs, int row) throws SQLException
	{
		EODBufferStore dto = new EODBufferStore();
		dto.setUsi( rs.getString( 1 ) );
		dto.setAssetClass( rs.getString( 2 ) );
		dto.setSendId( rs.getBigDecimal(3));
		dto.setMsgBuffer( rs.getString( 4 ) );
		dto.setUpdateDatetime( rs.getTimestamp(5 ) );
		dto.setMsgType( rs.getString( 6 ) );
		dto.setTemplateId( rs.getString( 7 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "not_reportable_msg_store";
	}

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria ''.
	 */
	@Transactional
	public List<EODBufferStore> findAll() throws EODBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<EODBufferStore> findWhereUsiEquals(String usi) throws EODBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + " WHERE usi = ? ORDER BY usi", this,usi);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'usi = :usi'.
	 */
	@Transactional
	public List<EODBufferStore> findWhereUsiAndMsgTypeEquals(String usi, String msgType) throws EODBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + " WHERE usi = ? and msg_type = ? ORDER BY usi", this, usi, msgType);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'asset_class = :assetClass'.
	 */
	@Transactional
	public List<EODBufferStore> findWhereAssetClassEquals(String assetClass) throws EODBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + " WHERE asset_class = ? ", this,assetClass);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<EODBufferStore> findWhereSendIdEquals(BigDecimal sendId) throws EODBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + " WHERE send_id = ? ORDER BY send_id", this,sendId);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'msg_buffer = :msgBuffer'.
	 */
	@Transactional
	public List<EODBufferStore> findWhereMsgBufferEquals(String msgBuffer) throws EODBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + " WHERE msg_buffer = ? ORDER BY msg_buffer", this,msgBuffer);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	@Transactional
	public List<EODBufferStore> findWhereUpdateDatetimeEquals(Date updateDatetime) throws EODBufferStoreDaoException
	{
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + " WHERE update_datetime = ? ORDER BY update_datetime", this,updateDatetime);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	@Transactional
	public int deleteBuffersForUSI(String usi) throws EODBufferStoreDaoException
	{
		try {			
			return jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE usi = ? ", usi);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'update_datetime = :updateDatetime'.
	 */
	@Transactional
	public int deleteNRBuffersForUSI(String usi) throws EODBufferStoreDaoException
	{
		try {			
			return jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE msg_type='Snapshot_NR' and usi = ? ", usi);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the eod_buffer_store table that match the criteria 'template_id = :templateId'.
	 */
	@Transactional
	public List<EODBufferStore> findWhereTemplateIdEquals(String templateId) throws EODBufferStoreDaoException {
		try {
			return jdbcTemplate.query("SELECT usi, asset_class, send_id, msg_buffer, update_datetime, msg_type,template_id FROM " + getTableName() + " WHERE template_id = ? ORDER BY template_id", this,templateId);
		}
		catch (Exception e) {
			throw new EODBufferStoreDaoException("Query failed", e);
		}
	
	}
}