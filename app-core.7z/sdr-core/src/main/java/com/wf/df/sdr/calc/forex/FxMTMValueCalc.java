package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxMTMValueCalc {

	
	@Calculation(value = Calc.fxMTMValueCalc, isPrototype = false)
	public String mtmValue(
			@DerivedFrom(value = Calc.mtmValueCalc, isInternal=true) String value){
		
		return value;
	}
}
