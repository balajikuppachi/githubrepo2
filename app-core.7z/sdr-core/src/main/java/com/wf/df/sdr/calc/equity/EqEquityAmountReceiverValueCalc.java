package com.wf.df.sdr.calc.equity;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EqEquityAmountReceiverValueCalc {

	@Calculation(value = Calc.eqEquityAmountReceiverValueCalc, isPrototype = false)
	public String valuationDate(
			@DerivedFrom(value = Calc.eqIsWFBuyerCalc, isInternal = true) Boolean isWFBuyer,
			@DerivedFrom(value = Calc.eqUnderlyngAssetCptyParticipantIdCalc, isInternal = true) String cpty,
			@DerivedFrom(value = Calc.eqUnderlyngAssetWFParticipantIdCalc, isInternal = true) String us) {

		if(isWFBuyer)
			return us; //if WF is buyer, then Cpty is payer
		else
			return cpty;
		
	}
	
}
