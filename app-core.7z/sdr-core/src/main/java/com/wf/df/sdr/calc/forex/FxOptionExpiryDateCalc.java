package com.wf.df.sdr.calc.forex;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxOptionExpiryDateCalc {

	@Autowired
	ParserService parser;

	@Autowired
	FormatterService formatter;

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.fxOptionExpiryDateCalc)
	public String calcExpireDate(@DerivedFrom(value = Stv.FXOptionExpiryDate) String optionFxExpiryDate) {

		if (!Utils.IsNullOrBlank(optionFxExpiryDate)) {
			try {
				return formatter.formatDateUTC(parser.parseDate(optionFxExpiryDate));

			} catch (ParseException e) {
				throw new CalculationException("Parse Exception ",Stv.FXOptionExpiryDate + " is in wrong format.");
			}
		}
		return Constants.EMPTY_STRING;
	}

}
