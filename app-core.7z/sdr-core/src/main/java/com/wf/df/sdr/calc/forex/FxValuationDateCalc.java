package com.wf.df.sdr.calc.forex;

import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class FxValuationDateCalc {

	@Calculation(value = Calc.fxValuationDateCalc, isPrototype = false)
	public String calculate(
			@DerivedFrom(value =Calc.ValuationDateCalc, isInternal=true) String value){
		return value;
	}
}