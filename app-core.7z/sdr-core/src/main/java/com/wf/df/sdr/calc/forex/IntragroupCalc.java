package com.wf.df.sdr.calc.forex;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class IntragroupCalc {
	
	@Value("${wf.lei}") String wfLei;
		
	@Calculation(value = Calc.intragroupCalc, isPrototype = false)
	public String transactionType(
			@DerivedFrom(value = Stv.LEI_US, isInternal = true) String leiUs,
			@DerivedFrom(value = Stv.LEI_CP, isInternal = true) String leiCp,
			@DerivedFrom(value = Calc.dtccAssetClassCalc, isInternal = true) String assetClass,
			@DerivedFrom(value=Calc.isDtccDelegatedTradeCalc, isInternal = true) boolean isDtccDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirDelegatedTradeCalc, isInternal = true) boolean isEmirDelegatedTrade,
			@DerivedFrom(value=Calc.isEmirTradeCalc,isInternal = true) boolean isEmirReportable)
	{
		
		if(isDtccDelegatedTrade || isEmirDelegatedTrade || isEmirReportable)
		{
			String leiUsValue=null,leiCpValue=null;
			leiUsValue=Utils.getElementAtIndex(leiUs, 1, Constants.COLON);
			leiCpValue=Utils.getElementAtIndex(leiCp, 1, Constants.COLON);
			if(Constants.ASSET_CLASS_FOREX.equals(assetClass)){
				
				if(wfLei.equals(leiCpValue) && "SX0CI4F7GVW5530ZMN03".equals(leiUsValue))
					return Constants.TRUE;
				return Constants.FALSE;
				
			}else if(Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass)){
				
				if(wfLei.equals(leiCpValue) && "BWS7DNS2Z4NPKPNYKL75".equals(leiUsValue))
					return Constants.TRUE;
				return Constants.FALSE;
				
			}
			
			return Constants.FALSE;	
		}
		return Constants.EMPTY_STRING;
			
		
	}
	
}
