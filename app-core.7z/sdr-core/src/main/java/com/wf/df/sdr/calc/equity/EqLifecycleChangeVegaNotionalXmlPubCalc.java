package com.wf.df.sdr.calc.equity;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.dao.TradeAttributesDao;
import com.wf.df.sdr.dto.TradeAttributes;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqLifecycleChangeVegaNotionalXmlPubCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	ParserService parser;	
	@Autowired
	FormatterService formatter;
	@Autowired
	TradeAttributesDao dao;
	
	@Autowired
	DTCCUtils dtccUtils;
	
	@Calculation(value = Calc.eqLifecycleChangeVegaNotionalXmlPubCalc, isPrototype = false)
	public String notional(
			@DerivedFrom(value = Stv.VegaNotionalAmount, isInternal = true) String vegaNotional,			
			@DerivedFrom(value = Stv.LifecycleEvent, isInternal = true) String txnType,
			@DerivedFrom(value = Calc.eqComputedUSICalc, isInternal = true) String usi){	
			
		if(Utils.IsNullOrBlank(vegaNotional))
			return Constants.EMPTY_STRING;
				
		String notional = null,transactionType=null;
		
		if (txnType != null) {
			transactionType=dtccUtils.getEquityTransactionType(txnType);
		}
		
		if(Constants.Increase.equals(transactionType)){
			//Assuming we are getting increase (+ve change) in notional for Increase i.e AddOn
			return formatter.parseAndFormatNumber(vegaNotional);
		}else if(Constants.Termination.equals(transactionType)){
			//Assuming we are getting decrease (-ve change) in notional for Termination i.e  Full Unwind or Partial Unwind
			return formatter.parseAndFormatNumber(vegaNotional);
		} else {
			//Assuming for all other types we are getting total notional			
			return getChangeInNotional(vegaNotional, usi);			 
		}
					
	}
	
	private String getChangeInNotional(String current, String usi) {
		String ret = current;
		List<TradeAttributes> trade = dao.findPreviousRecordsForUSI(usi, Constants.ASSET_CLASS_EQUITY);
		if (trade.size() > 0) {
			String original = trade.get(0).getNotionalAmount();
			try {
				double old = Double.parseDouble(original);
				double now = Double.parseDouble(current);
				double total = now - old;
				return formatter.formatDecimalDEC(total);
			} catch (Exception ee) {
				logger.info("Remaining Notional Failed, Returning the value as is.", ee);
			}
		}
		return formatter.parseAndFormatNumber(ret);
	}
	
}
