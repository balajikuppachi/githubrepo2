package com.wf.df.sdr.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.wf.df.sdr.dto.MappingTradeLei;

// TODO: Auto-generated Javadoc
/**
 * The Class MetaDataReader.
 */
public class TradesLeiMappingReader {
	
	public static final String LINE_SEPARATOR = System.getProperty("line.separator");
	public static final String DELIMETER = "~";
	public static final String EMPTY = "";
	/** The logger. */
	private static Log logger = LogFactory.getLog(TradesLeiMappingReader.class); 
	
	/** The file. */
	static File file= null;
	
	/** The out. */
	static Writer out = null;
	
	/**
	 * The main method.
	 *
	 * @param strings the arguments
	 */
	public static void main(String...strings)
	{
		
	
		try {
			List<String> tempList;
			List<String> bufferList;
			
			logger.info("Started Reading the metadata");
			TradesLeiUsiReadDao.createConnection();
			List<String> tradeList=TradesLeiUsiReadDao.readTradeID();
			int batchSize=1000;
			logger.info("No. of live trades available :"+tradeList.size());
		
			for(int i=0;i<tradeList.size();i+=batchSize)
			{
				tempList=tradeList.subList(i, i+batchSize>tradeList.size()?tradeList.size():i+batchSize);
				logger.debug("Loop Size: "+(i+tempList.size()));
				bufferList=TradesLeiUsiReadDao.readBufferData(tempList);
				List<MappingTradeLei> bufferlst=parseStv(bufferList);
				writeFieldsFile(bufferlst,i==0?true:false,i>=tradeList.size());
			}
			logger.info("Completed writing in to file.");
			TradesLeiUsiReadDao.closeConn();
		
		} catch (ClassNotFoundException e1) {
			logger.error(e1);
		} catch (SQLException e1) {
			e1.printStackTrace();
			logger.error(e1);
		} catch (IOException e) {
			logger.error(e);
		}
	}

	/**
	 * Parses the stv.
	 *
	 * @param bufferList the buffer list
	 * @return the list
	 */
	private static List<MappingTradeLei> parseStv(List<String> bufferList) {
		logger.debug("calling parseStv,bufferList size :"+bufferList.size());
		List<MappingTradeLei> metaData=new ArrayList<MappingTradeLei>();
		MappingTradeLei fields;
		for (Iterator<String> iterator = bufferList.iterator(); iterator.hasNext();) {
			String stvString = (String) iterator.next();
			String[] stringArray = stvString.split("\\{");
			fields=new MappingTradeLei();
			for(String line : stringArray) {
				if (!line.trim().isEmpty()) {				
					String[] pair = line.trim().split("=");
					String key = pair[0].trim().substring(0, pair[0].length()-1);
					String value = null;
					if(pair.length == 2) {
						String trimmedValue = pair[1].trim();
						value = trimmedValue.isEmpty() ? EMPTY : trimmedValue;
						if(key.equals("SystemSourceId"))fields.setSource(value);
						if(key.equals("TradeId"))fields.setTradeId(value);
						if(key.equals("USI_CURRENT"))fields.setUsiCurrent(value);
						if(key.equals("CounterpartyShortName"))fields.setCptyShortName(value);
						if(key.equals("LEI_CP"))fields.setCurrentLei(value);
						if(key.equals("BusinessAccountId"))fields.setBusinessAccountId(value);
						fields.setLeiUpdateFlag(isLeiUpdateNeeded(key,value));
						
					}
					fields.setNewLei(EMPTY);
					fields.setCreateDate(new Timestamp(new Date().getTime()));
					fields.setUpdateDate(new Timestamp(new Date().getTime()));
				}
			}
			metaData.add(fields);
		}	
		return metaData;
	}

	
	
	private static int isLeiUpdateNeeded(String key, String value) {
		if(key.equals("Book") && value.equals("IRD_SPURS_WFB"))
			return 0;
		return 1;
	}

	

	/**
	 * Write fields file.
	 *
	 * @param bufferlst the bufferlst
	 * @param header the header
	 * @param footer the footer
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private static void writeFieldsFile(List<MappingTradeLei> bufferlst, boolean header, boolean footer) throws IOException {
		logger.debug("calling writeFieldsFile,bufferlst size :"+bufferlst.size());
		if(header)
		{
			String userDirPath = System.getProperty("user.dir");
			File sdrHome = new File(userDirPath).getParentFile();
			String sdrHomePath = sdrHome.getCanonicalPath();
			logger.debug("writing file in :"+sdrHomePath);
			//file= new File(sdrHomePath+"/data/output");
			file= new File(sdrHomePath+"/data/output/TradesLeiMappingBcpIn.txt");
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		}
		// header row
		if(header)
		{
			out.append("src_system").append(DELIMETER)
			.append("trade_id").append(DELIMETER).append("usi").append(DELIMETER).append("cpty_shortname").append(DELIMETER)
			.append("current_lei").append(DELIMETER).append("alternate_id").append(DELIMETER).append("new _lei").append(DELIMETER).append("create_date_time").append(DELIMETER).append("update_date_time").append(DELIMETER).append("lei_update_flag");
			out.append(LINE_SEPARATOR);
		}
		// data rows
		for (MappingTradeLei field : bufferlst) {
			out.append(field.getSource()).append(DELIMETER).
			append(field.getTradeId()).append(DELIMETER).append(field.getUsiCurrent()).append(DELIMETER).append(field.getCptyShortName()).append(DELIMETER)
			.append(field.getCurrentLei()).append(DELIMETER).append(field.getBusinessAccountId()).append(DELIMETER).append(field.getNewLei()).append(DELIMETER).append(field.getCreateDate().toString()).append(DELIMETER).append(field.getUpdateDate().toString()).append(DELIMETER).append(String.valueOf(field.getLeiUpdateFlag()));
			out.append(LINE_SEPARATOR);
		}
		out.flush();
		if(footer)out.close();
	}

}
