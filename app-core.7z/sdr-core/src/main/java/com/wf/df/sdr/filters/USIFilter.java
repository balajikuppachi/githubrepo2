package com.wf.df.sdr.filters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.exception.FilterException;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.NotEligblePersister;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component(value="usiFilter")
public class USIFilter {
	
	@Value("${dummy.usi}")  String dummyUSI;	
	
	@Autowired
	NotEligblePersister nep;
	
	Logger log = Logger.getLogger(getClass());

	public boolean isUSIAvailable(UnitOfWork uow) {
		log.debug("USI filter Called");
		CalculationContext cc = uow.getCalculationContext();
		String usi = cc.getValue(Calc.computedUSICalc, String.class);
		
				
		Boolean affliateTrade = cc.getValue(Calc.isAffiliateTradeCalc, Boolean.class);
		Boolean isEmirTrade = cc.getValue(Calc.isEmirTradeCalc, Boolean.class);
		Boolean feeTrade = cc.getValue(Calc.shouldWeCreateFeeTradeCalc, Boolean.class);
		String feeUSI = cc.getValue(Stv.FEE_USI_CURRENT, String.class);
		
		//For affiliate trades USI will come as blank
		if(affliateTrade && Utils.IsNullOrBlank(usi)){
			return true;
		}
		
		if(feeTrade) {
				if(Utils.IsNullOrBlank(feeUSI)){
					log.debug("FEE USI Cannot be computed, IS NULL");
					nep.save(uow, NotEligblePersister.FEEUSI);
					return false;
			}
		}
		
		if(Utils.IsNullOrBlank(usi) && !isEmirTrade){
			log.debug("USI Cannot be computed, IS NULL");
			// Save it in NotSendPersister
			nep.save(uow, NotEligblePersister.USI);
			return false;
		}	
		
		if(dummyUSI.contains(usi) && !isEmirTrade)
			throw new FilterException("DummyUSI", "Trade received with dummy USI "+usi);
		
		return true;
	}
}
