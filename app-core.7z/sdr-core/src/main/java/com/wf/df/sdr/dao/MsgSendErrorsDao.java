package com.wf.df.sdr.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wf.df.sdr.dto.MsgSendErrors;
import com.wf.df.sdr.exception.dao.MsgSendErrorsDaoException;

public interface MsgSendErrorsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	public void insert(MsgSendErrors dto);

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria ''.
	 */
	public List<MsgSendErrors> findAll() throws MsgSendErrorsDaoException;

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'send_id = :sendId'.
	 */
	public List<MsgSendErrors> findWhereSendIdEquals(BigDecimal sendId) throws MsgSendErrorsDaoException;

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'msg_type = :msgType'.
	 */
	public List<MsgSendErrors> findWhereMsgTypeEquals(String msgType) throws MsgSendErrorsDaoException;

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'create_datetime = :createDatetime'.
	 */
	public List<MsgSendErrors> findWhereCreateDatetimeEquals(Date createDatetime) throws MsgSendErrorsDaoException;

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'error_code = :errorCode'.
	 */
	public List<MsgSendErrors> findWhereErrorCodeEquals(String errorCode) throws MsgSendErrorsDaoException;

	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'error_desc = :errorDesc'.
	 */
	public List<MsgSendErrors> findWhereErrorDescEquals(String errorDesc) throws MsgSendErrorsDaoException;
	
	/** 
	 * Returns all rows from the msg_send_errors table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	public List<MsgSendErrors> findWhereSdrRepositoryEquals(String sdrRepository) throws MsgSendErrorsDaoException;

}
