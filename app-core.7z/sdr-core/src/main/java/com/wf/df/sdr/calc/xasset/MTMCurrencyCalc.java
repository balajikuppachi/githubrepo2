package com.wf.df.sdr.calc.xasset;


import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class MTMCurrencyCalc {
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.mtmCurrencyCalc, isPrototype = false)
	public String mtmValue(
			@DerivedFrom(value = Stv.SdrNPVCurrency, isInternal=true) String value){
		
		if(!Utils.IsNullOrBlank(value))
			return value;
		else {
			// This field wll be populated at EOD with latest data from CDBO
			return "USD";
			// Required for Valuation, should throw an exception
			//throw new CalculationException("RFNF", Stv.SdrNPVCurrency + " can not be null. This is an injected value by Valuation Process");
		}
	}
}