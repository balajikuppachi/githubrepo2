package com.wf.df.sdr.calc.forex;

import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class FxExchangeRateCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	ParserService parser;
	
	@Autowired
	FormatterService formatter;


	@Calculation(value = Calc.fxExchangeRateCalc, isPrototype=false)
	public String calcAction(
			@DerivedFrom(value = Stv.FXRateFinalList, isInternal = true) List<String> fxRate,
			@DerivedFrom(value=Stv.FXOptionStrike) String optionStrike) {
		
			try {
				if (!Utils.IsListNullOrEmpty(fxRate)) {
						return formatter.formatDecimal8(parser.parseNumber(fxRate.get(0)));

				}
				if(!Utils.IsNullOrBlank(optionStrike))
				{	
					return formatter.formatDecimal8(parser.parseNumber(optionStrike));
				}
				
			} catch (ParseException e) {
			throw new CalculationException("Parse Error", "Exchange rate " + fxRate	+ " could not be parsed");				
		}
		
		return Constants.EMPTY_STRING;

	}
}