package com.wf.df.sdr.calc.equity;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;

@Component
public class EqBuyerCalc {

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqBuyerCalc, isPrototype = false)
	public String buyer(
			@DerivedFrom(value = Calc.eqIsWFBuyerCalc, isInternal = true) Boolean isWFBuyer,
			@DerivedFrom(value = Calc.eqCptyParticipantIdCalc, isInternal = true) String cpty,
			@DerivedFrom(value = Calc.eqWFParticipantIdCalc, isInternal = true) String us) {

		if(isWFBuyer)
			return us; 
		else
			return cpty;		
	}
}
