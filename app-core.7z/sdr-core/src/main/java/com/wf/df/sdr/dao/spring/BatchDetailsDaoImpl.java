package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.BatchDetailsDao;
import com.wf.df.sdr.dto.BatchDetails;
import com.wf.df.sdr.exception.dao.BatchDetailsDaoException;
import com.wf.df.sdr.util.Constants;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class BatchDetailsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<BatchDetails>, BatchDetailsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;
	
	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(BatchDetails dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( create_datetime, fq_filename, send_id, msg_type, transmit_id ) VALUES ( ?, ?, ?, ? ,?)",dto.getCreateDatetime(),dto.getFqFilename(),dto.getSendId(),dto.getMsgType(),dto.getTransmitId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return BatchDetails
	 */
	public BatchDetails mapRow(ResultSet rs, int row) throws SQLException
	{
		BatchDetails dto = new BatchDetails();
		dto.setCreateDatetime( rs.getTimestamp("create_datetime" ));
		dto.setFqFilename( rs.getString("fq_filename"));
		dto.setSendId( rs.getBigDecimal("send_id"));
		dto.setMsgType( rs.getString("msg_type"));
		dto.setTransmitId(rs.getBigDecimal("transmit_id"));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "batch_details";
	}

	/** 
	 * Returns all rows from the batch_details table that match the criteria ''.
	 */
	@Transactional
	public List<BatchDetails> findAll() throws BatchDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, send_id, msg_type,transmit_id FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new BatchDetailsDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<BatchDetails> findWhereCreateDatetimeEquals(Date createDatetime) throws BatchDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, send_id, msg_type,transmit_id FROM " + getTableName() + " WHERE create_datetime = ? ", this,createDatetime);
		}
		catch (Exception e) {
			throw new BatchDetailsDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'fq_filename = :fqFilename'.
	 */
	@Transactional
	public List<BatchDetails> findWhereFqFilenameEquals(String fqFilename) throws BatchDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, send_id, msg_type, transmit_id FROM " + getTableName() + " WHERE fq_filename = ? ", this,fqFilename);
		}
		catch (Exception e) {
			throw new BatchDetailsDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'send_id = :sendId'.
	 */
	@Transactional
	public List<BatchDetails> findWhereSendIdEquals(BigDecimal sendId) throws BatchDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, send_id, msg_type,transmit_id FROM " + getTableName() + " WHERE send_id = ? ", this,sendId);
		}
		catch (Exception e) {
			throw new BatchDetailsDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the batch_details table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<BatchDetails> findWhereMsgTypeEquals(String msgType) throws BatchDetailsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT create_datetime, fq_filename, send_id, msg_type,transmit_id FROM " + getTableName() + " WHERE msg_type = ? ", this,msgType);
		}
		catch (Exception e) {
			throw new BatchDetailsDaoException(Constants.EXCEPTION+"Query failed", e);
		}
		
	}

}
