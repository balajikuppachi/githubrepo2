package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.DtccFieldsMessageMappingsDao;
import com.wf.df.sdr.dto.DtccFieldsMessageMappings;
import com.wf.df.sdr.exception.dao.DtccFieldsMessageMappingsDaoException;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class DtccFieldsMessageMappingsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<DtccFieldsMessageMappings>, DtccFieldsMessageMappingsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(DtccFieldsMessageMappings dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getId(),dto.getFieldCsvSeq(),dto.getFieldOptionality(),dto.getDtccAssetClass(),dto.getDtccProdType(),dto.getDtccSubProdType(),dto.getMsgType(),dto.getTransactionType(),dto.getFieldName(),dto.getFieldId(),dto.getFieldRule(),dto.getSrcField(),dto.getDefaultValue(),dto.getFieldXpath(),dto.getCreateDatetime(),dto.getSdrRepository());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return DtccFieldsMessageMappings
	 */
	public DtccFieldsMessageMappings mapRow(ResultSet rs, int row) throws SQLException
	{
		DtccFieldsMessageMappings dto = new DtccFieldsMessageMappings();
		dto.setId( new Integer( rs.getInt(1) ) );
		dto.setFieldCsvSeq( new Integer( rs.getInt(2) ) );
		if (rs.wasNull()) {
			dto.setFieldCsvSeq( null );
		}
		
		dto.setFieldOptionality( rs.getString( 3 ) );
		dto.setDtccAssetClass( rs.getString( 4 ) );
		dto.setDtccProdType( rs.getString( 5 ) );
		dto.setDtccSubProdType( rs.getString( 6 ) );
		dto.setMsgType( rs.getString( 7 ) );
		dto.setTransactionType( rs.getString( 8 ) );
		dto.setFieldName( rs.getString( 9 ) );
		dto.setFieldId( new Integer( rs.getInt(10) ) );
		dto.setFieldRule( rs.getString( 11 ) );
		dto.setSrcField( rs.getString( 12 ) );
		dto.setDefaultValue( rs.getString( 13 ) );
		dto.setFieldXpath( rs.getString( 14 ) );
		dto.setCreateDatetime( rs.getTimestamp(15 ) );
		dto.setSdrRepository(rs.getString(16));
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "dtcc_fields_message_mappings";
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria ''.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findAll() throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'id = :id'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereIdEquals(Integer id) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE id = ? ORDER BY id", this,id);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_csv_seq = :fieldCsvSeq'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereFieldCsvSeqEquals(Integer fieldCsvSeq) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE field_csv_seq = ? ORDER BY field_csv_seq", this,fieldCsvSeq);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_optionality = :fieldOptionality'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereFieldOptionalityEquals(String fieldOptionality) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE field_optionality = ? ORDER BY field_optionality", this,fieldOptionality);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'dtcc_asset_class = :dtccAssetClass'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereDtccAssetClassEquals(String dtccAssetClass) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE dtcc_asset_class = ? ORDER BY dtcc_asset_class", this,dtccAssetClass);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'dtcc_prod_type = :dtccProdType'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereDtccProdTypeEquals(String dtccProdType) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE dtcc_prod_type = ? ORDER BY dtcc_prod_type", this,dtccProdType);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'dtcc_sub_prod_type = :dtccSubProdType'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereDtccSubProdTypeEquals(String dtccSubProdType) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE dtcc_sub_prod_type = ? ORDER BY dtcc_sub_prod_type", this,dtccSubProdType);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'msg_type = :msgType'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereMsgTypeEquals(String msgType) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE msg_type = ? ORDER BY msg_type", this,msgType);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'transaction_type = :transactionType'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereTransactionTypeEquals(String transactionType) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE transaction_type = ? ORDER BY transaction_type", this,transactionType);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_name = :fieldName'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereFieldNameEquals(String fieldName) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE field_name = ? ORDER BY field_name", this,fieldName);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_id = :fieldId'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereFieldIdEquals(Integer fieldId) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE field_id = ? ORDER BY field_id", this,fieldId);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_rule = :fieldRule'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereFieldRuleEquals(String fieldRule) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE field_rule = ? ORDER BY field_rule", this,fieldRule);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'src_field = :srcField'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereSrcFieldEquals(String srcField) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE src_field = ? ORDER BY src_field", this,srcField);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'default_value = :defaultValue'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereDefaultValueEquals(String defaultValue) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE default_value = ? ORDER BY default_value", this,defaultValue);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'field_xpath = :fieldXpath'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereFieldXpathEquals(String fieldXpath) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE field_xpath = ? ORDER BY field_xpath", this,fieldXpath);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereCreateDatetimeEquals(Date createDatetime) throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}
	
	/**
	 * Additional Implementation added to support the CSV in seq fetch Query
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findFieldsInCSVSeq() throws DtccFieldsMessageMappingsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT DISTINCT msg_type, dtcc_asset_class, field_id, field_name, field_csv_seq, sdr_repository FROM " + getTableName() + " ORDER BY field_csv_seq ASC", new DtccCustomRowMapper());
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the dtcc_fields_message_mappings table that match the criteria 'sdr_repository = :sdrRepository'.
	 */
	@Transactional
	public List<DtccFieldsMessageMappings> findWhereSdrRepositoryEquals(String sdrRepository) throws DtccFieldsMessageMappingsDaoException {
		try {
			return jdbcTemplate.query("SELECT id, field_csv_seq, field_optionality, dtcc_asset_class, dtcc_prod_type, dtcc_sub_prod_type, msg_type, transaction_type, field_name, field_id, field_rule, src_field, default_value, field_xpath, create_datetime, sdr_repository FROM " + getTableName() + " WHERE sdr_repository = ? ORDER BY sdr_repository", this,sdrRepository);
		}
		catch (Exception e) {
			throw new DtccFieldsMessageMappingsDaoException("Query failed", e);
		}
	}
	
	class DtccCustomRowMapper implements ParameterizedRowMapper<DtccFieldsMessageMappings> {

		@Override
		public DtccFieldsMessageMappings mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			
			DtccFieldsMessageMappings dto = new DtccFieldsMessageMappings();
			
			dto.setMsgType( rs.getString( 1 ) );			
			dto.setDtccAssetClass( rs.getString( 2 ) );	
			dto.setFieldId( rs.getInt( 3 ) );
			dto.setFieldName( rs.getString( 4 ) );
			dto.setFieldCsvSeq( rs.getInt( 5 ) );
			dto.setSdrRepository(rs.getString(6));
			return dto;
			
		}
		
	}


}
