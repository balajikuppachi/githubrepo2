package com.wf.df.sdr.calc.equity;

import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.exception.CalculationException;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.service.ParserService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqFinalValuationDateCalc {

	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	FormatterService formatter;
	
	@Autowired
	ParserService parser;
	
	@Calculation(value = Calc.eqFinalValuationDateCalc, isPrototype = false)
	public String valuationDate(
			@DerivedFrom(value = Stv.EquityValuationDateList, isInternal = true) List<String> valuationDateList) {

		String dateString = null;
		
		if (!Utils.IsListNullOrEmpty(valuationDateList)) {
			
			try{
				 dateString = valuationDateList.get(valuationDateList.size()-1);
				 dateString = formatter.formatDateUTC(parser.parseDate(dateString));
				 return dateString;
			}catch (ParseException e) {
				logger.error("Error in EqFinalValuationDateCalc: "+e.getMessage());
				throw new CalculationException("DateNotParsed", "Date string " + dateString	+ " could not be parsed" + Constants.ERROR_MSG_SEPARATOR+e.getMessage());				
			}		
			
		}		
		return null;
		
	}
	
}
