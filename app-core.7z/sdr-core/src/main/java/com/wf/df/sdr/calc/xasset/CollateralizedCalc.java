package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.meta.CollateralService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;

@Component
public class CollateralizedCalc {

	@Autowired
	CollateralService collateralService;
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(Calc.collateralizedCalc)
	public String clearingHouse(
			@DerivedFrom(value=Stv.CC_ClearingHouse) String chValue,
			@DerivedFrom(value=Stv.CC_ClearedDateTime) String value,
			@DerivedFrom(value=Stv.CounterpartyShortName) String shortName,
			@DerivedFrom(value=Stv.BusinessAccountId) String businessAccountId,
			@DerivedFrom(value=Stv.CID_ID, isInternal=true) String equityCidId,		
			@DerivedFrom(value=Calc.clearedTradeCalc,isInternal=true) boolean clearTrade,
			@DerivedFrom(value=Calc.dtccAssetClassCalc,isInternal=true) String assetClass,
			@DerivedFrom(value=Stv.TradeId,isInternal=true) String tradeID){
		
		// If its ONLY CLEARED! then its FullyCollateralized
		if(clearTrade){
			return Constants.FullyCollateralized;
		}
		else {			
			return collateralService.getDTCCCollaterlizedValue(equityCidId,shortName,businessAccountId,assetClass, tradeID);			
		}
		
	}
}