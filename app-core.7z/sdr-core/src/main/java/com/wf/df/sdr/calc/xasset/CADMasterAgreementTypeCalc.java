package com.wf.df.sdr.calc.xasset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.DTCCUtils;
import com.wf.df.sdr.util.Stv;

@Component
public class CADMasterAgreementTypeCalc {

	@Autowired
	DTCCUtils dtccUtils;
	
	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.cadMasterAgreementTypeCalc, isPrototype = false)
	public String compute(
			@DerivedFrom(value=Stv.LegalAgreementType, isInternal=true) String legal,
			@DerivedFrom(value=Stv.DTCCMasterAgreementType, isInternal=true) String dtccAgrementMaster,
			@DerivedFrom(value=Stv.MasterType, isInternal=true) String masterType) 
	{
		
		dtccAgrementMaster = dtccUtils.getMasterAgreement(dtccAgrementMaster);
		masterType = dtccUtils.getMasterAgreement(masterType);
		legal = dtccUtils.getLegalAgreement(legal);
		
		String ret =  (null != dtccAgrementMaster) ? dtccAgrementMaster :  (masterType != null) ? masterType :  legal;
		
		return (null != ret) ? ret : (String)Constants.NONE;
	}
}
