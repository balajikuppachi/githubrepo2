package com.wf.df.sdr.filters.utility;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.core.CalculationContext;
import com.wf.df.sdr.dao.InputMsgStoreDao;
import com.wf.df.sdr.dao.InputMsgStoreExtnDao;
import com.wf.df.sdr.dto.InputMsgStore;
import com.wf.df.sdr.exception.FilterException;
import com.wf.df.sdr.message.UnitOfWork;
import com.wf.df.sdr.service.utility.UtilityNotEligblePersister;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class UtilityUsiPreviousFilter {

	Logger logger = Logger.getLogger(getClass());
	
	
	@Autowired
	InputMsgStoreDao inputMsgStoreDao;
	
	@Autowired
	InputMsgStoreExtnDao inputMsgStoreExtnDao;
	
	@Autowired
	UtilityNotEligblePersister nep;
	
	public boolean isUSIPreviousAvailable(UnitOfWork uow) {
		logger.debug("UsiPreviousFilter Called");
		
		CalculationContext cc = uow.getCalculationContext();
		String tradeId = cc.getValue(Stv.TradeId, String.class);
		String usiCurrent = cc.getValue(Stv.USI_CURRENT, String.class);
		String usiPrevious = cc.getValue(Stv.USI_PREVIOUS, String.class);

		if(!Utils.IsNullOrBlank(tradeId)){
			List<String> lastTrades;
			
			/*For the Utility we get the second last trade from IMS*/
			lastTrades= inputMsgStoreExtnDao.findLatestTrade(tradeId); 
			
			if(Utils.IsListNullOrEmpty(lastTrades)){
				return true;
			} 
			
			if(Utils.IsNullOrBlank(lastTrades.get(0))){
				return true;
			} 
			
			
			if(!Utils.IsNullOrBlank(usiCurrent)) {
				 if(usiCurrent.equals(lastTrades.get(0))) {
					return true;
				} else {
					logger.info("USI Current do not match last trade USI Current for Trade ID: "+ Stv.TradeId);
				}
			}
				
			if(!Utils.IsNullOrBlank(usiPrevious)  && !Utils.IsNullOrBlank(usiPrevious))
			{
				/* PREV_USI*/
				/*Last trade drop only*/
				
				if(lastTrades.contains(usiPrevious))
					return true;

				nep.save(uow, UtilityNotEligblePersister.USIPREVIOUS);
				throw new FilterException("USIPrevious", "USI_PREVIOUS value is not available in SDR "+usiPrevious);
			} else {
				nep.save(uow, UtilityNotEligblePersister.USIPREVIOUS);
				throw new FilterException("USIPrevious", "Trade received with Empty USIPrevious "+usiPrevious);
			}
		} else {
			nep.save(uow, UtilityNotEligblePersister.USIPREVIOUS);
			throw new FilterException("TradeId", "TradeId Not Present ");
		}
	}
}
