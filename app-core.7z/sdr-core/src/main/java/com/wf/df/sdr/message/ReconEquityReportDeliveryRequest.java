package com.wf.df.sdr.message;

import java.io.File;

public class ReconEquityReportDeliveryRequest {

	private EquityEODReportGenerationRequest generationRequest;
	private File file;

	public ReconEquityReportDeliveryRequest(EquityEODReportGenerationRequest generationRequest, File file) {
		this.generationRequest = generationRequest;
		this.file = file;
	}

	public EquityEODReportGenerationRequest getReportGenerationRequest() {
		return generationRequest;
	}

	public File getFile() {
		return file;
	}
	
}
