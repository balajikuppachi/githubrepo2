package com.wf.df.sdr.dao.spring;

import com.wf.df.sdr.dao.DomainValuesDao;
import com.wf.df.sdr.dto.DomainValues;
import com.wf.df.sdr.exception.dao.DomainValuesDaoException;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

public class DomainValuesDaoImpl extends AbstractDAO implements ParameterizedRowMapper<DomainValues>, DomainValuesDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 */
	@Transactional
	public void insert(DomainValues dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime ) VALUES ( ?, ?, ?, ?, ?, ? )",dto.getDomain(),dto.getDtccCode(),dto.getDtccDesc(),dto.getSrcCode(),dto.getSrcDesc(),dto.getCreateDatetime());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return DomainValues
	 */
	public DomainValues mapRow(ResultSet rs, int row) throws SQLException
	{
		DomainValues dto = new DomainValues();
		dto.setDomain( rs.getString( 1 ) );
		dto.setDtccCode( rs.getString( 2 ) );
		dto.setDtccDesc( rs.getString( 3 ) );
		dto.setSrcCode( rs.getString( 4 ) );
		dto.setSrcDesc( rs.getString( 5 ) );
		dto.setCreateDatetime( rs.getTimestamp(6 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "domain_values";
	}

	/** 
	 * Returns all rows from the domain_values table that match the criteria ''.
	 */
	@Transactional
	public List<DomainValues> findAll() throws DomainValuesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime FROM " + getTableName() + "", this);
		}
		catch (Exception e) {
			throw new DomainValuesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'domain = :domain'.
	 */
	@Transactional
	public List<DomainValues> findWhereDomainEquals(String domain) throws DomainValuesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime FROM " + getTableName() + " WHERE domain = ? ORDER BY domain", this,domain);
		}
		catch (Exception e) {
			throw new DomainValuesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'dtcc_code = :dtccCode'.
	 */
	@Transactional
	public List<DomainValues> findWhereDtccCodeEquals(String dtccCode) throws DomainValuesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime FROM " + getTableName() + " WHERE dtcc_code = ? ORDER BY dtcc_code", this,dtccCode);
		}
		catch (Exception e) {
			throw new DomainValuesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'dtcc_desc = :dtccDesc'.
	 */
	@Transactional
	public List<DomainValues> findWhereDtccDescEquals(String dtccDesc) throws DomainValuesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime FROM " + getTableName() + " WHERE dtcc_desc = ? ORDER BY dtcc_desc", this,dtccDesc);
		}
		catch (Exception e) {
			throw new DomainValuesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'src_code = :srcCode'.
	 */
	@Transactional
	public List<DomainValues> findWhereSrcCodeEquals(String srcCode) throws DomainValuesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime FROM " + getTableName() + " WHERE src_code = ? ORDER BY src_code", this,srcCode);
		}
		catch (Exception e) {
			throw new DomainValuesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'src_desc = :srcDesc'.
	 */
	@Transactional
	public List<DomainValues> findWhereSrcDescEquals(String srcDesc) throws DomainValuesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime FROM " + getTableName() + " WHERE src_desc = ? ORDER BY src_desc", this,srcDesc);
		}
		catch (Exception e) {
			throw new DomainValuesDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the domain_values table that match the criteria 'create_datetime = :createDatetime'.
	 */
	@Transactional
	public List<DomainValues> findWhereCreateDatetimeEquals(Date createDatetime) throws DomainValuesDaoException
	{
		try {
			return jdbcTemplate.query("SELECT domain, dtcc_code, dtcc_desc, src_code, src_desc, create_datetime FROM " + getTableName() + " WHERE create_datetime = ? ORDER BY create_datetime", this,createDatetime);
		}
		catch (Exception e) {
			throw new DomainValuesDaoException("Query failed", e);
		}
		
	}

}
