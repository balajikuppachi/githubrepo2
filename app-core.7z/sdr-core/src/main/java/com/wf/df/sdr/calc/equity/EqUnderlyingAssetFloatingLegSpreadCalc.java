package com.wf.df.sdr.calc.equity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wf.df.sdr.calc.annotation.Calculation;
import com.wf.df.sdr.calc.annotation.DerivedFrom;
import com.wf.df.sdr.service.FormatterService;
import com.wf.df.sdr.util.Calc;
import com.wf.df.sdr.util.Constants;
import com.wf.df.sdr.util.Stv;
import com.wf.df.sdr.util.Utils;

@Component
public class EqUnderlyingAssetFloatingLegSpreadCalc {

	@Autowired
	FormatterService formatter;

	Logger logger = Logger.getLogger(this.getClass());

	@Calculation(value = Calc.eqUnderlyingAssetFloatingLegSpreadCalc, isPrototype = false)
	public String calcAction(
			@DerivedFrom(value = Stv.FloatingSpread, isInternal = true) String spread,
			@DerivedFrom(value = Stv.UnderlyngAssetIdentifierTypeList, isInternal = true) List<String> typelist) {

		if (!Utils.IsNullOrBlank(spread)) {
			
			return repeatPerUnderlyingAsset(formatter.parseAndFormatNumber(spread), typelist);	
			
		}
		return Constants.VALUE_NA;
	}
	
	private String repeatPerUnderlyingAsset(String notional, List<String> typelist){
		
		ArrayList<String> array = new ArrayList<String>();
		if (!Utils.IsListNullOrEmpty(typelist)) {
			for (int i = 0; i < typelist.size(); i++) {
				array.add(notional);
			}
		}
		return Utils.convertListToDelimitedString(array, Constants.SEMICOLON);
		
		
	}
	
}