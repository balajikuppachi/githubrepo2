package com.balaji.fileAdapter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

public class FileStringReplace {
	
	
	 public static void main( String[] args ) throws FileNotFoundException
	    {
		 
		 //File log= new File("C:\\Users\\u478943\\sources\\regulatory_dev\\reg-reporting\\regulatory\\distribution\\target-dev\\REG_REP_HOME\\data\\etd\\in\\CR_CDSABSIndex_1.xml");
		
		 File log= new File("C:\\Users\\u478943\\custom\\input\\16919906_CFTC_FX_110316FL.xml");
		 
		 File outlog;
		 String search;
		 String replace;
		 FileReader fr;
		 
		 for ( int i=1 ; i<101 ; i++) {
		 
			 outlog = new File("C:\\Users\\u478943\\custom\\out\\SDRReq_FX_16919906" + i + ".xml");
		 
			  search = "16919906";
			  replace = "16919906" + i;

			
			    fr = new FileReader(log);
			    String s;
			    String totalStr = "";
			    try {
			    		
			    	BufferedReader br = new BufferedReader(fr);

			        while ((s = br.readLine()) != null) {
			            totalStr += s;
			        }
			    totalStr = totalStr.replaceAll(search, replace);
			    
			    
			    FileWriter fw = new FileWriter(outlog);
			    fw.write(totalStr);
			    fw.close();
        
			}catch(Exception e){
			    e.printStackTrace();
			}
			    
			    
		}
		 
	    	
	        	
	 }
	    
	  

}
