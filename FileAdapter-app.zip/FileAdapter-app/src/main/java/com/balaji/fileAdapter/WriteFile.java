package com.balaji.fileAdapter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;

public class WriteFile {
	
	private static final Logger logger = Logger.getLogger(WriteFile.class);
	
	public void writeFile(String originalPayload, File outFile)
			throws IOException {
		logger.info("Enter writeFile method:");

		FileWriter fw = new FileWriter(outFile);
		fw.write(originalPayload);
		fw.close();
		
		logger.info(" outFile Path : "+outFile.getAbsolutePath());
		
		logger.info("Exit writeFile method:");
	}

}
