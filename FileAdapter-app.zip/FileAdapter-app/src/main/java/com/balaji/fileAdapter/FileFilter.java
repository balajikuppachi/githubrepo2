package com.balaji.fileAdapter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.Message;
import org.springframework.integration.MessagingException;

public class FileFilter {
	
	@Value("${outputFolder.DEV}")
	String outFolderDEV;
	
	@Value("${outputFolder.SIT}")
	String outFolderSIT;
	
	@Value("${outputFolder.UAT}")
	String outFolderUAT;
	
	@Value("${outputFolder.PROD}")
	String outFolderPROD;
	

	private static final Logger logger = Logger.getLogger(FileFilter.class);

	public void start(Message<?> message) throws MessagingException {

		logger.info("FileFilter execution started ...");

		File sourceFile = null;
		String fileName;
		Object inputMessage = message.getPayload();
		try {
			if (inputMessage instanceof File) {

				sourceFile = ((File) inputMessage);
				
				logger.info("getName...." + sourceFile.getName());
				
				fileName = sourceFile.getName();
						
				logger.info("getAbsolutePath...." + sourceFile.getAbsolutePath());

				String originalPayload = FileUtils.readFileToString(sourceFile);

				if (!originalPayload.isEmpty()) {
					publish(originalPayload,fileName);
				}

			}
		} catch (Exception e) {
			logger.error("Error while executing FileFilter ..."
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			sourceFile.delete();
		}

		logger.info("FileFilter execution ended ...");
	}

	private void publish(String originalPayload , String fileName) throws Exception {

		File outlog;
		
		logger.info("Enter publish method:");
		
		WriteFile writeFile = new WriteFile();

		try {
			if (originalPayload.contains("_DEV")) {
				outlog = new File(outFolderDEV + fileName);
				writeFile.writeFile(originalPayload,outlog);	
			} else if (originalPayload.contains("_SIT")) {
				outlog = new File(outFolderSIT + fileName);
				writeFile.writeFile(originalPayload,outlog);
			} else if (originalPayload.contains("_UAT")) {
				outlog = new File(outFolderUAT + fileName);
				writeFile.writeFile(originalPayload,outlog);
			} else if (originalPayload.contains("_PROD")) {
				outlog = new File(outFolderPROD + fileName);
				writeFile.writeFile(originalPayload,outlog);
			}

		} catch (Exception e) {
			throw e;
		}

		logger.info("Exit publish method:");
	}

//	private void writeFile(String originalPayload, File outFile)
//			throws IOException {
//		logger.info("Enter writeFile method:");
//
//		FileWriter fw = new FileWriter(outFile);
//		fw.write(originalPayload);
//		fw.close();
//		
//		logger.info(" outFile Path : "+outFile.getAbsolutePath());
//		
//		logger.info("Exit writeFile method:");
//	}

}
