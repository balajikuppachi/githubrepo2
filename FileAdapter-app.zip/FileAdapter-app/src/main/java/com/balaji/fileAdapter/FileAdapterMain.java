package com.balaji.fileAdapter;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class FileAdapterMain {
	
	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:/spring/fileAdapterContext.xml";
	private static final Logger logger = Logger.getLogger(FileAdapterMain.class);
	
	public static void main(String[] args) throws IOException	
	{
		logger.info("FileAdapterMain execution started ...");	
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		applicationContext.start();
		applicationContext.registerShutdownHook();
		//applicationContext.close();
		
	}

}
