package org.bala.java.utility.encryption.factory;

import org.apache.log4j.Logger;
import org.bala.java.utility.encryption.helper.SecureDBPwdHelper;


public class SecureDBPwdFactory 
{
    private static final Logger LOG = Logger.getLogger(SecureDBPwdFactory.class);

    private boolean encryptionEnabled = true;
    private String passPhrase = null;
    private String password = null;

    private SecureDBPwdHelper pwdHelper;

    public void setEncryptionEnabled(final boolean encryptionEnabled) 
    {
        this.encryptionEnabled = encryptionEnabled;
    }

    public void setPassPhrase(final String passPhrase) 
    {
        this.passPhrase = passPhrase;
    }

    public void setPassword(final String password) 
    {
        this.password = password;
    }

    public void init() 
    {
        LOG.info("SecureDBPwdFactory is being initialised with encryptionEnabled: " + encryptionEnabled);
        
        if (encryptionEnabled) 
        {
            LOG.info("Instatiating instance of password encoder, passphrase was " + (passPhrase == null ? "not provided" : "provided"));
            pwdHelper = new SecureDBPwdHelper(passPhrase);
        }
    }

    public String getPassword() 
    {
        if (encryptionEnabled) 
        {
            LOG.debug("Returning decrypted password...");
            return pwdHelper.decrypt(password);
        }
        
        LOG.debug("Returning password without decryption...");
        
        return password;
    }
    
    public String getPassword(String passwordToDecrypt) 
    {
        if (encryptionEnabled) 
        {
            LOG.debug("Returning decrypted password...");
            return pwdHelper.decrypt(passwordToDecrypt);
        }
        
        LOG.debug("Returning password without decryption...");
        
        return password;
    }
}
