package org.bala.java.utility.encryption.main;

import org.apache.log4j.Logger;
import org.bala.java.utility.encryption.helper.SecureDBPwdHelper;


public class EncryptionUtility 
{
	private static final Logger logger = Logger.getLogger(EncryptionUtility.class);
	
	public static void main(String[] args) 
	{
		/*** Check how many arguments were passed in ***/
	    if(args.length < 1)
	    {
	        System.out.println("<<<< Missing Input Parameter(s) : 2 arguments are required >>>> ");
	        System.out.println("<<<< EncryptionUtility Usage: \n Argument-1: Encrypt/Decrypt \n Argument-2: Password-Value ");
	        System.exit(0);
	    }

		String optionString = new String(args[0]);
		String deryptString = new String(args[1]);

		System.out.println("Input args[0] ===> " + args[0]);
		System.out.println("Input args[1] ===> " + args[1]);
		
        SecureDBPwdHelper secureDBPwdHelper = new SecureDBPwdHelper();
        
		if("Decrypt".equalsIgnoreCase(optionString)) 
		{
	        String decryptedString = secureDBPwdHelper.decrypt(deryptString);
	        String encryptedString = secureDBPwdHelper.encrypt(decryptedString);
			
	        System.out.println("Decrypted String ===> " + decryptedString);
			System.out.println("Encrypted String ===> " + encryptedString);
		}
		else if("Encrypt".equalsIgnoreCase(optionString)) 
		{
	        String encryptedString = secureDBPwdHelper.encrypt(deryptString);
	        String decryptedString = secureDBPwdHelper.decrypt(encryptedString);

			System.out.println("Encrypted String ===> " + encryptedString);
	        System.out.println("Decrypted String ===> " + decryptedString);
		}
		
	}

}
