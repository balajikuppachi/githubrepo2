package org.bala.java.adapter;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.bala.java.adapter.beans.CreateJmsTemplate;
import org.bala.java.adapter.beans.IBMMQConnectionFactoryBean;
import org.bala.java.adapter.enums.ExceptionSeverityEnum;
import org.bala.java.adapter.enums.ExceptionTypeEnum;
import org.bala.java.adapter.exceptions.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;


@Component
public class MQMessageProcessor {
	
	@Autowired
	@Qualifier("destinationTemplate")
	private  JmsTemplate jmsTemplate;
		
	@Autowired
	private IBMMQConnectionFactoryBean regMQConnectionFactory;
			
	@Value("${regrep.adapter.response.sit}")
	private String writerQueueSIT;
	
	@Value("${regrep.adapter.response.dev}")
	private String writerQueueDEV;
	
	@Value("${regrep.adapter.response.uat}")
	private String writerQueueUAT;
	
	@Value("${regrep.adapter.response.dsuat}")
	private String writerQueueDSUAT;
	
	private static Logger logger = Logger.getLogger(MQMessageProcessor.class.getName());

	public Message<?>  processMessage(Message<?> message) throws MessagingException, JMSException {

		logger.info("Entering processMessage() method");
		 try {
			logger.info("Message has been successfuly read from the DTCC Queue.");
			logger.info("Payload "+ message.getPayload());
			//publish(message);
			logger.info("Message has been successfuly routed to Environment specific Queue.");
		 }
		 catch (Exception ex) {
			logger.error("######## Exception occured while reading message from the queue:", ex);
			throw new MessagingException("PQ:submission:1", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, "Error while reading message from the queue " +  ex);
		 }
		 
		  logger.info("Leaving processMessage() method");
		  return message;
		 
	 }
	
	private void publish(Message<?> message) throws MessagingException, InterruptedException {
		
		logger.info("Enter MQ publish method:");
		Object ipMessage 		= null;
		String origPayload 		= null;
		String errorString 		= null;
		
		ipMessage 		= message.getPayload();
		
		if (null == ipMessage){
			
			errorString = "Null incoming request ";
			logger.error("########## " + errorString);

			throw new MessagingException("Reader-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, null, null);
		}
		
		if (ipMessage instanceof String){
			
			origPayload = (String) ipMessage;
		}
		
		MessageCreator messageCreator = getMessageCreator(origPayload);

		CreateJmsTemplate cjmsTemplate = new CreateJmsTemplate();
		
		jmsTemplate = cjmsTemplate.createJmsTemplate(regMQConnectionFactory);
		
		//for(int i = 0; i < 999999999; i++){
			//Thread.sleep(60000);
		//}

		try {
			if ( origPayload.contains("#DEV")) {
				logger.info("Sending message to DEV Environment Queue: " + writerQueueDEV);
				jmsTemplate.send(writerQueueDEV, messageCreator);	
			} else if ( origPayload.contains("#SIT")) {
				logger.info("Sending message to SIT Environment Queue: " + writerQueueSIT);
				jmsTemplate.send(writerQueueSIT, messageCreator);
			} else if ( origPayload.contains("#UAT")) {
				logger.info("Sending message to UAT Environemnt Queue: " + writerQueueUAT);
				jmsTemplate.send(writerQueueUAT, messageCreator);
			} else if ( origPayload.contains("#DSUAT")) {
				logger.info("Sending message to DSUAT Environment Queue: " + writerQueueDSUAT);
				jmsTemplate.send(writerQueueDSUAT, messageCreator);
			}else {
				logger.info("Sending message to default UAT Environment Queue: " + writerQueueUAT);
				jmsTemplate.send(writerQueueUAT, messageCreator);	
				
			}
			

		} catch (Exception ex) {
			logger.error("######## Exception occured in sendMessageToPriorityQueue:", ex);
			
			throw new MessagingException("PQ:submission:1", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, "Error while submiiting message to the queue ", ex);
		}

		logger.info("Exit MQ publish method:");
	}
	
	private  MessageCreator getMessageCreator(final String message){
	
		MessageCreator messageCreator = new MessageCreator(){
		
			public javax.jms.Message createMessage(Session session){
			
				TextMessage textMessage = null;
				try{
				
					textMessage = session.createTextMessage(message);
				}
				catch (JMSException e){
				
					logger.error("######## Error creating Text message in sendMessageToPriorityQueue:", e);
				}

				return textMessage;
			}
		};

		return messageCreator;
	}
	
	
	
}
