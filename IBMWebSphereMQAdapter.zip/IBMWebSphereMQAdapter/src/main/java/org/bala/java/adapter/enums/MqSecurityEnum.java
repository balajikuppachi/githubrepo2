package org.bala.java.adapter.enums;

public enum MqSecurityEnum
{

	SSLv3("SSLv3"),

	JKS("JKS");

	private final String value;

	private MqSecurityEnum(String strValue)
	{

		value = strValue;

	}

	public String getValue()
	{

		return value;

	}

}
