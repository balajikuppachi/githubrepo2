package org.bala.java.adapter.beans;

import java.util.Properties;

import org.bala.java.adapter.beans.IBMMQConnectionFactoryBean;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.destination.JndiDestinationResolver;
import org.springframework.jndi.JndiTemplate;

public class CreateJmsTemplate {
	
	private JmsTemplate jmsTemplate=null;
	
	public JmsTemplate createJmsTemplate(IBMMQConnectionFactoryBean regMQConnectionFactory){
		
		IBMMQConnectionFactoryBean connectionFactoryBean = new IBMMQConnectionFactoryBean();
		try {
			connectionFactoryBean.init();
			
			connectionFactoryBean.setHostName(regMQConnectionFactory.getHostName());
			connectionFactoryBean.setPort(regMQConnectionFactory.getPort());
			connectionFactoryBean.setQueueManager(regMQConnectionFactory.getQueueManager());
			connectionFactoryBean.setChannel(regMQConnectionFactory.getChannel());
			connectionFactoryBean.setTransportType(regMQConnectionFactory.getTransportType());
			connectionFactoryBean.setSSLCipherSuite(regMQConnectionFactory.getSSLCipherSuite());
			
			CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory();
			cachingConnectionFactory.setTargetConnectionFactory(connectionFactoryBean);
			
			JndiDestinationResolver destinationResolver = new JndiDestinationResolver();
			JndiTemplate jndiTemplate = new JndiTemplate();
			
			Properties environment = new Properties();
	
			jndiTemplate.setEnvironment(environment);
			
			destinationResolver.setJndiTemplate(jndiTemplate);
			destinationResolver.setCache(true);
			destinationResolver.setFallbackToDynamicDestination(true);

			jmsTemplate = new JmsTemplate();
			
			jmsTemplate.setConnectionFactory(cachingConnectionFactory);
			jmsTemplate.setDestinationResolver(destinationResolver);
			
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return jmsTemplate;
		
	}

}
