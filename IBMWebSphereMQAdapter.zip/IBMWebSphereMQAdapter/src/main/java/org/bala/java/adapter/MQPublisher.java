package org.bala.java.adapter;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.bala.java.adapter.enums.ExceptionSeverityEnum;
import org.bala.java.adapter.enums.ExceptionTypeEnum;
import org.bala.java.adapter.exceptions.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component
public class MQPublisher {
	
	
	private  JmsTemplate jmsTemplate;
	
	@Value("${regrep.adapter.response.uat}")
	private String writerQueueUAT;
	
	private static Logger logger = Logger.getLogger(MQMessageProcessor.class.getName());

	public void publishMessage(Message<?> message) throws MessagingException, JMSException {

		logger.info("Entering processMessage() method");
		 try {
			logger.info("Message has been successfuly read from the PublishChannel Queue.");
			
			logger.info("Payload "+ message.getPayload());
			

			logger.info("Enter MQ publish method:");
			Object ipMessage 		= null;
			String origPayload 		= null;
			String errorString 		= null;
			
			ipMessage 		= message.getPayload();
			
			if (null == ipMessage){
				
				errorString = "Null incoming request ";
				logger.error("########## " + errorString);

				throw new MessagingException("Reader-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, null, null);
			}
			
			if (ipMessage instanceof String){
				
				origPayload = (String) ipMessage;
			}
			
			MessageCreator messageCreator = getMessageCreator(origPayload);
			
			
			logger.info("Sending message to default UAT Environment Queue: " + writerQueueUAT);
			
			
			
			jmsTemplate.send(writerQueueUAT, messageCreator);	
			
			logger.info("Message has been successfuly routed to Environment specific Queue.");
		 }
		 catch (Exception ex) {
			logger.error("######## Exception occured while reading message from the queue:", ex);
			throw new MessagingException("PQ:submission:1", ExceptionSeverityEnum.WARNING, ExceptionTypeEnum.REG_REP_ERROR, "Error while reading message from the queue " +  ex);
		 }
		 
		 logger.info("Leaving processMessage() method");
		 
	 }
	
	private  MessageCreator getMessageCreator(final String message){
		
		MessageCreator messageCreator = new MessageCreator(){
		
			public javax.jms.Message createMessage(Session session){
			
				TextMessage textMessage = null;
				try{
				
					textMessage = session.createTextMessage(message);
				}
				catch (JMSException e){
				
					logger.error("######## Error creating Text message in sendMessageToPriorityQueue:", e);
				}

				return textMessage;
			}
		};

		return messageCreator;
	}
	
	public void setJmsTemplate(JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}

}
