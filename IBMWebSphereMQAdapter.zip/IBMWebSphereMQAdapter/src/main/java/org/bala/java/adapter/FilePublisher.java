package org.bala.java.adapter;

import java.io.File;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.bala.java.adapter.beans.CreateJmsTemplate;
import org.bala.java.adapter.beans.IBMMQConnectionFactoryBean;
import org.bala.java.adapter.exceptions.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component
public class FilePublisher {
			
	@Autowired
	@Qualifier("destinationTemplate")
	private  JmsTemplate jmsTemplate;
	
	@Autowired
	private IBMMQConnectionFactoryBean regMQConnectionFactory;
	
	@Value("${regRep.adapter.onDemand.queue}")
	private String onDemandQueue;
	
	private static final Logger logger = Logger.getLogger(FilePublisher.class);

	public void start(Message<?> message) throws MessagingException {

		logger.info("FilePublisher execution started ...");

		File sourceFile = null;
		Object inputMessage = message.getPayload();
		try {
			if (inputMessage instanceof File) {

				sourceFile = ((File) inputMessage);
						
				logger.info("getAbsolutePath...." + sourceFile.getAbsolutePath());

				String originalPayload = FileUtils.readFileToString(sourceFile);

				if (!originalPayload.isEmpty()) {
					publish(originalPayload);
				}

			}
		} catch (Exception e) {
			logger.error("Error while executing FileFilter ..."
					+ e.getMessage());
			e.printStackTrace();
		}
//		finally {
//			sourceFile.delete();
//		}

		logger.info("FilePublisher execution ended ...");
	}
	
	public void publish(String message){
			
		logger.info("Enter file publish method:");
		
		MessageCreator messageCreator = getMessageCreator(message);

		CreateJmsTemplate cjmsTemplate = new CreateJmsTemplate();
		
		jmsTemplate = cjmsTemplate.createJmsTemplate(regMQConnectionFactory);

		try{
		
			logger.info("Sending message to OnDemand Queue: " + onDemandQueue);
			jmsTemplate.send(onDemandQueue, messageCreator);	
		
		} catch (Exception ex) {
			logger.error("######## Exception occured in sendMessageToOnDemandQueue:", ex);
		}
		
		logger.info("End file publish method:");
	}
	
	private  MessageCreator getMessageCreator(final String message){
		
		MessageCreator messageCreator = new MessageCreator(){
		
			public javax.jms.Message createMessage(Session session){
			
				TextMessage textMessage = null;
				try{
				
					textMessage = session.createTextMessage(message);
				}
				catch (JMSException e){
				
					logger.error("######## Error creating Text message in sendMessageToOnDemandQueue:", e);
				}

				return textMessage;
			}
		};

		return messageCreator;
	}

}
