package org.bala.java.adapter.exceptions;

import org.bala.java.adapter.enums.ExceptionSeverityEnum;
import org.bala.java.adapter.enums.ExceptionTypeEnum;


/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public class MessagingException extends ReportingException
{

	private static final long serialVersionUID = 784242930442261737L;

	public MessagingException(String errorCode, ExceptionSeverityEnum severity, 
			ExceptionTypeEnum type, String message, String sdrMessageId,
			String tradeId)
	{

		super(message);
		this.exceptionCode = errorCode;
		this.exceptionSeverity = severity;
		this.exceptionType = type;
		this.sdrMessageId = sdrMessageId;
		this.swapTradeId = tradeId;
	}

	public MessagingException(String exceptionCode, ExceptionSeverityEnum severity, ExceptionTypeEnum type, 
			String message, String sdrMessageId, Throwable cause,
			String tradeId)
	{

		super(message, cause);
		this.exceptionCode = exceptionCode;
		this.exceptionSeverity = severity;
		this.exceptionType = type;
		this.sdrMessageId = sdrMessageId;
		this.swapTradeId = tradeId;
	}

	public MessagingException(String exceptionCode, ExceptionSeverityEnum severity, ExceptionTypeEnum type, String message)
	{

		super(message);
		this.exceptionCode = exceptionCode;
		this.exceptionSeverity = severity;
		this.exceptionType = type;
	}

	public MessagingException(String exceptionCode, ExceptionSeverityEnum severity, ExceptionTypeEnum type, String message, Throwable cause)
	{

		super(message, cause);
		this.exceptionCode = exceptionCode;
		this.exceptionSeverity = severity;
		this.exceptionType = type;
	}

}
