package org.bala.java.adapter.beans;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;

import javax.net.SocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.apache.log4j.Logger;
import org.bala.java.adapter.enums.ExceptionSeverityEnum;
import org.bala.java.adapter.enums.ExceptionTypeEnum;
import org.bala.java.adapter.enums.MqSecurityEnum;
import org.bala.java.adapter.exceptions.MessagingException;




public class IBMMQConnectionFactoryBean extends com.ibm.mq.jms.MQQueueConnectionFactory
{

	/**
	 * Default serial ID
	 */
	private static final long serialVersionUID = 1L;

	private String trustStoreFile;
	private String trustStorePass;
	private String keyStoreFile;
	private String keyStorePass;

	private static String OS = System.getProperty("os.name").toLowerCase();

	private static Logger logger = Logger.getLogger(IBMMQConnectionFactoryBean.class.getName());

	/*
	 * @param value It is the cipher suite (of type String) that is used for the ssl connectivity
	 * with the web sphere MQ eg:SSL_RSA_WITH_NULL_SHA
	 */
	public void setSSLCipherSuite(String value)
	{

		super.setSSLCipherSuite(value);

	}

	/**
	 * @param trustStore
	 * It is the store of certificates used for secure communication between. These certificates are
	 * used to trust the transacting parties Web Sphere MQ
	 */
	public void setTrustStore(String trustStore)
	{

		if (isWindows())
		{

			ClassLoader loader = this.getClass().getClassLoader();
			URL trustStoreUrl;

			if (loader == null)
			{

				trustStoreUrl = ClassLoader.getSystemResource(trustStore);  // A system class.
			}
			else
			{

				trustStoreUrl = loader.getResource(trustStore);
			}

			this.trustStoreFile = trustStoreUrl.getPath();

		}
		else
		{

			this.trustStoreFile = System.getProperty("javax.net.ssl.trustStore");
		}

	}

	/**
	 * @param keyStore
	 * It is the store of certificates used for secure communication between Web Sphere MQ. These
	 * keys belong to MQ which is given to us to use the MQ
	 */
	public void setKeyStore(String keyStore)
	{

		if (isWindows())
		{
			ClassLoader loader = this.getClass().getClassLoader();
			URL keyStoreUrl;

			if (loader == null)
			{

				keyStoreUrl = ClassLoader.getSystemResource(keyStore);  // A system class.
			}
			else
			{

				keyStoreUrl = loader.getResource(keyStore);
			}

			this.keyStoreFile = keyStoreUrl.getPath();
		}
		else
		{

			this.keyStoreFile = System.getProperty("javax.net.ssl.keyStore");
		}
	}

	/**
	 * @param trustStorePassword
	 * Here the password for the trust store is set from teh properties file
	 */
	public void setTrustStorePassword(String trustStorePassword)
	{
		this.trustStorePass = trustStorePassword;
	}

	/**
	 * @param keyStorePassword
	 * Here the pasword for the key store is set from the properties file
	 */
	public void setKeyStorePassword(String keyStorePassword)
	{
		this.keyStorePass = keyStorePassword;
	}

	public void setSSLDebug(boolean sslDebug)
	{
		if (sslDebug)
		{
			/*
			 * The SSl Debug is included which gives the certificates that are picked up for the SSL
			 * connection
			 */

			System.setProperty("javax.net.debug", "ssl");
		}
	}

	/**
	 * We create a custom SSL Context so that we never impact the SSL context in the app server.
	 * Setting the javax.net.ssl properties on the JVM causes global changes, so we avoid it.
	 * 
	 * @throws MessagingException
	 */
	public void init() throws MessagingException
	{

		SSLContext ctx = null;
		KeyManagerFactory keyManagerFactory = null;
		TrustManagerFactory trustManagerFactory = null;
		InputStream keyStoreIS = null;
		InputStream trustStoreIS = null;
		KeyStore keyStore = null;
		KeyStore trustStore = null;
		String errorString = null;

		logger.info("init():Initializing RegMQQueueConnectionfactoryBean..:BEGIN");

		if (trustStoreFile != null)
		{

			logger.debug("init():Initialize SSL Context");

			/*
			 * The ssl context is instantiated for SSLv3
			 */
			try
			{

				ctx = SSLContext.getInstance(MqSecurityEnum.SSLv3.getValue());
				keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
				trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
				keyStore = KeyStore.getInstance(MqSecurityEnum.JKS.getValue());
				trustStore = KeyStore.getInstance(MqSecurityEnum.JKS.getValue());

				logger.debug("init():Load KeyStore: " + keyStoreFile);

				/*
				 * Here the key store is loaded from the location mentioned in the spring beans for
				 * the key store This is loaded inside a try block.
				 */
				try
				{
					keyStoreIS = new FileInputStream(keyStoreFile);
					keyStore.load(keyStoreIS, keyStorePass.toCharArray());
				}
				finally
				{
					if (keyStoreIS != null)
					{
						try
						{

							keyStoreIS.close();

						}
						catch (Exception e)
						{

							logger.error("Error while closing key store ", e);
						}
					}
				}

				logger.debug("init():Load TrustStore: " + trustStoreFile);

				/*
				 * Here the trust store is loaded from the location mentioned in the spring beans
				 * for the trust store This is loaded inside a try block.
				 */
				try
				{
					trustStoreIS = new FileInputStream(trustStoreFile);
					trustStore.load(trustStoreIS, trustStorePass.toCharArray());
				}
				finally
				{
					if (trustStoreIS != null)
					{
						try
						{
							trustStoreIS.close();

						}
						catch (Exception e)
						{

							logger.error("Error while closing trust store ", e);
						}
					}
				}

				keyManagerFactory.init(keyStore, keyStorePass.toCharArray());
				trustManagerFactory.init(trustStore);

				ctx.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);

				SocketFactory factory = ctx.getSocketFactory();

				this.setSSLSocketFactory(factory);

			}
			catch (Exception e)
			{

				errorString = "Unable to initialize MQ Connection factory" + e;
				logger.error("######### "+errorString);
				throw new MessagingException("MQ:init:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString);
			}
		}

		logger.info("init():Initializing RegMQQueueConnectionfactoryBean..:END");
	}

	public static boolean isWindows()
	{
		return (OS.indexOf("win") >= 0);
	}

	public static boolean isUnix()
	{
		return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") > 0);
	}

	public static boolean isSolaris()
	{
		return (OS.indexOf("sunos") >= 0);
	}

}
