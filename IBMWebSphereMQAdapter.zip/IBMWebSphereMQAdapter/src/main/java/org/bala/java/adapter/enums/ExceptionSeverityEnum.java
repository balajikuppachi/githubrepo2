package org.bala.java.adapter.enums;

/**
 * @author Amit Rana
 * @date 0/23/2014
 * @version 1.0
 */

public enum ExceptionSeverityEnum
{

	WARNING("Warning"), ERROR("Error"), ALERT("Alert");

	private String value;

	private ExceptionSeverityEnum(String v)
	{

		this.value = v;
	}

	public String type()
	{
		return this.name();
	}

	public static ExceptionSeverityEnum fromValue(String v)
	{

		for (ExceptionSeverityEnum c : ExceptionSeverityEnum.values())
		{
			if (c.value.equals(v))
			{
				return c;
			}
		}

		throw new IllegalArgumentException(v);
	}
}
