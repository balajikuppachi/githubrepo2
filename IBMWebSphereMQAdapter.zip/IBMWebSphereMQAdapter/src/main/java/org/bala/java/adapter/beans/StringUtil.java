package org.bala.java.adapter.beans;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Collection of simple string utils.
 */
public final class StringUtil
{
	public static final String DEFAULT_LIST_DELIM = ",";

	private StringUtil()
	{
		// nothing to do
	}

	/**
	 * Converts a delimited string to a list of strings
	 * 
	 * @param s
	 * delimited string
	 * @param delim
	 * string delimiter
	 * @return list of strings
	 */
	public static List<String> stringToList(String s, String delim)
	{
		List<String> list = new Vector<String>();

		for (StringTokenizer tok = new StringTokenizer(s, delim); tok.hasMoreElements();)
		{
			list.add(tok.nextToken().trim());
		}

		return list;
	}

	/**
	 * Converts a delimited string to a list of strings
	 * 
	 * @param delimited
	 * string
	 * @return list of strings
	 */
	public static List<String> stringToList(String s)
	{
		return stringToList(s, DEFAULT_LIST_DELIM);
	}

	/**
	 * Converts a delimited string to an array of strings
	 * 
	 * @param s
	 * delimited string
	 * @param delim
	 * string delimiter
	 * @return array of strings
	 */
	public static String[] stringToArray(String s, String delim)
	{
		List<String> v = stringToList(s, delim);
		return (String[]) v.toArray(new String[]
		{});
	}

	/**
	 * Converts a delimited string to an array of strings
	 * 
	 * @param delimited
	 * string
	 * @return array of strings
	 */
	public static String[] stringToArray(String s)
	{
		return stringToArray(s, DEFAULT_LIST_DELIM);
	}

	/**
	 * Converts a delimited string to a list of Doubles
	 * 
	 * @param delimited
	 * string
	 * @return array of doubles
	 */
	public static List<Double> stringToDoubleList(String s)
	{
		List<String> sList = stringToList(s);
		List<Double> list = new Vector<Double>();

		for (String sItem : sList)
		{
			list.add(Double.parseDouble(sItem));
		}

		return list;
	}

	/**
	 * Converts a delimited string to an array of doubles
	 * 
	 * @param delimited
	 * string
	 * @return array of doubles
	 */
	public static double[] stringToDoubleArray(String s)
	{
		String[] sa = stringToArray(s);
		double[] da = new double[sa.length];

		for (int i = 0; i < da.length; i++)
		{
			da[i] = Double.parseDouble(sa[i]);
		}

		return da;
	}

	/**
	 * Converts a delimited string to a list of Longs
	 * 
	 * @param delimited
	 * string
	 * @return array of longs
	 */
	public static List<Long> stringToLongList(String s)
	{
		List<String> sList = stringToList(s);
		List<Long> list = new Vector<Long>();

		for (String sItem : sList)
		{
			list.add(Long.parseLong(sItem));
		}

		return list;
	}

	/**
	 * Converts a delimited string to an array of longs
	 * 
	 * @param delimited
	 * string
	 * @return array of longs
	 */
	public static long[] stringToLongArray(String s)
	{
		String[] sa = stringToArray(s);
		long[] la = new long[sa.length];

		for (int i = 0; i < la.length; i++)
		{
			la[i] = Long.parseLong(sa[i]);
		}

		return la;
	}

	/**
	 * Converts an array of strings to a single delimited string
	 * 
	 * @param s
	 * array of strings
	 * @param delim
	 * string delimiter
	 * @return delimited string
	 */
	public static String arrayToString(Object[] os, String delim)
	{
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < os.length; i++)
		{
			if (i > 0)
			{
				sb.append(delim);
			}

			sb.append(os[i]);
		}

		return sb.toString();
	}

	/**
	 * Converts an array of objects to a single delimited string
	 * 
	 * @param s
	 * array of strings
	 * @return delimited string
	 */
	public static String arrayToString(Object[] os)
	{
		return arrayToString(os, DEFAULT_LIST_DELIM);
	}

	/**
	 * Converts an array of ints to a single delimited string
	 * 
	 * @param s
	 * array of strings
	 * @param delim
	 * string delimiter
	 * @return delimited string
	 */
	public static String arrayToString(int[] is, String delim)
	{
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < is.length; i++)
		{
			if (i > 0)
			{
				sb.append(delim);
			}

			sb.append(is[i]);
		}

		return sb.toString();
	}

	/**
	 * Converts an array of ints to a single delimited string
	 * 
	 * @param s
	 * array of strings
	 * @return delimited string
	 */
	public static String arrayToString(int[] is)
	{
		return arrayToString(is, DEFAULT_LIST_DELIM);
	}

	/**
	 * pads the right of the String with the padding supplied until the string is the width required
	 * 
	 * @param str
	 * The String to be padded
	 * @param padStr
	 * The String to use as the padding
	 * @param totalWidth
	 * the total width of the original string and and the padding
	 * @return Right padded string
	 */
	public static String rightPad(String str, String padStr, int totalWidth)
	{
		StringBuffer buf = new StringBuffer(str);
		int padLen = totalWidth - str.length();

		if (padLen > 0)
		{
			double noRepeats = padLen / padStr.length();
			buf = repeat(buf, padStr, ((int) Math.round(noRepeats) + 1));
		}

		return buf.toString().substring(0, (totalWidth - 1));
	}

	/**
	 * pads the right of the String with the spaces until the string is the width required
	 * 
	 * @param str
	 * The String to be padded
	 * @param totalWidth
	 * the total width of the original string and and the padding
	 * @return Right padded string
	 */
	public static String rightPad(String str, int totalWidth)
	{
		return rightPad(str, " ", totalWidth);
	}

	/**
	 * Repeat the supplied String the number of times requested and populates teh StringBuffer with
	 * the repeating characters
	 * 
	 * @param container
	 * the Buffer to populate with the repeating characters
	 * @param repeatingString
	 * the String to repeat
	 * @param noRepeats
	 * the number of times to repeat
	 * @return the Buffer populated with repeats
	 */
	public static StringBuffer repeat(StringBuffer container, String repeatingString, int noRepeats)
	{
		for (int i = 0; i < noRepeats; i++)
		{
			container.append(repeatingString);
		}

		return container;
	}

	/**
	 * Creates a string with the required number of repeats
	 * 
	 * @param repeatStr
	 * the String to repeat
	 * @param noRepeats
	 * the number of times to repeat
	 * @return a String of repeats.
	 */
	public static String repeat(String repeatStr, int noRepeats)
	{
		return repeat(new StringBuffer(), repeatStr, noRepeats).toString();
	}

	/**
	 * Capitalises the supplied string to return a Camel Cased String. (default capitalisation based
	 * on Spaces) <br/> i.e. <br/> <table> <tr> <td>converts </td> <td><code>the fact that no one
	 * understands you doesn't make you an artist.</code></td> </tr> <tr> <td>to </td> <td><code>The
	 * Fact That No One Understands You Doesn't Make You An Artist. </code></td> <tr> </table> <br/>
	 * 
	 * @param str
	 * the String to capitalis
	 * @return
	 */
	public static String capitalise(String str)
	{
		return capitalise(str, " ", true);
	}

	/**
	 * Capitalises the supplied string to return a Camel Cased String. (default capitalisation based
	 * on Spaces) <br/> i.e. <br/> <table> <tr> <td>converts </td> <td><code>the fact that no one
	 * understands you doesn't make you an artist.</code></td> </tr> <tr> <td>to </td> <td><code>The
	 * Fact That No One Understands You Doesn't Make You An Artist. </code></td> <tr> </table> <br/>
	 * 
	 * @param str
	 * the String to capitalis
	 * @param includeFirstChar
	 * set the first char to upper case
	 * @return
	 */
	public static String capitalise(String str, boolean lowerFirstChar)
	{
		return capitalise(str, " ", lowerFirstChar);
	}

	/**
	 * Capitalises the supplied string to return a Camel Cased String.<br/> i.e. When the delimiter
	 * is a "_" it <br/> <table> <tr> <td>converts </td>
	 * <td><code>he_talked_with_more_claret_than_clarity.</code></td> </tr> <tr> <td>to </td>
	 * <td><code>He_Talked_With_More_Claret_Than_Clarity.</code></td> <tr> </table> <br/>
	 * 
	 * @param str
	 * the String to capitalise
	 * @param delimiter
	 * the delimiter to capitalise after
	 * @return
	 */
	public static String capitalise(String str, String delimiter)
	{
		return capitalise(str, delimiter, true);
	}

	/**
	 * Capitalises the supplied string to return a Camel Cased String.<br/> i.e. When the delimiter
	 * is a "_" it <br/> <table> <tr> <td>converts </td>
	 * <td><code>he_talked_with_more_claret_than_clarity.</code></td> </tr> <tr> <td>to </td>
	 * <td><code>He_Talked_With_More_Claret_Than_Clarity.</code></td> <tr> </table> <br/>
	 * 
	 * @param str
	 * the String to capitalise
	 * @param delimiter
	 * the delimiter to capitalise after
	 * @param includeFirstChar
	 * set the first char to upper case
	 * @return
	 */
	public static String capitalise(String str, String delimiter, boolean includeFirstChar)
	{
		String returnStr = null;

		if (str != null)
		{
			StringBuffer buf = new StringBuffer(str.toLowerCase());
			int strLength = buf.length();
			int index = -1;

			if (strLength > 0)
			{
				// Loop around and replace the lowercase values with upper case
				do
				{
					if (includeFirstChar || index > -1)
					{
						String upperstr = buf.substring(index + 1, index + 2).toUpperCase();
						buf.replace(index + 1, index + 2, upperstr);
					}

					int newIndex = buf.indexOf(delimiter, index + 1);
					// if (newIndex > -1) {
					// buf.replace(index + 2, newIndex, buf.substring(index + 2,
					// newIndex).toLowerCase());
					// }
					// else {
					// String lowerstr = buf.substring(index + 2).toLowerCase();
					// buf.replace(index + 2, index + 2 + lowerstr.length(), lowerstr);
					// }

					index = newIndex;
				}

				while (index > 0 && ((index + 1) < strLength));
			}

			returnStr = buf.toString();
		}

		return returnStr;
	}

	/**
	 * Remove spaces from a string.
	 */
	public static String scrunch(String s)
	{
		if (s != null && s.trim().length() > 0)
		{
			StringBuffer sb = new StringBuffer();

			for (StringTokenizer tok = new StringTokenizer(s, " "); tok.hasMoreTokens();)
			{
				sb.append(tok.nextToken());
			}

			return sb.toString();
		}
		else
		{
			return null;
		}
	}

	/**
	 * Truncates the supplied string at a certain width <br> The length of the Truncation Indicator
	 * is used in the final calculation of where to truncate the string
	 * 
	 * @param str
	 * the String to short (if too long)
	 * @param truncateAt
	 * Where to truncate the string
	 * @param truncIndicator
	 * prepending string to indicate that the String was truncated
	 * @return the Truncated string (if appropriate)
	 */
	public static String truncate(String sIn, int truncateAt, String truncIndicator)
	{
		String str = sIn;

		if (str.length() > truncateAt)
		{
			String ind = (truncIndicator != null ? truncIndicator : "");

			int truncateTo = truncateAt - ind.length();

			if (truncateTo > 0)
			{
				str = str.substring(0, truncateTo);
				str = str + ind;
			}
			else
			{
				// Do your best
				str = ind.substring(0, truncateAt);
			}
		}

		return str;
	}

	/**
	 * Truncates the supplied string at a certain width
	 * 
	 * @param str
	 * the String to short (if too long)
	 * @param truncateAt
	 * Where to truncate the string
	 * @return the Truncated String
	 */
	public static String truncate(String str, int truncateAt)
	{
		return truncate(str, truncateAt, null);
	}

	/**
	 * Returns the contents of a file on the VM classpath.
	 * 
	 * @param fileName
	 * - name of file to return
	 * @return contents of file
	 * @throws IOException
	 * - if the file is not found or is empty
	 */
	public static InputStream getInputStreamFromClasspath(String fileName) throws IOException
	{
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);

		if (is == null)
		{
			throw new FileNotFoundException("Cannot find file: " + fileName);
		}

		return is;
	}

	/**
	 * Returns a stack trace of the provided throwable, if the throwable is null, returns an empty
	 * string.
	 * 
	 * @param t
	 * - throwable to get the stack trace
	 * @return String - stacktrace
	 */
	public static String getStackTrace(Throwable t)
	{
		if (t == null)
		{
			return "";
		}

		StringWriter stringWriter = new StringWriter();
		PrintWriter writer = new PrintWriter(stringWriter);
		t.printStackTrace(writer);

		StringBuffer out = new StringBuffer();

		out.append("Exception class: " + t.getClass().getName());
		out.append(System.getProperty("line.separator"));
		out.append(t.getMessage());
		out.append(System.getProperty("line.separator"));
		out.append(stringWriter.toString());

		if (t.getCause() != null)
		{
			Throwable child = t.getCause();
			out.append(System.getProperty("line.separator"));
			out.append("Cause stack trace following:");
			out.append(getStackTrace(child));
		}

		return out.toString();
	}

	/**
	 * @param input
	 * @param regex
	 * @param replacementValue
	 * @return - input string with regex replaced by replacementValue
	 * @throws PatternSyntaxException
	 */
	public static String replaceRegex(String input, String regex, String replacementValue) throws PatternSyntaxException
	{
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(input);
		input = m.replaceAll(replacementValue);
		return input;
	}

}
