package org.bala.java.adapter;

import java.io.IOException;

import javax.jms.JMSException;

import org.apache.log4j.Logger;
import org.bala.java.adapter.exceptions.MessagingException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class IBMWebSphereMQAdapterMain {

	public static String APPLICATION_CONTEXT_CONFIG_LOCATION = "classpath:/spring/regrepMqAdapterContext.xml";
	private static final Logger logger = Logger.getLogger(IBMWebSphereMQAdapterMain.class);
	
	
	public static void main(String[] args) throws IOException, MessagingException, JMSException	
	{
		logger.info("IBMWebSphereMQAdapterMain application starting...");
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(APPLICATION_CONTEXT_CONFIG_LOCATION);
		applicationContext.start();
		applicationContext.registerShutdownHook();
		logger.info("IBMWebSphereMQAdapterMain application started successfully");
	}
}
