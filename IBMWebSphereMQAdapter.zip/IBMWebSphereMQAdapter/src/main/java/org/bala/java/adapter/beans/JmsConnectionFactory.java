package org.bala.java.adapter.beans;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertStore;
import java.security.cert.CertStoreParameters;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CollectionCertStoreParameters;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;



import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.FactoryBean;

import com.ibm.mq.jms.JMSC;
import com.ibm.mq.jms.MQQueueConnectionFactory;

/**
 * Creates the appropriate Connection Factory for the MQ implementation required. This can be
 * configured using Spring so that you can test against an ActiveMQ connection locally and then
 * deploy against a Websphere MQ remotely. <br/><b>N.B. Current TrustStore and Keystore must be the
 * same</b>
 * 
 * @author u363026
 */
@SuppressWarnings(
{ "rawtypes", "deprecation" })
public class JmsConnectionFactory implements FactoryBean
{
	/***
	 * Configuration Section of the JmsConnectionFactoryFactory <br/> Currently works with ActiveMQ
	 * (Non-SSL only) and Websphere MQ 53 (non-SSL and SSL).
	 ***/
	public static class JmsConnectionFactoryConfig
	{
		private String m_channel;
		private String m_communicationType;
		private String m_host;
		private SupportedJmsImplementations m_jmsImplementation;
		private String m_keyStoreJKSFilePath;
		private String m_keystorePassword;
		private String m_port;
		private String m_queueManager;
		private String m_sslCipherSuite;
		private String m_sslPeerName;
		private boolean m_traceConnection;

		/**
		 * <i>Websphere Only</i>
		 * 
		 * @return
		 */
		String getChannel()
		{
			return m_channel;
		}

		/**
		 * <i>ActiveMQ Only</i>
		 * 
		 * @return
		 */
		String getCommunicationType()
		{
			return m_communicationType;
		}

		/**
		 * Returns the Host that the MQServer (activeMQ and WebsphereMQ is installed on)
		 * 
		 * @return
		 */
		String getHost()
		{
			return m_host;
		}

		/**
		 * Returns Which implementation to initiate the Factory for
		 * 
		 * @return
		 */
		SupportedJmsImplementations getJmsImplementation()
		{
			return m_jmsImplementation;
		}

		/**
		 * <i>Websphere SSL Only</i>
		 * 
		 * @return the location of the Keystore (and TrustStore)
		 */
		// TODO Separate the configuration of the KeyStore and Truststore
		String getKeyStoreJKSFilePath()
		{
			return m_keyStoreJKSFilePath;
		}

		/**
		 * <i>Websphere SSL Only</i>
		 * 
		 * @return the password for the KeyStore
		 */
		String getKeystorePassword()
		{
			return m_keystorePassword;
		}

		/**
		 * @return the port the MQ Server is listening on
		 */
		String getPort()
		{
			return m_port;
		}

		/**
		 * <i>Websphere Only</i>
		 * 
		 * @return
		 */
		String getQueueManager()
		{
			return m_queueManager;
		}

		/**
		 * <i>Websphere SSL Only</i>
		 * 
		 * @return
		 */
		String getSslCipherSuite()
		{
			return m_sslCipherSuite;
		}

		/**
		 * <i>Websphere SSL Only</i>
		 * 
		 * @return the Peer Nae
		 */
		String getSslPeerName()
		{
			return m_sslPeerName;
		}

		/**
		 * <i>Websphere Only</i>
		 * 
		 * @return whether to enable Tracing
		 */
		public boolean isTraceConnection()
		{
			return m_traceConnection;
		}

		/**
		 * <i>Websphere Only</i>
		 * 
		 * @param channel
		 * the MQChannel
		 */
		public void setChannel(String channel)
		{
			if (isValidString(channel))
			{
				m_channel = channel;
			}
		}

		public void setCommunicationType(String communicationType)
		{
			if (isValidString(communicationType))
			{
				m_communicationType = communicationType;
			}
		}

		/**
		 * The host where MQ is installed <i>Websphere and ActiveMQ</i>
		 * 
		 * @param hostName
		 */
		public void setHost(String hostName)
		{
			if (isValidString(hostName))
			{
				m_host = hostName;
			}
		}

		public void setJmsImplementation(String jmsImplementation)
		{
			if (isValidString(jmsImplementation))
			{
				m_jmsImplementation = SupportedJmsImplementations.valueOf(jmsImplementation.trim());
			}

			if (m_jmsImplementation == null)
			{
				String validValues = StringUtil.arrayToString(SupportedJmsImplementations.values());
				String message = "JmsImplementation Type [" + jmsImplementation + "] is not Supported. supported types are " + validValues;

				LOG.error("setJmsImplementation() :" + message);
				throw new IllegalArgumentException(message);
			}
		}

		void setJmsImplementation(SupportedJmsImplementations jmsImplementation)
		{
			m_jmsImplementation = jmsImplementation;
		}

		public void setKeyStoreJKSFilePath(String keyStoreJKSFilePath)
		{
			m_keyStoreJKSFilePath = keyStoreJKSFilePath;
		}

		/**
		 * SSL is currently on available to
		 * 
		 * @param keystorePassword
		 */
		public void setKeystorePassword(String keystorePassword)
		{
			m_keystorePassword = keystorePassword;
		}

		/**
		 * ActiveMq and Websphere Configuration
		 * 
		 * @param port
		 */
		public void setPort(String port)
		{
			m_port = port;
		}

		/**
		 * WebSphere Config Only
		 * 
		 * @param queueManager
		 */
		public void setQueueManager(String queueManager)
		{
			if (isValidString(queueManager))
			{
				m_queueManager = queueManager;
			}
		}

		public void setSslCipherSuite(String sslCipherSuite)
		{
			m_sslCipherSuite = sslCipherSuite;
		}

		/**
		 * @param sslPeerName
		 */
		public void setSslPeerName(String sslPeerName)
		{
			m_sslPeerName = sslPeerName;
		}

		public void setTraceConnection(boolean traceConnection)
		{
			m_traceConnection = traceConnection;
		}

	}

	/**
	 * Enumeration declaring which MQ and versions are currently supported
	 */
	public static enum SupportedJmsImplementations
	{
		ActiveMQ, WebsphereMQ, WebsphereMQ53SSL
	}

	private static final Logger LOG = Logger.getLogger(JmsConnectionFactory.class);

	private JmsConnectionFactoryConfig m_config;

	private static boolean isValidString(String testString)
	{
		return !StringUtils.isEmpty(testString);
	}

	/**
	 * Once the store has been populated we need to extract the Certificates and populate a
	 * CertStore that the connection factory will accept. Strangely enough the Connection Factory
	 * only accepts a Collection<CertStore>
	 * 
	 * @param store
	 * @return
	 * @throws KeyStoreException
	 * @throws InvalidAlgorithmParameterException
	 * @throws NoSuchAlgorithmException
	 */
	private Collection<CertStore> buildCertStoreCollection(KeyStore store) throws KeyStoreException, InvalidAlgorithmParameterException, NoSuchAlgorithmException
	{
		Collection<Certificate> certs = new ArrayList<Certificate>();
		Enumeration<String> aliases = store.aliases();

		while (aliases.hasMoreElements())
		{
			Certificate certificate = store.getCertificate(aliases.nextElement());
			certs.add(certificate);
		}

		CertStoreParameters certStoreParam = new CollectionCertStoreParameters(certs);
		CertStore certStore = CertStore.getInstance("Collection", certStoreParam);

		LOG.warn("buildCertStoreCollection() :Properties" + System.getProperties());

		Collection<CertStore> certStoreCollection = new ArrayList<CertStore>();

		certStoreCollection.add(certStore);

		return certStoreCollection;
	}

	private Object buildWebsphere53ConnectionFactory() throws JMSException
	{
		MQQueueConnectionFactory connectionFactory = new MQQueueConnectionFactory();

		configureVanillaWebsphereFactory(connectionFactory);

		LOG.info("buildWebsphere53ConnectionFactory() : Using WebSphereMQ53 Broker on " + m_config.getHost() + ":" + m_config.getPort());

		return connectionFactory;
	}

	private Object buildWebsphere53SSLConnectionFactory() throws JMSException, IOException, GeneralSecurityException
	{
		MQQueueConnectionFactory connectionFactory = new MQQueueConnectionFactory();

		configureSSLWebsphereFactory(connectionFactory);

		LOG.info("buildWebsphere53SSLConnectionFactory() : Using WebSphereMQ53 Broker on  " + m_config.getHost() + ":" + m_config.getPort());

		return connectionFactory;

	}

	/**
	 * Configure the SSL connection details using a single store of keys (KeyStore).
	 * 
	 * @param connectionFactory
	 * @throws JMSException
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	private void configureSSLWebsphereFactory(MQQueueConnectionFactory connectionFactory) throws JMSException, IOException, GeneralSecurityException
	{
		configureVanillaWebsphereFactory(connectionFactory);

		if (isValidString(m_config.getSslCipherSuite()))
		{
			connectionFactory.setSSLCipherSuite(m_config.getSslCipherSuite());
		}

		if (isValidString(m_config.getSslPeerName()))
		{
			connectionFactory.setSSLPeerName(m_config.getSslPeerName());
		}

		String keyStoreJKSFilePath = m_config.getKeyStoreJKSFilePath();

		if (isValidString(m_config.getKeystorePassword()) && isValidString(keyStoreJKSFilePath))
		{
			char[] password = m_config.getKeystorePassword().toCharArray();

			/***
			 * For an SSL connection we need to load the keys manually from the keystore and supply
			 * them to the MQConnectionFactory
			 ***/
			KeyStore store = loadKeyStore(keyStoreJKSFilePath, password);

			Collection<CertStore> certStoreCollection = buildCertStoreCollection(store);

			connectionFactory.setSSLCertStores(certStoreCollection);

			/*** set the SSLSocketFactory ***/
			LOG.info("configureSSLWebsphereFactory() setting SSL Socket Factory");
			connectionFactory.setSSLSocketFactory(getSSLSocketFactory());
		}
	}

	private void configureVanillaWebsphereFactory(MQQueueConnectionFactory connectionFactory) throws JMSException
	{
		LOG.info("configureVanillaWebsphereFactory");

		connectionFactory.setTransportType(JMSC.MQJMS_TP_CLIENT_MQ_TCPIP);

		if (isValidString(m_config.getPort()))
		{
			connectionFactory.setPort(Integer.parseInt(m_config.getPort()));
		}

		if (isValidString(m_config.getChannel()))
		{
			connectionFactory.setChannel(m_config.getChannel());
		}

		if (isValidString(m_config.getQueueManager()))
		{
			connectionFactory.setQueueManager(m_config.getQueueManager());
		}

		if (isValidString(m_config.getHost()))
		{
			connectionFactory.setHostName(m_config.getHost());
		}

		if (m_config.isTraceConnection())
		{
			if (StringUtils.isNotEmpty(System.getProperty("MQJMS_TRACE_LEVEL")))
			{
				LOG.warn("configureSSLWebsphereFactory() : not setting Trace Level, system property setting already set");
			}
			else
			{
				LOG.info("configureSSLWebsphereFactory() : setting JMS MW trace level to base in system property");
				System.setProperty("MQJMS_TRACE_LEVEL", "base");
			}
		}

		connectionFactory.setUseConnectionPooling(true);

	}

	public JmsConnectionFactoryConfig getConfig()
	{
		return m_config;
	}

	private KeyManager[] getKeyManagers() throws IOException, GeneralSecurityException
	{
		/*** First, get the default KeyManagerFactory. ***/
		String defaultAlgorithm = KeyManagerFactory.getDefaultAlgorithm();
		KeyManagerFactory kmFact = KeyManagerFactory.getInstance(defaultAlgorithm);

		/*** Next, set up the KeyStore to use. We need to load the file into a KeyStore instance. ***/
		FileInputStream fileInputStream = new FileInputStream(m_config.getKeyStoreJKSFilePath());
		KeyStore keyStore = KeyStore.getInstance("jks");

		keyStore.load(fileInputStream, m_config.getKeystorePassword().toCharArray());

		fileInputStream.close();

		/*** Now we initialize the TrustManagerFactory with this KeyStore ***/
		kmFact.init(keyStore, m_config.getKeystorePassword().toCharArray());

		/*** And now get the TrustManagers ***/
		KeyManager[] kms = kmFact.getKeyManagers();

		return kms;
	}

	public Object getObject() throws Exception
	{
		switch (m_config.getJmsImplementation())
		{
			case WebsphereMQ:
				return buildWebsphere53ConnectionFactory();
			case WebsphereMQ53SSL:
				return buildWebsphere53SSLConnectionFactory();
			default:
				LOG.error("getObject() : JmsImplementation Type is not Supported supported types are " + StringUtil.arrayToString(SupportedJmsImplementations.values()));
				break;
		}

		return null;
	}

	public Class getObjectType()
	{
		return ConnectionFactory.class;
	}

	protected SSLSocketFactory getSSLSocketFactory() throws IOException, GeneralSecurityException
	{
		/*** Call getTrustManagers to get suitable trust managers ***/
		TrustManager[] tms = getTrustManagers();

		/*** Call getKeyManagers (from CustomKeyStoreClient) to get suitable key managers ***/
		KeyManager[] kms = getKeyManagers();

		/***
		 * Next construct and initialize a SSLContext with the KeyStore and the TrustStore. We use
		 * the default SecureRandom.
		 ***/
		SSLContext context = SSLContext.getInstance("SSL");
		context.init(kms, tms, null);

		/*** Finally, we get a SocketFactory, and pass it to SimpleSSLClient. ***/
		SSLSocketFactory ssf = context.getSocketFactory();

		return ssf;
	}

	/**
	 * Load the Trust Store (it is expected that the TrustStore is identical to the KeyStore)
	 * 
	 * @return
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	private TrustManager[] getTrustManagers() throws IOException, GeneralSecurityException
	{
		// TODO separate the KeyStore and TrustStore locations so that they can be configured
		// separately
		/*** First, get the default TrustManagerFactory. ***/
		String defaultAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
		TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(defaultAlgorithm);

		/*** Next, set up the TrustStore to use. We need to load the file into a KeyStore instance. ***/
		FileInputStream fis = new FileInputStream(m_config.getKeyStoreJKSFilePath());
		KeyStore ks = KeyStore.getInstance("jks");

		ks.load(fis, m_config.getKeystorePassword().toCharArray());

		fis.close();

		/*** Now we initialize the TrustManagerFactory with this KeyStore ***/
		trustManagerFactory.init(ks);

		/*** And now get the TrustManagers ***/
		TrustManager[] tms = trustManagerFactory.getTrustManagers();

		return tms;
	}

	/**
	 * @see org.springframework.beans.factory.FactoryBean#isSingleton()
	 */
	public boolean isSingleton()
	{
		return true;
	}

	/**
	 * Load the Key store where both Trusted and Client keys are stored see
	 * http://www.ibm.com/developerworks/websphere/techjournal/0502_benantar/0502_benantar.html
	 * 
	 * @param keyStoreJKSFilePath
	 * @param password
	 * @throws KeyStoreException
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 */
	private KeyStore loadKeyStore(String keyStoreJKSFilePath, char[] password) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException
	{
		KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());

		/*** get user password and file input stream ***/
		java.io.FileInputStream fis = new java.io.FileInputStream(keyStoreJKSFilePath);

		try
		{
			ks.load(fis, password);
		}
		finally
		{
			fis.close();
		}

		return ks;
	}

	public void setConfig(JmsConnectionFactoryConfig config)
	{
		m_config = config;
	}

}
