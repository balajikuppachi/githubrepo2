package com.wellsfargo.regulatory.eod.writers;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;



@Component
public class FileStaticContent {

	
	private String DATATRAK_HEADER;
	private String APPLICATION_HEADER;
	private String APPLICATION_TRAILER;
	private String DATATRAK_TRAILER;

	public String getDATATRAK_HEADER(String assetClass) throws ParseException {
		StringBuffer sb = new StringBuffer();
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST1);
		
		sb.append(getSysId(assetClass));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST2);
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST3);
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST4);
		//sb.append(ORIGINATOR);
		sb.append(getOriginator(assetClass));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_CONST5);
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_SUBORIGINATOR);
		sb.append(DateFormatUtils.formatUTC(new Date(), Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_HEADER_SUBMISSION_DATE));
		//TODO- change this FILE DESCRIPTION
		sb.append("THISLENGTHSHOULDBEOFLEN25");
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_MULTIBATCHINDICATOR);
		sb.append("  ");
		sb.append(String.format(Constants.TRIOPTIMA_REPORT_CONTENT_FUTUREUSE1SPACE,Constants.EMPTY_STRING));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_VARLENINDICATOR);
		sb.append(String.format(Constants.TRIOPTIMA_REPORT_CONTENT_FUTUREUSE15SPACE,Constants.EMPTY_STRING));
		DATATRAK_HEADER = sb.toString();
		return DATATRAK_HEADER;
	}
	
	public String getDOCUMENT_APPLICATION_HEADER(String clientIdentifier,String assetClass) throws ParseException{
		StringBuffer sb = new StringBuffer();
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST1);
		sb.append(getOriginator(assetClass));
		sb.append(DateFormatUtils.formatUTC(new Date(), Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_SUBMISSION_DATE));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST2);
		sb.append(String.format("%40s", clientIdentifier));
		APPLICATION_HEADER = sb.toString();
		return APPLICATION_HEADER;
	}
	
	public String getAPPLICATION_HEADER(String clientIdentifier,String assetClass) throws ParseException{
		StringBuffer sb = new StringBuffer();
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST1);
		//sb.append(ORIGINATOR);
		sb.append(getOriginator(assetClass));
		sb.append(DateFormatUtils.formatUTC(new Date(), Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_SUBMISSION_DATE));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST2);
		sb.append(String.format("%30s", clientIdentifier));
		APPLICATION_HEADER = sb.toString();
		return APPLICATION_HEADER;
	}
	public String getAPPLICATION_TRAILER(String assetClass){
		StringBuffer sb = new StringBuffer();
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST1);		
		sb.append(getOriginator(assetClass));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_TRAILER_CONST2);
		APPLICATION_TRAILER = sb.toString();
		return APPLICATION_TRAILER;
	}
	public String getDATATRAK_TRAILER(int count, String assetClass){
		StringBuffer sb = new StringBuffer();
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST1);
		sb.append(getSysId(assetClass));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST2);
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST3);
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST4);
		//sb.append(ORIGINATOR);
		sb.append(getOriginator(assetClass));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_DATARAK_TRAILER_CONST5);
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_SUBORIGINATOR);
		sb.append(String.format("%07d",count));
		sb.append(String.format(Constants.TRIOPTIMA_REPORT_CONTENT_FUTUREUSE47SPACE,Constants.EMPTY_STRING));
		DATATRAK_TRAILER = sb.toString();
		return DATATRAK_TRAILER;
	}
	public String getCOLL_APPLICATION_TRAILER(int count, String assetClass){
		StringBuffer sb = new StringBuffer();
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_HEADER_CONST1);		
		sb.append(getOriginator(assetClass));
		sb.append(Constants.TRIOPTIMA_REPORT_CONTENT_APP_TRAILER_CONST2);
		sb.append(String.format("%08d",count));
		APPLICATION_TRAILER = sb.toString();
		return APPLICATION_TRAILER;
	}
	
	private String getOriginator(String assetClass){
		if(Constants.ASSET_CLASS_CREDIT.equals(assetClass))
			return String.format("%4s", Constants.TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_CREDIT);
		if(Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
			return String.format("%4s", Constants.TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_INTERESTRATE);
		if(Constants.ASSET_CLASS_EQUITY.equals(assetClass))
			return String.format("%4s", Constants.TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_EQUITY);
		if(Constants.ASSET_CLASS_FOREX.equals(assetClass))
			return String.format("%4s",Constants.TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_FOREX);
		if(Constants.ASSET_CLASS_COLLATERAL.equals(assetClass))
			return String.format("%4s", Constants.TRIOPTIMA_REPORT_CONTENT_ORIGINATOR_COLLATERAL);
		
		return String.format("%4s", Constants.EMPTY_STRING);
	}
	
	private String getSysId(String assetClass){
		if(Constants.ASSET_CLASS_CREDIT.equals(assetClass))
			return String.format("%5s", Constants.TRIOPTIMA_REPORT_CONTENT_SYSID_CREDIT);
		if(Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
			return String.format("%5s", Constants.TRIOPTIMA_REPORT_CONTENT_SYSID_IR);
		if(Constants.ASSET_CLASS_EQUITY.equals(assetClass))
			return String.format("%5s", Constants.TRIOPTIMA_REPORT_CONTENT_SYSID_EQUITY);
		if(Constants.ASSET_CLASS_FOREX.equals(assetClass))
			return String.format("%5s", Constants.TRIOPTIMA_REPORT_CONTENT_SYSID_FOREIGNEXCHANGE);
		if(Constants.ASSET_CLASS_COMMODITY.equals(assetClass))
			return String.format("%5s", Constants.TRIOPTIMA_REPORT_CONTENT_SYSID_COMMODITY);
		if(Constants.ASSET_CLASS_COLLATERAL.equals(assetClass))
			return String.format("%5s", Constants.TRIOPTIMA_REPORT_CONTENT_SYSID_COLLATERAL);
		
		return String.format("%5s", Constants.EMPTY_STRING);
	}
}
