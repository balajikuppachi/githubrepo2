package com.wellsfargo.regulatory.eod.exception;

import static com.wellsfargo.regulatory.commons.keywords.Constants.EXCEPTION_OPEN_STATUS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.persister.util.dataSource.ConnectionManager;

@Component
public class EodExceptionLogger {
	
	@Autowired
	private ConnectionManager manager;
	
	public void logEodExceptions(Message<MessageHandlingException> message) throws Exception{
		
		Long 					submissionId 	= null;
		String					code		 	= null;
		String					desc		 	= null;
		String					type		 	= null;
		String					severity	 	= null;
		String					status			= null;
		Date					insertTime		= null;
		String					query			= null;
		Connection				con				= null;
		PreparedStatement		pStmt			= null;		
		Throwable 				exceptionParent = message.getPayload();
		RegRepEodException		exception		= null;
	
		exceptionParent = message.getPayload();

		while ((null != exceptionParent) 
				&& !(exceptionParent instanceof RegRepEodException)){

			exceptionParent = exceptionParent.getCause();
		}

		if ((null != exceptionParent) 
				&& (exceptionParent instanceof RegRepEodException)){
			
			exception = (RegRepEodException)exceptionParent;
			
			code 			= exception.getExceptionCode();
			desc 			= org.apache.commons.lang.exception.ExceptionUtils.getFullStackTrace(exceptionParent);						
			type 			= exception.getExceptionType() +"";			
			severity		= exception.getExceptionSeverity() +"";
			status			= EXCEPTION_OPEN_STATUS;
			insertTime		= new Date();
			submissionId 	= Long.getLong(exception.getSdrMessageId());

		}

		query = "INSERT INTO REG_REP_EOD_EXCEPTION (SUBMISSION_ID,CODE,DESCRIPTION,TYPE,SEVERITY,STATUS,INSERT_TIMESTAMP) "
				+ "VALUES (?,?,?,?,?,?,?)";

		con  = manager.getConnection();

		pStmt = con.prepareStatement(query); 

		pStmt.setLong(1, submissionId);
		pStmt.setString(2, code);
		pStmt.setString(3, desc);
		pStmt.setString(4, type);
		pStmt.setString(5, severity);
		pStmt.setString(6, status);
		pStmt.setTimestamp(7, new java.sql.Timestamp(insertTime.getTime()));

		pStmt.executeQuery(query);

	}

	public void persistEodExceptions(List<RegRepEodException> data) throws Exception{

		Long 					submissionId 	= null;
		String					code		 	= null;
		String					desc		 	= null;
		String					type		 	= null;
		String					severity	 	= null;
		String					status			= null;
		Date					insertTime		= null;
		String					query			= null;
		Connection				con				= null;
		PreparedStatement		pStmt			= null;		

		query = "INSERT INTO REG_REP_EOD_EXCEPTION (SUBMISSION_ID,CODE,DESCRIPTION,TYPE,SEVERITY,STATUS,INSERT_TIMESTAMP) "
				+ "VALUES (?,?,?,?,?,?,?)";

		con  = manager.getConnection();

		pStmt = con.prepareStatement(query); 
		
		for(RegRepEodException exception : data){		

			code 			= exception.getExceptionCode();
			desc 			= exception.getDescription();			
			type 			= exception.getExceptionType() +"";			
			severity		= exception.getExceptionSeverity() +"";
			status			= EXCEPTION_OPEN_STATUS;
			insertTime		= new Date();
			submissionId 	= Long.getLong(exception.getSdrMessageId());
			//temp fix figure out why submissionId is null
			if(null != submissionId) {			
				pStmt.setLong(1, submissionId);
				pStmt.setString(2, code);
				pStmt.setString(3, desc);
				pStmt.setString(4, type);
				pStmt.setString(5, severity);
				pStmt.setString(6, status);
				pStmt.setTimestamp(7, new java.sql.Timestamp(insertTime.getTime()));
				
				pStmt.addBatch();
			}
			
		}
		
		pStmt.executeBatch();

	}

	

}
