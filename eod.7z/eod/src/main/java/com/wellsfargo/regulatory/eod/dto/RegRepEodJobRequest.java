package com.wellsfargo.regulatory.eod.dto;

import java.io.File;

/**
 * @author Raji Komatreddy Java Object to set EodJob request
 */

public class RegRepEodJobRequest
{
	private String jobName;
	private String asOfDate;
	private String jurisdiction;
	private String reportType;
	private String assetClass;
	private File file;

	public RegRepEodJobRequest(String jobName)
	{
		this.jobName = jobName;

	}

	public RegRepEodJobRequest(String jobName, String asOfDate)
	{
		this.jobName = jobName;
		this.asOfDate = asOfDate;

	}
	
	public RegRepEodJobRequest(String jobName, String assetClass, String reportType,String sdrRepository)
	{
		this.jobName = jobName;
		this.assetClass=assetClass;
		this.reportType = reportType;
		this.jurisdiction = sdrRepository;
		

	}
	
	public RegRepEodJobRequest(File file)
	{
		this.file = file;

	}
	
	public RegRepEodJobRequest()
	{
		
	}

	public String getJobName()
	{
		return jobName;
	}

	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}

	public String getAsOfDate()
	{
		return asOfDate;
	}

	public void setAsOfDate(String asOfDate)
	{
		this.asOfDate = asOfDate;
	}


	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public File getFile()
	{
		return file;
	}

	public void setFile(File file)
	{
		this.file = file;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	
	

}
