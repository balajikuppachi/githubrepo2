package com.wellsfargo.regulatory.eod.services.parsers;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.Scanner;

import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.etd.bo.collateral.dtcc.ETDCollateralDtccTemplate;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author Raji Komatreddy
 */
@Component
public class CollateralValueDtccTemplateParser
{
	@Autowired
	@Qualifier("collateralValueDtccTemplateJaxbMarshaller")
	private Marshaller marshaller;
	
	@Autowired
	@Qualifier("collateralValueDtccTemplateJaxbMarshaller")
	private Unmarshaller unmarshaller;
	
	@Value("${regRep.response.file.path}")
	private String tempFileLoc;

	private static Logger logger = Logger.getLogger(CollateralValueDtccTemplateParser.class.getName());

	public String marshallToCollateralDtccTemplateString(ETDCollateralDtccTemplate inETDCollateralDtccTemplate) throws Exception
	{
		String response = null;
		String fileName = Constants.REG_REP_TEMP + Constants.UNDERSCORE + "RegRepCollateralValueDtccTemplate" + Constants.UNDERSCORE + (new Date()).getTime();

		File tempFile = new File(tempFileLoc + File.separator + fileName);

		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(tempFile);

			marshaller.marshal(inETDCollateralDtccTemplate, new StreamResult(fos));

			Scanner respScanner = new Scanner(tempFile);
			response = respScanner.useDelimiter("\\Z").next();
			respScanner.close();

			logger.debug("RegREpCollateralDtccTemplate string: " + response);

		}
		catch (Exception exp)
		{
			throw exp;

		}
		finally
		{
			if (fos != null)
			{
				fos.close();
			}

			tempFile.delete();
		}

		return response;
	}

}
