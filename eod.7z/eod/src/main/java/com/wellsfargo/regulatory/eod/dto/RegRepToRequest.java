/**
 * 
 */
package com.wellsfargo.regulatory.eod.dto;

/**
 * @author Pavan.Siram
 *
 */
public class RegRepToRequest {

	private String assetClass;
	private String msgType;
	private String sdrRepository;
	
	public RegRepToRequest(String assetClass, String msgType, String sdrRepository) {
		this.assetClass = assetClass;
		this.msgType = msgType;
		this.sdrRepository = sdrRepository;
	}

	public String getAssetClass() {
		return assetClass;
	}
	
	public String getMsgType() {
		return msgType;
	}

	/**
	 * @return the sdrRepository
	 */
	public String getSdrRepository() {
		return sdrRepository;
	}
}
