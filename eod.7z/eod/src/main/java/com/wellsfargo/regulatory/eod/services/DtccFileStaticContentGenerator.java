package com.wellsfargo.regulatory.eod.services;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;

@Component
public class DtccFileStaticContentGenerator
{
	@Value("${etd.dtcc.datatrak.sysid}")
	private String dataTrakSysid;
	
	@Value("${etd.dtcc.datatrak.originator.id}")
	private String dataTrakOriginator;
	
	@Value("${etd.collateral.dtcc.datatrak.sysid}")
	private String collateralDataTrakSysid;
	
	@Value("${etd.collateral.dtcc.datatrak.originator.id}")
	private String collateraldataTrakOriginator;
	
	private String DATATRAK_HEADER;
	private String APPLICATION_HEADER;
	private String APPLICATION_TRAILER;
	private String DATATRAK_TRAILER;
	
	public String getDATATRAK_HEADER(String msgType) throws ParseException {
		StringBuffer sb = new StringBuffer();
		sb.append(EtdConstants.report_content_datarak_header_const1);
		
		if(null != msgType && msgType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT))
		{
			sb.append(collateralDataTrakSysid);			
		}else
		{
			sb.append(dataTrakSysid);
		}
		
		sb.append(EtdConstants.report_content_datarak_header_const2);
		sb.append(EtdConstants.report_content_datarak_header_const3);
		sb.append(EtdConstants.report_content_datarak_header_const4);
		if(null != msgType && msgType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT))
		{
			sb.append(collateraldataTrakOriginator);
			
		}else
		{
			sb.append(dataTrakOriginator);
		}
		
		sb.append(EtdConstants.report_content_datarak_header_const5);
		sb.append(EtdConstants.report_content_datarak_header_suboriginator);
		sb.append(DateFormatUtils.formatUTC(new Date(), EtdConstants.report_content_datarak_header_submission_date));		
		sb.append("THISLENGTHSHOULDBEOFLEN25");
		sb.append(EtdConstants.report_content_multibatchindicator);
		// append three spaces for multibatch number
		sb.append("   "); 
		// append one space for future use
		sb.append(" "); 
		sb.append(EtdConstants.report_content_datarak_header_variableLenthRecordIndicator);
		sb.append(String.format(EtdConstants.report_content_futureuse15space,EtdConstants.EMPTY_STRING));
		DATATRAK_HEADER = sb.toString();
		return DATATRAK_HEADER;
	}
	
	public String getAPPLICATION_HEADER(String msgType) throws ParseException{
		StringBuffer sb = new StringBuffer();
		sb.append(EtdConstants.report_content_app_header_const1);
		if(null != msgType && msgType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT))
		{
			sb.append(collateraldataTrakOriginator);
			
		}else
		{
			sb.append(dataTrakOriginator);
		}		
		sb.append(DateFormatUtils.formatUTC(new Date(), EtdConstants.report_content_app_header_submission_date));
		sb.append(EtdConstants.report_content_app_header_const2);
		sb.append(String.format("%40s", EtdConstants.report_content_app_header_clientIdentifier));
		APPLICATION_HEADER = sb.toString();
		return APPLICATION_HEADER;
	}
	
	public String getAPPLICATION_TRAILER(int count, String msgType){
		StringBuffer sb = new StringBuffer();
		sb.append(EtdConstants.report_content_app_header_const1);
		if(null != msgType && msgType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT))
		{
			sb.append(collateraldataTrakOriginator);
			
		}else
		{
			sb.append(dataTrakOriginator);
		}		
		sb.append(EtdConstants.report_content_app_trailer_const2);
		sb.append(String.format("%08d",count));
		APPLICATION_TRAILER = sb.toString();
		return APPLICATION_TRAILER;
	}
	
	public String getDATATRAK_TRAILER(int count, String msgType){
		StringBuffer sb = new StringBuffer();
		sb.append(EtdConstants.report_content_datarak_trailer_const1);
		if(null != msgType && msgType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT))
		{
			sb.append(collateralDataTrakSysid);			
		}else
		{
			sb.append(dataTrakSysid);
		}		
		sb.append(EtdConstants.report_content_datarak_trailer_const2);
		sb.append(EtdConstants.report_content_datarak_trailer_const3);
		sb.append(EtdConstants.report_content_datarak_trailer_const4);		
		if(null != msgType && msgType.equalsIgnoreCase(EtdConstants.COLLATERAL_RPT))
		{
			sb.append(collateraldataTrakOriginator);
			
		}else
		{
			sb.append(dataTrakOriginator);
		}		
		sb.append(EtdConstants.report_content_datarak_trailer_const5);
		sb.append(EtdConstants.report_content_datarak_header_suboriginator);		
		sb.append(String.format("%07d",count));
		sb.append(String.format(EtdConstants.report_content_futureuse47space,EtdConstants.EMPTY_STRING));
		DATATRAK_TRAILER = sb.toString();
		return DATATRAK_TRAILER;
	}


}
