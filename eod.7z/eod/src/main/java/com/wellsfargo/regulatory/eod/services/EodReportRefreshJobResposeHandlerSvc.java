package com.wellsfargo.regulatory.eod.services;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobExecutionDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.util.dataSource.ConnectionManager;

/**
 * @author Amit Rana
 */
@Component
public class EodReportRefreshJobResposeHandlerSvc {
	
	@Autowired
	RegRepEodJobExecutionDetailsDaoImpl regRepEodJobExecutionDetailsDaoImpl;
	
	@Autowired
	ConnectionManager connectionManager;

	private static Logger logger = Logger.getLogger(EodReportRefreshJobResposeHandlerSvc.class.getName());

	public void handleResponse(Message<?> message) throws MessagingException
	{
		logger.info("inside EodReportRefreshJobResposeHandlerSvc: handleResponse method ");
		
		String errorString = null;
		Object ipMessage = null;
		String origPayload = null;
		JobExecution currJobExecution = null;
		ExitStatus currExitStatus = null;
		String jobExecutionId = null;
		long execId = 0;
		String jobName = null;
		String asOfDate = null;

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);
		}
		ipMessage = message.getPayload();

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
			// to do prepare file using string payload
		}
		else if (ipMessage instanceof JobExecution)
		{
			currJobExecution = (JobExecution) ipMessage;
			currExitStatus = currJobExecution.getExitStatus();

			jobExecutionId = currJobExecution.getJobParameters().getString(Constants.EOD_JOB_EXECUTION_ID);
			jobName = currJobExecution.getJobParameters().getString(Constants.EOD_JOB_NAME);
			asOfDate = currJobExecution.getJobParameters().getString(Constants.EOD_JOB_HEADER_AS_OF_DATE);

			logger.info("job response is for : " + jobName + "as of Date : " + asOfDate + "job Execution ID is : " + jobExecutionId);
			if (null != jobExecutionId)
			{
				execId = Long.parseLong(jobExecutionId);

			}
			else
			{
				errorString = "jobExecution ID was null from incoming request :";
				logger.error(" jobExecution ID is null : " + currJobExecution.getStepExecutions().toString());
				throw new MessagingException("EodSnapShotJobResponseSvc:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);

			}

			if (currExitStatus.getExitCode().equalsIgnoreCase("EXECUTING"))
			{
				logger.info(" Batch job is still running ");

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("COMPLETED"))
			{
				logger.info(" Batch job completed successfully  for : " + jobName);				

				regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_SUCCESS, null, execId);
			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("FAILED"))
			{

				errorString = currJobExecution.getStepExecutions().toString();
				regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, errorString, execId);
				logger.error(" Batch job Failed " + currJobExecution.getStepExecutions().toString());
				throw new MessagingException("EodSnapShotJobResponseSvc:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);

			}

		}

		logger.info("exiting EodSnapShotJobResponseSvc: jobResponse method");

	}

}
