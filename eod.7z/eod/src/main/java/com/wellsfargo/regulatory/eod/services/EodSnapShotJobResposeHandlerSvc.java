package com.wellsfargo.regulatory.eod.services;

import static com.wellsfargo.regulatory.commons.keywords.Constants.APP_FALSE;
import static com.wellsfargo.regulatory.commons.keywords.Constants.APP_TRUE;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobExecutionDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodReportDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodReport;

/**
 * @author Raji Komatreddy
 */
@Component
public class EodSnapShotJobResposeHandlerSvc
{
	@Autowired
	RegRepEodJobExecutionDetailsDaoImpl regRepEodJobExecutionDetailsDaoImpl;
	
	@Autowired
	RegRepEodReportDaoImpl regRepEodReportDaoImpl;
	
	@Autowired
	MailSenderService mailSenderService;

	private static Logger logger = Logger.getLogger(EodSnapShotJobResposeHandlerSvc.class.getName());

	public void handleResponse(Message<?> message) throws MessagingException
	{
		logger.info("inside EodSnapShotJobResposeHandlerSvc: handleResponse method ");

		String errorString = null;
		Object ipMessage = null;
		String origPayload = null;
		JobExecution currJobExecution = null;
		ExitStatus currExitStatus = null;
		String jobExecutionId = null;
		long execId = 0;
		String jobName = null;
		Date cobDate = null;
		String jurisdiction = null;
		String reportType = null;
		String assetClass = null;
		Map<String,Object> jobInfoMap=new HashMap<String,Object>();
		List<String> missingValuations = null;
		String mqPublishIssue = null;

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);
		}
		ipMessage = message.getPayload();

		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
			// to do prepare file using string payload
		}
		else if (ipMessage instanceof JobExecution)
		{
			currJobExecution = (JobExecution) ipMessage;
			currExitStatus = currJobExecution.getExitStatus();

			jobInfoMap=(Map<String, Object>) message.getHeaders().get(Constants.EOD_JOB_INFO);
			jobExecutionId = currJobExecution.getJobParameters().getString(Constants.EOD_JOB_EXECUTION_ID);
			jobName=(String)jobInfoMap.get(Constants.EOD_JOB_NAME);
			cobDate= (Date)jobInfoMap.get(Constants.EOD_JOB_COB_DATE);
	        jurisdiction=(String)jobInfoMap.get(Constants.JURISDICTION);
	        reportType=(String)jobInfoMap.get(Constants.REPORT_TYPE);
	        assetClass=(String)jobInfoMap.get(Constants.ASSET_CLASS);
	        String jobDetails=StringUtils.join(new String[]{jobName,reportType,jurisdiction,assetClass},Constants.COLON);
	      //  missingValuations = (List<String>) currJobExecution.getExecutionContext().get(Constants.VALUATION_DATA_MISSING_LIST);
	        mqPublishIssue = (String) currJobExecution.getExecutionContext().get(Constants.MQ_PUBLISH_ISSUE);

	        
			logger.info("job response is for : " + jobName + "cobDate : " + cobDate + "job Execution ID is : " + jobExecutionId+ " reportType: " + reportType+ " jurisdiction: " + jurisdiction+ " assetClass: " + assetClass);
			if (null != jobExecutionId)
			{
				execId = Long.parseLong(jobExecutionId);

			}
			else
			{
				errorString = "jobExecution ID was null from incoming request :";
				logger.error(" jobExecution ID is null : " + currJobExecution.getStepExecutions().toString());
				throw new MessagingException("EodSnapShotJobResponseSvc:1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);

			}

			if (currExitStatus.getExitCode().equalsIgnoreCase("EXECUTING"))
			{
				logger.info(jobDetails+" Batch job is still running ");

			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("COMPLETED"))
			{
				logger.info(" Batch job completed successfully  for : " + jobDetails);

				logger.info("Deactivating Expired trades..");
				
				if (!updateCancelTrades(reportType,jurisdiction,assetClass)) logger.error("Error deactivating retracted events");
				else logger.info("Successfully deactivated retracted events");

				if (!updateLastActiveForCancelTrades(reportType,jurisdiction,assetClass)) logger.error("Error activating the last active event for cancel trades");
				else logger.info("Successfully activated the last active events for cancel trades"); 
					
				if (!updateExpiredTrades(reportType,jurisdiction,assetClass)) logger.error("Error deactivating Expired trades");
				else logger.info("Successfully deactivated expired trades");

				regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_SUCCESS, null, execId);
				
				//send email notification with missing valuation details
			/*	if(null != missingValuations && missingValuations.size() > 0)
				{
					try
					{
						logger.info("sending mail with missing valuation: for asset class " + assetClass + "jurisdiction : " + jurisdiction + 
								"number of trades for which val data missing : "	+ missingValuations.size());
						mailSenderService.sendMailForValDataMissing(missingValuations, reportType, assetClass, jurisdiction );
					}
					catch(Exception ex)
					{
						logger.error("Exception occurred while sending email inside EodSnapShotJobResposeHandlerSvc class " + ExceptionUtils.getFullStackTrace(ex));
					}
					
				}*/
				if(StringUtils.isNotBlank(mqPublishIssue) && mqPublishIssue.equalsIgnoreCase(Constants.TRUE))
				{
					errorString = "Either all or some of the messages failed to submit to DTCC through MQ";
					regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, errorString, execId);
				}
			}
			else if (currExitStatus.getExitCode().equalsIgnoreCase("FAILED"))
			{

				errorString = currJobExecution.getStepExecutions().toString();
				regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, errorString, execId);
				logger.error(" Batch job Failed " + currJobExecution.getStepExecutions().toString());
				
				//send email notification to production support
				String sub = "Exception occurred inside regrep application , please act immediately "; 
				mailSenderService.sendRegRepAlertsMail(sub, errorString, null);
				
				throw new MessagingException("EodSnapShotJobResponseSvc:2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);

			}

		}

		logger.info("exiting EodSnapShotJobResponseSvc: jobResponse method");

	}

	private boolean updateExpiredTrades(String reportType, String jurisdiction, String assetClass)
	{

		boolean success = false;

		try
		{

			RegRepEodReport regRepEodReport=new RegRepEodReport();
			regRepEodReport.setIsActive(APP_TRUE);
			regRepEodReport.setJurisdiction(jurisdiction);
			regRepEodReport.setReportType(reportType);
			regRepEodReport.setAssetClass(assetClass);
			success=regRepEodReportDaoImpl.updateExpriredTrades(APP_FALSE, regRepEodReport);
			success = true;
		}
		catch (Exception e)
		{

			logger.error("Error updating Expired Trades ", e);
		}
		return success;
	}
	
	private boolean updateCancelTrades(String reportType, String jurisdiction, String assetClass)
	{

		boolean success = false;
		try
		{
			RegRepEodReport regRepEodReport=new RegRepEodReport();
			regRepEodReport.setActionType(Constants.Cancel);
			regRepEodReport.setIsActive(APP_TRUE);
			regRepEodReport.setJurisdiction(jurisdiction);
			regRepEodReport.setReportType(reportType);
			regRepEodReport.setAssetClass(assetClass);
			success=regRepEodReportDaoImpl.updateActiveFlagForAction(APP_FALSE, regRepEodReport);

		}
		catch (Exception e)
		{
			success=false;
			logger.error("Error updating Expired Trades ", e);
		}
		return success;
	}
	
	private boolean updateLastActiveForCancelTrades(String reportType, String jurisdiction, String assetClass)
	{

		boolean success = false;
		try
		{

			RegRepEodReport regRepEodReport=new RegRepEodReport();
			regRepEodReport.setIsActive(Constants.APP_LAST_ACTIVE_STATUS);
			regRepEodReport.setJurisdiction(jurisdiction);
			regRepEodReport.setReportType(reportType);
			regRepEodReport.setAssetClass(assetClass);
			success=regRepEodReportDaoImpl.updateLastActiveForCancel(APP_TRUE, regRepEodReport);
			
		}
		catch (Exception e)
		{
			success = false;
			logger.error("Error updating LastActiveForCancelTrades Trades ", e);
		}
		return success;
	}
}
