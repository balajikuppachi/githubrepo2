package com.wellsfargo.regulatory.eod.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobExecutionDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobExecutionDetails;

/**
 * 
 * @author Raji Komatreddy
 *
 */

@Component
public class CollateralDataExtractorService
{
	private static Logger logger = Logger.getLogger(CollateralDataExtractorService.class.getName());

	@Value("${regRep.eod.sdr.dbserver}")
	String SDR_DBSERVER;

	@Value("${regRep.eod.sdr.db}")
	String SDR_DB;

	@Value("${regRep.eod.sdr.dbuser}")
	String SDR_DBUSER;

	@Value("${regRep.eod.sdr.dbpass}")
	String SDR_DBPASS;

	@Value("${regRep.eod.algo.home.dir}")
	String ALGO_HOME_DIR;

	@Value("${regRep.eod.algo.script}")
	String ALGO_SCRIPT;

	@Autowired
	SecureDBPwdFactory dbPwdFactory;

	@Autowired
	RegRepEodJobExecutionDetailsDaoImpl regRepEodJobExecutionDetailsDaoImpl;
	
	@Autowired
	MailSenderService mailSenderService;

	public void updateDataFromALGO(Message<?> message) throws MessagingException
	{

		AbstractDriver.clearContextInformation();
		
		logger.info("Starting CollateralDataExtractorService.......");

		BufferedReader stdInput = null;
		BufferedReader stdError = null;

		String errorMsg = null;
		Object ipMessage = null;
		String errorString = null;
		RegRepEodJobDetails currRegRepEodJobDetails = null;
		String error_dtls = null;
		Date currDate = new Date();
		String decodedSdrPwd = null;

		if (null == message)
		{
			errorString = "Null incoming message RegRepEodJobDetails";
			logger.error("########## " + errorString);
			throw new MessagingException("CollateralDataExtractorService-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		if (ipMessage instanceof RegRepEodJobDetails)
		{
			currRegRepEodJobDetails = (RegRepEodJobDetails) message.getPayload();
		}
		if (null == currRegRepEodJobDetails)
		{
			errorString = "Null incoming Collateral Job Details";
			logger.error("########## " + errorString);
			throw new MessagingException("CollateralDataExtractorService-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);

		}
		RegRepEodJobExecutionDetails currRegRepEodJobExecutionDetails = new RegRepEodJobExecutionDetails();
		Map<String, Object> jobInfoMap=(Map<String, Object>) message.getHeaders().get(Constants.EOD_JOB_INFO);
		currRegRepEodJobExecutionDetails.setFileName((String)jobInfoMap.get(Constants.EOD_JOB_NAME));
		currRegRepEodJobExecutionDetails.setJobDetailsId(currRegRepEodJobDetails.getJobDetailsId());
		currRegRepEodJobExecutionDetails.setJobStatus(Constants.EOD_JOB_PROCESSING);
		currRegRepEodJobExecutionDetails.setAsOfDate(new java.sql.Date(currDate.getTime()));
		
		 
		long jobexecId = regRepEodJobExecutionDetailsDaoImpl.insertandGetId(currRegRepEodJobExecutionDetails);
		logger.info("job started with jobexecution id " + jobexecId);

		File algoFolder = new File(ALGO_HOME_DIR);
		if (!algoFolder.exists()) {
			if (!algoFolder.mkdirs()) {
				errorMsg = "Couldn't create folder - " + ALGO_HOME_DIR;
				throw new MessagingException("CollateralDataExtractorService-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorMsg);

			}
		} else if (!algoFolder.isDirectory()) {
			errorMsg = "Couldn't create folder - " + ALGO_HOME_DIR;
			throw new MessagingException("CollateralDataExtractorService-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorMsg);

		}
		
		decodedSdrPwd = dbPwdFactory.getPassword(SDR_DBPASS.trim());

		String[] command =
		{ ALGO_SCRIPT.trim(), ALGO_HOME_DIR, SDR_DBSERVER.trim(), SDR_DB.trim(), SDR_DBUSER.trim(), decodedSdrPwd.trim() };

		int intVal = -1;
		try
		{
			Process p = null;
			logger.info("===============Start Executing script================");
			p = Runtime.getRuntime().exec(command);
			logger.info("===============After Executing script================");
			stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			String line;
			logger.info("===============Loading Data From ALGO================");
			line = stdInput.readLine();
			while (line != null)
			{
				logger.info(line);
				line = stdInput.readLine();
			}

			line = stdError.readLine();
			while (line != null)
			{
				logger.info(line);
				line = stdError.readLine();
			}

			intVal = p.waitFor();
			error_dtls=line;
			try
			{
				if (stdInput != null) stdInput.close();
				if (stdError != null) stdError.close();
			}
			catch (Exception ignored)
			{
				logger.info("Ignored Standard I/O could not close:"+ ignored.getMessage(), ignored);
			}
			intVal= p.exitValue();
			
		}
		catch (Exception e)
		{
			logger.info("Execution of the script failed :"+ALGO_SCRIPT +" -> "+e.getMessage(), e);
			error_dtls = ExceptionUtils.getStackTrace(e);
			intVal=-1;
		}
		
		if(intVal!=0)
		{
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, "Failed:"+error_dtls, jobexecId);
			mailSenderService.sendRegRepAlertsMail("CRITICAL:JOB FAILED - "+currRegRepEodJobExecutionDetails.getFileName(),"JobName:"+currRegRepEodJobExecutionDetails.getFileName()+"Failed \n Collateral/Algo data Load is failed \n Exception:"+error_dtls,null);
		}
		else
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_SUCCESS, "Collateral/Algo data Load is success", jobexecId);


	}

}
