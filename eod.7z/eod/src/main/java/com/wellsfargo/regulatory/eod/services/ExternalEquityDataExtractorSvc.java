package com.wellsfargo.regulatory.eod.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepEodExtValDataCache;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobExecutionDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobExecutionDetails;



@Component
public class ExternalEquityDataExtractorSvc {

	private static Logger logger = Logger.getLogger(ExternalEquityDataExtractorSvc.class.getName());
	
	@Value("${regRep.eod.sdr.dbserver}") String SDR_DBSERVER;
	@Value("${regRep.eod.sdr.db}")	String SDR_DB;
	@Value("${regRep.eod.sdr.dbuser}")	String SDR_DBUSER;
	@Value("${regRep.eod.sdr.dbpass}")	String SDR_DBPASS;
	@Value("${regRep.eod.galaxy.equity.script}") String EQUITY_SCRIPT;
	@Value("${regRep.eod.galaxy.env}") String EQUITY_ENVI;
	@Value("${regRep.file.equityValutaion}") String eqValFolderName;
	
	@Autowired
	SecureDBPwdFactory dbPwdFactory;
	
	@Autowired
	RegRepEodJobExecutionDetailsDaoImpl regRepEodJobExecutionDetailsDaoImpl;
	
	@Autowired
	RegRepEodExtValDataCache regRepEodExtValDataCache;
	
	
	@Autowired
	MailSenderService mailSenderService;

	
	public void updateDataFromGalaxy(Message<?> message) throws MessagingException {
		
		AbstractDriver.clearContextInformation();
		
		logger.info("===============Inside ExternalEquityDataExtractorSvc ================");
	
		String errorMsg = null;
		BufferedReader stdInput = null;
		BufferedReader stdError = null;
	
		Object ipMessage = null;
		String errorString = null;
		RegRepEodJobDetails currRegRepEodJobDetails = null;
		String error_dtls = null;
		Date currDate = new Date();
		String decodedSdrPwd = null;

		if (null == message)
		{
			errorString = "Null incoming message RegRepEodJobDetails";
			logger.error("########## " + errorString);
			throw new MessagingException("ExternalEquityDataExtractorSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);
		}
		ipMessage = message.getPayload();
		if (ipMessage instanceof RegRepEodJobDetails)
		{
			currRegRepEodJobDetails = (RegRepEodJobDetails) message.getPayload();
		}
		if (null == currRegRepEodJobDetails)
		{
			errorString = "Null incoming External Galaxy price Job Details";
			logger.error("########## " + errorString);
			throw new MessagingException("ExternalEquityDataExtractorSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);

		}

		
		RegRepEodJobExecutionDetails currRegRepEodJobExecutionDetails = new RegRepEodJobExecutionDetails();
		Map<String, Object> jobInfoMap=(Map<String, Object>) message.getHeaders().get(Constants.EOD_JOB_INFO);
		currRegRepEodJobExecutionDetails.setFileName((String)jobInfoMap.get(Constants.EOD_JOB_NAME));
		currRegRepEodJobExecutionDetails.setJobDetailsId(currRegRepEodJobDetails.getJobDetailsId());
		currRegRepEodJobExecutionDetails.setJobStatus(Constants.EOD_JOB_PROCESSING);
		currRegRepEodJobExecutionDetails.setAsOfDate(new java.sql.Date(currDate.getTime()));

		long jobexecId = regRepEodJobExecutionDetailsDaoImpl.insertandGetId(currRegRepEodJobExecutionDetails);
		logger.info("ExternalEquityDataExtractorSvc job started with jobexecution id " + jobexecId);

		
		File cdboFolder = new File(eqValFolderName);
		if (!cdboFolder.exists()) {
			if (!cdboFolder.mkdirs()) {
				errorMsg = "Couldn't create folder - " + eqValFolderName;
				throw new MessagingException("ExternalEquityDataExtractorService-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorMsg);

			}
		} else if (!cdboFolder.isDirectory()) {
			errorMsg = "Couldn't create folder - " + eqValFolderName;
			throw new MessagingException("ExternalEquityDataExtractorService-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorMsg);

		}
		decodedSdrPwd = dbPwdFactory.getPassword(SDR_DBPASS.trim());
	
		String[] command = { EQUITY_SCRIPT.trim(),
				DateFormatUtils.format(CalendarUtils.yesterday(), "MM/dd/yyyy"),
				SDR_DBSERVER.trim(), SDR_DB.trim(), SDR_DBUSER.trim(), decodedSdrPwd.trim(),EQUITY_ENVI.trim() };
		
		int intVal = -1;
		
		try {
			Process p = null;			
			logger.info("===============Start Executing script================");
			p = Runtime.getRuntime().exec(command);
			logger.info("===============After Executing script================");
			stdInput = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			stdError = new BufferedReader(new InputStreamReader(
					p.getErrorStream()));
			String line;
			logger.info("===============Printing msg from Script================");
			line = stdInput.readLine();
			while (line != null) {
				logger.info(line);
				line = stdInput.readLine();
				
				//update EodExtValDataCache with latest data
				logger.info("refreshing EodExtEquityValDataCache for Equity trades");
				regRepEodExtValDataCache.loadEquityNpvDataToCache();
			}
			
			line = stdError.readLine();
			error_dtls=line;
			intVal = p.waitFor();
			try
			{
				if (stdInput != null) stdInput.close();
				if (stdError != null) stdError.close();
			}
			catch (Exception ignored)
			{
				logger.info("Ignored Standard I/O could not close:"+ ignored.getMessage(), ignored);
			}
			intVal= p.exitValue();
			
		}
		catch (Exception e)
		{
			logger.info("Execution of the script failed :"+EQUITY_SCRIPT +" -> "+e.getMessage(), e);
			error_dtls = ExceptionUtils.getStackTrace(e);
			intVal=-1;
		}
		
		if(intVal!=0)
		{
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, "Failed:"+error_dtls, jobexecId);
			mailSenderService.sendRegRepAlertsMail("CRITICAL:JOB FAILED - "+currRegRepEodJobExecutionDetails.getFileName(),"JobName:"+currRegRepEodJobExecutionDetails.getFileName()+"Failed \n Equity valuation data Load is failed \n Exception:"+error_dtls,null);
		}
		else
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_SUCCESS, "Equity valuation data Load is success", jobexecId);


	}
	
}
