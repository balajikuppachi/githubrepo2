package com.wellsfargo.regulatory.eod.collateral.batch.services;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.wellsfargo.regulatory.commons.collateral.dto.RegRepCollateralAgreements;
import com.wellsfargo.regulatory.commons.etd.bo.collateral.dtcc.ETDCollateralDtccTemplate;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.eod.services.parsers.CollateralValueDtccTemplateParser;
import com.wellsfargo.regulatory.persister.etd.dao.EtdTradeJurisdictionDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdTradeJurisdiction;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdTradeJurisdictionMapper;

public class RegRepCollateralValRptMapperProcessor implements ItemProcessor<RegRepCollateralAgreements, ETDCollateralDtccTemplate>, StepExecutionListener
{
	@Value("${regRep.eod.collateral.party1.id}")
	String party1IdCollateral;

	@Value("${regRep.eod.wfEur.lei}")
	String wfEurLEI;

	@Value("${regRep.eod.collateral.valuation.principlaIds.emir}")
	String principalIds;

	@Value("${regRep.eod.collateral.valuation.leis.emir}")
	String leis;

	@Autowired
	CollateralValueDtccTemplateParser collateralValueDtccTemplateParser;

	@Autowired
	EtdTradeJurisdictionDao etdTradeJurisdictionDao;

	String messageId = null;

	private static Logger logger = Logger.getLogger(RegRepCollateralValRptMapperProcessor.class);

	@Override
	public ETDCollateralDtccTemplate process(RegRepCollateralAgreements collAgreement) throws Exception
	{
		logger.info("inside RegRepCollateralValRptMapperProcessor: process method");

		String dataSubmitterPrefix = null;
		String dataSubmitterValue = null;
		String dtccOutMsg = null;
		String tradePartyPrefix = null;
		String tradePartyValue = null;
		String inPrincipalId = null;
		String valutionDateTime = null;
		Date reportingDate = null;
		String dateFormat = "yyyy-MM-dd";
		String formattedReportingDate = null;

		Date currDate = new Date();

		EtdTradeJurisdictionMapper etdTradeJurisdictionMapper = new EtdTradeJurisdictionMapper();

		if (StringUtils.isEmpty(party1IdCollateral))
		{
			if (null != wfEurLEI)
			{
				dataSubmitterPrefix = wfEurLEI.split(Constants.COLON)[0];
				dataSubmitterValue = wfEurLEI.split(Constants.COMMA)[0].split(Constants.COLON)[1];
			}

		}
		else
		{
			dataSubmitterPrefix = Constants.DTCC;
			if (party1IdCollateral.startsWith(Constants.DTCC))
			{
				dataSubmitterValue = party1IdCollateral.substring(4);
			}
		}

		inPrincipalId = collAgreement.getPrincipalId();
		String[] vals = principalIds.split(Constants.COMMA);

		int index = 0;
		for (String val : vals)
		{
			if (null != inPrincipalId && inPrincipalId.equalsIgnoreCase(val))
			{
				tradePartyPrefix = leis.split(Constants.COMMA)[index].split(Constants.COLON)[0];
				tradePartyValue = leis.split(Constants.COMMA)[index].split(Constants.COLON)[1];
			}
			index++;

		}

		valutionDateTime = CalendarUtils.dateToUtcFormat(currDate);

		Calendar c1 = Calendar.getInstance();
		c1.add(Calendar.DAY_OF_YEAR, -1);
		reportingDate = c1.getTime();
		SimpleDateFormat currDateFormat = new SimpleDateFormat(dateFormat);

		formattedReportingDate = currDateFormat.format(reportingDate);

		ETDCollateralDtccTemplate currTemplate = new ETDCollateralDtccTemplate();

		if (null != collAgreement)
		{
			collAgreement.setMessageId(messageId);

			currTemplate.setVersion(EtdConstants.ETD_COLLATERL_TEMPLATE_VERSION);
			currTemplate.setMsgType(EtdConstants.ETD_COLLATERL_VALUE_MSG);
			// currTemplate.setDataSubmitterMsgID(value); set after saving message to
			// REG_REP_EOD_SUBMISSION table
			currTemplate.setAction(EtdConstants.ETD_COLLATERL_VALUE_ACTION);
			currTemplate.setDataSubmitterPrefix(dataSubmitterPrefix);
			currTemplate.setDataSubmitterValue(dataSubmitterValue);
			currTemplate.setTradePartyPrefix(tradePartyPrefix);
			currTemplate.setTradePartyValue(tradePartyValue);
			currTemplate.setCollateralPortfolioCode(collAgreement.getPortfolioCode());
			currTemplate.setCollateralPortfolioIndicator(collAgreement.getCollateralPortfolio());

			currTemplate.setValueOfCollateral(collAgreement.getCaTotal());
			currTemplate.setCurrencyOfCollateral(collAgreement.getCaCcy());

			currTemplate.setCollateralValutionDate(valutionDateTime);

			currTemplate.setCollateralReportingDate(formattedReportingDate);
			currTemplate.setSendTo(EtdConstants.ETD_COLLATERL_SEND_TO);
			// currTemplate.setExecutionAgentMaskingIndicator(collAgreement.getExecutionAgentMaskInd());

			// save valuation record into Etd_tradeJurisdiction table
			if (null != collateralValueDtccTemplateParser)
			{
				dtccOutMsg = collateralValueDtccTemplateParser.marshallToCollateralDtccTemplateString(currTemplate);
			}

			EtdTradeJurisdiction currEtdTradeJurisdiction = etdTradeJurisdictionMapper.insertForRegRepCollateralMsg(collAgreement);
			currEtdTradeJurisdiction.setOutputMessage(dtccOutMsg);
			currEtdTradeJurisdiction = etdTradeJurisdictionDao.save(currEtdTradeJurisdiction);

			if (null != currEtdTradeJurisdiction) currTemplate.setDataSubmitterMsgID(Long.toString(currEtdTradeJurisdiction.getJurisdictionId()));

		}

		return currTemplate;
	}

	@Override
	public ExitStatus afterStep(StepExecution arg0)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeStep(StepExecution stepExecution)
	{
		messageId = stepExecution.getJobExecution().getJobParameters().getString(Constants.EOD_COLLATERALVALUE_MSG_ID);

	}

}
