package com.wellsfargo.regulatory.eod.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.apache.log4j.Logger;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;

/**
 * @author Raji Komatreddy
 */

@Component
public class MappingBussAccIdLeiLoaderSvc
{

	private static Logger logger = Logger.getLogger(MappingBussAccIdLeiLoaderSvc.class.getName());

	@Value("${regRep.eod.cid.dbserver}")
	String CID_DBSERVER;
	
	@Value("${regRep.eod.cid.db}")
	String CID_DB;
	
	@Value("${regRep.eod.cid.dbuser}")
	String CID_DBUSER;
	
	@Value("${regRep.eod.cid.dbpass}")
	String CID_DBPASS;

	@Value("${regRep.eod.sdr.dbserver}")
	String SDR_DBSERVER;
	
	@Value("${regRep.eod.sdr.db}")
	String SDR_DB;
	
	@Value("${regRep.eod.sdr.dbuser}")
	String SDR_DBUSER;
	
	@Value("${regRep.eod.sdr.dbpass}")
	String SDR_DBPASS;

	@Value("${regRep.eod.cid.script}")
	String CID_SCRIPT;

	@Value("${regrep.file.cidFolder}")
	String cidFolferName;

	@Autowired
	SecureDBPwdFactory dbPwdFactory;

	public void updateDataFromCID(Message<?> message) throws MessagingException
	{

		logger.info("===============Inside MappingBussAccIdLeiLoaderSvc================");

		Object ipMessage = null;
		String errorString = null;
		String jobName = null;
		RegRepEodJobDetails currRegRepEodJobDetails = null;

		BufferedReader stdInput = null;
		BufferedReader stdError = null;

		File cidFolder = new File(cidFolferName);
		if (!cidFolder.exists())
		{
			if (!cidFolder.mkdirs())
			{
				errorString = "Couldn't create folder - " + cidFolferName;
				logger.error("########## " + errorString);
				throw new MessagingException("ExternalValuationDataLoaderSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

			}
		}
		else if (!cidFolder.isDirectory())
		{
			errorString = "Output folder name doesn't point to a directory - " + cidFolferName;
			logger.error("########## " + errorString);
			throw new MessagingException("ExternalValuationDataLoaderSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
		}
		logger.info("===== Folder " + cidFolferName + " Created =====");

		CID_DBPASS = dbPwdFactory.getPassword(CID_DBPASS.trim());
		SDR_DBPASS = dbPwdFactory.getPassword(SDR_DBPASS.trim());
		String[] command =
		{ CID_SCRIPT.trim(), CID_DBSERVER.trim(), CID_DB.trim(), CID_DBUSER.trim(), CID_DBPASS.trim(), SDR_DBSERVER.trim(), SDR_DB.trim(), SDR_DBUSER.trim(), SDR_DBPASS.trim() };

		int intVal = -1;

		try
		{
			Process p = null;
			logger.info("===============Start Executing script================");
			p = Runtime.getRuntime().exec(command);
			logger.info("===============After Executing script================");
			stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			String line;
			logger.info("===============Loading Data From CID================");
			line = stdInput.readLine();
			while (line != null)
			{
				logger.info(line);
				line = stdInput.readLine();
			}

			line = stdError.readLine();
			while (line != null)
			{
				logger.info(line);
				line = stdError.readLine();
			}

			intVal = p.waitFor();
			try
			{
				if (stdInput != null) stdInput.close();
			}
			catch (Exception ignored)
			{
			}
			try
			{
				if (stdError != null) stdError.close();
			}
			catch (Exception ignored)
			{
			}

		}
		catch (Exception e)
		{
			logger.info(e.getMessage(), e);
		}

	}

}
