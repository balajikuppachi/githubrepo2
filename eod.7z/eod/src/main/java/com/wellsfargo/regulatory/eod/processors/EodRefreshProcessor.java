package com.wellsfargo.regulatory.eod.processors;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.persister.rowMapper.RegRepEodRefreshMessage;

public class EodRefreshProcessor implements ItemProcessor<RegRepEodRefreshMessage
		, RegRepEodRefreshMessage>, StepExecutionListener {
	
	private static Logger logger = Logger
			.getLogger(EodRefreshProcessor.class.getName());
	
	private static String refreshReason;
	
	public static int x;
	

	@Override
	public ExitStatus afterStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public RegRepEodRefreshMessage process(RegRepEodRefreshMessage msg) throws Exception {
		
		logger.info(" Entering Refresh processer");
		
		String outPayload 		= null;
		String stCutomBackloadTag 	= "<customBackload>";
		String edCutomBackloadTag 	= "</customBackload>"; 
		String isRefreshtag			= "<isCustomEodRefresh>true</isCustomEodRefresh>";
		String refreshReasonTag		= "<customEodRefreshReason>" + refreshReason + "</customEodRefreshReason>"; 
		String edTradeTag			= "</trade>";
		
		if(null == msg	){
			
			logger.error("Invalid incoming data "+msg);			
			return msg;
		}
		
		outPayload = msg.getPayload();
				
		if(outPayload.contains(stCutomBackloadTag))
			StringUtils.replace(outPayload, stCutomBackloadTag, stCutomBackloadTag+isRefreshtag
					+refreshReasonTag);
		else
			StringUtils.replace(outPayload, edTradeTag, stCutomBackloadTag+isRefreshtag
					+refreshReasonTag+edCutomBackloadTag+edTradeTag);
	
		msg.setPayload(outPayload);
		
		logger.debug(" Exiting Refresh processer ");
		return msg ;
	}
	
	public void setRefreshReason(String refreshReason){
		
		EodRefreshProcessor.refreshReason = refreshReason;
	}

}
