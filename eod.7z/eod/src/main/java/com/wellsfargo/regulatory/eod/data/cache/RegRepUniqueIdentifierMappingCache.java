package com.wellsfargo.regulatory.eod.data.cache;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.persister.dao.RegRepUniqueIdentifierMappingDao;
import com.wellsfargo.regulatory.persister.dto.RegRepUniqueIdentifierMapping;

@Component
public class RegRepUniqueIdentifierMappingCache 
{
    @Autowired
	RegRepUniqueIdentifierMappingDao regRepUniqueIdentifierMappingDao;
    

	@Autowired
	CacheManager tradeidUsiCacheManager;
    
	private static Log logger = LogFactory.getLog(RegRepUniqueIdentifierMappingCache.class);
	
    
    public void loadTradeUsiMapping(Date cobDate)
    {
    	logger.info("Called loadTradeUsiMapping to get the USI mapping in to cache");
    	if(!GeneralUtils.IsNull(tradeidUsiCacheManager))
    	{
    		Cache tradeUsiCache = tradeidUsiCacheManager.getCache("tradeUsiCache");
    		
    		if(!GeneralUtils.IsNull(tradeUsiCache))
    		{
    			tradeUsiCache.removeAll();
    			logger.info("getTradeUsiMapping: Load the mapping to Cache - tradeUsiCache");
	    		List<Element> tradeUsiList = new ArrayList<Element>();
	    		List<RegRepUniqueIdentifierMapping> loadAllMapping = regRepUniqueIdentifierMappingDao.loadAll();
	   			for (RegRepUniqueIdentifierMapping regRepUniqueIdentifierMapping : loadAllMapping) 
	   			{
	   				if(Constants.USI.equals(regRepUniqueIdentifierMapping.getId().getIdentifierType()) && !GeneralUtils.IsNull(regRepUniqueIdentifierMapping.getCurrentValue()))
	   				{
	   					tradeUsiList.add(new Element(regRepUniqueIdentifierMapping.getId().getTradeId(), regRepUniqueIdentifierMapping.getCurrentValue()));
	   					
	   				}
				}
	   			/**Adding COB date to the map*/
	   			tradeUsiList.add(new Element(Constants.EOD_JOB_COB_DATE, cobDate));
	   			tradeUsiCache.putAll(tradeUsiList);
    		}	
    	
    	}
    }

	/** Load the data from the cache
	 * Returns the USI for the given tradeID
	 * */
	public String getTradeUsiMapping(String tradeId, Date cobDate) 
	{
		
		logger.info("Called getTradeUsiMapping to get the USI mapping for the trade :"+tradeId);
		String retUsi=null;
		Cache tradeUsiCache = tradeidUsiCacheManager.getCache("tradeUsiCache");
		
		Element element = tradeUsiCache.get(Constants.EOD_JOB_COB_DATE);
		/**EOD_JOB_COB_DATE is cache is not equal to cobDate then refresh the cache */
		//if (GeneralUtils.IsNull(element) || !GeneralUtils.IsNull(cobDate) &&  cobDate.equals(element.getObjectValue()))
		//	loadTradeUsiMapping(cobDate);	
		
		/**EOD_JOB_COB_DATE is cache is not equal to cobDate then refresh the cache */
		if( null == element || (cobDate != null &&   !cobDate.equals(element.getObjectValue())))
			loadTradeUsiMapping(cobDate);
		
		element = tradeUsiCache.get(tradeId);
		
		if(!GeneralUtils.IsNull(element))
			retUsi= (String)element.getObjectValue();
		return retUsi;
	}
	
	/** get data from the cache
	 * Returns the USI for the given tradeID
	 * */
	public String getTradeUsiMapping(String tradeId) 
	{
		
		logger.info("Called getTradeUsiMapping to get the USI mapping for the trade :"+tradeId);
		String retUsi=null;
		Cache tradeUsiCache = tradeidUsiCacheManager.getCache("tradeUsiCache");		
		
		Element element = tradeUsiCache.get(tradeId);
		
		if(!GeneralUtils.IsNull(element))
			retUsi= (String)element.getObjectValue();
		return retUsi;
	}
	
	public  void updateTradeUsiMapping(RegRepUniqueIdentifierMapping regRepUniqueIdentifierMapping)
	{
		
		if(Constants.USI.equals(regRepUniqueIdentifierMapping.getId().getIdentifierType()) && !GeneralUtils.IsNull(regRepUniqueIdentifierMapping.getCurrentValue()))
			{
			Cache tradeUsiCache = tradeidUsiCacheManager.getCache("tradeUsiCache");
			  Element currElement = new Element(regRepUniqueIdentifierMapping.getId().getTradeId(),  regRepUniqueIdentifierMapping.getCurrentValue());
			  tradeUsiCache.put(currElement);
				
				
			}
		
	}
}
