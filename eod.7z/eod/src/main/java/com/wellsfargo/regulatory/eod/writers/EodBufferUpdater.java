package com.wellsfargo.regulatory.eod.writers;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepUniqueIdentifierMappingCache;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodExtValData;
	
/**
 * @author Shreekar
 *
 */
@Component
public class EodBufferUpdater 

{
	
	@Autowired
	private   RegRepUniqueIdentifierMappingCache regRepUniqueIdentifierMappingCache;
	
	public static final Pattern quotePattern = Pattern.compile("<quote>.*?</quote>", Pattern.DOTALL);
	public static final Pattern messageIdPattern= Pattern.compile("<messageId messageIdScheme=\"http://www.wellsfargo.com/msg_id\">.*?</messageId>", Pattern.DOTALL);
	public static final Pattern productIdPattern= Pattern.compile("<productId productIdScheme=\"http://www.dtcc.com/coding-scheme/external/GTR-Product-Id\">(.*)</productId>", Pattern.DOTALL);
	public static final Pattern notionalStepSchedulePattern= Pattern.compile("<notionalStepSchedule>.*?</notionalStepSchedule>", Pattern.DOTALL);
	public static final Pattern currencyPattern= Pattern.compile("<currency currencyScheme.+>(.*)</currency>", Pattern.DOTALL);
	public static final Pattern notionalPattern= Pattern.compile("<notional>.*?</notional>", Pattern.DOTALL);
	public static final Pattern calculationAmountPattern= Pattern.compile("<calculationAmount id=\"calculationAmount\">.*?</calculationAmount>", Pattern.DOTALL);
	
	public static final Pattern usiPrefixPattern= Pattern.compile("<issuer issuerIdScheme.+>GTRCREATE+</issuer>", Pattern.DOTALL);
	public static final Pattern usiValuePattern= Pattern.compile("<tradeId tradeIdScheme.+>GTRCREATE+</tradeId>", Pattern.DOTALL);
	
	private static Logger logger = Logger.getLogger(EodBufferUpdater.class.getName());	

	
	public  String updateWithLatestValData(RegRepEodSubmission submission, String xmlInstance,RegRepEodExtValData data, String messagType, Long submsnId, Date asofDate, Date cobDate, String[] valTimeArr) 
	{
	
	    StringBuffer modifiedXmlBuffer = new StringBuffer();
	    try 
	    {
	    	/**Update the asofdate & asoftime */
		    xmlInstance = xmlInstance.replaceFirst("<asOfDate>.*</asOfDate>",  "<asOfDate>" + CalendarUtils.parseDateToString(CalendarUtils.FORMAT_3, asofDate) + "</asOfDate>");
		    xmlInstance = xmlInstance.replaceFirst("<asOfTime>.*</asOfTime>",  "<asOfTime>" + CalendarUtils.parseDateToString(CalendarUtils.FORMAT_2, asofDate)+ "</asOfTime>");
		    
		    /**Update messageID**/
		    Matcher messId = messageIdPattern.matcher(xmlInstance);
		    if(messId.find()) 
		    {
		    	 String messIdPath = messId.group();
		    	 messIdPath = messIdPath.replaceFirst(submission.getEodReportId(), submsnId+":"+submission.getEodReportId());
		    	 messId.appendReplacement(modifiedXmlBuffer, messIdPath);
		    	 
		    }
		    
		    messId.appendTail(modifiedXmlBuffer);
		    
		    /**GTR create update**/
		    modifiedXmlBuffer = updateAffiliateUsi(modifiedXmlBuffer,submission.getTradeId(),cobDate);
		    
		    if(!GeneralUtils.IsNull(data))
		    {
		    	/**Update the nvpdata for valuation */
			    if(Constants.MESSAGE_TYPE_VALUATION.equals(messagType))
			    {
			    	modifiedXmlBuffer=updateValuationBuffer( data, modifiedXmlBuffer,valTimeArr);
			    }
			    /**Update the notional for snapshot */
			    if(Constants.MESSAGE_TYPE_SNAPSHOT.equals(messagType) && !CalendarUtils.isSameDay(submission.getEodReportTimestamp(), new Date()))
			    {
			    	modifiedXmlBuffer=updateSnapshotBuffer( data, modifiedXmlBuffer,submission);
			    }
		    }
		    
		}
	    catch (Exception e) 
	    {
	    	logger.error("Exception while updating the EOD buffer with CDBO valuation data", e);
		}
	    
	    return modifiedXmlBuffer.toString();
	}

	private StringBuffer updateAffiliateUsi(StringBuffer modifiedXmlBuffer, String tradeId, Date cobDate) 
	{
		/**Lookup DTCC USI from cache*/
		String dtccUsi=regRepUniqueIdentifierMappingCache.getTradeUsiMapping(tradeId,cobDate); 
		
		if(!GeneralUtils.IsNullOrBlank(dtccUsi))
		{
			/**Replace only if GTRCREATE*/
			boolean found=false;
			Matcher usiPrefixUpdate = usiPrefixPattern.matcher(modifiedXmlBuffer);
			if(usiPrefixUpdate.find()) 
			{	 found=true;
				 modifiedXmlBuffer=new StringBuffer();
				 String gtrCreateUsiPrefix = usiPrefixUpdate.group();
				 gtrCreateUsiPrefix = gtrCreateUsiPrefix.replaceFirst(Constants.GTRCREATE, StringUtils.substring(dtccUsi, 0, 10));
				 usiPrefixUpdate.appendReplacement(modifiedXmlBuffer, gtrCreateUsiPrefix);
			}
			if(found)
			usiPrefixUpdate.appendTail(modifiedXmlBuffer);
			
			found=false;
			Matcher usiValueUpdate = usiValuePattern.matcher(modifiedXmlBuffer);
			if(usiValueUpdate.find()) 
			{
				 found=true;
				 modifiedXmlBuffer=new StringBuffer();
				 String gtrCreateUsiValue = usiValueUpdate.group();
				 gtrCreateUsiValue = gtrCreateUsiValue.replaceFirst(Constants.GTRCREATE,  StringUtils.substring(dtccUsi,10));
				 usiValueUpdate.appendReplacement(modifiedXmlBuffer, gtrCreateUsiValue);
			}
			if(found)
			usiValueUpdate.appendTail(modifiedXmlBuffer);
		}
		return modifiedXmlBuffer;
	}

	private static StringBuffer updateSnapshotBuffer(RegRepEodExtValData data, StringBuffer xmlBuffer, RegRepEodSubmission submission) throws ParseException 
	{
	
		BigDecimal payNotionalBD = null,leg1Value=null,leg2Value=null;
		BigDecimal recvNotionalBD = null;
		BigDecimal notionalCurrentBD = null;
		String legNotionalSchedule=null,legNotional=null;
		Matcher notionalStepSchedulePath=null,notionalPath=null;
		String upi=null;
		StringBuffer buffer=xmlBuffer; 
		Matcher productIDPath = productIdPattern.matcher(xmlBuffer);
		int legCnt=0;
		if(productIDPath.find())
			upi=productIDPath.group(1);
		if(Constants.ASSET_CLASS_INTEREST_RATE.equalsIgnoreCase(submission.getAssetClass()))
		{
			buffer=new StringBuffer();
			if(!GeneralUtils.IsNullOrBlank(upi) && StringUtils.contains(upi, Constants.PRODUCT_TYPE_XCCY)) 
			{
				String payCurrency = data.getPayCurrency();
				String payNotional = data.getPayNotional();
				String recvNotional = data.getRecvNotional();
				if(!GeneralUtils.IsNullOrBlank(payCurrency) && !payCurrency.equals("0.0")) {
					
					payNotionalBD = ConversionUtils.parseBigDecimal(payNotional).abs();
					recvNotionalBD = ConversionUtils.parseBigDecimal(recvNotional).abs();							
					
					notionalStepSchedulePath =notionalStepSchedulePattern.matcher(xmlBuffer);
					
					while(notionalStepSchedulePath.find())
					{
						String legCurrency=null;
						legNotionalSchedule=notionalStepSchedulePath.group();
						Matcher legCurrencyPath =currencyPattern.matcher(legNotionalSchedule);
						if(legCurrencyPath.find())
							legCurrency=legCurrencyPath.group(1);
						
						if(payCurrency.equalsIgnoreCase(legCurrency) && legCnt==0) 
						{
							if(!GeneralUtils.IsNullOrBlank(payNotional))
								leg1Value=payNotionalBD;
							if(!GeneralUtils.IsNullOrBlank(recvNotional))
								leg2Value=recvNotionalBD;
						}
						if(payCurrency.equalsIgnoreCase(legCurrency) && legCnt==1) 
						{
							if(!GeneralUtils.IsNullOrBlank(recvNotional))
								leg1Value=recvNotionalBD;
							if(!GeneralUtils.IsNullOrBlank(payNotional))
								leg2Value=payNotionalBD;
						}
						legCnt++;
					}
					 notionalStepSchedulePath =notionalStepSchedulePattern.matcher(xmlBuffer);
					 legCnt=0;
					 while(notionalStepSchedulePath.find())
					 {
						 
						 legNotionalSchedule=notionalStepSchedulePath.group();
						 if(legCnt==0)
							 legNotionalSchedule=legNotionalSchedule.replaceFirst("<initialValue>.*?</initialValue>",  "<initialValue>" + ConversionUtils.formatDecimal4(leg1Value) + "</initialValue>");
						 if(legCnt==1)
							 legNotionalSchedule=legNotionalSchedule.replaceFirst("<initialValue>.*?</initialValue>",  "<initialValue>" + ConversionUtils.formatDecimal4(leg2Value) + "</initialValue>");
							notionalStepSchedulePath.appendReplacement(buffer, legNotionalSchedule);
							 legCnt++;
					 }
					 notionalStepSchedulePath.appendTail(buffer);
				}
				
			}else if(!GeneralUtils.IsNullOrBlank(data.getNotionalCurrent()) && !GeneralUtils.IsNullOrBlank(upi)) {
	
				notionalCurrentBD = ConversionUtils.parseBigDecimal(data.getNotionalCurrent()).abs();
				 
				if(StringUtils.contains(upi, Constants.PRODUCT_TYPE_EXOTIC)  || StringUtils.contains(upi, Constants.PRODUCT_TYPE_FRA)){
					
					 notionalPath =notionalPattern.matcher(xmlBuffer);
					 while(notionalPath.find())
					 {
						 String legCurrency=null;
						 legNotional=notionalPath.group();
						 Matcher legCurrencyPath =currencyPattern.matcher(legNotional);
						 if(legCurrencyPath.find())
							legCurrency=legCurrencyPath.group(1);
						 if(!GeneralUtils.IsNullOrBlank(legCurrency))
							 legNotional=legNotional.replaceFirst("<currency currencyScheme=\"http://www.fpml.org/ext/iso4217\">(.*)</currency>", "<currency currencyScheme=\"http://www.fpml.org/ext/iso4217\">"+ data.getNpvCurrency() +"</currency>");
						 legNotional=legNotional.replaceFirst("<amount>.*?</amount>",  "<amount>" + ConversionUtils.formatDecimal4(notionalCurrentBD) + "</amount>");
						 notionalPath.appendReplacement(buffer, legNotional);
					 }
					 notionalPath.appendTail(buffer);
				
				} else 
				{
					
					  notionalStepSchedulePath =notionalStepSchedulePattern.matcher(xmlBuffer);
				 	  while(notionalStepSchedulePath.find())
					  {
				 		 legNotionalSchedule=notionalStepSchedulePath.group();
						 legNotionalSchedule=legNotionalSchedule.replaceFirst("<initialValue>.*?</initialValue>",  "<initialValue>" + ConversionUtils.formatDecimal4(notionalCurrentBD) + "</initialValue>");
						 notionalStepSchedulePath.appendReplacement(buffer, legNotionalSchedule);
					  }
					 notionalStepSchedulePath.appendTail(buffer);
				
				}
			}
			
		}
		if(Constants.ASSET_CLASS_CREDIT.equals(submission.getAssetClass()) && !GeneralUtils.IsNullOrBlank(data.getNotionalCurrent()))
		{
			 notionalCurrentBD = ConversionUtils.parseBigDecimal(data.getNotionalCurrent()).abs();
			 boolean isFound=false;
			 buffer=new StringBuffer();
			 notionalPath =calculationAmountPattern.matcher(xmlBuffer);
			 while(notionalPath.find())
			 {
				 legNotional=notionalPath.group();
				 legNotional=legNotional.replaceFirst("<amount>.*?</amount>",  "<amount>" + ConversionUtils.formatDecimal4(notionalCurrentBD) + "</amount>");
				 notionalPath.appendReplacement(buffer, legNotional);
				 isFound=true;
			 }
			 notionalPath.appendTail(buffer);
			 
			 if(!isFound)
			 {
				 buffer=new StringBuffer();
				 notionalPath =notionalPattern.matcher(xmlBuffer);
				 while(notionalPath.find())
				 {
					 legNotional=notionalPath.group();
					 legNotional=legNotional.replaceFirst("<amount>.*?</amount>",  "<amount>" + ConversionUtils.formatDecimal4(notionalCurrentBD) + "</amount>");
					 notionalPath.appendReplacement(buffer, legNotional);
				 }
				 notionalPath.appendTail(buffer);
			 }
		}
	
		if(  GeneralUtils.IsNull(buffer) ||   GeneralUtils.IsNullOrBlank(buffer.toString()))
			buffer=xmlBuffer;
		return buffer;	
		
	}

	private static StringBuffer updateValuationBuffer(RegRepEodExtValData data, StringBuffer xmlBuffer,String[] valTimeArr) 
	{
		StringBuffer buffer =new StringBuffer();
		Matcher quote = quotePattern.matcher(xmlBuffer);
		if(quote.find()) 
		{
		    	String quotePath = quote.group();
				quotePath = quotePath.replaceFirst("<value>.*</value>", "<value>" + ConversionUtils.formatDecimal4(data.getNpvValue()) + "</value>");
				quotePath = quotePath.replaceFirst("<currency>.*</currency>", "<currency>" + data.getNpvCurrency() + "</currency>");
				
				Date npvDate=GeneralUtils.IsNull(data.getNpvDate())?CalendarUtils.yesterday():data.getNpvDate();
			
				Calendar cal=Calendar.getInstance();
				cal.setTime(npvDate);
				
				if(!GeneralUtils.IsNull(valTimeArr) && valTimeArr.length>0 && cal.get(Calendar.HOUR_OF_DAY)==0 && cal.get(Calendar.MINUTE)==0)
				{
					cal.set(Calendar.HOUR,Integer.valueOf(valTimeArr[0]));
					cal.set(Calendar.MINUTE,Integer.valueOf(valTimeArr[1]));
					cal.set(Calendar.SECOND,Integer.valueOf(valTimeArr[2]));
				}
				
				if(!quotePath.contains("<time>"))
				quotePath = quotePath.replaceFirst("</currency>", "</currency>\n<time>" + CalendarUtils.parseDateToString(CalendarUtils.FORMAT_1, cal.getTime())+ "</time>");
				else
					quotePath = quotePath.replaceFirst("<time>.*</time>", "<time>" + CalendarUtils.parseDateToString(CalendarUtils.FORMAT_1, cal.getTime())+ "</time>");
					
				quote.appendReplacement(buffer, quotePath);
		}
		quote.appendTail(buffer);
		
		return buffer;
	}
}
