package com.wellsfargo.regulatory.eod.fileNDM;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author a120564
 *
 */

@Component
public class NDMFile {

	private static Logger logger = Logger.getLogger(NDMFile.class.getName());
	
	@Value("${regRep.file.TriOptima.ndm.uid}") String uid;
	@Value("${regRep.file.TriOptima.ndm.node}") String node;
	@Value("${regRep.file.TriOptima.ndm.script}") String ndmScript;
	
	public void ndmScirpt(File fileName) 
	{
		BufferedReader stdInput = null;
		BufferedReader stdError = null;
		String[] command = { ndmScript.trim(), node.trim(), uid.trim(),  fileName.getAbsolutePath()};
		int intVal = -1;
		try {
			Process p = null;			
			logger.info("===============Start Executing NDM script================");
			p = Runtime.getRuntime().exec(command);
			logger.info("===============After Executing NDM script================");
			stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			String line;
			logger.info("===============Sending File to Trioptima================");
			logger.info("===============fileName is : " + fileName + "=================");
			line = stdInput.readLine();
			while (line != null) {
				logger.info(line);
				line = stdInput.readLine();
			}
			
			line = stdError.readLine();
			while (line != null) {
				logger.info(line);
				line = stdError.readLine();
			}

			intVal = p.waitFor();
			try {
				if (stdInput != null)
					stdInput.close();
			} catch (Exception ignored) {
			}
			try {
				if (stdError != null)
					stdError.close();
			} catch (Exception ignored) {
			}

		} catch (Exception e) {
			logger.info(e.getMessage(), e);
		}

	}
	
}
