package com.wellsfargo.regulatory.eod.writers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.PublishFpML;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.FileUtils;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;

@Component
public class EodReportSubmitter extends PublishFpML
{
	private static Logger logger = Logger.getLogger(EodReportSubmitter.class.getName());

	@Value("${regRep.mq.connector}")
	private String connectorString;

	@Value("${regRep.mq.connector.end}")
	private String endConnectorString;

	@Value("${regRep.dtcc.intrates.nonpriority.queue}")
	private String ratesDestination;

	@Autowired
	EodQueueWriter eodQueueWriter;

	public void submit(Message<?> message) throws MessagingException
	{
		Object ipMessage = null;
		String errorString = null;
		String origPayload = null;
		boolean success = false;
		File srcFile = null;
		String fileName = null;

		RegRepEodSubmission regRepEodSubmission = new RegRepEodSubmission();
		List<RegRepEodSubmission> regRepEodSubmissionList = new ArrayList<RegRepEodSubmission>();

		if (null == message)
		{
			errorString = "Null incoming message ";
			logger.error("########## " + errorString);

		}

		ipMessage = message.getPayload();

		if (null == ipMessage)
		{
			errorString = "Null incoming request ";
			logger.error("########## " + errorString);

		}
		
		if (ipMessage instanceof String)
		{
			origPayload = (String) ipMessage;
			try
			{
				success = submitMessage(origPayload, connectorString + ratesDestination + endConnectorString);
				logger.info("Submitted file to DTCC queue: and status is " + success);
			}
			catch (MessagingException e)
			{
				logger.error("######### Exception occurred while submitting message to dtcc " + ExceptionUtils.getFullStackTrace(e));
				e.printStackTrace();
			}

		}

		else if (ipMessage instanceof File)
		{
			srcFile = ((File) ipMessage);
			fileName = srcFile.getName();
			
			logger.info("Submitting file to DTCC : " + fileName);

			if (null != fileName && fileName.startsWith("IR_"))
			{
				regRepEodSubmission.setAssetClass(Constants.ASSET_CLASS_INTEREST_RATE);
			}
			else if (null != fileName && fileName.startsWith("CR_"))
			{
				regRepEodSubmission.setAssetClass(Constants.ASSET_CLASS_CREDIT);
			}
			else if (null != fileName && fileName.startsWith("FX_"))
			{
				regRepEodSubmission.setAssetClass(Constants.ASSET_CLASS_FOREX);
			}
			else if (null != fileName && fileName.startsWith("EQ_"))
			{
				regRepEodSubmission.setAssetClass(Constants.ASSET_CLASS_EQUITY);
			}
			else
			{

				logger.error("########## " + "invalid asset class in file name , valid file name should start with either IR_ CR_ FX_ EQ_");
			}

			try
			{
				origPayload = org.apache.commons.io.FileUtils.readFileToString(srcFile);
				regRepEodSubmission.setSdrReport(origPayload);

				regRepEodSubmissionList.add(regRepEodSubmission);

				if (null != eodQueueWriter) 
					eodQueueWriter.publishMessages(regRepEodSubmissionList);

				// - Remove the src file
				FileUtils.deleteAFile(srcFile);
			}
			catch (IOException e)
			{
				errorString = "Failed to read the FpMl file to be submitted ";
				logger.error("########## " + errorString);

				throw new MessagingException("Reader-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, errorString, null, null);
			}
		}

	
	}

}
