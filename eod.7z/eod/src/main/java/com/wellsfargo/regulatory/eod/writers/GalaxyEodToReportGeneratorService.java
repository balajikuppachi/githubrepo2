/**
 * 
 */
package com.wellsfargo.regulatory.eod.writers;

import java.io.File;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepEodExtValDataCache;
import com.wellsfargo.regulatory.eod.dto.RegRepToRequest;
import com.wellsfargo.regulatory.eod.fileNDM.NDMFile;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodToReportDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodToReport;
import com.wellsfargo.regulatory.persister.trioptima.parser.RegRepTrioptimaParser;

import org.apache.commons.lang.time.DateFormatUtils;

/**
 * @author Pavan Siram
 *
 */
@Component
public class GalaxyEodToReportGeneratorService {
	
private static Logger logger = Logger.getLogger(GalaxyEodToReportGeneratorService.class.getName());
	
	@Autowired
	RegRepEodToReportDaoImpl regRepEodToReportDaoImpl;
	
	@Autowired
	RegRepEodExtValDataCache regRepEodExtValDataCache;
	
	@Value("${regRep.eligible.for.TriOptima.lei}")
	private String listOfEligibleLeis;
	
	@Value("${regRep.eod.equity.TriOptima.outputFolder}")
	private String outputFolderName;
	
	private File outputFolder;
	
	List<RegRepEodToReport> equityRegRepToRequestList=null;
	List<RegRepEodToReport> equityEligibleRegRepToRequestList;
	List<RegRepEodToReport> equityCdboRegRepToRequestList=null;
	
	@Autowired 
	RegRepTrioptimaParser regRepTrioptimaParser;
	
	@Autowired 
	EquityCsvToWriter csvWriter;
	
	@Autowired
	NDMFile ndmFile;
	
	@Value("${regRep.file.TriOptima.ndm.enabled}")
	private String ndmEnabled;
	
	@PostConstruct
	public void initialize(){
		outputFolder = new File(outputFolderName);
		ensureFolderExists(outputFolder);
		
	}
	
	private void ensureFolderExists(File folder) {
		if (!folder.exists()) {
			if (!folder.mkdirs()) {
				logger.error("Couldn't create output folder - " + folder);
			}
		} else if (!folder.isDirectory()) {
			logger.error("Couldn't create output folder - " + folder);
		}
		
	}
	
	public void csvGenerate(RegRepToRequest request) throws ParseException{
		
		equityRegRepToRequestList=regRepEodToReportDaoImpl.findAllTrades(request.getAssetClass(), request.getMsgType(), request.getSdrRepository());
		reportRequest(Constants.EqTemplate_ES_PSA_CFD+Constants.HYPHEN+Constants.RECON, Constants.MESSAGE_TYPE_SNAPSHOT_TO,equityRegRepToRequestList,request.getSdrRepository());
		reportRequest(Constants.EqTemplate_StructuredProduct+Constants.HYPHEN+Constants.RECON, Constants.MESSAGE_TYPE_SNAPSHOT_TO,equityRegRepToRequestList,request.getSdrRepository());
		reportRequest(Constants.EqTemplate_VS+Constants.HYPHEN+Constants.RECON, Constants.MESSAGE_TYPE_SNAPSHOT_TO,equityRegRepToRequestList,request.getSdrRepository());
		reportRequest(Constants.EqTemplate_FWD+Constants.HYPHEN+Constants.RECON, Constants.MESSAGE_TYPE_SNAPSHOT_TO,equityRegRepToRequestList,request.getSdrRepository());
		reportRequest(Constants.EqTemplate_OPT+Constants.HYPHEN+Constants.RECON, Constants.MESSAGE_TYPE_SNAPSHOT_TO,equityRegRepToRequestList,request.getSdrRepository());
		
	}

	public void reportRequest(String productType,String msgType,List<RegRepEodToReport> equityRegRepToRequestList,String repository ){
		equityEligibleRegRepToRequestList=prepareTemplateData(equityRegRepToRequestList,productType);
		if(equityEligibleRegRepToRequestList.size()>0)
		{
		if(productType.contains(Constants.EqTemplate_VS)){
			
			File targetFolder = new File(outputFolderName, productType.replace("-Recon", ""));
			ensureFolderExists(targetFolder);
			File vsFile = csvWriter.vsReconWrite(equityEligibleRegRepToRequestList, getFileName(productType,msgType,repository), targetFolder);
			ndmFiletoTrioptima(vsFile);
			
		}else if(productType.contains(Constants.EqTemplate_StructuredProduct)){
			
			File targetFolder = new File(outputFolderName, productType.replace("-Recon", ""));
			ensureFolderExists(targetFolder);
			File spFile = csvWriter.structProdReconWrite(equityEligibleRegRepToRequestList, getFileName(productType,msgType,repository), targetFolder);
			ndmFiletoTrioptima(spFile);
			
		}else if(productType.contains(Constants.EqTemplate_ES_PSA_CFD)){
			
			File targetFolder = new File(outputFolderName, productType.replace("-Recon", ""));
			ensureFolderExists(targetFolder);
			File cfdFile = csvWriter.cfdReconWrite(equityEligibleRegRepToRequestList, getFileName(productType,msgType,repository), targetFolder);
			ndmFiletoTrioptima(cfdFile);
			
		}else if(productType.contains(Constants.EqTemplate_FWD)){
			
			File targetFolder = new File(outputFolderName, productType.replace("-Recon", ""));
			ensureFolderExists(targetFolder);
			File fwdFile = csvWriter.fwdReconWrite(equityEligibleRegRepToRequestList, getFileName(productType,msgType,repository), targetFolder);
			ndmFiletoTrioptima(fwdFile);
			
		}else if(productType.contains(Constants.EqTemplate_OPT)){
			
			File targetFolder = new File(outputFolderName, productType.replace("-Recon", ""));
			ensureFolderExists(targetFolder);
			File optFile = csvWriter.optReconWrite(equityEligibleRegRepToRequestList, getFileName(productType,msgType,repository), targetFolder);
			ndmFiletoTrioptima(optFile);
		}
		logger.info("TO report generation is done for "+productType+"::"+equityEligibleRegRepToRequestList.size());
		}
		else 
			logger.error("report not generated because count is 0 for:"+productType+":"+repository);
		
	}
	
	public void ndmFiletoTrioptima(File fileName)
	{
		if(ndmEnabled.equalsIgnoreCase(Constants.TRUE))
		{
			ndmFile.ndmScirpt(fileName);
		}
		else
			logger.info("Not sending file to TO, NDM enabled is not true");
	}
	
	private List<RegRepEodToReport>  prepareTemplateData(List<RegRepEodToReport> dataList,String templateName) 
	{
		List<RegRepEodToReport> returnDataList=new ArrayList<RegRepEodToReport>();
		RegRepTrioptima regrepTrioptima = null;
		
		for(RegRepEodToReport record:dataList)
		{
			if(!GeneralUtils.IsNullOrBlank(record.getEquityTemplate())){
				
			try 
			{
				regrepTrioptima = regRepTrioptimaParser.unmarshallToTemplateObj(record.getMessage());
			} 
			catch (Exception e) 
			{
					logger.error ("Exception while unmarshalling Trioptima Object" + e.getMessage());
			}
				
			if(!GeneralUtils.IsNull(record) && record.getEquityTemplate().equals(templateName.replace("-Recon", "")))
			{
				if (!GeneralUtils.IsNull(regrepTrioptima))
				{
					record.setRegRepTrioptima(regrepTrioptima);
					
					/** List of leis which are eligible for TO report*/
					if (isLeiEligibleForReport(regrepTrioptima) && isJurisdictionEligibleForReport(record))
						returnDataList.add(record);
				}
			}
		}
		}
		return returnDataList;
	}
	
	private boolean isLeiEligibleForReport(RegRepTrioptima record)
	{
		
		String leiParty1Lei,leiParty2Lei;
		leiParty1Lei=record.getTradeParty1();
		leiParty2Lei=record.getTradeParty2();

		if(StringUtils.contains(leiParty1Lei, Constants.COLON) )
			leiParty1Lei=StringUtils.substringAfter(leiParty1Lei, Constants.COLON);
		if(StringUtils.contains(leiParty2Lei, Constants.COLON) )
			leiParty2Lei=StringUtils.substringAfter(leiParty2Lei, Constants.COLON);
		if(StringUtils.contains(leiParty1Lei, Constants.COMMA) )
			leiParty1Lei=StringUtils.substringBefore(leiParty1Lei, Constants.COMMA);
		if(StringUtils.contains(leiParty2Lei, Constants.COMMA) )
			leiParty2Lei=StringUtils.substringBefore(leiParty2Lei, Constants.COMMA);
		
	
		/** List of leis which are eligible for TO report*/
		if (StringUtils.contains( listOfEligibleLeis,leiParty1Lei) && StringUtils.contains( listOfEligibleLeis,leiParty2Lei))
			return true;
		return false;
	}

	
	/**
	 * isJurisdictionEligibleForReport - Filter out non cftc trades from tri-optima report
	 * @param record
	 * @return
	 */
	private boolean isJurisdictionEligibleForReport(RegRepEodToReport record) 
	{
		boolean isBufferEligible=true;
		String sdrRepo = record.getJurisdiction();
		
		if(!GeneralUtils.IsNullOrBlank(sdrRepo))
		{
			if((sdrRepo.contains(Constants.CA_PERIOD)||sdrRepo.contains(Constants.CAD)) && !sdrRepo.contains(Constants.CFTC))
				isBufferEligible=false;
		}
		return isBufferEligible;
	}
	
	private String getFileName(String templateName, String msgType,String sdrRepository) {
		
		String repository=sdrRepository.equals(Constants.DTCC)?"D_":sdrRepository.equals(Constants.CAD)?"Cad_":"C_";
		String fileNamePart=templateName.replace("-Recon", "").replace("StructuredProduct", "SP");
		return repository+""+msgType+"_"+fileNamePart + Constants.TO_REPOSITORY_IDENTIFIER + DateFormatUtils.format(new Date(), "MMddyyyy_HHmm") + ".csv";
	}

}
