package com.wellsfargo.regulatory.eod.processors;
/**
 * @author 	Amit Rana
 * @date 	07/17/2015
 * @version 1.0
 */

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;

public class EodProcessor implements ItemProcessor<RegRepEodSubmission
		, RegRepEodSubmission>, StepExecutionListener {
	
	private JobExecution jobExecution;
	
	private static Logger logger = Logger
			.getLogger(EodProcessor.class.getName());

	@Override
	public ExitStatus afterStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		jobExecution = stepExecution.getJobExecution();
		
	}

	@Override
	public RegRepEodSubmission process(RegRepEodSubmission submission) throws Exception {
		
		logger.debug(" Entering processer ");
		
		Date asofDate=jobExecution.getJobParameters().getDate(Constants.EOD_JOB_HEADER_AS_OF_DATE);
		
		submission.setAsOfDate(asofDate);		
		submission.setInsertTimestamp(new Date());		
		submission.setSdrResponse(Constants.NULL);
		submission.setStatus(Constants.STATUS_SUBMITTED);
		submission.setSubmissionTimestamp(new Date());
		
		logger.debug(" Exiting processer ");
		return submission;
	}

}
