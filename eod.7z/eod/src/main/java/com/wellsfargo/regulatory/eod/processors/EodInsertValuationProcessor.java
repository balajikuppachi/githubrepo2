package com.wellsfargo.regulatory.eod.processors;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import com.wellsfargo.regulatory.persister.rowMapper.RegRepEodInsertRefreshMessage;

public class EodInsertValuationProcessor implements ItemProcessor<RegRepEodInsertRefreshMessage, RegRepEodInsertRefreshMessage>,
		StepExecutionListener {

	private static Logger logger = Logger
			.getLogger(EodInsertRefreshProcessor.class.getName());
	@Override
	public ExitStatus afterStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeStep(StepExecution arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public RegRepEodInsertRefreshMessage process(
			RegRepEodInsertRefreshMessage msg) throws Exception {
		
		logger.info(" Entering Insert Valuation processer");
		
			
		logger.debug(" Exiting Valuation processer ");
		return msg ;
	}

}
