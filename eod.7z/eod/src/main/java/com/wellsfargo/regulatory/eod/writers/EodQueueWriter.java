package com.wellsfargo.regulatory.eod.writers;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.PublishFpML;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;

@Component
public class EodQueueWriter extends PublishFpML
{
	private static String ratesDestination;
	private static String creditDestination;
	private static String fxDestination;
	private static String equityDestination;

	private static final Logger LOG = Logger.getLogger(EodQueueWriter.class.getName());

	public boolean publishMessages(List<? extends RegRepEodSubmission> messages)
	{
		String  destinationEndPoint = null;
		String  payload 			= null;
		boolean success 			= false;
		boolean msgSubStatus        = false;
		boolean allMsgsSubStatus    = true;
		
		if(null == messages || messages.size() < 1)
			return success;

		//LOG.info("**** Gateway Decision OutGoingQueue : " + destinationEndPoint);
		
		/*** FpML Submission ***/
		try 
		{
			for(RegRepEodSubmission message : messages)
			{
				payload = message.getSdrReport();
				
				if(Constants.ASSET_CLASS_INTEREST_RATE.equals(message.getAssetClass()))
					destinationEndPoint = ratesDestination;
				
				else if(Constants.ASSET_CLASS_CREDIT.equals(message.getAssetClass()))
					destinationEndPoint = creditDestination;
				
				else if(Constants.ASSET_CLASS_FOREX.equals(message.getAssetClass()))
					destinationEndPoint = fxDestination;
				
				else if(Constants.ASSET_CLASS_EQUITY.equals(message.getAssetClass()))
					destinationEndPoint = equityDestination;
				
				else 
					return success;
			
				msgSubStatus = submitMessage(payload, destinationEndPoint);	
				
				if(!msgSubStatus)
						allMsgsSubStatus = false;				
			}
			success =(allMsgsSubStatus) ? true :  false;			
			
		} 
		catch (MessagingException e) 
		{
			LOG.error("######### Error submitting data to OutGoingQueue : " + destinationEndPoint, e);
		}
		
		return success;
	}

	public static void setRatesDestination(String ratesDestination) {
		EodQueueWriter.ratesDestination = ratesDestination;
	}

	public static void setCreditDestination(String creditDestination) {
		EodQueueWriter.creditDestination = creditDestination;
	}

	public static void setFxDestination(String fxDestination) {
		EodQueueWriter.fxDestination = fxDestination;
	}

	public static void setEquityDestination(String equityDestination) {
		EodQueueWriter.equityDestination = equityDestination;
	}

}
