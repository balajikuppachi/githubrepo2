package com.wellsfargo.regulatory.eod.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.helpers.crypto.SecureDBPwdFactory;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepEodExtValDataCache;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobExecutionDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobExecutionDetails;

/**
 * @author Raji Komatreddy
 */


@Component
public class ExternalValuationDataLoaderSvc
{

	private static Logger logger = Logger.getLogger(ExternalValuationDataLoaderSvc.class.getName());

	@Value("${regRep.eod.cdbo.dbserver}")
	String CDBO_DBSERVER;

	@Value("${regRep.eod.cdbo.db}")
	String CDBO_DB;

	@Value("${regRep.eod.cdbo.dbuser}")
	String CDBO_DBUSER;

	@Value("${regRep.eod.cdbo.dbpass}")
	String CDBO_DBPASS;
	
	@Value("${regRep.eod.cdbo.env}")
	String CDBO_ENV;


	@Value("${regRep.eod.sdr.dbserver}")
	String SDR_DBSERVER;

	@Value("${regRep.eod.sdr.db}")
	String SDR_DB;

	@Value("${regRep.eod.sdr.dbuser}")
	String SDR_DBUSER;

	@Value("${regRep.eod.sdr.dbpass}")
	String SDR_DBPASS;

	@Value("${regRep.eod.cdbo.script}")
	String CDBO_SCRIPT;

	@Value("${regRep.file.cdboFolder}")
	String cdboFolferName;

	@Autowired
	MailSenderService mailSenderService;
	
	@Autowired
	SecureDBPwdFactory dbPwdFactory;

	@Autowired
	RegRepEodJobExecutionDetailsDaoImpl regRepEodJobExecutionDetailsDaoImpl;
	
	@Autowired
	RegRepEodExtValDataCache regRepEodExtValDataCache;

	// / public static final String EOD_JOB_PROCESSING = "processing";
	// public static final String EOD_JOB_SUCCESS = "success";
	// public static final String EOD_JOB_ERROR = "error";

	public void updateDataFromCDBO(Message<?> message) throws MessagingException
	{

		AbstractDriver.clearContextInformation();
		
		logger.info("===============Inside ExternalValuationDataLoaderSvc================");
		Object ipMessage = null;
		String errorString = null;
		RegRepEodJobDetails currRegRepEodJobDetails = null;
		String error_dtls = null;
		Date currDate = new Date();
		String decodedCdboPwd = null;
		String decodedSdrPwd = null;

		BufferedReader stdInput = null;
		BufferedReader stdError = null;
		String errorMsg = null;

		if (null == message)
		{
			errorString = "Null incoming message RegRepEodJobDetails";
			logger.error("########## " + errorString);
			throw new MessagingException("ExternalValuationDataLoaderSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);
		}
		ipMessage = message.getPayload();
		if (ipMessage instanceof RegRepEodJobDetails)
		{
			currRegRepEodJobDetails = (RegRepEodJobDetails) message.getPayload();
		}
		if (null == currRegRepEodJobDetails)
		{
			errorString = "Null incoming External Valuation Job Details";
			logger.error("########## " + errorString);
			throw new MessagingException("ExternalValuationDataLoaderSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);

		}

		RegRepEodJobExecutionDetails currRegRepEodJobExecutionDetails = new RegRepEodJobExecutionDetails();
		Map<String, Object> jobInfoMap=(Map<String, Object>) message.getHeaders().get(Constants.EOD_JOB_INFO);
		currRegRepEodJobExecutionDetails.setFileName((String)jobInfoMap.get(Constants.EOD_JOB_NAME));
		currRegRepEodJobExecutionDetails.setJobDetailsId(currRegRepEodJobDetails.getJobDetailsId());
		currRegRepEodJobExecutionDetails.setJobStatus(Constants.EOD_JOB_PROCESSING);
		currRegRepEodJobExecutionDetails.setAsOfDate(new java.sql.Date(currDate.getTime()));

		long jobexecId = regRepEodJobExecutionDetailsDaoImpl.insertandGetId(currRegRepEodJobExecutionDetails);
		logger.info("job started with jobexecution id " + jobexecId);

		File cdboFolder = new File(cdboFolferName);
		if (!cdboFolder.exists())
		{
			if (!cdboFolder.mkdirs())
			{
				errorMsg = "Couldn't create folder - " + cdboFolferName;
				throw new MessagingException("ExternalValuationDataLoaderSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorMsg);

			}
		}
		else if (!cdboFolder.isDirectory())
		{
			errorMsg = "Output folder name doesn't point to a directory - " + cdboFolferName;
			throw new MessagingException("ExternalValuationDataLoaderSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorMsg);
		}
		logger.info("===== Folder " + cdboFolferName + " Created =====");

		decodedCdboPwd = dbPwdFactory.getPassword(CDBO_DBPASS.trim());
		decodedSdrPwd = dbPwdFactory.getPassword(SDR_DBPASS.trim());

		String[] command =
		{ CDBO_SCRIPT.trim(), DateFormatUtils.format(CalendarUtils.yesterday(), "MM/dd/yyyy"), CDBO_DBSERVER.trim(), CDBO_DB.trim(), CDBO_DBUSER.trim(), decodedCdboPwd.trim(), SDR_DBSERVER.trim(), SDR_DB.trim(),
		        SDR_DBUSER.trim(), decodedSdrPwd.trim(), CDBO_ENV.trim() };

		int intVal = -1;

		try
		{
			Process p = null;
			logger.info("===============Start Executing script================");
			p = Runtime.getRuntime().exec(command);
			logger.info("===============After Executing script================");
			stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			String line;
			logger.info("===============Loading Data From CDBO================");
			line = stdInput.readLine();
			while (line != null)
			{
				logger.info(line);
				line = stdInput.readLine();
				
				//update EodExtValDataCache with latest data
				logger.info("refreshing EodExtValDataCache for non Equity trades");
				regRepEodExtValDataCache.loadNpvDataToCache();
				
			}

			line = stdError.readLine();
			while (line != null)
			{
				logger.info(line);
				line = stdError.readLine();
			}
			error_dtls=line;
			intVal = p.waitFor();
			try
			{
				if (stdInput != null) stdInput.close();
				if (stdError != null) stdError.close();
			}
			catch (Exception ignored)
			{
				logger.info("Ignored Standard I/O could not close:"+ ignored.getMessage(), ignored);
			}
			intVal= p.exitValue();
			
		}
		catch (Exception e)
		{
			logger.info("Execution of the script failed :"+CDBO_SCRIPT +" -> "+e.getMessage(), e);
			error_dtls = ExceptionUtils.getStackTrace(e);
			intVal=-1;
		}
		
		if(intVal!=0)
		{
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, "Failed:"+error_dtls, jobexecId);
			mailSenderService.sendRegRepAlertsMail("CRITICAL:JOB FAILED - "+currRegRepEodJobExecutionDetails.getFileName(),"JobName:"+currRegRepEodJobExecutionDetails.getFileName()+"Failed \n CDBO Data Load is failed \n Exception:"+error_dtls,null);
		}
		else
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_SUCCESS, "CDBO Data Load is success", jobexecId);


	}

	

}
