/**
 * 
 */
package com.wellsfargo.regulatory.eod.writers;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodToReport;

/**
 * @author Pavan Siram
 *
 */

@Component
public class EquityCsvToWriter {

	Logger logger=Logger.getLogger(CsvToWriter.class.getName());
	static char SEPARATOR = ',';
	File file;
	FileWriter writer;
	
	@Autowired
	private FileStaticContent fileStaticContentGenerator;
	
	public File vsReconWrite(List<RegRepEodToReport> tradeList,
			String fileName, File targetFolder) {

		file=new File(targetFolder,fileName);
		try{
			writer=new FileWriter(file);
			writeFileHeader("Equity", writer, fileName);
			
			writer.append("*PARTY_ID");
			writer.append(SEPARATOR);
			writer.append("CP_ID");
			writer.append(SEPARATOR);
			writer.append("Party 1 Prefix:Party 1 Value");
			writer.append(SEPARATOR);
			writer.append("Party 2 Prefix:Party 2 Value");
			writer.append(SEPARATOR);
			writer.append("TRADE_ID");
			writer.append(SEPARATOR);
			writer.append("USI Prefix:USI Value");
			writer.append(SEPARATOR);
			writer.append("Product ID Prefix:Product ID Value");
			writer.append(SEPARATOR);
			writer.append("PRODUCT_CLASS");
			writer.append(SEPARATOR);
			writer.append("Buyer Prefix:Buyer Value");
			writer.append(SEPARATOR);
			writer.append("Vega Notional Amount");
			writer.append(SEPARATOR);
			writer.append("Vega Notional Currency");
			writer.append(SEPARATOR);
			writer.append("START_DATE");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Valuation Date");
			writer.append(SEPARATOR);
			writer.append("Reporting Jurisdiction");
			writer.append(SEPARATOR);
			writer.append("Party 2 Role");
			writer.append(SEPARATOR);
			writer.append("Party 1 Role");
			writer.append(SEPARATOR);
			writer.append("Additional Repository 1 Prefix:Additional Repository 1 Value");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);
			writer.append("Execution Venue Prefix:Execution Venue");
			writer.append(SEPARATOR);
			writer.append("EXERCISE");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Secondary Asset Class (repeats four times)");
			writer.append(SEPARATOR);
			writer.append("Underlying Asset");
			writer.append(SEPARATOR);
			writer.append("Variance Strike Price");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE_CURR");
			writer.append(SEPARATOR);
			writer.append("Underlying Asset Identifier Type");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append('\n');
			for(RegRepEodToReport trade:tradeList){
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getBuyer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getBuyer()));
				writer.append(SEPARATOR);
				//Pending
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getEffectiveDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTerminationDateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTerminationDateLeg1()));
				writer.append(SEPARATOR);
				writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExercise())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExercise()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAsset())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAsset()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getStrikePrice())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getStrikePrice().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUpfrontFee())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFee()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUpfrontFeeCurr())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFeeCurr()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append('\n');
				
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				writeFileFooter("Equity", writer, tradeList);
			writer.flush();
			writer.close();
			}catch(Exception e){
				logger.error(e);
			}
		}
		return file;
	}

	public File structProdReconWrite(List<RegRepEodToReport> tradeList,
			String fileName, File targetFolder) {
		file=new File(targetFolder,fileName);
		try{
			writer=new FileWriter(file);
			writeFileHeader("Equity", writer, fileName);
			
			writer.append("*PARTY_ID");
			writer.append(SEPARATOR);
			writer.append("CP_ID");
			writer.append(SEPARATOR);
			writer.append("Party 1 Prefix:Party 1 Value");
			writer.append(SEPARATOR);
			writer.append("Party 2 Prefix:Party 2 Value");
			writer.append(SEPARATOR);
			writer.append("TRADE_ID");
			writer.append(SEPARATOR);
			writer.append("USI Prefix:USI Value");
			writer.append(SEPARATOR);
			writer.append("Product ID Prefix:Product ID Value");
			writer.append(SEPARATOR);
			writer.append("PRODUCT_CLASS");
			writer.append(SEPARATOR);
			writer.append("Buyer Prefix:Buyer Value");
			writer.append(SEPARATOR);
			writer.append("NOTIONAL");
			writer.append(SEPARATOR);
			writer.append("TRADE_CURR");
			writer.append(SEPARATOR);
			writer.append("START_DATE");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Termination Date/Expiration Date");
			writer.append(SEPARATOR);
			writer.append("Reporting Jurisdiction");
			writer.append(SEPARATOR);
			writer.append("Party 2 Role");
			writer.append(SEPARATOR);
			writer.append("Party 1 Role");
			writer.append(SEPARATOR);
			writer.append("Additional Repository 1 Prefix:Additional Repository 1 Value");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);
			writer.append("Execution Venue Prefix:Execution Venue");
			writer.append(SEPARATOR);
			writer.append("EXERCISE");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Secondary Asset Class (repeats four times)");
			writer.append(SEPARATOR);
			writer.append('"').append("Underlying Asset (Repeatable 10,000 times)").append('"');
			writer.append(SEPARATOR);
			writer.append("Option Strike Price");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE_CURR");
			writer.append(SEPARATOR);
			writer.append('"').append("Underlying Asset Identifier Type (Repeatable 10,000 times)").append('"');
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append('\n');
			for(RegRepEodToReport trade:tradeList){
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getBuyer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getBuyer()));
				writer.append(SEPARATOR);
				//Pending
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getEffectiveDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
				writer.append(SEPARATOR);
				writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTerminationDateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTerminationDateLeg1());
				writer.append(SEPARATOR);
				writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExercise())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExercise()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAsset())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAsset()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getStrikePrice())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getStrikePrice().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFee())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFee()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFeeCurr())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFeeCurr()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append('\n');

				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				writeFileFooter("Equity", writer, tradeList);
			writer.flush();
			writer.close();
			}catch(Exception e){
				logger.error(e);
			}
		}
		return file;
	}

	public File optReconWrite(List<RegRepEodToReport> tradeList,
			String fileName, File targetFolder) {
		file=new File(targetFolder,fileName);
		try{
			writer=new FileWriter(file);
			writeFileHeader("Equity", writer, fileName);
			
			writer.append("*PARTY_ID");
			writer.append(SEPARATOR);
			writer.append("CP_ID");
			writer.append(SEPARATOR);
			writer.append("Party 1 Prefix:Party 1 Value");
			writer.append(SEPARATOR);
			writer.append("Party 2 Prefix:Party 2 Value");
			writer.append(SEPARATOR);
			writer.append("TRADE_ID");
			writer.append(SEPARATOR);
			writer.append("USI Prefix:USI Value");
			writer.append(SEPARATOR);
			writer.append("Product ID Prefix:Product ID Value");
			writer.append(SEPARATOR);
			writer.append("PRODUCT_CLASS");
			writer.append(SEPARATOR);
			writer.append("Buyer Prefix:Buyer Value");
			writer.append(SEPARATOR);
			writer.append("NOTIONAL");
			writer.append(SEPARATOR);
			writer.append("TRADE_CURR");
			writer.append(SEPARATOR);
			writer.append("START_DATE");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Termination Date/Expiration Date");
			writer.append(SEPARATOR);
			writer.append("Reporting Jurisdiction");
			writer.append(SEPARATOR);
			writer.append("Party 2 Role");
			writer.append(SEPARATOR);
			writer.append("Party 1 Role");
			writer.append(SEPARATOR);
			writer.append("Additional Repository 1 Prefix:Additional Repository 1 Value");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);
			writer.append("Execution Venue Prefix:Execution Venue");
			writer.append(SEPARATOR);
			writer.append("EXERCISE");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Secondary Asset Class (repeats four times)");
			writer.append(SEPARATOR);
			writer.append('"').append("Underlying Asset (Repeatable 10,000 times)").append('"');
			writer.append(SEPARATOR);
			writer.append("Option Strike Price");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE_CURR");
			writer.append(SEPARATOR);
			writer.append('"').append("Underlying Asset Identifier Type (Repeatable 10,000 times)").append('"');
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append('\n');
			for(RegRepEodToReport trade:tradeList){
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getBuyer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getBuyer()));
				writer.append(SEPARATOR);
				//Pending
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getEffectiveDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTerminationDateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTerminationDateLeg1()));
				writer.append(SEPARATOR);
				writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExercise())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExercise()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAsset())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAsset()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getStrikePrice())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getStrikePrice().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFee())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFee()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFeeCurr())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFeeCurr()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append('\n');
					
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				writeFileFooter("Equity", writer, tradeList);
			writer.flush();
			writer.close();
			}catch(Exception e){
				logger.error(e);
			}
		}
		return file;
	}

	public File cfdReconWrite(List<RegRepEodToReport> tradeList,
			String fileName, File targetFolder) {
		file=new File(targetFolder,fileName);
		try{
			writer=new FileWriter(file);
			writeFileHeader("Equity", writer, fileName);
			
			writer.append("*PARTY_ID");
			writer.append(SEPARATOR);
			writer.append("CP_ID");
			writer.append(SEPARATOR);
			writer.append("Party 1 Prefix:Party 1 Value");
			writer.append(SEPARATOR);
			writer.append("Party 2 Prefix:Party 2 Value");
			writer.append(SEPARATOR);
			writer.append("TRADE_ID");
			writer.append(SEPARATOR);
			writer.append("USI Prefix:USI Value");
			writer.append(SEPARATOR);
			writer.append("Product ID Prefix:Product ID Value");
			writer.append(SEPARATOR);
			writer.append("PRODUCT_CLASS");
			writer.append(SEPARATOR);
			writer.append("Buyer Prefix:Buyer Value");
			writer.append(SEPARATOR);
			writer.append("NOTIONAL");
			writer.append(SEPARATOR);
			writer.append("TRADE_CURR");
			writer.append(SEPARATOR);
			writer.append("START_DATE");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Equity Leg Final Valuation Date");
			writer.append(SEPARATOR);
			writer.append("Reporting Jurisdiction");
			writer.append(SEPARATOR);
			writer.append("Party 2 Role");
			writer.append(SEPARATOR);
			writer.append("Party 1 Role");
			writer.append(SEPARATOR);
			writer.append("Additional Repository 1 Prefix:Additional Repository 1 Value");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);
			writer.append("Execution Venue Prefix:Execution Venue");
			writer.append(SEPARATOR);
			writer.append("EXERCISE");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Secondary Asset Class (repeats four times)");
			writer.append(SEPARATOR);
			writer.append('"').append("Underlying Asset (Repeatable 10,000 times)").append('"');
			writer.append(SEPARATOR);
			writer.append("STRIKE_PRICE");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE_CURR");
			writer.append(SEPARATOR);
			writer.append('"').append("Underlying Asset Identifier Type (Repeatable 10,000 times)").append('"');
			writer.append(SEPARATOR);
			
			writer.append('"').append("Underlying Asset Number of Units/Shares (Repeatable per underlying asset  10,000 times)").append('"');
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append('\n');
			for(RegRepEodToReport trade:tradeList){
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getBuyer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getBuyer()));
				writer.append(SEPARATOR);
				//Pending
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getEffectiveDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTerminationDateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTerminationDateLeg1()));
				writer.append(SEPARATOR);
				writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExercise())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExercise()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAsset())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAsset()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getStrikePrice())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getStrikePrice().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFee())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFee()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFeeCurr())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFeeCurr()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUnderlyingAssetNumberOfUnits())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAssetNumberOfUnits().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append('\n');
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				writeFileFooter("Equity", writer, tradeList);
			writer.flush();
			writer.close();
			}catch(Exception e){
				logger.error(e);
			}
		}
		return file;
	}

	public File fwdReconWrite(List<RegRepEodToReport> tradeList,
			String fileName, File targetFolder) {
		file=new File(targetFolder,fileName);
		try{
			writer=new FileWriter(file);
			writeFileHeader("Equity", writer, fileName);
			
			writer.append("*PARTY_ID");
			writer.append(SEPARATOR);
			writer.append("CP_ID");
			writer.append(SEPARATOR);
			writer.append("Party 1 Value");
			writer.append(SEPARATOR);
			writer.append("Party 2 Value");
			writer.append(SEPARATOR);
			writer.append("TRADE_ID");
			writer.append(SEPARATOR);
			writer.append("USI Value");
			writer.append(SEPARATOR);
			writer.append("Product ID Value");
			writer.append(SEPARATOR);
			writer.append("PRODUCT_CLASS");
			writer.append(SEPARATOR);
			writer.append("Buyer Value");
			writer.append(SEPARATOR);
			writer.append("Notional Amount");
			writer.append(SEPARATOR);
			writer.append("Notional Amount Currency");
			writer.append(SEPARATOR);
			writer.append("START_DATE");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Valuation Date");
			writer.append(SEPARATOR);
			writer.append("Reporting Jurisdiction");
			writer.append(SEPARATOR);
			writer.append("Party 2 Role");
			writer.append(SEPARATOR);
			writer.append("Party 1 Role");
			writer.append(SEPARATOR);
			writer.append("Additional Repository 1 Value");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);
			writer.append("Execution Venue");
			writer.append(SEPARATOR);
			writer.append("EXERCISE");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 US Person Indicator (CFTC field)");
			writer.append(SEPARATOR);
			writer.append("Secondary Asset Class (repeats four times)");
			writer.append(SEPARATOR);
			writer.append("Underlying Asset");
			writer.append(SEPARATOR);
			writer.append("STRIKE_PRICE");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE");
			writer.append(SEPARATOR);
			writer.append("UPFRONT_FEE_CURR");
			writer.append(SEPARATOR);
			writer.append("Underlying Asset Identifier Type");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");
			writer.append('\n');
			for(RegRepEodToReport trade:tradeList){
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getBuyer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getBuyer()));
				writer.append(SEPARATOR);
				//Pending
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getEffectiveDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getTerminationDateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTerminationDateLeg1()));
				writer.append(SEPARATOR);
				writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExercise())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExercise()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAsset())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAsset()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getStrikePrice())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getStrikePrice().toString()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFee())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFee()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNull(trade.getRegRepTrioptima().getUpfrontFeeCurr())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUpfrontFeeCurr()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAssetIdentifierType()));
				writer.append(SEPARATOR);
				writer.append(csvEQCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				writer.append(SEPARATOR);
				writer.append('\n');
				
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				writeFileFooter("Equity", writer, tradeList);
			writer.flush();
			writer.close();
			}catch(Exception e){
				logger.error(e);
			}
		}
		return file;
	}
	
	private void writeFileFooter(String assetClass,FileWriter out,List<RegRepEodToReport> tradeList)
			throws IOException {
		//Writing File Footer
		out.write(fileStaticContentGenerator.getAPPLICATION_TRAILER(assetClass));
		out.append('\n');
		out.write(fileStaticContentGenerator.getDATATRAK_TRAILER(tradeList.size(), assetClass));
		
		//ADD template ID
	}

	private void writeFileHeader(String assetClass, FileWriter out,
			 String fileName)
			throws IOException, ParseException {
		out.write(fileStaticContentGenerator.getDATATRAK_HEADER(assetClass));
		out.append('\n');
		out.write(fileStaticContentGenerator.getAPPLICATION_HEADER(fileName, assetClass));
		out.append('\n');

			
	}
	
	private String csvEQCommaField(String s)
	{
		StringBuilder sb = new StringBuilder();
		
		if(s.contains(Constants.COMMA)) {
			if(!s.startsWith(("\"")) && !s.endsWith("\""))
			{
				sb = sb.append("\"").append(s).append("\"");
			}
			s  = sb.toString();
		}
		return s;
	}

}
