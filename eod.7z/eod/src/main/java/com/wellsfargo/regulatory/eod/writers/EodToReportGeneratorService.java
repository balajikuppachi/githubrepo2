/**
 * 
 */
package com.wellsfargo.regulatory.eod.writers;

import java.io.File;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.gatewys.AbstractDriver;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.trioptima.RegRepTrioptima;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.ConversionUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepEodExtValDataCache;
import com.wellsfargo.regulatory.eod.dto.RegRepToRequest;
import com.wellsfargo.regulatory.eod.fileNDM.NDMFile;
import com.wellsfargo.regulatory.persister.dto.CollateralizationType;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodToReportDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodExtValData;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodToReport;
import com.wellsfargo.regulatory.persister.trioptima.parser.RegRepTrioptimaParser;

/**
 * @author Pavan Siram
 *
 */
@Component
public class EodToReportGeneratorService {
	
	private static Logger logger = Logger.getLogger(EodToReportGeneratorService.class.getName());
	
	@Autowired
	RegRepEodToReportDaoImpl regRepEodToReportDaoImpl;
	
	@Value("${regRep.eod.rates.TriOptima.outputFolder}")
	private String outputFolderTriOptimaInterestRate;
	
	@Value("${regRep.eod.credit.TriOptima.outputFolder}")
	private String outputFolderTriOptimaCredit;
	
	@Value("${regRep.eod.Forex.TriOptima.outputFolder}")
	private String outputFolderTriOptimaForex;
	
	private File outputFolderNRPInterestRate;
	
	private File outputFolderNRPCredit;

	private File outputFolderNRPForex;
	
	private File targetFolder;

	@Value("${regRep.eligible.for.TriOptima.lei}")
	private String listOfEligibleLeis;
	
	@Autowired
	CsvToWriter csvWriter;
	
	@Autowired
	RegRepEodExtValDataCache regRepEodExtValDataCache;
		
	List<RegRepEodToReport> regRepToRequestList=null;
	List<RegRepEodToReport> eligibleRegRepToRequestList;
	List<RegRepEodToReport> cdboRegRepToRequestList=null;
		
	@Autowired 
	RegRepTrioptimaParser regRepTrioptimaParser;
	
	@Autowired
	NDMFile ndmFile;
	
	@Value("${regRep.file.TriOptima.ndm.enabled}")
	private String ndmEnabled;
	
	@PostConstruct
	public void initialize() {
		
			
		outputFolderNRPInterestRate = new File(outputFolderTriOptimaInterestRate);
		if (!outputFolderNRPInterestRate.exists()) {
			if (!outputFolderNRPInterestRate.mkdirs()) {
				logger.error("Couldn't create output folder - " + outputFolderTriOptimaInterestRate);
			}
		} else if (!outputFolderNRPInterestRate.isDirectory()) {
			logger.error("Output folder name doesn't point to a directory - " + outputFolderTriOptimaInterestRate);
		}
		
		outputFolderNRPCredit = new File(outputFolderTriOptimaCredit);
		if (!outputFolderNRPCredit.exists()) {
			if (!outputFolderNRPCredit.mkdirs()) {
				logger.error("Couldn't create output folder - " + outputFolderTriOptimaCredit);
			}
		} else if (!outputFolderNRPCredit.isDirectory()) {
			logger.error("Output folder name doesn't point to a directory - " + outputFolderTriOptimaCredit);
		}
		
		outputFolderNRPForex = new File(outputFolderTriOptimaForex);
		if (!outputFolderNRPForex.exists()) {
			if (!outputFolderNRPForex.mkdirs()) {
				logger.error("Couldn't create output folder - " + outputFolderTriOptimaForex);
			}
		} else if (!outputFolderNRPForex.isDirectory()) {
			logger.error("Output folder name doesn't point to a directory - " + outputFolderTriOptimaForex);
		}
	}
	
	public void csvGenerate(RegRepToRequest request) throws ParseException{
		
		if(Constants.MESSAGE_TYPE_SNAPSHOT_TO.equals(request.getMsgType())){
			targetFolder = Constants.ASSET_CLASS_INTEREST_RATE.equals(request.getAssetClass()) ? outputFolderNRPInterestRate : Constants.ASSET_CLASS_CREDIT.equals(request.getAssetClass()) ? outputFolderNRPCredit : outputFolderNRPForex;
		}
		regRepToRequestList=regRepEodToReportDaoImpl.findAllTrades(request.getAssetClass(), request.getMsgType(), request.getSdrRepository());
		
		eligibleRegRepToRequestList=leiAndJurisdictionEligible(regRepToRequestList, request);
		logger.info("Tri-optima report query fetch data size:"+eligibleRegRepToRequestList.size());
		
		if(eligibleRegRepToRequestList.size()>0)
		{
			if(Constants.ASSET_CLASS_INTEREST_RATE.equals(request.getAssetClass()))
			{
				File irFile = csvWriter.irWrite(eligibleRegRepToRequestList, getFileName(request.getMsgType(),request.getAssetClass(),request.getSdrRepository()), targetFolder,request);
				ndmFiletoTrioptima(irFile);
			}
			else if (Constants.ASSET_CLASS_CREDIT.equals(request.getAssetClass()))
			{
				File crFile = csvWriter.crWrite(eligibleRegRepToRequestList, getFileName(request.getMsgType(),request.getAssetClass(),request.getSdrRepository()), targetFolder,request);
				ndmFiletoTrioptima(crFile);
			}
			else if (Constants.ASSET_CLASS_FOREX.equals(request.getAssetClass()))
			{
				File fxFile = csvWriter.fxWrite(eligibleRegRepToRequestList, getFileName(request.getMsgType(),request.getAssetClass(),request.getSdrRepository()), targetFolder,request);
				ndmFiletoTrioptima(fxFile);
			}
				logger.info("TO report generated successfully");
		}
		else 
			logger.error("report not generated because count is 0 for:"+request.getAssetClass()+":"+request.getSdrRepository());
		
	}
	
	public void ndmFiletoTrioptima(File fileName)
	{
		if(ndmEnabled.equalsIgnoreCase(Constants.TRUE))
		{
			ndmFile.ndmScirpt(fileName);
		}
		else
			logger.info("Not sending file to TO, NDM enabled is not true");
	}

	
	private String getFileName(String messageType, String assetClass,String sdrRepository) {
		String repository=sdrRepository.equals("DTCC")?"D_":sdrRepository.equals("EMIR")?"E_":sdrRepository.equals("CAD")?"Cad_":"C_";
		return repository+messageType + assetClass + "_Repository_"+DateFormatUtils.format(new Date(), "MMddyyyy_HHmm") + ".csv";
	}
	
	public List<RegRepEodToReport> leiAndJurisdictionEligible(List<RegRepEodToReport> regRepToRequestList, RegRepToRequest request) throws ParseException{
		List<String> errorList = new ArrayList<String>();
		Map<String, String> collMap = new HashMap<String, String>();
		Date curDate = new Date();
		List<CollateralizationType> colType = null;
		RegRepTrioptima regrepTrioptima = null;
		
		long startTime = System.currentTimeMillis();
		if(!Constants.ASSET_CLASS_FOREX.equals(request.getAssetClass())){
			 colType = regRepEodToReportDaoImpl.fetchCollateralizationType(request.getAssetClass(), request.getMsgType(), request.getSdrRepository());
					
			if(!GeneralUtils.IsListNullOrEmpty(colType)){
				for(CollateralizationType collateral : colType){
					collMap.put(collateral.getTradeID(), collateral.getcollateralizationType());
						}
					}
			}
		long stopTime = System.currentTimeMillis();

		logger.info("Total Time Taken to get Collateral Map in MilliSeconds "+ (stopTime - startTime));
		
		eligibleRegRepToRequestList=new ArrayList<RegRepEodToReport>();
		for(RegRepEodToReport report:regRepToRequestList){
			
			try {
					regrepTrioptima = regRepTrioptimaParser.unmarshallToTemplateObj(report.getMessage());
			} catch (Exception e) {
				logger.error ("Exception while unmarshalling Trioptima Object" + e.getMessage());
			}
			if (!GeneralUtils.IsNull(regrepTrioptima))
			{
				report.setRegRepTrioptima(regrepTrioptima);
				
			if(isLeiEligibleForReport(regrepTrioptima) && isJurisdictionEligibleForReport(report)) {
				
				if (!CalendarUtils.isSameDay(report.getUpdateTimestamp(), curDate)) {
					String collType = null;
					
					if(!Constants.ASSET_CLASS_FOREX.equals(request.getAssetClass())){
						collType = (String) collMap.get(report.getTradeId());
					} else {
						String tradeID, collfx= null;
						tradeID = report.getTradeId();	
						tradeID = tradeID.replace("NL", "").replace("FL","");
						collfx = regRepEodToReportDaoImpl.fetchCollateralizationTypeFX(tradeID);
						if(!GeneralUtils.IsNullOrBlank(collfx)){
							collType = collfx;
						}
					}
					eligibleRegRepToRequestList.add(updateMsgBufferForSnapshot(request.getAssetClass(),report, errorList, collType, regrepTrioptima));
				}else{
					eligibleRegRepToRequestList.add(report);
				}
			}
			else
				logger.info("Trade skipped either LEI not eligible or jurisdiction"+report.getTradeId());
			}
		}
		return eligibleRegRepToRequestList;
	}
	


	private boolean isLeiEligibleForReport(RegRepTrioptima record)
	{
		
		String leiParty1Lei,leiParty2Lei;
		leiParty1Lei=record.getTradeParty1();
		leiParty2Lei=record.getTradeParty2();
		//leiParty2Lei="INTERNAL:930117";

		if(StringUtils.contains(leiParty1Lei, Constants.COLON) )
			leiParty1Lei=StringUtils.substringAfter(leiParty1Lei, Constants.COLON);
		if(StringUtils.contains(leiParty2Lei, Constants.COLON) )
			leiParty2Lei=StringUtils.substringAfter(leiParty2Lei, Constants.COLON);
		if(StringUtils.contains(leiParty1Lei, Constants.COMMA) )
			leiParty1Lei=StringUtils.substringBefore(leiParty1Lei, Constants.COMMA);
		if(StringUtils.contains(leiParty2Lei, Constants.COMMA) )
			leiParty2Lei=StringUtils.substringBefore(leiParty2Lei, Constants.COMMA);
		
	
		/** List of leis which are eligible for TO report*/
		if (StringUtils.contains( listOfEligibleLeis,leiParty1Lei) && StringUtils.contains( listOfEligibleLeis,leiParty2Lei))
			return true;
		return false;
	}

	
	/**
	 * isJurisdictionEligibleForReport - Filter out non cftc trades from tri-optima report
	 * @param record
	 * @return
	 */
	private boolean isJurisdictionEligibleForReport(RegRepEodToReport record) 
	{
		boolean isBufferEligible=true;
		String sdrRepo = record.getJurisdiction();
		
		if(!GeneralUtils.IsNullOrBlank(sdrRepo))
		{
			if((sdrRepo.contains(Constants.CA_PERIOD)||sdrRepo.contains(Constants.CAD)) && !sdrRepo.contains(Constants.CFTC))
				isBufferEligible=false;
		}
		return isBufferEligible;
	}
	

	private RegRepEodToReport updateMsgBufferForSnapshot(String assetClass, RegRepEodToReport record, List<String> errorList, String collType,RegRepTrioptima regrepTrioptima  ) throws ParseException {
		
		RegRepEodExtValData data = new RegRepEodExtValData();
		data = regRepEodExtValDataCache.getValData(record.getTradeId().trim(), assetClass);
		
		String tradeDate = null;
		tradeDate = regrepTrioptima.getTradeDate();
		
		if(!GeneralUtils.IsNullOrBlank(tradeDate)){
			
				try {	
					regrepTrioptima.setTradeDate(CalendarUtils.dateToUTCStringFormat(CalendarUtils.parseStringToDate(CalendarUtils.FORMAT_3, tradeDate)));
				} catch (Exception e) {
					logger.warn("Could not parse the trade date while creating snapshot NR message for Trade ID:"+record.getTradeId()+ " ->"+e);
				}
			}
		
		if(!GeneralUtils.IsNullOrBlank(collType)){
			regrepTrioptima.setCollateralized(getCollateralizationType(collType, assetClass));
		}
		updateMsgBufferForSnapshotFromCdbo(assetClass, record, data, errorList, regrepTrioptima);
		return record;
	}
	
	private RegRepEodToReport updateMsgBufferForSnapshotFromCdbo(String assetClass, RegRepEodToReport record , RegRepEodExtValData data, List<String> errorList,RegRepTrioptima regrepTrioptima ) throws ParseException {
	
		String tradeID=record.getTradeId();	
		
		if(GeneralUtils.IsNull(data))
		{
			errorList.add(tradeID);
		}
		else
		{
			String upi = regrepTrioptima.getProductId();
		
			String leg1Currency = regrepTrioptima.getNotionalCurrencyLeg1();
			String leg2Currency = regrepTrioptima.getNotionalCurrencyLeg2();
			
			String payCurrency = data.getPayCurrency();
			String payNotional = data.getPayNotional();
			String recvNotional = data.getRecvNotional();
			String notionalCurrent = data.getNotionalCurrent();
			
			BigDecimal payNotionalBD = null;
			BigDecimal recvNotionalBD = null;
			BigDecimal notionalCurrentBD = null;
			
			payNotionalBD = ConversionUtils.parseBigDecimal(payNotional).abs();
			recvNotionalBD = ConversionUtils.parseBigDecimal(recvNotional).abs();		
			notionalCurrentBD = ConversionUtils.parseBigDecimal(data.getNotionalCurrent()).abs();
		
			try{
			if (Constants.ASSET_CLASS_INTEREST_RATE.equals(assetClass))
			{
				if(!GeneralUtils.IsNullOrBlank(upi) && StringUtils.contains(upi, Constants.PRODUCT_TYPE_XCCY)) {
				
					if(!GeneralUtils.IsNullOrBlank(payCurrency) && !payCurrency.equals("0.0")) {
						
						if(payCurrency.equalsIgnoreCase(leg1Currency)) {
							if(!GeneralUtils.IsNull(payNotionalBD))
								regrepTrioptima.setNotionalAmountLeg1(payNotionalBD);
							if(!GeneralUtils.IsNull(recvNotionalBD))
								regrepTrioptima.setNotionalAmountLeg2(recvNotionalBD);
						}
						
						if(payCurrency.equalsIgnoreCase(leg2Currency))	{
							if(!GeneralUtils.IsNull(recvNotionalBD))
								regrepTrioptima.setNotionalAmountLeg1(recvNotionalBD);
							if(!GeneralUtils.IsNull(payNotionalBD))
								regrepTrioptima.setNotionalAmountLeg2(payNotionalBD);
						}
					}
					
				} else if(!GeneralUtils.IsNullOrBlank(notionalCurrent) && !GeneralUtils.IsNullOrBlank(upi)) {
	
					if(StringUtils.contains(upi, Constants.PRODUCT_TYPE_CAPFLOOR)){
						regrepTrioptima.setNotionalAmountLeg1(notionalCurrentBD);
						regrepTrioptima.setNotionalAmountLeg2(notionalCurrentBD);
					}else if( StringUtils.contains(upi, Constants.PRODUCT_TYPE_FRA)){
						regrepTrioptima.setNotionalAmountLeg1(notionalCurrentBD);
					}
					
					else if(StringUtils.contains(upi, Constants.PRODUCT_TYPE_EXOTIC)){
												
						if(GeneralUtils.IsNullOrBlank(leg1Currency))
							regrepTrioptima.setNotionalCurrencyLeg1(data.getNpvCurrency());
							
						if(GeneralUtils.IsNullOrBlank(leg2Currency))
							regrepTrioptima.setNotionalCurrencyLeg2(data.getNpvCurrency());
						
						regrepTrioptima.setNotionalAmountLeg1(notionalCurrentBD);
						regrepTrioptima.setNotionalAmountLeg2(notionalCurrentBD);
					} else {
						regrepTrioptima.setNotionalAmountLeg1(notionalCurrentBD);
						regrepTrioptima.setNotionalAmountLeg2(notionalCurrentBD);
					}
				} 
			}
		
			
			if(Constants.ASSET_CLASS_CREDIT.equals(assetClass))	{
				if(!StringUtils.containsIgnoreCase(upi, Constants.INDEX)) {
					if(!GeneralUtils.IsNull(notionalCurrentBD)){
						regrepTrioptima.setNotionalAmountLeg1(notionalCurrentBD);
						}
					}
				}
			}catch (Exception e) {
				logger.error("Error in NotionalCalc: "+e.getMessage());
				logger.error("Error in Snapshot_TO update from Cdbo: "+e.getMessage());
				
				}
			}
		return record;
	}
	
public String getCollateralizationType(String collateralizationType, String assetClass){
		
		if(StringUtils.contains(collateralizationType,Constants.PC)){
				if(Constants.ASSET_CLASS_FOREX.equals(assetClass)){
					return Constants.Partially;
				}
				else return Constants.PartiallyCollateralized;
				}
		else if(StringUtils.contains(collateralizationType,Constants.OW)){
			if(Constants.ASSET_CLASS_FOREX.equals(assetClass)){
				return Constants.One_Way;
			}
			else return Constants.OneWayCollateralized;
			}
		else if(StringUtils.contains(collateralizationType,Constants.FC)){
			if(Constants.ASSET_CLASS_FOREX.equals(assetClass)){
				return Constants.Fully;
			}
			else return Constants.FullyCollateralized;
			}
		else if(StringUtils.contains(collateralizationType,Constants.UC)){
				return Constants.UnCollateralized;
			}
		else 
			return null;
	}

}

