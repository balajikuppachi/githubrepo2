package com.wellsfargo.regulatory.eod.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.Message;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.email.service.MailSenderService;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.etd.utils.EtdConstants;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepEodExtValDataCache;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobExecutionDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodReportDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodExtValData;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobExecutionDetails;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodReport;
import com.wellsfargo.regulatory.persister.etd.dao.EtdPayloadDao;
import com.wellsfargo.regulatory.persister.etd.dto.EtdPayload;
import com.wellsfargo.regulatory.persister.helper.mapper.EtdPayloadMapper;

/**
 * @author Raji Komatreddy
 */

@Component
public class EodSnapShotJobReqGenSvc
{
	@Autowired
	@Qualifier("eodCftcJob")
	private Job eodCftcJob;
	
	@Autowired
	@Qualifier("eodDeltaCftcJob")
	private Job eodDeltaCftcJob;
	
	
	@Autowired
	@Qualifier("eodCadJob")
	private Job eodCadJob;
	
	@Autowired
	@Qualifier("eodEsmaJob")
	private Job eodEsmaJob;
	
	@Autowired
	@Qualifier("eodRefreshJob")
	private Job eodRefreshJob;
	
	@Autowired
	@Qualifier("eodInsertRefreshJob")
	private Job eodInsertBufferJob;
		
	@Autowired
	@Qualifier("eodInsertValuationJob")
	private Job eodInsertValuationJob;
	
	
	@Autowired
	@Qualifier("onDemandSnapShotSubmitJob")
	private Job onDemandSnapShotSubmitJob;
	
	@Autowired
	@Qualifier("regRepCollateralValuejob")
	private Job regRepCollateralValuejob; 	
	
	
	@Autowired
	@Qualifier("eodValJob")
	private Job eodValJob;
	
	
	@Value("${eod.collateral.to.dtcc.input.file.path}")
	private String dtccOutFileLoc;
	
	@Autowired 
	private EtdPayloadDao etdPayloadDao;

	@Autowired
	RegRepEodJobExecutionDetailsDaoImpl regRepEodJobExecutionDetailsDaoImpl;	
	
	@Autowired
	MailSenderService mailSenderService;
	
	@Autowired
	CacheManager cacheManager;
	
	@Autowired
	RegRepEodExtValDataCache regRepEodExtValDataCache;
	
	@Autowired
	RegRepEodReportDaoImpl regRepEodReportDaoImpl;

	private static Logger logger = Logger.getLogger(EodSnapShotJobReqGenSvc.class.getName());
	private Cache eodValuationCache = null;
	private Cache eodEquityValuationCache = null;

	public Message<JobLaunchRequest> toRequest(Message<?> message) throws MessagingException
	{
		Object ipMessage = null;
		String errorString = null;
		RegRepEodJobDetails currRegRepEodJobDetails = null;
		JobLaunchRequest eodBatchJobLaunch = null;
		Message<JobLaunchRequest> eodBatchJobLaunchMessage = null;		
		Date currDate = new Date();
		String jobName = null;
		Date cobDate = null;
		String jobExecutionId = null;
		EtdPayloadMapper etdPayloadMapper = null;
		EtdPayload etdPayload = null;
		String outFileName = null;
		String outFileDate = null;
		String dtccFileAbsolutLoc = null;
		String onDemandParams = null;
		String jurisdiction = null;
		String reportType = null;
		String assetClass = null;
		Long dayFraction = null;
		Date asOfDateTime=null;
		Map<String,Object> jobInfoMap=new HashMap<String,Object>();
		String eodValTime = null;
		boolean isCachDataAvailable = true;

		try
        {
	        if (null == message)
	        {
	        	errorString = "Null incoming message RegRepEodJobDetails";
	        	logger.error("########## " + errorString);
	        	throw new MessagingException("ExternalValuationDataLoaderSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);
	        }
	        ipMessage = message.getPayload();

	        jobInfoMap=(Map<String, Object>) message.getHeaders().get(Constants.EOD_JOB_INFO);

	        if (ipMessage instanceof RegRepEodJobDetails)
	        {
	        	currRegRepEodJobDetails = (RegRepEodJobDetails) message.getPayload();
	        }
	        if (null == currRegRepEodJobDetails || jobInfoMap == null)
	        {
	        	errorString = "Null incoming PrJobDetails";
	        	logger.error("########## " + errorString);
	        	throw new MessagingException("ExternalValuationDataLoaderSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.ETD_ERROR, errorString);

	        }

	        jobName=(String)jobInfoMap.get(Constants.EOD_JOB_NAME);
	        asOfDateTime=(Date) jobInfoMap.get(Constants.EOD_JOB_HEADER_AS_OF_DATE);
	        cobDate=(Date) jobInfoMap.get(Constants.EOD_JOB_COB_DATE);
	        jurisdiction=(String)jobInfoMap.get(Constants.JURISDICTION);
	        reportType=(String)jobInfoMap.get(Constants.REPORT_TYPE);
	        assetClass=(String)jobInfoMap.get(Constants.ASSET_CLASS);
	        dayFraction=(Long.valueOf((String)jobInfoMap.get(Constants.EOD_DAY_FRACTION)));
	        eodValTime=(String)jobInfoMap.get(Constants.EOD_JOB_VAL_TIME);
	        
	        String jobDetails=GeneralUtils.IsNullOrBlank(reportType)?jobName:StringUtils.join(new String[]{jobName,reportType,jurisdiction,assetClass},Constants.COLON);
	        logger.info("job request received for jobName:" + jobName + " cob_date: " + cobDate+ " reportType: " + reportType+ " jurisdiction: " + jurisdiction+ " assetClass: " + assetClass);
	        
	        RegRepEodJobExecutionDetails currRegRepEodJobExecutionDetails = new RegRepEodJobExecutionDetails();
	        currRegRepEodJobExecutionDetails.setJobDetailsId(currRegRepEodJobDetails.getJobDetailsId());
	        currRegRepEodJobExecutionDetails.setJobStatus(Constants.EOD_JOB_PROCESSING);
	        currRegRepEodJobExecutionDetails.setAsOfDate(new java.sql.Date(asOfDateTime.getTime()));
	        currRegRepEodJobExecutionDetails.setFileName(jobDetails);

	        long jobexecId = regRepEodJobExecutionDetailsDaoImpl.insertandGetId(currRegRepEodJobExecutionDetails);
	        jobExecutionId = Long.toString(jobexecId);
	        
	        logger.info("job started with jobexecution id " + jobexecId);

	        /**Setting the JOB parameters*/
	        JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
	        jobParametersBuilder.addString(Constants.EOD_JOB_NAME, jobName);
	        jobParametersBuilder.addDate(Constants.EOD_JOB_COB_DATE, cobDate);
	        jobParametersBuilder.addDate(Constants.EOD_JOB_HEADER_AS_OF_DATE, asOfDateTime);
	        jobParametersBuilder.addString(Constants.EOD_JOB_EXECUTION_ID, jobExecutionId);
	        jobParametersBuilder.addString(Constants.REPORT_TYPE, reportType);
	        jobParametersBuilder.addString(Constants.JURISDICTION, jurisdiction);
	        jobParametersBuilder.addString(Constants.ASSET_CLASS, assetClass);
	        jobParametersBuilder.addLong(Constants.EOD_DAY_FRACTION, dayFraction);
	        jobParametersBuilder.addString(Constants.EOD_JOB_VAL_TIME, eodValTime);
	        
	        onDemandParams = currRegRepEodJobDetails.getOnDemandParams();
	        
	      if(StringUtils.equalsIgnoreCase(Constants.MESSAGE_TYPE_VALUATION, reportType))	      
	    	 isCachDataAvailable = isEodValCacheLoaded(assetClass, jobexecId);
	      
	     //if cache is not available for Valuation jobs do not proceed with job execution
	      if(!isCachDataAvailable)
	      {
	    	  logger.error("Valuation cache data is not available for assetclass: " + assetClass + "hence not procedding with valuation processing"); 
	      }
	        		      
	      else if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_FULL_REPORT_JOB))
	        {	        	
        		if(StringUtils.equalsIgnoreCase(Constants.MESSAGE_TYPE_VALUATION, reportType))        		
        			checkValData(jurisdiction, assetClass);
        		
	    	  eodBatchJobLaunch = new JobLaunchRequest(eodCftcJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is EOD_FULL_REPORT_JOB generation");	      		
  	
	        }
	        else  if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_DELTA_REPORT_JOB) && Constants.CFTC.equalsIgnoreCase(jurisdiction))
	        {
	        	eodBatchJobLaunch = new JobLaunchRequest(eodDeltaCftcJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is EOD_DELTA_REPORT_JOB generation");
	        	
	        }else  if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_DELTA_REPORT_JOB)  && (Constants.ESMA.equalsIgnoreCase(jurisdiction) 
	        															|| (Constants.JURISDICTION_CAD.equals(jurisdiction))))
	        {
	        	eodBatchJobLaunch = new JobLaunchRequest(eodEsmaJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is EOD_DELTA_REPORT_JOB generation");
	        	
	        }
	        else if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_COMB_REPORT_JOB))
	        {
	        	eodBatchJobLaunch = new JobLaunchRequest(eodCadJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is EOD_COMB_REPORT_JOB generation");
	        }
	        else if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_REPORT_REFRESH_JOB))
	        {
	        	jobParametersBuilder.addString(Constants.EOD_SNAPSHOT_ONDEMAND_JOB_PARAMS, onDemandParams);
	        	eodBatchJobLaunch = new JobLaunchRequest(eodRefreshJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is Report refresh generation");	        		
        	        	
	        }
	        else if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_REPORT_INSERT_BUFFER_JOB))
	        {
	        	jobParametersBuilder.addString(Constants.EOD_SNAPSHOT_ONDEMAND_JOB_PARAMS, onDemandParams);
	        	eodBatchJobLaunch = new JobLaunchRequest(eodInsertBufferJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is Report insert buffer for EOD");
	        }
	        else if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_REPORT_INSERT_VALUATION_JOB))
	        {
	        	jobParametersBuilder.addString(Constants.EOD_SNAPSHOT_ONDEMAND_JOB_PARAMS, onDemandParams);
	        	eodBatchJobLaunch = new JobLaunchRequest(eodInsertValuationJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is Report Valuation insert buffer for EOD");
	        }
	        
	        
	        else if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_SNAPSHOT_SUBM_ONDEMAND_JOB))
	        {
        	
        		jobParametersBuilder.addString(Constants.EOD_SNAPSHOT_ONDEMAND_JOB_PARAMS, onDemandParams);
	        	eodBatchJobLaunch = new JobLaunchRequest(onDemandSnapShotSubmitJob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_JOB_NAME, jobName).build();
	        	logger.info("job request is for OnDemand Snapshots submission for trades present in the file: " + onDemandParams);
        		
	        }
	        else if (null != jobName && jobName.equalsIgnoreCase(Constants.EOD_ESMA_COLLATERALVALUE_JOB))
	        {
	        	String collateralCobDate=null;
	        	String fileDateFormat = "yyMMddHHmmssZ";
	        	SimpleDateFormat currfileDateFormat = new SimpleDateFormat(fileDateFormat);
	        	outFileDate = currfileDateFormat.format(currDate);

	        	outFileName = Constants.EOD_REGREP_COLLATERALVALUE + "_" + outFileDate + ".csv";
	        	dtccFileAbsolutLoc = dtccOutFileLoc + outFileName;
	        	
	        	Date current_date = new Date();
	        	SimpleDateFormat dateFormat = new SimpleDateFormat(EtdConstants.ETD_COBDATE_FORMAT);
	        	collateralCobDate = dateFormat.format(current_date);
	        	
	        	etdPayloadMapper = new EtdPayloadMapper();
	        	etdPayload = etdPayloadMapper.entryForRegRepCollateral();
	        	logger.debug("DB call initiated for payload persistence in ETD_PAYLOAD table....");
	        	etdPayload = etdPayloadDao.save(etdPayload);
	        	
	        	jobParametersBuilder.addString(Constants.EOD_COLLATERALVALUE_MSG_ID, etdPayload.getMessageId());
	        	jobParametersBuilder.addString(EtdConstants.DTTC_OUT_FILE_LOC, dtccFileAbsolutLoc);
	        	jobParametersBuilder.addString(EtdConstants.COBDATE, collateralCobDate);	        	
	        	
	        	eodBatchJobLaunch = new JobLaunchRequest(regRepCollateralValuejob, jobParametersBuilder.toJobParameters());
	        	eodBatchJobLaunchMessage = MessageBuilder.withPayload(eodBatchJobLaunch).setHeader(Constants.EOD_ESMA_COLLATERALVALUE_JOB, jobName).build();
	        	logger.info("job request is ESMA CollateralValue report generation");
	        }
        }
        catch (Exception ex)
        {
        	logger.error("exception occurred inside EodSnapShotJobReqGenSvc" + ExceptionUtils.getFullStackTrace(ex));
	       // e.printStackTrace();
        }
		finally
		{
			jobName= null;
			cobDate = null;
			onDemandParams = null;	
			
		}

		return eodBatchJobLaunchMessage;	
		

	}
	
	private boolean isEodValCacheLoaded(String assetClass, long jobExecId)
	{
		boolean cacheLoaded = true;
		String errorString = null;		
		
		eodValuationCache = cacheManager.getCache("eodValuationCache");		
		eodEquityValuationCache = cacheManager.getCache("eodEquityValuationCache");
		
		if(null != eodValuationCache && eodValuationCache.getSize() <= 0 && !StringUtils.endsWithIgnoreCase(assetClass, Constants.ASSET_CLASS_EQUITY))		
			regRepEodExtValDataCache.loadNpvDataToCache();
		
		if(null != eodEquityValuationCache && eodEquityValuationCache.getSize() <= 0 && StringUtils.endsWithIgnoreCase(assetClass, Constants.ASSET_CLASS_EQUITY))		
			regRepEodExtValDataCache.loadEquityNpvDataToCache();
		
		if(eodValuationCache.getSize() <= 0 && !StringUtils.equalsIgnoreCase(assetClass, Constants.ASSET_CLASS_EQUITY))
		{
			cacheLoaded = false;
			errorString = "CDBO Valuation data does not exist in REG_REP_EXT_VAL_DATA table, hence not proceeding with valuation processing ";
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, errorString, jobExecId);
			logger.error( " Critical error: Not proceeding with Valuation job as CDBO valuation data is not available " + errorString);
			
			//send email notification to production support
			String sub = "Critical Alert: Eod Valuation data from CDBO was not loaded in RegRep, Please act immediately "; 
			mailSenderService.sendRegRepAlertsMail(sub, errorString, null);
		}
		else if(eodEquityValuationCache.getSize() <= 0 && StringUtils.equalsIgnoreCase(assetClass, Constants.ASSET_CLASS_EQUITY))
		{
			cacheLoaded = false;
			errorString = "Galaxy Valuation data does not exist in REG_REP_EXT_VAL_DATA table, hence not proceeding with valuation processing ";
			regRepEodJobExecutionDetailsDaoImpl.update(Constants.EOD_JOB_ERROR, errorString, jobExecId);
			logger.error( " Critical error: Not proceeding with Valuation job as Galaxy valuation data is not available " + errorString);
			
			//send email notification to production support
			String sub = "Critical Alert: Eod Valuation data from Galaxy was not loaded in RegRep, Please act immediately "; 
			mailSenderService.sendRegRepAlertsMail(sub, errorString, null);
			
		}
		
		return cacheLoaded;
	}
	
	/**
	 * 
	 * @param jurisdiction
	 * @param assetClass
	 *  send email notification with list of trades for which valuation data is missing
	 */
	private void checkValData( String jurisdiction, String assetClass)
	{
		List<Map<String, String>> missingValuations =new ArrayList<Map<String,String>>();
		List<Map<String, String>> eodReportDataList = regRepEodReportDaoImpl.getTradeIdsWithOutValData(jurisdiction, assetClass);
		RegRepEodExtValData data =null;
		for (Map<String, String> eodReportMap : eodReportDataList) 
		{
			String tradeId=eodReportMap.get(Constants.TRADE_ID);
			if (Constants.ASSET_CLASS_FOREX.equals(assetClass)  && (StringUtils.endsWith(tradeId, Constants.FOREX_SWAP_LEG_NEAR) || StringUtils.endsWith(tradeId, Constants.FOREX_SWAP_LEG_FAR)))
				tradeId = StringUtils.substring(tradeId, 0, tradeId.length() - 2);

			data = regRepEodExtValDataCache.getValData(tradeId.trim(), assetClass);
			 if(GeneralUtils.IsNull(data))
				 missingValuations.add(eodReportMap);
			 
		}
		
		if(!GeneralUtils.IsListNullOrEmpty(missingValuations))
		{
			Map<String,String> additionalInfo=new HashMap<String, String>();
			additionalInfo.put(Constants.ASSET_CLASS, assetClass);
			additionalInfo.put(Constants.REPORT_TYPE, "Valuation");
			additionalInfo.put(Constants.JURISDICTION, jurisdiction);
			missingValuations.add(additionalInfo);
			
			try
			{
				logger.info("sending mail with missing valuation: for asset class " + assetClass + "jurisdiction : " + jurisdiction + 	"number of trades for which val data missing : "	+ missingValuations.size());
				mailSenderService.sendMailForValDataMissing(missingValuations, "Valuation", assetClass, jurisdiction );
			}
			catch(Exception ex)
			{
				logger.error("Exception occurred while sending email inside EodSnapShotJobReqGenSvc class " + ExceptionUtils.getFullStackTrace(ex));
			}
			
		}
		
	}

}
