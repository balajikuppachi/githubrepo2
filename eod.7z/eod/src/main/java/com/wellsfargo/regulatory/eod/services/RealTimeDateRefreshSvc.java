/**
 * 
 */
package com.wellsfargo.regulatory.eod.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.cache.dao.RealtimeConfigDAO;
import com.wellsfargo.regulatory.commons.keywords.Constants;

/**
 * @author u293876
 *
 */
@Component
public class RealTimeDateRefreshSvc {

	private static Logger logger = Logger.getLogger(RealTimeDateRefreshSvc.class.getName());
	
	@Autowired
	RealtimeConfigDAO  realtimeConfigDAOImpl;
	
	public void updateRefreshData(String value)
	{
		try
		{
			logger.info("Regrep propety value table updated with current Date:"+dateFormatter());
			
			realtimeConfigDAOImpl.updateRealtimeConfig(Constants.CLOSE_OF_BUSINESS_DATE,dateFormatter(),getUTCdatetimeAsString());
		
			logger.info("Regrep refresh value table updated with current Date:"+getUTCdatetimeAsString());
			
			//realtimeConfigDAOImpl.updateRefreshConfigByDate(getUTCdatetimeAsString());
			realtimeConfigDAOImpl.updateRefreshConfig();
		
			logger.info("tables updated successfully");
		}
		catch (Exception e) 
		{
			logger.info(e.getMessage(), e);
		}
		
	}
	
	//Will convert current date to yyyy-mm-dd
	public String dateFormatter()
	{
		SimpleDateFormat formatter=new SimpleDateFormat(Constants.DATEFORMAT);
		String date=formatter.format(new Date());
		return date;
	}
	
	//Will convert current date to UTC timezone
	public  String getUTCdatetimeAsString()
	{
	    final SimpleDateFormat sdf = new SimpleDateFormat(Constants.UTCDATEFORMAT);
	    sdf.setTimeZone(TimeZone.getTimeZone(Constants.UTC_TIMEZONE));
	    final String utcTime = sdf.format(new Date());

	    return utcTime;
	}
}
