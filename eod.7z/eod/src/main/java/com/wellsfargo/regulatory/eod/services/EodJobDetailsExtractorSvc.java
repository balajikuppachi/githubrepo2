package com.wellsfargo.regulatory.eod.services;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.cache.beans.RealtimeConfig;
import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.exceptions.MessagingException;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.CalendarUtils;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.eod.dto.RegRepEodJobRequest;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodJobDetailsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodJobDetails;

/**
 * @author Raji Komatreddy
 */
@Component
public class EodJobDetailsExtractorSvc
{

	Logger logger = Logger.getLogger(EodJobDetailsExtractorSvc.class);
//	private static final String EOD_JOB_NAME = "eodJobName";
//	private static final String EOD_JOB_HEADER_AS_OF_DATE = "asOfDate";

	@Autowired
	RealtimeConfig realtimeConfig;

	
	@Autowired
	RegRepEodJobDetailsDaoImpl regRepEodJobDetailsDaoImpl;

	@Transformer
	public Message<RegRepEodJobDetails> extractJobDetails(Message<?> message) throws MessagingException
	{
		logger.info("inside EodJobDetailsExtractorSvc extractJobDetails method");

		Object ipMessage = null;
		String errorString = null;
		RegRepEodJobRequest inRegRepEodJobRequest = null;
		Message<RegRepEodJobDetails> regRepEodJobDetailsMessage = null;
		String jobName = null;
		String asOfDate = null,cobDate=null;
		String [] onDemandParams = null;
		String fileData  = null;
		String onDemandParamsList = null;
		StringBuilder paramBuilder = null;
		Map<String,Object> jobInfoMap=new HashMap<String,Object>();
		String assetClass = null;
		String jurisdiction = null;
		String reportType = null;
		String dayFraction = "0";
		
		if (null == message)
		{
			errorString = "Null incoming message RegRepEodJobDetails";
			logger.error("########## " + errorString);
			throw new MessagingException("EodJobDetailsExtractorSvc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);
		}

		ipMessage = message.getPayload();
		if (ipMessage instanceof RegRepEodJobRequest)
		{
			inRegRepEodJobRequest = (RegRepEodJobRequest) ipMessage;
			jobName = inRegRepEodJobRequest.getJobName();
			reportType=inRegRepEodJobRequest.getReportType();
			jurisdiction=inRegRepEodJobRequest.getJurisdiction();
			assetClass=inRegRepEodJobRequest.getAssetClass();
			dayFraction="0";
		}
		else if (ipMessage instanceof File)
		{

			logger.info("eod onDemand job started by file watcher, jobName and asOfDate will be taken from file name or taken from config file");
			try
			{
				String onDemandFileName = null;
				String[] fileParams = null;

				int numParams = 0;
				File inFile = (File) ipMessage;
				if (null != inFile)
				{
					onDemandFileName = inFile.getName();
					onDemandFileName = StringUtils.substringBefore(onDemandFileName, ".");
					fileParams = onDemandFileName.split("_");
					numParams = fileParams.length;
					
					if(numParams ==1)
					{
						jobName = fileParams[0];
						dayFraction ="0";
					}
					else
					{
						jobName = fileParams[0];
						assetClass = fileParams[1];
						reportType= fileParams[2];
						jurisdiction = fileParams[3];
						dayFraction ="0";
						if(numParams == 5)
							dayFraction = fileParams[4];
					}
					//Params will be passed inside the file, separated with comma (,)
					
					fileData = org.apache.commons.io.FileUtils.readFileToString(inFile);
					if(null != fileData)
					{
						onDemandParams = fileData.split(",");
						if (Constants.EOD_REPORT_REFRESH_JOB.equals(jobName) || Constants.EOD_REPORT_INSERT_BUFFER_JOB.equals(jobName) || Constants.EOD_REPORT_INSERT_VALUATION_JOB.equals(jobName))
						{
							onDemandParamsList = fileData;
						} else if(onDemandParams!=null && onDemandParams.length>0)
							onDemandParamsList=Constants.SINGLE_QUOTE+StringUtils.join(onDemandParams,"','")+Constants.SINGLE_QUOTE;
					}
					
					inFile.delete();
				}

			}
			catch (Exception e)
			{
				errorString = "exception occurred while creating RegRepEodJobRequest  " + ExceptionUtils.getFullStackTrace(e);
				logger.error("########## " + errorString);
				throw new MessagingException("EodJobDetailsExtractorSvc-2", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, e.getMessage());

			}			

		}
		
		RegRepEodJobDetails eodJobDetails = null;
		try
		{
			if(Constants.EOD_DELTA_REPORT_JOB.equalsIgnoreCase(jobName) || Constants.EOD_FULL_REPORT_JOB.equalsIgnoreCase(jobName) || Constants.EOD_COMB_REPORT_JOB.equalsIgnoreCase(jobName))
				eodJobDetails = regRepEodJobDetailsDaoImpl.findByJobName(jobName,reportType,jurisdiction,assetClass);
			else
				eodJobDetails = regRepEodJobDetailsDaoImpl.findByJobName(jobName,Constants.NONE,Constants.NONE,Constants.NONE);			
		}
		catch (SQLException e)
		{
			errorString = "exception occurred while getting eod job details from DB  " + ExceptionUtils.getFullStackTrace(e);
			logger.error("########## " + errorString);
			throw new MessagingException("EodJobDetailsExtractorSvc-3", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, e.getMessage());
		}

		if (eodJobDetails == null)
		{
			errorString = "Could not find job in REG_REP_EOD_JOB_DETAILS table";
			logger.error("########## " + errorString);
			throw new MessagingException("EodJobDetailsExtractorSvc-4", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.EOD_ERROR, errorString);
		}
		
		 if(null != onDemandParamsList)
		 {
			eodJobDetails.setOnDemandParams(onDemandParamsList);
		 }
		 
		List<String> cobValues = new ArrayList<String>(realtimeConfig.getValues(Constants.CLOSE_OF_BUSINESS_DATE));
		List<String> valDateTimeValues = new ArrayList<String>(realtimeConfig.getValues(StringUtils.upperCase(jurisdiction+Constants.UNDERSCORE+assetClass),false));
		 
	 	jobInfoMap.put(Constants.EOD_JOB_NAME,jobName);
		jobInfoMap.put(Constants.EOD_JOB_COB_DATE, CalendarUtils.parseStringToDate(CalendarUtils.FORMAT_3, !GeneralUtils.IsListNullOrEmpty(cobValues)?cobValues.get(0):null));
		jobInfoMap.put(Constants.EOD_JOB_HEADER_AS_OF_DATE, CalendarUtils.getCurrentDateInUTC());
		jobInfoMap.put(Constants.REPORT_TYPE, reportType);
		jobInfoMap.put(Constants.JURISDICTION, jurisdiction);
		jobInfoMap.put(Constants.ASSET_CLASS, assetClass);
		jobInfoMap.put(Constants.EOD_DAY_FRACTION, dayFraction);
		jobInfoMap.put(Constants.EOD_JOB_VAL_TIME,!GeneralUtils.IsListNullOrEmpty(valDateTimeValues)?valDateTimeValues.get(0):null);
		
		regRepEodJobDetailsMessage = MessageBuilder.withPayload(eodJobDetails).setHeader(Constants.EOD_JOB_NAME, jobName).setHeader(Constants.EOD_JOB_INFO, jobInfoMap).build();

		// clear jobName and asOfDate for next run
		jobName = null;
		asOfDate = null;
		return regRepEodJobDetailsMessage;
	}

	
}
