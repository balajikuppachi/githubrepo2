package com.wellsfargo.regulatory.eod.data.cache;

import java.util.ArrayList;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodExtValDataDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodExtValData;

/**
 * @author Raji Komatreddy
 */
@Component
public class RegRepEodExtValDataCache
{
	@Autowired
	CacheManager cacheManager;

	@Autowired
	RegRepEodExtValDataDaoImpl regRepEodExtValDataDaoImpl;

	private Cache eodValuationCache = null;
	private Cache eodEquityValuationCache = null;

	private static Log logger = LogFactory.getLog(RegRepEodExtValDataCache.class);

	// load non Equity data from ExtValData into cache
	public void loadNpvDataToCache()
	{
		logger.info("inside RegRepEodExtValDataCache: loadNpvDataToCache method ");
		if (null != cacheManager)
		{
			try
			{

				eodValuationCache = cacheManager.getCache("eodValuationCache");

				eodValuationCache.removeAll();
				List<RegRepEodExtValData> eventsList = null;
				List<Element> eventElementList = new ArrayList<Element>();

				// get Data from RegRepEodExtValData table
				if (null != regRepEodExtValDataDaoImpl) 
					eventsList = regRepEodExtValDataDaoImpl.getNpvData();

				for (RegRepEodExtValData currEvent : eventsList)
				{

					if (null != currEvent.getFoTradeId())
					{
						Element currElement = new Element(currEvent.getFoTradeId().trim(), currEvent);
						eventElementList.add(currElement);
					}
					else
					{
						logger.info("no FoTrade ID for record received from  RegRepEodExtValData");

					}

				}

				eodValuationCache.putAll(eventElementList);

			}
			catch (Exception ex)
			{
				logger.error("exception occurred while loading non Equity data into RegRepEodExtValDataCache " + ExceptionUtils.getFullStackTrace(ex));
			}
		}

	}

	// load Equity data from ExtValData into cache

	public void loadEquityNpvDataToCache()
	{
		logger.info("inside RegRepEodExtValDataCache: loadNpvDataToCache method ");
		if (null != cacheManager)
		{
			try
			{

				eodEquityValuationCache = cacheManager.getCache("eodEquityValuationCache");

				eodEquityValuationCache.removeAll();
				List<RegRepEodExtValData> eventsList = null;
				List<Element> eventElementList = new ArrayList<Element>();

				// get Data from RegRepEodExtValData table
				if (null != regRepEodExtValDataDaoImpl) 
					eventsList = regRepEodExtValDataDaoImpl.getEquityNpvData();

				for (RegRepEodExtValData currEvent : eventsList)
				{

					if (null != currEvent.getFoTradeId())
					{
						Element currElement = new Element(currEvent.getFoTradeId().trim(), currEvent);
						eventElementList.add(currElement);
					}
					else
					{
						logger.info("no FoTrade ID for record received from  RegRepEodExtValData");

					}

				}

				eodEquityValuationCache.putAll(eventElementList);

			}
			catch (Exception ex)
			{
				logger.error("exception occurred while loading cache into RegRepEodExtValDataCache " + ExceptionUtils.getFullStackTrace(ex));
			}
		}

	}
	
	// Check in both Equity and NonEquity cache for ExtValData for a given tradeId

	public RegRepEodExtValData getValData(String tradeId, String assetClass)
	{
		RegRepEodExtValData currRegRepEodExtValData = null;
		
		try
		{		
				
			eodValuationCache = cacheManager.getCache("eodValuationCache");
		
			eodEquityValuationCache = cacheManager.getCache("eodEquityValuationCache");	
			Element currElement = 
					StringUtils.equalsIgnoreCase(assetClass, Constants.ASSET_CLASS_EQUITY)?eodEquityValuationCache.get(tradeId):eodValuationCache.get(tradeId);		
	
			if (null != currElement) 
				currRegRepEodExtValData = (RegRepEodExtValData) currElement.getObjectValue();			

		}
		catch(Exception ex)
		{
			logger.error("exception occurred while getting trade Data from cache " + ExceptionUtils.getFullStackTrace(ex));
			
		}

		return currRegRepEodExtValData;
	}

}
