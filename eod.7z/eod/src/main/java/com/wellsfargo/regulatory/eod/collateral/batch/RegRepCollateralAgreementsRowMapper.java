package com.wellsfargo.regulatory.eod.collateral.batch;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.wellsfargo.regulatory.commons.collateral.dto.RegRepCollateralAgreements;
import com.wellsfargo.regulatory.eod.collateral.batch.services.RegRepCollateralValRptMapperProcessor;



public class RegRepCollateralAgreementsRowMapper implements RowMapper<RegRepCollateralAgreements>
{
	private static Logger logger = Logger.getLogger(RegRepCollateralAgreementsRowMapper.class);
	
	@Override
    public RegRepCollateralAgreements mapRow(ResultSet rs, int rowNum) throws SQLException
    {
		logger.info("inside RegRepCollateralAgreementsRowMapper: mapRow method");
		
		RegRepCollateralAgreements currColAgrrement = new RegRepCollateralAgreements();
		currColAgrrement.setCaTotal(rs.getBigDecimal("total"));
		currColAgrrement.setPortfolioCode(rs.getString("portfolio_code"));
		currColAgrrement.setPrincipalId(rs.getString("principal_id"));
		currColAgrrement.setCaCcy(rs.getString("ca_ccy"));
		currColAgrrement.setCollateralPortfolio(rs.getString("collateral_portfolio"));
	  
	    return currColAgrrement;
    }

}
