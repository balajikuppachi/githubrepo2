/**
 * 
 */
package com.wellsfargo.regulatory.eod.writers;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.eod.dto.RegRepToRequest;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodToReport;

/**
 * @author u293876
 *
 */
@Component
public class CsvToWriter {
	
	Logger logger=Logger.getLogger(CsvToWriter.class.getName());
	static char SEPARATOR = ',';
	File file;
	FileWriter writer;
	
	@Autowired
	private FileStaticContent fileStaticContentGenerator;
	
public File irWrite(List<RegRepEodToReport> tradeList,String fileName, File targetFolder,RegRepToRequest request){
		
		file=new File(targetFolder,fileName);
		
		try{
			writer=new FileWriter(file);
			writeFileHeader(request.getAssetClass(), writer, fileName);
			if(request.getSdrRepository().equalsIgnoreCase("CAD"))
			{
			writer.append("Trade Date");
			}
			else 
			{
			writer.append("PARTY ID");
			}
			writer.append(SEPARATOR);
			writer.append("CP_ID");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 Prefix:Trade Party 1 Value");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 Prefix:Trade Party 2 Value");
			writer.append(SEPARATOR);
			writer.append("TRADE_ID");
			writer.append(SEPARATOR);
			writer.append("USI Prefix:USI Value");
			writer.append(SEPARATOR);
			writer.append("Product ID Prefix:Product ID Value");
			writer.append(SEPARATOR);
			writer.append("PRODUCT_CLASS");
			writer.append(SEPARATOR);
			writer.append("Leg 1 Payer");
			writer.append(SEPARATOR);
			writer.append("Notional Amount - leg 1 or Notional Amount (FRA)");
			writer.append(SEPARATOR);
			writer.append("Notional Currency - leg 1");
			writer.append(SEPARATOR);
			writer.append("Notional Amount - leg 2");
			writer.append(SEPARATOR);
			writer.append("Notional Currency - leg 2");
			writer.append(SEPARATOR);
			writer.append("Effective Date - leg 1");
			writer.append(SEPARATOR);
			writer.append("Trade Date");
			writer.append(SEPARATOR);
			writer.append("Termination Date (unadjusted) - leg 1");
			writer.append(SEPARATOR);
			writer.append("Reporting Jurisdiction");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 Role");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 Role");
			writer.append(SEPARATOR);
			writer.append("Payment Frequency period - leg 1:Payment Frequency period multiplier - leg 1");
			writer.append(SEPARATOR);
			writer.append("Fixed Rate (initial) - leg 1");
			writer.append(SEPARATOR);
			writer.append("Day Count Fraction - leg 1");
			writer.append(SEPARATOR);
			writer.append("Day Count Fraction - leg 2");
			writer.append(SEPARATOR);
			writer.append("Additional Repository 1 Prefix:Additional Repository 1");
			writer.append(SEPARATOR);
			writer.append("Collateralized");
			writer.append(SEPARATOR);
			writer.append("Execution Venue Prefix:Execution Venue");
			writer.append(SEPARATOR);
			writer.append("Optional Early Termination Exercise Style");
			writer.append(SEPARATOR);
			writer.append("Floating Rate Tenor period - leg 1");
			writer.append(SEPARATOR);
			writer.append("Payment Frequency period - leg 1");
			writer.append(SEPARATOR);
			writer.append("Floating Rate Index - leg 1");
			writer.append(SEPARATOR);
			writer.append("Reset Frequency period multiplier - leg 1:Reset Frequency period - leg 1");
			writer.append(SEPARATOR);
			writer.append("Floating Rate Tenor period - leg 2");
			writer.append(SEPARATOR);
			writer.append("Payment Frequency period - leg 2");
			writer.append(SEPARATOR);
			writer.append("Floating Rate Index - leg 2");
			writer.append(SEPARATOR);
			writer.append("Reset Frequency period multiplier - leg 2:Reset Frequency period - leg 2");
			writer.append(SEPARATOR);
			writer.append("Submitted For Prefix:Submitted For Value");
			writer.append(SEPARATOR);
			writer.append("Trade Party 2 US Person Indicator");
			writer.append(SEPARATOR);
			writer.append("Trade Party 1 US Person Indicator");
			writer.append(SEPARATOR);
			writer.append("Option type");
			writer.append(SEPARATOR);
			writer.append("Secondary Asset Class");
			writer.append(SEPARATOR);
			writer.append("leg 2 payer");
			writer.append(SEPARATOR);
			writer.append("Buyer");
			writer.append(SEPARATOR);
			writer.append("Seller");
			writer.append(SEPARATOR);
			writer.append("Effective Date - leg 2");
			writer.append(SEPARATOR);
			writer.append("Fixed Rate (initial) - leg 2");
			writer.append(SEPARATOR);
			writer.append("Reporting Party");


			writer.append('\n');
			for(RegRepEodToReport trade:tradeList){
				if(request.getSdrRepository().equalsIgnoreCase("CAD"))
				{
					writer.append(Constants.EMPTY_STRING);
				}
				else 
				{
					writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
				}
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
				//writer.append(trade.getRegRepTrioptima().getTradeParty1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
				//writer.append(trade.getRegRepTrioptima().getTradeParty2());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
				//writer.append(trade.getRegRepTrioptima().getTradeId());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
				//writer.append(trade.getRegRepTrioptima().getUsi());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
				//writer.append(trade.getRegRepTrioptima().getProductId());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
				//writer.append(trade.getRegRepTrioptima().getProductClass());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getLeg1Payer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getLeg1Payer()));
				//writer.append(trade.getRegRepTrioptima().getLeg1Payer());
				writer.append(SEPARATOR);
				writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString());
				//writer.append(trade.getRegRepTrioptima().getNotionalAmountLeg1().toString());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
				//writer.append(trade.getRegRepTrioptima().getNotionalCurrencyLeg1());
				writer.append(SEPARATOR);
				writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg2().toString());
				//writer.append(trade.getRegRepTrioptima().getNotionalAmountLeg2().toString());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getNotionalCurrencyLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg2()));
				//writer.append(trade.getRegRepTrioptima().getNotionalCurrencyLeg2());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getEffectiveDateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDateLeg1()));
				//writer.append(trade.getRegRepTrioptima().getEffectiveDateLeg1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
				//writer.append(trade.getRegRepTrioptima().getTradeDate());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTerminationDateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTerminationDateLeg1()));
				//writer.append(trade.getRegRepTrioptima().getTerminationDateLeg1());
				writer.append(SEPARATOR);
				writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
				//writer.append(trade.getJurisdiction());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
				//writer.append(trade.getRegRepTrioptima().getTradeParty2Role());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
				//writer.append(trade.getRegRepTrioptima().getTradeParty1Role());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPaymentFreqMultiplierLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPaymentFreqMultiplierLeg1()));
				//writer.append(trade.getRegRepTrioptima().getPaymentFreqMultiplierLeg1());
				writer.append(SEPARATOR);
				writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getFixedRateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFixedRateLeg1().toString());
				//writer.append(trade.getRegRepTrioptima().getFixedRateLeg1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getDayCountFractionLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getDayCountFractionLeg1()));
				//writer.append(trade.getRegRepTrioptima().getDayCountFractionLeg1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getDayCountFractionLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getDayCountFractionLeg2()));
				//writer.append(trade.getRegRepTrioptima().getDayCountFractionLeg2());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
				//writer.append(trade.getRegRepTrioptima().getAdditionalRepository());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
				//writer.append(trade.getRegRepTrioptima().getCollateralized());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
				//writer.append(trade.getRegRepTrioptima().getExecutionVenue());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getOptionalEarlyTermination())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getOptionalEarlyTermination()));
				//writer.append(trade.getRegRepTrioptima().getOptionalEarlyTermination());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getFloatingRateTenorLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFloatingRateTenorLeg1()));
				//writer.append(trade.getRegRepTrioptima().getFloatingRateTenorLeg1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPaymentFreqLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPaymentFreqLeg1()));
				//writer.append(trade.getRegRepTrioptima().getPaymentFreqLeg1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getFloatingRateIndexLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFloatingRateIndexLeg1()));
				//writer.append(trade.getRegRepTrioptima().getFixedRateLeg1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getResetFreq1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getResetFreq1()));
				//writer.append(trade.getRegRepTrioptima().getResetFreq1());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getFloatingRateTenorLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFloatingRateTenorLeg2()));
				//writer.append(trade.getRegRepTrioptima().getFloatingRateTenorLeg2());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPaymentFreqLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPaymentFreqLeg2()));
				//writer.append(trade.getRegRepTrioptima().getPaymentFreqLeg2());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getFloatingRateIndexLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFloatingRateIndexLeg2()));
				//writer.append(trade.getRegRepTrioptima().getFixedRateLeg2());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getResetFreq2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getResetFreq2()));
				//writer.append(trade.getRegRepTrioptima().getResetFreq2());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSubmittor())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSubmittor()));
				//writer.append(trade.getRegRepTrioptima().getSubmittor());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
				//writer.append(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
				//writer.append(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getOptionType())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getOptionType()));
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getLeg2Payer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getLeg2Payer()));
				writer.append(SEPARATOR);
				if(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getBuyer()))
						writer.append(Constants.EMPTY_STRING);
				else
				writer.append('"').append(trade.getRegRepTrioptima().getBuyer()).append('"');
				
				writer.append(SEPARATOR);
				
				if(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSeller()))
					writer.append(Constants.EMPTY_STRING);
				else
				writer.append('"').append(trade.getRegRepTrioptima().getSeller()).append('"');
				writer.append(SEPARATOR);
				
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getEffectiveDateLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDateLeg2()));
				writer.append(SEPARATOR);
				writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getFixedRateLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFixedRateLeg2().toString());
				writer.append(SEPARATOR);
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
				
				writer.append('\n');
				
			}
			
			}catch(Exception e){
				e.printStackTrace();
				logger.error(e);
			}
			finally{
				try{
					writeFileFooter(request.getAssetClass(), writer, tradeList);
				writer.flush();
				writer.close();
				}catch(Exception e){
					logger.error(e);
				}
			}
		return file;
			
}

public File crWrite(List<RegRepEodToReport> tradeList,String fileName, File targetFolder,RegRepToRequest request){
	
	file=new File(targetFolder,fileName);
	try{
		writer=new FileWriter(file);
		writeFileHeader(request.getAssetClass(), writer, fileName);
		if(request.getSdrRepository().equalsIgnoreCase("CAD"))
		{
		writer.append("Trade Date");
		}
		else 
		{
		writer.append("PARTY ID");
		}
		writer.append(SEPARATOR);
		writer.append("CP_ID");
		writer.append(SEPARATOR);
		writer.append("Trade Party 1 Prefix:Trade Party 1 Value");
		writer.append(SEPARATOR);
		writer.append("Trade Party 2 Prefix:Trade Party 2 Value");
		writer.append(SEPARATOR);
		writer.append("TRADE_ID");
		writer.append(SEPARATOR);
		writer.append("USI Prefix:USI Value");
		writer.append(SEPARATOR);
		writer.append("Product ID Prefix:Product ID Value");
		writer.append(SEPARATOR);
		writer.append("PRODUCT_CLASS");
		writer.append(SEPARATOR);
		writer.append("Buyer prefix:Buyer value");
		writer.append(SEPARATOR);
		writer.append("Notional Amount - leg 1 or Notional Amount (FRA)");
		writer.append(SEPARATOR);
		writer.append("Notional Currency - leg 1");
		writer.append(SEPARATOR);
		writer.append("Effective Date - leg 1");
		writer.append(SEPARATOR);
		writer.append("Trade Date");
		writer.append(SEPARATOR);
		writer.append("Scheduled Termination Date");
		writer.append(SEPARATOR);
		writer.append("Reporting Jurisdiction");
		writer.append(SEPARATOR);
		writer.append("Underlying Asset");
		writer.append(SEPARATOR);
		writer.append("Trade Party 2 Role");
		writer.append(SEPARATOR);
		writer.append("Trade Party 1 Role");
		writer.append(SEPARATOR);
		writer.append("Payment Frequency period - leg 1:Payment Frequency period multiplier - leg 1");
		writer.append(SEPARATOR);
		writer.append("Fixed Rate (per annum)");
		writer.append(SEPARATOR);
		writer.append("Additional Repository 1 Prefix:Additional Repository 1 Value");
		writer.append(SEPARATOR);
		writer.append("Collateralized");
		writer.append(SEPARATOR);
		writer.append("Execution Venue Prefix:Execution Venue");
		writer.append(SEPARATOR);
		writer.append("Submitted For Prefix:Submitted For Value");
		writer.append(SEPARATOR);
		writer.append("Trade Party 2 US Person Indicator");
		writer.append(SEPARATOR);
		writer.append("Trade Party 1 US Person Indicator");
		writer.append(SEPARATOR);
		writer.append("Secondary Asset Class");
		writer.append(SEPARATOR);
		writer.append("Option Strike Price");
		writer.append(SEPARATOR);
		writer.append("Reporting Party");


		writer.append('\n');
		for(RegRepEodToReport trade:tradeList){
			if(request.getSdrRepository().equalsIgnoreCase("CAD"))
			{
				writer.append(Constants.EMPTY_STRING);
			}
			else 
			{
				writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
			}
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
			//writer.append(trade.getRegRepTrioptima().getProductClass());
			writer.append(SEPARATOR);
			//Buyer prefix:Buyer value
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getBuyer())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getBuyer()));
			writer.append(SEPARATOR);
			
			writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString());
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getEffectiveDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDate()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSchedTerminationDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSchedTerminationDate()));
			writer.append(SEPARATOR);
			writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUnderlyingAsset())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUnderlyingAsset()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPaymentFreqMultiplierLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPaymentFreqMultiplierLeg1()));
			writer.append(SEPARATOR);
			writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getFixedRateLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFixedRateLeg1().toString());
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSubmittor())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSubmittor()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getOptionStrikePrice())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getOptionStrikePrice()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
			
			writer.append('\n');
		}
		
		}catch(Exception e){
			e.printStackTrace();
			logger.error(e);
		}
		finally{
			try{
				writeFileFooter(request.getAssetClass(), writer, tradeList);
			writer.flush();
			writer.close();
			}catch(Exception e){
				logger.error(e);
			}
		}
	return file;
		
}

public File fxWrite(List<RegRepEodToReport> tradeList,String fileName, File targetFolder,RegRepToRequest request){
	
	file=new File(targetFolder,fileName);
	try{
		writer=new FileWriter(file);
		writeFileHeader(request.getAssetClass(), writer, fileName);
		writer.append("PARTY_ID");
		writer.append(SEPARATOR);
		writer.append("CP_ID");
		writer.append(SEPARATOR);
		writer.append("Trade Party 1 Prefix:Trade Party 1 Value");
		writer.append(SEPARATOR);
		writer.append("Trade Party 2 Prefix:Trade Party 2 Value");
		writer.append(SEPARATOR);
		writer.append("TRADE_ID");
		writer.append(SEPARATOR);
		writer.append("USI Prefix:USI Value");
		writer.append(SEPARATOR);
		writer.append("Product ID Prefix:Product ID Value");
		writer.append(SEPARATOR);
		writer.append("PRODUCT_CLASS");
		writer.append(SEPARATOR);
		writer.append("Put Notional Amount");
		writer.append(SEPARATOR);
		writer.append("Put Notional Currency");
		writer.append(SEPARATOR);
		writer.append("Call Notional Amount");
		writer.append(SEPARATOR);
		writer.append("Call Notional Currency");
		writer.append(SEPARATOR);
		writer.append("Effective Date");
		writer.append(SEPARATOR);
		writer.append("Trade Date");
		writer.append(SEPARATOR);
		writer.append("Expiration Date");
		writer.append(SEPARATOR);
		writer.append("Reporting Jurisdiction");
		writer.append(SEPARATOR);
		writer.append("Trade Party 2 Role");
		writer.append(SEPARATOR);
		writer.append("Trade Party 1 Role");
		writer.append(SEPARATOR);
		writer.append("Additional Repository 1 Prefix:Additional Repository 1");
		writer.append(SEPARATOR);
		writer.append("Collateralized");
		writer.append(SEPARATOR);
		writer.append("Execution Venue Prefix:Execution Venue");
		writer.append(SEPARATOR);
		writer.append("Option style");
		writer.append(SEPARATOR);
		writer.append("Final Settlement Date");
		writer.append(SEPARATOR);
		writer.append("Submitted For Prefix:Submitted For Value");
		writer.append(SEPARATOR);
		writer.append("Trade Party 2 US Person Indicator");
		writer.append(SEPARATOR);
		writer.append("Trade Party 1 US Person Indicator");
		writer.append(SEPARATOR);
		writer.append("Secondary Asset Class");
		writer.append(SEPARATOR);
		writer.append("FX Delivery Type");
		writer.append(SEPARATOR);
		writer.append("Reporting Party");


		writer.append('\n');
		for(RegRepEodToReport trade:tradeList){
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getPartyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getPartyId()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCptyId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCptyId()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeId()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getUsi())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getUsi()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductId())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductId()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getProductClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getProductClass()));
			writer.append(SEPARATOR);	
			writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg1().toString().toString());
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getNotionalCurrencyLeg1())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg1()));
			writer.append(SEPARATOR);
			writer.append(GeneralUtils.IsNull(trade.getRegRepTrioptima().getNotionalAmountLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalAmountLeg2().toString());
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getNotionalCurrencyLeg2())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getNotionalCurrencyLeg2()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getEffectiveDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getEffectiveDate()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeDate()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExpirationDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExpirationDate()));
			writer.append(SEPARATOR);
			writer.append('"').append(GeneralUtils.IsNullOrBlank(trade.getJurisdiction())?Constants.EMPTY_STRING:trade.getJurisdiction()).append('"');
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2Role()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1Role())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1Role()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getAdditionalRepository())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getAdditionalRepository()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getCollateralized())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getCollateralized()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getExecutionVenue())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getExecutionVenue()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getOptionStyle())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getOptionStyle()));
			
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getFinalSettlementDate())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFinalSettlementDate()));
			
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSubmittor())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSubmittor()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty2UsPersonIndicator()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getTradeParty1UsPersonIndicator()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getSecondaryAssetClass())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getSecondaryAssetClass()));
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getFxDeliveryType())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getFxDeliveryType()));
			
			writer.append(SEPARATOR);
			writer.append(csvCommaField(GeneralUtils.IsNullOrBlank(trade.getRegRepTrioptima().getReportingParty())?Constants.EMPTY_STRING:trade.getRegRepTrioptima().getReportingParty()));
			
			
			writer.append('\n');
		}
		
		}catch(Exception e){
			e.printStackTrace();
			logger.error(e);
		}
		finally{
			try{
				writeFileFooter(request.getAssetClass(), writer, tradeList);
			writer.flush();
			writer.close();
			}catch(Exception e){
				e.printStackTrace();
				logger.error(e);
			}
		}
	return file;
		
}

private void writeFileFooter(String assetClass,FileWriter out,List<RegRepEodToReport> tradeList)
		throws IOException {
	//Writing File Footer
	out.write(fileStaticContentGenerator.getAPPLICATION_TRAILER(assetClass));
	writer.append('\n');
	out.write(fileStaticContentGenerator.getDATATRAK_TRAILER(tradeList.size(), assetClass));
}

private void writeFileHeader(String assetClass, FileWriter out,
		 String fileName)
		throws IOException, ParseException {
	out.write(fileStaticContentGenerator.getDATATRAK_HEADER(assetClass));
	writer.append('\n');
	out.write(fileStaticContentGenerator.getAPPLICATION_HEADER(fileName, assetClass));
	writer.append('\n');

		
}
private String csvCommaField(String s)
{
	StringBuilder sb = new StringBuilder();
	
	if(s.contains(Constants.COMMA)) {
		if(!s.startsWith(("\"")) && !s.endsWith("\""))
		{
			sb = sb.append("\"").append(s).append("\"");
		}
		s  = sb.toString();
	}
	return s;
}

}
