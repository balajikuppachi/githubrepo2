package com.wellsfargo.regulatory.eod.writers;

import java.io.StringReader;
import java.util.List;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.oxm.Unmarshaller;
import com.wellsfargo.regulatory.commons.beans.ReportingContext;
import com.wellsfargo.regulatory.commons.bo.sdrRequest.SdrRequest;
import com.wellsfargo.regulatory.commons.enums.PayloadTypeEnum;
import com.wellsfargo.regulatory.persister.rowMapper.RegRepEodRefreshMessage;

public class EodRefreshWriter implements ItemWriter<RegRepEodRefreshMessage>
		, StepExecutionListener {
	
	private static Logger logger = Logger
			.getLogger(EodRefreshWriter.class.getName());
	
	private MessageChannel eodRefreshChannel;
	
	
	@Autowired
	@Qualifier("sdrRequestJaxbMarshaller")
	private Unmarshaller unmarshaller;
	
	@Override
	public ExitStatus afterStep(StepExecution arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void beforeStep(StepExecution arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void write(List<? extends RegRepEodRefreshMessage> msgs)
			throws Exception {
		
		logger.info(" Entering Writer");
		
		
		Message<?> messageOut 		= null;
		
		if(null == msgs
				|| msgs.size() < 1){
			
			logger.error("Invalid submssion set recieved");
			return;
		}
		
		logger.info("No. of items to write --> "+msgs.size());
		
		for(RegRepEodRefreshMessage msg : msgs){
			
			if(null == msg)
				continue;
			
			//messageOut = MessageBuilder.withPayload(payload).build();
			messageOut = createPayloadForEodRefresh(msg);
			
			eodRefreshChannel.send(messageOut);
		}
		
		logger.debug(" Exiting Refresh Writer ");

	}
	
	public void setRegRepInputChannel(MessageChannel regRepInputChannel){
		
		this.eodRefreshChannel = regRepInputChannel;
	}
	
	
	public void setEodRefreshChannel(MessageChannel eodRefreshChannel) {
		this.eodRefreshChannel = eodRefreshChannel;
	}

	private Message<?> createPayloadForEodRefresh(RegRepEodRefreshMessage message)
	{
		Message<?> messageOut 			= null;
		ReportingContext repContext 	= null;
		SdrRequest trade 				= null;
		Object parsedObject 			= null;
		StringReader payLoadStream 		= null;
		String sdrMsgId 				= message.getMessageId();

		
		repContext = ReportingContext.getInstance();
		
		repContext.setMessageId(sdrMsgId);
		repContext.setMessageSource("REG_REP_REQUEST");
		repContext.setEodRefreshRptId(message.getEodReportId());
		repContext.setEodRefreshRptType(message.getReportType());
		repContext.setPayload(message.getPayload());
		repContext.setEodRefreshJurisdiction(message.getJurisdiction());
	
		payLoadStream 	= new StringReader(message.getPayload());
			
		try 
		{
			parsedObject 	= unmarshaller.unmarshal(new StreamSource(payLoadStream));
			
			trade = (SdrRequest) parsedObject;
			
			repContext.initializeContext(trade, sdrMsgId, PayloadTypeEnum.REG_REP_XML, repContext);
			
		} catch (Exception e) {
			
			logger.error("Exception in refresh sevice while creating reporting Context for original EOD_REPORT_ID: "+ message.getEodReportId());
		
		} 
		
		if (trade!= null)
		{
			repContext.setSwapTradeId(trade.getTrade().getTradeHeader().getTradeId());
		}
		repContext.setEodRefresh(true);
		
		
		messageOut =  MessageBuilder.withPayload(repContext).build();
		
		return messageOut;
		
	}
	
	public void setUnmarshaller(Unmarshaller unmarshaller)
	{
		this.unmarshaller = unmarshaller;
	}
}
