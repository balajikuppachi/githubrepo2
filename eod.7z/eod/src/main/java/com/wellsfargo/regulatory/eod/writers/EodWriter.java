package com.wellsfargo.regulatory.eod.writers;

/**
 * @author Amit Rana
 * @date 07/17/2015
 * @version 1.0
 */

import static com.wellsfargo.regulatory.commons.keywords.Constants.MESSAGE_TYPE_VALUATION;

import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.regulatory.commons.enums.ExceptionSeverityEnum;
import com.wellsfargo.regulatory.commons.enums.ExceptionTypeEnum;
import com.wellsfargo.regulatory.commons.keywords.Constants;
import com.wellsfargo.regulatory.commons.utils.GeneralUtils;
import com.wellsfargo.regulatory.eod.data.cache.RegRepEodExtValDataCache;
import com.wellsfargo.regulatory.eod.data.cache.RegRepUniqueIdentifierMappingCache;
import com.wellsfargo.regulatory.eod.exception.EodExceptionLogger;
import com.wellsfargo.regulatory.eod.exception.RegRepEodException;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmission;
import com.wellsfargo.regulatory.persister.dto.RegRepEodSubmissionTracker;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodSubmissionsDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dao.RegRepEodSubmissionsTrackerDaoImpl;
import com.wellsfargo.regulatory.persister.eod.dto.RegRepEodExtValData;
import com.wellsfargo.regulatory.persister.util.dataSource.ConnectionManager;


public class EodWriter implements ItemWriter<RegRepEodSubmission>, StepExecutionListener
{
	private static Logger logger = Logger.getLogger(EodWriter.class.getName());

	@Autowired
	private static EodQueueWriter qWriter;

	@Autowired
	private ConnectionManager manager;

	@Autowired
	private EodExceptionLogger eodExceptionLogger;
	
	private static AtomicLong uniqueLongId;

	private final TimeZone UTC = TimeZone.getTimeZone("UTC");

	private JobExecution jobExecution;

	@Autowired
	EodBufferUpdater eodBufferUpdater;

	@Autowired
	RegRepEodSubmissionsDaoImpl regRepEodSubmissionsDaoImpl;

	@Autowired
	RegRepEodSubmissionsTrackerDaoImpl regRepEodSubmissionsTrackerDaoImpl;
	
	@Autowired
	RegRepEodExtValDataCache regRepEodExtValDataCache;
	
	@Autowired
	private   RegRepUniqueIdentifierMappingCache regRepUniqueIdentifierMappingCache;

	private List<String> missionValuationFinalList; 
	private String mqPublishIssue;

	@Override
	public ExitStatus afterStep(StepExecution stepExecution)
	{
	
		stepExecution.getJobExecution().getExecutionContext().put(Constants.VALUATION_DATA_MISSING_LIST, missionValuationFinalList);
		stepExecution.getJobExecution().getExecutionContext().put(Constants.MQ_PUBLISH_ISSUE, mqPublishIssue);

		return null;
	}

	@Override
	public void beforeStep(StepExecution stepExecution)
	{
		jobExecution = stepExecution.getJobExecution();
		missionValuationFinalList = new ArrayList<String>();
		mqPublishIssue = null;
	}

	@Override
	public void write(List<? extends RegRepEodSubmission> submissions) throws Exception
	{
		logger.debug(" Entering Writer ");

		if (null == submissions || submissions.size() < 1)
		{
			logger.error("######### Invalid submssion set recieved");
			return;
		}

		Date asofDate = jobExecution.getJobParameters().getDate(Constants.EOD_JOB_HEADER_AS_OF_DATE);
		Date cobDate = jobExecution.getJobParameters().getDate(Constants.EOD_JOB_COB_DATE);
		String valTimeArr[]= StringUtils.split(jobExecution.getJobParameters().getString(Constants.EOD_JOB_VAL_TIME),Constants.COLON);
		
		logger.info("No. of items to write --> " + submissions.size());

		submissions = updateSubmissions(submissions, asofDate, cobDate,valTimeArr);

		writeSubmissions(submissions, cobDate);
		
		/** below code is to persist submission in to REG_REP_EOD_SUBMISSION_TRACKER */
		writeInToSubmissionsTracker(submissions,cobDate);

		logger.debug(" Exiting Writer ");
	}

	

	private void writeSubmissions(List<? extends RegRepEodSubmission> submissions, Date cobDate) throws Exception
	{
		boolean success = false;
		List<RegRepEodSubmission> data = null;

		int numRecInserted = 0;

		if (null == submissions || submissions.size() < 1)
		{
			logger.error("######### Invalid incoming submission list.");
			return;
		}

		try
		{

			data = new ArrayList<RegRepEodSubmission>(submissions);
			numRecInserted = regRepEodSubmissionsDaoImpl.batchInsertEodSubmission(data, cobDate);

			logger.debug("Number of records inserted into EodSubmission table  .... " + numRecInserted);

			success = qWriter.publishMessages(data);
			//success = true;

			if (success) 
				logger.debug("EOD Batch messages are sent for submission .... ");
			else
				mqPublishIssue = "true";

		}
		catch (Exception ex)
		{
			logger.error("######### Exception occurred inside RegRepEodSubmissionsDaoImpl:  batchInsertEodSubmission method- " + ExceptionUtils.getFullStackTrace(ex));
		}

	}

	private List<? extends RegRepEodSubmission> updateSubmissions(List<? extends RegRepEodSubmission> submissions, Date asofDate, Date cobDate, String[] valTimeArr) throws Exception
	{
		String report = null;
		String tradeId = null;
		String reportType = null;
		RegRepEodSubmission submission = null;
		Long submsnId = null;
		List<? extends RegRepEodSubmission> newList = null;
		ListIterator<? extends RegRepEodSubmission> iterator = null;
		RegRepEodExtValData data = new RegRepEodExtValData();

		newList = new ArrayList<>(submissions);
		iterator = newList.listIterator();
		
		List<String> missingValList = new ArrayList<String>();

		while (iterator.hasNext())
		{
			submission = iterator.next();

			if (null == submission) 
				continue;

			report = submission.getSdrReport();
			reportType = submission.getReportType();
			tradeId = submission.getTradeId();

			if (null == report || null == tradeId || null == reportType) 
				continue;

			submsnId = getUniqueLongId();

			submission.setSubmissionId(submsnId);

			if (Constants.ASSET_CLASS_FOREX.equals(submission.getAssetClass())
			        && (StringUtils.endsWith(tradeId, Constants.FOREX_SWAP_LEG_NEAR) || StringUtils.endsWith(tradeId, Constants.FOREX_SWAP_LEG_FAR)))
				tradeId = StringUtils.substring(tradeId, 0, tradeId.length() - 2);

			// data = mpvMap.get(tradeId);
			data = regRepEodExtValDataCache.getValData(tradeId.trim(), submission.getAssetClass());

			if (MESSAGE_TYPE_VALUATION.equals(reportType) && null == data)
			{
				logger.warn(">>>>>>>>> This is where valuation data is not found. Hence removing that Val record from submission list <<<<<<<<<. TradeId : " + tradeId);
				iterator.remove();
			
				missingValList.add(submission.getTradeId());
				
				continue;
			}

			report = eodBufferUpdater.updateWithLatestValData(submission, report, data, reportType, submsnId, asofDate, cobDate,valTimeArr);

			submission.setSdrReport(report);
		}
		
		//accumulate all trades which are not having valuation data
		if(missingValList.size() > 0)
		{
			missionValuationFinalList.addAll(missingValList);
			
			missingValList.clear();
		}

		return newList;
	}

	public long getUniqueLongId() throws Exception
	{
		long id = -1L;

		if (null == uniqueLongId) 
			uniqueLongId = new AtomicLong(getDBId());

		id = uniqueLongId.incrementAndGet();
		// uniqueID = Math.abs(random.nextLong()) + id;

		return id;
	}

	private Long getDBId() throws Exception
	{
		Long initialId = null;
		try
		{
			initialId = regRepEodSubmissionsDaoImpl.getMaxSubmissionId();
			if (null == initialId) 
				initialId = 0L;

		}
		catch (Exception e)
		{
			logger.error("######### Error getting the initial submission Id ", e);
			throw e;
		}
		return initialId;
	}

	public static void setqWriter(EodQueueWriter qWriter)
	{
		EodWriter.qWriter = qWriter;
	}

	

	public List<RegRepEodSubmission> handleBatchInserts(List<RegRepEodSubmission> submissionData, PreparedStatement pStmt, List<RegRepEodSubmission> failedSubmissions, Date cobDate) throws Exception
	{
		List<RegRepEodSubmission> dataLeft = null;
		List<RegRepEodSubmission> dataRight = null;
		Date asOfDate = null;
		Date insrtTime = null;
		Date submsnTime = null;
		String status = null;
		String sdrReport = null;
		String eodRptId = null;
		String tradeId = null;
		String reportType = null;
		Long submsnId = null;
		boolean lastRecord = false;

		int mid = submissionData.size() / 2;

		if (mid < 1)
		{
			lastRecord = true;
		}

		try
		{
			// insert entire data
			for (RegRepEodSubmission eodSubmsn : submissionData)
			{
				eodRptId = eodSubmsn.getEodReportId();
				asOfDate = eodSubmsn.getAsOfDate();
				sdrReport = eodSubmsn.getSdrReport();
				insrtTime = eodSubmsn.getInsertTimestamp();
				submsnTime = eodSubmsn.getSubmissionTimestamp();
				status = eodSubmsn.getStatus();
				submsnId = eodSubmsn.getSubmissionId();
				tradeId = eodSubmsn.getTradeId();
				reportType = eodSubmsn.getReportType();

				pStmt.setString(1, eodRptId);
				pStmt.setTimestamp(2, ((asOfDate == null) ? null : new Timestamp(asOfDate.getTime())));
				pStmt.setString(3, sdrReport);
				pStmt.setString(4, status);
				pStmt.setString(5, tradeId);
				pStmt.setString(6, reportType);
				pStmt.setTimestamp(7, ((insrtTime == null) ? null : new Timestamp(insrtTime.getTime())), Calendar.getInstance(UTC));
				pStmt.setTimestamp(8, ((submsnTime == null) ? null : new Timestamp(submsnTime.getTime())), Calendar.getInstance(UTC));
				pStmt.setLong(9, submsnId);
				pStmt.setDate(10, new java.sql.Date(cobDate.getTime()));

				pStmt.addBatch();
			}

			pStmt.executeUpdate();
		}
		catch (Exception e)
		{
			if (lastRecord)
			{
				if (null == failedSubmissions) failedSubmissions = new ArrayList<RegRepEodSubmission>();

				failedSubmissions.addAll(submissionData);

				try
				{
					logException(submissionData, e);
				}
				catch (Exception ex)
				{
					logger.error("######### Failed to log exception records for failed EOD submissions - " + ExceptionUtils.getFullStackTrace(ex));
					// throw ex;
				}
			}
			else
			{
				dataLeft = submissionData.subList(0, mid);
				dataRight = submissionData.subList(mid, submissionData.size());

				handleBatchInserts(dataLeft, pStmt, failedSubmissions, cobDate);
				handleBatchInserts(dataRight, pStmt, failedSubmissions, cobDate);
			}
		}

		return failedSubmissions;
	}

	private void logException(List<RegRepEodSubmission> data, Exception e) throws Exception
	{
		List<RegRepEodException> exceptions = null;
		RegRepEodException exception = null;

		if (null == data || null == e)
			return;

		for (RegRepEodSubmission submission : data)
		{
			if (null == exceptions)
				exceptions = new ArrayList<>(data.size() * 2);

			exception = new RegRepEodException("Eod-Exc-1", ExceptionSeverityEnum.ERROR, ExceptionTypeEnum.REG_REP_ERROR, StringUtils.trimToEmpty(e.getMessage()));
			exception.setDescription(StringUtils.trimToEmpty(e.getMessage()));
			exception.setSubmissionId(submission.getEodReportId());

			exceptions.add(exception);
		}

		if (null != exceptions && exceptions.size() > 0) 
			eodExceptionLogger.persistEodExceptions(exceptions);
	}
	
		
	
	private void writeInToSubmissionsTracker(List<? extends RegRepEodSubmission> submissions, Date cobDate) 
	{
		
		List<RegRepEodSubmissionTracker> submissionTrackerList=new ArrayList<RegRepEodSubmissionTracker>();
		try {
			for (RegRepEodSubmission regRepEodSubmission : submissions) 
			{
				
				String dtccUsi=regRepUniqueIdentifierMappingCache.getTradeUsiMapping(regRepEodSubmission.getTradeId(),cobDate);
				String calUSi=regRepEodSubmission.getTradeUsi();
				
				if(!GeneralUtils.IsNullOrBlank(calUSi) && StringUtils.contains(calUSi, Constants.GTRCREATE))
					calUSi=dtccUsi;
					
				String calUti=regRepEodSubmission.getTradeUti();
				if(!GeneralUtils.IsNullOrBlank(calUti) && StringUtils.contains(calUti, Constants.GTRCREATE))
					calUti=dtccUsi;
								
				RegRepEodSubmissionTracker eodSubmsnTracker= new RegRepEodSubmissionTracker();
				eodSubmsnTracker.setSubmissionId(regRepEodSubmission.getSubmissionId());
				eodSubmsnTracker.setEodReportId(regRepEodSubmission.getEodReportId());
				eodSubmsnTracker.setRegRepMessageId(regRepEodSubmission.getRegRepMessageId());
				eodSubmsnTracker.setTradeId(regRepEodSubmission.getTradeId());
				eodSubmsnTracker.setTradeUsi(calUSi);
				eodSubmsnTracker.setTradeUti(calUti);
				eodSubmsnTracker.setEventType(regRepEodSubmission.getEventType());
				eodSubmsnTracker.setReportType(regRepEodSubmission.getReportType());
				eodSubmsnTracker.setJurisdiction(regRepEodSubmission.getJurisdiction());
				eodSubmsnTracker.setAssetClass(regRepEodSubmission.getAssetClass());
				eodSubmsnTracker.setRepository(Constants.DTCC);
				eodSubmsnTracker.setParty1LeiPrefix(null);
				eodSubmsnTracker.setParty1Lei(null);
				eodSubmsnTracker.setParty2LeiPrefix(null);
				eodSubmsnTracker.setParty2Lei(null);
				eodSubmsnTracker.setSentTo(null);
				eodSubmsnTracker.setSentBy(null);
				eodSubmsnTracker.setDataSubmitter(null);
				eodSubmsnTracker.setResponseStatus(null);
				eodSubmsnTracker.setCobDate(cobDate);
				submissionTrackerList.add(eodSubmsnTracker);
			}
		
			regRepEodSubmissionsTrackerDaoImpl.batchInsertEodSubmissionTracker(submissionTrackerList);
		} catch (Exception e) {
			logger.error("######### Failed to persist trades in REG_REP_EOD_SUBMISSION_TRACKER - " + ExceptionUtils.getFullStackTrace(e));
		}
	}


}
