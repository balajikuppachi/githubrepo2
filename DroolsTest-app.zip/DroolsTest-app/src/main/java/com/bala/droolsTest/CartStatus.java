package com.bala.droolsTest;


public enum CartStatus {
NEW,
PROCESSED,
PENDING
}
