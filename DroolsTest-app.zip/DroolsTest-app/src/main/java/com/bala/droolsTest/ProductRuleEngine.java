package com.bala.droolsTest;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;
import org.apache.log4j.Logger;

public class ProductRuleEngine {
	
	private static final Logger logger = Logger.getLogger(ProductRuleEngine.class);
	
	
	public static final void main(String[] args) {
		try {
			Product p1 = new Product("Laptop", 600);
			p1.setAvailableQty(0);
			Product p2 = new Product("Mobile", 1650);
			p2.setRequiresRegistration(true);
			p2.setAvailableQty(1);
			Product p3 = new Product("Books", 100);
			p3.setAvailableQty(5);
			Product p4OutOfStock = new Product("TV", 2000);
			p4OutOfStock.setAvailableQty(0);

			Product p5 = new Product("Tab", 10000);
			p5.setAvailableQty(2);

			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer.newKieSession("productKS");
			kSession.setGlobal("logger", logger);
			
			kSession.insert(p1);
			logger.info("************* Fire Rules P1**************");
			kSession.fireAllRules();
			logger.info("*****************P1 End*******************");
			
			
			kSession.insert(p3);
			logger.info("************* Fire Rules P3**************");
			kSession.fireAllRules();
			logger.info("******************P3 End******************");
			
			
			
			
			kSession.insert(p2);
			logger.info("************* Fire Rules  P2**************");
			Agenda agenda = kSession.getAgenda();
			agenda.getAgendaGroup( "productAgenda" ).setFocus();
			kSession.fireAllRules();
			logger.info("*****************P2 End*******************");
			
			
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}
}
